//CONFIG-Array
var config_array = [];
config_array["features"] = ["diagram", "filter", "facet", "tree", "basket"];

//Diagramwerte
config_array["diagram_min_year"] = 5;
config_array["diagram_max_year"] = 110;
config_array["diagram_every_x_years"] = 10;

//Felder fuer Text-Facettierung
config_array["facet_array"] = ['SPEAKER_SEX_CLEAN_all_facet'];

//hierarische Baum-Suche
config_array["tree_array"] = ["LOC_CLEAN_all_facet"];

//Tabellewerte in Treferliste
config_array["table_array"] = ['py_sort_string', 'sex', 'loc', 'mode_string', 'file', 'show_text', 'download', 'online'];