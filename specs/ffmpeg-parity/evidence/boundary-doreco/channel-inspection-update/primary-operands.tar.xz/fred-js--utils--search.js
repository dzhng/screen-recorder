//Zuletzt gedrueckte Taste (z.B. keine neue Suche bei Space)
var pressedKey = 0;

//Tasten bei denen keine Ajaxanfrage losgeschickt werden soll (z.B. Space)
var keysWithoutAction = new Array(9, 16, 17, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 116, 123);

//Suchfelder mit Funktion belegen
function prepareSearchForm() {

    //Bei Suche in Input oder Enter oder Klick auf Input leeren (sonst doppelte Suche)
    $('#searchfields input').on("search keyup", function (event) {

        //zuletzt gedrueckte Taste merken
        pressedKey = event.keyCode;

        //Enter uber search steuern, nicht ueber keyup
        if (pressedKey !== 13) {

            //Bei bestimmten Tasten keine Ajaxanfrage (z.B. Space)
            if ($.inArray(pressedKey, keysWithoutAction) === -1) {

                //Suchanfrage losschicken
                sendQuery("search");
            }
        }
    });

    //Bei Klick auf Reset Button
    $('.selectbox_filter').change(function () {

        //Suchanfrage losschicken
        sendQuery();
    });

    //Bei Klick auf Reset Button
    $('#reset_form').click(function () {

        //Suchefelder, Filter und Facetten leeren
        reset_form();

        //ungefilterte *:* Suchanfrage losschicken
        sendQuery();

        //ersten Input in Suchmaske fokusieren
        $("#searchfields input:first").focus();
    });

    //Beim Hover eines Info-Icons bei der Select-Search
    $('.select_search_help').hover(function () {

        //Derzeit selektiertes Select-Feld holen
        var field = $(this).parent().find("select").val();

        //Zugehoerige Hilfe anzeigen
        $(this).find("div[data-help_id='" + field + "']").show();
    }, //beim Verlassen des Hovers
            function () {

                //alle Hilfetext ausblenden
                $(this).children().hide();
            }
    );

    //Wenn es das Feature automcomplete gibt
    if (has_feature("autocomplete")) {

        //Autocomplete laden
        activeSearchAutoComplete();
    }
}

//Autocomplete aktivieren
function activeSearchAutoComplete() {

    //Autocomplete fuer die konfigurierten Felder anlegen (alles Einzelfelder, keine Select-Search Felder)
    $.each(config_array["autocomplete_array"], function (i, field) {

        //_edgy und _text-Felder brauchen trotzdem ein _string-Feld für das das Automcomplete laueft
        var fieldCheck = field.replace(/_edgy/g, "_facet");
        fieldCheck = fieldCheck.replace(/_text/g, "_facet");

        //Autocomplete ueber Proxy
        $('input[name^="' + field + '"]').autocomplete({
            source: "php/utils/solr_proxy_suggestions.php?type=" + fieldCheck + "&limit=10",
            minLength: 1,
            focus: function (event, ui) {

                //Wert auf aktuell gehoverten Wert setzen damit Validierung richtig funktioniert
                $(this).val(ui.item["value"]);

                //Suchanfrage losschicken
                sendQuery();
            }
        });
    });

    //Bei Aenderungen eines Select-Search Selects
    $('select.select_search_field').change(function () {

        //ausgeawaehlten Wert holen
        var field = $(this).find("option:selected").val();

        //wenn es ein Automcomplete-Wert ist
        if ($.inArray(field, config_array["autocomplete_array"]) > -1) {

            //_edgy und _text-Felder brauchen trotzdem ein _string-Feld für das das Automcomplete laueft
            var fieldCheck = field.replace(/_edgy/g, "_facet");
            fieldCheck = fieldCheck.replace(/_text/g, "_facet");

            //Autocomplete fuer benachbarten Input mit diesem Feld anlegen
            $(this).next().autocomplete({
                source: "php/utils/solr_proxy_suggestions.php?type=" + fieldCheck + "&limit=10",
                minLength: 1,
                focus: function (event, ui) {

                    //Wert auf aktuell gehoverten Wert setzen damit Validierung richtig funktioniert
                    $(this).val(ui.item["value"]);

                    //Suchanfrage losschicken
                    sendQuery();
                }
            });
        }

        //kein Autocompletewert
        else {

            //Autocomplete bei benachbartem Input deaktivieren
            $(this).next().autocomplete("destroy");
        }
    });

    //Zu Beginn ueber Select-Search Inputs gehen
    $.each($('input[name="select_search"]'), function () {

        //Ausgewaehltes benachbartes Select auslesen
        var field = $(this).prev().find("option:selected").val();

        //Wenn es ein Autocomplete Feld ist
        if ($.inArray(field, config_array["autocomplete_array"]) > -1) {

            //_edgy und _text-Felder brauchen trotzdem ein _string-Feld für das das Automcomplete laueft
            var fieldCheck = field.replace(/_edgy/g, "_facet");
            fieldCheck = fieldCheck.replace(/_text/g, "_facet");

            //Autocomplete fuer dieses Input mit passendem Feld anlegen
            $(this).autocomplete({
                source: "php/utils/solr_proxy_suggestions.php?type=" + fieldCheck + "&limit=10",
                minLength: 1,
                focus: function (event, ui) {

                    //Wert auf aktuell gehoverten Wert setzen damit Validierung richtig funktioniert
                    $(this).val(ui.item["value"]);

                    //Suchanfrage losschicken
                    sendQuery();
                }
            });
        }
    });
}

//Komplette Form (Suchefelder, Filter und Facetten) zuruecksetzen
function reset_form() {

    //Wenn es Selectfilerboxen gibt (Ordenssuche St. Peter), diese auf 1. Wert zuruecksetzen
    $('#searchfields select.selectbox_filter').prop('selectedIndex', 0);

    //Wenn es ein Diagramm gibt
    if (has_feature("diagram")) {

        //Wenn die Titel ohne Jahr derzeit nicht angezeigt werden
        if (!$(".tristate_checkbox").hasClass("checked")) {

            //Wieder alle Titel anzeigen (auch ohne Jahr)
            $(".tristate_checkbox").addClass("checked");
        }
    }

    //Wenn es ein Diagram oder Facetten gibt
    if (has_feature("diagram") || has_feature("facet")) {

        //Facetten + Diagram zuruecksetzen
        reset_facet("all");
    }

    //wenn es Filter gibt
    if (has_feature("filter")) {

        //Alle Filter auf "nicht ausgewaehlt" zurucksetzen
        $("div[data-selected]").attr("data-selected", "false");
    }

    //Wenn es Treesuche gibt
    if (has_feature("tree")) {

        //ueber alle Baeume gehen
        $.each(config_array["tree_array"], function (i, tree_id) {

            //Alle Knoten im Baum deselektieren und Baum zuklappen
            $('#tree_' + tree_id).jstree("deselect_all");
            $('#tree_' + tree_id).jstree("close_all");

            //Suchefelder fuer Baumfilterung zuruecksetzen
            $('.tree_search_input').val("");
        });
    }

    //Alle Textfelder leeren
    $('#site_content_search input').val("");
}