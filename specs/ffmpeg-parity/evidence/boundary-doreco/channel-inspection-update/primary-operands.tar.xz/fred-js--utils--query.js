//Variable um Ajax-Request vorzeitig abzubrechen
var xhr;

//Anzahl der Treffer Seite: Standardwert 200
var displayRows = 30;

//Variable um SolrAntwort zwischenzuspeichern
var data;

//q-Parameter fuer Solr-Anfrage
var query = "";

//Anfrage, die geschickt wird, wenn Suchanfrage zu kurz ist -> liefert keine Treffer
var standardQuery = "*:*";

//Variable fuer Filterquery und Jahresfilterquery
var filterQueryString = "";
var yearQueryString = "";

//Zu Beginn bei Datensatz 1 (Offset 0) starten
var startAt = 0;

//Aktuelle Antwort mit vorheriger vergleichen. Tabelle nur neu aufbauen, wenn Treffermenge anders
var fingerPrint = "";

//Anfrage abschicken und Ergebnis verarbeiten
function sendQuery(mode) {

    //vorherige Suchrequest ignorieren, wenn er noch nicht abgeschlossen ist, stattdessen neuen losschicken
    (xhr !== undefined) ? xhr.abort() : null;

    //Querystring fuer Facet und Filterqueries
    filterQueryString = '';

    //Suchanfrage berechnen
    setMainQuery();

    //Wenn es eine Filtersuche uber Selectbox gibt
    if (has_feature("selectbox_filter")) {

        //Filter setzen
        setSelectboxFilterQuery();
    }

    //Wenn Digramm vorhanden
    if (has_feature("diagram")) {

        //Jahresslider berechnen
        setYearQuery();
    }

    //Wenn es Facetten gibt
    if (has_feature("facet")) {

        //Facettenanfrage berechnen
        setFacetQuery();
    }

    //Wenn es Filter gibt
    if (has_feature("filter")) {

        //Filtersuche erzeugen
        setFilterQuery();
    }

    //Wenn es eine Baumsuche gibt
    if (has_feature("tree")) {

        //Filtersuche erzeugen
        setTreeQuery();
    }

    //Wenn es eine fixe Filterabfrage gibt
    if (has_feature("fixed_filter")) {

        //fixe Filterquery einbauen
        query += config_array["fixed_filter"];
    }

    //Wenn es keine Blaetteranfrage ist (sondern Suchfeld, Facette oder Sortierung)
    if (mode !== 'page') {

        //Auf Seite 1 mit Datensatz 1 beginnen
        startAt = 0;
        currentPage = 1;
    }

    //Anfrage zusammenbauen
    var ajax_query = query + filterQueryString + yearQueryString + "&sort=" + sortBy + "&start=" + startAt + "&rows=" + displayRows;

    //Ins passende Format umwandeln
    ajax_query = encodeURI(ajax_query);

    //Ajax-Request losschicken, xhr-Variable speichern, damit Request abgebrochen werden kann
    xhr = $.ajax({
        beforeSend: function () {

            //Ladebild anzeigen
            $('#loading_img').css("visibility", "visible");
        },
        type: 'POST',
        url: 'php/utils/solr_proxy.php',
        data: {
            query: ajax_query,
            mode: 'search'
        },
        dataType: 'json',
        success: function (responseData) {

            //Antwort zwischenspeichern
            data = responseData;

            //Trefferliste nur neu aufbauen, wenn es andere Treffer als vorher sind (unterschiedliche IDs), es werden nicht alle Treffer geliefert
            if (resultsAreDifferent()) {

                //Tabelle fuer Trefferliste erzeugen
                createResultTable();
            }

            //Anzeigelabel auf jeden Fall aktualisieren
            $('#small_result').text("(" + getResultCount() + ")");

            //Hintergrundfarbe bei td entfernen (wird fuer passende tds gleich gesetzt)
            $("#result div").removeClass("sort_td");

            //Div in Sortierspalte farblich hinterlegen (Ueberschrift + Zellen in Tabelle)
            $("#result .table_header > div:nth-child(" + sortPos + ")").addClass("sort_td");
            $("#result div[data-id] > div:nth-child(" + sortPos + ")").addClass("sort_td");

            //Wenn es Facetten gibt
            if (has_feature("facet") || has_feature("diagram")) {

                //Facetten erstellen
                createFacets(mode);
            }

            //Wenn eine Baumsuche gibt und die Trefferanzahl angezeigt werden soll
            if (has_feature("tree") && !has_feature("tree_no_count")) {

                //Zaehlwerte bei Knoten anpassen
                updateTreeCount();
            }

            //Ladebild ausblenden
            $('#loading_img').css("visibility", "hidden");
        }
    });
}

//Hauptsuchanfrage zusammenbauen
function setMainQuery() {

    //Array, dass die einzelnen Werte der Textfelder speichert
    var queryArray = [];

    //Wenn es spezielle Suche gibt (z.B. stpeter-Blaettern)
    if (has_feature("special_search")) {

        //Werte der speziellen Suche sammeln
        queryArray = special_search();
    }

    //Werte aus Inputfeldern holen
    $.each($('#searchfields input'), function () {

        //Wert holen
        var val = $.trim($(this).val());

        // solr-sonderzeichen escapen
        val = val.replace(/(\+|-|&&|\|\||!|\(|\)|\{|}|\[|]|\^|\)|\)\)|~|\*|\?|:|\\)/g,  "\\$1");
		
        //Um welches Feld geht es
        var name = $(this).attr("name");

        //Wenn es ein Feld ist, dessen Solr-Suchfeld von einem Select Feld abhaengt
        if (name === "select_search") {

            //steht das Solr-Suchfeld im value der ausgewaehlten Select-Option
            name = $(this).prev().val();
        }

        //Steht etwas im Feld?
        if (val.length > 0) {

            //Es ist ein normales Feld, Expertensuche kommt unten
            if (name !== "expert") {

                //bei edgy Suchen
                if (name.match(/edgy$/)) {

                    //auch in Textfeld suchen -> name_edgy -> name_text
                    var text_field_name = name.replace(/edgy/, 'text');

                    //auch in Stringfeld suchen -> name_edgy -> name_string
                    var string_field_name = name.replace(/edgy/, 'string');

                    //"" verwenden bei edgy
                    queryArray.push('(' + string_field_name + ':"' + val + '" OR ' + name + ':"' + val + '" OR ' + text_field_name + ':(' + val + '*))');
                }

                //bei text Suchen
                else {

                    //Bei all_text gibt es die Moeglichkeit auch noch in weiteren Feldern (z.B. Abstract, Volltext) zu suchen
                    if (name === "all_text") {

                        //Zunaechst die all_text-Anfrage aufbauen
                        var all_text_search_string = 'all_text:(' + val + '*)';

                        //Nun ggf. ueber weitere Felder gehen, die per OR mit dem gleichen Wert wie das all_text-Feld durchsucht werden
                        $.each($('.po_r.all div[data-selected="true"]'), function () {

                            //Solr-Feld holen
                            var field = $(this).attr("data-search_value");

                            //Anfrage per OR zu all_text-Suchanfrage hinzufuegen
                            all_text_search_string += ' OR ' + field + ':(' + val + '*)';
                        });

                        //Anfrage in queryArray einfuegen, dabei sicherstellen, dass die all_text-Anfragen zusammengefuegt bleiben
                        queryArray.push("(" + all_text_search_string + ")");
                    }

                    //Anderes Textfeld
                    else {

                        //() verwenden und rechtstrunkiert suchen
                        queryArray.push(name + ':(' + val + '*)');
                    }
                }
            }

            //Expertensuche
            else {

                //Feld + Name steht komplett im Input: z.B. period_all_facet:"18th century"
                queryArray.push(val);
            }
        }
    });

    //einzelne Terme mit + (=AND) verbinden
    var queryTerms = queryArray.join('+');

    //Bei leerer Anfrage Standardanfrage senden
    if (queryTerms.length === 0) {
        query = standardQuery;
    }

    //ansonsten Suchenfrage zusammenbauen
    else {

        //Anfrage
        query = queryTerms;
    }
}

//Facetten fuer Suchanfrage holen und Filterquery bauen
function setFacetQuery() {

    //Alle Facetten durchgehen und Querystring bauen
    $.each(config_array["facet_array"], function (i, facetName) {

        //Wenn keine Facettenwerte gewaehlt -> Suche nach *
        if (selectArray[facetName].length === 0) {

            //Wenn nach * gesucht wird, kein Tag und Ex, da kein Multiselect
            var facetFieldString = '&facet.field=' + facetName;

            //fq mit Tag setzen
            var fqPrefix = '&fq=' + facetName + ':(';
            var fqString = '*)';
        }

        //Facetten aus Arraywerten zusammenbauen
        else {

            //facet.field exclusion einfuegen -> Facette werden angezeigt auch wenn sie nicht angeklickt sind -> Multiselect moeglich
            facetFieldString = '&facet.field={!ex=' + facetName + '}' + facetName;

            //Wenn Werte innerhalb einer Facette mit AND verknuepft werden sollen
            if (has_feature("facet_and")) {

                //fq
                fqPrefix = '&fq=' + facetName + ':("';

                //Elemente aus Array mit Operator zusammenfuehren
                fqString = selectArray[facetName].join('" AND "');
                fqString += '")';
            }

            //fq per OR
            else {

                //fq mit Tag setzen
                fqPrefix = '&fq={!tag=' + facetName + '}' + facetName + ':("';

                //Elemente aus Array mit Operator zusammenfuehren
                fqString = selectArray[facetName].join('" OR "');
                fqString += '")';
            }
        }

        //Filterquery aufbauen fuer alle Facetten
        filterQueryString += facetFieldString + fqPrefix + fqString;
    });
}

//Filterquery
function setFilterQuery() {

    //Ueber Filterbloecke gehen
    $.each($('div[data-filter_field]'), function (i, filter_block) {

        //Solr Feldname fuer Fitleranfrage
        var filter_field = $(filter_block).attr("data-filter_field");

        //Filterwerte sammeln
        var value_array = [];

        //ueber angehakte Werte gehen
        $.each($(filter_block).find(('div[data-selected="true"]')), function () {

            //Wert in Array sammeln
            value_array.push($(this).attr("data-search_value"));
        });

        //Wenn es Werte gibt
        if (value_array.length > 0) {

            //Filterstring anpassen
            filterQueryString += '&fq=' + filter_field + ':(' + value_array.join(" OR ") + ')';
        }
    });
}

//Selectbox-Filterquery
function setSelectboxFilterQuery() {

    //Ueber Filterbloecke gehen
    $.each($('select.selectbox_filter'), function (i, filter_block) {

        //Solr Feldname fuer Fitleranfrage
        var filter_field = $(filter_block).attr("data-field");

        //ausgeaehlten Wert holen
        var search = $(this).find("option:selected").val();

        //Filterstring anpassen
        filterQueryString += '&fq=' + filter_field + ':"' + search + '"';
    });
}

//Tree-Query
function setTreeQuery() {

    //Ueber Treewerte gehen
    $.each(config_array["tree_array"], function (i, tree_id) {

        //Wenn es ausgewaehlte Werte bei diesem Baum gibt
        if ((tree_data_selected_array[tree_id]).length > 0) {

            //Werte per OR zusammenfuegen, trotzdem auch andere Werte holen (tag)
            filterQueryString += '&fq={!tag=' + tree_id + '}' + tree_id + ':("' + (tree_data_selected_array[tree_id]).join('" OR "') + '")';
        }

        //Facette aus Solr laden, dabei auch die nicht ausgewaehlten Werte anzeigen (ex), alle Werte holen und auch 0 Werte anzeigen
        filterQueryString += '&facet.field={!ex=' + tree_id + '}' + tree_id + '&f.' + tree_id + '.facet.limit=-1&f.' + tree_id + '.facet.mincount=0&';
    });
}

//Jahresabfrage zusammenbauen
function setYearQuery() {

    //Bereichsabfrage bauen, Tag damit auch Treffer ausserhalb des selektierten Bereichs geholt und angezeigt werden
    yearQueryString = "&fq={!tag=py_all_facet}py_all_facet:[" + years[0] + " TO " + years[1] + "]";

    //Pruefen, ob Titel ohne Jahresangabe angezeigt werden sollen. Das ist der Fall, wenn die Checkbox div angehakt ist
    if ($('#noYear div.checked').length) {
        yearQueryString += ' OR py_all_facet:0';
    }
}

// SOLR-FUNCTIONS: Werte aus Antwort auslesen

//Anzahl der Treffer einer Solr-Suchanfrage liefern
function getResultCount() {
    return data.response.numFound;
}

//Alle Dokumente einer Solr-Suchanfrage holen
function getDocuments() {
    return data.response.docs;
}

//fuer eine Facette die Werte als Array holen
function getFacetValues(facetName) {
    return data.facet_counts.facet_fields[facetName];
}

//Pruefen ob 2 Anfragen unterschiedliche Ergebnisse liefern
function resultsAreDifferent() {

    //String fuer neuen Fingeradruck der Antwort
    var fingerPrintString = "";

    //Ueber Dokumente gehen und ID-String bauen
    $.each(getDocuments(), function (i, val) {

        //FingerPrint der Antwort erstellen
        fingerPrintString += "/" + val.id;
    });

    //Mit vorheriger Anfrage vergleichen
    var sameQuery = (fingerPrintString !== fingerPrint);

    //Neuen Fingeradruck speichern
    fingerPrint = fingerPrintString;

    //Ergebnis zurueckliefern
    return sameQuery;
}

//Werte fuer zusaetzliche Zeile oder Merklistenexport auslesen und formattieren (Einzelwert)
function getSingle(doc, field, header, format) {

    //Ausgabewert
    var output = "";

    //Wenn Wert vorhanden ist
    if (doc[field] !== undefined && doc[field] !== "") {

        //Welche Anzeigeform?
        switch (format) {

            //nur Wert auslesen
            case "clean":
                output = doc[field];
                break;

                //mehrere Werte zusammenfuegen
            case "pre":
                output = header + doc[field];
                break;

                //Label + Span
            case "label":
                output = "<label>" + header + ":</label><span>" + doc[field] + "</span><br/>";
                break;

                //Link erzeugen
            case "url":

                //und Werte in a schrieben
                output += "<label>" + header + ":</label><span><a class='external_link' target='_blank' href='" + doc[field] + "'>Link</a></span>";
                break;

                //Textexport
            case "text":
                output = header + ": " + doc[field] + "<br />";
                break;

                //Bibtextexport
            case "bibtex":
                output = "  " + header + " = {" + doc[field] + "},\n";
                break;

                //Coins fuer Citaviexport
            case "coins":
                output = "&rft." + header + "=" + doc[field];
                break;
        }
    }

    //Werte zurueckgeben
    return output;
}

//Werte fuer zusaetzliche Zeile oder Merklistenexport auslesen und formattieren (Multiwert mit Join)
function getMulti(doc, field, header, format) {

    //Ausgabewert
    var output = "";

    //Wenn Wert vorhanden ist
    if (doc[field] !== undefined && doc[field] !== "") {

        //Welche Anzeigeform?
        switch (format) {

            //nur Werte auslesen
            case "clean":
                output = doc[field].join("<br />");
                break;

                //lokale Verfuegbarkeit nur ein Link bei mehreren
            case "opac_link_single":

                //Suche nach ISBN
                var index = "sb";

                //Bei ISSN
                if (header === "ISSN") {

                    //Suche im OPAC nach ISSN
                    index = "ss";
                }

                //ueber einzelne Werte gehen
                $.each(doc[field], function (i, val) {

                    //Link auf OPAC
                    output = "<label>" + header + ":</label><a class='opac_link' target='_blank' href='https://katalog.ub.uni-freiburg.de/link?" + index + "=" + val + "'>lokale Verfügbarkeit prüfen</a> " + val + "<br>";
                });
                break;

                //lokale Verfuegbarkeit
            case "opac_link":

                //Suche nach ISBN
                var index = "sb";

                //Bei ISSN
                if (header === "ISSN") {

                    //Suche im OPAC nach ISSN
                    index = "ss";
                }

                //ueber einzelne Werte gehen
                $.each(doc[field], function (i, val) {

                    //Link auf OPAC
                    output += "<label>" + header + ":</label><a class='opac_link' target='_blank' href='https://katalog.ub.uni-freiburg.de/link?" + index + "=" + val + "'>lokale Verfügbarkeit prüfen</a> " + val + "<br>";
                });
                break;

                //fuer Linkresolver aufbereiten
            case "linkresolver":
                output = "&" + header + "=" + doc[field][0];
                break;

                //Label + Span
            case "label":
                output = "<label>" + header + ":</label><span>" + doc[field].join("<br />") + "</span><br />";
                break;

                //Label + einzelne Werte in Spans
            case "single_values":

                //Label + Sammelspan
                output = "<label>" + header + ":</label><span>";

                //ueber einzelne Werte gehen
                $.each(doc[field], function (i, val) {

                    //und Werte in spans schrieben
                    output += "<span data-field='" + field + "'>" + val + "</span><br />";
                });

                //Sammelspan schliessen
                output += "</span>";
                break;

                //Link erzeugen
            case "url":

                //ueber einzelne Werte gehen
                $.each(doc[field], function (i, val) {

                    //und Werte in spans schrieben
                    output += "<label>" + header + ":</label><span class='v_m'><a class='external_link' target='_blank' href='" + val + "'>Link</a></span>";
                });
                break;

                //Textexport
            case "text":
                output = header + ": " + doc[field].join("; ") + "<br />";
                break;

                //Bibtextexport
            case "bibtex":
                output = "  " + header + " = {" + doc[field].join(" and ") + "},\n";
                break;

                //Coins fuer Citaviexport
            case "coins":

                //Ueber Felder gehen und Werte eintragen
                $.each(doc[field], function (i, val) {
                    output += "&rft." + header + "=" + val;
                });
                break;
        }
    }

    //Werte zurueckgeben
    return output;
}