//INIT-FUNCTIONS

//Spezielle Einstellungen fuer diese Instanz
function special_init(early_init) {

    //Beim 1. Aufruf des inits
    if (early_init) {

        //Bibtext-Export Button entfernen
        $('div[data-format="bib"]').remove();
        $('div[data-format="txt"]').remove();       
        $('#zip_export').show();

        //Felder auf english setzen
        $('#searchfields .blue_header').text("Search");
        $('label[for="search_all"]').text("Full text:");
        $('#search_all').attr("placeholder", "Full text");
        $('#titles_without_year').text("speakers without age information");
        $('#result_label').text("Results");
        $('#reset_form').html("New search");
        $('#basket_label').text("Saved items");
        $('.no_results').text("No results");
        $('.remember').text("Save");
        $('#reset_basket').text("Clear list");
        $('div[data-format=txt]').text("Save as text file");
        $('#pdf_export').text("Save as pdf file");
        $('#zip_export').text("Save as zip file");
        $('#pdf_export').remove();
        $('#hide_search span:eq(0)').html("Hide search form");
        $('#hide_search span:eq(1)').html("Show search form");

        //Alle Filter vorauswaehlen
        //$("div[data-filter_field] div[data-func='filter_search']").attr("data-selected", true);
        $("div[data-filter_field] div[data-search_value='FRED-S']").attr("data-selected", true);
        $("div[data-filter_field] div[data-search_value='FRED-S']").attr("title", 'Subset of texts and audio files from FRED. Comprises about 1 million words of orthographically transcribed texts from 121 interviews, covering five major dialect areas (SW England, SE England, Midlands, N England, Scottish Lowlands). Fully accessible online.');
        $("div[data-filter_field] div[data-search_value='FRED']").attr("title", 'Monolingual spoken-language corpus of regional English dialects. Samples 372 interviews with native speakers, amounting to approximately 2.5 million words of orthographically transcribed text. Covers nine major dialect areas (SW England, SE England, Midlands, N England, Scottish Lowlands, Scottish Highlands, Hebrides, Wales, Isle of Man). Not (yet) accessible online. ');
        
        $(".tabs_body").on("click", "div[data-id] > div", function () {

            //Wenn es nicht der Merkbutton ist
            if (!$(this).hasClass("remember") && !$(this).hasClass("w5") && !$(this).hasClass("add_content")) {                
                //Wenn Info geschlossen ist (=hat nicht Klasse open)
                if (!$(this).parent().hasClass("open")) {

                    //CSS-Klasse anpassen
                    $(this).parent().addClass("open");

                    //DokumentID auslesen (ueber .attr, weil .data fuehrende Nullen entfernt
                    var docID = $(this).closest("div[data-id]").attr("data-id");

                    //Wenn Daten schon zwischengespeichert wurden
                    if (addInfoArray[docID] !== undefined) {

                        //zwischengespeichten Inhalt einfuegen
                        $(this).parent().after("<div class='addInfo' data-id='"+docID+"'><div class='no_border more'></div><div class='add_content'>" + addInfoArray[docID] + "</div></div>");
                    }

                    //Daten noch nicht gespeichert
                    else {

                        //Daten per Ajax-Anfrage holen
                        $.ajax({
                            type: 'POST',
                            url: 'php/utils/solr_proxy.php',
                            context: this,
                            data: {
                                query: "id:" + docID,
                                mode: 'extra_data'
                            },
                            dataType: 'json',
                            success: function (responseData) {

                                //Daten im passenden Format vorbereiten
                                var prep = prepare_extra_data(responseData.response.docs[0]);

                                //Inhalt einfuegen
                                $(this).parent().after("<div class='addInfo' data-id='"+docID+"'><div class='no_border more'></div><div class='add_content'>" + prep + "</div></div>");

                                //Wert speichern, damit er beim naechsten Mal nicht neu geholt werden muss
                                addInfoArray[docID] = prep;
                            }
                        });
                    }
                }

                //Zeile ist geoeffnet
                else {

                    //CSS-Bild anpassen
                    $(this).parent().removeClass("open");

                    //Info Zeile entfernen
                    $(this).parent().next('.addInfo').remove();

                    //Border unten wieder grau machen
                    $(this).css("border-bottom", "1px solid grey");
                }
            }
        });
    }

    //beim 2. Aufruf des inits
    else {

        //Durch 2 Klicks auf Spaltenueberschrift eine nach Jahr absteigend sortierte Tabelle erstellen
        $('#result div[data-field="py_sort_string"]').trigger("click");
        $('#result div[data-field="py_sort_string"]').trigger("click");

        //Eventlistener einfuegen um aktuell laufendes Audio stoppen, wenn anderes Audio gestartet wird
        window.addEventListener("play", function (evt) {

            //wenn es ein laufendes Audio gibt und es sich nicht um die aktuell abspielende handelt
            if (window.$_currentlyPlaying && window.$_currentlyPlaying !== evt.target) {

                //dieses stoppen
                window.$_currentlyPlaying.pause();
            }

            //gestartetes Audio merken
            window.$_currentlyPlaying = evt.target;
        }, true);

        //Filterbereichsinhalt in Suchbereich einfuegen
        $('#searchfields').append($('#filters').children());

        //Leeren Filterbereich ausblenden
        $('#filters').hide();

        //Bei Klick auf "show text" Button
        $('#results').on("click", "span.show_text", function () {

            //DOC-ID holen
            var docid = $(this).attr("data-docid");

            //Popup-Fenster anlegen                        
            window.open("config/fred/show_text.php?docid=" + docid, docid, "width=600, height=700, scrollbars=yes");
        });
    }
}

//TABLE-FUNCTIONS

//Ausgabewerte fuer Suche transformieren
function get_table_values(doc) {

    //Werte holen
        
    doc["loc"] = getMulti(doc, "LOC_CLEAN_all_string", "", "clean");
    doc["sex"] = getMulti(doc, "SPEAKER_SEX_CLEAN_all_string", "", "clean");
    doc["file_name"] = getMulti(doc, "file_all_string", "", "clean");

    //Leere Felder anlegen
    doc["file"] = "";
    doc["show_text"] = "";
    doc["download"] = "";

    //Nur FRED-S derzeit
    if (doc["mode_string"] === "FRED-S") {

        //Es koennen mehrere Dateien Eintrag sein
        var filesname_array = [];
        var files_array = [];

        //Ueber file_names gehen
        $.each(doc["TEXTS_all_string"], function (i, file_name) {

            //Dateiname merken
            filesname_array.push(file_name);

            //Name + Audio Element aufbauen, noch kein Audio vorladen
            var content = "<audio controls preload='none'><source src='files/fred/audio/" + file_name + ".mp3' type='audio/mpeg'></audio>";

            //Button "show text" für popup
            doc["show_text"] += "<span class='show_text' data-docid='" + file_name + "'>show text</span>";

            //Dateidownload fuer audio, text und text_tagged
            doc["download"] += "<div class='download_block'>";
            doc["download"] += "<a onclick='download_zip("+doc["id"]+")' class='file_download'>audio</a>";
            doc["download"] += "<a download href='files/fred/text/" + file_name + ".txt" + "' class='file_download'>text</a>";
            doc["download"] += "<a download href='files/fred/text_tagged/" + file_name + "_clean_htagged.txt' class='file_download'>tagged</a>";
            doc["download"] += "</div>";

            //In Array merken
            files_array.push(content);
        });

        //(mehrere) Datei(en) fuer Ausgabe zusammenbauen
        doc["file"] = files_array.join("<br>");
    }

    //Wenn kein Jahr gesetzt
    if (doc["py_sort_string"] === 0) {

        //unknown
        doc["py_sort_string"] = "unknown";
    }

    //Online-Status
    doc["online"] = "";

    //Ueber Online Status gehen
    $.each(doc["online_all_string"], function (i, state) {

        //Status-DIV(s) anzeigen
        doc["online"] += "<div class='online_state online_" + state + "'></div>";
    });

    //Array zurueckgeben
    return doc;
}

    //PDF-Exportdatei erzeugen
    function download_zip(doc_id) {        
        
        //IDs in hidden Feld speichern
        $('#basket input[name="audio_only"]').val("1");
        $('#basket input[name="id_array"]').val(doc_id);        
        $('#basket form[name="zip_form"]').submit();
        $('#basket input[name="audio_only"]').val("");
    };


//Volltefferanzeige in zusaetzlicher Zeile
function prepare_extra_data(doc) {

    //Ausgabewerte sammeln
    var add = "";

    //Felder ausgeben
    add += getMulti(doc, "TEXTS_all_string", "File", "label");
    add += getMulti(doc, "SPEAKER_ID_all_string", "Speaker ID", "label");
    add += getMulti(doc, "AREA_CLEAN_all_string", "Area", "label");
    add += getMulti(doc, "COUNTY_CLEAN_all_string", "County", "label");
    add += getMulti(doc, "SPEAKER_DOB_CLEAN_all_string", "Speaker Date of Birth", "label");
    add += getMulti(doc, "SPEAKER_DECADE_CLEAN_all_string", "Speaker Decade", "label");
    add += getMulti(doc, "REC_DATE_CLEAN_all_string", "Record Date", "label");
    add += getMulti(doc, "REC_DECADE_CLEAN_all_string", "Record Decade", "label");
    add += getMulti(doc, "EEXTENT_all_string", "Word Count", "label");

    //Werte zurueckgeben
    return add;
}

//Exportformate erzeugen
function create_export_format(file_type, doc) {
    
    //Ausgabewert
    var output = "";

    //unterschiedliche Formate erzeugen
    switch (file_type) {

        //Textdatei
        case "txt":
            output += getMulti(doc, "AREA_CLEAN_all_string", "Area", "text");
            break;
    }

    //Werte zurueckgeben
    return output;
}