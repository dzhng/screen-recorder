# Multi-CAST English

## How to cite

If you use these data please cite
- the original source
  > Schiborr, Nils N. 2022. Multi-CAST English. In Haig, Geoffrey & Schnell, Stefan (eds.), Multi-CAST: Multilingual corpus of annotated spoken texts. Version 2211. Bamberg: University of Bamberg. (multicast.aspra.uni-bamberg.de/#english) (date accessed)
- the derived dataset using the DOI of the [particular released version](../../releases/) you were using

![](cldf/media/image.jpg)

## Description


The Multi-CAST **English** ([sout3282](https://glottolog.org/resource/languoid/id/sout3282)) corpus contains auto- biographical narratives taken from the *[Freiburg English Dialect Corpus](https://fred.ub.uni-freiburg.de/)* (FRED, [English Dialects Research Group 2005](Source#cldf:englishdialectsresearchgroup2005)), which has been compiled under the supervision of Bernd Kortmann and Lieselotte Anderwald at the University of Freiburg from texts recorded during the 1970s and 80s as part of various oral history projects.

The texts annotated for Multi-CAST were recorded with older working-class speakers from southern and southeastern England. They depict everyday scenes and personal experiences from the speakers' lives: recurring topics include agriculture, animal husbandry, shipwrighting, work in the London docks, and the two World Wars.

A subset of the texts in this corpus (version 2207) have been time-aligned at the phone level for a [data set](https://doreco.huma-num.fr/languages/sout3282) in the [DoReCo project](https://doreco.huma-num.fr/).

The audio recordings (WAV, MP3) in this corpus are in the public domain.

This dataset is licensed under a CC-BY-4.0 license

Available online at https://multicast.aspra.uni-bamberg.de/#english


```geojson
{
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -1.0,
                    53.0
                ]
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -6.0,
                            58.0
                        ],
                        [
                            4.0,
                            58.0
                        ],
                        [
                            4.0,
                            48.0
                        ],
                        [
                            -6.0,
                            48.0
                        ],
                        [
                            -6.0,
                            58.0
                        ]
                    ]
                ]
            }
        }
    ]
}
```



## Corpus counts

Only a small number of basic GRAID symbols are counted:

*Function symbols*
- ⟨0⟩ zero
- ⟨pro⟩ definite pronoun
- ⟨np⟩ full noun phrase
- ⟨other⟩ form not further specified

*Person/Animacy symbols*
- ⟨.1⟩ first person
- ⟨.2⟩ second person
- ⟨.h⟩ third person, human
- ⟨.d⟩ third person, anthropomorphic
- ø third person, non-human

*Function symbols*
- ⟨:s⟩ subject of an intransitive clause
- ⟨:a⟩ subject of a transitive clause
- ⟨:ncs⟩ non-canonical subject
- ⟨:p⟩ direct object
- ⟨:obl⟩ oblique argument
- ⟨:g⟩ goal argument
- ⟨:l⟩ locational argument
- ⟨:pred⟩ predicate
- ⟨:poss⟩ possessive
- ⟨:other⟩ function not further specified

Only basic categories are listed; categories represented by complex symbols with additional
specifiers (e.g. ⟨dem_pro⟩ ‘demonstrative pronoun’) have been subsumed under the more basic
category (e.g. ⟨pro⟩ ‘definite pronoun’). Please refer to the annotation notes for this corpus for
information on all annotated categories, including those not listed here.

| GRAID | ⟨:s⟩ | ⟨:a⟩ | ⟨:ncs⟩ | ⟨:p⟩ | ⟨:obl⟩ | ⟨:g⟩ | ⟨:l⟩ | ⟨:pred⟩ | ⟨:poss⟩ | ⟨:other⟩ | totals |
|:--------------|-------:|-------:|---------:|-------:|---------:|-------:|-------:|----------:|----------:|-----------:|---------:|
| **⟨0.1⟩** | 140 | 222 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 363 |
| **⟨0.2⟩** | 51 | 138 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 189 |
| **⟨0.h⟩** | 109 | 252 | 0 | 10 | 0 | 1 | 0 | 1 | 0 | 1 | 374 |
| **⟨0.d⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨0⟩** | 163 | 49 | 0 | 90 | 10 | 8 | 2 | 20 | 0 | 6 | 348 |
| **⟨pro.1⟩** | 645 | 770 | 0 | 107 | 28 | 18 | 1 | 0 | 249 | 4 | 1822 |
| **⟨pro.2⟩** | 175 | 285 | 0 | 50 | 15 | 13 | 1 | 1 | 68 | 1 | 609 |
| **⟨pro.h⟩** | 530 | 468 | 0 | 83 | 26 | 11 | 1 | 0 | 113 | 2 | 1234 |
| **⟨pro.d⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨pro⟩** | 676 | 128 | 0 | 584 | 84 | 32 | 17 | 20 | 72 | 28 | 1641 |
| **⟨np.1⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨np.2⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨np.h⟩** | 194 | 136 | 0 | 111 | 71 | 46 | 3 | 104 | 37 | 36 | 738 |
| **⟨np.d⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨np⟩** | 361 | 36 | 0 | 1204 | 312 | 334 | 344 | 370 | 35 | 667 | 3663 |
| **⟨other.1⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨other.2⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨other.h⟩** | 12 | 15 | 0 | 11 | 1 | 1 | 0 | 1 | 0 | 2 | 43 |
| **⟨other.d⟩** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **⟨other⟩** | 28 | 8 | 0 | 91 | 17 | 137 | 125 | 877 | 0 | 3 | 1286 |
| | 3084 | 2507 | 0 | 2342 | 564 | 601 | 494 | 1394 | 574 | 750 | 12310 |


**Clause boundaries**

| GRAID | count |
|:-----------|--------:|
| **⟨##⟩** | 3907 |
| **⟨#⟩** | 1742 |
| **totals** | 5649 |



## Corpus metadata

- [Annotation notes](cldf/media/annotation-notes.pdf)
- [Metadata](cldf/media/metadata.pdf)
- [Translated texts](cldf/media/translated-texts.pdf)


## CLDF Datasets

The following CLDF datasets are available in [cldf](cldf):

- CLDF [TextCorpus](https://github.com/cldf/cldf/tree/master/modules/TextCorpus) at [cldf/TextCorpus-metadata.json](cldf/TextCorpus-metadata.json)