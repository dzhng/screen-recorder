CONTENTS OF THE BUNDLE

A bundle of additional documentation is provided with every bulk download of DoReCo datasets. This includes the following files:
    I) Project-wide files (same for all datasets):
        README file (doreco_#1_README.txt) includes:
            - Description of the contents of the bundle
            - How to cite the DoReCo database
        DoReCo conventions (doreco_#2_CONVENTIONS.txt) includes:
            - Tier name conventions 
            - Labelling conventions used in transcriptions for non-aligned elements
            - Morpheme type and morpheme break conventions
            - Word count method
    II) Language-specific files:
        Language information (doreco_[glottocode]_#1_dataset-info.txt) includes:
            - Information about the language, the corpus and its creator(s), including license information, and how to cite the downloaded dataset
        File metadata (doreco_[glottocode]_#2_metadata.csv) includes:
            - Speaker information: ID, age, sex
            - File information: genre, recording date, glossing coverage, word count, sound quality
        Grapheme-to-phoneme mappings (doreco_[glottocode]_#3_transcription-conventions.csv)
            - Correspondence tables mapping the symbols used in the fieldworker's transcription to X-SAMPA characters
        List of abbreviations (doreco_[glottocode]_#4_gloss-abbreviations.csv)
            - A list of abbreviations for grammatical categories on the “gl” and “ps” tiers and their meanings
        Changes to tier names (doreco_[glottocode]_#5_renamed-tiers.csv)
            - All changes made to tier names in a dataset

####################

HOW TO CITE

Please note that when actual data from any number of DoReCo datasets is used, the full reference for each individual dataset must be provided, including the name(s) of the creator(s) of each dataset. It is NOT sufficient to refer to DoReCo as a whole. We are aware that this may result in very long lists of references, but it is only in this way that corpus creators get due recognition for their work. The default is to include the full set of bibliographical references in the reference section of the main text of a paper or abstract. If this is absolutely impossible (because of page limit restrictions, for instance), then inclusion of the full list of references in an appendix is acceptable, or - as a last resort - in supplementary material published separately, e.g. on Zenodo or OSF, in which case the main text of the paper or the abstract must explicitly refer to this list and provide its URL or PID.

The reference for the DoReCo database as a whole (which does NOT replace references to datasets if actual data are used) is:
Seifart, Frank, Ludger Paschen & Matthew Stave (eds.). 2024. Language Documentation Reference Corpus (DoReCo) 2.0. Lyon: Laboratoire Dynamique Du Langage (UMR5596, CNRS & Université Lyon 2). DOI:10.34847/nkl.7cbfq779	

For the methods used in building DoReCo, the following can be cited:	
Paschen, Ludger, François Delafontaine, Christoph Draxler, Susanne Fuchs, Matthew Stave & Frank Seifart. 2020. Building a Time-Aligned Cross-Linguistic Reference Corpus from Language Documentation Data (DoReCo). In Proceedings of The 12th Language Resources and Evaluation Conference, 2657–2666. Marseille, France: European Language Resources Association. https://www.aclweb.org/anthology/2020.lrec-1.324

A web interface for easy access to DoReCo data and further information can be found at https://doreco.huma-num.fr.