import CoreImage
import CoreGraphics
import Foundation
let filter = CIFilter(name:"CIHighlightShadowAdjust")!
print(filter.attributes)
let space = CGColorSpace(name:CGColorSpace.extendedLinearSRGB)!
let context = CIContext(options:[.workingColorSpace:space,.workingFormat:CIFormat.RGBAh.rawValue])
let source:[Float] = [0,0,0,1,0.01,0.01,0.01,1,0.1,0.1,0.1,1,0.5,0.5,0.5,1,0.9,0.9,0.9,1,1,1,1,1]
let image = CIImage(bitmapData:source.withUnsafeBytes{Data($0)},bytesPerRow:source.count*4,size:CGSize(width:6,height:1),format:.RGBAf,colorSpace:space)
for shadow in [0.0,0.25,0.5,1] {
 for highlight in [0.0,0.25,0.5,1] {
  let result=image.applyingFilter("CIHighlightShadowAdjust",parameters:["inputShadowAmount":shadow,"inputHighlightAmount":highlight])
  var output=[Float](repeating:0,count:source.count)
  output.withUnsafeMutableBytes {context.render(result,toBitmap:$0.baseAddress!,rowBytes:source.count*4,bounds:image.extent,format:.RGBAf,colorSpace:space)}
  print("s=\(shadow) h=\(highlight) \(stride(from:0,to:output.count,by:4).map{output[$0]})")
 }
}
