from pathlib import Path
import sys
script=Path('/tmp/screenrec-audio-recipes/raw-reviewed-harness.py').read_text()
base=Path('/tmp/screenrec-audio-recipes/confirmation');dest=Path('/tmp/screenrec-audio-recipes/reviewed-confirmation');dest.mkdir(exist_ok=True)
script=script.replace('root.mkdir()','root.mkdir(exist_ok=True)')
start=script.index('def diff(')
replacement='''originalRun=run
def run(name,program,filt,detector=None):
 if name.startswith('l132-near'):
  outputPath=nearCache/(name+'.f32')
  if outputPath.exists():values=read(outputPath)
  else:
   values=originalRun(name,program,filt,detector)
   outputPath.write_bytes((root/(name+'.f32')).read_bytes())
 else:values=read(frozenRoot/(name+'.f32'))
 if fault=='polarity' and name.startswith('l'):values=[tuple(-x for x in row) for row in values]
 if fault=='makeup' and name.startswith('l'):
  originals=read(program)
  if name.endswith('crop'):originals=originals[len(originals)//4:len(originals)*3//4]
  ceiling=.375 if name.startswith('l132') else (.8 if name.startswith('l4') and not name.startswith('l3840') else .25)
  values=[tuple(x*min(4,ceiling/max(map(abs,row))) for x in row) if max(map(abs,row))<ceiling else actual for row,actual in zip(originals,values)]
 if fault=='instant' and name.startswith('compress'):
  programRows=read(program);detectorRows=read(detector)
  values=[tuple(x*(1 if max(map(abs,d))<=.1875 else (.1875/max(map(abs,d)))**(1-1/3)) for x in p) for p,d in zip(programRows,detectorRows)]
  if name.endswith('crop'):values=values[3107:15301]
 (root/(name+'-fault-operand.f32')).write_bytes(b''.join(struct.pack('<ff',*row) for row in values))
 return values
'''
script=script[:start]+replacement+script[start:]
cache=dest/'near-cache';cache.mkdir(exist_ok=True)
for fault in ['none','polarity','makeup','instant']:
 sys.argv=['dynamics.py','/tmp/screenrec zimg final/distribution/bin/ffmpeg',str(dest/fault)]
 try:exec(compile(script,'reviewed-dynamics.py','exec'),{'frozenRoot':base,'fault':fault,'nearCache':cache})
 except SystemExit:print('FAULT REJECTED',fault)
