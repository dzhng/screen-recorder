from pathlib import Path
import subprocess,struct,json,math,hashlib
root=Path('/tmp/screenrec-audio-recipes/normalization');root.mkdir(exist_ok=True)
ff='/tmp/screenrec zimg final/distribution/bin/ffmpeg';rate=44100;n=rate*12
rows=[]
for i in range(n):
 amp=.05 if i<rate*4 else (.15 if i<rate*8 else .03)
 taper=min(1,i/(rate*.05),(n-1-i)/(rate*.05))
 rows.append(amp*taper*(math.sin(2*math.pi*997*i/rate)+.2*math.sin(2*math.pi*233*i/rate)))
source=root/'input.f32';source.write_bytes(struct.pack('<'+'f'*n,*rows))
def run(name,filt,output=False):
 args=[ff,'-hide_banner','-nostdin','-y','-f','f32le','-ar',str(rate),'-ac','1','-i',str(source),'-af',filt]
 args+=['-ar',str(rate),'-c:a','pcm_f32le','-f','f32le',str(root/(name+'.f32'))] if output else ['-f','null','-']
 p=subprocess.run(args,capture_output=True,text=True,check=True);(root/(name+'.log')).write_text(p.stderr)
 start=p.stderr.rfind('{');return json.JSONDecoder().raw_decode(p.stderr[start:])[0]
log=(root/'measure.log').read_text();first=json.JSONDecoder().raw_decode(log[log.rfind('{'):])[0]
recipe='loudnorm=I=-18:TP=-1:LRA=7:linear=false:measured_I='+first['input_i']+':measured_TP='+first['input_tp']+':measured_LRA='+first['input_lra']+':measured_thresh='+first['input_thresh']+':offset='+first['target_offset']+':print_format=json'
second=run('dynamic',recipe,True)
b=(root/'dynamic.f32').read_bytes();out=struct.unpack('<'+'f'*(len(b)//4),b)
report={'source':{'rate':rate,'channels':1,'frames':n,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},'targets':{'integratedLufs':-18,'truePeakDbtp':-1,'loudnessRangeLu':7},'first':first,'second':second,'recipe':recipe,'output':{'frames':len(out),'sha256':hashlib.sha256(b).hexdigest(),'samplePeak':max(map(abs,out))}}
(root/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
