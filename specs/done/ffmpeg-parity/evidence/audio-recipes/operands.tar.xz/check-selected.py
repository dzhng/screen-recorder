from pathlib import Path
import sys
source=Path('/tmp/screenrec-parity-audio-processing/packages/test-harness/editing/audio-recipes/dynamics.py').read_text();out=Path('/tmp/screenrec-audio-recipes/selected-confirmation')
start=source.index('def diff(')
wrapper='''originalRun=run
def run(name,program,filt,detector=None):
 roots=[Path('/tmp/screenrec-audio-recipes/linked-detector')] if name.startswith('l') else [Path('/tmp/screenrec-audio-recipes/confirmation')]
 for frozen in roots:
  p=frozen/(name+'.f32')
  if p.exists():return read(p)
 return originalRun(name,program,filt,detector)
'''
source=source[:start]+wrapper+source[start:];sys.argv=['dynamics.py','/tmp/screenrec zimg final/distribution/bin/ffmpeg',str(out)];exec(compile(source,'selected-dynamics.py','exec'))
