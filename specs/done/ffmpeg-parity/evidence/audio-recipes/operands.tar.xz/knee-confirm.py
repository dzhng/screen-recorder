exec(open('/tmp/screenrec-audio-recipes/confirm.py').read().split("report={'protocol'")[0].replace("confirmation'","knee-confirmation'"))
n=2001;threshold=.1875;ratio=3;knee=6;program=save('program',[(.125,.0625)]*n);detector=save('detector',[(threshold,threshold/2)]*n)
filter=f'[0:a]asetnsamples=n=128:p=1[p];[1:a]asetnsamples=n=128:p=1[d];[p][d]sidechaincompress=threshold={threshold}:ratio={ratio}:attack=.01:release=.01:knee={10**(knee/20)}:detection=peak:link=maximum:level_in=1:level_sc=1:makeup=1:mix=1:mode=downward,atrim=end_sample={n}'
a=run('knee',program,filter,detector);expected=10**(((1/ratio-1)*(knee/2)**2/(2*knee))/20);error=max(abs(row[0]/.125-expected) for row in a)
report={'recipe':filter,'frames':len(a),'expectedFrames':n,'expectedGain':expected,'actualGain':a[0][0]/.125,'maxGainError':error,'passed':len(a)==n and error<=1e-6};(root/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
