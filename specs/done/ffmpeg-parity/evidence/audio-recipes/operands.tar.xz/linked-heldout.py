from pathlib import Path
import subprocess,struct,json,math,hashlib
code=Path('/tmp/screenrec-audio-recipes/linked-detector.py').read_text();start=code.index('def read(');end=code.index('records=[]',start);ns={'math':math,'struct':struct};exec(code[start:end],ns);graph=ns['graph'];read=ns['read']
root=Path('/tmp/screenrec-audio-recipes/linked-heldout');root.mkdir(exist_ok=True);ff='/tmp/screenrec zimg final/distribution/bin/ffmpeg';rate=48000
protocol={'acceptedBy':'parent before untouched confirmation','recipe':'linked-mono-max-limiter-v1','frames':'exact','ceilingLinearExcess':1e-6,'linkedRatioAbsolute':1e-6,'packetCropAbsolute':1e-6,'signedResponse':'preserved','zeroDetector':'exact zeros','gainBound':'one release step, not automatic level compensation','releaseMs':37}
(root/'frozen-protocol.json').write_text(json.dumps(protocol,indent=2))
records=[]
for name,n,lookahead in [('near-heldout',19007,7.25),('short-zero-heldout',101,80)]:
 ceiling=.2;rows=[]
 for i in range(n):
  x=.199999 if name=='near-heldout' else 0
  if 3000<=i<3300:x=0
  if i in [0,n//2,n-1]:x=(-1 if i==n//2 else 1)*.95
  rows.append((x,-x/5))
 source=root/(name+'-input.f32');source.write_bytes(b''.join(struct.pack('<ff',*row) for row in rows));arrays=[]
 for variant,fragment,crop in [('full',False,''),('fragment',True,''),('crop',False,f',atrim=start_sample={n//4}:end_sample={n*3//4}')]:
  recipe=graph(n,ceiling,lookahead,37,fragment,crop);path=root/(name+'-'+variant+'.f32');args=[ff,'-hide_banner','-nostdin','-y','-f','f32le','-ar',str(rate),'-ac','2','-i',str(source),'-filter_complex',recipe,'-c:a','pcm_f32le','-f','f32le',str(path)]
  p=subprocess.run(args,capture_output=True,text=True);(root/(name+'-'+variant+'.log')).write_text(p.stderr)
  if p.returncode:raise RuntimeError(p.stderr)
  arrays.append(read(path))
 a,b,c=arrays;clip=a[n//4:n*3//4]
 record={'name':name,'frames':len(a),'expectedFrames':n,'fragmentFrames':len(b),'cropFrames':len(c),'expectedCropFrames':len(clip),'peak':max(abs(x) for row in a for x in row),'ceiling':ceiling,'linkedError':max(abs(row[0]+5*row[1]) for row in a),'packetDifference':max(abs(x-y) for ar,br in zip(a,b) for x,y in zip(ar,br)),'cropDifference':max(abs(x-y) for ar,br in zip(clip,c) for x,y in zip(ar,br)),'signed':all(x*y>=0 for ar,br in zip(a,rows) for x,y in zip(ar,br)),'zerosExact':all(x==0 for ar,br in zip(a,rows) for x,y in zip(ar,br) if y==0),'gainExcess':max(abs(x/y)-1 for ar,br in zip(a,rows) for x,y in zip(ar,br) if y),'releaseStepBound':1/(rate*.037),'landmarks':{str(i):a[i] for i in [0,n//2,n-1]}}
 records.append(record);(root/'report.json').write_text(json.dumps({'protocol':protocol,'records':records},indent=2))
 checks=[record['frames']==n,record['fragmentFrames']==n,record['cropFrames']==len(clip),record['peak']<=ceiling+1e-6,record['linkedError']<=1e-6,record['packetDifference']<=1e-6,record['cropDifference']<=1e-6,record['signed'],record['zerosExact'],record['gainExcess']<=record['releaseStepBound']+1e-6]
 checks += [abs(v[0]-math.copysign(ceiling,rows[int(i)][0]))<=1e-6 for i,v in record['landmarks'].items()]
 record['passed']=all(checks)
report={'protocol':protocol,'records':records,'passed':all(r['passed'] for r in records),'ffmpegSha256':hashlib.sha256(Path(ff).read_bytes()).hexdigest()};(root/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if not report['passed']:raise SystemExit('Candidate failed frozen acceptance')
