from pathlib import Path
import sys
script=Path('/tmp/screenrec-parity-audio-processing/packages/test-harness/editing/audio-recipes/dynamics.py').read_text()
base=Path('/tmp/screenrec-audio-recipes/confirmation');dest=Path('/tmp/screenrec-audio-recipes/review-confirmation');dest.mkdir(exist_ok=True)
script=script.replace('root.mkdir()','root.mkdir(exist_ok=True)')
start=script.index('def run(');end=script.index('def diff(',start)
replacement='''def run(name,program,filt,detector=None):
 values=read(frozenRoot/(name+'.f32'))
 if fault=='polarity' and name.startswith('l'):
  values=[tuple(-x for x in row) for row in values]
 if fault=='instant' and name.startswith('compress'):
  programRows=read(program);detectorRows=read(detector)
  values=[tuple(x*(1 if max(map(abs,d))<=.1875 else (.1875/max(map(abs,d)))**(1-1/3)) for x in p) for p,d in zip(programRows,detectorRows)]
  if name.endswith('crop'):values=values[3107:15301]
 if fault=='nan' and name.startswith('l'):
  values[4]=(float('nan'),float('nan'))
 return values
'''
script=script[:start]+replacement+script[end:]
for fault in ['none','polarity','instant','nan']:
 runDest=dest/fault
 sys.argv=['dynamics.py','retained-ffmpeg',str(runDest)]
 runDest.mkdir(exist_ok=True)
 # Hash remains the immutable actual candidate, never the observer stub.
 source=script.replace("hashlib.sha256(Path(ff).read_bytes()).hexdigest()", "'8410694433e927bdf2cc751b8c81cb4545b2302828fdffed6044018b10f39f31'")
 try:exec(compile(source,'retained-dynamics.py','exec'),{'frozenRoot':base,'fault':fault})
 except SystemExit:print('fault rejected:',fault)
 except Exception as e:print('fault error:',fault,type(e).__name__,str(e))
