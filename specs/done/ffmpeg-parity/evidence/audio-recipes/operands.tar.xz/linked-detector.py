from pathlib import Path
import subprocess,struct,json,math,hashlib
root=Path('/tmp/screenrec-audio-recipes/linked-detector');root.mkdir(exist_ok=True);ff='/tmp/screenrec zimg final/distribution/bin/ffmpeg';rate=48000
protocol={'recipe':'linked-mono-max-limiter-v1','frozenBeforeCandidateExecution':True,'frames':'exact','clock':'exact authored landmarks','ceilingLinearExcess':1e-6,'linkedRatioAbsolute':1e-6,'packetCropAbsolute':1e-6,'lowLevelPriorWinnerAbsolute':1e-6,'intentionalDifference':'one linked scalar clamp avoids per-channel safetyclip divergence','implementation':'FFmpeg9.0.2 finalzimg'}
(root/'frozen-protocol.json').write_text(json.dumps(protocol,indent=2))
def read(p):
 b=p.read_bytes()
 if len(b)%8:raise ValueError('Incomplete stereo frame')
 v=struct.unpack('<'+'f'*(len(b)//4),b)
 if not all(math.isfinite(x) for x in v):raise ValueError('Nonfinite PCM')
 return [v[i:i+2] for i in range(0,len(v),2)]
def graph(n,ceiling,lookahead,release=71,fragment=False,crop=''):
 prefix='asetnsamples=n=17:p=0,' if fragment else ''
 return f'[0:a]{prefix}asetnsamples=n=128:p=1,asplit=2[p][d];[d]aeval=exprs=max(abs(val(0))\\,abs(val(1))):c=mono,asplit=2[m][md];[m]alimiter=limit={ceiling}:attack={lookahead}:release={release}:level_in=1:level_out=1:level=false:asc=false:latency=true,asetnsamples=n=128:p=1[ml];[p][md][ml]amerge=inputs=3,aeval=exprs=if(eq(val(2)\\,0)\\,val(0)\\,val(0)*val(3)/val(2))|if(eq(val(2)\\,0)\\,val(1)\\,val(1)*val(3)/val(2)):c=stereo,atrim=end_sample={n}'+crop
records=[]
for name,n,ms,ceiling in [('l132',11003,2.75,.375),('l4',1031,.1,.8),('l3840-short',31,80,.25),('l132-near',11003,2.75,.375)]:
 base=Path('/tmp/screenrec-audio-recipes/confirmation') if name!='l132-near' else Path('/tmp/screenrec-audio-recipes/reviewed-confirmation/none');source=base/(name+'-input.f32');old=read((base if name!='l132-near' else Path('/tmp/screenrec-audio-recipes/reviewed-confirmation/near-cache'))/(name+'.f32'))
 path=root/(name+'.f32');recipe=graph(n,ceiling,ms);args=[ff,'-hide_banner','-nostdin','-y','-f','f32le','-ar',str(rate),'-ac','2','-i',str(source),'-filter_complex',recipe,'-c:a','pcm_f32le','-f','f32le',str(path)]
 s=subprocess.run(args,capture_output=True,text=True);(root/(name+'.log')).write_text(s.stderr)
 if s.returncode:raise RuntimeError(s.stderr)
 new=read(path);record={'name':name,'frames':len(new),'expectedFrames':n,'recipe':recipe,'peak':max(abs(x) for row in new for x in row),'ceiling':ceiling,'linkedError':max(abs(row[0]-2*row[1]) for row in new),'priorWinnerMaxDifference':max(abs(x-y) for ar,br in zip(new,old) for x,y in zip(ar,br)),'outputSha256':hashlib.sha256(path.read_bytes()).hexdigest()};records.append(record);(root/'report.json').write_text(json.dumps({'protocol':protocol,'records':records},indent=2))
print(json.dumps(records,indent=2))
