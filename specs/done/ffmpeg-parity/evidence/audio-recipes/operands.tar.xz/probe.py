from pathlib import Path
import subprocess,struct,json,math,hashlib
root=Path('/tmp/screenrec-audio-recipes');ff='/tmp/screenrec zimg final/distribution/bin/ffmpeg';rate=48000;n=rate//4

def pcm(path,rows):
 b=b''.join(struct.pack('<f',x) for row in rows for x in row);path.write_bytes(b);return b

def run(name,source,filter,sidechain=None):
 out=root/(name+'.f32');args=[ff,'-hide_banner','-nostdin','-y','-f','f32le','-ar',str(rate),'-ac','2','-i',str(source)]
 if sidechain:args+=['-f','f32le','-ar',str(rate),'-ac','2','-i',str(sidechain),'-filter_complex',filter]
 else:args+=['-af',filter]
 args+=['-f','f32le','-acodec','pcm_f32le',str(out)]
 p=subprocess.run(args,text=True,capture_output=True,check=True);(root/(name+'.log')).write_text(p.stderr)
 b=out.read_bytes();values=struct.unpack('<'+'f'*(len(b)//4),b);return [values[i:i+2] for i in range(0,len(values),2)]
source=root/'limit-input.f32';rows=[(.05,.02) for i in range(n)]
for at in [0,1000,6000,n-1]:rows[at]=(1,.2)
pcm(source,rows)
recipe='alimiter=limit=0.5:attack=5:release=50:level_in=1:level_out=1:level=false:asc=false:latency=true'
full=run('limiter-full',source,recipe);packet=run('limiter-packets',source,'asetnsamples=n=37:p=0,'+recipe)
report={'limiter':{'frames':len(full),'peak':max(abs(x) for row in full for x in row),'landmarks':{str(i):full[i] for i in [0,1000,6000,n-1]},'packetMaxDifference':max(abs(a-b) for ar,br in zip(full,packet) for a,b in zip(ar,br))}}
no=run('limiter-uncompensated',source,recipe.replace('latency=true','latency=false'));report['limiter']['uncompensatedPeakIndices']=[i for i,row in enumerate(no) if abs(row[0])>.4][:10]
program=root/'compress-program.f32';detector=root/'compress-detector.f32';pcm(program,[(.2,.1)]*n);pcm(detector,[(.5,.01) if 2400<=i<7200 else (.01,.01) for i in range(n)])
recipe='[0:a][1:a]sidechaincompress=threshold=0.125:ratio=4:attack=10:release=50:knee=1:detection=peak:link=maximum:level_in=1:level_sc=1:makeup=1:mix=1:mode=downward'
out=run('compress-full',program,recipe,detector)
report['compressorPartial']={'actualFrames':len(out),'expectedFrames':n}
(root/'partial-report.json').write_text(json.dumps(report,indent=2))
recipe=recipe.replace('[0:a][1:a]', '[0:a]asetnsamples=n=128:p=1[p];[1:a]asetnsamples=n=128:p=1[d];[p][d]')
out=run('compress-padded-packets',program,recipe+',atrim=end_sample='+str(n),detector)
report['compressor']={'frames':len(out),'samples':{str(i):out[i] for i in [0,2399,2400,2520,2760,4000,7199,7200,8400,11999]},'steadyExpectedGain':(.125/.5)**.75,'channelRatioMaxError':max(abs(row[0]-2*row[1]) for row in out)}
(root/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
