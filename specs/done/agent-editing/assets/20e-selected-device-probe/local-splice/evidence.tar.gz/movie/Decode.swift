@preconcurrency import AVFoundation
import CryptoKit
import Foundation
@main struct Decode {
 static func stamp(_ t:CMTime)->[String:Any] {["value":t.value,"timescale":t.timescale,"flags":t.flags.rawValue]}
 static func main() async throws {
  var reports:[[String:Any]]=[]
  for path in CommandLine.arguments.dropFirst() {
   let asset=AVURLAsset(url:URL(fileURLWithPath:path),options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
   let track=try await asset.loadTracks(withMediaType:.video).first!
   let segments=SourceSegment.occupied(of:try await track.load(.segments))
   var cursors:[[String:Any]]=[]
   for value:Int64 in [1666700,181244263] {
    if let c=track.makeSampleCursor(presentationTimeStamp:CMTime(value:value,timescale:1000000)) {
     cursors.append(["requested":value,"returned":stamp(c.presentationTimeStamp)])
    }
   }
   for coded in [false,true] {
    let reader=try AVAssetReader(asset:asset)
    reader.timeRange=CMTimeRange(start:CMTime(value:181144273,timescale:1000000),end:CMTime(value:181277593,timescale:1000000))
    let output=AVAssetReaderTrackOutput(track:track,outputSettings:coded ? nil : [kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
    reader.add(output);precondition(reader.startReading());defer{reader.cancelReading()}
    var frames:[[String:Any]]=[]
    while let row=autoreleasepool(invoking:{()->[String:Any]? in
     guard let s=output.copyNextSampleBuffer() else{return nil}
     let pts=s.presentationTimeStamp
     var hash=SHA256();var bytes=0
     if coded,let data=s.dataBuffer {
      bytes=CMBlockBufferGetDataLength(data);var payload=Data(count:bytes)
      _=payload.withUnsafeMutableBytes{CMBlockBufferCopyDataBytes(data,atOffset:0,dataLength:bytes,destination:$0.baseAddress!)}
      hash.update(data:payload)
     } else if let image=s.imageBuffer {
      CVPixelBufferLockBaseAddress(image,.readOnly);defer{CVPixelBufferUnlockBaseAddress(image,.readOnly)}
      let width=CVPixelBufferGetWidth(image);bytes=width*4*CVPixelBufferGetHeight(image)
      for y in 0..<CVPixelBufferGetHeight(image){hash.update(data:Data(bytes:CVPixelBufferGetBaseAddress(image)!.advanced(by:y*CVPixelBufferGetBytesPerRow(image)),count:width*4))}
     }
     return ["pts":stamp(pts),"duration":stamp(s.duration),"bytes":bytes,"sha256":hash.finalize().map{String(format:"%02x",$0)}.joined(),"helperEnd":assetEnd(ofSamplePresentedAt:pts,in:segments,of:track).map(stamp) as Any? ?? NSNull()]
    }) {frames.append(row);precondition(frames.count<100)}
    reports.append(["path":path,"coded":coded,"cursors":cursors,"status":reader.status.rawValue,"error":reader.error?.localizedDescription ?? "","frames":frames])
   }
  }
  FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:reports,options:[.prettyPrinted,.sortedKeys]))
 }
}
