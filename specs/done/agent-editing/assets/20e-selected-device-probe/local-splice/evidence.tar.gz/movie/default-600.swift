@preconcurrency import AVFoundation
import Foundation
@main struct Splice {
 static func main() async throws {
  let source = URL(fileURLWithPath: CommandLine.arguments[1])
  let destination = URL(fileURLWithPath: CommandLine.arguments[2])
  let asset = AVURLAsset(url: source, options: [AVURLAssetPreferPreciseDurationAndTimingKey:true])
  let original = try await asset.loadTracks(withMediaType:.video).first!
  let composition = AVMutableComposition()
  let track = composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid)!
  track.naturalTimeScale = try await original.load(.naturalTimeScale)
  let ranges = [(Int64(181144273),Int64(181210933)),(Int64(181244263),Int64(181277593))].map {
   CMTimeRange(start:CMTime(value:$0.0,timescale:1_000_000),end:CMTime(value:$0.1,timescale:1_000_000))
  }
  var pieces:[AVCompositionTrackSegment]=[];var previous=CMTime.zero
  for range in ranges {
   if range.start > previous {pieces.append(AVCompositionTrackSegment(timeRange:CMTimeRange(start:previous,end:range.start)))}
   pieces.append(AVCompositionTrackSegment(url:source,trackID:original.trackID,sourceTimeRange:range,targetTimeRange:range))
   previous=range.end
  }
  try track.validateSegments(pieces);track.segments=pieces
  let movie = AVMutableMovie()
  movie.defaultMediaDataStorage = AVMediaDataStorage(url: destination, options: nil)
  try movie.insertTimeRange(CMTimeRange(start: .zero, end: ranges.last!.end), of: composition, at: .zero, copySampleData: true)
  try movie.writeHeader(to: destination, fileType: .mov, options: .addMovieHeaderToDestination)
  print("export completed; exact original timescale and occupied ranges preserved; no decoding")
 }
}
