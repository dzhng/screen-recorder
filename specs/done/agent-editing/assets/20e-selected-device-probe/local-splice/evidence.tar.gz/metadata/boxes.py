import struct,json
from pathlib import Path
names={'raw':Path('/tmp/screenrec-20-physical-take-1/camera/camera.raw.mov'),'candidate':Path('/tmp/screenrec-20-physical-take-1/camera/.screenrec-output-12421E0E-F5AB-4CB0-A2DB-31B99043174C/camera.mov')}
def boxes(f,first,end):
 while first+8<=end:
  f.seek(first);n,t=struct.unpack('>I4s',f.read(8));h=8
  if n==1:n=struct.unpack('>Q',f.read(8))[0];h=16
  if n==0:n=end-first
  if n<h or first+n>end:raise ValueError((first,n,end))
  yield t,first+h,first+n
  first+=n
def parse(p):
 result={}
 with p.open('rb') as f:
  def walk(first,end):
   for t,a,b in boxes(f,first,end):
    if t in [b'moov',b'trak',b'mdia',b'edts']:walk(a,b)
    elif t in [b'mvhd',b'mdhd']:
     f.seek(a);data=f.read(min(b-a,40));offset=20 if data[0]==1 else 12
     result[t.decode()+'Timescale']=struct.unpack_from('>I',data,offset)[0]
    elif t==b'elst':
     f.seek(a);data=f.read(b-a);version=data[0];count=struct.unpack_from('>I',data,4)[0];rows=[];offset=8;at=0
     for i in range(count):
      if version==1:duration,media,rate,frac=struct.unpack_from('>Qqhh',data,offset);offset+=20
      else:duration,media,rate,frac=struct.unpack_from('>Iihh',data,offset);offset+=12
      rows.append({'ordinal':i,'targetStart':at,'targetEnd':at+duration,'mediaStart':media,'rateInteger':rate,'rateFraction':frac});at+=duration
     result['edits']=rows
  walk(0,p.stat().st_size)
 return result
for n,p in names.items():
 r=parse(p);Path('/tmp/screenrec-camera-metadata/'+n+'-edits.json').write_text(json.dumps(r,indent=2)+'\n');scale=r['mvhdTimescale']
 print(n,'movie',scale,'media',r['mdhdTimescale'],'edits',len(r.get('edits',[])))
 for x in r.get('edits',[]):
  if x['targetEnd']/scale>=181.10 and x['targetStart']/scale<=181.30:print(x)
