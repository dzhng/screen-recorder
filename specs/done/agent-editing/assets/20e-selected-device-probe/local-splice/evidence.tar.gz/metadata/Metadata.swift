@preconcurrency import AVFoundation
import Foundation

@main struct Metadata {
 static func stamp(_ t: CMTime) -> [String:Any] { ["value":t.value,"timescale":t.timescale,"epoch":t.epoch,"flags":t.flags.rawValue] }
 static func range(_ r:CMTimeRange)->[String:Any] { ["start":stamp(r.start),"duration":stamp(r.duration),"end":stamp(r.end)] }
 static func main() async throws {
  var results:[[String:Any]]=[]
  for path in CommandLine.arguments.dropFirst() {
   let asset=AVURLAsset(url:URL(fileURLWithPath:path),options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
   let track=try await asset.loadTracks(withMediaType:.video).first!
   let all=try await track.load(.segments)
   let occupied=SourceSegment.occupied(of:all)
   var segments:[[String:Any]]=[]
   for (i,s) in all.enumerated() where s.timeMapping.target.end >= time(microseconds:181_100_000) && s.timeMapping.target.start <= time(microseconds:181_350_000) {
    var row:[String:Any]=["index":i,"empty":s.isEmpty,"source":range(s.timeMapping.source),"target":range(s.timeMapping.target)]
    if !s.isEmpty {
     let mapping=SourceSegment(media:s.timeMapping.source,asset:s.timeMapping.target)
     let requested=CMTimeMaximum(s.timeMapping.target.start,time(microseconds:181_100_000))
     if let c=track.makeSampleCursor(presentationTimeStamp:mapping.mediaTime(ofAsset:requested)) {
      _=c.stepInPresentationOrder(byCount:-2)
      var samples:[[String:Any]]=[]
      for _ in 0..<12 {
       let at=mapping.assetTime(ofMedia:c.presentationTimeStamp)
       samples.append(["mediaPTS":stamp(c.presentationTimeStamp),"mediaDTS":stamp(c.decodeTimeStamp),"duration":stamp(c.currentSampleDuration),"assetPTS":stamp(at),"inside":s.timeMapping.target.containsTime(at),"helperEnd":assetEnd(ofSamplePresentedAt:at,in:occupied,of:track).map(stamp) as Any? ?? NSNull()])
       if c.stepInPresentationOrder(byCount:1) != 1 {break}
      }
      row["samples"]=samples
     }
    }
    segments.append(row)
   }
   results.append(["path":path,"timescale":try await track.load(.naturalTimeScale),"range":range(try await track.load(.timeRange)),"segmentsTotal":all.count,"segments":segments])
  }
  FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:results,options:[.prettyPrinted,.sortedKeys]))
 }
}
