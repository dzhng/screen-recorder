from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
root=Path(sys.argv[1]);root.mkdir()
source=Path(sys.argv[2]);binary=Path('/tmp/screenrec-20e-stop-scale-build/arm64-apple-macosx/debug/ScreenRecorderCaptureTests')
def identity(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
before=identity(source);report={'sourceBefore':before,'binary':identity(binary),'deadlineSeconds':420,'rssGuardBytes':4*1024**3}
env=os.environ.copy();env.update(SCREENREC_SELECTED_STOP_SCALE_OUTPUT=str(root/'result'),SCREENREC_SELECTED_STOP_SCALE_SOURCE=str(source),SWIFT_BACKTRACE='enable=no')
started=time.monotonic();peak=0
with (root/'test.log').open('wb') as log:
 p=subprocess.Popen([str(binary)],env=env,stdout=log,stderr=log,start_new_session=True)
 print('pid='+str(p.pid),flush=True)
 (root/'pid').write_text(str(p.pid))
 while p.poll() is None:
  try: peak=max(peak,int(subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip())*1024)
  except (ValueError,subprocess.CalledProcessError): pass
  if time.monotonic()-started>420 or peak>4*1024**3:
   report['stoppedBy']='deadline' if time.monotonic()-started>420 else 'rssGuard'
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.5)
report.update(exitCode=p.wait(),elapsedSeconds=time.monotonic()-started,peakSampledRSSBytes=peak,sourceAfter=identity(source))
report['sourceUnchanged']=report['sourceBefore']==report['sourceAfter']
(root/'execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
sys.exit(0 if report['exitCode']==0 and report['sourceUnchanged'] else 1)
