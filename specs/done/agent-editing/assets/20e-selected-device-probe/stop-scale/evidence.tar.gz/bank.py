from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder')
bank=Path('/tmp/screenrec-20e-stop-scale-bank');bank.mkdir(exist_ok=True)
assets=repo/'specs/agent-editing/assets/20e-selected-device-probe/stop-scale';assets.mkdir(parents=True,exist_ok=True)
def ident(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def copy(p,name):
 dest=bank/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for case in ['small','small-green','long','mutation','restored','verified']:
 root=Path('/tmp/screenrec-20e-stop-scale-'+case)
 if not root.exists():continue
 for p in root.rglob('*'):
  if p.is_file() and (case not in ['long','verified'] or p.suffix != '.mov'): copy(p,case+'/'+str(p.relative_to(root)))
for p in Path('/tmp').glob('screenrec-20e-stop-scale-*.log'):copy(p,'logs/'+p.name)
copy(Path('/tmp/screenrec-20e-stop-scale-run.py'),'reproduce.py')
copy(Path('/tmp/screenrec-20e-stop-scale-review.txt'),'review.txt')
copy(Path('/tmp/screenrec-20e-stop-scale-bank.py'),'bank.py')
copy(Path('/tmp/screenrec-20e2-delivery-recovery/receipt.json'),'independent-source-inventory.json')
for name in ['source-ffprobe.json','fixture-diagnosis.json']:
 copy(Path('/tmp/screenrec-20e-stop-scale-'+name),name)
for name in ['corrected','final']:
 copy(Path('/tmp/screenrec-20e-stop-scale-'+name+'/execution.json'),'early-canceled-'+name+'.json')
paths=list((repo/'helpers/mac/Sources/ScreenRecorderCapture').glob('*.swift'))+[repo/'helpers/mac/Tests/ScreenRecorderCaptureTests'/name for name in ['SelectedCaptureStopScale.swift','PrerecordedCaptureInput.swift','main.swift']]
for p in paths:copy(p,'sources/'+str(p.relative_to(repo)))
long=Path('/tmp/screenrec-20e-stop-scale-verified');report=json.loads((long/'result/measurement.json').read_text());run=json.loads((long/'execution.json').read_text());prior=json.loads((bank/'independent-source-inventory.json').read_text())
assert run['exitCode']==0 and run['sourceUnchanged']
assert report['offeredPictures']==report['representedPictures']==prior['representedFrames']==4428
assert run['sourceBefore']['sha256']==prior['raw']['sha256']
external=[ident(p) for p in (long/'result').rglob('*.mov')]
(bank/'external-media.json').write_text(json.dumps(external,indent=2)+'\n')
(bank/'source-identities.json').write_text(json.dumps([ident(p) for p in paths],indent=2)+'\n')
(bank/'toolchain.txt').write_text(subprocess.check_output(['swift','--version'],text=True))
manifest=[{**ident(p),'path':str(p.relative_to(bank))} for p in sorted(bank.rglob('*')) if p.is_file()]
(assets/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(assets/'evidence.tar.gz','w:gz') as tar:
 for p in sorted(bank.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(bank)))
verification={'status':'verified offline prerecorded accumulated-media closure','base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'measurement':report,'execution':run,'expectedSourcePictures':4428,'independentInventoryHash':ident(bank/'independent-source-inventory.json')['sha256'],'archive':ident(assets/'evidence.tar.gz'),'sourceSnapshots':len(paths),'archiveMembers':len(manifest)}
(assets/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
