@preconcurrency import AVFoundation
import CryptoKit
import Foundation
@main struct Packets {
 static func t(_ x:CMTime)->[String:Any]{["value":x.value,"scale":x.timescale,"flags":x.flags.rawValue]}
 static func main() async throws {
  let first=Int64(CommandLine.arguments[1])!,last=Int64(CommandLine.arguments[2])!
  let points=CommandLine.arguments[3].split(separator:",").map{Int64($0)!}
  var results:[[String:Any]]=[]
  for path in CommandLine.arguments.dropFirst(4) {
   let asset=AVURLAsset(url:URL(fileURLWithPath:path),options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
   let track=try await asset.loadTracks(withMediaType:.video).first!
   let segs=SourceSegment.occupied(of:try await track.load(.segments))
   var cursors:[[String:Any]]=[]
   for point in points {
    let at=CMTime(value:point,timescale:1000000)
    guard let seg=segs.first(where:{$0.asset.containsTime(at)}),let c=track.makeSampleCursor(presentationTimeStamp:seg.mediaTime(ofAsset:at)) else {continue}
    let sync=c.currentSampleSyncInfo,dep=c.currentSampleDependencyInfo
    cursors.append(["requestedAssetPTS":point,"mediaPTS":t(c.presentationTimeStamp),"assetPTS":t(seg.assetTime(ofMedia:c.presentationTimeStamp)),"DTS":t(c.decodeTimeStamp),"duration":t(c.currentSampleDuration),"sync":String(describing:sync),"dependency":String(describing:dep),"refreshSamples":c.samplesRequiredForDecoderRefresh,"attachments":String(describing:c.currentSampleDependencyAttachments)])
   }
   let reader=try AVAssetReader(asset:asset)
   reader.timeRange=CMTimeRange(start:CMTime(value:first,timescale:1000000),end:CMTime(value:last,timescale:1000000))
   let output=AVAssetReaderTrackOutput(track:track,outputSettings:nil)
   reader.add(output);precondition(reader.startReading());defer{reader.cancelReading()}
   var packets:[[String:Any]]=[]
   while let sample=output.copyNextSampleBuffer() {
    var bytes=0;var hash=""
    if let b=sample.dataBuffer {
     bytes=CMBlockBufferGetDataLength(b);var data=Data(count:bytes)
     _=data.withUnsafeMutableBytes{CMBlockBufferCopyDataBytes(b,atOffset:0,dataLength:bytes,destination:$0.baseAddress!)}
     hash=SHA256.hash(data:data).map{String(format:"%02x",$0)}.joined()
    }
    packets.append(["PTS":t(sample.presentationTimeStamp),"DTS":t(sample.decodeTimeStamp),"duration":t(sample.duration),"samples":sample.numSamples,"bytes":bytes,"sha256":hash,"attachments":String(describing:CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false))])
    precondition(packets.count<200)
   }
   results.append(["path":path,"cursors":cursors,"packets":packets,"status":reader.status.rawValue,"error":reader.error?.localizedDescription ?? ""])
  }
  FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:results,options:[.prettyPrinted,.sortedKeys]))
 }
}
