@preconcurrency import AVFoundation
import Foundation

@main struct Diagnostic {
    static func emit(_ value: [String: Any]) {
        let bytes = try! JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        FileHandle.standardOutput.write(bytes + Data([10]))
    }
    static func stamp(_ t: CMTime) -> [String: Any] {
        ["value": t.value, "timescale": t.timescale, "flags": t.flags.rawValue, "epoch": t.epoch]
    }
    static func main() async throws {
        let asset = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]),
            options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        let track = try await asset.loadTracks(withMediaType: .video).first!
        let segments = SourceSegment.occupied(of: try await track.load(.segments))
        let reader = try AVAssetReader(asset: asset)
        let output = AVAssetReaderTrackOutput(track: track,
            outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
        reader.add(output)
        emit(["phase":"metadata", "occupied":segments.count,
            "first":stamp(segments.first!.asset.start), "end":stamp(segments.last!.asset.end),
            "readerRangeStart":stamp(reader.timeRange.start), "readerRangeDuration":stamp(reader.timeRange.duration)])
        precondition(reader.startReading())
        defer { reader.cancelReading() }
        var represented = 0
        for ordinal in 0..<30000 {
            emit(["phase":"before", "ordinal":ordinal, "represented":represented, "status":reader.status.rawValue])
            guard let sample = output.copyNextSampleBuffer() else {
                emit(["phase":"terminal", "ordinal":ordinal, "represented":represented,
                    "status":reader.status.rawValue, "error":reader.error?.localizedDescription ?? ""])
                return
            }
            let occupied = assetEnd(ofSamplePresentedAt: sample.presentationTimeStamp, in: segments, of: track) != nil
            if occupied { represented += 1 }
            emit(["phase":"after", "ordinal":ordinal, "represented":represented,
                "pts":stamp(sample.presentationTimeStamp), "occupied":occupied, "status":reader.status.rawValue])
        }
        emit(["phase":"diagnostic-row-guard", "represented":represented])
    }
}
