from pathlib import Path
import hashlib,json,subprocess,time,os,signal
root=Path('/tmp/screenrec-camera-reader-diagnostic')
source=Path('/tmp/screenrec-20-physical-take-1/camera/.screenrec-output-12421E0E-F5AB-4CB0-A2DB-31B99043174C/camera.mov')
def identity():
 h=hashlib.sha256()
 with source.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return {'path':str(source),'bytes':source.stat().st_size,'sha256':h.hexdigest()}
r={'input':identity(),'deadlineSeconds':60,'operationalRssGuardBytes':4*1024**3,'note':'Unchanged unbounded reader and existing assetEnd helper, no autoreleasepool added. No pixel digest/export/publication; diagnostic only.'}
with (root/'trace.jsonl').open('wb') as log,(root/'stderr.log').open('wb') as err:
 p=subprocess.Popen([str(root/'reader'),str(source)],stdout=log,stderr=err,start_new_session=True);r['pid']=p.pid;start=time.monotonic();peak=0
 while p.poll() is None:
  try:
   rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip())*1024;peak=max(peak,rss)
  except (ValueError,subprocess.CalledProcessError):pass
  if time.monotonic()-start>=60 or peak>r['operationalRssGuardBytes']:
   r['stoppedBy']='deadline' if time.monotonic()-start>=60 else 'rssGuard'
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.2)
 r.update(exitCode=p.wait(),elapsedSeconds=time.monotonic()-start,peakSampledRssBytes=peak)
r['after']=identity();r['unchanged']=r['input']==r['after']
(root/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
