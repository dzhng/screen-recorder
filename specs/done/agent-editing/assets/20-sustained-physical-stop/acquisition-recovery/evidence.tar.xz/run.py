import pathlib,json,os,subprocess,time,signal,hashlib
out=pathlib.Path(__file__).parent;base=out.parent;prior=base/'sustained-physical-stop-verification';old=json.loads((prior/'report.json').read_text());home=pathlib.Path(old['home']);app=base/'ScreenRecorder.app';sock=home/'run/service.sock';node='/Users/david/.nvm/versions/node/v24.14.0/bin/node';rid=old['terminalRecording']['recordingId'];camera='1b13ff16-5530-451d-a53a-ab58bfcaef0b';primary='7c3315c3-a072-41ca-9f93-3fddad5b95fb';env={**os.environ,'SCREENREC_HOME':str(home),'SCREENREC_DEFAULTS':str(home/'preferences'),'SCREENREC_SERVICE_LAUNCH':'1','PATH':'/usr/bin:/bin:/usr/sbin:/sbin'}
report={'scope':'One saved sustained capture source-admission recovery; no capture or publication replay. No sync/installed/general performance verdict.','passed':False,'calls':[],'home':str(home),'recordingId':rid};began=time.monotonic();deadline=began+90;p=None;logs=[]
def pin(path):
 q=pathlib.Path(path);return {'path':str(q),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
def verify():
 assert [pin(x['path']) for x in old['candidatePins']]==old['candidatePins'],'Candidate bytes changed'
 for x in old['recordingFiles']:assert pathlib.Path(x['path']).stat().st_size==x['bytes'],x['path']
def call(op,params={}):
 left=deadline-time.monotonic();assert left>12,'90s deadline with12s cleanup reserve';argv=[node,str(app/'Contents/Resources/cli/main.mjs'),op,'--socket',str(sock),'--params',json.dumps(params)];at=time.monotonic();q=subprocess.Popen(argv,cwd='/',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:stdout,stderr=q.communicate(timeout=min(10,left-12))
 except BaseException:q.kill();stdout,stderr=q.communicate();report['calls'].append({'argv':argv,'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'timedOut':True});raise
 report['calls'].append({'operation':op,'params':params,'argv':argv,'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'elapsedSeconds':time.monotonic()-at});assert q.returncode==0,report['calls'][-1];v=json.loads(stdout);assert v['ok'],v;return v['data']
try:
 verify();assert not sock.exists(),'Existing listener: no process ownership'
 report['beforeCandidatePins']=old['candidatePins'];report['priorReportPin']=pin(prior/'report.json');report['priorJobsPin']=pin(prior/'post-cleanup-jobs.json');report['sourceFactsPolicy']='Original media byte sizes checked; existing captured hashes and publication receipts reused, not independently rehashed.'
 plan={'scope':report['scope'],'candidate':str(app),'home':str(home),'socket':str(sock),'candidatePins':old['candidatePins'],'retryJobId':camera,'preservePrimaryJobId':primary,'wholeSeconds':90,'cleanupReserveSeconds':12,'maxRetries':1,'noCapture':True,'beforeSocketAbsent':True,'priorReportPin':report['priorReportPin']};(out/'plan.json').write_text(json.dumps(plan,indent=2))
 logs=[(out/'app.stdout').open('w'),(out/'app.stderr').open('w')];p=subprocess.Popen([str(app/'Contents/MacOS/ScreenRecorder')],cwd='/',env=env,stdout=logs[0],stderr=logs[1],start_new_session=True);report['appPid']=p.pid;(out/'active.json').write_text(json.dumps({'appPid':p.pid,'home':str(home),'deadlineSeconds':90}))
 end=time.monotonic()+12
 while not sock.exists() and p.poll() is None and time.monotonic()<end:time.sleep(.05)
 assert sock.is_socket(),'Listener not ready';health=call('service.health');report['servicePid']=health['pid'];assert health['home']==str(home)
 recording=call('recording.get',{'recordingId':rid});assert recording['publication']==old['terminalRecording']['publication'] and recording['state']=='complete'
 before={j:call('job.get',{'jobId':j}) for j in [primary,camera]};report['initialJobs']=before;assert before[primary]['state']=='ready'
 if before[camera]['state']=='failed':
  assert before[camera]['errorCode']=='JOB_INTERRUPTED';report['retry']=call('job.retry',{'jobId':camera});assert report['retry']['attemptId']!=before[camera]['attemptId'];assert report['retry']['generation']==before[camera]['generation']+1
 else:assert before[camera]['state']=='ready','Unexpected camera state; no retry'
 while True:
  job=call('job.get',{'jobId':camera});report['cameraLatest']=job
  assert job['state'] not in ['failed','unavailable','canceled'],job
  if job['state']=='ready':break
  time.sleep(.25)
 after=call('job.get',{'jobId':primary});assert after==before[primary];report['primaryUnchanged']=True
 acquisitions={}
 for admission in recording['sourceAdmissions']:
  a=call('acquisition.get',{'acquisitionId':admission['acquisitionId']});assert a['sourceId']==admission['sourceId'];assert a['bindings'];pins=admission['publication']['source']['members'];hashes={x['sha256'] for name,x in pins.items() if name.endswith('.mov')}
  for binding in a['bindings']:
   assert binding['assetId'] in hashes;asset=call('asset.get',{'assetId':binding['assetId']});assert asset['bytes']==int(next(x['bytes'] for x in pins.values() if x['sha256']==asset['id']));assert binding['sourceToAssetOffsetUs']==-asset['originUs'];assert all(x['startUs']<x['endUs'] for x in binding['available'])
  acquisitions[admission['kind']]=a
 report['acquisitions']=acquisitions
 report['projects']=call('project.list');assert not report['projects']['projects']
 final=call('recording.get',{'recordingId':rid});assert final['currentRevisionId'] is None and final['publication']==recording['publication'];assert all(a['job']['state']=='ready' for a in final['sourceAdmissions']);report['finalRecording']=final;report['noAutomaticProjectOrRevision']=True
 verify();report['afterCandidatePins']=old['candidatePins'];report['originalMediaSizesUnchanged']=True;report['passed']=True
except BaseException as e:report['error']=repr(e)
finally:
 if p:
  if p.poll() is None:
   p.send_signal(signal.SIGTERM)
   try:p.wait(timeout=max(.1,min(12,deadline-time.monotonic())))
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();report['forcedKill']=True;report['passed']=False
  report.update(appExitCode=p.returncode,appReaped=True)
  if p.returncode!=0:report['passed']=False
 for f in logs:f.close()
 if 'servicePid' in report:
  q=subprocess.run(['ps','-p',str(report['servicePid']),'-o','pid=,command='],capture_output=True,text=True,timeout=2);report['serviceAfterQuit']={'exitCode':q.returncode,'stdout':q.stdout,'stderr':q.stderr};report['servicePidAbsent']=not q.stdout.strip()
  if q.stdout.strip():report['passed']=False
 report.update(socketAbsent=not sock.exists(),elapsedSeconds=time.monotonic()-began)
 if sock.exists():report['passed']=False
 (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k in ['passed','error','appPid','servicePid','appExitCode','servicePidAbsent','elapsedSeconds']}))
raise SystemExit(0 if report['passed'] else 1)
