# Choices

Keep byte pinning inside physical closure, move only verification joining into
camera source publication, and join before cancellation checking. High confidence:
this separates source verification from SDK/encoder closure without relaxing the
closed-source authority or permitting background readers to escape canceled Stop.

Retain the existing close in Verification.finish for direct publishers. High
confidence: the public closed-source publisher and direct lease publisher have
different cancellation entry points but share one idempotent verification owner.

Use a seven-second, 210-picture synthetic fixture solely to open an actual
acquisition checkpoint. No new user task or editorial choice. Medium confidence
on smallest fixture size: a three-second fixture was explicitly unexercised; no
further size minimization was needed to answer the contract.

Do not claim the ten-second sustained Stop deadline or any camera-path speedup.
Only primary/camera overlap is proved. No physical capture, app candidate build,
large replay, inference or full-suite run was performed in this pass.
