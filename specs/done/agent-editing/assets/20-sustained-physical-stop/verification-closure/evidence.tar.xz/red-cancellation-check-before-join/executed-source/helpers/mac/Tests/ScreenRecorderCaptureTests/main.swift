import Foundation

if let output = ProcessInfo.processInfo.environment["SCREENREC_CANCELED_CAMERA_CONTINUATION_OUTPUT"] {
    try await runCanceledCameraContinuationTest(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_CONTINUATION_CLOSURE_OUTPUT"] {
    try await runCameraContinuationClosureTest(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SOURCE_PUBLICATION_OVERLAP_OUTPUT"] {
    try await runSourcePublicationOverlapTest(output: output)
} else if ProcessInfo.processInfo.environment["SCREENREC_CAMERA_PUBLICATION_OVERLAP"] != nil {
    try await runProbeCameraPixelPublicationTests(widths: [32])
    try await runCameraPublicationClippedSupportTest()
    try await runCameraPublicationPrefixTests()
    try await runCameraPublicationErrorOrderTest()
    try runCameraPublicationDecisionTests()
    try await runCameraPublicationReplayTests()
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_EMPTY_CAPTURE_RECOVERY_OUTPUT"] {
    try await runEmptyCaptureRecoveryTests(output: output)
} else if ProcessInfo.processInfo.environment["SCREENREC_SOURCE_RECOVERY_CHILD"] != nil {
    try await runSourcePublicationCrashChild()
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SOURCE_RECOVERY_OUTPUT"] {
    try await runSourcePublicationRecoveryTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SHARED_INTERRUPTION_OUTPUT"] {
    try await runSharedInterruptionDuringFinishTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_CLOCK_OUTPUT"] {
    try await runIndependentCameraClockTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_WITHOUT_PRIMARY_OUTPUT"] {
    try await runCameraWithoutPrimaryTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_INDEPENDENT_PUBLICATION_OUTPUT"] {
    try await runIndependentPublicationTests(output: output)
    try await runNativeCaptureInputTests()
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_PROJECT_OUTPUT"] {
    try await runCameraProjectFixture(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_SOURCE_ADMISSION_OUTPUT"] {
  try await runCameraSourceAdmissionTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SELECTED_CAMERA_INPUT_OUTPUT"] {
  try await runSelectedCameraInputTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_LIVE_PUBLICATION_OUTPUT"] {
  try await runCameraLivePublicationTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAMERA_SOURCE_PUBLICATION_OUTPUT"] {
  try await runCameraSourcePublicationTests(output: output)
} else if ProcessInfo.processInfo.environment["SCREENREC_CAMERA_PIXELS"] != nil {
  try await runProbeCameraPixelPublicationTests()
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SELECTED_STOP_SCALE_OUTPUT"] {
  try await runSelectedCaptureStopScale(output: output, sourcePath: ProcessInfo.processInfo.environment["SCREENREC_SELECTED_STOP_SCALE_SOURCE"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SELECTED_STOP_OUTPUT"] {
  try await runSelectedCaptureStopTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_PROBE_REPLAY_OUTPUT"] {
  try await runProbeCameraReplayTests(source: ProcessInfo.processInfo.environment["SCREENREC_PROBE_REPLAY_INPUT"] ?? "", output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SELECTED_FRAME_OUTPUT"] {
  try await runProbeFrameBoundary(output: output, sourcePath: ProcessInfo.processInfo.environment["SCREENREC_SELECTED_ADMITTED_SOURCE"])
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_SELECTED_PROBE_OUTPUT"] {
  try runSelectedCaptureRequestTests()
  try await runSelectedCaptureMediaTests(output: output,
    corpus: ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_CORPUS"] ?? "")
} else if ProcessInfo.processInfo.environment["SCREENREC_JOURNAL_LEASE_CHILD"] != nil {
  runCaptureJournalLeaseChild(directory: CommandLine.arguments[1])
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_NATIVE_PUBLICATION_OUTPUT"] {
  try await runNativeCapturePublicationProbe(output: output,
    corpus: ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_CORPUS"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_MATERIALIZER_DESCRIPTOR_OUTPUT"] {
  try await runCaptureAudioMaterializerDescriptorProbe(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_MATERIALIZER_OUTPUT"] {
  try await runCaptureAudioMaterializerScaleProbe(output: output, runs: Int(ProcessInfo.processInfo.environment["SCREENREC_MATERIALIZER_RUNS"] ?? "128")!)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_PUBLICATION_OUTPUT"] {
  try await runCaptureAudioPublicationTests(output: output)
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_AUDIO_FORMAT_OUTPUT"] {
  try await runCaptureAudioFormatProbe(
    output: output,
    corpus: ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_CORPUS"] ?? "",
    stereoFixture: ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_FORMAT_STEREO"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_JOURNAL_FAILURE_OUTPUT"] {
  try await runCaptureJournalFailureProbe(
    output: output,
    corpus: ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_CORPUS"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_PCM_WINDOWS_OUTPUT"] {
  try await runPCMAdmissionWindows(
    output: output,
    canonical: ProcessInfo.processInfo.environment["SCREENREC_PCM_WINDOWS_CANONICAL"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_PCM_ADMISSION_OUTPUT"] {
  try await runPCMAdmissionProbe(
    output: output,
    canonical: ProcessInfo.processInfo.environment["SCREENREC_PCM_ADMISSION_CANONICAL"] ?? "")
} else if let output = ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_OUTPUT"],
  let corpus = ProcessInfo.processInfo.environment["SCREENREC_CAPTURE_GAP_CORPUS"]
{
  try await runCaptureAudioGapProbe(output: output, corpus: corpus)
} else {
  try await runCameraSourceAdmissionTests()
  try await runProbeCameraPixelPublicationTests()
  try runSelectedCaptureRequestTests()
  try await runFractionalRecoveryDurationTest()
  try await runCaptureDurationTests()
  try await runNativeCaptureInputTests()
  try await runSelectedCameraInputTests()
  try await runCameraLivePublicationTests()
  try await runCameraSourcePublicationTests()
  try await runSourcePublicationOverlapTest()
  try await runIndependentPublicationTests()
  try await runSharedInterruptionDuringFinishTests()
  try await runSourcePublicationRecoveryTests()
  try await runEmptyCaptureRecoveryTests()
  try await runCanonicalRecoveryTests()
  try await runCaptureTerminationTests()
  try await runCaptureWriterTests()
  runCaptureClockTests()
  try await runIndependentCameraClockTests()
  try await runCameraWithoutPrimaryTests()
  await runHeldTailFrameTests()
  try await runCaptureJournalTests()
  try runCaptureJournalLeaseTests()
  try runPCMJournalTests()
  try await runCaptureAudioMaterializerTests()
  try await runCaptureAudioPublicationTests()
  try await runDeferredPauseTests()
  try runCursorGeometryTests()
  try await runMediaRecoveryTests()
  runCaptureExclusionTests()
}
