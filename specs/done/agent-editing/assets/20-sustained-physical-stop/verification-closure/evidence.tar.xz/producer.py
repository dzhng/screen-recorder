import subprocess,os,time,json,pathlib,hashlib,sys
root=pathlib.Path('/Users/david/.cache/screen-recorder/verification/camera-verification-close-boundary')
name=sys.argv[1]; flag=sys.argv[2] if len(sys.argv)>2 else 'SCREENREC_CAMERA_CONTINUATION_CLOSURE_OUTPUT'
base=root/name;base.mkdir();binary=pathlib.Path('/Users/david/.codex/worktrees/sustained-stop/screen-recorder/helpers/mac/.build/debug/ScreenRecorderCaptureTests')
import shutil
wt=pathlib.Path('/Users/david/.codex/worktrees/sustained-stop/screen-recorder')
for relative in ['helpers/mac/Sources/ScreenRecorderCapture/CameraWriter.swift','helpers/mac/Sources/ScreenRecorderCapture/CameraMedia.swift','helpers/mac/Sources/ScreenRecorderCapture/ClosedCameraSource.swift','helpers/mac/Tests/ScreenRecorderCaptureTests/IndependentPublicationTests.swift','helpers/mac/Tests/ScreenRecorderCaptureTests/CameraReaderStarts.swift','helpers/mac/Tests/ScreenRecorderCaptureTests/main.swift']:
 destination=base/'executed-source'/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(wt/relative,destination)
env=dict(os.environ);env[flag]=str(base/'output');started=time.monotonic()
with (base/'stdout.log').open('wb') as out,(base/'stderr.log').open('wb') as err:
 p=subprocess.Popen([str(binary)],env=env,stdout=out,stderr=err);pid=p.pid;code=p.wait(timeout=90)
report={'pid':pid,'exitCode':code,'elapsedSeconds':time.monotonic()-started,'binary':str(binary),'binarySHA256':hashlib.sha256(binary.read_bytes()).hexdigest(),'flag':flag,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/Users/david/.codex/worktrees/sustained-stop/screen-recorder',text=True).strip()}
(base/'process.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));print((base/'stdout.log').read_text());print((base/'stderr.log').read_text()[-1800:])
