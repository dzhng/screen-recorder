import pathlib,hashlib,json,subprocess,time,os
root=pathlib.Path('/Users/david/.cache/screen-recorder/verification/camera-verification-close-boundary/merged-e9f0597e');root.mkdir()
binary=pathlib.Path('/Users/david/dev/screen-recorder/helpers/mac/.build/debug/ScreenRecorderCaptureTests')
report={'rootHead':'e9f0597e','binary':{'path':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},'cases':[]}
for case,flag in [('continuation','SCREENREC_CAMERA_CONTINUATION_CLOSURE_OUTPUT'),('cancellation','SCREENREC_CANCELED_CAMERA_CONTINUATION_OUTPUT')]:
 env=os.environ.copy();env[flag]=str(root/case);start=time.monotonic()
 with (root/(case+'.stdout')).open('w') as out,(root/(case+'.stderr')).open('w') as err:
  p=subprocess.Popen([str(binary)],cwd='/Users/david/dev/screen-recorder',env=env,stdout=out,stderr=err)
  try: code=p.wait(timeout=45)
  except subprocess.TimeoutExpired:p.kill();code=p.wait()
 report['cases'].append({'case':case,'argv':[str(binary)],'environmentOverride':{flag:str(root/case)},'pid':p.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'reaped':True})
 (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report['cases'][-1]),flush=True)
 if code:raise SystemExit(code)
