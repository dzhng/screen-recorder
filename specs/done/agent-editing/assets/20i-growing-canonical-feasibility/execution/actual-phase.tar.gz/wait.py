# Nonmedia ownership fault: supervisor must kill this child, native Process must reap.
import time
print('WAITING ownership child',flush=True)
time.sleep(60)
