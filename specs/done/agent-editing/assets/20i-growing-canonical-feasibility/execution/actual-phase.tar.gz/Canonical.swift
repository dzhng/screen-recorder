@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import Darwin
import ScreenRecorderMedia

struct FrozenPictures:Decodable {let pictures:[Picture];let nativeScale:Int32;let duration:Tick;let readerStatus:Int}
struct SavedCursorRow:Decodable {let ordinal:Int;let cursor:CursorFact}
struct SavedNativeInventory:Decodable {let rows:[SavedCursorRow];let nativeDuration:Tick;let nativeScale:Int32;let segmentBounds:[SegmentBounds]}
struct Packet:Codable,Equatable {
    let decodePosition:Int;let presentationOrdinal:Int;let pts:Tick;let dts:Tick;let duration:Tick
    let payload:Data;let attachmentsJSON:Data?;let formatEqualToSource:Bool
}
func nativeTime(_ t:Tick)->CMTime {CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)}
func packet(_ sample:CMSampleBuffer,position:Int,presentation:Int,description:CMFormatDescription) throws -> Packet {
    guard let block=sample.dataBuffer,let format=sample.formatDescription,sample.numSamples==1 else {throw ProbeFailure(message:"Compressed sample lacks one complete block/format")}
    let length=CMBlockBufferGetDataLength(block);guard length>0 && length<=65_536 else {throw ProbeFailure(message:"Compressed packet length outside fixed bound")}
    var data=Data(count:length)
    let status=data.withUnsafeMutableBytes {bytes in CMBlockBufferCopyDataBytes(block,atOffset:0,dataLength:length,destination:bytes.baseAddress!)}
    guard status==noErr else {throw ProbeFailure(message:"Compressed bytes unavailable: \(status)")}
    var attachments:Data?
    if let array=CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false) {
        let encoder=JSONEncoder();encoder.outputFormatting=[.sortedKeys];attachments=try encoder.encode(FormatValue(array as NSArray))
    }
    return Packet(decodePosition:position,presentationOrdinal:presentation,pts:Tick(sample.presentationTimeStamp),dts:Tick(sample.decodeTimeStamp),duration:Tick(sample.duration),payload:data,attachmentsJSON:attachments,formatEqualToSource:CMFormatDescriptionEqual(format,otherFormatDescription:description))
}
@main struct CanonicalExperiment {
    @MainActor static func main() async {
        var ownership:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments,mode=args[1],root=URL(fileURLWithPath:args[2])
            let owner=try OwnedEvidenceDestination(root:root);ownership=owner
            let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence"))
            if mode=="ownership" {
                let receipt=root.appendingPathComponent("wait.process.json")
                do {try runByte([args[3]],record:receipt,evidence:evidence);throw ProbeFailure(message:"Waiting ownership child exited without supervisor signal")}
                catch let error as ProbeFailure {
                    guard error.message=="byte query failed",let record=try JSONSerialization.jsonObject(with:Data(contentsOf:receipt)) as? [String:Any],record["terminal"] as? Bool==true,record["waited"] as? Bool==true,record["exitCode"] as? Int==Int(SIGKILL),record["terminationReason"] as? String==String(describing:Process.TerminationReason.uncaughtSignal) else {throw error}
                    try save(["status":"pass","scope":"Actual waiting child killed by supervisor; same Foundation runByte waited/reaped; no media"],root.appendingPathComponent("verdict.json"));return
                }
            }
            guard mode=="canonical" else {throw ProbeFailure(message:"Unknown fixed case")}
            let sourceURL=URL(fileURLWithPath:args[3]),savedURL=URL(fileURLWithPath:args[4]),metadataURL=URL(fileURLWithPath:args[5]),script=args[6]
            let saved=try JSONDecoder().decode(FrozenPictures.self,from:Data(contentsOf:savedURL))
            let sourceSnapshot=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:savedURL))
            let metadata=try JSONDecoder().decode(SavedNativeInventory.self,from:Data(contentsOf:metadataURL))
            try require(saved.pictures.count==197 && metadata.rows.count==197 && metadata.nativeScale==1_000_000,"frozen source inventory",["pictures":String(saved.pictures.count),"metadata":String(metadata.rows.count),"scale":String(metadata.nativeScale)],evidence:evidence)
            let source=AVURLAsset(url:sourceURL,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true]);let tracks=try await source.loadTracks(withMediaType:.video)
            let audio=try await source.loadTracks(withMediaType:.audio)
            try require(tracks.count==1 && audio.isEmpty,"source one video/no audio",["videos":String(tracks.count)],evidence:evidence)
            let track=tracks[0],descriptions=try await track.load(.formatDescriptions),scale=try await track.load(.naturalTimeScale),transform=try await track.load(.preferredTransform)
            try require(descriptions.count==1 && scale==1_000_000,"source description/scale",["descriptions":String(descriptions.count),"scale":String(scale)],evidence:evidence)
            let description=descriptions[0]
            let sourceFormatsURL=root.appendingPathComponent("source-formats.json"),sourceCodecURL=root.appendingPathComponent("source-codec.json")
            try save(try await formatFacts(sourceURL,sourceSnapshot,evidence:evidence),sourceFormatsURL)
            _ = try inspectBytes(sourceURL,savedURL,sourceFormatsURL,sourceCodecURL,script,evidence:evidence)
            let sourceBytes=try Data(contentsOf:sourceURL)
            try require(sourceBytes.count<=2_097_152,"source byte cap",["bytes":String(sourceBytes.count)],evidence:evidence)
            let ordered=metadata.rows.sorted {CMTimeCompare(nativeTime($0.cursor.clocks["mediaDTS"]!),nativeTime($1.cursor.clocks["mediaDTS"]!))<0}
            var cursors=[AVSampleCursor]()
            for row in ordered {
                guard let cursor=track.makeSampleCursor(presentationTimeStamp:nativeTime(row.cursor.clocks["mediaPTS"]!)) else {throw ProbeFailure(message:"Source decode cursor missing at ordinal \(row.ordinal)")}
                cursors.append(cursor)
            }
            for i in 1..<cursors.count {try require(cursors[i-1].comparePositionInDecodeOrder(withPositionOf:cursors[i]) == .orderedAscending,"saved DTS order differs from actual same-track decode order",["position":String(i)],evidence:evidence)}
            let reader=try AVAssetReader(asset:source);defer{reader.cancelReading()}
            let output=AVAssetReaderTrackOutput(track:track,outputSettings:nil);output.alwaysCopiesSampleData=false;reader.add(output)
            let readerStarted=reader.startReading();try require(readerStarted,"compressed source reader start",["status":String(reader.status.rawValue)],evidence:evidence)
            var samples=[CMSampleBuffer](),packets=[Packet]()
            while let sample=output.copyNextSampleBuffer() {
                let i=samples.count;try require(i<197,"unexpected extra source packet",["position":String(i)],evidence:evidence)
                let row=ordered[i],record=try packet(sample,position:i,presentation:row.ordinal,description:description)
                packets.append(record);try save(packets,root.appendingPathComponent("source-packets.json"))
                let extent=row.cursor.extents["sample"]!,offset=Int(extent.offset),length=Int(extent.length)
                try require(offset>=0 && length>0 && offset+length<=sourceBytes.count,"source packet extent",["position":String(i),"offset":String(offset),"length":String(length)],evidence:evidence)
                try require(record.payload==sourceBytes.subdata(in:offset..<offset+length),"source packet bytes differ from frozen extent",["position":String(i),"presentationOrdinal":String(row.ordinal)],evidence:evidence)
                try require(record.pts==row.cursor.clocks["mediaPTS"]! && record.dts==row.cursor.clocks["mediaDTS"]! && record.duration==row.cursor.clocks["decodeDuration"]! && record.formatEqualToSource,"compressed source packet/cursor timing correspondence",["position":String(i),"presentationOrdinal":String(row.ordinal),"pts":String(describing:record.pts),"dts":String(describing:record.dts),"duration":String(describing:record.duration)],evidence:evidence)
                samples.append(sample)
            }
            try require(reader.status == .completed && samples.count==197,"complete compressed source read",["status":String(reader.status.rawValue),"count":String(samples.count)],evidence:evidence)
            let movie=root.appendingPathComponent("candidate.mov"),writer=try AVAssetWriter(outputURL:movie,fileType:.mov)
            var appended=[Packet]()
            defer {
                try? save(appended,root.appendingPathComponent("appended-packets.json"))
                evidence.preserve(mappings:[],observations:Data(),receipts:[],raw:movie)
                if writer.status == .writing{writer.cancelWriting()}
            }
            writer.movieTimeScale=scale;writer.initialMovieFragmentInterval=CMTime(value:1,timescale:4);writer.movieFragmentInterval=CMTime(value:1,timescale:1)
            let input=AVAssetWriterInput(mediaType:.video,outputSettings:nil,sourceFormatHint:description);input.mediaTimeScale=scale;input.transform=transform
            try require(writer.canAdd(input),"candidate rejects passthrough input",[:],evidence:evidence);writer.add(input)
            let writing=writer.startWriting();try require(writing,"candidate writer start",["status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence);writer.startSession(atSourceTime:.zero)
            let started=ContinuousClock.now
            func append(to end:Int) async throws {
                for i in appended.count..<end {
                    while !input.isReadyForMoreMediaData {
                        try require(writer.status == .writing && started.duration(to:.now) < .seconds(15),"passthrough admission deadline",["position":String(i),"status":String(writer.status.rawValue)],evidence:evidence)
                        try await Task.sleep(for:.milliseconds(1))
                    }
                    let accepted=input.append(samples[i]);try require(accepted,"passthrough append failed",["position":String(i),"status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence)
                    appended.append(packets[i]);try save(appended,root.appendingPathComponent("appended-packets.json"))
                }
            }
            var last=0,candidate:Snapshot?,candidateCodec:URL?,fence:Int?,selectedCount:Int?,activePassed=false
            func observe() async throws {
                guard let (copy,n)=try frozenExtension(movie,root,last,evidence:evidence) else{return}
                let snap=try await read(copy,phase:"canonical-active-\(n)",fragments:n,evidence:evidence)
                let snapshotURL=root.appendingPathComponent("active-\(n).json"),fmtURL=root.appendingPathComponent("active-\(n)-formats.json"),codecURL=root.appendingPathComponent("active-\(n)-codec.json")
                try save(snap,snapshotURL);try save(try await formatFacts(copy,snap,evidence:evidence),fmtURL)
                let result=try inspectBytes(copy,snapshotURL,fmtURL,codecURL,script,evidence:evidence)
                try require(snap.canContainFragments==true && (n==1 || snap.containsFragments==true),"native candidate fragment qualification",["count":String(n)],evidence:evidence)
                if candidate==nil,let selected=result.completeIDRFenceOrdinals.min() {
                    try require(snap.pictures.count>selected,"candidate closing IDR was not decoded",["fence":String(selected),"pictures":String(snap.pictures.count)],evidence:evidence)
                    candidate=snap;candidateCodec=codecURL;fence=selected;selectedCount=appended.count
                    try save(snap,root.appendingPathComponent("candidate-prefix.json"));try save(["fenceOrdinal":selected,"appendedAtSelection":appended.count,"fragment":n],root.appendingPathComponent("selection.json"))
                } else if let candidate,let fence,let expected=candidateCodec,let count=selectedCount {
                    try save(["candidateAppended":count,"laterAppended":appended.count,"candidateFragment":candidate.completedFragments,"laterFragment":n,"closeCalled":0],root.appendingPathComponent("active-\(n)-comparison-receipt.json"))
                    try require(appended.count>count && n>candidate.completedFragments,"further active successful append absent",["selected":String(count),"later":String(appended.count)],evidence:evidence)
                    try compare(Array(candidate.pictures.prefix(fence)),snap,evidence:evidence);try compareLogical(expected,codecURL,fence,script,root.appendingPathComponent("active-\(n)-logical-comparison.json"),evidence:evidence);activePassed=true
                }
                last=n
            }
            try await append(to:59)
            while candidate==nil && started.duration(to:.now) < .seconds(7){try await observe();if candidate==nil{try await Task.sleep(for:.milliseconds(20))}}
            try require(candidate != nil && selectedCount==59,"first fixed batch lacks a complete candidate IDR fence",["appended":String(appended.count)],evidence:evidence)
            try await append(to:175)
            while !activePassed && started.duration(to:.now) < .seconds(14){try await observe();if !activePassed{try await Task.sleep(for:.milliseconds(20))}}
            try require(activePassed,"second fixed batch lacks further active candidate extension",["appended":String(appended.count),"fragments":String(last)],evidence:evidence)
            try await append(to:197)
            let end=saved.pictures.last!.end!;writer.endSession(atSourceTime:nativeTime(end));input.markAsFinished();await writer.finishWriting()
            try require(writer.status == .completed,"candidate closure failed",["status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence)
            let final=try await read(movie,phase:"canonical-closed",fragments:try fragments(movie,evidence:evidence),evidence:evidence)
            let finalURL=root.appendingPathComponent("closed.json"),fmtURL=root.appendingPathComponent("closed-formats.json"),codecURL=root.appendingPathComponent("closed-codec.json")
            try save(final,finalURL);try save(try await formatFacts(movie,final,evidence:evidence),fmtURL);_ = try inspectBytes(movie,finalURL,fmtURL,codecURL,script,evidence:evidence)
            try compareLogical(sourceCodecURL,codecURL,197,script,root.appendingPathComponent("all197-source-logical-comparison.json"),evidence:evidence)
            let reopened=AVURLAsset(url:movie),reopenedTracks=try await reopened.loadTracks(withMediaType:.video)
            try require(reopenedTracks.count==1,"closed compressed track count",["count":String(reopenedTracks.count)],evidence:evidence)
            let compressedReader=try AVAssetReader(asset:reopened);defer{compressedReader.cancelReading()}
            let compressedOutput=AVAssetReaderTrackOutput(track:reopenedTracks[0],outputSettings:nil);compressedOutput.alwaysCopiesSampleData=false;compressedReader.add(compressedOutput)
            let compressedStarted=compressedReader.startReading();try require(compressedStarted,"closed compressed reader start",["status":String(compressedReader.status.rawValue)],evidence:evidence)
            var closedPackets=[Packet]()
            while let sample=compressedOutput.copyNextSampleBuffer() {
                let i=closedPackets.count;try require(i<197,"extra closed packet",["position":String(i)],evidence:evidence)
                closedPackets.append(try packet(sample,position:i,presentation:ordered[i].ordinal,description:description));try save(closedPackets,root.appendingPathComponent("closed-packets.json"))
            }
            try require(compressedReader.status == .completed && closedPackets==packets,"all compressed payload/attachment/timing/format receipts differ",["status":String(compressedReader.status.rawValue),"expectedCount":String(packets.count),"actualCount":String(closedPackets.count),"expectedOperand":"source-packets.json","actualOperand":"closed-packets.json"],evidence:evidence)
            try compare(saved.pictures,final,evidence:evidence);try require(final.pictures.count==197 && (final.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}) == (metadata.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}),"complete candidate support/inventory correspondence",["count":String(final.pictures.count)],evidence:evidence)
            try compare(Array(candidate!.pictures.prefix(fence!)),final,evidence:evidence);try compareLogical(candidateCodec!,codecURL,fence!,script,root.appendingPathComponent("closed-prefix-logical-comparison.json"),evidence:evidence)
            try save(["status":"pass","scope":"Distinct passthrough MOV own prefix active/closure plus full197 frozen input tuples; no private production digest/adoption","committedPictures":String(fence!),"appended":"197"],root.appendingPathComponent("verdict.json"))
        }catch{if let owner=ownership{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
    }
}
