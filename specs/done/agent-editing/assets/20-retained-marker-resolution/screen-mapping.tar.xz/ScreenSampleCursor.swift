@preconcurrency import AVFoundation
import Foundation

enum ProbeError: Error { case invalid(String) }
func ticks(_ t: CMTime) -> [String: Any] {
    ["value": String(t.value), "timescale": Int(t.timescale), "epoch": String(t.epoch), "flags": t.flags.rawValue]
}
func us(_ t: CMTime) -> Int64 {
    CMTimeConvertScale(t, timescale: 1_000_000, method: .roundHalfAwayFromZero).value
}
@main struct Probe {
    static func main() async throws {
        guard CommandLine.arguments.count == 3 else { throw ProbeError.invalid("input output") }
        let input = CommandLine.arguments[1], output = CommandLine.arguments[2]
        let asset = AVURLAsset(url: URL(fileURLWithPath: input), options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        guard let track = try await asset.loadTracks(withMediaType: .video).first else { throw ProbeError.invalid("no video") }
        let segments = try await track.load(.segments)
        var rows: [[String: Any]] = [], segmentRows: [[String: Any]] = []
        let deadline = Date().addingTimeInterval(45)
        var visited = 0
        for (segmentIndex, segment) in segments.enumerated() {
            let map = segment.timeMapping
            segmentRows.append(["ordinal": segmentIndex, "empty": segment.isEmpty,
                "sourceStart": ticks(map.source.start), "sourceDuration": ticks(map.source.duration),
                "targetStart": ticks(map.target.start), "targetDuration": ticks(map.target.duration)])
            if segment.isEmpty { continue }
            // This retained source is1:1. Refuse unsupported retiming rather than approximating it.
            guard map.source.duration == map.target.duration else { throw ProbeError.invalid("non-unit segment mapping") }
            guard let cursor = track.makeSampleCursor(presentationTimeStamp: map.source.start) else { throw ProbeError.invalid("no cursor") }
            let segmentEnd = CMTimeRangeGetEnd(map.source)
            while cursor.presentationTimeStamp < segmentEnd {
                guard Date() < deadline, visited < 8000 else { throw ProbeError.invalid("deadline or8000-position bound") }
                visited += 1
                let at = cursor.presentationTimeStamp, duration = cursor.currentSampleDuration
                guard at.isNumeric, duration.isNumeric, duration > .zero else { throw ProbeError.invalid("invalid sample timing") }
                let end = CMTimeMinimum(CMTimeAdd(at, duration), segmentEnd)
                if end > map.source.start {
                    let presented = CMTimeAdd(map.target.start, CMTimeSubtract(CMTimeMaximum(at, map.source.start), map.source.start))
                    let presentedEnd = CMTimeAdd(map.target.start, CMTimeSubtract(end, map.source.start))
                    rows.append(["presentationOrdinal": rows.count, "segmentOrdinal": segmentIndex,
                        "cursorPts": ticks(at), "cursorDts": ticks(cursor.decodeTimeStamp), "cursorDuration": ticks(duration),
                        "presentedAssetUs": us(presented), "presentedEndUs": us(presentedEnd)])
                }
                if cursor.stepInPresentationOrder(byCount: 1) != 1 { break }
                guard cursor.presentationTimeStamp > at else { throw ProbeError.invalid("no cursor progress") }
            }
        }
        let result: [String: Any] = ["input": input, "scope": "AVAsset sample cursor metadata only; no asset reader/decoder or payload hash", "maxPositions": 8000,
            "internalDeadlineSeconds": 45, "visitedPositions": visited, "presentedSamples": rows.count, "segments": segmentRows, "samples": rows]
        let bytes = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        try bytes.write(to: URL(fileURLWithPath: output), options: [.atomic])
        print("samples \(rows.count), visited \(visited)")
    }
}
