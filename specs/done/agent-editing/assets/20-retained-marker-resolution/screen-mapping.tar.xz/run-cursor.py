import subprocess,time,json,pathlib,os,signal,hashlib
p=pathlib.Path('/tmp/retained-camera-measurement-20260930/screen-mapping');root=pathlib.Path('/Users/david/dev/screen-recorder');cmd=[str(p/'screen-sample-cursor'),str(root/'fixtures/screen-camera-timing/screen/video.mov'),str(p/'cursor-metadata.json')];start=time.monotonic()
with (p/'cursor.stdout.log').open('wb') as stdout,(p/'cursor.stderr.log').open('wb') as stderr:
 proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=proc.wait(timeout=60);stopped=None
 except subprocess.TimeoutExpired:
  stopped='60-second hard deadline';os.killpg(proc.pid,signal.SIGTERM)
  try:code=proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
compiler=subprocess.check_output(['xcrun','--find','swiftc'],text=True).strip();version=subprocess.check_output(['xcrun','swiftc','--version'],text=True).strip()
identity=lambda f:{'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
result={'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'hardDeadlineSeconds':60,'stoppedBy':stopped,'compiler':{'path':compiler,'version':version},'source':identity(p/'ScreenSampleCursor.swift'),'executable':identity(p/'screen-sample-cursor'),'inputIdentity':next(x for x in json.loads((root/'fixtures/screen-camera-timing/manifest.json').read_text())['sources'] if x['path']=='screen/video.mov'),'inputHashPolicy':'Reused retained manifest hash; this run did not hash media or decode any pixels.'}
(p/'cursor-run.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
