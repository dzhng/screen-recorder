import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {projectCompositionFromRevision} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/core/dist/project-window.js';
const home='/tmp/screenrec-state-bindings-trace';
function source(name:string,rate:number,channels:number) {
 const bytes=Buffer.alloc(44+rate*channels*4);bytes.write('RIFF');bytes.writeUInt32LE(bytes.length-8,4);bytes.write('WAVEfmt ',8);bytes.writeUInt32LE(16,16);bytes.writeUInt16LE(3,20);bytes.writeUInt16LE(channels,22);bytes.writeUInt32LE(rate,24);bytes.writeUInt32LE(rate*channels*4,28);bytes.writeUInt16LE(channels*4,32);bytes.writeUInt16LE(32,34);bytes.write('data',36);bytes.writeUInt32LE(bytes.length-44,40);for(let i=0;i<rate;i++) for(let c=0;c<channels;c++)bytes.writeFloatLE(c===0?.125:-.25,44+(i*channels+c)*4);
 const path=join(home,name);writeFileSync(path,bytes);return {path,asset:{id:createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,createdAt:'2026-09-29T00:00:00.000Z',fileName:name,originUs:0,streams:[{id:'sound',kind:'audio',codec:'pcm_f32le',decodable:true,startUs:0,endUs:1000000,segments:[{startUs:0,endUs:1000000,empty:false}],sampleRate:rate,channels}]}};
}
const first=source('mono-44100.wav',44100,1),second=source('mono-48000.wav',48000,1),stereo=source('stereo-44100.wav',44100,2);
const results=[];
for(const scenario of ['mono','missing-support','stereo','unknown','restricted'] as const) {
 const left=scenario==='stereo'?stereo:first;
 const asset=scenario==='unknown'?{...left.asset,streams:left.asset.streams.map(({channels,...s})=>s)}:left.asset;
 const metadata=new Map([[asset.id,asset],[second.asset.id,second.asset]]),paths=new Map([[asset.id,left.path],[second.asset.id,second.path]]);
 const document={canvas:{width:64,height:64,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:[{id:'audio',kind:'audio',order:0}],groups:[],syncGroups:[],clips:[{id:'first',trackId:'audio',assetId:asset.id,streamId:'sound',acquisitionId:'capture',source:{kind:'range',range:{startUs:0,endUs:1000000}},placement:{kind:'project',range:{startUs:0,endUs:1000000}}},{id:'silence',trackId:'audio',source:{kind:'silence'},placement:{kind:'project',range:{startUs:1000000,endUs:2000000}}},{id:'second',trackId:'audio',assetId:second.asset.id,streamId:'sound',source:{kind:'range',range:{startUs:0,endUs:1000000}},placement:{kind:'project',range:{startUs:2000000,endUs:3000000}}}],processing:[{target:{kind:'clip',id:'first'},steps:[{id:'gain',enabled:true,processor:{type:'gain',gain:.5}}]},{target:{kind:'track',id:'audio'},steps:[{id:'noise',enabled:true,processor:{type:'rnnoise'},...(scenario==='restricted'?{window:{kind:'project',range:{startUs:2000000,endUs:3000000}}}:{})}]}]};
 const contexts=[{id:'capture',bindings:[{assetId:asset.id,streamId:'sound',available:scenario==='missing-support'?[{startUs:0,endUs:250000},{startUs:500000,endUs:1000000}]:[{startUs:0,endUs:1000000}]}]}];
 const composition=projectCompositionFromRevision({id:'revision-'+scenario,projectId:'fixture-project',document} as any,{get:(id:string)=>metadata.get(id)!,path:(id:string)=>paths.get(id)!} as any,contexts);
 const request={range:{startUs:2000000,endUs:2500000}}, support={implementationId:'unbound-fixture'};
 const retained=composition.window(request,support,'audio','retained');let refusal;
 try {composition.window(request,support,'audio');refusal={unexpected:'admitted'};}catch(error:any){refusal={code:error.code,message:error.message,details:error.details};}
 results.push({scenario,metadata:[...metadata.values()],contexts,document,request,bindings:retained.assets,manifest:retained.window.manifest,refusal});
}
writeFileSync(join(home,'results.json'),JSON.stringify({scope:'Generated WAV and declared-probe fixtures; no native probe, DSP, publication or listening',results},null,2)+'\n');
