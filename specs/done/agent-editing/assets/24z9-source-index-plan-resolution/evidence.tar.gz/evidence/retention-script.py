from pathlib import Path
import subprocess, json, hashlib, shutil
root=Path.cwd();proof=Path('/tmp/24z9-evidence');proof.mkdir(exist_ok=True)
owner=Path('packages/core/src/index-processing.ts');test=Path('packages/core/src/source-index-processing.test.ts');ownerSource=owner.read_bytes();testSource=test.read_bytes()
def snapshot(where):
 paths=['packages/core/src/index-processing.ts','packages/core/src/source-index-processing.test.ts','packages/core/src/index-processing.fixture.ts'];pins=[]
 for name in paths:
  p=Path(name);target=where/'runtime'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  pins.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 return pins
for arm in ['red','green']:
 directory=proof/arm;directory.mkdir(exist_ok=True)
 try:
  owner.write_bytes(subprocess.check_output(['git','show','HEAD:'+str(owner)]) if arm=='red' else ownerSource)
  instrument=testSource.decode().replace('import { createHash }','import { cpSync, mkdirSync, writeFileSync } from "node:fs";\nimport { createHash }',1)
  for pattern,label,values in [
   ('  expect(work).toEqual({ headers: 6, segments: 6, acquisitions: 3 });','request','{ selection, delivered, before, result, work, callsBefore: calls, callsAfter: f.calls }'),
   ('  expect(work).toEqual({ headers: 2, segments: 2, acquisitions: 1 });','execution','{ selection, delivered, job, work, finalJob: f.jobs.job(job.jobId) }')]:
   injection='''  f.catalog.catalog.exec("PRAGMA wal_checkpoint(TRUNCATE)");
  mkdirSync(%s, { recursive: true });
  cpSync(f.home, %s, { recursive: true });
  writeFileSync(%s, JSON.stringify(%s, null, 2));
'''%(json.dumps(str(directory/label)),json.dumps(str(directory/label/'catalog')),json.dumps(str(directory/label/'consumer.json')),values)
   assert pattern in instrument;instrument=instrument.replace(pattern,injection+pattern,1)
  test.write_text(instrument);pins=snapshot(directory)
  command=['node','node_modules/vitest/vitest.mjs','run',str(test),'-t','ready source index requests resolve|source index execution validates','--maxWorkers=1']
  with (directory/'test.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  (directory/'source-pins.json').write_text(json.dumps({'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'command':command,'exitCode':result.returncode,'pins':pins},indent=2)+'\n')
  print(arm,'exit',result.returncode,'request',json.loads((directory/'request'/'consumer.json').read_text())['work'],'execution',json.loads((directory/'execution'/'consumer.json').read_text())['work'])
 finally:owner.write_bytes(ownerSource);test.write_bytes(testSource)
for name,needle,replacement,pattern in [
 ('target-order','''    if (job.target.assetId !== input.assetId)
      throw new CatalogError("ARTIFACT_CHANGED", "Source index recipe changed");
    const { options, source } = this.asset.frames.sourcePlan({ ...input, atUs: 0 });''','''    const { options, source } = this.asset.frames.sourcePlan({ ...input, atUs: 0 });
    if (job.target.assetId !== input.assetId)
      throw new CatalogError("ARTIFACT_CHANGED", "Source index recipe changed");''','source index target mismatch'),
 ('complete-support','{ durationUs: source.durationUs, support: source.track.available }','{ durationUs: source.durationUs, support: [] }','source index execution validates')]:
 directory=proof/'controls'/name;directory.mkdir(parents=True,exist_ok=True);assert needle in ownerSource.decode()
 try:
  owner.write_text(ownerSource.decode().replace(needle,replacement,1));pins=snapshot(directory)
  command=['node','node_modules/vitest/vitest.mjs','run',str(test),'-t',pattern,'--maxWorkers=1']
  with (directory/'red.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  (directory/'source-pins.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'mutation':{'path':str(owner),'needle':needle,'replacement':replacement},'pins':pins},indent=2)+'\n');print(name,'red',result.returncode)
 finally:owner.write_bytes(ownerSource)
 with (directory/'restored.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,'restored',result.returncode)
final=proof/'final-source';final.mkdir(exist_ok=True);pins=snapshot(final)
(final/'source-pins.json').write_text(json.dumps({'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'pins':pins},indent=2)+'\n')
shutil.copy2('/tmp/24z9-retain.py',proof/'retention-script.py')
