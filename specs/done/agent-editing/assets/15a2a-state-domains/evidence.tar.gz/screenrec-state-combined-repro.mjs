import { applyBatch, validateComposition } from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/dist/index.js';
import {writeFileSync} from 'node:fs';
const clip=(id,trackId,startUs,endUs)=>({id,trackId,source:{kind:'silence'},placement:{kind:'project',range:{startUs,endUs}}});
const step=(id,stateKey)=>({id,stateKey,enabled:true,processor:{type:'rnnoise'}});
const input={canvas:{width:64,height:64,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:['audio','x','destination'].map((id,order)=>({id,kind:'audio',order})),groups:[],syncGroups:[],clips:[clip('c0','audio',0,1000000),clip('c2','audio',2000000,3000000),clip('d0','x',0,1000000),clip('d2','x',2000000,3000000)],processing:[{target:{kind:'clip',id:'c0'},steps:[step('a0','A'),step('b0','B')]},{target:{kind:'clip',id:'c2'},steps:[step('b2','B'),step('a2','A')]},{target:{kind:'clip',id:'d0'},steps:[step('x0','X')]},{target:{kind:'clip',id:'d2'},steps:[step('x2','X')]}]};
validateComposition(input,[]);
const operations=[{operation:'move',clipIds:['c2','d2'],atUs:1000000,scope:'selected',ripple:'none',tracks:[{clipId:'d2',trackId:'destination'}]}];
let outcome;
try { outcome={ok:true,result:applyBatch(input,operations,{namespace:'combined',assets:[]})}; }
catch(error){outcome={ok:false,error:{message:error.message,code:error.code,details:error.details}};}
writeFileSync('/tmp/screenrec-state-combined-repro.json',JSON.stringify({input,operations,outcome},null,2)+'\n');
console.log(JSON.stringify(outcome));
