**This can remain one coherent pure checkpoint, but the proposal is not yet clean enough to implement.** The scope is sensible; the unresolved parts are membership normalization, domain selection, and edit semantics—not DSP.

I read the schema, processing/edit paths, partition, duplicate, replacement, compiler, and processing contract. No files changed; no builds, tests, or inference ran.

1. **Overlap detachment conflicts with the existing timeline invariant.**

   [model.ts:371](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/model.ts:371) rejects overlapping clips on the same track, regardless of processing identity. Detaching keys cannot make such a move valid.

   Smallest correction: retain same-track overlap rejection. Demonstrate detachment by moving a member to another track, including a destination where it overlaps its former sibling in project time. Allowing same-track overlap would be a separate structural change.

2. **`processing.set` needs explicit omission and processor-change rules.**

   Existing set replaces the complete stack and reconstructs each step in [edits.ts:426](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:426). Merely allowing an inspected `stateKey` to roundtrip is insufficient: an ordinary gain-prefix edit that omits that field could accidentally sever continuity.

   Specify:

   - Existing stateful instance, omitted key: preserve existing membership.
   - Supplied key: check against that instance’s effective key before normalization.
   - Fresh instance: reject caller-supplied membership.
   - Stateful → stateless under the same instance ID: remove membership; reject an explicitly supplied state key.
   - Incompatible stateful recipe change: detach the changed instance, or explicitly define recipe-separated domains.

   “Compatible recipe” needs an exact definition. Prefix gain differences are correctly excluded from that comparison.

3. **The root-token repair is real complexity; it can be avoided.**

   Under `effectiveKey = stateKey ?? id`, detaching root instance `a` from group `{a,b,c}` requires rewriting the surviving group because clearing `a.stateKey` still yields `a`. Your proposed repair works, but needs deterministic survivor selection, handling of multiple detachments, deleted roots, and keys whose original instance no longer exists.

   The smallest alternative is **distinct implicit and explicit identity namespaces**:

   - Absent key means independent identity `["instance", step.id]`.
   - Present key means shared identity `["shared", stateKey]`.
   - First split writes the original step ID as explicit `stateKey` on **both** retained original and children.
   - Detach clears the changed instance’s key; siblings need no rewrite.

   This requires no allocator or ancestor lookup, but changes the proposed equivalence between absent key and explicit own ID. If that equivalence is mandatory, retain the repair and document its deterministic rules. Do not add a persistent group registry.

4. **Normalization must respect existing operation boundaries and indirect changes.**

   [edits.ts:906](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:906) validates after every operation and then records its normalized changes. Replacement/ripple paths also validate intermediate documents, including [move.ts:44](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/move.ts:44).

   “Before final validation” is therefore ambiguous. Specify normalization at each externally meaningful operation boundary, without letting temporary helper documents trigger irreversible membership repairs.

   Also, “changed target” must include resolved descendants and ripple-shifted occurrences, not just explicitly selected IDs. Conversely, moving an entire shared group together to one new track should preserve continuity when its relationships remain valid.

   Existing processing receipts can expose sibling rekeying through ordinary stack changes; no new receipt owner is necessary.

5. **Dependency analysis belongs to current domains, but repair needs a bounded rule.**

   Keep graph nodes as **connected execution domains**, not state keys. One key can have several disconnected domains; key-level edges could report false cycles.

   Derive prerequisites from enabled prefix steps and their relevant domain coverage. Preserve `A → independent X → B` when acyclic. Compare the relative ordering of surviving shared steps, so adding/removing a step is not mistaken for reordering merely because indices shifted.

   “Detach as necessary” otherwise invites a complicated minimum-repair search. A robust first policy is:

   - Apply explicit reorder/track-detachment rules.
   - Derive domains and detect cycles.
   - If cyclic, detach shared memberships on the affected changed targets participating in those cycles, then recompute with a documented progress bound.

   Reuse one pure derivation routine for editor diagnostics and compiler validation. Imported cyclic documents should fail validation without editor-style repair.

6. **Whole-activation authoring does not remove window/tap compilation requirements.**

   [compiler.ts:230](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/compiler.ts:230) selects requested-window contributors before constructing the processing plan. A request covering only the right split child therefore excludes the left child from the ordinary inputs.

   If `stateDomains` is derived from that selected plan, the same revision acquires different domains depending on the request—contradicting revision-owned membership.

   Derive domains from the complete current revision first, then select relevant domains and prerequisite closure for the requested tap. Explicitly distinguish:

   - **Authored activation window:** limits permitted DSP input.
   - **Requested output window:** selects output from the activation domain.

   Also resolve clip taps: the right child’s processed tap may require earlier sibling input for shared state, while its dry tap must not acquire that dependency. This distinction is needed in pure metadata now, even though execution remains unavailable.

7. **“Gaps separate domains” needs a precise definition.**

   The model distinguishes structural span, source availability, and ancestor support in [model.ts:328](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/model.ts:328). Existing resampling domains intentionally follow available source support in [audio-context.ts:26](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/audio-context.ts:26).

   Specify separately:

   - Empty project time between member spans: separate domains.
   - Explicit replacement silence: participates in continuity.
   - Source/acquisition holes and unavailable ancestor intervals: define whether these feed known silence or break activation.
   - Bypassed member: retains stored membership but contributes no stateful execution; define the resulting domain break and reconnection on re-enable.

   Do not inherit resampling’s source/rate continuity rules: authored DSP is downstream of retiming and may legitimately continue across different sources or a silence tail.

   Use exact project endpoints for adjacency, then lower to sample ranges. Include fractional boundaries and positive-duration members producing zero output samples.

Two smaller decisions should also be explicit:

- **Batch duplication:** resetting every copied key makes copied siblings independent of one another as well as their originals. That fits a literal “duplicate independent” contract, but differs from cloning a shared group into a new independent group. [duplicate.ts:40](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/duplicate.ts:40) currently uses the same remapper as preservation operations.
- **Silence manifest coverage:** [execution-window.ts:155](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/execution-window.ts:155) omits synthetic silence from `sources`. Domain members must identify silence and its timing without requiring a media-source entry.

The unavailable execution boundary fits the existing architecture: [project-window.ts:27](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/core/src/project-window.ts:27) explicitly binds supported processor implementations, leaving RNNoise unresolved. Enabled RNNoise should remain `NOT_READY`; dry/bypassed paths should retain their existing behavior. The composition stream schema has no channel-count proof, so mono/structural-dual-mono execution eligibility remains outside this checkpoint.

**Verdict: one checkpoint is viable after these decisions are pinned.** Keep its acceptance to stored membership, deterministic edit normalization, current-domain compilation, request/tap consistency, unchanged stateless manifest shape, and refusal behavior. Add root deletion/detachment, omitted-key gain edits, bypass/re-enable, whole-group movement, fractional splits, and right-child-only taps to the proposed tracers. Parent processing, temporal RNNoise activation, channel execution, prepared consumers, and audible split preservation remain open.