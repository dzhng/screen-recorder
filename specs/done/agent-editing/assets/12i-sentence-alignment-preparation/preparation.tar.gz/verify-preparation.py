"""Verify saved preparation records without importing or loading candidate libraries."""
import hashlib,json,pathlib
ns=pathlib.Path(__file__).parent
def pin(p):
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
qpath=ns/'evidence/qualification.json';q=json.loads(qpath.read_text())
epath=pathlib.Path('/Users/david/.cache/screen-recorder/verification/sentence-12h-2591aa28/evidence/evaluation.json');e=json.loads(epath.read_text())
assert e['controls']['medianErrorMs']==q['timingAudit']['medianAbsoluteMs']
assert e['controls']['p95ErrorMs']==q['timingAudit']['p95AbsoluteMs']
assert [p['errorMs'] for p in e['controls']['boundaries']]==q['timingAudit']['sixSignedErrorsMs']
assert e['openingUm']['end']['errorMs']==q['timingAudit']['openingUmEndSignedErrorMs']
q['timingEvaluationAuthority']=pin(epath);qpath.write_text(json.dumps(q,indent=2)+'\n')
rpath=ns/'evidence/report.json';r=json.loads(rpath.read_text());r['qualification']=pin(qpath)
paths={str(p.relative_to(ns/'model')) for p in (ns/'model').rglob('*') if p.is_file() and '.cache' not in p.relative_to(ns/'model').parts}
assert paths=={p['path'] for p in r['model']['files']}
r['model']['completeFileSetMatches']=True;rpath.write_text(json.dumps(r,indent=2)+'\n')
print('PASS: exact eight managed model files; retained12h timing metrics and all signed errors equal saved evaluation; model load/conversion/inference unexecuted')
