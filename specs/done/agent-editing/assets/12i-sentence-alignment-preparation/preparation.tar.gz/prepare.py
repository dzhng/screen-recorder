"""One isolated recipe preparation; never imports or loads an inference dependency."""
import json, os, pathlib, signal, subprocess, time
ns = pathlib.Path(__file__).parent
history = json.loads((ns/'evidence/historical-manifest.json').read_text())
env = dict(os.environ, HF_HOME=str(ns/'hf-cache'), HF_HUB_CACHE=str(ns/'hf-cache/hub'), HF_XET_CACHE=str(ns/'hf-cache/xet'), HF_HUB_DISABLE_IMPLICIT_TOKEN='1', UV_CACHE_DIR=str(ns/'uv-cache'), UV_HTTP_RETRIES='0', UV_PYTHON_DOWNLOADS='never', TMPDIR=str(ns/'temp'), PYTHONDONTWRITEBYTECODE='1')
phases = [
 ('environment', ['/opt/homebrew/bin/uv','venv','--no-config','--no-project','--no-python-downloads','--python',str(ns/'python/bin/python3.11'),str(ns/'venv')]),
 ('model-download', ['/Users/david/.local/bin/hf','download','Qwen/Qwen3-ForcedAligner-0.6B-hf',*[p['path'] for p in history['modelFiles']],'--revision','c07281df297b9905d24a508279258cccf987a064','--cache-dir',str(ns/'hf-cache/hub'),'--local-dir',str(ns/'model')]),
 ('dependencies', ['/opt/homebrew/bin/uv','pip','install','--no-config','--no-python-downloads','--no-deps','--no-build','--link-mode','copy','--python',str(ns/'venv/bin/python'),'--requirement',str(ns/'requirements.txt')]),
 ('dependency-check', ['/opt/homebrew/bin/uv','pip','check','--no-config','--python',str(ns/'venv/bin/python')]),
]
records=[]
def size():
 return sum(p.stat().st_size for p in ns.rglob('*') if p.is_file() and not p.is_symlink())
for name, command in phases:
 started=time.monotonic()
 with (ns/f'evidence/{name}.stdout').open('wb') as out, (ns/f'evidence/{name}.stderr').open('wb') as err:
  child=subprocess.Popen(command,env=env,stdout=out,stderr=err,start_new_session=True,cwd=ns)
  reason=None
  while child.poll() is None:
   elapsed=time.monotonic()-started
   current=size()
   if elapsed>900 or current>10*1024**3:
    reason='deadline' if elapsed>900 else 'namespace-capacity'
    os.killpg(child.pid,signal.SIGTERM)
    try: child.wait(timeout=10)
    except subprocess.TimeoutExpired:
     os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(2)
  record={'phase':name,'command':command,'pid':child.pid,'exitCode':child.wait(),'wallSeconds':time.monotonic()-started,'namespaceBytes':size(),'stopReason':reason}
  records.append(record)
  (ns/'evidence/commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps(record),flush=True)
  if record['exitCode'] or reason:
   raise SystemExit(1)
