# Pointer demo edit report

Two H.264 movie exports were committed from managed project revisions. The project was left intact.

| Version | Revision | Export |
|---|---|---|
| Initial picture with captured pointer and 0.6 s trail | `ebcc09cd-f9d1-4c99-b7bf-f2dc09bac08f` | [pointer-demo-v1.mp4](./pointer-demo-v1.mp4) |
| Footage at 20% opacity with pointer and trail retained; split at 950001 µs | `2224b4b3-7290-4aed-81f1-89ae21fba970` | [pointer-demo-v2-dim-split.mp4](./pointer-demo-v2-dim-split.mp4) |

Both exports cover 0–2,000,000 µs at 256×160 and 10 fps, with a black `#000000ff` canvas. The footage source remains 256×160 and is placed at `(32,16)` with a 256×160 destination rectangle. The capture-bound pointer processor is enabled with `trailUs: 600000`. The second revision adds a 0.2 opacity step before the pointer step, so the pointer and trail remain bright over the dimmed footage.

The split receipt partitions the video into project/source ranges `[0,950001)` and `[950001,2000000)`. Both halves retain the same asset, stream, and acquisition binding; the second half begins at source time 950001 µs. The processing lineage receipt shows geometry, opacity, and pointer steps carried onto the right clip. A project cursor read across the split reports available support on both sides and a cursor observation at 900000 µs on the left; later observations at 1100000 and 1300000 µs map to the right clip at those same project/source times. This supports continuous source mapping through the split.

## Inspection pictures

- [Version 1 at 700 ms](./frame_v1/01.png)
- [Version 1 at 1.3 s](./frame_v1/02.png)
- [Version 2 at 900 ms](./frame_v2/01.png)
- [Version 2 requested at the 950001 µs split](./frame_v2/02.png)
- [Version 2 at 1.0 s](./frame_v2/03.png)
- [Version 2 at 1.3 s](./frame_v2/04.png)

The inspected version 1 image shows the pointer and trail over footage shifted within the black canvas. Version 2 at 1.0 s and 1.3 s shows dimmed footage with the pointer and trail bright. The long trail at 1.0 s is visually consistent with carrying cursor history across the split rather than starting a fresh 50 ms trail.

The request at 950001 µs resolves to the preceding 10 fps sampled picture at 900000 µs, with a reported visible range of `[900000,1000000)`. Its delivered PNG is black even though the receipt reports an available video layer. That exact boundary picture is therefore inconclusive; the adjacent 900 ms and 1.0 s pictures and cursor mapping receipts provide the evidence above. No audio was present in the imported capture, so no audio behavior was verified. Movie exports were confirmed committed by `export.status`; they were not played back.

## Receipts

Requests and raw receipts are preserved alongside this report, including rejected attempts: acquisition import/get and job receipts, project create/list/get, edit requests/receipts, capability read, frame batch requests/receipts, cursor and timeline reads, and both export create/status receipts. The first project ID appeared in `project.list` but returned `NOT_FOUND` from `project.get` and `edit.apply`; a second project was created and used for the completed exports. An early placement attempt was rejected for a request-shape error and the corrected attempt was retained separately.
