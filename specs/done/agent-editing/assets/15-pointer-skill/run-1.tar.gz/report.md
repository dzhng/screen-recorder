# Captured pointer demo

Completed through the supplied `screenrec` CLI. The project remains in place.

## Delivered movies

- `pointer-demo-v1.mp4` — [open file](/tmp/screenrec-pointer-skill-1/pointer-demo-v1.mp4), committed export of revision `8ca4c885-8494-4eac-8f6c-b8db5cf6ce47`.
- `pointer-demo-v2.mp4` — [open file](/tmp/screenrec-pointer-skill-1/pointer-demo-v2.mp4), committed export of revision `3a7e220f-2014-4f97-859d-f41311fadae3`.

Both export receipts report a 0–2,000,000 µs H.264 Rec.709 video export. The project canvas is 256×160 at 10 fps on opaque black. The admitted source video is also 256×160 and two seconds long. Its clip uses the captured acquisition binding. Processing capabilities reported executable pointer, geometry and opacity steps. The pointer trail is 600,000 µs; the geometry places the original 256×160 footage at x=32, y=16; version two applies 0.2 opacity before drawing the pointer and trail.

The first revision remains in project history as a separate immutable revision. Version two splits the footage at exactly 950,001 µs and keeps both sides mapped to the corresponding source ranges through 2,000,000 µs.

## Inspection evidence

The CLI delivered project output frames in [version 1 frames](/tmp/screenrec-pointer-skill-1/version1-frames) at 0.3, 0.9, 1.2 and 1.8 seconds; and [version 2 frames](/tmp/screenrec-pointer-skill-1/version2-frames) at 0.3, 0.9, 1.0, 1.1 and 1.8 seconds. Each sampled PNG is 256×160 and its receipt identifies the pinned revision and visible clip occurrence.

I compared the version-two frame at 1.0 seconds (50 ms after the split) with the unsplit version-one frame at the same project time. The bright pointer and trail occupy the same path in both pictures, while the second version's footage is dimmer. The split receipt also shows the right side begins at source time 950,001 µs, the left side ends there, and the pointer stack was carried to the right clip. Together, these checks support that the trail did not restart at the split.

Useful seam comparison pictures are [unsplit version one at 1.0 s](/tmp/screenrec-pointer-skill-1/version1-seam-reference/01.png) and [split version two at 1.0 s](/tmp/screenrec-pointer-skill-1/version2-frames/03.png). All raw CLI receipts and request JSON files are saved alongside this report.

## Verification limits

The export service confirmed both files committed and returned their byte counts and SHA-256 digests. I inspected selected rendered stills, including the split seam, but did not play or decode the full movie exports. The still-frame checks establish those sampled images and their provenance; they do not prove every frame or full-playback behavior.
