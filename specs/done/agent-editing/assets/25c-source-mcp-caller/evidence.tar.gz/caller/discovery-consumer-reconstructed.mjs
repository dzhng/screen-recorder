import fs from 'node:fs';
import readline from 'node:readline';
import crypto from 'node:crypto';
const input=JSON.parse(fs.readFileSync('/Users/david/.codex/artifacts/screen-recorder/25c-source-mcp-caller/inputs.json','utf8'));
const out=input.outputDirectory;
const {Client}=await import(input.sdk+'/dist/esm/client/index.js');
const {StdioClientTransport}=await import(input.sdk+'/dist/esm/client/stdio.js');
const save=(name,data)=>fs.writeFileSync(out+'/'+name,JSON.stringify(data,null,2));
const log=(direction,message)=>fs.appendFileSync(out+'/envelopes.jsonl',JSON.stringify({time:new Date().toISOString(),direction,message})+'\n');
const transport=new StdioClientTransport({command:input.node,args:[input.cli,'mcp','--socket',input.socketPath]});
const send=transport.send.bind(transport);transport.send=message=>{log('request',message);return send(message)};
const start=transport.start.bind(transport);transport.start=async()=>{const onmessage=transport.onmessage;transport.onmessage=message=>{log('reply',message);return onmessage(message)};return start()};
const client=new Client({name:'independent-source-consumer',version:'1.0.0'});
let childClosed,childOutcome;
let count=0;
async function call(name,args,label){
  save(label+'.request.json',{name,arguments:args});
  const result=await client.callTool({name,arguments:args});save(label+'.reply.json',result);
  console.log(JSON.stringify({label,isError:result.isError,content:result.content?.map(x=>x.type),structuredKeys:Object.keys(result.structuredContent??{})}));
  return result;
}
try {
 await client.connect(transport);
 const child=transport._process;
 childClosed=new Promise(resolve=>child.once('close',(code,signal)=>{childOutcome={pid:child.pid,code,signal,time:new Date().toISOString()};save('child-close.json',childOutcome);resolve()}));
 const listed=await client.listTools();save('tools-list.json',listed);
 console.log(JSON.stringify({toolCount:listed.tools.length}));
 for(const name of ['revision.get','edit.apply','frame.get','asset.get','artifact.read','artifact.renew','artifact.close'])save('schema-'+name+'.json',listed.tools.find(x=>x.name===name));
 await call('revision.get',{projectId:input.projectId,revisionId:input.revisionId},'before-pinned');
 await call('asset.get',{assetId:input.assetId},'source-asset');

 const rl=readline.createInterface({input:process.stdin});
 for await(const line of rl){
  const command=JSON.parse(line);
  if(command.close){rl.close();break}
  try{await call(command.name,command.args,command.label??'call-'+(++count))}catch(e){save((command.label??'call-'+count)+'.error.json',{message:e.message,stack:e.stack});console.log(JSON.stringify({label:command.label,error:e.message}))}
 }

} catch(e){save('consumer-error.json',{message:e.message,stack:e.stack});process.exitCode=1;console.error(e)}
finally{await client.close();if(childClosed)await childClosed;save('consumer-end.json',{exitCode:process.exitCode??0,childOutcome,time:new Date().toISOString()});console.log(JSON.stringify({closed:true,childOutcome}))}
