import fs from 'node:fs';
import readline from 'node:readline';
import crypto from 'node:crypto';
const input=JSON.parse(fs.readFileSync('/Users/david/.codex/artifacts/screen-recorder/25c-source-mcp-caller/inputs.json','utf8'));
const out=input.outputDirectory;
const {Client}=await import(input.sdk+'/dist/esm/client/index.js');
const {StdioClientTransport}=await import(input.sdk+'/dist/esm/client/stdio.js');
const save=(name,data)=>fs.writeFileSync(out+'/'+name,JSON.stringify(data,null,2));
const log=(direction,message)=>fs.appendFileSync(out+'/envelopes.jsonl',JSON.stringify({time:new Date().toISOString(),direction,message})+'\n');
const transport=new StdioClientTransport({command:input.node,args:[input.cli,'mcp','--socket',input.socketPath]});
const send=transport.send.bind(transport);transport.send=message=>{log('request',message);return send(message)};
const start=transport.start.bind(transport);transport.start=async()=>{const onmessage=transport.onmessage;transport.onmessage=message=>{log('reply',message);return onmessage(message)};return start()};
const client=new Client({name:'independent-source-consumer',version:'1.0.0'});
let childClosed,childOutcome;
let count=0;
async function call(name,args,label){
  save(label+'.request.json',{name,arguments:args});
  const result=await client.callTool({name,arguments:args});save(label+'.reply.json',result);
  console.log(JSON.stringify({label,isError:result.isError,content:result.content?.map(x=>x.type),structuredKeys:Object.keys(result.structuredContent??{})}));
  return result;
}
try {
 await client.connect(transport);
 const child=transport._process;
 childClosed=new Promise(resolve=>child.once('close',(code,signal)=>{childOutcome={pid:child.pid,code,signal,time:new Date().toISOString()};save('cleanup-child-close.json',childOutcome);resolve()}));
 await call('artifact.close',{token:"63e02972-95ed-40d3-9499-bf8efb8a551d"},'image-delivery-close');
} catch(e){save('consumer-error.json',{message:e.message,stack:e.stack});process.exitCode=1;console.error(e)}
finally{await client.close();if(childClosed)await childClosed;save('cleanup-consumer-end.json',{exitCode:process.exitCode??0,childOutcome,time:new Date().toISOString()});console.log(JSON.stringify({closed:true,childOutcome}))}
