from pathlib import Path
import base64,hashlib,json,sqlite3,struct
base=Path('/Users/david/.codex/artifacts/screen-recorder/25c-source-mcp-caller'); caller=base/'caller'; root=Path('/Users/david/dev/screen-recorder')
load=lambda p:json.loads(p.read_text())
pin=lambda p:{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
prep=load(base/'preparation.json');inputs=load(base/'inputs.json');f=prep['fixture']
assert prep['passed'] and prep['closureReason']=='requested' and 'error' not in prep
assert pin(base/'prepare.mjs')['sha256']==prep['producer']['sourceSha256']
replies=[]
for p in sorted(caller.glob('*.reply.json')):
 r=load(p);text=[x for x in r['content'] if x['type']=='text'];assert len(text)==1,p
 assert json.loads(text[0]['text'])==r['structuredContent'],p
 replies.append({'path':p.name,'bytes':p.stat().st_size,'ok':r['structuredContent']['ok']})
data=lambda name:load(caller/(name+'.reply.json'))['structuredContent']['data']
before=data('before-pinned')['revision'];prior=data('prior-after')['revision'];split=data('split');after=data('after-pinned')['revision']
assert before==prior==f['placed']['revision']
assert split['revision']==after==data('after-current')['revision']==data('after-stale-current')['revision']
assert after['ordinal']==before['ordinal']+1==2
assert after['projectId']==before['projectId']==inputs['projectId']
old=before['document'];new=after['document']
assert {k:v for k,v in old.items() if k!='clips'}=={k:v for k,v in new.items() if k!='clips'}
assert len(old['clips'])==1 and len(new['clips'])==2
clips=sorted(new['clips'],key=lambda c:c['placement']['range']['startUs'])
assert [c['placement'] for c in clips]==[{'kind':'project','range':{'startUs':0,'endUs':500000}},{'kind':'project','range':{'startUs':500000,'endUs':1000000}}]
expected={k:v for k,v in old['clips'][0].items() if k not in ['id','placement']}
for c in clips:assert {k:v for k,v in c.items() if k not in ['id','placement']}==expected
assert clips[0]['id']==old['clips'][0]['id'] and clips[1]['id']!=clips[0]['id']
assert data('replay')==split
request=load(caller/'split.request.json');assert load(caller/'replay.request.json')==request
staleRequest=load(caller/'stale-different-mutation.request.json');a=request['arguments'];b=staleRequest['arguments']
assert a['requestId']!=b['requestId'] and {k:v for k,v in a.items() if k!='requestId'}=={k:v for k,v in b.items() if k!='requestId'}
stale=load(caller/'stale-different-mutation.reply.json');assert stale['isError'] and not stale['structuredContent']['ok']
assert stale['structuredContent']['error']['code']=='STALE_REVISION' and stale['structuredContent']['error']['details']['currentRevisionId']==after['id']
asset=data('source-asset');assert asset==f['asset']
image=load(caller/'raw-image.reply.json');pictures=[c for c in image['content'] if c['type']=='image'];assert len(pictures)==1 and pictures[0]['mimeType']=='image/png'
bytes=base64.b64decode(pictures[0]['data'],validate=True);assert bytes==(caller/'raw-source-0.png').read_bytes()==(base/'prepared-source.png').read_bytes()==(root/'specs/agent-editing/assets/10d-still-image-native/png-1.png').read_bytes()
assert len(bytes)==329 and bytes[:8]==b'\x89PNG\r\n\x1a\n';assert struct.unpack('>II',bytes[16:24])==(64,40)
actual=image['structuredContent']['data'];assert actual['state']=='ready' and actual['published']==f['ready']['published']
assert actual['delivery']['bytes']==len(bytes) and actual['published']['frame']['bytes']==len(bytes)
assert data('image-delivery-close')=={'closed':True}
assert load(caller/'image-delivery-close.request.json')['arguments']['token']==actual['delivery']['token']
envelopes=[json.loads(line) for line in (caller/'envelopes.jsonl').read_text().splitlines()]
pending={};pairs=[]
for e in envelopes:
 m=e['message']
 if e['direction']=='request' and 'id' in m:
  assert m['id'] not in pending;pending[m['id']]=m
 elif e['direction']=='reply' and 'id' in m:
  q=pending.pop(m['id']);pairs.append((q,m))
assert not pending
listReplies=[m['result'] for q,m in pairs if q['method']=='tools/list'];assert len(listReplies)==2
assert all(r==load(caller/'tools-list.json') for r in listReplies)
for p in caller.glob('*.request.json'):
 req=load(p);rep=load(p.with_name(p.name.replace('.request.json','.reply.json')))
 matches=[m['result'] for q,m in pairs if q['method']=='tools/call' and q['params']==req]
 assert matches and rep in matches,p
assert len(load(caller/'tools-list.json')['tools'])==83
conn=sqlite3.connect('file:'+str(base/'home/library/catalog.sqlite')+'?mode=ro',uri=True)
rows=list(conn.execute('SELECT id,ordinal,content FROM project_revisions WHERE projectId=? ORDER BY ordinal',(inputs['projectId'],)))
assert len(rows)==3 and [r[1] for r in rows]==[0,1,2]
assert json.loads(rows[1][2])==before and json.loads(rows[2][2])==after
assert conn.execute('SELECT currentRevisionId FROM projects WHERE projectId=?',(inputs['projectId'],)).fetchone()[0]==after['id']
requests=list(conn.execute('SELECT requestId,arguments,result FROM project_requests WHERE projectId=?',(inputs['projectId'],)))
assert len(requests)==2 and a['requestId'] in {r[0] for r in requests} and b['requestId'] not in {r[0] for r in requests}
conn.close()
events=[json.loads(line) for line in (base/'processes.jsonl').read_text().splitlines()]
children=[e for e in events if e['event']=='spawn'];assert len(children)==5
for child in children:
 assert any(e['event']=='node-exit' and e['pid']==child['pid'] and e['code']==0 for e in events)
 assert any(e['event']=='close' and e['pid']==child['pid'] and e['code']==0 and e['signal'] is None for e in events)
for pid in [33556,37584,37924,39061]:assert any(e['event']=='node-exit' and e['pid']==pid and e['code']==0 for e in events)
assert [e['kind'] for e in children].count('source')==1
assert [o['operation'] for o in prep['nativeOperations']].count('media.sourceImage')==1
assert all(o['operation'] in ['storage.clearRenderWorkspace','media.audioCapabilities','media.sourceImage'] for o in prep['nativeOperations'])
assert pin(Path(f['source']['path']))['sha256']==f['source']['sha256']
assert pin(Path('/private/tmp/screenrec-09c-native-presented-worker'))['sha256']=='0a9cd72a62af990a2bccef585184df0a2bbc36220a2fc258e0198ee43d726928'
record={'scope':'Independent saved-data verification; no service/query/render/inference replay','passed':True,'replies':replies,'envelopeCount':len(envelopes),'pairedRequests':len(pairs),'toolsCount':83,'revisions':{'before':before['id'],'after':after['id'],'ordinals':[0,1,2],'persistedRequests':len(requests)},'completeProtectedDocument':True,'replaySameData':True,'truthfulStaleNoMutation':True,'image':pin(caller/'raw-source-0.png'),'equalPreparedAndAcceptedPNG':True,'cachedImageGeneration':actual['published']['generation'],'processEvents':events,'prepareProducer':pin(base/'prepare.mjs'),'rootPreparationExec':{'session':32204,'exit':0},'callerSessions':[{'session':57171,'exit':0},{'session':4369,'exit':0},{'session':58290,'exit':0}],'limits':['Discovery-only consumer source was overwritten; labeled reconstruction is not original execution identity. Complete original envelopes survive.','Preparation initial native allowlist mistake prevented image dispatch; explicit retry reused the same failed job. Initial process exit1 and source/MCP close0 are retained.','SDK fixture path corrected without installation or setting change.','Explicit socket and tiny empty-processing hold fixture; no installed/default discovery, listening/physical/complex-project/full-release claim.']}
(base/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'passed':True,'envelopes':len(envelopes),'pairs':len(pairs),'replies':len(replies),'revisionRows':len(rows),'children':len(children),'imageBytes':len(bytes)}))
