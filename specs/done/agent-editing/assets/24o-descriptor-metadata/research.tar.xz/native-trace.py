import pathlib,json,subprocess,os
r=json.loads(pathlib.Path('/tmp/screenrec-24o-native-green/report.json').read_text());p=next(c['request'] for c in r['cases'] if c['label']=='late-descriptor');p['output']='/tmp/screenrec-24o/native-trace.wav'
source='/tmp/screenrec-24o-native-green/source.wav';fd=os.open(source,os.O_RDONLY);st=os.fstat(fd)
r=subprocess.run([str(pathlib.Path('helpers/mac/.build/release/screenrec-native').resolve())],input=json.dumps({'id':'trace','operation':'media.mixCompositionAudio','params':p})+'\n',text=True,capture_output=True,pass_fds=(fd,),env={**os.environ,'SOURCE_DEV':str(st.st_dev),'SOURCE_INO':str(st.st_ino),'DYLD_INSERT_LIBRARIES':'/tmp/screenrec-24o/io.dylib'},timeout=20)
os.close(fd);pathlib.Path('/tmp/screenrec-24o/native-trace.json').write_text(r.stdout);pathlib.Path('/tmp/screenrec-24o/native-trace.log').write_text(r.stderr);print(r.stdout);print(r.stderr)
