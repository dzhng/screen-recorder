import subprocess,pathlib,os,json,hashlib
root=pathlib.Path('/tmp/screenrec-24o');results=[]
fixtures=[('wav','/tmp/screenrec-24n-verified/source.wav',59*48000),('aac','/tmp/screenrec-24n-verified/retained-marker.m4a',2999*48000),('caf','/tmp/screenrec-composition-segment-fixtures/long.caf',59*48000),('mov','/tmp/screenrec-project-preview/specs/agent-editing/assets/00-corpus/a.mov',48000),('mp3','/tmp/screenrec-audio-rates-verified/mp3-encoded.mp3',48000),('aiff',str(root/'source.aiff'),48000),('flac','/tmp/screenrec-clean-speech-preparation/1272-128104-0000.flac',48000)]
for name,path,start in fixtures:
 for enabled in ['false','true']:
  label=name+'-available-'+enabled;out=root/(label+'.f32')
  r=subprocess.run([str(root/'probe'),path,'loader',str(start),str(out)],env={**os.environ,'ON_DEMAND':enabled,'DYLD_INSERT_LIBRARIES':str(root/'io.dylib')},capture_output=True,timeout=20)
  (root/(label+'.json')).write_bytes(r.stdout);(root/(label+'.log')).write_bytes(r.stderr)
  entry={'name':label,'exitCode':r.returncode,'stdout':r.stdout.decode(),'sourceSHA256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None}
  results.append(entry);print(json.dumps(entry),flush=True)
(root/'ondemand.json').write_text(json.dumps(results,indent=2))
