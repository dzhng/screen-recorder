#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
static int match(int fd) {struct stat s; const char *dev=getenv("SOURCE_DEV"),*ino=getenv("SOURCE_INO");return dev&&ino&&fstat(fd,&s)==0&&(unsigned long long)s.st_dev==strtoull(dev,0,10)&&(unsigned long long)s.st_ino==strtoull(ino,0,10);}
static ssize_t observe_pread(int fd,void*data,size_t count,off_t at){ssize_t n=pread(fd,data,count,at);if(match(fd))fprintf(stderr,"IO pread fd=%d at=%lld requested=%zu actual=%zd\n",fd,(long long)at,count,n);return n;}
static ssize_t observe_read(int fd,void*data,size_t count){off_t at=lseek(fd,0,SEEK_CUR);ssize_t n=read(fd,data,count);if(match(fd))fprintf(stderr,"IO read fd=%d at=%lld requested=%zu actual=%zd\n",fd,(long long)at,count,n);return n;}
static void* observe_mmap(void*a,size_t count,int prot,int flags,int fd,off_t at){void*r=mmap(a,count,prot,flags,fd,at);if(match(fd))fprintf(stderr,"IO mmap fd=%d at=%lld length=%zu success=%d\n",fd,(long long)at,count,r!=MAP_FAILED);return r;}
__attribute__((used)) static struct{const void*replacement;const void*original;} mappings[] __attribute__((section("__DATA,__interpose")))={{observe_pread,pread},{observe_read,read},{observe_mmap,mmap}};
