@preconcurrency import AVFoundation
import Foundation
import Darwin
public struct NativeFailure: Error { let code: String; let message: String; init(_ code:String,_ message:String){self.code=code;self.message=message}; static func decodeFailed(_ message:String)->NativeFailure{.init("DECODE_FAILED",message)} }
@main struct Experiment {
 static func main() async {
  do { try await run() } catch { print("ERROR \(error)"); exit(1) }
 }
 static func run() async throws {
  let args=CommandLine.arguments
  let source=args[1], mode=args[2], start=Int64(args[3])!, output=args[4]
  let path=output+".link"
  guard link(source,path)==0 else { fatalError("link") }
  let original=open(path,O_RDONLY)
  guard original>=0 else {fatalError("open")}
  defer {close(original)}
  let descriptor=try MediaDescriptor(url:URL(fileURLWithPath:"/dev/fd/\(original)"),writable:false)!
  guard unlink(path)==0 else {fatalError("unlink")}
  var info=stat();fstat(original,&info)
  setenv("SOURCE_DEV",String(info.st_dev),1);setenv("SOURCE_INO",String(info.st_ino),1)
  lseek(original,123,SEEK_SET)
  let input: MediaInput?
  let asset: AVURLAsset
  let precise=ProcessInfo.processInfo.environment["PRECISE"] != "false"
  if mode.hasPrefix("direct") {
   input=nil
   var options: [String:Any] = [AVURLAssetPreferPreciseDurationAndTimingKey:precise]
   if mode=="direct-mime" { options[AVURLAssetOverrideMIMETypeKey] = ProcessInfo.processInfo.environment["MIME"] ?? (source.hasSuffix("m4a") ? "audio/mp4" : "audio/wav") }
   asset=AVURLAsset(url:descriptor.url,options:options)
  } else {
   input=try MediaInput(url:descriptor.url)
   asset=input!.asset
  }
  FileHandle.standardError.write(Data("metadata begin\n".utf8))
  let tracks=try await asset.loadTracks(withMediaType:.audio)
  guard let track=tracks.first else {fatalError("no audio")}
  let duration=try await asset.load(.duration)
  let range=try await track.load(.timeRange)
  let segments=try await track.load(.segments)
  let descriptions=try await track.load(.formatDescriptions)
  let format=CMAudioFormatDescriptionGetStreamBasicDescription(descriptions[0])!.pointee
  FileHandle.standardError.write(Data("metadata end; decoder begin\n".utf8))
  let reader=try AVAssetReader(asset:asset)
  let sink=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVLinearPCMIsFloatKey:true,AVLinearPCMBitDepthKey:32,AVLinearPCMIsNonInterleaved:false])
  reader.add(sink);reader.timeRange=CMTimeRange(start:CMTime(value:start,timescale:48000),duration:CMTime(value:960,timescale:48000))
  guard reader.startReading() else {throw reader.error!}
  var result=Data(),frames=0
  while let sample=sink.copyNextSampleBuffer(){
   frames+=CMSampleBufferGetNumSamples(sample)
   if let block=CMSampleBufferGetDataBuffer(sample){
    let count=CMBlockBufferGetDataLength(block);var bytes=Data(count:count)
    let status=bytes.withUnsafeMutableBytes{CMBlockBufferCopyDataBytes(block,atOffset:0,dataLength:count,destination:$0.baseAddress!)}
    guard status==0 else {fatalError("copy")};result.append(bytes)
   }
  }
  if let error=reader.error{throw error}
  try result.write(to:URL(fileURLWithPath:output))
  let resultInfo:[String:Any]=["mode":mode,"preciseRequested":precise,"precise":try await asset.load(.providesPreciseDurationAndTiming),"duration":[duration.value,Int64(duration.timescale)],"trackRange":[range.start.value,Int64(range.start.timescale),range.duration.value,Int64(range.duration.timescale)],"segments":segments.map{["empty":$0.isEmpty,"start":$0.timeMapping.target.start.seconds,"duration":$0.timeMapping.target.duration.seconds]},"sampleRate":format.mSampleRate,"channels":format.mChannelsPerFrame,"decodedFrames":frames,"bytes":result.count,"originalOffset":lseek(original,0,SEEK_CUR),"ownedOffset":lseek(descriptor.descriptor,0,SEEK_CUR),"descriptorRead":input?.readWork?.readBytes ?? -1,"descriptorDelivered":input?.readWork?.deliveredBytes ?? -1]
  print(String(data:try JSONSerialization.data(withJSONObject:resultInfo,options:[.sortedKeys]),encoding:.utf8)!)
  withExtendedLifetime(descriptor){}
 }
}
