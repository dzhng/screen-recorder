import os,subprocess,json,pathlib,hashlib
root=pathlib.Path('/tmp/screenrec-24o')
results=[]
for label,path,start in [('wav','/tmp/screenrec-24n-verified/source.wav',59*48000),('aac','/tmp/screenrec-24n-verified/retained-marker.m4a',2999*48000)]:
 for mode in ['loader','direct']:
  for precise in ['true','false']:
   name=f'{label}-{mode}-{precise}';out=root/(name+'.f32')
   try:
    r=subprocess.run([str(root/'probe'),path,mode,str(start),str(out)],env={**os.environ,'PRECISE':precise},capture_output=True,timeout=20)
    (root/(name+'.log')).write_bytes(r.stderr);(root/(name+'.json')).write_bytes(r.stdout)
    entry={'name':name,'exitCode':r.returncode,'stdout':r.stdout.decode(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None}
   except subprocess.TimeoutExpired:
    entry={'name':name,'timeout':True}
   results.append(entry);print(json.dumps(entry),flush=True)
(root/'results.json').write_text(json.dumps(results,indent=2))
