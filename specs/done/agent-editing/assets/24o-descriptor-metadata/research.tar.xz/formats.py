import subprocess,pathlib,os,json,hashlib
root=pathlib.Path('/tmp/screenrec-24o');results=[]
fixtures=[('wav','/tmp/screenrec-24n-verified/source.wav','audio/wav',59*48000),('aac','/tmp/screenrec-24n-verified/retained-marker.m4a','video/quicktime',2999*48000),('caf','/tmp/screenrec-composition-segment-fixtures/long.caf','audio/x-caf',59*48000),('mov','/tmp/screenrec-project-preview/specs/agent-editing/assets/00-corpus/a.mov','video/quicktime',48000),('mp3','/tmp/screenrec-audio-rates-verified/mp3-encoded.mp3','video/quicktime',48000),('mp3mime','/tmp/screenrec-audio-rates-verified/mp3-encoded.mp3','audio/mpeg',48000)]
for name,path,mime,start in fixtures:
 for mode in ['loader','direct-mime']:
  label=name+'-'+mode+'-hint';out=root/(label+'.f32')
  r=subprocess.run([str(root/'probe'),path,mode,str(start),str(out)],env={**os.environ,'MIME':mime,'DYLD_INSERT_LIBRARIES':str(root/'io.dylib')},capture_output=True,timeout=20)
  (root/(label+'.json')).write_bytes(r.stdout);(root/(label+'.log')).write_bytes(r.stderr)
  entry={'name':label,'exitCode':r.returncode,'stdout':r.stdout.decode(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None}
  results.append(entry);print(json.dumps(entry),flush=True)
(root/'formats.json').write_text(json.dumps(results,indent=2))
