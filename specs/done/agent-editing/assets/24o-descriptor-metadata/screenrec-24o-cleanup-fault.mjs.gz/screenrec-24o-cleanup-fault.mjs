import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
const write = fs.writeSync;
fs.writeSync = function(fd, ...args) {
  if (fs.fstatSync(fd).size > 2700000000) throw Object.assign(new Error('Injected sparse initialization ENOSPC'), {code:'ENOSPC'});
  return write(fd, ...args);
};
syncBuiltinESMExports();
