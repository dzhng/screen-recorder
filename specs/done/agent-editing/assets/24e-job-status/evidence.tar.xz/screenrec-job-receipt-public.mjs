import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {JourneyService} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const failure=JSON.parse(await readFile('/tmp/screenrec-denoise-two-hour-final/report.json','utf8'));
const db=new DatabaseSync(join(failure.failureHome,'library/catalog.sqlite'),{readOnly:true});
const row=db.prepare("SELECT * FROM jobs WHERE artifact='prepared-audio'").get();db.close();
const hashAt=performance.now(),inputSha256=createHash('sha256').update(row.input).digest('hex'),hashMs=performance.now()-hashAt;
const report={passed:false,home:failure.failureHome,trace:[],inputBytes:Buffer.byteLength(row.input),hashMs,inputSha256,measurements:[],receipts:[]};
const service=new JourneyService(report.home,report);
const check=v=>{assert(!('input' in v));assert.equal(v.inputSha256,inputSha256);assert.equal(v.jobId,row.jobId);return v;};
try {
 await service.start();
 for(const transport of ['cli','mcp','cli','mcp','cli','mcp']) {
  const at=performance.now(),v=check(await service.call('job.get',{jobId:row.jobId},{transport}));
  report.measurements.push({transport,elapsedMs:performance.now()-at,bytes:Buffer.byteLength(JSON.stringify(v))});
  assert.equal(v.state,'failed');
 }
 const tools=await service.mcp.listTools();
 for(const name of ['job.get','job.retry','job.cancel'])assert(tools.tools.find(t=>t.name===name).description.includes('inputSha256'));
 const retry=check(await service.call('job.retry',{jobId:row.jobId},{transport:'mcp'}));report.receipts.push(retry);assert.notEqual(retry.attemptId,row.attemptId);
 const canceled=check(await service.call('job.cancel',{jobId:row.jobId}));report.receipts.push(canceled);assert.equal(canceled.state,'canceled');
 assert.deepEqual(check(await service.call('job.get',{jobId:row.jobId},{transport:'mcp'})),canceled);
 await service.stop();await service.start();
 assert.deepEqual(check(await service.call('job.get',{jobId:row.jobId})),canceled);
 report.passed=true;
}finally{await service.stop();await writeFile('/tmp/screenrec-job-receipt-public.json',JSON.stringify(report,null,2));}
console.log(report);
