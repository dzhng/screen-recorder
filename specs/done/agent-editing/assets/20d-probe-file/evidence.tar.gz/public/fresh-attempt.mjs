import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,root} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const report={trace:[],passed:false};
const service=new JourneyService('/tmp/probe-consumer-red/home',report,'/tmp/probe-file-public-next.reads.jsonl',new URL(`file://${root}/packages/test-harness/editing/capture-evidence-service.mjs`));
try{
 await service.start();
 report.replay=await service.call('acquisition.import',{requestId:'original-bulk-metadata-refusal',path:'/tmp/probe-consumer-red/source'});
 assert.equal(report.replay.jobId,'b2d4f5cf-d51c-4875-9798-a0929a89fbc6');
 report.submitted=await service.call('acquisition.import',{requestId:'probe-file-fresh-attempt',path:'/tmp/probe-consumer-red/source'});
 assert.notEqual(report.submitted.jobId,report.replay.jobId);
 const started=performance.now();
 while(performance.now()-started<180000){
 const job=await service.call('job.get',{jobId:report.submitted.jobId},{transport:'mcp'});
 if(['ready','failed','canceled'].includes(job.state)){report.terminal=job;break;}
 await delay(500);
 }
 report.seconds=(performance.now()-started)/1000;
 assert.equal(report.terminal.state,'failed');
 assert.doesNotMatch(report.terminal.reason,/JSON frame exceeds/);
 report.passed=true;
}finally{await service.stop();await writeFile('/tmp/probe-file-public-next.json',JSON.stringify(report,null,2));}
