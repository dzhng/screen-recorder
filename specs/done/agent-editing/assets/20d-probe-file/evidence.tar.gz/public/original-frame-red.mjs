import assert from 'node:assert/strict';
import {mkdir,cp,copyFile,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,root} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/probe-consumer-red';
await cp('/tmp/source-admission-scale/source',`${out}/source`,{recursive:true});
await copyFile(`${root}/specs/agent-editing/assets/00-corpus/video-only.mov`,`${out}/source/video.mov`);
const report={trace:[],passed:false};
const service=new JourneyService(`${out}/home`,report,`${out}/reads.jsonl`,new URL(`file://${root}/packages/test-harness/editing/capture-evidence-service.mjs`));
const save=()=>writeFile(`${out}/report.json`,JSON.stringify(report,null,2));
try {
 await service.start();const started=performance.now();
 const request={requestId:'original-bulk-metadata-refusal',path:`${out}/source`};report.request=request;
 report.submitted=await service.call('acquisition.import',request);
 while(performance.now()-started<180000){
  const job=await service.call('job.get',{jobId:report.submitted.jobId},{transport:'mcp'});
  if(['ready','failed','canceled'].includes(job.state)){report.terminal=job;break;}
  await delay(500);
 }
 report.seconds=(performance.now()-started)/1000;
 report.replay=await service.call('acquisition.import',request);
 report.assets=await service.call('asset.list',{});
 await save();assert.equal(report.terminal.state,'failed');assert.match(report.terminal.reason,/JSON frame exceeds/);
 assert.equal(report.replay.jobId,report.submitted.jobId);
 report.passed=true;
}finally{await service.stop();await save();}
