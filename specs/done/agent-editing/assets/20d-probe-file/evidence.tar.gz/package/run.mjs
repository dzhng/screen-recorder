import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,root} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/private/tmp/probe-package-boundary';const report={trace:[],passed:false};
const service=new JourneyService(`${out}/home`,report,`${out}/reads.jsonl`,new URL(`file://${root}/packages/test-harness/editing/capture-evidence-service.mjs`));
try {await service.start();report.submitted=await service.call('package.open',{path:`${out}/bulk-metadata.zip`});
 const started=performance.now();while(performance.now()-started<30000){const s=await service.call('package.status',{admissionId:report.submitted.id});if(['ready','failed'].includes(s.state)){report.terminal=s;break;}await delay(50);}
 assert.equal(report.terminal.state,'failed');assert.equal(report.terminal.packageHandle,null);report.passed=true;
}finally{await service.stop();await writeFile(`${out}/report.json`,JSON.stringify(report,null,2));}
