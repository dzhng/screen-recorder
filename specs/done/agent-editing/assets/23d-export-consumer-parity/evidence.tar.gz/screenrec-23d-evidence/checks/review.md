# Review

Shape: received ownership lives in the existing Record and is shared by controller
and menu. Outbound recording choices/requests stay scoped to the existing real
consumer; there is no optional-ID compatibility facade or project authoring path.
Unreadable or lost replies use one existing unanswered-request classification.
Read uncertainty and definite action refusals stay in the same existing view
state owner with distinct clearing and observation rules. The service retains all
lifecycle/publication/retry/cleanup ownership.

Diff: strict owner decoding, response export identity, literal received status
fields, recording-only retirement and caller-selected recording export behavior
are covered through real consumer code. Root review found two successive recovery
gaps: a stopped receipt did not resume observation after unreadable accepted retry,
and a malformed-only repair missed timeout/service-loss variants. Both findings
were reproduced red and corrected at the existing shared classification. The
final parameterized controller check covers all four ambiguity classes; each
resolves by status without another mutation. Definite refusal does not create
perpetual observation. Discovery retains its first failure while later items and
pages make progress. No remaining actionable issue was found in the local pass.

Tests: original recording controller regression retained; one coherent retained
receipt/controller test added; the complete pure-controls executable passes.
The service/media test was deliberately outside the selected direct-controls
scope. No screenshot aesthetics or installed behavior acceptance is claimed.

Docs: child contract, parent 23 scope, evidence boundary and three load-bearing
choices are current. Root README/pickup remains owned by the parent orchestrator.
Known unavailable configured CLI review was not retried. All owned compilation
and test processes exited; unique scratch build directories were removed.
