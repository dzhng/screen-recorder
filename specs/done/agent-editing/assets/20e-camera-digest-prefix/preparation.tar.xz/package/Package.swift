// swift-tools-version: 6.1
import PackageDescription
let package = Package(name: "CameraDigestDiagnostic", platforms: [.macOS("26.0")], targets: [
 .target(name: "ScreenRecorderMedia"),
 .target(name: "ScreenRecorderCapture", dependencies: ["ScreenRecorderMedia"]),
 .executableTarget(name: "CameraDigestDiagnostic", dependencies: ["ScreenRecorderCapture"])
])
