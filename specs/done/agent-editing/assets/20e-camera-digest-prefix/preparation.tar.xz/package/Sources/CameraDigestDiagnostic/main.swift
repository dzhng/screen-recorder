import Foundation
import ScreenRecorderCapture
let args = CommandLine.arguments
 guard args.count == 4 else { fatalError("usage: CameraDigestDiagnostic RAW OBSERVATIONS RESULT") }
let result = try await ProbeCameraMedia.diagnose128(rawURL: URL(fileURLWithPath: args[1]),
    observationURL: URL(fileURLWithPath: args[2]))
try result.write(to: URL(fileURLWithPath: args[3]), options: .withoutOverwriting)
print("PASS exactly128 occupied raw camera pictures; diagnostic result saved")
