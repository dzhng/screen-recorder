import pathlib,json,subprocess,os,time,hashlib
root=pathlib.Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder')
out=pathlib.Path('/tmp/screenrec-19d-controls');out.mkdir(exist_ok=False)
cases=json.loads((root/'packages/test-harness/editing/voice/cases.json').read_text())
reference=root/'specs/agent-editing/assets/18-voice/reference.wav'
sentence='Okay, so this is the recorder workbench.'
trials=[('seed',sentence,{'seed':19}),('seed-replay',sentence,{'seed':19}),('greedy',sentence,{'temperature':0}),('top-k-disabled',sentence,{'top_k':0}),('top-k-one',sentence,{'top_k':1}),('top-p',sentence,{'top_p':0.8}),('penalty',sentence,{'repetition_penalty':1.8}),('language-auto',sentence,{'lang_code':'auto'})]
env=dict(os.environ,HF_HOME=str(out/'cache'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1')
summary=[]
for name,text,change in trials:
 request={'reference':str(reference),'referenceText':cases['reference']['text'],'text':text,'generation':dict(cases['generation'],**{k:v for k,v in change.items() if k!='seed'}),'seed':change.get('seed',cases['seed'])}
 (out/(name+'.request.json')).write_text(json.dumps(request,indent=2)+'\n')
 cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/private/tmp/screenrec-19b-relocation/bundle/python/bin/python3.12','-I','-B',str(root/'packages/test-harness/editing/voice/settings.py'),'--bundle','/private/tmp/screenrec-19b-relocation/bundle','--model','/tmp/screenrec-voice-model','--request',str(out/(name+'.request.json')),'--output',str(out/(name+'.wav')),'--report',str(out/(name+'.json'))]
 started=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 row={'name':name,'command':cmd,'exitCode':result.returncode,'wallSeconds':time.monotonic()-started};summary.append(row)
 (out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(row,flush=True)
 if result.returncode: break
 if name.startswith('frozen-'):
  oracle=root/('specs/agent-editing/assets/18-voice/same-take-'+name.removeprefix('frozen-')+'.wav')
  row['exactFrozenWav']=oracle.read_bytes()==(out/(name+'.wav')).read_bytes()
  assert row['exactFrozenWav'],row
 if name=='seed-replay':
  row['exactFrozenWav']=(out/'seed.wav').read_bytes()==(out/(name+'.wav')).read_bytes()
  assert row['exactFrozenWav'],row
 (out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n')
