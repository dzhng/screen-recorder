import json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder')
out=pathlib.Path('/tmp/screenrec-19d-corner');model='/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519';limit=12*1024**3
old=json.loads((root/'specs/agent-editing/assets/19d-voice-envelope/report.json').read_text())
prior=next(row for row in old['trials'] if row['id']=='output-512')
projection=prior['output']['mlxPeakBytes']*(250+512)/(63+512)
assert projection<limit
receipt={'passed':False,'targetBytes':limit,'expectedReferenceFrames':480000,'expectedTargetTokens':1024,'expectedReferenceCodes':250,'expectedPrefillPositions':1325,'requestedOutputBudget':512,'projectedMlxPeakBytes':projection,'projectionScope':'Whole prior MLX peak scaled by combined reference+output codes; heuristic, not guaranteed bound','model':model,'hostConcurrency':'19c inference completed; root24j package I/O may run independently; no RTF acceptance','samples':[]}
receipt['diskAtStart']=dict(zip(('total','used','free'),shutil.disk_usage(out)))
assert receipt['diskAtStart']['free']>=512*1024**2
receipt['startUtc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
receipt['processSnapshot']=subprocess.run(['ps','-axo','pid,comm,%cpu,rss'],capture_output=True,text=True).stdout
cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/private/tmp/screenrec-19b-relocation/bundle/python/bin/python3.12','-I','-B',str(root/'packages/test-harness/editing/voice/settings.py'),'--bundle','/private/tmp/screenrec-19b-relocation/bundle','--model',model,'--request',str(out/'combined-512.request.json'),'--output',str(out/'combined-512.wav'),'--report',str(out/'combined-512.json'),'--envelope'];receipt['command']=cmd
start=time.monotonic()
try:
 with (out/'worker.log').open('x') as log:
  process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,HF_HOME=str(out/'cache'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1'))
  try:
   while process.poll() is None:
    sample=subprocess.run(['ps','-o','rss=','-p',str(process.pid)],capture_output=True,text=True)
    if sample.stdout.strip():
     rss=int(sample.stdout.strip())*1024;receipt['samples'].append({'seconds':time.monotonic()-start,'residentBytes':rss})
     if rss>limit:receipt['stopped']='resident target';process.kill();break
    if time.monotonic()-start>600:receipt['stopped']='existing deadline';process.kill();break
    time.sleep(.25)
  finally:
   if process.poll() is None:process.kill()
   receipt['exitCode']=process.wait()
 assert receipt['exitCode']==0
 result=json.loads((out/'combined-512.json').read_text());receipt['result']=result
 assert result['passed']
 assert result['prefill']=={'referenceFrames':480000,'referenceCodes':250,'referenceTextTokens':40,'targetTextTokens':1024,'inputTokens':1325,'language':'english'}
 count=sum(result['output']['resultTokens']);assert count<=512 and result['termination']['reason']==('eos' if count<512 else 'token-budget')
 assert result['peakResidentBytes']<=limit and result['output']['mlxPeakBytes']<=limit
 receipt['passed']=True
except Exception as error:
 receipt['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 receipt['wallSeconds']=time.monotonic()-start;receipt['diskAtEnd']=dict(zip(('total','used','free'),shutil.disk_usage(out)))
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ('passed','wallSeconds','diskAtStart','projectedMlxPeakBytes')}))
