import datetime,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder')
base=pathlib.Path('/Users/david/.cache/screen-recorder/verification/parakeet-23n-lifecycle-correction')
owner=root/'packages/test-harness/editing/parakeet-readiness-processes.mjs'
checker=root/'packages/test-harness/editing/parakeet-readiness.mjs'
test=root/'packages/test-harness/editing/parakeet-readiness-processes.test.mjs'
node='/Users/david/.local/share/mise/installs/node/24.14.0/bin/node'
if not pathlib.Path(node).is_file():
    node=subprocess.check_output(['which','node'],text=True).strip()
commands=[]
def run(label,args,expected,environment=None):
    env=os.environ.copy()
    if environment:env.update(environment)
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    child=subprocess.Popen(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stdout,stderr=child.communicate()
    record={'label':label,'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(root),'executable':args[0],'args':args[1:],'environmentOverrides':environment or {},'pid':child.pid,'terminal':{'code':child.returncode,'signal':None},'stdout':stdout.decode(),'stderr':stderr.decode()}
    commands.append(record)
    (base/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert child.returncode==expected,record
    return record
current=owner.read_bytes()
(base/'final-owner.mjs').write_bytes(current)
(base/'final-checker.mjs').write_bytes(checker.read_bytes())
(base/'final-tests.mjs').write_bytes(test.read_bytes())
(base/'original-checker.mjs').write_bytes(subprocess.check_output(['git','show','2f0690dc:packages/test-harness/editing/parakeet-readiness.mjs'],cwd=root))
try:
    owner.write_bytes((base/'red/owner.mjs').read_bytes())
    run('baseline-red',[node,'--test','--test-name-pattern=source exit before ready|failed control and nonzero exit',str(test)],1,{'SCREENREC_READINESS_CONTROLS_OUT':str(base/'baseline-red')})
finally:
    owner.write_bytes(current)
assert owner.read_bytes()==current
run('final-green',[node,'--test',str(test)],0,{'SCREENREC_READINESS_CONTROLS_OUT':str(base/'final-green')})
for path in [checker,owner,test]:run('syntax-'+path.stem,[node,'--check',str(path)],0)
run('lint',[str(root/'node_modules/.bin/oxlint'),str(checker),str(owner),str(test)],0)
run('format',[str(root/'node_modules/.bin/oxfmt'),'--check',str(checker),str(owner),str(test)],0)
run('diff-check',['git','diff','--check'],0)
(base/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps([{'label':r['label'],'terminal':r['terminal']} for r in commands]))
