import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { join } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { JsonLineStream, CONTROL_FRAME_BYTES } from "../../protocol/dist/index.js";

export async function withReadinessProcesses(
  { report, env, serviceObserver, runtime, observer, cliLog, childLog },
  verify,
  save,
) {
let service, client, transport, mcpClosed;
async function start() {
  const child = spawn(process.execPath, [serviceObserver], {
    env: {
      ...env,
      SCREENREC_READINESS_SERVICE: join(runtime, "service.mjs"),
      SCREENREC_READINESS_CHILD_LOG: childLog,
    },
    stdio: ["pipe", "pipe", "pipe"],
  });
  const record = { label: "source service", pid: child.pid, control: [], stderr: "", exit: null };
  report.processes.push(record);
  const terminal = new Promise((resolveExit) =>
    child.once("close", (code, signal) => {
      record.exit = { code, signal };
      resolveExit(record.exit);
    }),
  );
  const stream = new JsonLineStream(CONTROL_FRAME_BYTES);
  let resolveReady, rejectReady;
  const ready = new Promise((resolveValue, reject) => {
    resolveReady = resolveValue;
    rejectReady = reject;
  });
  child.once("error", rejectReady);
  child.stderr.on("data", (bytes) => (record.stderr += bytes));
  child.stdout.on("data", (bytes) => {
    for (const frame of stream.push(bytes)) {
      assert(frame.ok);
      record.control.push(frame.value);
      if (frame.value.event === "started") resolveReady(frame.value);
      if (frame.value.event === "failed") rejectReady(new Error(JSON.stringify(frame.value)));
    }
  });
  service = { child, terminal, record };
  const started = await ready;
  transport = new StdioClientTransport({
    command: process.execPath,
    args: [observer, "mcp", "--socket", started.socketPath],
    env: {
      ...env,
      SCREENREC_READINESS_CLI: join(runtime, "cli.mjs"),
      SCREENREC_READINESS_CLI_LOG: cliLog,
    },
    stderr: "pipe",
  });
  client = new Client({ name: "parakeet-readiness", version: "1" });
  await client.connect(transport);
  const pid = transport.pid;
  mcpClosed = new Promise((resolveClose) => {
    const previous = transport.onclose;
    transport.onclose = () => {
      previous?.();
      resolveClose(pid);
    };
  });
  return started.socketPath;
}
async function stop() {
  if (client) {
    await client.close();
    const pid = await mcpClosed;
    report.processes.push({ label: "default SDK child close", pid, closeObserved: true });
    client = undefined;
  }
  if (service) {
    service.child.stdin.end();
    const exit = await service.terminal;
    assert.deepEqual(exit, { code: 0, signal: null }, service.record.stderr);
    service = undefined;
  }
}
try {
  await verify({ start, stop, get client() { return client; } });
} catch (error) {
  report.error = { message: error.message, stack: error.stack };
  throw error;
} finally {
  await stop();
  await save("report.json", report);
}
}
