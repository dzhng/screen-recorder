from pathlib import Path
import hashlib,json,tarfile,subprocess
root=Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder')
base=Path('/Users/david/.cache/screen-recorder/verification/parakeet-23n-lifecycle-correction')
packet=root/'specs/agent-editing/assets/23n-parakeet-readiness-lifecycle'
def pin(path):
 b=path.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
original=root/'specs/agent-editing/assets/23n-parakeet-model-readiness/evidence.tar.gz'
assert pin(original)['sha256']=='0e3acab53e7eecbe2116b3102d4204f47ea51386a8291e0ec438ed26c71b4a4e'
closure=[]
for n in ['parakeet-readiness.mjs','parakeet-readiness-processes.mjs','parakeet-readiness-processes.test.mjs']:
 p=root/'packages/test-harness/editing'/n;closure.append({'path':str(p.relative_to(root)),**pin(p)})
assert (base/'final-owner.mjs').read_bytes()==(root/closure[1]['path']).read_bytes()
assert (base/'final-checker.mjs').read_bytes()==(root/closure[0]['path']).read_bytes()
assert (base/'final-tests.mjs').read_bytes()==(root/closure[2]['path']).read_bytes()
deps=[]
for path in ['packages/test-harness/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js','packages/test-harness/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js','packages/test-harness/node_modules/@modelcontextprotocol/sdk/dist/esm/shared/protocol.js','packages/test-harness/node_modules/@modelcontextprotocol/sdk/dist/esm/server/index.js','packages/test-harness/node_modules/@modelcontextprotocol/sdk/dist/esm/server/stdio.js','packages/protocol/dist/index.js','packages/protocol/dist/framing.js']:
 p=(root/path).resolve();deps.append({'requested':path,'realpath':str(p),**pin(p)})
node=Path(json.loads((base/'final-green.json').read_text())['executable']).resolve();deps.append({'requested':'actual Node executable','realpath':str(node),**pin(node)})
files=[base/n for n in ['bank-controls.py','bank-packet.py','commands.json','baseline-red.json','final-green.json','final-static-checks.json','operation-oracle-preservation.json','original-checker.mjs','final-owner.mjs','final-checker.mjs','final-tests.mjs','red/owner.mjs']]
files+=sorted((base/'baseline-red').rglob('*'))+sorted((base/'final-green').rglob('*'))
files=[p for p in files if p.is_file()]
with tarfile.open(packet/'evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(base)),recursive=False)
metadata={'scope':'Synthetic actual-child readiness checker lifecycle controls only; no preparation/native/inference/readiness cohort','sourceBase':'2f0690dc8959c02b1950c0bc7e4945d201bf8398','originalAcceptedPacket':{'path':'../23n-parakeet-model-readiness/evidence.tar.gz',**pin(original),'unchanged':True},'sourceClosure':closure,'directSDKProtocolAndToolAuthority':deps,'authorityLimit':'Controls import the existing compiled protocol and installed SDK directly. Frozen production service/CLI/model runtime bundles are not executed by synthetic fixtures; their readiness authority remains in original accepted packet.','baseline':{'producer':'bank-controls.py','source':'red/owner.mjs','label':'Extracted original checker lifecycle; no model preflight','command':'baseline-red.json','missingReports':[str(p.relative_to(base)) for p in [base/'baseline-red/exit-before-ready/report.json',base/'baseline-red/failed-control/report.json'] if not p.exists()]},'corrected':{'command':'final-green.json','tests':8,'pass':8,'fail':0,'driverBoundMs':5000,'defaultSDKDeadlinesUnchanged':True,'sourceModule':'final-owner.mjs'},'staticChecks':'final-static-checks.json','operationOraclePreservation':'operation-oracle-preservation.json','archive':pin(packet/'evidence.tar.gz'),'members':[[str(p.relative_to(base)),pin(p)['bytes'],pin(p)['sha256']] for p in files]}
(packet/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(packet/'evidence.tar.gz') as tar:
 for name,size,digest in metadata['members']:
  value=tar.extractfile(name).read();assert len(value)==size and hashlib.sha256(value).hexdigest()==digest,name
assert len(metadata['baseline']['missingReports'])==2
print(json.dumps({'members':len(files),'archive':metadata['archive'],'originalUnchanged':True}))
