import {appendFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
process.on('exit',code=>appendFileSync(process.env.SCREENREC_READINESS_CLI_LOG,JSON.stringify({pid:process.pid,code})+'\n'));
await import(pathToFileURL(process.env.SCREENREC_READINESS_CLI).href);