@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import Darwin
import ScreenRecorderMedia
struct NativeInventory: Decodable { struct Row: Decodable { let ordinal:Int; let cursor:CursorFact }; let rows:[Row] }
func nativeTime(_ t:Tick)->CMTime {CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)}
struct RequestFact:Encodable {let decodePosition:Int;let presentationOrdinal:Int;let expectedPTS:Tick;let expectedDTS:Tick;let actualPTS:Tick?;let actualDTS:Tick?;let overrideTime:Tick?;let mode:String;let direction:String}
struct Difference:Encodable {let decodePosition:Int;let fields:[String]}
@main struct CursorBuffers {
 @MainActor static func main() async {
  var owner:OwnedEvidenceDestination?
  do {
   let args=CommandLine.arguments,root=URL(fileURLWithPath:args[1]),url=URL(fileURLWithPath:args[2]);let destination=try OwnedEvidenceDestination(root:root);owner=destination
   let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence")),asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
   let tracks=try await asset.loadTracks(withMediaType:.video),audio=try await asset.loadTracks(withMediaType:.audio)
   try require(tracks.count==1 && audio.isEmpty,"source tracks",["video":String(tracks.count),"audio":String(audio.count)],evidence:evidence)
   let track=tracks[0],descriptions=try await track.load(.formatDescriptions);try require(descriptions.count==1,"source format",["count":String(descriptions.count)],evidence:evidence)
   let inventory=try JSONDecoder().decode(NativeInventory.self,from:Data(contentsOf:URL(fileURLWithPath:args[3])))
   let ordered=inventory.rows.sorted{CMTimeCompare(nativeTime($0.cursor.clocks["mediaDTS"]!),nativeTime($1.cursor.clocks["mediaDTS"]!))<0};try require(ordered.count==197,"saved membership",["rows":String(ordered.count)],evidence:evidence)
   let sourceFile=try FileHandle(forReadingFrom:url);defer{try? sourceFile.close()};let raw=try sourceFile.read(upToCount:2_097_153) ?? Data();try require(raw.count<=2_097_152,"source byte cap",["bytes":String(raw.count)],evidence:evidence)
   let generator=AVSampleBufferGenerator(asset:asset,timebase:nil),baselineRoot=URL(fileURLWithPath:args[4]);var facts=[BufferFact](),payload=0
   for (position,row) in ordered.enumerated() {
    let pts=row.cursor.clocks["mediaPTS"]!,dts=row.cursor.clocks["mediaDTS"]!,cursor=track.makeSampleCursor(presentationTimeStamp:nativeTime(pts))
    guard let cursor else {try save(RequestFact(decodePosition:position,presentationOrdinal:row.ordinal,expectedPTS:pts,expectedDTS:dts,actualPTS:nil,actualDTS:nil,overrideTime:nil,mode:"immediate",direction:"none"),root.appendingPathComponent("request-\(position).json"));throw ProbeFailure(message:"No source cursor")}
    let request=AVSampleBufferRequest(start:cursor);request.direction = .none;request.mode = .immediate
    let requestFact=RequestFact(decodePosition:position,presentationOrdinal:row.ordinal,expectedPTS:pts,expectedDTS:dts,actualPTS:Tick(cursor.presentationTimeStamp),actualDTS:Tick(cursor.decodeTimeStamp),overrideTime:Tick(request.overrideTime),mode:"immediate",direction:"none")
    try save(requestFact,root.appendingPathComponent("request-\(position).json"));try require(requestFact.actualPTS==pts && requestFact.actualDTS==dts,"source cursor identity",["position":String(position)],evidence:evidence)
    let sample:CMSampleBuffer
    do {sample=try generator.makeSampleBuffer(for:request)}catch {let e=error as NSError;try save(["domain":TypedFact(e.domain),"code":TypedFact(e.code),"description":TypedFact(e.localizedDescription),"userInfo":TypedFact(e.userInfo)],root.appendingPathComponent("creation-error-\(position).json"));throw error}
    let fact=observe(sample,ordinal:position,remainingPayload:2_097_152-payload,source:descriptions[0]);try save(fact,root.appendingPathComponent("buffer-\(position).json"));facts.append(fact);payload+=fact.copiedBytes
    try require(fact.numSamples==1 && fact.valid && fact.dataReady && fact.blockCopyComplete==true && !fact.indexedOmittedForBound && !fact.rawTiming.boundedOmission && !fact.outputTiming.boundedOmission && !fact.sizes.boundedOmission,"bounded stored sample",["position":String(position),"samples":String(fact.numSamples),"payload":String(payload)],evidence:evidence)
   }
   try save(facts,root.appendingPathComponent("all-buffer-facts.json"));try save(["requests":"197","returned":String(facts.count),"payloadBytes":String(payload)],root.appendingPathComponent("inventory.json"))
   var differences=[Difference](),nativeDifferences=[Difference]()
   for (i,fact) in facts.enumerated() {
    let row=ordered[i],extent=row.cursor.extents["sample"]!,at=Int(extent.offset),count=Int(extent.length);var fields=[String]()
    if fact.payload != raw.subdata(in:at..<at+count){fields.append("payload")}
    if fact.format?.sourceEqual != true{fields.append("format")}
    if fact.indexed.count != 1{fields.append("indexedCount")}else {
     let x=fact.indexed[0];if x.timingStatus != 0{fields.append("timingStatus")};if x.sizeBytes != count{fields.append("size")}
     if x.timing?.pts != row.cursor.clocks["mediaPTS"]{fields.append("rawPTS")};if x.timing?.dts != row.cursor.clocks["mediaDTS"]{fields.append("rawDTS")};if x.timing?.duration != row.cursor.clocks["decodeDuration"]{fields.append("rawDuration")}
    }
    if !fields.isEmpty{nativeDifferences.append(Difference(decodePosition:i,fields:fields))}
    let encoder=JSONEncoder();guard var actual=try JSONSerialization.jsonObject(with:encoder.encode(fact)) as? [String:Any] else {throw ProbeFailure(message:"Encoded buffer fact is not an object")}
    let expectedURL=baselineRoot.appendingPathComponent("buffer-\(i+1).json");guard var expected=try JSONSerialization.jsonObject(with:Data(contentsOf:expectedURL)) as? [String:Any] else {throw ProbeFailure(message:"Saved buffer fact is not an object")}
    actual.removeValue(forKey:"bufferOrdinal");expected.removeValue(forKey:"bufferOrdinal")
    let differing=Set(actual.keys).union(expected.keys).filter{key in !NSDictionary(dictionary:["value":actual[key] ?? NSNull()]).isEqual(to:["value":expected[key] ?? NSNull()])}.sorted()
    if !differing.isEmpty{differences.append(Difference(decodePosition:i,fields:differing))}
   }
   try save(nativeDifferences,root.appendingPathComponent("native-correspondence-differences.json"));try save(differences,root.appendingPathComponent("full-reader-fact-differences.json"))
   try require(nativeDifferences.isEmpty,"stored source byte/clock/format correspondence",["differences":String(nativeDifferences.count)],evidence:evidence)
   try save(["status":"observed","nativeCorrespondence":"pass","fullReaderFactParity":differences.isEmpty ? "pass" : "different","differingMediaRows":String(differences.count),"scope":"197 stored samples only; no marker policy/writer/pixel decode/adoption"],root.appendingPathComponent("verdict.json"))
  }catch{if let owner{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
 }
}
