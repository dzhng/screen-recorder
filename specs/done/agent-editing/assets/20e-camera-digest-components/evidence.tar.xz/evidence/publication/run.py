from pathlib import Path
import subprocess,json,hashlib,time,sys,os,signal
binary=Path(sys.argv[1]);source=Path(sys.argv[2]);root=Path(sys.argv[3]);root.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
cmd=[str(binary),str(source),str(root/'result')];r={'command':cmd,'binarySha256':sha(binary),'deadlineSeconds':120,'rssGuardBytes':2*1024**3};began=time.monotonic();peak=0
with (root/'run.log').open('wb') as out:
 p=subprocess.Popen(cmd,stdout=out,stderr=out,start_new_session=True);r['pid']=p.pid
 while p.poll() is None:
  try:peak=max(peak,int(subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip())*1024)
  except (ValueError,subprocess.CalledProcessError):pass
  if time.monotonic()-began>120 or peak>r['rssGuardBytes']:
   r['guardFired']=True;os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.5)
 r.update(exitCode=p.wait(),launcherSeconds=time.monotonic()-began,peakRssBytes=peak)
(root/'execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(r['exitCode'] if r['exitCode']>=0 else 1)
