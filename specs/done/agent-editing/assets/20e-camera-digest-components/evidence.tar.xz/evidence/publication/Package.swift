// swift-tools-version: 6.1
import PackageDescription
let package = Package(name: "CameraPublicationProfile", platforms: [.macOS("26.0")], targets: [
 .target(name:"ScreenRecorderMedia"),
 .target(name:"ScreenRecorderCapture", dependencies:["ScreenRecorderMedia"]),
 .executableTarget(name:"CameraPublicationBenchmark", dependencies:["ScreenRecorderCapture"])
])
