from pathlib import Path
import hashlib,struct,json,sys

def bind(path):
 fields=[];atoms=[]
 with path.open('rb') as f:
  def walk(start,end,parent):
   at=start
   while at<end:
    f.seek(at);n,kind=struct.unpack('>I4s',f.read(8));header=8
    if n==1:n=struct.unpack('>Q',f.read(8))[0];header=16
    if n==0:n=end-at
    assert n>=header and at+n<=end,(at,n,kind)
    name=kind.decode('ascii');here=parent+'/'+name;atoms.append({'path':here,'offset':at,'bytes':n})
    if name in ['mvhd','tkhd','mdhd']:
     f.seek(at+header);version=f.read(1)[0];assert version==0
     for tag,delta in [('creation',4),('modification',8)]:fields.append({'path':here,'field':tag,'offset':at+header+delta,'bytes':4})
    if name in ['moov','trak','mdia']:walk(at+header,at+n,here)
    at+=n
   assert at==end
  walk(0,path.stat().st_size,'')
 assert len(fields)==6
 raw=hashlib.sha256();norm=hashlib.sha256()
 with path.open('rb') as f:
  at=0
  while b:=f.read(1024*1024):
   raw.update(b);b=bytearray(b)
   for field in fields:
    lo=max(at,field['offset']);hi=min(at+len(b),field['offset']+field['bytes'])
    if hi>lo:b[lo-at:hi-at]=bytes(hi-lo)
   norm.update(b);at+=len(b)
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':raw.hexdigest(),'dateOnlyNormalizedSha256':norm.hexdigest(),'normalizedFields':fields,'atoms':atoms}
records=[bind(Path(p))for p in sys.argv[1:]]
assert len({r['dateOnlyNormalizedSha256']for r in records})==1
assert all(r['normalizedFields']==records[0]['normalizedFields']for r in records)
print(json.dumps({'passed':True,'scope':'Only six v0 mvhd/tkhd/mdhd creation/modification date fields are zeroed for comparison. No sample/PTS/duration/metadata normalization elsewhere.','records':records},indent=2))
