import Foundation
import ScreenRecorderCapture
if CommandLine.arguments[1] == "pixels" {
    try await runProbeCameraPixelPublicationTests()
} else {

let source = URL(fileURLWithPath: CommandLine.arguments[1])
let root = URL(fileURLWithPath: CommandLine.arguments[2])
try FileManager.default.createDirectory(at: root.appendingPathComponent("camera"), withIntermediateDirectories: true)
for member in ["camera/camera.raw.mov", "camera/camera.closed.json", "camera/capture.journal.jsonl", "timestamps.jsonl"] {
    try FileManager.default.copyItem(at: source.appendingPathComponent(member), to: root.appendingPathComponent(member))
}
let expected = try JSONDecoder().decode(ProbeCameraMedia.Receipt.self,
    from: Data(contentsOf: source.appendingPathComponent("camera/camera.publication.json")))
let lease = try CaptureJournalLease(directory: root.appendingPathComponent("camera").path)
let began = ContinuousClock.now
let receipt = try await ProbeCameraMedia.publish(lease: lease, observationURL: root.appendingPathComponent("timestamps.jsonl"))
let duration = began.duration(to: .now)
lease.release()
precondition(receipt.raw == expected.raw && receipt.observations == expected.observations && receipt.closed == expected.closed)
precondition(receipt.representedFrames == expected.representedFrames && receipt.firstUs == expected.firstUs && receipt.endUs == expected.endUs)
precondition(receipt.pictureSHA256 == expected.pictureSHA256 && receipt.diagnostics == expected.diagnostics)
precondition(receipt.canonical.bytes == expected.canonical.bytes, "Canonical size changed")
try JSONEncoder().encode(receipt).write(to: root.appendingPathComponent("receipt.json"))
let elapsed = Double(duration.components.seconds) + Double(duration.components.attoseconds) / 1e18
try JSONSerialization.data(withJSONObject: ["passed":true,"publicationSeconds":elapsed,"frames":receipt.representedFrames,"pictureSHA256":receipt.pictureSHA256], options:[.prettyPrinted,.sortedKeys]).write(to: root.appendingPathComponent("measurement.json"))
print("PASS copied offline publisher: \(receipt.representedFrames) frames in \(elapsed)s")

}
