@preconcurrency import AVFoundation
import CryptoKit
import Foundation

func seconds(_ d: Duration) -> Double { Double(d.components.seconds) + Double(d.components.attoseconds) / 1e18 }
let source = URL(fileURLWithPath: CommandLine.arguments[1])
let asset = AVURLAsset(url: source, options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
let track = try await asset.loadTracks(withMediaType: .video).first!
let scale = try await track.load(.naturalTimeScale)
let reader = try AVAssetReader(asset: asset)
let output = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
reader.add(output); precondition(reader.startReading())
var hash = SHA256(), decode = Duration.zero, lock = Duration.zero, metadata = Duration.zero, pixels = Duration.zero, unlock = Duration.zero
var frames = 0, pixelBytes = 0, rowUpdates = 0
var geometry = [[String:Int]](), endpoints = [Int64]()
let began = ContinuousClock.now
while frames < 128 {
 let decodeBegan = ContinuousClock.now
 guard let sample = output.copyNextSampleBuffer() else { break }
 decode += decodeBegan.duration(to: .now)
 let pixel = sample.imageBuffer!
 let lockBegan = ContinuousClock.now
 CVPixelBufferLockBaseAddress(pixel, .readOnly)
 lock += lockBegan.duration(to: .now)
 let metadataBegan = ContinuousClock.now
 let timestamp = CMTimeConvertScale(sample.presentationTimeStamp, timescale: scale, method: .roundHalfAwayFromZero).value
 for number in [timestamp, Int64(CVPixelBufferGetWidth(pixel)), Int64(CVPixelBufferGetHeight(pixel))] {
  var little = number.littleEndian
  withUnsafeBytes(of: &little) { hash.update(bufferPointer: $0) }
 }
 metadata += metadataBegan.duration(to: .now)
 let base = CVPixelBufferGetBaseAddress(pixel)!
 let visibleRowBytes = CVPixelBufferGetWidth(pixel) * 4
 let stride = CVPixelBufferGetBytesPerRow(pixel)
 let height = CVPixelBufferGetHeight(pixel)
 let pixelsBegan = ContinuousClock.now
 if stride == visibleRowBytes {
  hash.update(bufferPointer: UnsafeRawBufferPointer(start: base, count: visibleRowBytes * height));rowUpdates += 1
 } else {
  for row in 0..<height {hash.update(bufferPointer: UnsafeRawBufferPointer(start: base.advanced(by: row * stride), count: visibleRowBytes));rowUpdates += 1}
 }
 pixels += pixelsBegan.duration(to: .now)
 let unlockBegan = ContinuousClock.now
 CVPixelBufferUnlockBaseAddress(pixel, .readOnly)
 unlock += unlockBegan.duration(to: .now)
 pixelBytes += visibleRowBytes * height
 if frames == 0 {geometry.append(["width":visibleRowBytes/4,"height":height,"stride":stride]);endpoints.append(timestamp)}
 if frames == 127 {endpoints.append(timestamp)}
 frames += 1
}
reader.cancelReading()
precondition(frames == 128)
let digest = hash.finalize().map {String(format:"%02x",$0)}.joined()
let result:[String:Any] = ["frames":frames,"pixelBytes":pixelBytes,"shaUpdateCalls":rowUpdates,"geometry":geometry,"timestampEndpoints":endpoints,"timeScale":scale,"picturePrefixSha256":digest,"timingSeconds":["decode":seconds(decode),"lock":seconds(lock),"metadata":seconds(metadata),"pixels":seconds(pixels),"unlock":seconds(unlock),"total":seconds(began.duration(to:.now))],"scope":"First128 raw decoded pictures only; no export/capture/playback; no whole-publication or live-stop acceptance"]
print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]),as:UTF8.self))
