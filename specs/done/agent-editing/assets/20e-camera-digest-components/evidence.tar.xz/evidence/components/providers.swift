import Foundation
import CryptoKit
import CommonCrypto
func seconds(_ d: Duration) -> Double { Double(d.components.seconds) + Double(d.components.attoseconds)/1e18 }
let bytes = Data((0..<(1920*1080*4)).map{ UInt8(truncatingIfNeeded:$0) })
let began = ContinuousClock.now
var digest:[UInt8]
if CommandLine.arguments[1] == "cryptokit" {
 var hash = SHA256()
 bytes.withUnsafeBytes { view in for _ in 0..<128 {hash.update(bufferPointer:view)} }
 digest = Array(hash.finalize())
} else {
 var context = CC_SHA256_CTX();precondition(CC_SHA256_Init(&context) == 1)
 bytes.withUnsafeBytes { view in for _ in 0..<128 {precondition(CC_SHA256_Update(&context,view.baseAddress,CC_LONG(view.count)) == 1)} }
 digest = [UInt8](repeating:0,count:Int(CC_SHA256_DIGEST_LENGTH));precondition(CC_SHA256_Final(&digest,&context) == 1)
}
let duration=seconds(began.duration(to:.now))
print(String(decoding:try JSONSerialization.data(withJSONObject:["provider":CommandLine.arguments[1],"bytes":bytes.count*128,"seconds":duration,"sha256":digest.map{String(format:"%02x",$0)}.joined(),"scope":"Synthetic in-memory SHA screening only, not a production provider change/publication/stop result"],options:[.sortedKeys]),as:UTF8.self))
