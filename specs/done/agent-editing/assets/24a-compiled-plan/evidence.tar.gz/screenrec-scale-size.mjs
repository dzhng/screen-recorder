import {createCompiler,validateComposition} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/dist/index.js';
import {writeFileSync} from 'node:fs';
const asset={id:'a'.repeat(64),streams:[{id:'0',kind:'audio',channels:2,sampleRate:48000,bounds:{startUs:0,endUs:1000000},available:[{startUs:0,endUs:1000000}]}]};
const rows=[];
for(const count of [500,10000]) {
 const seconds=count===500?300:7200,span=seconds*1e6/count;
 const doc={canvas:{width:16,height:16,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:[{id:'audio',kind:'audio',order:0}],groups:[],syncGroups:[],clips:Array.from({length:count},(_,i)=>({id:'clip:'+('b'.repeat(64))+':'+i,trackId:'audio',assetId:asset.id,streamId:'0',source:{kind:'range',range:{startUs:0,endUs:span}},placement:{kind:'project',range:{startUs:i*span,endUs:(i+1)*span}}})),processing:[{target:{kind:'output'},steps:[{id:'step:'+('c'.repeat(64)),enabled:true,processor:{type:'rnnoise'}}]}]};
 const start=performance.now();
 const w=createCompiler(validateComposition(doc,[asset]),'revision').audioWindow({range:{startUs:0,endUs:seconds*1e6},rendition:{sampleRate:48000,channels:2},tap:{target:{kind:'output'},point:{kind:'processed'}}});
 const state=w.audioState();
 const params={output:'/tmp/output.wav',range:w.manifest.sampleRange,clips:[...w.audio()],processing:w.processing(),state:{...state,implementationId:'rnnoise-70f1d256-d6021b7697677c4d2274c912975e143765552b0e6f25500aa660fdb4a9849be5-f480-s32768-flush2-delay960-independent-channels-v2'},assets:[{assetId:asset.id,streamId:'0',path:'/tmp/source.wav',originUs:0}]};
 rows.push({count,seconds,compileMs:performance.now()-start,wireBytes:Buffer.byteLength(JSON.stringify({id:'worker-media.mixCompositionAudio',operation:'media.mixCompositionAudio',params})+'\n'),components:Object.fromEntries(Object.entries(params).map(([k,v])=>[k,Buffer.byteLength(JSON.stringify(v))]))});
}
writeFileSync('/tmp/screenrec-scale-size.json',JSON.stringify(rows,null,2));console.log(rows);
