import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const frozen=JSON.parse(await readFile('/tmp/screenrec-edit-scalar.json','utf8'));
const old=(await import(pathToFileURL(frozen.path+'/dist/index.js'))).applyBatch;
const current=(await import('/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/dist/index.js')).applyBatch;
const bounds={startUs:0,endUs:1000000};
const assets=[{id:'asset',streams:[{id:'a',kind:'audio',sampleRate:48000,channels:2,bounds,available:[bounds]},{id:'v',kind:'video',width:64,height:48,bounds,available:[bounds]},{id:'i',kind:'image',width:64,height:48}]},{id:'font',streams:[],fontFaces:['Test']}];
const context={namespace:'case',assets,acquisitions:[{id:'take',bindings:[{assetId:'asset',streamId:'a',available:[{startUs:200000,endUs:800000}]}]}]};
const document={canvas:{width:64,height:48,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:[{id:'audio',kind:'audio',order:0},{id:'video',kind:'video',order:1}],clips:[],groups:[],syncGroups:[],processing:[]};
const place=(i,patch={})=>({operation:'place',label:'p'+i,clip:{assetId:'asset',streamId:'a',trackId:'audio',source:{kind:'range',range:{startUs:0,endUs:10000}},placement:{kind:'project',range:{startUs:i*10000,endUs:(i+1)*10000}},...patch}});
const cases=[];
function add(name,ops,doc=document){cases.push({name,document:structuredClone(doc),operations:ops,context:structuredClone(context)});}
for(let n=1;n<=24;n++)add('ordered-'+n,Array.from({length:n},(_,i)=>place(i)));
add('later-removal',[place(0),place(1),{operation:'remove',clipIds:[{label:'p0'}],scope:'selected',ripple:'none'}]);
add('later-move',[place(0),place(1),{operation:'move',clipIds:[{label:'p1'}],atUs:40000,scope:'selected',ripple:'none',tracks:[]}]);
add('later-processing',[place(0),place(1),{operation:'processing.set',target:{kind:'output'},steps:[{processor:{type:'gain',gain:.5}}]},place(2)]);
add('processing-fallback',[place(0),place(1)],{...document,processing:[{target:{kind:'output'},steps:[{id:'gain',enabled:true,processor:{type:'gain',gain:1}}]}]});
add('later-anchor',[place(0),place(1,{trackId:'video',streamId:'v',placement:{kind:'clip',clipId:{label:'p0'},start:{numerator:0,denominator:1},end:{numerator:1,denominator:1}}})]);
add('silence',[{operation:'place',clip:{trackId:'audio',source:{kind:'silence'},placement:{kind:'project',range:{startUs:0,endUs:10000}}}},place(1)]);
add('image',[place(0,{trackId:'video',streamId:'i',source:{kind:'hold',atUs:0}}),place(1,{trackId:'video',streamId:'i',source:{kind:'hold',atUs:0}})]);
add('acquisition',[place(0,{acquisitionId:'take'}),place(1,{acquisitionId:'take'})]);
const text={kind:'text',text:'Example',font:{assetId:'font',postScriptName:'Test'},width:32,height:16,size:12,color:'#ffffffff',alignment:'left',wrap:false};
const textPlace=(i)=>({operation:'place',label:'t'+i,clip:{trackId:'video',source:text,placement:{kind:'project',range:{startUs:{numerator:i,denominator:3},endUs:{numerator:i+1,denominator:3}}}}});
add('rational-text-and-mutation',[textPlace(0),textPlace(1),{operation:'text.set',clipId:{label:'t0'},source:{...text,text:'Changed'}}]);
add('track-label',[{operation:'track.add',track:{kind:'audio',order:2},label:'new'},place(0,{trackId:{label:'new'}}),place(1,{trackId:{label:'new'}})]);
for(const invalid of ['overlap','source','label','track','identity']) {
 const first=place(0),second=place(1);let doc=document;
 if(invalid==='overlap')second.clip.placement=structuredClone(first.clip.placement);
 if(invalid==='source')second.clip.streamId='missing';
 if(invalid==='label')second.label=first.label;
 if(invalid==='track')second.clip.trackId={label:'missing'};
 if(invalid==='identity')doc={...document,clips:[{...place(5).clip,id:'clip:case:1'}]};
 add('later-'+invalid,[first,second],doc);
 const overlapping=place(0);const initial={...doc,clips:[...doc.clips,{...place(0).clip,id:'existing'}]};
 add('earlier-overlap-before-'+invalid,[overlapping,second],initial);
}
const outcome=(fn,c)=>{try{return {ok:true,value:fn(c.document,c.operations,c.context)}}catch(e){return {ok:false,name:e.name,code:e.code,message:e.message,details:e.details}}};
const report={baseline:frozen,cases:[]};
for(const c of cases) {
 const before=JSON.stringify(c), expected=outcome(old,c),actual=outcome(current,c);
 assert.deepEqual(actual,expected,c.name);assert.equal(JSON.stringify(c),before,c.name+' input mutation');
 report.cases.push({...c,expected,sha256:createHash('sha256').update(JSON.stringify(actual)).digest('hex')});
}
await writeFile('/tmp/screenrec-edit-differential.json',JSON.stringify(report,null,2));console.log({passed:true,cases:cases.length,success:report.cases.filter(c=>c.expected.ok).length,refusal:report.cases.filter(c=>!c.expected.ok).length});
