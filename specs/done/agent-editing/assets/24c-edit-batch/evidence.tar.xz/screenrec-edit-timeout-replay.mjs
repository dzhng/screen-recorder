import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {JourneyService,hash} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const failed=JSON.parse(await readFile('/tmp/screenrec-public-edit-timeout/report.json','utf8'));
const home=failed.failureHome;
const db=new DatabaseSync(join(home,'library/catalog.sqlite'),{readOnly:true});
const row=db.prepare('SELECT projectId,requestId,arguments,result FROM project_requests WHERE requestId=?').get('place-4500');
assert(row,'Timed-out request must be observed, not assumed committed');
const args=JSON.parse(row.arguments), expected=JSON.parse(row.result); db.close();
const report={trace:[],home,requestId:row.requestId,projectId:row.projectId,expectedRevisionId:args.expectedRevisionId,committedRevisionId:expected.revision.id,committedClipCount:expected.revision.document.clips.length};
const service=new JourneyService(home,report);
try {
 await service.start();
 const before=await service.call('revision.get',{projectId:row.projectId});
 assert.equal(before.revision.id,expected.revision.id);
 assert.equal(before.revision.document.clips.length,5000);
 const at=performance.now();
 const replay=await service.call('edit.apply',{projectId:row.projectId,requestId:row.requestId,expectedRevisionId:args.expectedRevisionId,operations:args.operations},{transport:'mcp'});
 report.replayMs=performance.now()-at;
 assert.deepEqual(replay,expected);
 const after=await service.call('revision.get',{projectId:row.projectId});
 assert.deepEqual(after,before);
 report.resultSha256=hash(Buffer.from(row.result));report.exactReplay=true;report.unchangedHead=true;report.budgetAccepted=false;
 await writeFile('/tmp/screenrec-edit-timeout-request.json',JSON.stringify({projectId:row.projectId,requestId:row.requestId,...args},null,2));
} finally {await service.stop();await writeFile('/tmp/screenrec-edit-timeout-replay.json',JSON.stringify(report,null,2));}
console.log(report);
