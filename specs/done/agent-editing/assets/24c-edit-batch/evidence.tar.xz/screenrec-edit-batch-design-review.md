**Verdict: sound as a bounded optimization in the existing owner.** At `29d2fc5b`, I found no counterexample to prefix monotonicity under your exact eligibility rules. It addresses repeated whole-document work, so I would not call it a benchmark-specific point fix. It does not establish general edit-budget compliance.

Priority findings:

1. **P1 — “Final resolved document” must mean the end of that run, not the entire batch.**  
   Concrete counterexample: `place(label: A)` followed by `text.set(A)` or `remove(A)`. The placement receipt must retain the originally placed clip, even though the final batch document changes or removes it. Scalar execution captures each operation’s changes immediately ([edits.ts:927](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:927)). Capture canonical added clips from the frozen run result before executing the next operation. If that is already your intended meaning, this is a clarification, not a defect.

2. **P1 — Locate the first failing prefix, then preserve that prefix’s actual error and the existing wrapper.**  
   Example: append an overlapping clip, then a clip with an unknown stream. Whole-run resolution reports the unknown stream because source validation precedes overlap validation; scalar execution reports the earlier overlap. Your prefix search handles this, provided it retains or reruns the shortest failing prefix’s error rather than reusing the full-run error ([model.ts:308](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/model.ts:308), [model.ts:367](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/model.ts:367)).  
   Preserve `INVALID_EDIT`, details, original `operationIndex`, and `cause` exactly; avoid double wrapping ([edits.ts:934](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:934)). Likewise, preserve construction order: allocate → bind → resolve track ([edits.ts:876](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:876)). Your pending-prefix rule correctly covers construction failures.

3. **P2 — Separate composition error precedence from public metadata preflight in the proof.**  
   A genuinely missing catalog asset in a later operation can already mask an earlier overlap publicly: `applyOperations` gathers metadata for **all** operations before calling `applyBatch` ([projects.ts:367](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/core/src/projects.ts:367)). That existing behavior must remain.  
   For public overlap-before-source-failure coverage, use an admitted asset with an unknown stream or invalid source selection. Separately verify that missing catalog assets/acquisitions retain their existing preflight behavior.

4. **P2 — Rational-placement coverage needs the current schema distinction.**  
   Authored media and silence placements require integer project ranges; text uses `exactAnchor` and permits rational endpoints ([edits.ts:57](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/edits.ts:57)). Cover rational text placements and existing rational clips interacting with new placements. Do not accidentally broaden command acceptance while implementing aggregation.

The safety argument holds because:

- Initial admission establishes a valid starting document.
- Appended project placements do not depend on newly added clips or alter existing anchor resolution.
- Fixed source/routing metadata cannot become valid through another append.
- An overlapping pair remains overlapping after further appends.
- Empty processing makes state normalization return the candidate unchanged ([processing-state.ts:136](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/processing-state.ts:136), [processing-state.ts:377](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/processing-state.ts:377)).

I would keep the repair in `applyBatch`, sharing placement construction with the scalar path and retaining `resolveComposition` as the validator. I see no simpler **general** repair with an equally small semantic burden. Incremental validation would require substantially broader dependency and invalidation ownership.

A simpler failure-only alternative is scalar replay from the run boundary after aggregate failure. It reduces localization machinery but restores expensive work for rejected requests; binary prefix localization is reasonable if bounded failure cost matters.

The call-local `WeakSet` is also sound for these parsed object graphs, including shallow-frozen inputs, but secondary: it reduces repeated traversal within one resolution without removing repeated resolutions ([model.ts:53](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/model.ts:53)).

**Design verdict: clean with the receipt clarification above; performance acceptance remains open.** Replay bypasses execution and returns the stored result, so the reported 170 ms replay supports replay correctness, not the write budget ([projects.ts:611](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/core/src/projects.ts:611)). No edits, builds, or experiments performed.