import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {JourneyService} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
import {ReadBuffer,STDIO_DEFAULT_MAX_BUFFER_SIZE} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/node_modules/.bun/@modelcontextprotocol+sdk@1.30.0/node_modules/@modelcontextprotocol/sdk/dist/esm/shared/stdio.js';
const failed=JSON.parse(await readFile('/tmp/screenrec-public-edit-timeout/report.json','utf8')); const home=failed.failureHome;
const db=new DatabaseSync(join(home,'library/catalog.sqlite'),{readOnly:true});const row=db.prepare('SELECT * FROM project_requests WHERE requestId=?').get('place-5500');assert(row);db.close();
const args=JSON.parse(row.arguments),expected=JSON.parse(row.result);
const result={id:'00000000-0000-4000-8000-000000000000',ok:true,data:expected};
const envelope={jsonrpc:'2.0',id:1,result:{content:[{type:'text',text:JSON.stringify(result)}],structuredContent:result,isError:false}};
const bytes=Buffer.from(JSON.stringify(envelope)+'\n');
assert.throws(()=>new ReadBuffer().append(bytes),/exceeded maximum size/);
const report={trace:[],home,requestId:row.requestId,committedClips:expected.revision.document.clips.length,resultBytes:Buffer.byteLength(row.result),mcpEnvelopeBytes:bytes.length,mcpLimit:STDIO_DEFAULT_MAX_BUFFER_SIZE};
const service=new JourneyService(home,report);
try {
 await service.start();
 const at=performance.now();const replay=await service.call('edit.apply',{projectId:row.projectId,requestId:row.requestId,expectedRevisionId:args.expectedRevisionId,operations:args.operations});
 report.cliReplayMs=performance.now()-at;assert.deepEqual(replay,expected);report.exactCLIReplay=true;
 const after=(await service.call('revision.get',{projectId:row.projectId})).revision;assert.equal(after.id,expected.revision.id);report.unchangedHead=true;
} finally {await service.stop();await writeFile('/tmp/screenrec-edit-size-replay.json',JSON.stringify(report,null,2));}
console.log(report);
