import assert from 'node:assert/strict';
import { appendFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const workspace = process.env.SCREENREC_READINESS_WORKSPACE;
const log = process.env.SCREENREC_READINESS_NATIVE_LOG;
globalThis.fetch = async (...args) => {
  appendFileSync(process.env.SCREENREC_READINESS_NETWORK_LOG, JSON.stringify(args)+'\n');
  throw new Error('Readiness inspection must not fetch');
};
const { startProjectService } = await import(pathToFileURL(workspace+'/apps/service/dist/project-service.js'));
const worker = async (operation, params) => {
  appendFileSync(log, JSON.stringify({operation,params})+'\n');
  assert(['media.audioCapabilities','storage.clearRenderWorkspace'].includes(operation), 'No inference, devices, capture or media jobs permitted');
  return {ok:true,data:operation==='media.audioCapabilities'?{}:{removed:true}};
};
const service = await startProjectService({home:process.argv[2],worker});
let closing;
const close = () => closing ??= service.close().then(()=>process.disconnect());
process.on('message',message=>{if(message==='close')void close();});
process.on('disconnect',()=>void close());
process.send({socketPath:service.socketPath});
