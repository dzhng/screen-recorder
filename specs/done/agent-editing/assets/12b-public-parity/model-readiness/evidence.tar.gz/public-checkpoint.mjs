import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdtemp, realpath, readFile, writeFile, lstat, readdir, mkdir, rm } from 'node:fs/promises';
import { Readable } from 'node:stream';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const workspace = process.argv[2];
const out = process.argv[3];
const { Models, parakeetModel: manifest } = await import(pathToFileURL(join(workspace, 'packages/core/dist/models.js')));
const original = '/Users/david/.screen-recorder/models/parakeet/ee09c569f73759e6d44c9bd16766f477b2b36d39/parakeet-tdt-0.6b-v2';
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const history = [];
const requests = [];
const record = async (operation, run) => {
  try { const result = await run(); history.push({ operation, result }); return result; }
  catch (error) { history.push({ operation, error: { code: error.code, message: error.message, details: error.details, retryable: error.retryable } }); throw error; }
};
async function inventory(folder) {
  const files = [];
  for (const pin of manifest.files) {
    const file = join(folder, pin.path);
    const before = await lstat(file, { bigint: true });
    const body = await readFile(file);
    const after = await lstat(file, { bigint: true });
    assert(before.isFile());
    assert.equal(before.ino, after.ino); assert.equal(before.mtimeNs, after.mtimeNs); assert.equal(before.ctimeNs, after.ctimeNs);
    assert.equal(body.length, pin.bytes); assert.equal(sha(body), pin.sha256);
    files.push({ ...pin, inode: String(after.ino), device: String(after.dev), modifiedNs: String(after.mtimeNs), changedNs: String(after.ctimeNs), mode: String(after.mode) });
  }
  const receiptPath = join(folder, '..', 'receipt.json');
  const stat = await lstat(receiptPath, { bigint: true });
  const bytes = await readFile(receiptPath);
  return { files, receipt: { bytes: bytes.length, sha256: sha(bytes), inode: String(stat.ino), device: String(stat.dev), modifiedNs: String(stat.mtimeNs), changedNs: String(stat.ctimeNs), content: JSON.parse(bytes) } };
}

const { JourneyService } = await import(pathToFileURL(join(workspace, 'packages/test-harness/editing/source-evidence-fixture.mjs')));
const before = await inventory(original);
const home = await realpath(await mkdtemp('/tmp/screenrec-model-readiness-public-home-'));
const library = join(home,'library'); await mkdir(library,{mode:0o700});
const report = {passed:false,scope:'Actual generic owner receipt through public CLI/MCP status and ready-idempotent prepare; network denied; controlled native startup only', trace:[],exchanges:[],preparationRequests:[]};
const source = new Models(library,async (input,init)=>{
 const prefix=`https://huggingface.co/${manifest.repo}/resolve/${manifest.revision}/`;
 assert(String(input).startsWith(prefix));init.signal.throwIfAborted();
 const relative=String(input).slice(prefix.length).split('/').map(decodeURIComponent).join('/');
 const pin=manifest.files.find(file=>file.path===relative);assert(pin);
 report.preparationRequests.push({url:String(input),relative,bytes:pin.bytes,sha256:pin.sha256});
 return new Response(Readable.toWeb(createReadStream(join(original,relative))),{status:200,headers:{'content-length':String(pin.bytes)}});
});
process.env.SCREENREC_READINESS_WORKSPACE=workspace;
process.env.SCREENREC_READINESS_NATIVE_LOG=join(out,'public-native.jsonl');
process.env.SCREENREC_READINESS_NETWORK_LOG=join(out,'public-network.jsonl');
await writeFile(process.env.SCREENREC_READINESS_NATIVE_LOG,'');await writeFile(process.env.SCREENREC_READINESS_NETWORK_LOG,'');
const service=new JourneyService(home,report,undefined,pathToFileURL(join(out,'public-service.mjs')));
try {
 await source.prepare(manifest.name,new AbortController().signal);await source.settled();
 const target=join(library,'models',manifest.name,manifest.revision,manifest.folderName);
 const prepared=await inventory(target);const expected=source.list().find(row=>row.modelId===manifest.name);
 assert.equal(prepared.receipt.content.modelDigest,expected.modelDigest);
 await writeFile(join(out,'public-prepared.json'),JSON.stringify(prepared,null,2));
 for(let generation=0;generation<2;generation++){
  await service.start();
  for(const transport of ['cli','mcp']){
   const listing=await service.call('model.list',{}, {transport});
   assert.deepEqual(listing.find(row=>row.modelId===manifest.name),expected);
   assert.deepEqual(await service.call('model.status',{modelId:manifest.name},{transport}),{state:'ready'});
   assert.deepEqual(await service.call('model.prepare',{modelId:manifest.name},{transport}),{state:'ready'});
  }
  await service.stop();
  assert.deepEqual(await inventory(target),prepared);
 }
 assert.deepEqual(await inventory(original),before);
 assert.equal(await readFile(process.env.SCREENREC_READINESS_NETWORK_LOG,'utf8'),'');
 assert.equal(report.preparationRequests.length,manifest.files.length);
 report.passed=true;report.home=home;report.model=expected;report.inferenceAttempts=0;report.additionalPreparation={files:22,bytes:expected.preparation.modelBytes,purpose:'Connect real receipt to public service; first scratch owner checkpoint already cleaned'};
 report.allPreparations={completePreparations:3,filesCopied:66,bytesCopied:3*expected.preparation.modelBytes,failedFirstCheckpointRequests:1,intermediatePublicStartupFailure:'Scratch library 0755 refused by service, prepared copy then removed; corrected to 0700'};
 report.personalModelIdentitiesUnchanged=true;report.readyReceiptAndFilesUnchangedAcrossServiceReopen=true;
 await writeFile(join(out,'public-report.json'),JSON.stringify(report,null,2));
} finally {
 await service.stop();await source.settled();await writeFile(join(out,'public-service.log'),service.logs.join(''));if(report.passed)await rm(home,{recursive:true,force:true});else await writeFile(join(out,'failed-public-report.json'),JSON.stringify({...report,home},null,2));
}
console.log('PASS public CLI/MCP genuine model readiness, idempotence and reopen; zero network/inference');
