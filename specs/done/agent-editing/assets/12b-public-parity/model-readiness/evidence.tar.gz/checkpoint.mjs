import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdtemp, realpath, readFile, writeFile, lstat, readdir, mkdir, rm } from 'node:fs/promises';
import { Readable } from 'node:stream';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const workspace = process.argv[2];
const out = process.argv[3];
const { Models, parakeetModel: manifest } = await import(pathToFileURL(join(workspace, 'packages/core/dist/models.js')));
const original = '/Users/david/.screen-recorder/models/parakeet/ee09c569f73759e6d44c9bd16766f477b2b36d39/parakeet-tdt-0.6b-v2';
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const history = [];
const requests = [];
const record = async (operation, run) => {
  try { const result = await run(); history.push({ operation, result }); return result; }
  catch (error) { history.push({ operation, error: { code: error.code, message: error.message, details: error.details, retryable: error.retryable } }); throw error; }
};
async function inventory(folder) {
  const files = [];
  for (const pin of manifest.files) {
    const file = join(folder, pin.path);
    const before = await lstat(file, { bigint: true });
    const body = await readFile(file);
    const after = await lstat(file, { bigint: true });
    assert(before.isFile());
    assert.equal(before.ino, after.ino); assert.equal(before.mtimeNs, after.mtimeNs); assert.equal(before.ctimeNs, after.ctimeNs);
    assert.equal(body.length, pin.bytes); assert.equal(sha(body), pin.sha256);
    files.push({ ...pin, inode: String(after.ino), device: String(after.dev), modifiedNs: String(after.mtimeNs), changedNs: String(after.ctimeNs), mode: String(after.mode) });
  }
  const receiptPath = join(folder, '..', 'receipt.json');
  const stat = await lstat(receiptPath, { bigint: true });
  const bytes = await readFile(receiptPath);
  return { files, receipt: { bytes: bytes.length, sha256: sha(bytes), inode: String(stat.ino), device: String(stat.dev), modifiedNs: String(stat.mtimeNs), changedNs: String(stat.ctimeNs), content: JSON.parse(bytes) } };
}
const before = await inventory(original);
await writeFile(join(out, 'installed-before.json'), JSON.stringify(before, null, 2));
const home = await realpath(await mkdtemp('/tmp/screenrec-model-readiness-home-'));
let owner;
let release;
let entered;
try {
  let mode = 'fail';
  let successCount = 0;
  const held = new Promise(resolve => { release = resolve; });
  const waiting = new Promise(resolve => { entered = resolve; });
  const fetch = async (input, init) => {
    const url = String(input);
    const prefix = `https://huggingface.co/${manifest.repo}/resolve/${manifest.revision}/`;
    assert(url.startsWith(prefix)); assert(init.signal instanceof AbortSignal);
    const relative = url.slice(prefix.length).split('/').map(decodeURIComponent).join('/');
    const pin = manifest.files.find(file => file.path === relative); assert(pin);
    const row = { url, relative, expectedBytes: pin.bytes, expectedSha256: pin.sha256, delivery: 'read-only installed file stream at external fetch boundary', mode };
    requests.push(row);
    if (mode === 'fail') { row.responseStatus = 503; return new Response('fixture failure', { status: 503 }); }
    if (++successCount === 2) { entered(); await held; }
    init.signal.throwIfAborted();
    row.responseStatus = 200;
    return new Response(Readable.toWeb(createReadStream(join(original, relative))), { status: 200, headers: { 'content-length': String(pin.bytes) } });
  };
  owner = new Models(home, fetch); // Full current generic registry, no replacement manifest.
  const selected = (await record('models.list', async () => owner.list())).find(model => model.modelId === manifest.name);
  assert.equal(selected.preparation.modelBytes, manifest.files.reduce((n, file) => n + file.bytes, 0));
  assert.deepEqual(await record('status.absent', () => owner.status(manifest.name)), { state: 'absent' });
  await assert.rejects(record('nativeRequest.absent', () => owner.transcription(manifest.name).nativeRequest()), { code: 'MODEL_NOT_PREPARED' });
  assert.equal(requests.length, 0);
  await assert.rejects(record('prepare.failed', () => owner.prepare(manifest.name, new AbortController().signal)), { code: 'MODEL_DOWNLOAD_FAILED' });
  assert.equal((await record('status.failed', () => owner.status(manifest.name))).state, 'failed');
  assert.deepEqual(await readdir(join(home, 'models/.staging')), []);
  mode = 'success';
  const preparing = record('prepare.fullSelectedManifest', () => owner.prepare(manifest.name, new AbortController().signal));
  await waiting;
  const progress = await record('status.preparing', () => owner.status(manifest.name));
  assert.equal(progress.state, 'preparing'); assert.equal(progress.receivedBytes, manifest.files[0].bytes); assert.equal(progress.totalBytes, selected.preparation.modelBytes);
  await assert.rejects(record('nativeRequest.preparing', () => owner.transcription(manifest.name).nativeRequest()), { code: 'MODEL_NOT_PREPARED' });
  release(); await preparing; await owner.settled();
  assert.deepEqual(await record('status.ready', () => owner.status(manifest.name)), { state: 'ready' });
  const target = join(home, 'models', manifest.name, manifest.revision, manifest.folderName);
  const installed = await inventory(target);
  assert.equal(installed.receipt.content.modelDigest, selected.modelDigest);
  for (const file of installed.files) {
    assert.deepEqual(installed.receipt.content.files[file.path], { modifiedNs: file.modifiedNs, inode: file.inode });
    assert.notEqual(file.inode, before.files.find(pin => pin.path === file.path).inode);
  }
  await writeFile(join(out, 'prepared.json'), JSON.stringify(installed, null, 2));
  const native = await record('nativeRequest.ready', () => owner.transcription(manifest.name).nativeRequest());
  assert.deepEqual(native, { directory: target, files: manifest.files });
  const count = requests.length;
  await record('prepare.idempotent', () => owner.prepare(manifest.name, new AbortController().signal));
  assert.equal(requests.length, count); assert.deepEqual(await inventory(target), installed);
  await mkdir(join(home, 'models/.staging/owned-orphan'));
  await writeFile(join(home, 'models/.staging/owned-orphan/partial'), 'unfinished fixture');
  const offline = () => { throw new Error('ordinary inspection unexpectedly fetched'); };
  owner = new Models(home, offline);
  assert.deepEqual(await record('status.reopened', () => owner.status(manifest.name)), { state: 'ready' });
  assert.deepEqual(await record('nativeRequest.reopened', () => owner.transcription(manifest.name).nativeRequest()), native);
  await record('prepare.reopened.idempotent', () => owner.prepare(manifest.name, new AbortController().signal));
  assert.deepEqual(await readdir(join(home, 'models/.staging')), []);
  assert.deepEqual(await inventory(target), installed);
  assert.equal(successCount, manifest.files.length);
  assert.deepEqual(requests.slice(1).map(row => row.relative), manifest.files.map(file => file.path));
  const after = await inventory(original); assert.deepEqual(after, before);
  await writeFile(join(out, 'installed-after.json'), JSON.stringify(after, null, 2));
  await writeFile(join(out, 'requests.json'), JSON.stringify(requests, null, 2));
  await writeFile(join(out, 'operations.json'), JSON.stringify(history, null, 2));
  await writeFile(join(out, 'report.json'), JSON.stringify({ passed: true, scope: 'Current generic Models owner, full registered Parakeet preparation/readiness/reopen/nativeRequest; file-backed fetch edge, not public CLI/MCP model preparation transport or live Hub availability', home, model: selected, files: manifest.files.length, registeredBytes: selected.preparation.modelBytes, installedOriginalUnchanged: true, inferenceAttempts: 0, originalAcceptedInferenceAttemptsRetained: 2, receiptAuthoredBy: 'production Preparation.install', wholePublishedCopyVerified: true, ordinaryInspectionFetches: 0, requests: requests.length, ownership: 'scratch model copies removed after evidence; personal Models owner never constructed' }, null, 2));
} finally {
  release?.(); await owner?.settled(); await rm(home, { recursive: true, force: true });
}
console.log('PASS full selected manifest preparation and readiness; original files unchanged; zero inference');
