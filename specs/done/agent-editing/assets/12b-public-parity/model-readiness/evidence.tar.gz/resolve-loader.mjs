import { appendFileSync } from 'node:fs';
export async function resolve(specifier, context, nextResolve) {
  const result = await nextResolve(specifier, context);
  appendFileSync(process.env.SCREENREC_RESOLUTION_LOG, JSON.stringify({specifier,parentURL:context.parentURL,url:result.url})+'\n');
  return result;
}
