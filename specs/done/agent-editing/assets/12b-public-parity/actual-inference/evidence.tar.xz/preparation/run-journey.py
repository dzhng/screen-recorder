import json,os,signal,subprocess,time,hashlib
from pathlib import Path
s=Path(__file__).resolve().parent
worker=json.loads((s/'worker.json').read_text())
assert hashlib.sha256(Path(worker['path']).read_bytes()).hexdigest()==worker['sha256']
assert not (s/'actual-run').exists(), 'No repeated actual cohort'
assert not (s/'journey-execution.json').exists(), 'No repeated actual cohort'
wt='/tmp/screenrec-12b-actual-public-parity-pass'
command=['node','packages/test-harness/editing/speech-parity.mjs','--reference','specs/agent-editing/assets/12-speech','--existing-models','/Users/david/.screen-recorder/models/parakeet/ee09c569f73759e6d44c9bd16766f477b2b36d39/parakeet-tdt-0.6b-v2','--out',str(s/'actual-run')]
env=os.environ.copy();env['SCREENREC_NATIVE']=worker['path']
with (s/'journey.log').open('wb') as log:
 began=time.monotonic();child=subprocess.Popen(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=420);guard=None
 except subprocess.TimeoutExpired:
  guard='wholeJourneyDeadlineSeconds420';os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
(s/'journey-execution.json').write_text(json.dumps({'command':command,'worker':worker,'pid':child.pid,'exitCode':code,'launcherSeconds':time.monotonic()-began,'deadlineSeconds':420,'guardViolation':guard,'scope':'Bounded functional parity; inference latency is not performance acceptance.'},indent=2)+'\n')
print(json.dumps({'exitCode':code,'guardViolation':guard,'evidence':str(s)}))
raise SystemExit(code if code>=0 else 1)
