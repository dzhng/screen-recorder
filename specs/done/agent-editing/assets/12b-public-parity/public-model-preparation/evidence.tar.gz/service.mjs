import assert from 'node:assert/strict';
import { createReadStream, appendFileSync } from 'node:fs';
import { Readable } from 'node:stream';
import { pathToFileURL } from 'node:url';
const root=process.env.SCREENREC_PUBLIC_PREP_ROOT, out=process.env.SCREENREC_PUBLIC_PREP_OUT;
const {parakeetModel:manifest}=await import(pathToFileURL(root+'/packages/core/dist/models.js'));
let attempt=0, release;
process.on('message', m=>{if(m==='release-fetch'){const r=release;release=undefined;r?.();}});
globalThis.fetch=async(input, init)=>{
 const prefix=`https://huggingface.co/${manifest.repo}/resolve/${manifest.revision}/`;
 assert(String(input).startsWith(prefix)); init.signal.throwIfAborted();
 const relative=String(input).slice(prefix.length).split('/').map(decodeURIComponent).join('/');
 const pin=manifest.files.find(f=>f.path===relative);assert(pin);
 appendFileSync(out+'/fetch.jsonl',JSON.stringify({url:String(input),relative,bytes:pin.bytes,sha256:pin.sha256})+'\n');
 if(relative===manifest.files[0].path){
  attempt++; await new Promise((resolve,reject)=>{release=resolve;init.signal.addEventListener('abort',()=>reject(init.signal.reason),{once:true});});
  init.signal.throwIfAborted(); if(attempt===1)return new Response(null,{status:503});
 }
 return new Response(Readable.toWeb(createReadStream(process.env.SCREENREC_PUBLIC_PREP_ORIGINAL+'/'+relative)),{status:200,headers:{'content-length':String(pin.bytes)}});
};
const {startProjectService}=await import(pathToFileURL(root+'/apps/service/dist/project-service.js'));
const service=await startProjectService({home:process.argv[2],worker:async(operation,params)=>{
 appendFileSync(out+'/native.jsonl',JSON.stringify({operation,params})+'\n');
 assert(['media.audioCapabilities','storage.clearRenderWorkspace'].includes(operation));
 return {ok:true,data:operation==='media.audioCapabilities'?{}:{removed:true}};
}});
let closing;const close=()=>closing??=service.close().then(()=>process.disconnect());
process.on('message',m=>{if(m==='close')void close();});process.on('disconnect',()=>void close());
process.send({socketPath:service.socketPath});
