import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile,lstat,mkdtemp,realpath,rm} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
const root='/Users/david/dev/screen-recorder',out='/tmp/screenrec-public-model-preparation-root';
const {parakeetModel:manifest}=await import(pathToFileURL(root+'/packages/core/dist/models.js'));
const original='/Users/david/.screen-recorder/models/parakeet/'+manifest.revision+'/'+manifest.folderName;
const sha=b=>createHash('sha256').update(b).digest('hex');
async function inventory(folder){const files=[];for(const pin of manifest.files){const path=join(folder,pin.path),a=await lstat(path,{bigint:true}),b=await readFile(path),z=await lstat(path,{bigint:true});assert(a.isFile());assert.equal(a.ino,z.ino);assert.equal(a.mtimeNs,z.mtimeNs);assert.equal(a.ctimeNs,z.ctimeNs);assert.equal(b.length,pin.bytes);assert.equal(sha(b),pin.sha256);files.push({...pin,inode:String(z.ino),device:String(z.dev),modifiedNs:String(z.mtimeNs),changedNs:String(z.ctimeNs),mode:String(z.mode)});}const path=join(folder,'..','receipt.json'),a=await lstat(path,{bigint:true}),b=await readFile(path);return {files,receipt:{bytes:b.length,sha256:sha(b),inode:String(a.ino),device:String(a.dev),modifiedNs:String(a.mtimeNs),changedNs:String(a.ctimeNs),content:JSON.parse(b)}};}
const before=await inventory(original);await writeFile(out+'/original-before.json',JSON.stringify(before,null,2));
const home=await realpath(await mkdtemp('/tmp/screenrec-public-model-home-'));
const report={passed:false,scope:'Actual CLI/MCP absent-to-ready preparation through production Models owner with file-backed fetch edge, controlled native startup, zero network and inference',home,trace:[],exchanges:[]};
process.env.SCREENREC_PUBLIC_PREP_ROOT=root;process.env.SCREENREC_PUBLIC_PREP_OUT=out;process.env.SCREENREC_PUBLIC_PREP_ORIGINAL=original;
await writeFile(out+'/fetch.jsonl','');await writeFile(out+'/native.jsonl','');
const {JourneyService}=await import(pathToFileURL(root+'/packages/test-harness/editing/source-evidence-fixture.mjs'));
const service=new JourneyService(home,report,undefined,pathToFileURL(out+'/service.mjs'));
const params={modelId:manifest.name};
const status=transport=>service.call('model.status',params,{transport});
async function waitState(state){const deadline=performance.now()+60000;for(;;){const value=await status('cli');if(value.state===state)return value;assert(performance.now()<deadline,'state deadline '+state);await delay(100);}}
try{
 await service.start();
 for(const transport of ['cli','mcp'])assert.deepEqual(await status(transport),{state:'absent'});
 assert.equal((await service.call('model.prepare',params,{transport:'cli'})).state,'preparing');
 for(const transport of ['cli','mcp'])assert.equal((await status(transport)).state,'preparing');
 assert.equal((await service.call('model.prepare',params,{transport:'mcp'})).state,'preparing');
 service.child.send('release-fetch');const failed=await waitState('failed');assert.equal(failed.retryable,true);assert.equal(failed.code,'MODEL_DOWNLOAD_FAILED');
 assert.deepEqual(await status('mcp'),failed);
 assert.equal((await service.call('model.prepare',params,{transport:'mcp'})).state,'preparing');
 assert.equal((await status('cli')).state,'preparing');
 service.child.send('release-fetch');assert.deepEqual(await waitState('ready'),{state:'ready'});
 const target=join(home,'library/models',manifest.name,manifest.revision,manifest.folderName),prepared=await inventory(target);
 await writeFile(out+'/prepared.json',JSON.stringify(prepared,null,2));
 for(const transport of ['cli','mcp'])assert.deepEqual(await service.call('model.prepare',params,{transport}),{state:'ready'});
 await service.stop();await service.start();
 for(const transport of ['cli','mcp']){assert.deepEqual(await status(transport),{state:'ready'});assert.deepEqual(await service.call('model.prepare',params,{transport}),{state:'ready'});}
 await service.stop();assert.deepEqual(await inventory(target),prepared);
 const after=await inventory(original);assert.deepEqual(after,before);await writeFile(out+'/original-after.json',JSON.stringify(after,null,2));
 const requests=(await readFile(out+'/fetch.jsonl','utf8')).trim().split('\n').map(JSON.parse);
 assert.equal(requests.length,manifest.files.length+1);assert.deepEqual(requests.slice(1).map(r=>r.relative),manifest.files.map(f=>f.path));
 report.passed=true;report.fetches=requests.length;report.completedPreparations=1;report.failedDownloads=1;report.bytesPrepared=manifest.files.reduce((n,f)=>n+f.bytes,0);report.publicExchanges=report.exchanges.length;report.serviceStarts=2;report.inferenceAttempts=0;report.liveNetworkRequests=0;report.personalModelsUnchanged=true;report.modelDigest=prepared.receipt.content.modelDigest;report.priorCompletedPreparations=3;report.totalCompletedPreparations=4;
}finally{await service.stop();await writeFile(out+'/service.log',service.logs.join(''));await writeFile(out+'/report.json',JSON.stringify(report,null,2));if(report.passed)await rm(home,{recursive:true,force:true});}
console.log(JSON.stringify({passed:report.passed,exchanges:report.publicExchanges,fetches:report.fetches,inferenceAttempts:0}));
