import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
const target = new URL('file:///Users/david/dev/screen-recorder/packages/core/dist/projects.js').href;
registerHooks({
  load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (url !== target) return result;
    const source = String(result.source);
    const before = 'WHERE projectId=? AND ordinal>? AND ordinal<=? ORDER BY ordinal LIMIT ?';
    assert.equal(source.split(before).length, 2, 'Mutation target must match exactly once');
    process.stderr.write('HISTORY_UNLIMITED_MUTATION_ACTIVE\n');
    return { ...result, source: source.replace(before, 'WHERE projectId=? AND ordinal>? AND ordinal<=? AND ?>=0 ORDER BY ordinal') };
  }
});
