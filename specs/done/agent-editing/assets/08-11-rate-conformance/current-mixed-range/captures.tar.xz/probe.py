"""One retained mixed full/range case; path relocation only, no new corpus."""
import copy,hashlib,json,math,pathlib,platform,struct,subprocess,sys,tarfile,time
root=pathlib.Path(sys.argv[1]).resolve()
out=pathlib.Path(sys.argv[2]);out.mkdir();out=out.resolve()
worker=pathlib.Path('/Users/david/dev/screen-recorder/helpers/mac/.build/debug/screenrec-native').resolve()
sha=lambda b:hashlib.sha256(b).hexdigest()
worker_hash=sha(worker.read_bytes());assert worker_hash=='8a0c7732f3c1f99e074048f2ac3b8b29beb613462fb5ce769a134b1cbfdea186'
leaf=root/'specs/agent-editing/assets/08-11-rate-conformance'
archive=leaf/'captures.tar.xz';meta=json.loads((leaf/'archive.json').read_text());assert sha(archive.read_bytes())==meta['sha256']
index={x['path']:x for x in json.loads((leaf/'files.json').read_text())}
report={'passed':False,'scope':'One retained2s AAC+48kPCM mixed full/range case; no universal determinism or historical-red resolution','worker':str(worker),'workerSha256':worker_hash,'host':platform.platform(),'historicalArchiveSha256':meta['sha256'],'historicalWorkerSha256':None,'inputs':[],'cases':[]}
def write(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
def pcm(path,frames):
 b=path.read_bytes();assert b[:4]==b'RIFF' and b[8:12]==b'WAVE' and int.from_bytes(b[4:8],'little')+8==len(b)
 at=12;fmt=None
 while at+8<=len(b):
  tag=b[at:at+4];size=int.from_bytes(b[at+4:at+8],'little');at+=8
  if tag==b'fmt ':fmt=struct.unpack_from('<HHIIHH',b,at)
  if tag==b'data':
   assert fmt==(3,2,48000,384000,8,32) and size==frames*8 and at+size==len(b)
   return b[at:at+size]
  at+=size+size%2
 raise AssertionError('missingPCM')
def compare(a,b):
 assert len(a)==len(b);av=struct.unpack('<%df'%(len(a)//4),a);bv=struct.unpack('<%df'%(len(b)//4),b)
 d=[abs(x-y) for x,y in zip(av,bv)];assert all(math.isfinite(x) for x in d)
 nz=[i for i,v in enumerate(d) if v]
 return {'exact':a==b,'changedSamples':len(nz),'maximum':max(d),'rms':math.sqrt(sum(v*v for v in d)/len(d)),'firstMismatch':nz[0] if nz else None,'lastMismatch':nz[-1] if nz else None,'sha256':sha(a),'referenceSha256':sha(b)}
try:
 with tarfile.open(archive) as tar:
  def retained(name):
   m=index[name];b=tar.extractfile(m['storedAs']).read();assert len(b)==m['bytes'] and sha(b)==m['sha256'];return b
  historical=json.loads(retained('mix-verified/report.json'));case=historical['cases'][0];assert case['codec']=='aac'
  report['historicalWorkerSha256']=historical['workerSHA256'];write('historical-report.json',historical)
  replacements={}
  for asset,name,filename in [('rate-m4a','m4a-encoded.m4a','input.m4a'),('music','reference-48.wav','reference-48.wav')]:
   data=retained('mix-verified/'+name);path=out/filename;path.write_bytes(data);replacements[asset]=str(path)
   report['inputs'].append({'assetId':asset,'retainedPath':'mix-verified/'+name,'path':str(path),'bytes':len(data),'sha256':sha(data)})
  for label,filename in [('full','m4a-mixed-full.wav'),('range','m4a-mixed-range.wav')]: (out/('historical-'+label+'.wav')).write_bytes(retained('mix-verified/'+filename))
  report['historicalDifference']=compare(pcm(out/'historical-range.wav',81067),pcm(out/'historical-full.wav',96000)[5925*8:86992*8])
  assert not report['historicalDifference']['exact']
 requests=[('full',case['fullRequest'],96000),('range',case['windows'][0]['request'],81067)]
 for label,original,frames in requests:
  params=copy.deepcopy(original);params['output']=str(out/(label+'.wav'))
  for asset in params['assets']:
   if asset['assetId'] in replacements:asset['path']=replacements[asset['assetId']]
  restored=copy.deepcopy(params);restored['output']=original['output']
  for a,b in zip(restored['assets'],original['assets']):a['path']=b['path']
  assert restored==original
  request={'id':'current-mixed-'+label,'operation':'media.mixCompositionAudio','params':params};write(label+'-original-params.json',original);write(label+'-request.json',request)
  started=time.monotonic();child=subprocess.run([str(worker)],input=(json.dumps(request)+'\n').encode(),capture_output=True,timeout=30)
  (out/(label+'-stdout.json')).write_bytes(child.stdout);(out/(label+'-stderr.txt')).write_bytes(child.stderr)
  entry={'name':label,'exitCode':child.returncode,'elapsedSeconds':time.monotonic()-started,'request':request};report['cases'].append(entry)
  assert child.returncode==0,child.stderr
  response=json.loads(child.stdout);entry['response']=response;assert response['ok'],response
  result=response['data'];assert result['frames']==frames and result['channels']==2 and result['sampleRate']==48000
  entry['pcmSha256']=sha(pcm(out/(label+'.wav'),frames))
  entry['wavSha256']=sha((out/(label+'.wav')).read_bytes())
 full=pcm(out/'full.wav',96000);window=pcm(out/'range.wav',81067)
 report['difference']=compare(window,full[5925*8:86992*8]);report['currentVsHistoricalFull']=compare(full,pcm(out/'historical-full.wav',96000));report['currentVsHistoricalRange']=compare(window,pcm(out/'historical-range.wav',81067))
 report['passed']=report['difference']['exact']
 assert report['passed'],'Current mixed full/range PCM mismatch; no repetition permitted'
except BaseException as error:
 report['error']=repr(error);raise
finally:
 write('report.json',report);print(json.dumps(report.get('difference',{'error':report.get('error')})))
