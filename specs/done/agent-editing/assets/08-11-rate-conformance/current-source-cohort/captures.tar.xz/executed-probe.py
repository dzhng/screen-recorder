from pathlib import Path
import json,tarfile,hashlib,struct,math,subprocess,time,platform,copy
repo=Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder'); old=repo/'specs/agent-editing/assets/08-11-rate-conformance'; out=Path('/tmp/screenrec-current-aac-cohort'); out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
worker=Path('/Users/david/dev/screen-recorder/helpers/mac/.build/arm64-apple-macosx/debug/screenrec-native'); workerhash=sha(worker.read_bytes()); assert workerhash=='8a0c7732f3c1f99e074048f2ac3b8b29beb613462fb5ce769a134b1cbfdea186'
manifest={x['path']:x for x in json.loads((old/'files.json').read_text())}; archive=old/'captures.tar.xz'; assert sha(archive.read_bytes())=='80988c0df64f2f7f306750c0c2057b46c0c13ea95cde2b25613dfcb18c2900de'
with tarfile.open(archive) as t:
 def read(name):
  m=manifest[name]; b=t.extractfile(m['storedAs']).read(); assert sha(b)==m['sha256'] and len(b)==m['bytes']; return b
 frozen=json.loads(read('aac-repeat/report.json')); source=read('mix-controlled/m4a-encoded.m4a'); (out/'input.m4a').write_bytes(source)
 for i in [0,5]: (out/f'historical-{i}.wav').write_bytes(read(f'aac-repeat/source-{i}.wav'))
request=next(x['request'] for x in frozen['cases'] if x['kind']=='source'); cases=[]
for i in range(8):
 req=copy.deepcopy(request); req['id']=f'source-{i}'; req['params']['source']['source']=str(out/'input.m4a'); req['params']['output']=str(out/f'source-{i}.wav'); (out/f'request-{i}.json').write_text(json.dumps(req)+'\n')
 start=time.time(); r=subprocess.run([str(worker)],input=json.dumps(req)+'\n',text=True,capture_output=True,timeout=30); elapsed=time.time()-start
 (out/f'stdout-{i}.json').write_text(r.stdout); (out/f'stderr-{i}.txt').write_text(r.stderr); cases.append({'index':i,'exitCode':r.returncode,'elapsedSeconds':elapsed,'request':req,'receipt':json.loads(r.stdout)})
 assert r.returncode==0 and cases[-1]['receipt']['ok'],cases[-1]
# Every complete WAV and raw receipt is retained before comparisons.
def wave(path):
 b=path.read_bytes(); at=12; fmt=None
 while at+8<=len(b):
  name=b[at:at+4]; n=struct.unpack_from('<I',b,at+4)[0]; at+=8
  if name==b'fmt ': fmt=struct.unpack_from('<HHIIHH',b,at)
  if name==b'data':
   assert fmt[0]==3 and fmt[-1]==32
   payload=b[at:at+n]; return fmt,payload,struct.unpack('<'+'f'*(n//4),payload)
  at+=n+n%2
 raise Exception('No PCM')
def compare(a,b):
 assert a[0]==b[0] and len(a[2])==len(b[2]); d=[abs(x-y)for x,y in zip(a[2],b[2])]; changed=[i for i,v in enumerate(d)if v]
 return {'pcmBytesEqual':a[1]==b[1],'changedSamples':len(changed),'maximum':max(d),'rms':math.sqrt(sum(x*x for x in d)/len(d)),'firstChangedReturnedSample':changed[0]if changed else None,'lastChangedReturnedSample':changed[-1]if changed else None,'firstSamples':[a[2][0],b[2][0]],'lastSamples':[a[2][-1],b[2][-1]]}
base=wave(out/'source-0.wav'); historical={i:wave(out/f'historical-{i}.wav') for i in [0,5]}
for c in cases:
 p=out/f'source-{c["index"]}.wav'; w=wave(p); c.update({'wavSha256':sha(p.read_bytes()),'pcmSha256':sha(w[1]),'format':list(w[0]),'frames':len(w[2])//w[0][1],'versusCurrentFirst':compare(base,w),'versusHistorical':{str(i):compare(v,w)for i,v in historical.items()}})
report={'scope':'Eight fresh-process source reads; only source/output pathname and request id relocated from retained source requests','worker':str(worker),'workerSha256':workerhash,'host':platform.platform(),'sourceSha256':sha(source),'historicalArchiveSha256':sha(archive.read_bytes()),'cases':cases,'allCurrentPCMExact':all(c['versusCurrentFirst']['pcmBytesEqual']for c in cases),'universalDeterminismEstablished':False,'originalMixCauseEstablished':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps({k:v for k,v in report.items()if k!='cases'},indent=2)); print([(c['index'],c['versusCurrentFirst']['changedSamples'],{i:v['changedSamples']for i,v in c['versusHistorical'].items()})for c in cases])
