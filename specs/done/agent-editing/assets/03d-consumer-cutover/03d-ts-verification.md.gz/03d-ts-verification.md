# 03d TypeScript implementation verification

Implementation commit: ea8a00fe10a99635a88deca38db205b1db825554 (root integrated as 57688126).
Scheduling repair: bfeac090 (root integrated as 60efd4cf).
Isolated worktree: /tmp/screenrec-03d-ts.

## Passing verification

- Direct tsc builds and check-types for composition, core, protocol, client, and service passed after the exact-time implementation. No broad bun build or model installation.
- Combined `vitest run packages/composition/src packages/core/src packages/protocol/src apps/service/src --maxWorkers=4`: 113 files passed; 1219 tests passed, 3 skipped. Evidence: /tmp/03d-tests-final.txt.
- Scheduling repair: direct service build and check-types passed; all 18 service files passed, 165 tests passed and 2 skipped. Evidence: /tmp/03d-deadline-service-tests.txt.
- git diff --check passed. Changed files formatted. Lint found no errors; three existing unused-variable warnings in acoustic-inspection.ts were left alone.
- Self review and independent root/minimal-agent review passed. Minimal agent separately reviewed final extraction/voice duration changes and found no actionable issue. Codex CLI review was attempted but its configured model was unsupported (HTTP 400); no model or installation changed. Logs: /tmp/03d-ts-codex-review.log and /tmp/03d-ts-codex-review.txt.

## Red/green and mutation evidence

- Fractional source admission test was red against the old integer-only composition schema, then green.
- /tmp/03d-mutation-signed-admission.txt: rejecting signed fractional origins fails the admission regression (INVALID_NATIVE_RESPONSE).
- /tmp/03d-mutation-floor-audio.txt: flooring raw physical endpoint drops one sample, yielding 246477 instead of 246478.
- /tmp/03d-mutation-projected-transcript.txt: replacing exact persisted transcript intervals with projected integer labels loses the original physical interval; portable regression fails.
- /tmp/03d-mutation-premature-frame-rounding.txt: rounding the container clock before subtracting the fractional origin yields label 1 instead of the correct 0; observation regression fails.
- Each deliberate mutation was restored before the final passing suite. Mutation runner: /tmp/03d-mutations.py.
- /tmp/03d-deadline-red.txt: compiled preserve-pitch plus RNNoise fixture failed with RangeError converting a nonintegral frame-duration number to BigInt. Exact preparation-frame arithmetic now projects only the scheduling cost to conservative whole milliseconds; /tmp/03d-deadline-green.txt passes.

## Additional implementation decisions reviewed

- Published extraction and generated-voice durations derive from verified PCM frame count/sample rate. Voice's frozen worker receipt remains its existing rounded observation. The deterministic 6001-frame 24 kHz test expects public 750125/3 microseconds, receipt 250042, and unchanged audio bytes. No voice/DSP profile identity changed.
- Audio timeout budgeting now rounds preparation frames up to whole milliseconds, adds the existing query budget, and caps at MAX_MEDIA_TIMEOUT_MS. Separate upward projection can add at most 2 ms compared with rounding the combined cost once. This is a scheduling estimate only and cannot change media selection, audio bytes, or retained recipe identity.
- Transcript segments retain exact source JSON alongside integer observation/query columns. Source scene metadata retains exact duration in the existing JSON descriptor; existing integer coverage columns represent the ceil-projected query grid. This uses existing owners rather than a new timing subsystem.
- Pointer-preparation test fixtures now call importer.recover(), matching production. The two missing-acquisition-directory failures were independently reproduced on unchanged main; no production workaround was added.
- New public harness failure at audio.prepare was a harness path issue: mkdtemp('/tmp/...') yields a macOS symlink traversal rejected by the existing retained-file reader. Prepared job completed successfully; canonical /private/tmp reads succeeded. Root corrected both donor and receiver homes using realpath. Product file security behavior was preserved.

## Remaining scope and uncertainty

No unresolved TypeScript defect or unreviewed choice remains from these checks. Public native integration and final evidence preservation belong to root. Tests establish exact admission, selection/sample accounting, persistence, observation projection, and timeout behavior; they do not make a listening-quality claim or change speech anchoring/resampling policy. Old catalogs/packages are intentionally refused under the established catalog 20/package 3 fence; no migration was implemented.
