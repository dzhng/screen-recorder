	.build_version macos, 26, 0	sdk_version 26, 5
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_$s9aggregate5ExactV9numerators6Int128Vvg ; -- Begin function $s9aggregate5ExactV9numerators6Int128Vvg
	.globl	_$s9aggregate5ExactV9numerators6Int128Vvg
	.p2align	2
_$s9aggregate5ExactV9numerators6Int128Vvg: ; @"$s9aggregate5ExactV9numerators6Int128Vvg"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate5ExactV11denominators6Int128Vvg ; -- Begin function $s9aggregate5ExactV11denominators6Int128Vvg
	.globl	_$s9aggregate5ExactV11denominators6Int128Vvg
	.p2align	2
_$s9aggregate5ExactV11denominators6Int128Vvg: ; @"$s9aggregate5ExactV11denominators6Int128Vvg"
	.cfi_startproc
; %bb.0:
	mov	x0, x2
	mov	x1, x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC ; -- Begin function $s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	.globl	_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	.p2align	2
_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC: ; @"$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate5RangeV5startAA5ExactVvg ; -- Begin function $s9aggregate5RangeV5startAA5ExactVvg
	.globl	_$s9aggregate5RangeV5startAA5ExactVvg
	.p2align	2
_$s9aggregate5RangeV5startAA5ExactVvg:  ; @"$s9aggregate5RangeV5startAA5ExactVvg"
	.cfi_startproc
; %bb.0:
	ldr	q1, [x20]
	ldr	q0, [x20, #16]
	mov.16b	v3, v1
	mov	d2, v1[1]
	mov.16b	v1, v0
	mov	d0, v0[1]
	fmov	x0, d3
	fmov	x1, d2
	fmov	x2, d1
	fmov	x3, d0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate5RangeV3endAA5ExactVvg ; -- Begin function $s9aggregate5RangeV3endAA5ExactVvg
	.globl	_$s9aggregate5RangeV3endAA5ExactVvg
	.p2align	2
_$s9aggregate5RangeV3endAA5ExactVvg:    ; @"$s9aggregate5RangeV3endAA5ExactVvg"
	.cfi_startproc
; %bb.0:
	ldr	q1, [x20, #32]
	ldr	q0, [x20, #48]
	mov.16b	v3, v1
	mov	d2, v1[1]
	mov.16b	v1, v0
	mov	d0, v0[1]
	fmov	x0, d3
	fmov	x1, d2
	fmov	x2, d1
	fmov	x3, d0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC ; -- Begin function $s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC
	.globl	_$s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC
	.p2align	2
_$s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC: ; @"$s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC"
	.cfi_startproc
; %bb.0:
                                        ; implicit-def: $q3
	mov.d	v3[0], x0
	mov.d	v3[1], x1
                                        ; implicit-def: $q2
	mov.d	v2[0], x2
	mov.d	v2[1], x3
                                        ; implicit-def: $q1
	mov.d	v1[0], x4
	mov.d	v1[1], x5
                                        ; implicit-def: $q0
	mov.d	v0[0], x6
	mov.d	v0[1], x7
	str	q3, [x8]
	str	q2, [x8, #16]
	str	q1, [x8, #32]
	str	q0, [x8, #48]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionV4pathSSvg ; -- Begin function $s9aggregate9SelectionV4pathSSvg
	.globl	_$s9aggregate9SelectionV4pathSSvg
	.p2align	2
_$s9aggregate9SelectionV4pathSSvg:      ; @"$s9aggregate9SelectionV4pathSSvg"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x20]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x20, #8]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionV2idSSSgvg ; -- Begin function $s9aggregate9SelectionV2idSSSgvg
	.globl	_$s9aggregate9SelectionV2idSSSgvg
	.p2align	2
_$s9aggregate9SelectionV2idSSSgvg:      ; @"$s9aggregate9SelectionV2idSSSgvg"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x20, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x20, #24]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionV6offsetAA5ExactVvg ; -- Begin function $s9aggregate9SelectionV6offsetAA5ExactVvg
	.globl	_$s9aggregate9SelectionV6offsetAA5ExactVvg
	.p2align	2
_$s9aggregate9SelectionV6offsetAA5ExactVvg: ; @"$s9aggregate9SelectionV6offsetAA5ExactVvg"
	.cfi_startproc
; %bb.0:
	ldr	q1, [x20, #32]
	ldr	q0, [x20, #48]
	mov.16b	v3, v1
	mov	d2, v1[1]
	mov.16b	v1, v0
	mov	d0, v0[1]
	fmov	x0, d3
	fmov	x1, d2
	fmov	x2, d1
	fmov	x3, d0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionV9availableSayAA5RangeVGvg ; -- Begin function $s9aggregate9SelectionV9availableSayAA5RangeVGvg
	.globl	_$s9aggregate9SelectionV9availableSayAA5RangeVGvg
	.p2align	2
_$s9aggregate9SelectionV9availableSayAA5RangeVGvg: ; @"$s9aggregate9SelectionV9availableSayAA5RangeVGvg"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x20, #64]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC ; -- Begin function $s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC
	.globl	_$s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC
	.p2align	2
_$s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC: ; @"$s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC"
	.cfi_startproc
; %bb.0:
	mov	x9, x8
                                        ; implicit-def: $q1
	mov.d	v1[0], x4
	mov.d	v1[1], x5
                                        ; implicit-def: $q0
	mov.d	v0[0], x6
	mov.d	v0[1], x7
	ldr	x8, [sp]
	str	x0, [x9]
	str	x1, [x9, #8]
	str	x2, [x9, #16]
	str	x3, [x9, #24]
	str	q1, [x9, #32]
	str	q0, [x9, #48]
	str	x8, [x9, #64]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_ ; -- Begin function $s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_
	.globl	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_
	.p2align	2
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_: ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_"
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF ; -- Begin function $s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF
	.globl	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF
	.p2align	2
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF: ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	x22, [sp, #184]
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]                        ; 8-byte Folded Spill
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	str	x0, [x22, #296]
	mov	x8, x22
	str	x8, [x22, #168]
	add	x8, x22, #272
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	xzr, [x22, #272]
	add	x8, x22, #320
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	strb	wzr, [x22, #320]
	str	xzr, [x22, #280]
	str	xzr, [x22, #152]
	str	xzr, [x22, #160]
	add	x0, x22, #176
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x0, [x22, #272]
	; InlineAsm Start
	; InlineAsm End
	and	w9, w1, #0x1
	and	w9, w9, #0x1
	strb	w9, [x22, #320]
	; InlineAsm Start
	; InlineAsm End
	ldr	x22, [x22, #168]
	adrp	x0, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY0_@PAGE
	add	x0, x0, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY0_@PAGEOFF
	mov	x2, #0                          ; =0x0
	mov	x1, x2
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #208
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY0_
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY0_: ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #288
	str	x28, [sp, #256]                 ; 8-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	str	x22, [sp, #264]
	add	x29, sp, #272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w28, -32
	str	x22, [sp, #88]                  ; 8-byte Folded Spill
	ldr	x8, [x22, #296]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x9, x22
	str	x9, [x22, #168]
	ldr	q0, [x8]
	add	x0, x22, #88
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	stur	q0, [x22, #88]
	add	x1, x22, #104
	bl	_$sSSWOc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	; InlineAsm Start
	; InlineAsm End
	ldr	q0, [x8, #32]
	add	x9, x22, #240
	str	q0, [x22, #240]
	ldr	q0, [x8, #48]
	str	q0, [x22, #256]
	; InlineAsm Start
	; InlineAsm End
	ldr	x0, [x8, #64]
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x22, #304]
	bl	_swift_bridgeObjectRetain
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, x22, #280
	str	x9, [x22, #280]
	; InlineAsm Start
	; InlineAsm End
	mov	w8, #4                          ; =0x4
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.6.before@PAGE
	add	x0, x0, l_.str.6.before@PAGEOFF
	mov	w8, #6                          ; =0x6
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	adrp	x10, _$sSSN@GOTPAGE
	ldr	x10, [x10, _$sSSN@GOTPAGEOFF]
	str	x10, [sp, #24]                  ; 8-byte Folded Spill
	str	x10, [x8, #56]
	str	x9, [x8, #32]
	str	x1, [x8, #40]
	add	x1, x22, #120
	bl	_$sSSWOc
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [x0, #88]
	ldur	q0, [x22, #88]
	str	q0, [x0, #64]
	adrp	x8, _$s9aggregate5ExactVMf@PAGE
	add	x8, x8, _$s9aggregate5ExactVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #120]
	adrp	x8, l_metadata@PAGE
	add	x8, x8, l_metadata@PAGEOFF
	add	x0, x8, #16
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x10, #96]
	ldr	q0, [x22, #240]
	str	q0, [x8, #16]
	ldr	q0, [x22, #256]
	str	q0, [x8, #32]
	adrp	x8, _$s9aggregate5RangeVMf@PAGE
	add	x8, x8, _$s9aggregate5RangeVMf@PAGEOFF
	add	x1, x8, #16
	bl	_$sSa5countSivg
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	adrp	x9, _$sSiN@GOTPAGE
	ldr	x9, [x9, _$sSiN@GOTPAGEOFF]
	str	x9, [x0, #152]
	str	x8, [x0, #128]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	str	x1, [sp, #72]                   ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldr	x2, [sp, #72]                   ; 8-byte Folded Reload
	mov	x3, x0
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	str	x4, [sp, #64]                   ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	adrp	x8, _$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu@GOTPAGE
	ldr	x8, [x8, _$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu@GOTPAGEOFF]
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #312]
	ldr	x8, [x8, #168]
	str	x8, [x22]
	adrp	x8, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_@PAGE
	add	x8, x8, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldr	x28, [sp, #256]                 ; 8-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #288
	b	_$sScTss5NeverORszABRs_rlE5yieldyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_: ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	str	x22, [sp, #168]
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #312]
	ldr	x8, [x22]
	str	x8, [x9, #168]
	bl	_swift_task_dealloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x22, [x8, #168]
	adrp	x0, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY2_@PAGE
	add	x0, x0, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY2_@PAGEOFF
	mov	x2, #0                          ; =0x0
	mov	x1, x2
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #192
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY2_
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY2_: ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTY2_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #432
	str	x28, [sp, #400]                 ; 8-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	str	x22, [sp, #408]
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w28, -32
	str	x22, [sp, #160]                 ; 8-byte Folded Spill
	ldr	x8, [x22, #304]
	stur	x8, [x29, #-192]                ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #168]
	mov	w8, #4                          ; =0x4
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #176]                  ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #184]                  ; 8-byte Folded Spill
	adrp	x0, l_.str.5.after@PAGE
	add	x0, x0, l_.str.5.after@PAGEOFF
	mov	w8, #5                          ; =0x5
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	mov	x8, x0
	ldr	x0, [sp, #184]                  ; 8-byte Folded Reload
	adrp	x9, _$sSSN@GOTPAGE
	ldr	x9, [x9, _$sSSN@GOTPAGEOFF]
	str	x9, [sp, #168]                  ; 8-byte Folded Spill
	str	x9, [x0, #56]
	str	x8, [x0, #32]
	str	x1, [x0, #40]
	add	x0, x22, #88
	add	x1, x22, #136
	bl	_$sSSWOc
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [x0, #88]
	ldur	q0, [x22, #88]
	str	q0, [x0, #64]
	adrp	x8, _$s9aggregate5ExactVMf@PAGE
	add	x8, x8, _$s9aggregate5ExactVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #120]
	adrp	x8, l_metadata@PAGE
	add	x8, x8, l_metadata@PAGEOFF
	add	x0, x8, #16
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	x10, [sp, #184]                 ; 8-byte Folded Reload
	mov	x8, x0
	ldur	x0, [x29, #-192]                ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x10, #96]
	ldr	q0, [x22, #240]
	str	q0, [x8, #16]
	ldr	q0, [x22, #256]
	str	q0, [x8, #32]
	adrp	x8, _$s9aggregate5RangeVMf@PAGE
	add	x8, x8, _$s9aggregate5RangeVMf@PAGEOFF
	add	x1, x8, #16
	bl	_$sSa5countSivg
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #184]                  ; 8-byte Folded Reload
	adrp	x9, _$sSiN@GOTPAGE
	ldr	x9, [x9, _$sSiN@GOTPAGEOFF]
	str	x9, [x0, #152]
	str	x8, [x0, #128]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	stur	x0, [x29, #-200]                ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #192]                  ; 8-byte Folded Spill
	str	x1, [sp, #208]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldr	x2, [sp, #208]                  ; 8-byte Folded Reload
	mov	x3, x0
	ldur	x0, [x29, #-200]                ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #192]                  ; 8-byte Folded Reload
	str	x4, [sp, #200]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldr	x0, [sp, #200]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #208]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-200]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-192]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRetain
	ldur	x8, [x29, #-192]                ; 8-byte Folded Reload
	add	x20, x22, #288
	str	x8, [x22, #288]
	adrp	x0, _$sSay9aggregate5RangeVGMd@PAGE
	add	x0, x0, _$sSay9aggregate5RangeVGMd@PAGEOFF
	adrp	x1, _$sSay9aggregate5RangeVGMR@PAGE
	add	x1, x1, _$sSay9aggregate5RangeVGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameV2
	stur	x0, [x29, #-184]                ; 8-byte Folded Spill
	bl	_$sSay9aggregate5RangeVGSayxGSlsWl
	mov	x1, x0
	ldur	x0, [x29, #-184]                ; 8-byte Folded Reload
	add	x8, x22, #152
	bl	_$sSlss16IndexingIteratorVyxG0B0RtzrlE04makeB0ACyF
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	adrp	x0, _$ss16IndexingIteratorVySay9aggregate5RangeVGGMd@PAGE
	add	x0, x0, _$ss16IndexingIteratorVySay9aggregate5RangeVGGMd@PAGEOFF
	adrp	x1, _$ss16IndexingIteratorVySay9aggregate5RangeVGGMR@PAGE
	add	x1, x1, _$ss16IndexingIteratorVySay9aggregate5RangeVGGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameV2
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	add	x8, x9, #16
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	add	x20, x9, #152
	bl	_$ss16IndexingIteratorV4next7ElementQzSgyF
	ldr	x1, [sp, #136]                  ; 8-byte Folded Reload
	sub	x0, x29, #96
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	mov	w8, #65                         ; =0x41
	mov	x2, x8
	str	x2, [sp, #152]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #152]                  ; 8-byte Folded Reload
	sub	x0, x29, #176
	bl	_memcpy
	ldurb	w8, [x29, #-32]
	subs	w8, w8, #1
	b.eq	LBB15_3
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	ldur	q3, [x29, #-176]
	str	q3, [sp, #16]                   ; 16-byte Folded Spill
	ldur	q2, [x29, #-160]
	str	q2, [sp, #32]                   ; 16-byte Folded Spill
	ldur	q1, [x29, #-144]
	str	q1, [sp, #48]                   ; 16-byte Folded Spill
	ldur	q0, [x29, #-128]
	str	q0, [sp, #64]                   ; 16-byte Folded Spill
	add	x8, x9, #176
	str	q3, [x9, #176]
	str	q2, [x9, #192]
	str	q1, [x9, #208]
	str	q0, [x9, #224]
	; InlineAsm Start
	; InlineAsm End
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #88]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #96]                   ; 8-byte Folded Spill
	adrp	x8, _$s9aggregate5RangeVMf@PAGE
	add	x8, x8, _$s9aggregate5RangeVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #56]
	adrp	x8, l_metadata.5@PAGE
	add	x8, x8, l_metadata.5@PAGEOFF
	add	x0, x8, #16
	mov	w8, #80                         ; =0x50
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	q3, [sp, #16]                   ; 16-byte Folded Reload
	ldr	q2, [sp, #32]                   ; 16-byte Folded Reload
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #64]                   ; 16-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x0, #32]
	str	q3, [x8, #16]
	str	q2, [x8, #32]
	str	q1, [x8, #48]
	str	q0, [x8, #64]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	str	x0, [sp, #128]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #104]                  ; 8-byte Folded Spill
	str	x1, [sp, #120]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldr	x2, [sp, #120]                  ; 8-byte Folded Reload
	mov	x3, x0
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	str	x4, [sp, #112]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	b	LBB15_1
LBB15_3:
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #304]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	add	x0, x8, #152
	bl	_$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	add	x0, x8, #88
	bl	_$sSSWOh
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #168]
	ldr	x0, [x9, #8]
	ldr	x22, [x8, #168]
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldr	x28, [sp, #400]                 ; 8-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #432
	br	x0
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$sSSWOc                ; -- Begin function $sSSWOc
	.globl	_$sSSWOc
	.weak_definition	_$sSSWOc
	.p2align	2
_$sSSWOc:                               ; @"$sSSWOc"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x1, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [x0]
	str	x8, [x1]
	ldr	x0, [x0, #8]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy
l_objectdestroy:                        ; @objectdestroy
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss27_finalizeUninitializedArrayySayxGABnlF ; -- Begin function $ss27_finalizeUninitializedArrayySayxGABnlF
	.globl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	.weak_definition	_$ss27_finalizeUninitializedArrayySayxGABnlF
	.p2align	2
_$ss27_finalizeUninitializedArrayySayxGABnlF: ; @"$ss27_finalizeUninitializedArrayySayxGABnlF"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x1
	str	x8, [sp, #8]
	mov	x20, sp
	str	x0, [sp]
	mov	x0, #0                          ; =0x0
	bl	_$sSaMa
	bl	_$sSa12_endMutationyyF
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss5print_9separator10terminatoryypd_S2StFfA0_ ; -- Begin function $ss5print_9separator10terminatoryypd_S2StFfA0_
	.globl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	.weak_definition	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	.p2align	2
_$ss5print_9separator10terminatoryypd_S2StFfA0_: ; @"$ss5print_9separator10terminatoryypd_S2StFfA0_"
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, "l_.str.1. "@PAGE
	add	x0, x0, "l_.str.1. "@PAGEOFF
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss5print_9separator10terminatoryypd_S2StFfA1_ ; -- Begin function $ss5print_9separator10terminatoryypd_S2StFfA1_
	.globl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	.weak_definition	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	.p2align	2
_$ss5print_9separator10terminatoryypd_S2StFfA1_: ; @"$ss5print_9separator10terminatoryypd_S2StFfA1_"
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, "l_.str.1.\n"@PAGE
	add	x0, x0, "l_.str.1.\n"@PAGEOFF
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	___swift_instantiateConcreteTypeFromMangledNameV2 ; -- Begin function __swift_instantiateConcreteTypeFromMangledNameV2
	.globl	___swift_instantiateConcreteTypeFromMangledNameV2
	.weak_definition	___swift_instantiateConcreteTypeFromMangledNameV2
	.p2align	2
___swift_instantiateConcreteTypeFromMangledNameV2: ; @__swift_instantiateConcreteTypeFromMangledNameV2
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
	stur	x8, [x29, #-8]                  ; 8-byte Folded Spill
	and	x8, x8, #0x1
	subs	x8, x8, #1
	b.eq	LBB21_3
	b	LBB21_1
LBB21_1:
	ldur	x8, [x29, #-8]                  ; 8-byte Folded Reload
	mov	x0, x8
	str	x0, [sp]                        ; 8-byte Folded Spill
	cbz	x8, LBB21_3
	b	LBB21_2
LBB21_2:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB21_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	asr	x1, x9, #32
                                        ; kill: def $w9 killed $w9 killed $x9
	add	x0, x8, w9, sxtw
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_swift_getTypeByMangledNameInContext2
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	x8, x0
	str	x8, [x9]
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB21_2
                                        ; -- End function
	.private_extern	_$sSay9aggregate5RangeVGSayxGSlsWl ; -- Begin function $sSay9aggregate5RangeVGSayxGSlsWl
	.globl	_$sSay9aggregate5RangeVGSayxGSlsWl
	.weak_definition	_$sSay9aggregate5RangeVGSayxGSlsWl
	.p2align	2
_$sSay9aggregate5RangeVGSayxGSlsWl:     ; @"$sSay9aggregate5RangeVGSayxGSlsWl"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
                                        ; implicit-def: $x8
	adrp	x8, _$sSay9aggregate5RangeVGSayxGSlsWL@PAGE
	ldr	x8, [x8, _$sSay9aggregate5RangeVGSayxGSlsWL@PAGEOFF]
	mov	x0, x8
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	cbnz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	adrp	x0, _$sSay9aggregate5RangeVGMd@PAGE
	add	x0, x0, _$sSay9aggregate5RangeVGMd@PAGEOFF
	adrp	x1, _$sSay9aggregate5RangeVGMR@PAGE
	add	x1, x1, _$sSay9aggregate5RangeVGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	mov	x1, x0
	adrp	x0, _$sSayxGSlsMc@GOTPAGE
	ldr	x0, [x0, _$sSayxGSlsMc@GOTPAGEOFF]
	bl	_swift_getWitnessTable
	adrp	x9, _$sSay9aggregate5RangeVGSayxGSlsWL@PAGE
	add	x9, x9, _$sSay9aggregate5RangeVGSayxGSlsWL@PAGEOFF
	mov	x8, x0
	stlr	x8, [x9]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB22_2
LBB22_2:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_instantiateConcreteTypeFromMangledNameAbstractV2 ; -- Begin function __swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.globl	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.weak_definition	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.p2align	2
___swift_instantiateConcreteTypeFromMangledNameAbstractV2: ; @__swift_instantiateConcreteTypeFromMangledNameAbstractV2
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
	mov	x9, x8
	stur	x9, [x29, #-8]                  ; 8-byte Folded Spill
	cbz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	ldur	x8, [x29, #-8]                  ; 8-byte Folded Reload
	and	x0, x8, #0xfffffffffffffffe
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB23_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	asr	x2, x9, #32
                                        ; kill: def $w9 killed $w9 killed $x9
	add	x1, x8, w9, sxtw
	mov	w8, #255                        ; =0xff
	mov	x0, x8
	mov	x4, #0                          ; =0x0
	mov	x3, x4
	bl	_swift_getTypeByMangledNameInContextInMetadataState2
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	orr	x8, x0, #0x1
	mov	x9, x8
	str	x9, [x10]
	stur	x8, [x29, #-8]                  ; 8-byte Folded Spill
	b	LBB23_1
                                        ; -- End function
	.private_extern	_$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh ; -- Begin function $ss16IndexingIteratorVySay9aggregate5RangeVGGWOh
	.globl	_$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh
	.weak_definition	_$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh
	.p2align	2
_$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh: ; @"$ss16IndexingIteratorVySay9aggregate5RangeVGGWOh"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x0]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	_$sSSWOh                ; -- Begin function $sSSWOh
	.globl	_$sSSWOh
	.weak_definition	_$sSSWOh
	.p2align	2
_$sSSWOh:                               ; @"$sSSWOh"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy.4
l_objectdestroy.4:                      ; @objectdestroy.4
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #80                         ; =0x50
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate4MainV4mainyyYaFZ ; -- Begin function $s9aggregate4MainV4mainyyYaFZ
	.globl	_$s9aggregate4MainV4mainyyYaFZ
	.p2align	2
_$s9aggregate4MainV4mainyyYaFZ:         ; @"$s9aggregate4MainV4mainyyYaFZ"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [x22, #88]
	mov	x0, #0                          ; =0x0
	bl	_$sScMMa
	mov	x20, x0
	str	x20, [sp, #8]                   ; 8-byte Folded Spill
	bl	_$sScM6sharedScMvgZ
	mov	x20, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x8, x20
	str	x8, [x22, #160]
	adrp	x1, _$sScMScAsWP@GOTPAGE
	ldr	x1, [x1, _$sScMScAsWP@GOTPAGEOFF]
	bl	_$sScA15unownedExecutorScevgTj
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	str	x1, [x22, #168]
	str	x2, [x22, #176]
	ldr	x22, [x22, #88]
	adrp	x0, _$s9aggregate4MainV4mainyyYaFZTY0_@PAGE
	add	x0, x0, _$s9aggregate4MainV4mainyyYaFZTY0_@PAGEOFF
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate4MainV4mainyyYaFZTY0_
_$s9aggregate4MainV4mainyyYaFZTY0_:     ; @"$s9aggregate4MainV4mainyyYaFZTY0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	x22, [sp, #184]
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x22, [x29, #-32]                ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #88]
	mov	x3, #0                          ; =0x0
	str	x3, [sp, #56]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x2, x8
	str	x2, [sp, #64]                   ; 8-byte Folded Spill
	mov	x0, x3
	mov	x1, x3
	bl	_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	mov	x0, x2
	ldr	x2, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x0, x3
	ldr	x3, [sp, #56]                   ; 8-byte Folded Reload
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	w8, #10                         ; =0xa
	mov	x0, x8
	mov	x1, x3
	bl	_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	mov	x4, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x5, x1
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x6, x2
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	mov	x7, x3
	ldr	x3, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x22, #96
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	bl	_$s9aggregate5RangeV5start3endAcA5ExactV_AGtcfC
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	; InlineAsm Start
	; InlineAsm End
	adrp	x0, "l_.str.8./fixture"@PAGE
	add	x0, x0, "l_.str.8./fixture"@PAGEOFF
	mov	w8, #8                          ; =0x8
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	stur	x0, [x29, #-40]                 ; 8-byte Folded Spill
	str	x1, [sp, #96]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.5.audio@PAGE
	add	x0, x0, l_.str.5.audio@PAGEOFF
	mov	w9, #5                          ; =0x5
	mov	x1, x9
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	x3, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #64]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-88]                 ; 8-byte Folded Spill
	stur	x1, [x29, #-80]                 ; 8-byte Folded Spill
	mov	x0, #-100                       ; =0xffffffffffffff9c
	mov	x1, #-1                         ; =0xffffffffffffffff
	bl	_$s9aggregate5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	mov	x4, x0
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	stur	x4, [x29, #-72]                 ; 8-byte Folded Spill
	stur	x1, [x29, #-64]                 ; 8-byte Folded Spill
	stur	x2, [x29, #-56]                 ; 8-byte Folded Spill
	stur	x3, [x29, #-48]                 ; 8-byte Folded Spill
	adrp	x8, _$s9aggregate5RangeVMf@PAGE
	add	x8, x8, _$s9aggregate5RangeVMf@PAGEOFF
	add	x1, x8, #16
	str	x1, [sp, #88]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	add	x0, x0, #32
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	bl	_memcpy
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
	ldur	x2, [x29, #-88]                 ; 8-byte Folded Reload
	ldur	x3, [x29, #-80]                 ; 8-byte Folded Reload
	ldur	x4, [x29, #-72]                 ; 8-byte Folded Reload
	ldur	x5, [x29, #-64]                 ; 8-byte Folded Reload
	ldur	x6, [x29, #-56]                 ; 8-byte Folded Reload
	ldur	x7, [x29, #-48]                 ; 8-byte Folded Reload
	mov	x8, x0
	ldur	x0, [x29, #-40]                 ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	add	x8, x22, #16
	stur	x8, [x29, #-16]                 ; 8-byte Folded Spill
	bl	_$s9aggregate9SelectionV4path2id6offset9availableACSS_SSSgAA5ExactVSayAA5RangeVGtcfC
	bl	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFfA0_
	stur	w0, [x29, #-20]                 ; 4-byte Folded Spill
	adrp	x8, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu@PAGE
	add	x8, x8, _$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldur	x9, [x29, #-32]                 ; 8-byte Folded Reload
	ldur	w8, [x29, #-20]                 ; 4-byte Folded Reload
	mov	x22, x0
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	mov	x10, x22
	str	x10, [x9, #184]
	ldr	x9, [x9, #88]
	str	x9, [x22]
	adrp	x9, _$s9aggregate4MainV4mainyyYaFZTQ1_@PAGE
	add	x9, x9, _$s9aggregate4MainV4mainyyYaFZTQ1_@PAGEOFF
	str	x9, [x22, #8]
	and	w1, w8, #0x1
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #208
	b	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate4MainV4mainyyYaFZTQ1_
_$s9aggregate4MainV4mainyyYaFZTQ1_:     ; @"$s9aggregate4MainV4mainyyYaFZTQ1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	add	x8, x9, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x9, #184]
	ldr	x8, [x22]
	str	x8, [x9, #88]
	bl	_swift_task_dealloc
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_$s9aggregate9SelectionVWOh
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x22, [x8, #88]
	ldr	x2, [x8, #176]
	ldr	x1, [x8, #168]
	adrp	x0, _$s9aggregate4MainV4mainyyYaFZTY2_@PAGE
	add	x0, x0, _$s9aggregate4MainV4mainyyYaFZTY2_@PAGEOFF
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate4MainV4mainyyYaFZTY2_
_$s9aggregate4MainV4mainyyYaFZTY2_:     ; @"$s9aggregate4MainV4mainyyYaFZTY2_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x22, #160]
	mov	x8, x22
	str	x8, [x22, #88]
	bl	_swift_release
	ldr	x8, [x22, #88]
	ldr	x0, [x8, #8]
	ldr	x22, [x22, #88]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionVWOh ; -- Begin function $s9aggregate9SelectionVWOh
	.globl	_$s9aggregate9SelectionVWOh
	.weak_definition	_$s9aggregate9SelectionVWOh
	.p2align	2
_$s9aggregate9SelectionVWOh:            ; @"$s9aggregate9SelectionVWOh"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x0, #24]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x0, #64]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	_$s9aggregate4MainV5$mainyyYaFZ ; -- Begin function $s9aggregate4MainV5$mainyyYaFZ
	.globl	_$s9aggregate4MainV5$mainyyYaFZ
	.p2align	2
_$s9aggregate4MainV5$mainyyYaFZ:        ; @"$s9aggregate4MainV5$mainyyYaFZ"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x22, [sp]                       ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #16]
	mov	x0, #0                          ; =0x0
	bl	_$sScMMa
	mov	x20, x0
	mov	x0, x20
	str	x0, [x22, #24]
	bl	_$sScM6sharedScMvgZ
	str	x0, [x22, #32]
	adrp	x8, _$s9aggregate4MainV4mainyyYaFZTu@PAGE
	add	x8, x8, _$s9aggregate4MainV4mainyyYaFZTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #40]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _$s9aggregate4MainV5$mainyyYaFZTQ0_@PAGE
	add	x8, x8, _$s9aggregate4MainV5$mainyyYaFZTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	b	_$s9aggregate4MainV4mainyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate4MainV5$mainyyYaFZTQ0_
_$s9aggregate4MainV5$mainyyYaFZTQ0_:    ; @"$s9aggregate4MainV5$mainyyYaFZTQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #40]
	ldr	x20, [x9, #32]
	ldr	x8, [x9, #24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	adrp	x1, _$sScMScAsWP@GOTPAGE
	ldr	x1, [x1, _$sScMScAsWP@GOTPAGEOFF]
	bl	_$sScA15unownedExecutorScevgTj
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	adrp	x0, _$s9aggregate4MainV5$mainyyYaFZTY1_@PAGE
	add	x0, x0, _$s9aggregate4MainV5$mainyyYaFZTY1_@PAGEOFF
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate4MainV5$mainyyYaFZTY1_
_$s9aggregate4MainV5$mainyyYaFZTY1_:    ; @"$s9aggregate4MainV5$mainyyYaFZTY1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x22, #32]
	mov	x8, x22
	str	x8, [x22, #16]
	bl	_swift_release
	ldr	x8, [x22, #16]
	ldr	x0, [x8, #8]
	ldr	x22, [x22, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate4MainVACycfC ; -- Begin function $s9aggregate4MainVACycfC
	.globl	_$s9aggregate4MainVACycfC
	.p2align	2
_$s9aggregate4MainVACycfC:              ; @"$s9aggregate4MainVACycfC"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function async_Main
_async_Main:                            ; @async_Main
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	x22, x8
	str	x22, [x8, #16]
	adrp	x8, _$s9aggregate4MainV5$mainyyYaFZTu@PAGE
	add	x8, x8, _$s9aggregate4MainV5$mainyyYaFZTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #24]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _async_MainTQ0_@PAGE
	add	x8, x8, _async_MainTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	b	_$s9aggregate4MainV5$mainyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function async_MainTQ0_
_async_MainTQ0_:                        ; @async_MainTQ0_
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	mov	w0, #0                          ; =0x0
	bl	_exit
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, l_metadata.10@PAGE
	add	x8, x8, l_metadata.10@PAGEOFF
	add	x0, x8, #16
	mov	w8, #24                         ; =0x18
	mov	x1, x8
	mov	w8, #7                          ; =0x7
	mov	x2, x8
	bl	_swift_allocObject
	mov	x4, x0
	adrp	x8, _async_MainTu@PAGE
	add	x8, x8, _async_MainTu@PAGEOFF
	str	x8, [x4, #16]
	mov	w8, #2048                       ; =0x800
	mov	x0, x8
	mov	x1, #0                          ; =0x0
	adrp	x8, _$sytN@GOTPAGE
	ldr	x8, [x8, _$sytN@GOTPAGEOFF]
	add	x2, x8, #8
	adrp	x3, _$sIetH_yts5Error_pIegHrzo_TRTATu@PAGE
	add	x3, x3, _$sIetH_yts5Error_pIegHrzo_TRTATu@PAGEOFF
	bl	_swift_task_create
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_swift_task_getMainExecutor
	mov	x2, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	bl	_swift_job_run
	bl	_swift_task_asyncMainDrainQueue
	brk	#0x1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$sIetH_yts5Error_pIegHrzo_TR ; -- Begin function $sIetH_yts5Error_pIegHrzo_TR
	.globl	_$sIetH_yts5Error_pIegHrzo_TR
	.weak_definition	_$sIetH_yts5Error_pIegHrzo_TR
	.p2align	2
_$sIetH_yts5Error_pIegHrzo_TR:          ; @"$sIetH_yts5Error_pIegHrzo_TR"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x22, x8
	str	x22, [x8, #16]
	ldrsw	x9, [x1]
	mov	x8, x1
	add	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w8, [x1, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	x22, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x9, x22
	str	x9, [x8, #24]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTQ0_@PAGE
	add	x8, x8, _$sIetH_yts5Error_pIegHrzo_TRTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTQ0_
_$sIetH_yts5Error_pIegHrzo_TRTQ0_:      ; @"$sIetH_yts5Error_pIegHrzo_TRTQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	ldr	x0, [x22, #8]
	mov	x20, #0                         ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy.9
l_objectdestroy.9:                      ; @objectdestroy.9
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #24                         ; =0x18
	mov	x1, x8
	mov	w8, #7                          ; =0x7
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTA
_$sIetH_yts5Error_pIegHrzo_TRTA:        ; @"$sIetH_yts5Error_pIegHrzo_TRTA"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	str	x22, [sp, #40]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]                 ; 8-byte Folded Spill
	mov	x9, x22
	str	x9, [sp]                        ; 8-byte Folded Spill
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGE
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGE
	add	x8, x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGEOFF
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x22, x9
	str	x22, [x9, #16]
	ldr	x9, [x20, #16]
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x22, x0
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	mov	x11, x22
	str	x11, [x10, #24]
	ldr	x10, [x10, #16]
	str	x10, [x22]
	adrp	x10, _$sIetH_yts5Error_pIegHrzo_TRTATQ0_@PAGE
	add	x10, x10, _$sIetH_yts5Error_pIegHrzo_TRTATQ0_@PAGEOFF
	str	x10, [x22, #8]
	ldrsw	x9, [x9, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGEOFF]
	add	x2, x8, x9
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #64
	br	x2
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTATQ0_
_$sIetH_yts5Error_pIegHrzo_TRTATQ0_:    ; @"$sIetH_yts5Error_pIegHrzo_TRTATQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	ldr	x0, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5ExactVwCP
_$s9aggregate5ExactVwCP:                ; @"$s9aggregate5ExactVwCP"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x1]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_retain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	x8, [x0]
	add	x0, x8, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_noop_void_return ; -- Begin function __swift_noop_void_return
	.globl	___swift_noop_void_return
	.weak_definition	___swift_noop_void_return
	.p2align	2
___swift_noop_void_return:              ; @__swift_noop_void_return
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy32_16    ; -- Begin function __swift_memcpy32_16
	.globl	___swift_memcpy32_16
	.weak_definition	___swift_memcpy32_16
	.p2align	2
___swift_memcpy32_16:                   ; @__swift_memcpy32_16
; %bb.0:
	ldr	q0, [x1]
	str	q0, [x0]
	ldr	q0, [x1, #16]
	str	q0, [x0, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5ExactVwet
_$s9aggregate5ExactVwet:                ; @"$s9aggregate5ExactVwet"
; %bb.0:
	sub	sp, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w1, LBB47_14
	b	LBB47_1
LBB47_1:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	b.ls	LBB47_13
	b	LBB47_2
LBB47_2:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB47_4
	b	LBB47_3
LBB47_3:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB47_11
LBB47_4:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB47_6
	b	LBB47_5
LBB47_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB47_11
LBB47_6:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB47_8
	b	LBB47_7
LBB47_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB47_11
LBB47_8:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB47_10
	b	LBB47_9
LBB47_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB47_11
LBB47_10:
	brk	#0x1
LBB47_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB47_13
	b	LBB47_12
LBB47_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	subs	w9, w9, #1
	mov	w10, #256                       ; =0x100
	lsl	w10, w9, w10
	mov	w9, #0                          ; =0x0
	mov	w11, #1                         ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	ldr	x8, [x8]
                                        ; kill: def $w8 killed $w8 killed $x8
	orr	w8, w8, w9
	add	w8, w8, #0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB47_15
LBB47_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB47_15
LBB47_14:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB47_15
LBB47_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	add	w0, w8, #1
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5ExactVwst
_$s9aggregate5ExactVwst:                ; @"$s9aggregate5ExactVwst"
; %bb.0:
	sub	sp, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
                                        ; implicit-def: $w8
	mov	w8, #0                          ; =0x0
	subs	w9, w2, #0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.ls	LBB48_2
	b	LBB48_1
LBB48_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB48_2
LBB48_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #0
	b.hi	LBB48_14
	b	LBB48_3
LBB48_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbnz	w8, LBB48_5
	b	LBB48_4
LBB48_4:
	b	LBB48_12
LBB48_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB48_7
	b	LBB48_6
LBB48_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #32]
	b	LBB48_12
LBB48_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB48_9
	b	LBB48_8
LBB48_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strh	wzr, [x8, #32]
	b	LBB48_12
LBB48_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB48_11
	b	LBB48_10
LBB48_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #32]
	b	LBB48_12
LBB48_11:
	brk	#0x1
LBB48_12:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	cbz	w8, LBB48_26
	b	LBB48_13
LBB48_13:
	b	LBB48_26
LBB48_14:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	add	w9, w8, #0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x10, x8
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB48_16
	b	LBB48_15
LBB48_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	mov	w9, #256                        ; =0x100
	lsr	w9, w10, w9
	add	w9, w9, #1
	and	w8, w8, w10
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB48_16
LBB48_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #20]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	str	w11, [sp, #8]                   ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $x11 killed $w11
	bfi	x10, x11, #32, #32
	str	x10, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	str	xzr, [x9, #24]
	cbnz	w8, LBB48_18
	b	LBB48_17
LBB48_17:
	b	LBB48_25
LBB48_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB48_20
	b	LBB48_19
LBB48_19:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strb	w8, [x9, #32]
	b	LBB48_25
LBB48_20:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB48_22
	b	LBB48_21
LBB48_21:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strh	w8, [x9, #32]
	b	LBB48_25
LBB48_22:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB48_24
	b	LBB48_23
LBB48_23:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #32]
	b	LBB48_25
LBB48_24:
	brk	#0x1
LBB48_25:
	b	LBB48_26
LBB48_26:
	add	sp, sp, #48
	ret
                                        ; -- End function
	.private_extern	_$s9aggregate5ExactVMa  ; -- Begin function $s9aggregate5ExactVMa
	.globl	_$s9aggregate5ExactVMa
	.p2align	2
_$s9aggregate5ExactVMa:                 ; @"$s9aggregate5ExactVMa"
; %bb.0:
	adrp	x8, _$s9aggregate5ExactVMf@PAGE
	add	x8, x8, _$s9aggregate5ExactVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5RangeVwCP
_$s9aggregate5RangeVwCP:                ; @"$s9aggregate5RangeVwCP"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x1]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_retain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	x8, [x0]
	add	x0, x8, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy64_16    ; -- Begin function __swift_memcpy64_16
	.globl	___swift_memcpy64_16
	.weak_definition	___swift_memcpy64_16
	.p2align	2
___swift_memcpy64_16:                   ; @__swift_memcpy64_16
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5RangeVwet
_$s9aggregate5RangeVwet:                ; @"$s9aggregate5RangeVwet"
; %bb.0:
	sub	sp, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w1, LBB52_14
	b	LBB52_1
LBB52_1:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	b.ls	LBB52_13
	b	LBB52_2
LBB52_2:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB52_4
	b	LBB52_3
LBB52_3:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB52_11
LBB52_4:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB52_6
	b	LBB52_5
LBB52_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB52_11
LBB52_6:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB52_8
	b	LBB52_7
LBB52_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB52_11
LBB52_8:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB52_10
	b	LBB52_9
LBB52_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB52_11
LBB52_10:
	brk	#0x1
LBB52_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB52_13
	b	LBB52_12
LBB52_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	subs	w9, w9, #1
	mov	w10, #512                       ; =0x200
	lsl	w10, w9, w10
	mov	w9, #0                          ; =0x0
	mov	w11, #1                         ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	ldr	x8, [x8]
                                        ; kill: def $w8 killed $w8 killed $x8
	orr	w8, w8, w9
	add	w8, w8, #0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB52_15
LBB52_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB52_15
LBB52_14:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB52_15
LBB52_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	add	w0, w8, #1
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate5RangeVwst
_$s9aggregate5RangeVwst:                ; @"$s9aggregate5RangeVwst"
; %bb.0:
	sub	sp, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
                                        ; implicit-def: $w8
	mov	w8, #0                          ; =0x0
	subs	w9, w2, #0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.ls	LBB53_2
	b	LBB53_1
LBB53_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB53_2
LBB53_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #0
	b.hi	LBB53_14
	b	LBB53_3
LBB53_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbnz	w8, LBB53_5
	b	LBB53_4
LBB53_4:
	b	LBB53_12
LBB53_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB53_7
	b	LBB53_6
LBB53_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #64]
	b	LBB53_12
LBB53_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB53_9
	b	LBB53_8
LBB53_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strh	wzr, [x8, #64]
	b	LBB53_12
LBB53_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB53_11
	b	LBB53_10
LBB53_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #64]
	b	LBB53_12
LBB53_11:
	brk	#0x1
LBB53_12:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	cbz	w8, LBB53_26
	b	LBB53_13
LBB53_13:
	b	LBB53_26
LBB53_14:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	add	w9, w8, #0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x10, x8
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB53_16
	b	LBB53_15
LBB53_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	mov	w9, #512                        ; =0x200
	lsr	w9, w10, w9
	add	w9, w9, #1
	and	w8, w8, w10
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB53_16
LBB53_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #20]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	str	w11, [sp, #8]                   ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $x11 killed $w11
	bfi	x10, x11, #32, #32
	str	x10, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	str	xzr, [x9, #24]
	str	xzr, [x9, #32]
	str	xzr, [x9, #40]
	str	xzr, [x9, #48]
	str	xzr, [x9, #56]
	cbnz	w8, LBB53_18
	b	LBB53_17
LBB53_17:
	b	LBB53_25
LBB53_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB53_20
	b	LBB53_19
LBB53_19:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strb	w8, [x9, #64]
	b	LBB53_25
LBB53_20:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB53_22
	b	LBB53_21
LBB53_21:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strh	w8, [x9, #64]
	b	LBB53_25
LBB53_22:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB53_24
	b	LBB53_23
LBB53_23:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #64]
	b	LBB53_25
LBB53_24:
	brk	#0x1
LBB53_25:
	b	LBB53_26
LBB53_26:
	add	sp, sp, #48
	ret
                                        ; -- End function
	.private_extern	_$s9aggregate5RangeVMa  ; -- Begin function $s9aggregate5RangeVMa
	.globl	_$s9aggregate5RangeVMa
	.p2align	2
_$s9aggregate5RangeVMa:                 ; @"$s9aggregate5RangeVMa"
; %bb.0:
	adrp	x8, _$s9aggregate5RangeVMf@PAGE
	add	x8, x8, _$s9aggregate5RangeVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwCP
_$s9aggregate9SelectionVwCP:            ; @"$s9aggregate9SelectionVwCP"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x1]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_retain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	x8, [x0]
	add	x0, x8, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwxx
_$s9aggregate9SelectionVwxx:            ; @"$s9aggregate9SelectionVwxx"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x0, #24]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x0, #64]
	bl	_swift_bridgeObjectRelease
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwcp
_$s9aggregate9SelectionVwcp:            ; @"$s9aggregate9SelectionVwcp"
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	stur	x0, [x29, #-16]                 ; 8-byte Folded Spill
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x8, [x1]
	str	x8, [x0]
	ldr	x0, [x1, #8]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [x0, #8]
	ldr	x8, [x1, #16]
	str	x8, [x0, #16]
	ldr	x0, [x1, #24]
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [x0, #24]
	ldr	q0, [x1, #32]
	str	q0, [x0, #32]
	ldr	q0, [x1, #48]
	str	q0, [x0, #48]
	ldr	x0, [x1, #64]
	stur	x0, [x29, #-8]                  ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]                  ; 8-byte Folded Reload
	str	x8, [x0, #64]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwca
_$s9aggregate9SelectionVwca:            ; @"$s9aggregate9SelectionVwca"
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	stur	x0, [x29, #-8]                  ; 8-byte Folded Spill
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x8, [x1]
	str	x8, [x0]
	ldr	x0, [x1, #8]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x9, [x29, #-8]                  ; 8-byte Folded Reload
	ldr	x0, [x9, #8]
	str	x8, [x9, #8]
	bl	_swift_bridgeObjectRelease
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]                  ; 8-byte Folded Reload
	ldr	x8, [x1, #16]
	str	x8, [x0, #16]
	ldr	x0, [x1, #24]
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-8]                  ; 8-byte Folded Reload
	ldr	x0, [x9, #24]
	str	x8, [x9, #24]
	bl	_swift_bridgeObjectRelease
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]                  ; 8-byte Folded Reload
	ldr	q0, [x1, #32]
	str	q0, [x0, #32]
	ldr	q0, [x1, #48]
	str	q0, [x0, #48]
	ldr	x0, [x1, #64]
	stur	x0, [x29, #-16]                 ; 8-byte Folded Spill
	bl	_swift_bridgeObjectRetain
	ldur	x8, [x29, #-16]                 ; 8-byte Folded Reload
	ldur	x9, [x29, #-8]                  ; 8-byte Folded Reload
	ldr	x0, [x9, #64]
	str	x8, [x9, #64]
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-8]                  ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy72_16    ; -- Begin function __swift_memcpy72_16
	.globl	___swift_memcpy72_16
	.weak_definition	___swift_memcpy72_16
	.p2align	2
___swift_memcpy72_16:                   ; @__swift_memcpy72_16
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, #72                         ; =0x48
	mov	x2, x8
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwta
_$s9aggregate9SelectionVwta:            ; @"$s9aggregate9SelectionVwta"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	x9, x0
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [x1]
	str	x8, [x9]
	ldr	x8, [x1, #8]
	ldr	x0, [x9, #8]
	str	x8, [x9, #8]
	bl	_swift_bridgeObjectRelease
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x1, #16]
	str	x8, [x9, #16]
	ldr	x8, [x1, #24]
	ldr	x0, [x9, #24]
	str	x8, [x9, #24]
	bl	_swift_bridgeObjectRelease
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	q0, [x1, #32]
	str	q0, [x9, #32]
	ldr	q0, [x1, #48]
	str	q0, [x9, #48]
	ldr	x8, [x1, #64]
	ldr	x0, [x9, #64]
	str	x8, [x9, #64]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwet
_$s9aggregate9SelectionVwet:            ; @"$s9aggregate9SelectionVwet"
; %bb.0:
	sub	sp, sp, #48
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	cbz	w1, LBB61_16
	b	LBB61_1
LBB61_1:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w8, #31, LBB61_13
	b	LBB61_2
LBB61_2:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, #72
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB61_4
	b	LBB61_3
LBB61_3:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB61_11
LBB61_4:
	mov	w8, #0                          ; =0x0
	cbnz	w8, LBB61_6
	b	LBB61_5
LBB61_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB61_11
LBB61_6:
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB61_8
	b	LBB61_7
LBB61_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB61_11
LBB61_8:
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB61_10
	b	LBB61_9
LBB61_9:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB61_11
LBB61_10:
	brk	#0x1
LBB61_11:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	cbz	w8, LBB61_13
	b	LBB61_12
LBB61_12:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	mov	w9, #2147483647                 ; =0x7fffffff
	add	w8, w8, w9
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB61_17
LBB61_13:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x0, x8
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	w0, #-1                         ; =0xffffffff
	lsr	x8, x8, #32
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	x8, LBB61_15
	b	LBB61_14
LBB61_14:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB61_15
LBB61_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB61_17
LBB61_16:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB61_17
LBB61_17:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	add	w0, w8, #1
	add	sp, sp, #48
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s9aggregate9SelectionVwst
_$s9aggregate9SelectionVwst:            ; @"$s9aggregate9SelectionVwst"
; %bb.0:
	sub	sp, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
                                        ; implicit-def: $w8
	mov	w9, #2147483647                 ; =0x7fffffff
	mov	w8, #0                          ; =0x0
	subs	w9, w2, w9
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.ls	LBB62_2
	b	LBB62_1
LBB62_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB62_2
LBB62_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.hi	LBB62_14
	b	LBB62_3
LBB62_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbnz	w8, LBB62_5
	b	LBB62_4
LBB62_4:
	b	LBB62_12
LBB62_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB62_7
	b	LBB62_6
LBB62_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #72]
	b	LBB62_12
LBB62_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB62_9
	b	LBB62_8
LBB62_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strh	wzr, [x8, #72]
	b	LBB62_12
LBB62_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB62_11
	b	LBB62_10
LBB62_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #72]
	b	LBB62_12
LBB62_11:
	brk	#0x1
LBB62_12:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	cbz	w8, LBB62_26
	b	LBB62_13
LBB62_13:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [x9, #8]
	b	LBB62_26
LBB62_14:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	mov	w9, #-2147483647                ; =0x80000001
	add	w9, w8, w9
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x10, x8
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB62_16
	b	LBB62_15
LBB62_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	mov	w9, #576                        ; =0x240
	lsr	w9, w10, w9
	add	w9, w9, #1
	and	w8, w8, w10
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB62_16
LBB62_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #20]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	str	w11, [sp, #8]                   ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $x11 killed $w11
	bfi	x10, x11, #32, #32
	str	x10, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	str	xzr, [x9, #24]
	str	xzr, [x9, #32]
	str	xzr, [x9, #40]
	str	xzr, [x9, #48]
	str	xzr, [x9, #56]
	str	xzr, [x9, #64]
	cbnz	w8, LBB62_18
	b	LBB62_17
LBB62_17:
	b	LBB62_25
LBB62_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB62_20
	b	LBB62_19
LBB62_19:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strb	w8, [x9, #72]
	b	LBB62_25
LBB62_20:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB62_22
	b	LBB62_21
LBB62_21:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strh	w8, [x9, #72]
	b	LBB62_25
LBB62_22:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB62_24
	b	LBB62_23
LBB62_23:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #72]
	b	LBB62_25
LBB62_24:
	brk	#0x1
LBB62_25:
	b	LBB62_26
LBB62_26:
	add	sp, sp, #48
	ret
                                        ; -- End function
	.private_extern	_$s9aggregate9SelectionVMa ; -- Begin function $s9aggregate9SelectionVMa
	.globl	_$s9aggregate9SelectionVMa
	.p2align	2
_$s9aggregate9SelectionVMa:             ; @"$s9aggregate9SelectionVMa"
; %bb.0:
	adrp	x8, _$s9aggregate9SelectionVMf@PAGE
	add	x8, x8, _$s9aggregate9SelectionVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.private_extern	_$s9aggregate4MainVMa   ; -- Begin function $s9aggregate4MainVMa
	.globl	_$s9aggregate4MainVMa
	.p2align	2
_$s9aggregate4MainVMa:                  ; @"$s9aggregate4MainVMa"
; %bb.0:
	adrp	x8, _$s9aggregate4MainVMf@PAGE
	add	x8, x8, _$s9aggregate4MainVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.private_extern	_$sSa12_endMutationyyF  ; -- Begin function $sSa12_endMutationyyF
	.globl	_$sSa12_endMutationyyF
	.weak_definition	_$sSa12_endMutationyyF
	.p2align	2
_$sSa12_endMutationyyF:                 ; @"$sSa12_endMutationyyF"
	.cfi_startproc
; %bb.0:
	ldr	x8, [x20]
	str	x8, [x20]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu ; @"$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu"
	.section	__TEXT,__const
	.globl	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu
	.p2align	3, 0x0
_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu:
	.long	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF-_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTu
	.long	336                             ; 0x150

	.section	__TEXT,__cstring,cstring_literals
l_.str.6.before:                        ; @.str.6.before
	.asciz	"before"

	.private_extern	"_symbolic _____ 9aggregate5ExactV" ; @"symbolic _____ 9aggregate5ExactV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 9aggregate5ExactV"
	.weak_definition	"_symbolic _____ 9aggregate5ExactV"
	.p2align	1, 0x0
"_symbolic _____ 9aggregate5ExactV":
	.byte	1                               ; 0x1
	.long	_$s9aggregate5ExactVMn-"_symbolic _____ 9aggregate5ExactV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor"
l__swift5_reflection_descriptor:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5ExactV"-l__swift5_reflection_descriptor-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata
l_metadata:
	.quad	l_objectdestroy
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor

	.section	__TEXT,__cstring,cstring_literals
l_.str.5.after:                         ; @.str.5.after
	.asciz	"after"

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.1"
l__swift5_reflection_descriptor.1:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5ExactV"-l__swift5_reflection_descriptor.1-12

	.private_extern	"_symbolic Say_____G 9aggregate5RangeV" ; @"symbolic Say_____G 9aggregate5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic Say_____G 9aggregate5RangeV"
	.weak_definition	"_symbolic Say_____G 9aggregate5RangeV"
	.p2align	1, 0x0
"_symbolic Say_____G 9aggregate5RangeV":
	.ascii	"Say"
	.byte	1                               ; 0x1
	.long	_$s9aggregate5RangeVMn-"_symbolic Say_____G 9aggregate5RangeV"-4
	.byte	71
	.byte	0                               ; 0x0

	.private_extern	_$sSay9aggregate5RangeVGMd ; @"$sSay9aggregate5RangeVGMd"
	.section	__DATA,__data
	.globl	_$sSay9aggregate5RangeVGMd
	.weak_definition	_$sSay9aggregate5RangeVGMd
	.p2align	3, 0x0
_$sSay9aggregate5RangeVGMd:
	.space	8

	.private_extern	_$sSay9aggregate5RangeVGMR ; @"$sSay9aggregate5RangeVGMR"
	.section	__TEXT,__const
	.globl	_$sSay9aggregate5RangeVGMR
	.weak_definition	_$sSay9aggregate5RangeVGMR
	.p2align	3, 0x0
_$sSay9aggregate5RangeVGMR:
	.long	"_symbolic Say_____G 9aggregate5RangeV"-_$sSay9aggregate5RangeVGMR
	.long	9                               ; 0x9

	.private_extern	_$sSay9aggregate5RangeVGSayxGSlsWL ; @"$sSay9aggregate5RangeVGSayxGSlsWL"
	.section	__DATA,__data
	.globl	_$sSay9aggregate5RangeVGSayxGSlsWL
	.weak_definition	_$sSay9aggregate5RangeVGSayxGSlsWL
	.p2align	3, 0x0
_$sSay9aggregate5RangeVGSayxGSlsWL:
	.quad	0

	.private_extern	"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV" ; @"symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV"
	.weak_definition	"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV"
	.p2align	1, 0x0
"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV":
	.byte	2                               ; 0x2
Ltmp0:
	.long	_$ss16IndexingIteratorVMn@GOT-Ltmp0
	.ascii	"ySay"
	.byte	1                               ; 0x1
	.long	_$s9aggregate5RangeVMn-"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV"-10
	.space	2,71
	.byte	0                               ; 0x0

	.private_extern	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMd ; @"$ss16IndexingIteratorVySay9aggregate5RangeVGGMd"
	.section	__DATA,__data
	.globl	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMd
	.weak_definition	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMd
	.p2align	3, 0x0
_$ss16IndexingIteratorVySay9aggregate5RangeVGGMd:
	.space	8

	.private_extern	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMR ; @"$ss16IndexingIteratorVySay9aggregate5RangeVGGMR"
	.section	__TEXT,__const
	.globl	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMR
	.weak_definition	_$ss16IndexingIteratorVySay9aggregate5RangeVGGMR
	.p2align	3, 0x0
_$ss16IndexingIteratorVySay9aggregate5RangeVGGMR:
	.long	"_symbolic _____ySay_____GG s16IndexingIteratorV 9aggregate5RangeV"-_$ss16IndexingIteratorVySay9aggregate5RangeVGGMR
	.long	16                              ; 0x10

	.private_extern	"_symbolic _____ 9aggregate5RangeV" ; @"symbolic _____ 9aggregate5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 9aggregate5RangeV"
	.weak_definition	"_symbolic _____ 9aggregate5RangeV"
	.p2align	1, 0x0
"_symbolic _____ 9aggregate5RangeV":
	.byte	1                               ; 0x1
	.long	_$s9aggregate5RangeVMn-"_symbolic _____ 9aggregate5RangeV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.3"
l__swift5_reflection_descriptor.3:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5RangeV"-l__swift5_reflection_descriptor.3-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata.5
l_metadata.5:
	.quad	l_objectdestroy.4
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor.3

	.private_extern	_$s9aggregate4MainV4mainyyYaFZTu ; @"$s9aggregate4MainV4mainyyYaFZTu"
	.section	__TEXT,__const
	.globl	_$s9aggregate4MainV4mainyyYaFZTu
	.p2align	3, 0x0
_$s9aggregate4MainV4mainyyYaFZTu:
	.long	_$s9aggregate4MainV4mainyyYaFZ-_$s9aggregate4MainV4mainyyYaFZTu
	.long	192                             ; 0xc0

	.section	__TEXT,__cstring,cstring_literals
"l_.str.8./fixture":                    ; @".str.8./fixture"
	.asciz	"/fixture"

l_.str.5.audio:                         ; @.str.5.audio
	.asciz	"audio"

	.private_extern	_$s9aggregate4MainV5$mainyyYaFZTu ; @"$s9aggregate4MainV5$mainyyYaFZTu"
	.section	__TEXT,__const
	.globl	_$s9aggregate4MainV5$mainyyYaFZTu
	.p2align	3, 0x0
_$s9aggregate4MainV5$mainyyYaFZTu:
	.long	_$s9aggregate4MainV5$mainyyYaFZ-_$s9aggregate4MainV5$mainyyYaFZTu
	.long	48                              ; 0x30

	.p2align	3, 0x0                          ; @async_MainTu
_async_MainTu:
	.long	_async_Main-_async_MainTu
	.long	32                              ; 0x20

	.private_extern	_$sIetH_yts5Error_pIegHrzo_TRTu ; @"$sIetH_yts5Error_pIegHrzo_TRTu"
	.globl	_$sIetH_yts5Error_pIegHrzo_TRTu
	.weak_definition	_$sIetH_yts5Error_pIegHrzo_TRTu
	.p2align	3, 0x0
_$sIetH_yts5Error_pIegHrzo_TRTu:
	.long	_$sIetH_yts5Error_pIegHrzo_TR-_$sIetH_yts5Error_pIegHrzo_TRTu
	.long	32                              ; 0x20

	.private_extern	"_symbolic IetH_"       ; @"symbolic IetH_"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic IetH_"
	.weak_definition	"_symbolic IetH_"
	.p2align	1, 0x0
"_symbolic IetH_":
	.ascii	"IetH_"
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.8"
l__swift5_reflection_descriptor.8:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic IetH_"-l__swift5_reflection_descriptor.8-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata.10
l_metadata.10:
	.quad	l_objectdestroy.9
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor.8

	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @"$sIetH_yts5Error_pIegHrzo_TRTATu"
_$sIetH_yts5Error_pIegHrzo_TRTATu:
	.long	_$sIetH_yts5Error_pIegHrzo_TRTA-_$sIetH_yts5Error_pIegHrzo_TRTATu
	.long	32                              ; 0x20

	.section	__TEXT,__swift5_entry,regular,no_dead_strip
	.p2align	2, 0x0                          ; @"\01l_entry_point"
l_entry_point:
	.long	_main-l_entry_point
	.long	1                               ; 0x1

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate5ExactVWV"
_$s9aggregate5ExactVWV:
	.quad	_$s9aggregate5ExactVwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	_$s9aggregate5ExactVwet
	.quad	_$s9aggregate5ExactVwst
	.quad	32                              ; 0x20
	.quad	32                              ; 0x20
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.9.aggregate:                     ; @.str.9.aggregate
	.asciz	"aggregate"

	.private_extern	_$s9aggregateMXM        ; @"$s9aggregateMXM"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9aggregateMXM
	.weak_definition	_$s9aggregateMXM
	.p2align	2, 0x0
_$s9aggregateMXM:
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	l_.str.9.aggregate-_$s9aggregateMXM-8

	.section	__TEXT,__const
l_.str.5.Exact:                         ; @.str.5.Exact
	.asciz	"Exact"

	.private_extern	_$s9aggregate5ExactVMn  ; @"$s9aggregate5ExactVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9aggregate5ExactVMn
	.p2align	2, 0x0
_$s9aggregate5ExactVMn:
	.long	81                              ; 0x51
	.long	_$s9aggregateMXM-_$s9aggregate5ExactVMn-4
	.long	l_.str.5.Exact-_$s9aggregate5ExactVMn-8
	.long	_$s9aggregate5ExactVMa-_$s9aggregate5ExactVMn-12
	.long	_$s9aggregate5ExactVMF-_$s9aggregate5ExactVMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate5ExactVMf"
_$s9aggregate5ExactVMf:
	.quad	0
	.quad	_$s9aggregate5ExactVWV
	.quad	512                             ; 0x200
	.quad	_$s9aggregate5ExactVMn
	.long	0                               ; 0x0
	.long	16                              ; 0x10

	.private_extern	"_symbolic _____ s6Int128V" ; @"symbolic _____ s6Int128V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ s6Int128V"
	.weak_definition	"_symbolic _____ s6Int128V"
	.p2align	1, 0x0
"_symbolic _____ s6Int128V":
	.byte	2                               ; 0x2
Ltmp1:
	.long	_$ss6Int128VMn@GOT-Ltmp1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_1:                          ; @0
	.asciz	"numerator"

l___unnamed_2:                          ; @1
	.asciz	"denominator"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s9aggregate5ExactVMF"
_$s9aggregate5ExactVMF:
	.long	"_symbolic _____ 9aggregate5ExactV"-_$s9aggregate5ExactVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	"_symbolic _____ s6Int128V"-_$s9aggregate5ExactVMF-20
	.long	l___unnamed_1-_$s9aggregate5ExactVMF-24
	.long	0                               ; 0x0
	.long	"_symbolic _____ s6Int128V"-_$s9aggregate5ExactVMF-32
	.long	l___unnamed_2-_$s9aggregate5ExactVMF-36

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate5RangeVWV"
_$s9aggregate5RangeVWV:
	.quad	_$s9aggregate5RangeVwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	_$s9aggregate5RangeVwet
	.quad	_$s9aggregate5RangeVwst
	.quad	64                              ; 0x40
	.quad	64                              ; 0x40
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.5.Range:                         ; @.str.5.Range
	.asciz	"Range"

	.private_extern	_$s9aggregate5RangeVMn  ; @"$s9aggregate5RangeVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9aggregate5RangeVMn
	.p2align	2, 0x0
_$s9aggregate5RangeVMn:
	.long	81                              ; 0x51
	.long	_$s9aggregateMXM-_$s9aggregate5RangeVMn-4
	.long	l_.str.5.Range-_$s9aggregate5RangeVMn-8
	.long	_$s9aggregate5RangeVMa-_$s9aggregate5RangeVMn-12
	.long	_$s9aggregate5RangeVMF-_$s9aggregate5RangeVMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate5RangeVMf"
_$s9aggregate5RangeVMf:
	.quad	0
	.quad	_$s9aggregate5RangeVWV
	.quad	512                             ; 0x200
	.quad	_$s9aggregate5RangeVMn
	.long	0                               ; 0x0
	.long	32                              ; 0x20

	.section	__TEXT,__swift5_reflstr
l___unnamed_3:                          ; @2
	.asciz	"start"

l___unnamed_4:                          ; @3
	.asciz	"end"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s9aggregate5RangeVMF"
_$s9aggregate5RangeVMF:
	.long	"_symbolic _____ 9aggregate5RangeV"-_$s9aggregate5RangeVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5ExactV"-_$s9aggregate5RangeVMF-20
	.long	l___unnamed_3-_$s9aggregate5RangeVMF-24
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5ExactV"-_$s9aggregate5RangeVMF-32
	.long	l___unnamed_4-_$s9aggregate5RangeVMF-36

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate9SelectionVWV"
_$s9aggregate9SelectionVWV:
	.quad	_$s9aggregate9SelectionVwCP
	.quad	_$s9aggregate9SelectionVwxx
	.quad	_$s9aggregate9SelectionVwcp
	.quad	_$s9aggregate9SelectionVwca
	.quad	___swift_memcpy72_16
	.quad	_$s9aggregate9SelectionVwta
	.quad	_$s9aggregate9SelectionVwet
	.quad	_$s9aggregate9SelectionVwst
	.quad	72                              ; 0x48
	.quad	80                              ; 0x50
	.long	33751055                        ; 0x203000f
	.long	2147483647                      ; 0x7fffffff

	.section	__TEXT,__const
l_.str.9.Selection:                     ; @.str.9.Selection
	.asciz	"Selection"

	.private_extern	_$s9aggregate9SelectionVMn ; @"$s9aggregate9SelectionVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9aggregate9SelectionVMn
	.p2align	2, 0x0
_$s9aggregate9SelectionVMn:
	.long	81                              ; 0x51
	.long	_$s9aggregateMXM-_$s9aggregate9SelectionVMn-4
	.long	l_.str.9.Selection-_$s9aggregate9SelectionVMn-8
	.long	_$s9aggregate9SelectionVMa-_$s9aggregate9SelectionVMn-12
	.long	_$s9aggregate9SelectionVMF-_$s9aggregate9SelectionVMn-16
	.long	4                               ; 0x4
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate9SelectionVMf"
_$s9aggregate9SelectionVMf:
	.quad	0
	.quad	_$s9aggregate9SelectionVWV
	.quad	512                             ; 0x200
	.quad	_$s9aggregate9SelectionVMn
	.long	0                               ; 0x0
	.long	16                              ; 0x10
	.long	32                              ; 0x20
	.long	64                              ; 0x40

	.private_extern	"_symbolic _____ 9aggregate9SelectionV" ; @"symbolic _____ 9aggregate9SelectionV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 9aggregate9SelectionV"
	.weak_definition	"_symbolic _____ 9aggregate9SelectionV"
	.p2align	1, 0x0
"_symbolic _____ 9aggregate9SelectionV":
	.byte	1                               ; 0x1
	.long	_$s9aggregate9SelectionVMn-"_symbolic _____ 9aggregate9SelectionV"-1
	.byte	0                               ; 0x0

	.private_extern	"_symbolic SS"          ; @"symbolic SS"
	.globl	"_symbolic SS"
	.weak_definition	"_symbolic SS"
	.p2align	1, 0x0
"_symbolic SS":
	.space	2,83
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_5:                          ; @4
	.asciz	"path"

	.private_extern	"_symbolic SSSg"        ; @"symbolic SSSg"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic SSSg"
	.weak_definition	"_symbolic SSSg"
	.p2align	1, 0x0
"_symbolic SSSg":
	.ascii	"SSSg"
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_6:                          ; @5
	.asciz	"id"

l___unnamed_7:                          ; @6
	.asciz	"offset"

l___unnamed_8:                          ; @7
	.asciz	"available"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s9aggregate9SelectionVMF"
_$s9aggregate9SelectionVMF:
	.long	"_symbolic _____ 9aggregate9SelectionV"-_$s9aggregate9SelectionVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	"_symbolic SS"-_$s9aggregate9SelectionVMF-20
	.long	l___unnamed_5-_$s9aggregate9SelectionVMF-24
	.long	0                               ; 0x0
	.long	"_symbolic SSSg"-_$s9aggregate9SelectionVMF-32
	.long	l___unnamed_6-_$s9aggregate9SelectionVMF-36
	.long	0                               ; 0x0
	.long	"_symbolic _____ 9aggregate5ExactV"-_$s9aggregate9SelectionVMF-44
	.long	l___unnamed_7-_$s9aggregate9SelectionVMF-48
	.long	0                               ; 0x0
	.long	"_symbolic Say_____G 9aggregate5RangeV"-_$s9aggregate9SelectionVMF-56
	.long	l___unnamed_8-_$s9aggregate9SelectionVMF-60

	.section	__TEXT,__const
l_.str.4.Main:                          ; @.str.4.Main
	.asciz	"Main"

	.private_extern	_$s9aggregate4MainVMn   ; @"$s9aggregate4MainVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s9aggregate4MainVMn
	.p2align	2, 0x0
_$s9aggregate4MainVMn:
	.long	81                              ; 0x51
	.long	_$s9aggregateMXM-_$s9aggregate4MainVMn-4
	.long	l_.str.4.Main-_$s9aggregate4MainVMn-8
	.long	_$s9aggregate4MainVMa-_$s9aggregate4MainVMn-12
	.long	_$s9aggregate4MainVMF-_$s9aggregate4MainVMn-16
	.long	0                               ; 0x0
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s9aggregate4MainVMf"
_$s9aggregate4MainVMf:
	.quad	0
	.quad	_$sytWV
	.quad	512                             ; 0x200
	.quad	_$s9aggregate4MainVMn

	.private_extern	"_symbolic _____ 9aggregate4MainV" ; @"symbolic _____ 9aggregate4MainV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 9aggregate4MainV"
	.weak_definition	"_symbolic _____ 9aggregate4MainV"
	.p2align	1, 0x0
"_symbolic _____ 9aggregate4MainV":
	.byte	1                               ; 0x1
	.long	_$s9aggregate4MainVMn-"_symbolic _____ 9aggregate4MainV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s9aggregate4MainVMF"
_$s9aggregate4MainVMF:
	.long	"_symbolic _____ 9aggregate4MainV"-_$s9aggregate4MainVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	0                               ; 0x0

	.private_extern	__swift_FORCE_LOAD_$_swiftFoundation_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftFoundation_$_aggregate"
	.section	__DATA,__const
	.globl	__swift_FORCE_LOAD_$_swiftFoundation_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftFoundation_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftFoundation_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftFoundation

	.private_extern	__swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate ; @"_swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swift_Builtin_float

	.private_extern	__swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftObjectiveC

	.private_extern	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftCoreFoundation

	.private_extern	__swift_FORCE_LOAD_$_swiftDispatch_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftDispatch_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swiftDispatch_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftDispatch_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftDispatch_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftDispatch

	.private_extern	__swift_FORCE_LOAD_$_swiftXPC_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftXPC_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swiftXPC_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftXPC_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftXPC_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftXPC

	.private_extern	__swift_FORCE_LOAD_$_swiftIOKit_$_aggregate ; @"_swift_FORCE_LOAD_$_swiftIOKit_$_aggregate"
	.globl	__swift_FORCE_LOAD_$_swiftIOKit_$_aggregate
	.weak_definition	__swift_FORCE_LOAD_$_swiftIOKit_$_aggregate
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftIOKit_$_aggregate:
	.quad	__swift_FORCE_LOAD_$_swiftIOKit

	.section	__TEXT,__cstring,cstring_literals
"l_.str.1.\n":                          ; @".str.1.\0A"
	.asciz	"\n"

"l_.str.1. ":                           ; @".str.1. "
	.asciz	" "

	.section	__TEXT,__swift5_types
	.p2align	2, 0x0                          ; @"$s9aggregate5ExactVHn"
l_$s9aggregate5ExactVHn:
	.long	_$s9aggregate5ExactVMn-l_$s9aggregate5ExactVHn

	.p2align	2, 0x0                          ; @"$s9aggregate5RangeVHn"
l_$s9aggregate5RangeVHn:
	.long	_$s9aggregate5RangeVMn-l_$s9aggregate5RangeVHn

	.p2align	2, 0x0                          ; @"$s9aggregate9SelectionVHn"
l_$s9aggregate9SelectionVHn:
	.long	_$s9aggregate9SelectionVMn-l_$s9aggregate9SelectionVHn

	.p2align	2, 0x0                          ; @"$s9aggregate4MainVHn"
l_$s9aggregate4MainVHn:
	.long	_$s9aggregate4MainVMn-l_$s9aggregate4MainVHn

	.private_extern	___swift_reflection_version ; @__swift_reflection_version
	.section	__TEXT,__const
	.globl	___swift_reflection_version
	.weak_definition	___swift_reflection_version
	.p2align	1, 0x0
___swift_reflection_version:
	.short	3                               ; 0x3

	.section	__TEXT,__swift_as_entry,coalesced,no_dead_strip
	.p2align	2, 0x0                          ; @__swift_async_entry_functlets
___swift_async_entry_functlets:
	.long	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF-___swift_async_entry_functlets
	.long	_$s9aggregate4MainV4mainyyYaFZ-___swift_async_entry_functlets-4
	.long	_$s9aggregate4MainV5$mainyyYaFZ-___swift_async_entry_functlets-8
	.long	_async_Main-___swift_async_entry_functlets-12
	.long	_$sIetH_yts5Error_pIegHrzo_TR-___swift_async_entry_functlets-16

	.section	__TEXT,__swift_as_ret,coalesced,no_dead_strip
	.p2align	2, 0x0                          ; @__swift_async_ret_functlets
___swift_async_ret_functlets:
	.long	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaFTQ1_-___swift_async_ret_functlets
	.long	_$s9aggregate4MainV4mainyyYaFZTQ1_-___swift_async_ret_functlets-4
	.long	_$s9aggregate4MainV5$mainyyYaFZTQ0_-___swift_async_ret_functlets-8
	.long	_async_MainTQ0_-___swift_async_ret_functlets-12
	.long	_$sIetH_yts5Error_pIegHrzo_TRTQ0_-___swift_async_ret_functlets-16

	.no_dead_strip	_$s9aggregate5ExactV9numerators6Int128Vvg
	.no_dead_strip	_$s9aggregate5ExactV11denominators6Int128Vvg
	.no_dead_strip	_$s9aggregate5RangeV5startAA5ExactVvg
	.no_dead_strip	_$s9aggregate5RangeV3endAA5ExactVvg
	.no_dead_strip	_$s9aggregate9SelectionV4pathSSvg
	.no_dead_strip	_$s9aggregate9SelectionV2idSSSgvg
	.no_dead_strip	_$s9aggregate9SelectionV6offsetAA5ExactVvg
	.no_dead_strip	_$s9aggregate9SelectionV9availableSayAA5RangeVGvg
	.no_dead_strip	_$s9aggregate7inspect9selection6strictyAA9SelectionV_SbtYaF
	.no_dead_strip	l__swift5_reflection_descriptor
	.no_dead_strip	l__swift5_reflection_descriptor.1
	.no_dead_strip	l__swift5_reflection_descriptor.3
	.no_dead_strip	_$s9aggregate4MainV4mainyyYaFZ
	.no_dead_strip	_main
	.no_dead_strip	l__swift5_reflection_descriptor.8
	.no_dead_strip	l_entry_point
	.no_dead_strip	_$s9aggregate5ExactVMF
	.no_dead_strip	_$s9aggregate5RangeVMF
	.no_dead_strip	_$s9aggregate9SelectionVMF
	.no_dead_strip	_$s9aggregate4MainVMF
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftFoundation_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swift_Builtin_float_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftObjectiveC_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftDispatch_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftXPC_$_aggregate
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftIOKit_$_aggregate
	.no_dead_strip	l_$s9aggregate5ExactVHn
	.no_dead_strip	l_$s9aggregate5RangeVHn
	.no_dead_strip	l_$s9aggregate9SelectionVHn
	.no_dead_strip	l_$s9aggregate4MainVHn
	.no_dead_strip	___swift_reflection_version
	.no_dead_strip	___swift_async_entry_functlets
	.no_dead_strip	___swift_async_ret_functlets
	.linker_option "-lswiftFoundation"
	.linker_option "-framework", "Foundation"
	.linker_option "-lswiftCore"
	.linker_option "-lswift_DarwinFoundation3"
	.linker_option "-lswift_DarwinFoundation1"
	.linker_option "-lswift_DarwinFoundation2"
	.linker_option "-lswift_StringProcessing"
	.linker_option "-lswift_Concurrency"
	.linker_option "-lswiftSystem"
	.linker_option "-lswiftDarwin"
	.linker_option "-lswift_Builtin_float"
	.linker_option "-lswiftObservation"
	.linker_option "-lswiftObjectiveC"
	.linker_option "-lswiftCoreFoundation"
	.linker_option "-framework", "CoreFoundation"
	.linker_option "-lswiftDispatch"
	.linker_option "-framework", "Combine"
	.linker_option "-framework", "CoreServices"
	.linker_option "-framework", "Security"
	.linker_option "-lswiftXPC"
	.linker_option "-framework", "CFNetwork"
	.linker_option "-framework", "DiskArbitration"
	.linker_option "-lswiftIOKit"
	.linker_option "-framework", "IOKit"
	.linker_option "-lswiftSwiftOnoneSupport"
	.linker_option "-lobjc"
	.section	__DATA,__objc_imageinfo,regular,no_dead_strip
L_OBJC_IMAGE_INFO:
	.long	0
	.long	100861760

	.globl	_$s9aggregate5ExactVN
	.private_extern	_$s9aggregate5ExactVN
	.alt_entry	_$s9aggregate5ExactVN
_$s9aggregate5ExactVN = _$s9aggregate5ExactVMf+16
	.globl	_$s9aggregate5RangeVN
	.private_extern	_$s9aggregate5RangeVN
	.alt_entry	_$s9aggregate5RangeVN
_$s9aggregate5RangeVN = _$s9aggregate5RangeVMf+16
	.globl	_$s9aggregate9SelectionVN
	.private_extern	_$s9aggregate9SelectionVN
	.alt_entry	_$s9aggregate9SelectionVN
_$s9aggregate9SelectionVN = _$s9aggregate9SelectionVMf+16
	.globl	_$s9aggregate4MainVN
	.private_extern	_$s9aggregate4MainVN
	.alt_entry	_$s9aggregate4MainVN
_$s9aggregate4MainVN = _$s9aggregate4MainVMf+16
	.weak_reference __swift_FORCE_LOAD_$_swiftFoundation
	.weak_reference __swift_FORCE_LOAD_$_swift_Builtin_float
	.weak_reference __swift_FORCE_LOAD_$_swiftObjectiveC
	.weak_reference __swift_FORCE_LOAD_$_swiftCoreFoundation
	.weak_reference __swift_FORCE_LOAD_$_swiftDispatch
	.weak_reference __swift_FORCE_LOAD_$_swiftXPC
	.weak_reference __swift_FORCE_LOAD_$_swiftIOKit
.subsections_via_symbols
