	.build_version macos, 26, 0	sdk_version 26, 5
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_$s3clt5ExactV9numerators6Int128Vvg ; -- Begin function $s3clt5ExactV9numerators6Int128Vvg
	.globl	_$s3clt5ExactV9numerators6Int128Vvg
	.p2align	2
_$s3clt5ExactV9numerators6Int128Vvg:    ; @"$s3clt5ExactV9numerators6Int128Vvg"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt5ExactV11denominators6Int128Vvg ; -- Begin function $s3clt5ExactV11denominators6Int128Vvg
	.globl	_$s3clt5ExactV11denominators6Int128Vvg
	.p2align	2
_$s3clt5ExactV11denominators6Int128Vvg: ; @"$s3clt5ExactV11denominators6Int128Vvg"
	.cfi_startproc
; %bb.0:
	mov	x0, x2
	mov	x1, x3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC ; -- Begin function $s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	.globl	_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	.p2align	2
_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC: ; @"$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt5RangeV5startAA5ExactVvg ; -- Begin function $s3clt5RangeV5startAA5ExactVvg
	.globl	_$s3clt5RangeV5startAA5ExactVvg
	.p2align	2
_$s3clt5RangeV5startAA5ExactVvg:        ; @"$s3clt5RangeV5startAA5ExactVvg"
	.cfi_startproc
; %bb.0:
	ldr	q1, [x20]
	ldr	q0, [x20, #16]
	mov.16b	v3, v1
	mov	d2, v1[1]
	mov.16b	v1, v0
	mov	d0, v0[1]
	fmov	x0, d3
	fmov	x1, d2
	fmov	x2, d1
	fmov	x3, d0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt5RangeV3endAA5ExactVvg ; -- Begin function $s3clt5RangeV3endAA5ExactVvg
	.globl	_$s3clt5RangeV3endAA5ExactVvg
	.p2align	2
_$s3clt5RangeV3endAA5ExactVvg:          ; @"$s3clt5RangeV3endAA5ExactVvg"
	.cfi_startproc
; %bb.0:
	ldr	q1, [x20, #32]
	ldr	q0, [x20, #48]
	mov.16b	v3, v1
	mov	d2, v1[1]
	mov.16b	v1, v0
	mov	d0, v0[1]
	fmov	x0, d3
	fmov	x1, d2
	fmov	x2, d1
	fmov	x3, d0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt5RangeV5start3endAcA5ExactV_AGtcfC ; -- Begin function $s3clt5RangeV5start3endAcA5ExactV_AGtcfC
	.globl	_$s3clt5RangeV5start3endAcA5ExactV_AGtcfC
	.p2align	2
_$s3clt5RangeV5start3endAcA5ExactV_AGtcfC: ; @"$s3clt5RangeV5start3endAcA5ExactV_AGtcfC"
	.cfi_startproc
; %bb.0:
                                        ; implicit-def: $q3
	mov.d	v3[0], x0
	mov.d	v3[1], x1
                                        ; implicit-def: $q2
	mov.d	v2[0], x2
	mov.d	v2[1], x3
                                        ; implicit-def: $q1
	mov.d	v1[0], x4
	mov.d	v1[1], x5
                                        ; implicit-def: $q0
	mov.d	v0[0], x6
	mov.d	v0[1], x7
	str	q3, [x8]
	str	q2, [x8, #16]
	str	q1, [x8, #32]
	str	q0, [x8, #48]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_ ; -- Begin function $s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_
	.globl	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_
	.p2align	2
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_: ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_"
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF ; -- Begin function $s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF
	.globl	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF
	.p2align	2
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF: ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #320
	str	x28, [sp, #288]                 ; 8-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	str	x22, [sp, #296]
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w28, -32
	str	x0, [sp]                        ; 8-byte Folded Spill
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	str	x3, [sp, #32]                   ; 8-byte Folded Spill
                                        ; implicit-def: $q0
	mov.d	v0[0], x4
	mov.d	v0[1], x5
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
                                        ; implicit-def: $q1
	mov.d	v1[0], x6
	mov.d	v1[1], x7
	str	q1, [sp, #64]                   ; 16-byte Folded Spill
	ldr	x8, [x29, #16]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	ldrb	w9, [x29, #24]
	str	w9, [sp, #116]                  ; 4-byte Folded Spill
	str	x8, [x22, #304]
	str	q1, [x22, #256]
	str	q0, [x22, #240]
	str	x1, [x22, #296]
	str	x0, [x22, #288]
	mov	x8, x22
	str	x8, [x22, #136]
	add	x8, x22, #88
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	xzr, [x22, #88]
	str	xzr, [x22, #96]
	add	x8, x22, #104
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	str	xzr, [x22, #104]
	str	xzr, [x22, #112]
	movi.2d	v0, #0000000000000000
	add	x8, x22, #208
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	str	q0, [x22, #208]
	str	q0, [x22, #224]
	add	x8, x22, #272
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	str	xzr, [x22, #272]
	add	x8, x22, #320
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	strb	wzr, [x22, #320]
	str	xzr, [x22, #120]
	str	xzr, [x22, #128]
	add	x0, x22, #144
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x14, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x13, [sp, #40]                  ; 8-byte Folded Reload
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #64]                   ; 16-byte Folded Reload
	ldr	x12, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #104]                 ; 8-byte Folded Reload
	ldr	w9, [sp, #116]                  ; 4-byte Folded Reload
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	str	x0, [x22, #88]
	str	x1, [x22, #96]
	; InlineAsm Start
	; InlineAsm End
	str	x2, [x22, #104]
	str	x3, [x22, #112]
	; InlineAsm Start
	; InlineAsm End
	str	q1, [x22, #208]
	str	q0, [x22, #224]
	; InlineAsm Start
	; InlineAsm End
	str	x11, [x22, #272]
	; InlineAsm Start
	; InlineAsm End
	and	w9, w9, #0x1
	and	w9, w9, #0x1
	strb	w9, [x22, #320]
	; InlineAsm Start
	; InlineAsm End
	ldr	x22, [x22, #136]
	adrp	x0, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_@PAGE
	add	x0, x0, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_@PAGEOFF
	mov	x2, #0                          ; =0x0
	mov	x1, x2
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldr	x28, [sp, #288]                 ; 8-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #336
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_: ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #320
	str	x28, [sp, #288]                 ; 8-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	str	x22, [sp, #296]
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w28, -32
	mov	x8, x22
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	ldr	x9, [x8, #304]
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	ldr	q0, [x8, #256]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	ldr	q0, [x8, #240]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
	ldr	x9, [x8, #296]
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x9, [x8, #288]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x22, x8
	str	x22, [x8, #136]
	mov	w8, #4                          ; =0x4
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #72]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.6.before@PAGE
	add	x0, x0, l_.str.6.before@PAGEOFF
	mov	w8, #6                          ; =0x6
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x10, _$sSSN@GOTPAGE
	ldr	x10, [x10, _$sSSN@GOTPAGEOFF]
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	str	x10, [x8, #56]
	str	x9, [x8, #32]
	str	x1, [x8, #40]
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x10, [x0, #88]
	str	x9, [x0, #64]
	str	x8, [x0, #72]
	adrp	x8, _$s3clt5ExactVMf@PAGE
	add	x8, x8, _$s3clt5ExactVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #120]
	adrp	x8, l_metadata@PAGE
	add	x8, x8, l_metadata@PAGEOFF
	add	x0, x8, #16
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #48]                   ; 16-byte Folded Reload
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x10, #96]
	str	q1, [x8, #16]
	str	q0, [x8, #32]
	adrp	x8, _$s3clt5RangeVMf@PAGE
	add	x8, x8, _$s3clt5RangeVMf@PAGEOFF
	add	x1, x8, #16
	bl	_$sSa5countSivg
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x9, _$sSiN@GOTPAGE
	ldr	x9, [x9, _$sSiN@GOTPAGEOFF]
	str	x9, [x0, #152]
	str	x8, [x0, #128]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	str	x0, [sp, #112]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	str	x1, [sp, #104]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldr	x2, [sp, #104]                  ; 8-byte Folded Reload
	mov	x3, x0
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	str	x4, [sp, #96]                   ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #104]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	adrp	x8, _$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu@GOTPAGE
	ldr	x8, [x8, _$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu@GOTPAGEOFF]
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #312]
	ldr	x8, [x8, #136]
	str	x8, [x22]
	adrp	x8, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_@PAGE
	add	x8, x8, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldr	x28, [sp, #288]                 ; 8-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #320
	b	_$sScTss5NeverORszABRs_rlE5yieldyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_: ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	str	x22, [sp, #168]
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #312]
	ldr	x8, [x22]
	str	x8, [x9, #136]
	bl	_swift_task_dealloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x22, [x8, #136]
	adrp	x0, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_@PAGE
	add	x0, x0, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_@PAGEOFF
	mov	x2, #0                          ; =0x0
	mov	x1, x2
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #192
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_: ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #464
	str	x28, [sp, #432]                 ; 8-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	str	x22, [sp, #440]
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w28, -32
	str	x22, [sp, #144]                 ; 8-byte Folded Spill
	ldr	x8, [x22, #304]
	stur	x8, [x29, #-192]                ; 8-byte Folded Spill
	ldr	q0, [x22, #256]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
	ldr	q0, [x22, #240]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
	ldr	x8, [x22, #296]
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	ldr	x8, [x22, #288]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #136]
	mov	w8, #4                          ; =0x4
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #208]                  ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #216]                  ; 8-byte Folded Spill
	adrp	x0, l_.str.5.after@PAGE
	add	x0, x0, l_.str.5.after@PAGEOFF
	mov	w8, #5                          ; =0x5
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	adrp	x10, _$sSSN@GOTPAGE
	ldr	x10, [x10, _$sSSN@GOTPAGEOFF]
	str	x10, [sp, #152]                 ; 8-byte Folded Spill
	str	x10, [x8, #56]
	str	x9, [x8, #32]
	str	x1, [x8, #40]
	bl	_swift_bridgeObjectRetain
	ldr	x0, [sp, #216]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	x10, [x0, #88]
	str	x9, [x0, #64]
	str	x8, [x0, #72]
	adrp	x8, _$s3clt5ExactVMf@PAGE
	add	x8, x8, _$s3clt5ExactVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #120]
	adrp	x8, l_metadata@PAGE
	add	x8, x8, l_metadata@PAGEOFF
	add	x0, x8, #16
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #192]                  ; 16-byte Folded Reload
	ldr	x10, [sp, #216]                 ; 8-byte Folded Reload
	mov	x8, x0
	ldur	x0, [x29, #-192]                ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x10, #96]
	str	q1, [x8, #16]
	str	q0, [x8, #32]
	adrp	x8, _$s3clt5RangeVMf@PAGE
	add	x8, x8, _$s3clt5RangeVMf@PAGEOFF
	add	x1, x8, #16
	bl	_$sSa5countSivg
	ldr	x1, [sp, #208]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #216]                  ; 8-byte Folded Reload
	adrp	x9, _$sSiN@GOTPAGE
	ldr	x9, [x9, _$sSiN@GOTPAGEOFF]
	str	x9, [x0, #152]
	str	x8, [x0, #128]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	stur	x0, [x29, #-200]                ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #224]                  ; 8-byte Folded Spill
	stur	x1, [x29, #-208]                ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldur	x2, [x29, #-208]                ; 8-byte Folded Reload
	mov	x3, x0
	ldur	x0, [x29, #-200]                ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #224]                  ; 8-byte Folded Reload
	stur	x4, [x29, #-216]                ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldur	x0, [x29, #-216]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-208]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-200]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x0, [x29, #-192]                ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRetain
	ldur	x8, [x29, #-192]                ; 8-byte Folded Reload
	add	x20, x22, #280
	str	x8, [x22, #280]
	adrp	x0, _$sSay3clt5RangeVGMd@PAGE
	add	x0, x0, _$sSay3clt5RangeVGMd@PAGEOFF
	adrp	x1, _$sSay3clt5RangeVGMR@PAGE
	add	x1, x1, _$sSay3clt5RangeVGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameV2
	stur	x0, [x29, #-184]                ; 8-byte Folded Spill
	bl	_$sSay3clt5RangeVGSayxGSlsWl
	mov	x1, x0
	ldur	x0, [x29, #-184]                ; 8-byte Folded Reload
	add	x8, x22, #120
	bl	_$sSlss16IndexingIteratorVyxG0B0RtzrlE04makeB0ACyF
	b	LBB10_1
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	adrp	x0, _$ss16IndexingIteratorVySay3clt5RangeVGGMd@PAGE
	add	x0, x0, _$ss16IndexingIteratorVySay3clt5RangeVGGMd@PAGEOFF
	adrp	x1, _$ss16IndexingIteratorVySay3clt5RangeVGGMR@PAGE
	add	x1, x1, _$ss16IndexingIteratorVySay3clt5RangeVGGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameV2
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	add	x8, x9, #16
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	add	x20, x9, #120
	bl	_$ss16IndexingIteratorV4next7ElementQzSgyF
	ldr	x1, [sp, #120]                  ; 8-byte Folded Reload
	sub	x0, x29, #96
	str	x0, [sp, #128]                  ; 8-byte Folded Spill
	mov	w8, #65                         ; =0x41
	mov	x2, x8
	str	x2, [sp, #136]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #136]                  ; 8-byte Folded Reload
	sub	x0, x29, #176
	bl	_memcpy
	ldurb	w8, [x29, #-32]
	subs	w8, w8, #1
	b.eq	LBB10_3
	b	LBB10_2
LBB10_2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldur	q3, [x29, #-176]
	str	q3, [sp]                        ; 16-byte Folded Spill
	ldur	q2, [x29, #-160]
	str	q2, [sp, #16]                   ; 16-byte Folded Spill
	ldur	q1, [x29, #-144]
	str	q1, [sp, #32]                   ; 16-byte Folded Spill
	ldur	q0, [x29, #-128]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	add	x8, x9, #144
	str	q3, [x9, #144]
	str	q2, [x9, #160]
	str	q1, [x9, #176]
	str	q0, [x9, #192]
	; InlineAsm Start
	; InlineAsm End
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	adrp	x8, _$sypN@GOTPAGE
	ldr	x8, [x8, _$sypN@GOTPAGEOFF]
	add	x1, x8, #8
	str	x1, [sp, #72]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	adrp	x8, _$s3clt5RangeVMf@PAGE
	add	x8, x8, _$s3clt5RangeVMf@PAGEOFF
	add	x8, x8, #16
	str	x8, [x0, #56]
	adrp	x8, l_metadata.5@PAGE
	add	x8, x8, l_metadata.5@PAGEOFF
	add	x0, x8, #16
	mov	w8, #80                         ; =0x50
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_allocObject
	ldr	q3, [sp]                        ; 16-byte Folded Reload
	ldr	q2, [sp, #16]                   ; 16-byte Folded Reload
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #48]                   ; 16-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	x9, x8
	str	x9, [x0, #32]
	str	q3, [x8, #16]
	str	q2, [x8, #32]
	str	q1, [x8, #48]
	str	q0, [x8, #64]
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	str	x0, [sp, #112]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	str	x1, [sp, #104]                  ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	ldr	x2, [sp, #104]                  ; 8-byte Folded Reload
	mov	x3, x0
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	mov	x4, x1
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	str	x4, [sp, #96]                   ; 8-byte Folded Spill
	bl	_$ss5print_9separator10terminatoryypd_S2StF
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #104]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	b	LBB10_1
LBB10_3:
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	add	x0, x8, #120
	bl	_$ss16IndexingIteratorVySay3clt5RangeVGGWOh
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #136]
	ldr	x0, [x9, #8]
	ldr	x22, [x8, #136]
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldr	x28, [sp, #432]                 ; 8-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #464
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy
l_objectdestroy:                        ; @objectdestroy
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #48                         ; =0x30
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss27_finalizeUninitializedArrayySayxGABnlF ; -- Begin function $ss27_finalizeUninitializedArrayySayxGABnlF
	.globl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	.weak_definition	_$ss27_finalizeUninitializedArrayySayxGABnlF
	.p2align	2
_$ss27_finalizeUninitializedArrayySayxGABnlF: ; @"$ss27_finalizeUninitializedArrayySayxGABnlF"
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x1
	str	x8, [sp, #8]
	mov	x20, sp
	str	x0, [sp]
	mov	x0, #0                          ; =0x0
	bl	_$sSaMa
	bl	_$sSa12_endMutationyyF
	ldr	x0, [sp]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss5print_9separator10terminatoryypd_S2StFfA0_ ; -- Begin function $ss5print_9separator10terminatoryypd_S2StFfA0_
	.globl	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	.weak_definition	_$ss5print_9separator10terminatoryypd_S2StFfA0_
	.p2align	2
_$ss5print_9separator10terminatoryypd_S2StFfA0_: ; @"$ss5print_9separator10terminatoryypd_S2StFfA0_"
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, "l_.str.1. "@PAGE
	add	x0, x0, "l_.str.1. "@PAGEOFF
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$ss5print_9separator10terminatoryypd_S2StFfA1_ ; -- Begin function $ss5print_9separator10terminatoryypd_S2StFfA1_
	.globl	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	.weak_definition	_$ss5print_9separator10terminatoryypd_S2StFfA1_
	.p2align	2
_$ss5print_9separator10terminatoryypd_S2StFfA1_: ; @"$ss5print_9separator10terminatoryypd_S2StFfA1_"
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x0, "l_.str.1.\n"@PAGE
	add	x0, x0, "l_.str.1.\n"@PAGEOFF
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	___swift_instantiateConcreteTypeFromMangledNameV2 ; -- Begin function __swift_instantiateConcreteTypeFromMangledNameV2
	.globl	___swift_instantiateConcreteTypeFromMangledNameV2
	.weak_definition	___swift_instantiateConcreteTypeFromMangledNameV2
	.p2align	2
___swift_instantiateConcreteTypeFromMangledNameV2: ; @__swift_instantiateConcreteTypeFromMangledNameV2
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
	stur	x8, [x29, #-8]                  ; 8-byte Folded Spill
	and	x8, x8, #0x1
	subs	x8, x8, #1
	b.eq	LBB15_3
	b	LBB15_1
LBB15_1:
	ldur	x8, [x29, #-8]                  ; 8-byte Folded Reload
	mov	x0, x8
	str	x0, [sp]                        ; 8-byte Folded Spill
	cbz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB15_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	asr	x1, x9, #32
                                        ; kill: def $w9 killed $w9 killed $x9
	add	x0, x8, w9, sxtw
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_swift_getTypeByMangledNameInContext2
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	x8, x0
	str	x8, [x9]
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB15_2
                                        ; -- End function
	.private_extern	_$sSay3clt5RangeVGSayxGSlsWl ; -- Begin function $sSay3clt5RangeVGSayxGSlsWl
	.globl	_$sSay3clt5RangeVGSayxGSlsWl
	.weak_definition	_$sSay3clt5RangeVGSayxGSlsWl
	.p2align	2
_$sSay3clt5RangeVGSayxGSlsWl:           ; @"$sSay3clt5RangeVGSayxGSlsWl"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
                                        ; implicit-def: $x8
	adrp	x8, _$sSay3clt5RangeVGSayxGSlsWL@PAGE
	ldr	x8, [x8, _$sSay3clt5RangeVGSayxGSlsWL@PAGEOFF]
	mov	x0, x8
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	cbnz	x8, LBB16_2
	b	LBB16_1
LBB16_1:
	adrp	x0, _$sSay3clt5RangeVGMd@PAGE
	add	x0, x0, _$sSay3clt5RangeVGMd@PAGEOFF
	adrp	x1, _$sSay3clt5RangeVGMR@PAGE
	add	x1, x1, _$sSay3clt5RangeVGMR@PAGEOFF
	bl	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	mov	x1, x0
	adrp	x0, _$sSayxGSlsMc@GOTPAGE
	ldr	x0, [x0, _$sSayxGSlsMc@GOTPAGEOFF]
	bl	_swift_getWitnessTable
	adrp	x9, _$sSay3clt5RangeVGSayxGSlsWL@PAGE
	add	x9, x9, _$sSay3clt5RangeVGSayxGSlsWL@PAGEOFF
	mov	x8, x0
	stlr	x8, [x9]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB16_2
LBB16_2:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_instantiateConcreteTypeFromMangledNameAbstractV2 ; -- Begin function __swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.globl	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.weak_definition	___swift_instantiateConcreteTypeFromMangledNameAbstractV2
	.p2align	2
___swift_instantiateConcreteTypeFromMangledNameAbstractV2: ; @__swift_instantiateConcreteTypeFromMangledNameAbstractV2
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
	mov	x9, x8
	stur	x9, [x29, #-8]                  ; 8-byte Folded Spill
	cbz	x8, LBB17_2
	b	LBB17_1
LBB17_1:
	ldur	x8, [x29, #-8]                  ; 8-byte Folded Reload
	and	x0, x8, #0xfffffffffffffffe
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB17_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	asr	x2, x9, #32
                                        ; kill: def $w9 killed $w9 killed $x9
	add	x1, x8, w9, sxtw
	mov	w8, #255                        ; =0xff
	mov	x0, x8
	mov	x4, #0                          ; =0x0
	mov	x3, x4
	bl	_swift_getTypeByMangledNameInContextInMetadataState2
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	orr	x8, x0, #0x1
	mov	x9, x8
	str	x9, [x10]
	stur	x8, [x29, #-8]                  ; 8-byte Folded Spill
	b	LBB17_1
                                        ; -- End function
	.private_extern	_$ss16IndexingIteratorVySay3clt5RangeVGGWOh ; -- Begin function $ss16IndexingIteratorVySay3clt5RangeVGGWOh
	.globl	_$ss16IndexingIteratorVySay3clt5RangeVGGWOh
	.weak_definition	_$ss16IndexingIteratorVySay3clt5RangeVGGWOh
	.p2align	2
_$ss16IndexingIteratorVySay3clt5RangeVGGWOh: ; @"$ss16IndexingIteratorVySay3clt5RangeVGGWOh"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x0]
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy.4
l_objectdestroy.4:                      ; @objectdestroy.4
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #80                         ; =0x50
	mov	x1, x8
	mov	w8, #15                         ; =0xf
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt4MainV4mainyyYaFZ ; -- Begin function $s3clt4MainV4mainyyYaFZ
	.globl	_$s3clt4MainV4mainyyYaFZ
	.p2align	2
_$s3clt4MainV4mainyyYaFZ:               ; @"$s3clt4MainV4mainyyYaFZ"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [x22, #80]
	mov	x0, #0                          ; =0x0
	bl	_$sScMMa
	mov	x20, x0
	str	x20, [sp, #8]                   ; 8-byte Folded Spill
	bl	_$sScM6sharedScMvgZ
	mov	x20, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x8, x20
	str	x8, [x22, #88]
	adrp	x1, _$sScMScAsWP@GOTPAGE
	ldr	x1, [x1, _$sScMScAsWP@GOTPAGEOFF]
	bl	_$sScA15unownedExecutorScevgTj
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	str	x1, [x22, #96]
	str	x2, [x22, #104]
	ldr	x22, [x22, #80]
	adrp	x0, _$s3clt4MainV4mainyyYaFZTY0_@PAGE
	add	x0, x0, _$s3clt4MainV4mainyyYaFZTY0_@PAGEOFF
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt4MainV4mainyyYaFZTY0_
_$s3clt4MainV4mainyyYaFZTY0_:           ; @"$s3clt4MainV4mainyyYaFZTY0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #208
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	str	x22, [sp, #168]
	add	x29, sp, #176
	.cfi_def_cfa w29, 32
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	str	x22, [sp, #80]                  ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #80]
	mov	x3, #0                          ; =0x0
	str	x3, [sp, #40]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x2, x8
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	mov	x0, x3
	mov	x1, x3
	bl	_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	mov	x0, x2
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x0, x3
	ldr	x3, [sp, #40]                   ; 8-byte Folded Reload
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	w8, #10                         ; =0xa
	mov	x0, x8
	mov	x1, x3
	bl	_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	mov	x4, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x5, x1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	mov	x6, x2
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	mov	x7, x3
	ldr	x3, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, x22, #16
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	bl	_$s3clt5RangeV5start3endAcA5ExactV_AGtcfC
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	; InlineAsm Start
	; InlineAsm End
	adrp	x0, "l_.str.8./fixture"@PAGE
	add	x0, x0, "l_.str.8./fixture"@PAGEOFF
	mov	w8, #8                          ; =0x8
	mov	x1, x8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #88]                   ; 4-byte Folded Spill
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	stur	x0, [x29, #-16]                 ; 8-byte Folded Spill
	stur	x1, [x29, #-64]                 ; 8-byte Folded Spill
	str	x1, [x22, #112]
	adrp	x0, l_.str.5.audio@PAGE
	add	x0, x0, l_.str.5.audio@PAGEOFF
	mov	w9, #5                          ; =0x5
	mov	x1, x9
	and	w2, w8, #0x1
	bl	_$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC
	ldr	x3, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-56]                 ; 8-byte Folded Spill
	stur	x1, [x29, #-48]                 ; 8-byte Folded Spill
	str	x1, [x22, #120]
	mov	x0, #-100                       ; =0xffffffffffffff9c
	mov	x1, #-1                         ; =0xffffffffffffffff
	bl	_$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC
	mov	x4, x0
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	stur	x4, [x29, #-40]                 ; 8-byte Folded Spill
	stur	x1, [x29, #-32]                 ; 8-byte Folded Spill
	stur	x2, [x29, #-24]                 ; 8-byte Folded Spill
	stur	x3, [x29, #-80]                 ; 8-byte Folded Spill
	adrp	x8, _$s3clt5RangeVMf@PAGE
	add	x8, x8, _$s3clt5RangeVMf@PAGEOFF
	add	x1, x8, #16
	str	x1, [sp, #72]                   ; 8-byte Folded Spill
	bl	_$ss27_allocateUninitializedArrayySayxG_BptBwlF
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	add	x0, x0, #32
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	bl	_memcpy
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	bl	_$ss27_finalizeUninitializedArrayySayxGABnlF
	stur	x0, [x29, #-72]                 ; 8-byte Folded Spill
	str	x0, [x22, #128]
	bl	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_
	stur	w0, [x29, #-84]                 ; 4-byte Folded Spill
	adrp	x8, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu@PAGE
	add	x8, x8, _$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x12, [sp, #80]                  ; 8-byte Folded Reload
	ldr	w11, [sp, #88]                  ; 4-byte Folded Reload
	ldur	w8, [x29, #-84]                 ; 4-byte Folded Reload
	ldur	x10, [x29, #-80]                ; 8-byte Folded Reload
	ldur	x9, [x29, #-72]                 ; 8-byte Folded Reload
	ldur	x1, [x29, #-64]                 ; 8-byte Folded Reload
	ldur	x2, [x29, #-56]                 ; 8-byte Folded Reload
	ldur	x3, [x29, #-48]                 ; 8-byte Folded Reload
	ldur	x4, [x29, #-40]                 ; 8-byte Folded Reload
	ldur	x5, [x29, #-32]                 ; 8-byte Folded Reload
	ldur	x6, [x29, #-24]                 ; 8-byte Folded Reload
	mov	x22, x0
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	mov	x13, x22
	str	x13, [x12, #136]
	ldr	x12, [x12, #80]
	str	x12, [x22]
	adrp	x12, _$s3clt4MainV4mainyyYaFZTQ1_@PAGE
	add	x12, x12, _$s3clt4MainV4mainyyYaFZTQ1_@PAGEOFF
	str	x12, [x22, #8]
	and	w8, w8, w11
	str	x10, [x29, #16]
	str	x9, [x29, #24]
	strb	w8, [x29, #32]
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #192
	b	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt4MainV4mainyyYaFZTQ1_
_$s3clt4MainV4mainyyYaFZTQ1_:           ; @"$s3clt4MainV4mainyyYaFZTQ1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	str	x22, [sp, #40]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	stur	x9, [x29, #-16]                 ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #136]
	ldr	x8, [x9, #128]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x8, [x9, #120]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [x9, #112]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x8, [x22]
	str	x8, [x9, #80]
	bl	_swift_task_dealloc
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_swift_bridgeObjectRelease
	ldur	x8, [x29, #-16]                 ; 8-byte Folded Reload
	ldr	x22, [x8, #80]
	ldr	x2, [x8, #104]
	ldr	x1, [x8, #96]
	adrp	x0, _$s3clt4MainV4mainyyYaFZTY2_@PAGE
	add	x0, x0, _$s3clt4MainV4mainyyYaFZTY2_@PAGEOFF
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #64
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt4MainV4mainyyYaFZTY2_
_$s3clt4MainV4mainyyYaFZTY2_:           ; @"$s3clt4MainV4mainyyYaFZTY2_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x22, #88]
	mov	x8, x22
	str	x8, [x22, #80]
	bl	_swift_release
	ldr	x8, [x22, #80]
	ldr	x0, [x8, #8]
	ldr	x22, [x22, #80]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt4MainV5$mainyyYaFZ ; -- Begin function $s3clt4MainV5$mainyyYaFZ
	.globl	_$s3clt4MainV5$mainyyYaFZ
	.p2align	2
_$s3clt4MainV5$mainyyYaFZ:              ; @"$s3clt4MainV5$mainyyYaFZ"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x22, [sp]                       ; 8-byte Folded Spill
	mov	x8, x22
	str	x8, [x22, #16]
	mov	x0, #0                          ; =0x0
	bl	_$sScMMa
	mov	x20, x0
	mov	x0, x20
	str	x0, [x22, #24]
	bl	_$sScM6sharedScMvgZ
	str	x0, [x22, #32]
	adrp	x8, _$s3clt4MainV4mainyyYaFZTu@PAGE
	add	x8, x8, _$s3clt4MainV4mainyyYaFZTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #40]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _$s3clt4MainV5$mainyyYaFZTQ0_@PAGE
	add	x8, x8, _$s3clt4MainV5$mainyyYaFZTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	b	_$s3clt4MainV4mainyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt4MainV5$mainyyYaFZTQ0_
_$s3clt4MainV5$mainyyYaFZTQ0_:          ; @"$s3clt4MainV5$mainyyYaFZTQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #40]
	ldr	x20, [x9, #32]
	ldr	x8, [x9, #24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	adrp	x1, _$sScMScAsWP@GOTPAGE
	ldr	x1, [x1, _$sScMScAsWP@GOTPAGEOFF]
	bl	_$sScA15unownedExecutorScevgTj
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	adrp	x0, _$s3clt4MainV5$mainyyYaFZTY1_@PAGE
	add	x0, x0, _$s3clt4MainV5$mainyyYaFZTY1_@PAGEOFF
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	b	_swift_task_switch
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt4MainV5$mainyyYaFZTY1_
_$s3clt4MainV5$mainyyYaFZTY1_:          ; @"$s3clt4MainV5$mainyyYaFZTY1_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x22, #32]
	mov	x8, x22
	str	x8, [x22, #16]
	bl	_swift_release
	ldr	x8, [x22, #16]
	ldr	x0, [x8, #8]
	ldr	x22, [x22, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt4MainVACycfC     ; -- Begin function $s3clt4MainVACycfC
	.globl	_$s3clt4MainVACycfC
	.p2align	2
_$s3clt4MainVACycfC:                    ; @"$s3clt4MainVACycfC"
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function async_Main
_async_Main:                            ; @async_Main
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	x22, x8
	str	x22, [x8, #16]
	adrp	x8, _$s3clt4MainV5$mainyyYaFZTu@PAGE
	add	x8, x8, _$s3clt4MainV5$mainyyYaFZTu@PAGEOFF
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	x22, x0
	mov	x0, x22
	str	x0, [x8, #24]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _async_MainTQ0_@PAGE
	add	x8, x8, _async_MainTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	b	_$s3clt4MainV5$mainyyYaFZ
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function async_MainTQ0_
_async_MainTQ0_:                        ; @async_MainTQ0_
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	mov	w0, #0                          ; =0x0
	bl	_exit
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, l_metadata.10@PAGE
	add	x8, x8, l_metadata.10@PAGEOFF
	add	x0, x8, #16
	mov	w8, #24                         ; =0x18
	mov	x1, x8
	mov	w8, #7                          ; =0x7
	mov	x2, x8
	bl	_swift_allocObject
	mov	x4, x0
	adrp	x8, _async_MainTu@PAGE
	add	x8, x8, _async_MainTu@PAGEOFF
	str	x8, [x4, #16]
	mov	w8, #2048                       ; =0x800
	mov	x0, x8
	mov	x1, #0                          ; =0x0
	adrp	x8, _$sytN@GOTPAGE
	ldr	x8, [x8, _$sytN@GOTPAGEOFF]
	add	x2, x8, #8
	adrp	x3, _$sIetH_yts5Error_pIegHrzo_TRTATu@PAGE
	add	x3, x3, _$sIetH_yts5Error_pIegHrzo_TRTATu@PAGEOFF
	bl	_swift_task_create
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_swift_task_getMainExecutor
	mov	x2, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, x1
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	bl	_swift_job_run
	bl	_swift_task_asyncMainDrainQueue
	brk	#0x1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$sIetH_yts5Error_pIegHrzo_TR ; -- Begin function $sIetH_yts5Error_pIegHrzo_TR
	.globl	_$sIetH_yts5Error_pIegHrzo_TR
	.weak_definition	_$sIetH_yts5Error_pIegHrzo_TR
	.p2align	2
_$sIetH_yts5Error_pIegHrzo_TR:          ; @"$sIetH_yts5Error_pIegHrzo_TR"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	str	x22, [sp, #24]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x22
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x22, x8
	str	x22, [x8, #16]
	ldrsw	x9, [x1]
	mov	x8, x1
	add	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w8, [x1, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	x22, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x9, x22
	str	x9, [x8, #24]
	ldr	x8, [x8, #16]
	str	x8, [x22]
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTQ0_@PAGE
	add	x8, x8, _$sIetH_yts5Error_pIegHrzo_TRTQ0_@PAGEOFF
	str	x8, [x22, #8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #48
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTQ0_
_$sIetH_yts5Error_pIegHrzo_TRTQ0_:      ; @"$sIetH_yts5Error_pIegHrzo_TRTQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	ldr	x0, [x22, #8]
	mov	x20, #0                         ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function objectdestroy.9
l_objectdestroy.9:                      ; @objectdestroy.9
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x20
	mov	w8, #24                         ; =0x18
	mov	x1, x8
	mov	w8, #7                          ; =0x7
	mov	x2, x8
	bl	_swift_deallocObject
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTA
_$sIetH_yts5Error_pIegHrzo_TRTA:        ; @"$sIetH_yts5Error_pIegHrzo_TRTA"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	str	x22, [sp, #40]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]                 ; 8-byte Folded Spill
	mov	x9, x22
	str	x9, [sp]                        ; 8-byte Folded Spill
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGE
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGE
	add	x8, x8, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGEOFF
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x22, x9
	str	x22, [x9, #16]
	ldr	x9, [x20, #16]
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_swift_task_alloc
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x22, x0
	ldur	x0, [x29, #-16]                 ; 8-byte Folded Reload
	mov	x11, x22
	str	x11, [x10, #24]
	ldr	x10, [x10, #16]
	str	x10, [x22]
	adrp	x10, _$sIetH_yts5Error_pIegHrzo_TRTATQ0_@PAGE
	add	x10, x10, _$sIetH_yts5Error_pIegHrzo_TRTATQ0_@PAGEOFF
	str	x10, [x22, #8]
	ldrsw	x9, [x9, _$sIetH_yts5Error_pIegHrzo_TRTu@PAGEOFF]
	add	x2, x8, x9
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #64
	br	x2
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $sIetH_yts5Error_pIegHrzo_TRTATQ0_
_$sIetH_yts5Error_pIegHrzo_TRTATQ0_:    ; @"$sIetH_yts5Error_pIegHrzo_TRTATQ0_"
	.cfi_startproc
; %bb.0:
	orr	x29, x29, #0x1000000000000000
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x22]
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	x8, x29
	sub	x8, x8, #8
	str	x9, [x8]
	ldr	x0, [x9, #24]
	ldr	x8, [x22]
	str	x8, [x9, #16]
	bl	_swift_task_dealloc
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x22, [x8, #16]
	ldr	x0, [x22, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	and	x29, x29, #0xefffffffffffffff
	add	sp, sp, #32
	br	x0
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5ExactVwCP
_$s3clt5ExactVwCP:                      ; @"$s3clt5ExactVwCP"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x1]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_retain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	x8, [x0]
	add	x0, x8, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_noop_void_return ; -- Begin function __swift_noop_void_return
	.globl	___swift_noop_void_return
	.weak_definition	___swift_noop_void_return
	.p2align	2
___swift_noop_void_return:              ; @__swift_noop_void_return
; %bb.0:
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy32_16    ; -- Begin function __swift_memcpy32_16
	.globl	___swift_memcpy32_16
	.weak_definition	___swift_memcpy32_16
	.p2align	2
___swift_memcpy32_16:                   ; @__swift_memcpy32_16
; %bb.0:
	ldr	q0, [x1]
	str	q0, [x0]
	ldr	q0, [x1, #16]
	str	q0, [x0, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5ExactVwet
_$s3clt5ExactVwet:                      ; @"$s3clt5ExactVwet"
; %bb.0:
	sub	sp, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w1, LBB39_14
	b	LBB39_1
LBB39_1:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	b.ls	LBB39_13
	b	LBB39_2
LBB39_2:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB39_4
	b	LBB39_3
LBB39_3:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_11
LBB39_4:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB39_6
	b	LBB39_5
LBB39_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_11
LBB39_6:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB39_8
	b	LBB39_7
LBB39_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_11
LBB39_8:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB39_10
	b	LBB39_9
LBB39_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_11
LBB39_10:
	brk	#0x1
LBB39_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB39_13
	b	LBB39_12
LBB39_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	subs	w9, w9, #1
	mov	w10, #256                       ; =0x100
	lsl	w10, w9, w10
	mov	w9, #0                          ; =0x0
	mov	w11, #1                         ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	ldr	x8, [x8]
                                        ; kill: def $w8 killed $w8 killed $x8
	orr	w8, w8, w9
	add	w8, w8, #0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB39_15
LBB39_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB39_15
LBB39_14:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB39_15
LBB39_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	add	w0, w8, #1
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5ExactVwst
_$s3clt5ExactVwst:                      ; @"$s3clt5ExactVwst"
; %bb.0:
	sub	sp, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
                                        ; implicit-def: $w8
	mov	w8, #0                          ; =0x0
	subs	w9, w2, #0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.ls	LBB40_2
	b	LBB40_1
LBB40_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB40_2
LBB40_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #0
	b.hi	LBB40_14
	b	LBB40_3
LBB40_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbnz	w8, LBB40_5
	b	LBB40_4
LBB40_4:
	b	LBB40_12
LBB40_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB40_7
	b	LBB40_6
LBB40_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #32]
	b	LBB40_12
LBB40_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB40_9
	b	LBB40_8
LBB40_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strh	wzr, [x8, #32]
	b	LBB40_12
LBB40_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB40_11
	b	LBB40_10
LBB40_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #32]
	b	LBB40_12
LBB40_11:
	brk	#0x1
LBB40_12:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	cbz	w8, LBB40_26
	b	LBB40_13
LBB40_13:
	b	LBB40_26
LBB40_14:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	add	w9, w8, #0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x10, x8
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB40_16
	b	LBB40_15
LBB40_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	mov	w9, #256                        ; =0x100
	lsr	w9, w10, w9
	add	w9, w9, #1
	and	w8, w8, w10
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB40_16
LBB40_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #20]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	str	w11, [sp, #8]                   ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $x11 killed $w11
	bfi	x10, x11, #32, #32
	str	x10, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	str	xzr, [x9, #24]
	cbnz	w8, LBB40_18
	b	LBB40_17
LBB40_17:
	b	LBB40_25
LBB40_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB40_20
	b	LBB40_19
LBB40_19:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strb	w8, [x9, #32]
	b	LBB40_25
LBB40_20:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB40_22
	b	LBB40_21
LBB40_21:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strh	w8, [x9, #32]
	b	LBB40_25
LBB40_22:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB40_24
	b	LBB40_23
LBB40_23:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #32]
	b	LBB40_25
LBB40_24:
	brk	#0x1
LBB40_25:
	b	LBB40_26
LBB40_26:
	add	sp, sp, #48
	ret
                                        ; -- End function
	.private_extern	_$s3clt5ExactVMa        ; -- Begin function $s3clt5ExactVMa
	.globl	_$s3clt5ExactVMa
	.p2align	2
_$s3clt5ExactVMa:                       ; @"$s3clt5ExactVMa"
; %bb.0:
	adrp	x8, _$s3clt5ExactVMf@PAGE
	add	x8, x8, _$s3clt5ExactVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5RangeVwCP
_$s3clt5RangeVwCP:                      ; @"$s3clt5RangeVwCP"
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [x1]
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_swift_retain
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	x8, [x0]
	add	x0, x8, #16
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.private_extern	___swift_memcpy64_16    ; -- Begin function __swift_memcpy64_16
	.globl	___swift_memcpy64_16
	.weak_definition	___swift_memcpy64_16
	.p2align	2
___swift_memcpy64_16:                   ; @__swift_memcpy64_16
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, #64                         ; =0x40
	mov	x2, x8
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5RangeVwet
_$s3clt5RangeVwet:                      ; @"$s3clt5RangeVwet"
; %bb.0:
	sub	sp, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w1, LBB44_14
	b	LBB44_1
LBB44_1:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	b.ls	LBB44_13
	b	LBB44_2
LBB44_2:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB44_4
	b	LBB44_3
LBB44_3:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB44_11
LBB44_4:
	mov	w8, #1                          ; =0x1
	tbz	w8, #0, LBB44_6
	b	LBB44_5
LBB44_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB44_11
LBB44_6:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB44_8
	b	LBB44_7
LBB44_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB44_11
LBB44_8:
	mov	w8, #0                          ; =0x0
	tbz	w8, #0, LBB44_10
	b	LBB44_9
LBB44_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #64]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB44_11
LBB44_10:
	brk	#0x1
LBB44_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB44_13
	b	LBB44_12
LBB44_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	subs	w9, w9, #1
	mov	w10, #512                       ; =0x200
	lsl	w10, w9, w10
	mov	w9, #0                          ; =0x0
	mov	w11, #1                         ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	ldr	x8, [x8]
                                        ; kill: def $w8 killed $w8 killed $x8
	orr	w8, w8, w9
	add	w8, w8, #0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB44_15
LBB44_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB44_15
LBB44_14:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB44_15
LBB44_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	add	w0, w8, #1
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function $s3clt5RangeVwst
_$s3clt5RangeVwst:                      ; @"$s3clt5RangeVwst"
; %bb.0:
	sub	sp, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
                                        ; implicit-def: $w8
	mov	w8, #0                          ; =0x0
	subs	w9, w2, #0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.ls	LBB45_2
	b	LBB45_1
LBB45_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB45_2
LBB45_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #0
	b.hi	LBB45_14
	b	LBB45_3
LBB45_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbnz	w8, LBB45_5
	b	LBB45_4
LBB45_4:
	b	LBB45_12
LBB45_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB45_7
	b	LBB45_6
LBB45_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #64]
	b	LBB45_12
LBB45_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB45_9
	b	LBB45_8
LBB45_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strh	wzr, [x8, #64]
	b	LBB45_12
LBB45_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB45_11
	b	LBB45_10
LBB45_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #64]
	b	LBB45_12
LBB45_11:
	brk	#0x1
LBB45_12:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	cbz	w8, LBB45_26
	b	LBB45_13
LBB45_13:
	b	LBB45_26
LBB45_14:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	add	w9, w8, #0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	x10, x8
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB45_16
	b	LBB45_15
LBB45_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	mov	w9, #512                        ; =0x200
	lsr	w9, w10, w9
	add	w9, w9, #1
	and	w8, w8, w10
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB45_16
LBB45_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #20]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	str	w11, [sp, #8]                   ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $x11 killed $w11
	bfi	x10, x11, #32, #32
	str	x10, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	str	xzr, [x9, #24]
	str	xzr, [x9, #32]
	str	xzr, [x9, #40]
	str	xzr, [x9, #48]
	str	xzr, [x9, #56]
	cbnz	w8, LBB45_18
	b	LBB45_17
LBB45_17:
	b	LBB45_25
LBB45_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB45_20
	b	LBB45_19
LBB45_19:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strb	w8, [x9, #64]
	b	LBB45_25
LBB45_20:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.ne	LBB45_22
	b	LBB45_21
LBB45_21:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	strh	w8, [x9, #64]
	b	LBB45_25
LBB45_22:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB45_24
	b	LBB45_23
LBB45_23:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #64]
	b	LBB45_25
LBB45_24:
	brk	#0x1
LBB45_25:
	b	LBB45_26
LBB45_26:
	add	sp, sp, #48
	ret
                                        ; -- End function
	.private_extern	_$s3clt5RangeVMa        ; -- Begin function $s3clt5RangeVMa
	.globl	_$s3clt5RangeVMa
	.p2align	2
_$s3clt5RangeVMa:                       ; @"$s3clt5RangeVMa"
; %bb.0:
	adrp	x8, _$s3clt5RangeVMf@PAGE
	add	x8, x8, _$s3clt5RangeVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.private_extern	_$s3clt4MainVMa         ; -- Begin function $s3clt4MainVMa
	.globl	_$s3clt4MainVMa
	.p2align	2
_$s3clt4MainVMa:                        ; @"$s3clt4MainVMa"
; %bb.0:
	adrp	x8, _$s3clt4MainVMf@PAGE
	add	x8, x8, _$s3clt4MainVMf@PAGEOFF
	add	x0, x8, #16
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.private_extern	_$sSa12_endMutationyyF  ; -- Begin function $sSa12_endMutationyyF
	.globl	_$sSa12_endMutationyyF
	.weak_definition	_$sSa12_endMutationyyF
	.p2align	2
_$sSa12_endMutationyyF:                 ; @"$sSa12_endMutationyyF"
	.cfi_startproc
; %bb.0:
	ldr	x8, [x20]
	str	x8, [x20]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu ; @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu"
	.section	__TEXT,__const
	.globl	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu
	.p2align	3, 0x0
_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu:
	.long	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF-_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu
	.long	336                             ; 0x150

	.section	__TEXT,__cstring,cstring_literals
l_.str.6.before:                        ; @.str.6.before
	.asciz	"before"

	.private_extern	"_symbolic _____ 3clt5ExactV" ; @"symbolic _____ 3clt5ExactV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 3clt5ExactV"
	.weak_definition	"_symbolic _____ 3clt5ExactV"
	.p2align	1, 0x0
"_symbolic _____ 3clt5ExactV":
	.byte	1                               ; 0x1
	.long	_$s3clt5ExactVMn-"_symbolic _____ 3clt5ExactV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor"
l__swift5_reflection_descriptor:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 3clt5ExactV"-l__swift5_reflection_descriptor-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata
l_metadata:
	.quad	l_objectdestroy
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor

	.section	__TEXT,__cstring,cstring_literals
l_.str.5.after:                         ; @.str.5.after
	.asciz	"after"

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.1"
l__swift5_reflection_descriptor.1:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 3clt5ExactV"-l__swift5_reflection_descriptor.1-12

	.private_extern	"_symbolic Say_____G 3clt5RangeV" ; @"symbolic Say_____G 3clt5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic Say_____G 3clt5RangeV"
	.weak_definition	"_symbolic Say_____G 3clt5RangeV"
	.p2align	1, 0x0
"_symbolic Say_____G 3clt5RangeV":
	.ascii	"Say"
	.byte	1                               ; 0x1
	.long	_$s3clt5RangeVMn-"_symbolic Say_____G 3clt5RangeV"-4
	.byte	71
	.byte	0                               ; 0x0

	.private_extern	_$sSay3clt5RangeVGMd    ; @"$sSay3clt5RangeVGMd"
	.section	__DATA,__data
	.globl	_$sSay3clt5RangeVGMd
	.weak_definition	_$sSay3clt5RangeVGMd
	.p2align	3, 0x0
_$sSay3clt5RangeVGMd:
	.space	8

	.private_extern	_$sSay3clt5RangeVGMR    ; @"$sSay3clt5RangeVGMR"
	.section	__TEXT,__const
	.globl	_$sSay3clt5RangeVGMR
	.weak_definition	_$sSay3clt5RangeVGMR
	.p2align	3, 0x0
_$sSay3clt5RangeVGMR:
	.long	"_symbolic Say_____G 3clt5RangeV"-_$sSay3clt5RangeVGMR
	.long	9                               ; 0x9

	.private_extern	_$sSay3clt5RangeVGSayxGSlsWL ; @"$sSay3clt5RangeVGSayxGSlsWL"
	.section	__DATA,__data
	.globl	_$sSay3clt5RangeVGSayxGSlsWL
	.weak_definition	_$sSay3clt5RangeVGSayxGSlsWL
	.p2align	3, 0x0
_$sSay3clt5RangeVGSayxGSlsWL:
	.quad	0

	.private_extern	"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV" ; @"symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV"
	.weak_definition	"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV"
	.p2align	1, 0x0
"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV":
	.byte	2                               ; 0x2
Ltmp0:
	.long	_$ss16IndexingIteratorVMn@GOT-Ltmp0
	.ascii	"ySay"
	.byte	1                               ; 0x1
	.long	_$s3clt5RangeVMn-"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV"-10
	.space	2,71
	.byte	0                               ; 0x0

	.private_extern	_$ss16IndexingIteratorVySay3clt5RangeVGGMd ; @"$ss16IndexingIteratorVySay3clt5RangeVGGMd"
	.section	__DATA,__data
	.globl	_$ss16IndexingIteratorVySay3clt5RangeVGGMd
	.weak_definition	_$ss16IndexingIteratorVySay3clt5RangeVGGMd
	.p2align	3, 0x0
_$ss16IndexingIteratorVySay3clt5RangeVGGMd:
	.space	8

	.private_extern	_$ss16IndexingIteratorVySay3clt5RangeVGGMR ; @"$ss16IndexingIteratorVySay3clt5RangeVGGMR"
	.section	__TEXT,__const
	.globl	_$ss16IndexingIteratorVySay3clt5RangeVGGMR
	.weak_definition	_$ss16IndexingIteratorVySay3clt5RangeVGGMR
	.p2align	3, 0x0
_$ss16IndexingIteratorVySay3clt5RangeVGGMR:
	.long	"_symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV"-_$ss16IndexingIteratorVySay3clt5RangeVGGMR
	.long	16                              ; 0x10

	.private_extern	"_symbolic _____ 3clt5RangeV" ; @"symbolic _____ 3clt5RangeV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 3clt5RangeV"
	.weak_definition	"_symbolic _____ 3clt5RangeV"
	.p2align	1, 0x0
"_symbolic _____ 3clt5RangeV":
	.byte	1                               ; 0x1
	.long	_$s3clt5RangeVMn-"_symbolic _____ 3clt5RangeV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.3"
l__swift5_reflection_descriptor.3:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic _____ 3clt5RangeV"-l__swift5_reflection_descriptor.3-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata.5
l_metadata.5:
	.quad	l_objectdestroy.4
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor.3

	.private_extern	_$s3clt4MainV4mainyyYaFZTu ; @"$s3clt4MainV4mainyyYaFZTu"
	.section	__TEXT,__const
	.globl	_$s3clt4MainV4mainyyYaFZTu
	.p2align	3, 0x0
_$s3clt4MainV4mainyyYaFZTu:
	.long	_$s3clt4MainV4mainyyYaFZ-_$s3clt4MainV4mainyyYaFZTu
	.long	144                             ; 0x90

	.section	__TEXT,__cstring,cstring_literals
"l_.str.8./fixture":                    ; @".str.8./fixture"
	.asciz	"/fixture"

l_.str.5.audio:                         ; @.str.5.audio
	.asciz	"audio"

	.private_extern	_$s3clt4MainV5$mainyyYaFZTu ; @"$s3clt4MainV5$mainyyYaFZTu"
	.section	__TEXT,__const
	.globl	_$s3clt4MainV5$mainyyYaFZTu
	.p2align	3, 0x0
_$s3clt4MainV5$mainyyYaFZTu:
	.long	_$s3clt4MainV5$mainyyYaFZ-_$s3clt4MainV5$mainyyYaFZTu
	.long	48                              ; 0x30

	.p2align	3, 0x0                          ; @async_MainTu
_async_MainTu:
	.long	_async_Main-_async_MainTu
	.long	32                              ; 0x20

	.private_extern	_$sIetH_yts5Error_pIegHrzo_TRTu ; @"$sIetH_yts5Error_pIegHrzo_TRTu"
	.globl	_$sIetH_yts5Error_pIegHrzo_TRTu
	.weak_definition	_$sIetH_yts5Error_pIegHrzo_TRTu
	.p2align	3, 0x0
_$sIetH_yts5Error_pIegHrzo_TRTu:
	.long	_$sIetH_yts5Error_pIegHrzo_TR-_$sIetH_yts5Error_pIegHrzo_TRTu
	.long	32                              ; 0x20

	.private_extern	"_symbolic IetH_"       ; @"symbolic IetH_"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic IetH_"
	.weak_definition	"_symbolic IetH_"
	.p2align	1, 0x0
"_symbolic IetH_":
	.ascii	"IetH_"
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_capture
	.p2align	2, 0x0                          ; @"\01l__swift5_reflection_descriptor.8"
l__swift5_reflection_descriptor.8:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	"_symbolic IetH_"-l__swift5_reflection_descriptor.8-12

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @metadata.10
l_metadata.10:
	.quad	l_objectdestroy.9
	.quad	0
	.quad	1024                            ; 0x400
	.long	16                              ; 0x10
	.space	4
	.quad	l__swift5_reflection_descriptor.8

	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @"$sIetH_yts5Error_pIegHrzo_TRTATu"
_$sIetH_yts5Error_pIegHrzo_TRTATu:
	.long	_$sIetH_yts5Error_pIegHrzo_TRTA-_$sIetH_yts5Error_pIegHrzo_TRTATu
	.long	32                              ; 0x20

	.section	__TEXT,__swift5_entry,regular,no_dead_strip
	.p2align	2, 0x0                          ; @"\01l_entry_point"
l_entry_point:
	.long	_main-l_entry_point
	.long	1                               ; 0x1

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s3clt5ExactVWV"
_$s3clt5ExactVWV:
	.quad	_$s3clt5ExactVwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	___swift_memcpy32_16
	.quad	_$s3clt5ExactVwet
	.quad	_$s3clt5ExactVwst
	.quad	32                              ; 0x20
	.quad	32                              ; 0x20
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.3.clt:                           ; @.str.3.clt
	.asciz	"clt"

	.private_extern	_$s3cltMXM              ; @"$s3cltMXM"
	.section	__TEXT,__constg_swiftt
	.globl	_$s3cltMXM
	.weak_definition	_$s3cltMXM
	.p2align	2, 0x0
_$s3cltMXM:
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	l_.str.3.clt-_$s3cltMXM-8

	.section	__TEXT,__const
l_.str.5.Exact:                         ; @.str.5.Exact
	.asciz	"Exact"

	.private_extern	_$s3clt5ExactVMn        ; @"$s3clt5ExactVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s3clt5ExactVMn
	.p2align	2, 0x0
_$s3clt5ExactVMn:
	.long	81                              ; 0x51
	.long	_$s3cltMXM-_$s3clt5ExactVMn-4
	.long	l_.str.5.Exact-_$s3clt5ExactVMn-8
	.long	_$s3clt5ExactVMa-_$s3clt5ExactVMn-12
	.long	_$s3clt5ExactVMF-_$s3clt5ExactVMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s3clt5ExactVMf"
_$s3clt5ExactVMf:
	.quad	0
	.quad	_$s3clt5ExactVWV
	.quad	512                             ; 0x200
	.quad	_$s3clt5ExactVMn
	.long	0                               ; 0x0
	.long	16                              ; 0x10

	.private_extern	"_symbolic _____ s6Int128V" ; @"symbolic _____ s6Int128V"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ s6Int128V"
	.weak_definition	"_symbolic _____ s6Int128V"
	.p2align	1, 0x0
"_symbolic _____ s6Int128V":
	.byte	2                               ; 0x2
Ltmp1:
	.long	_$ss6Int128VMn@GOT-Ltmp1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_reflstr
l___unnamed_1:                          ; @0
	.asciz	"numerator"

l___unnamed_2:                          ; @1
	.asciz	"denominator"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s3clt5ExactVMF"
_$s3clt5ExactVMF:
	.long	"_symbolic _____ 3clt5ExactV"-_$s3clt5ExactVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	"_symbolic _____ s6Int128V"-_$s3clt5ExactVMF-20
	.long	l___unnamed_1-_$s3clt5ExactVMF-24
	.long	0                               ; 0x0
	.long	"_symbolic _____ s6Int128V"-_$s3clt5ExactVMF-32
	.long	l___unnamed_2-_$s3clt5ExactVMF-36

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s3clt5RangeVWV"
_$s3clt5RangeVWV:
	.quad	_$s3clt5RangeVwCP
	.quad	___swift_noop_void_return
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	___swift_memcpy64_16
	.quad	_$s3clt5RangeVwet
	.quad	_$s3clt5RangeVwst
	.quad	64                              ; 0x40
	.quad	64                              ; 0x40
	.long	131087                          ; 0x2000f
	.long	0                               ; 0x0

	.section	__TEXT,__const
l_.str.5.Range:                         ; @.str.5.Range
	.asciz	"Range"

	.private_extern	_$s3clt5RangeVMn        ; @"$s3clt5RangeVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s3clt5RangeVMn
	.p2align	2, 0x0
_$s3clt5RangeVMn:
	.long	81                              ; 0x51
	.long	_$s3cltMXM-_$s3clt5RangeVMn-4
	.long	l_.str.5.Range-_$s3clt5RangeVMn-8
	.long	_$s3clt5RangeVMa-_$s3clt5RangeVMn-12
	.long	_$s3clt5RangeVMF-_$s3clt5RangeVMn-16
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s3clt5RangeVMf"
_$s3clt5RangeVMf:
	.quad	0
	.quad	_$s3clt5RangeVWV
	.quad	512                             ; 0x200
	.quad	_$s3clt5RangeVMn
	.long	0                               ; 0x0
	.long	32                              ; 0x20

	.section	__TEXT,__swift5_reflstr
l___unnamed_3:                          ; @2
	.asciz	"start"

l___unnamed_4:                          ; @3
	.asciz	"end"

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s3clt5RangeVMF"
_$s3clt5RangeVMF:
	.long	"_symbolic _____ 3clt5RangeV"-_$s3clt5RangeVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	"_symbolic _____ 3clt5ExactV"-_$s3clt5RangeVMF-20
	.long	l___unnamed_3-_$s3clt5RangeVMF-24
	.long	0                               ; 0x0
	.long	"_symbolic _____ 3clt5ExactV"-_$s3clt5RangeVMF-32
	.long	l___unnamed_4-_$s3clt5RangeVMF-36

	.section	__TEXT,__const
l_.str.4.Main:                          ; @.str.4.Main
	.asciz	"Main"

	.private_extern	_$s3clt4MainVMn         ; @"$s3clt4MainVMn"
	.section	__TEXT,__constg_swiftt
	.globl	_$s3clt4MainVMn
	.p2align	2, 0x0
_$s3clt4MainVMn:
	.long	81                              ; 0x51
	.long	_$s3cltMXM-_$s3clt4MainVMn-4
	.long	l_.str.4.Main-_$s3clt4MainVMn-8
	.long	_$s3clt4MainVMa-_$s3clt4MainVMn-12
	.long	_$s3clt4MainVMF-_$s3clt4MainVMn-16
	.long	0                               ; 0x0
	.long	2                               ; 0x2

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @"$s3clt4MainVMf"
_$s3clt4MainVMf:
	.quad	0
	.quad	_$sytWV
	.quad	512                             ; 0x200
	.quad	_$s3clt4MainVMn

	.private_extern	"_symbolic _____ 3clt4MainV" ; @"symbolic _____ 3clt4MainV"
	.section	__TEXT,__swift5_typeref
	.globl	"_symbolic _____ 3clt4MainV"
	.weak_definition	"_symbolic _____ 3clt4MainV"
	.p2align	1, 0x0
"_symbolic _____ 3clt4MainV":
	.byte	1                               ; 0x1
	.long	_$s3clt4MainVMn-"_symbolic _____ 3clt4MainV"-1
	.byte	0                               ; 0x0

	.section	__TEXT,__swift5_fieldmd
	.p2align	2, 0x0                          ; @"$s3clt4MainVMF"
_$s3clt4MainVMF:
	.long	"_symbolic _____ 3clt4MainV"-_$s3clt4MainVMF
	.long	0                               ; 0x0
	.short	0                               ; 0x0
	.short	12                              ; 0xc
	.long	0                               ; 0x0

	.private_extern	__swift_FORCE_LOAD_$_swiftFoundation_$_clt ; @"_swift_FORCE_LOAD_$_swiftFoundation_$_clt"
	.section	__DATA,__const
	.globl	__swift_FORCE_LOAD_$_swiftFoundation_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftFoundation_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftFoundation_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftFoundation

	.private_extern	__swift_FORCE_LOAD_$_swift_Builtin_float_$_clt ; @"_swift_FORCE_LOAD_$_swift_Builtin_float_$_clt"
	.globl	__swift_FORCE_LOAD_$_swift_Builtin_float_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swift_Builtin_float_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swift_Builtin_float_$_clt:
	.quad	__swift_FORCE_LOAD_$_swift_Builtin_float

	.private_extern	__swift_FORCE_LOAD_$_swiftObjectiveC_$_clt ; @"_swift_FORCE_LOAD_$_swiftObjectiveC_$_clt"
	.globl	__swift_FORCE_LOAD_$_swiftObjectiveC_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftObjectiveC_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftObjectiveC_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftObjectiveC

	.private_extern	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt ; @"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt"
	.globl	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftCoreFoundation

	.private_extern	__swift_FORCE_LOAD_$_swiftDispatch_$_clt ; @"_swift_FORCE_LOAD_$_swiftDispatch_$_clt"
	.globl	__swift_FORCE_LOAD_$_swiftDispatch_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftDispatch_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftDispatch_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftDispatch

	.private_extern	__swift_FORCE_LOAD_$_swiftXPC_$_clt ; @"_swift_FORCE_LOAD_$_swiftXPC_$_clt"
	.globl	__swift_FORCE_LOAD_$_swiftXPC_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftXPC_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftXPC_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftXPC

	.private_extern	__swift_FORCE_LOAD_$_swiftIOKit_$_clt ; @"_swift_FORCE_LOAD_$_swiftIOKit_$_clt"
	.globl	__swift_FORCE_LOAD_$_swiftIOKit_$_clt
	.weak_definition	__swift_FORCE_LOAD_$_swiftIOKit_$_clt
	.p2align	3, 0x0
__swift_FORCE_LOAD_$_swiftIOKit_$_clt:
	.quad	__swift_FORCE_LOAD_$_swiftIOKit

	.section	__TEXT,__cstring,cstring_literals
"l_.str.1.\n":                          ; @".str.1.\0A"
	.asciz	"\n"

"l_.str.1. ":                           ; @".str.1. "
	.asciz	" "

	.section	__TEXT,__swift5_types
	.p2align	2, 0x0                          ; @"$s3clt5ExactVHn"
l_$s3clt5ExactVHn:
	.long	_$s3clt5ExactVMn-l_$s3clt5ExactVHn

	.p2align	2, 0x0                          ; @"$s3clt5RangeVHn"
l_$s3clt5RangeVHn:
	.long	_$s3clt5RangeVMn-l_$s3clt5RangeVHn

	.p2align	2, 0x0                          ; @"$s3clt4MainVHn"
l_$s3clt4MainVHn:
	.long	_$s3clt4MainVMn-l_$s3clt4MainVHn

	.private_extern	___swift_reflection_version ; @__swift_reflection_version
	.section	__TEXT,__const
	.globl	___swift_reflection_version
	.weak_definition	___swift_reflection_version
	.p2align	1, 0x0
___swift_reflection_version:
	.short	3                               ; 0x3

	.section	__TEXT,__swift_as_entry,coalesced,no_dead_strip
	.p2align	2, 0x0                          ; @__swift_async_entry_functlets
___swift_async_entry_functlets:
	.long	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF-___swift_async_entry_functlets
	.long	_$s3clt4MainV4mainyyYaFZ-___swift_async_entry_functlets-4
	.long	_$s3clt4MainV5$mainyyYaFZ-___swift_async_entry_functlets-8
	.long	_async_Main-___swift_async_entry_functlets-12
	.long	_$sIetH_yts5Error_pIegHrzo_TR-___swift_async_entry_functlets-16

	.section	__TEXT,__swift_as_ret,coalesced,no_dead_strip
	.p2align	2, 0x0                          ; @__swift_async_ret_functlets
___swift_async_ret_functlets:
	.long	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_-___swift_async_ret_functlets
	.long	_$s3clt4MainV4mainyyYaFZTQ1_-___swift_async_ret_functlets-4
	.long	_$s3clt4MainV5$mainyyYaFZTQ0_-___swift_async_ret_functlets-8
	.long	_async_MainTQ0_-___swift_async_ret_functlets-12
	.long	_$sIetH_yts5Error_pIegHrzo_TRTQ0_-___swift_async_ret_functlets-16

	.no_dead_strip	_$s3clt5ExactV9numerators6Int128Vvg
	.no_dead_strip	_$s3clt5ExactV11denominators6Int128Vvg
	.no_dead_strip	_$s3clt5RangeV5startAA5ExactVvg
	.no_dead_strip	_$s3clt5RangeV3endAA5ExactVvg
	.no_dead_strip	_$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF
	.no_dead_strip	l__swift5_reflection_descriptor
	.no_dead_strip	l__swift5_reflection_descriptor.1
	.no_dead_strip	l__swift5_reflection_descriptor.3
	.no_dead_strip	_$s3clt4MainV4mainyyYaFZ
	.no_dead_strip	_main
	.no_dead_strip	l__swift5_reflection_descriptor.8
	.no_dead_strip	l_entry_point
	.no_dead_strip	_$s3clt5ExactVMF
	.no_dead_strip	_$s3clt5RangeVMF
	.no_dead_strip	_$s3clt4MainVMF
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftFoundation_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swift_Builtin_float_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftObjectiveC_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftDispatch_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftXPC_$_clt
	.no_dead_strip	__swift_FORCE_LOAD_$_swiftIOKit_$_clt
	.no_dead_strip	l_$s3clt5ExactVHn
	.no_dead_strip	l_$s3clt5RangeVHn
	.no_dead_strip	l_$s3clt4MainVHn
	.no_dead_strip	___swift_reflection_version
	.no_dead_strip	___swift_async_entry_functlets
	.no_dead_strip	___swift_async_ret_functlets
	.linker_option "-lswiftFoundation"
	.linker_option "-framework", "Foundation"
	.linker_option "-lswiftCore"
	.linker_option "-lswift_DarwinFoundation3"
	.linker_option "-lswift_DarwinFoundation1"
	.linker_option "-lswift_DarwinFoundation2"
	.linker_option "-lswift_StringProcessing"
	.linker_option "-lswift_Concurrency"
	.linker_option "-lswiftSystem"
	.linker_option "-lswiftDarwin"
	.linker_option "-lswift_Builtin_float"
	.linker_option "-lswiftObservation"
	.linker_option "-lswiftObjectiveC"
	.linker_option "-lswiftCoreFoundation"
	.linker_option "-framework", "CoreFoundation"
	.linker_option "-lswiftDispatch"
	.linker_option "-framework", "Combine"
	.linker_option "-framework", "CoreServices"
	.linker_option "-framework", "Security"
	.linker_option "-lswiftXPC"
	.linker_option "-framework", "CFNetwork"
	.linker_option "-framework", "DiskArbitration"
	.linker_option "-lswiftIOKit"
	.linker_option "-framework", "IOKit"
	.linker_option "-lswiftSwiftOnoneSupport"
	.linker_option "-lobjc"
	.section	__DATA,__objc_imageinfo,regular,no_dead_strip
L_OBJC_IMAGE_INFO:
	.long	0
	.long	100861760

	.globl	_$s3clt5ExactVN
	.private_extern	_$s3clt5ExactVN
	.alt_entry	_$s3clt5ExactVN
_$s3clt5ExactVN = _$s3clt5ExactVMf+16
	.globl	_$s3clt5RangeVN
	.private_extern	_$s3clt5RangeVN
	.alt_entry	_$s3clt5RangeVN
_$s3clt5RangeVN = _$s3clt5RangeVMf+16
	.globl	_$s3clt4MainVN
	.private_extern	_$s3clt4MainVN
	.alt_entry	_$s3clt4MainVN
_$s3clt4MainVN = _$s3clt4MainVMf+16
	.weak_reference __swift_FORCE_LOAD_$_swiftFoundation
	.weak_reference __swift_FORCE_LOAD_$_swift_Builtin_float
	.weak_reference __swift_FORCE_LOAD_$_swiftObjectiveC
	.weak_reference __swift_FORCE_LOAD_$_swiftCoreFoundation
	.weak_reference __swift_FORCE_LOAD_$_swiftDispatch
	.weak_reference __swift_FORCE_LOAD_$_swiftXPC
	.weak_reference __swift_FORCE_LOAD_$_swiftIOKit
.subsections_via_symbols
