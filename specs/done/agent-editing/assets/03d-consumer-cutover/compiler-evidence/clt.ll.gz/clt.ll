; ModuleID = '/tmp/screenrec-03d-abi-diagnosis/clt.ll'
source_filename = "/tmp/screenrec-03d-abi-diagnosis/clt.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%swift.async_func_pointer = type <{ i32, i32 }>
%swift.full_existential_type = type { ptr, %swift.type }
%swift.type = type { i64 }
%swift.full_boxmetadata = type { ptr, ptr, %swift.type, i32, ptr }
%swift.protocol_conformance_descriptor = type { i32, i32, i32, i32 }
%swift.type_descriptor = type opaque
%swift.vwtable = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32 }
%swift.type_metadata_record = type { i32 }
%T3clt5RangeV = type <{ %T3clt5ExactV, %T3clt5ExactV }>
%T3clt5ExactV = type <{ %Ts6Int128V, %Ts6Int128V }>
%Ts6Int128V = type <{ i128 }>
%T3clt5RangeVSg = type <{ [64 x i8], [1 x i8] }>
%"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame" = type { %T3clt5RangeVSg, [7 x i8], %TSS, %TSSSg, %Ts16IndexingIteratorVySay3clt5RangeVGG, ptr, %T3clt5RangeV, %T3clt5ExactV, i128, i128, ptr, %TSa, i64, ptr, ptr, ptr, i1 }
%TSS = type <{ %Ts11_StringGutsV }>
%Ts11_StringGutsV = type <{ %Ts13_StringObjectV }>
%Ts13_StringObjectV = type <{ %Ts6UInt64V, ptr }>
%Ts6UInt64V = type <{ i64 }>
%TSSSg = type <{ [16 x i8] }>
%Ts16IndexingIteratorVySay3clt5RangeVGG = type <{ %TSa, %TSi }>
%TSi = type <{ i64 }>
%TSa = type <{ %Ts12_ArrayBufferV }>
%Ts12_ArrayBufferV = type <{ %Ts14_BridgeStorageV }>
%Ts14_BridgeStorageV = type <{ ptr }>
%Any = type { [24 x i8], ptr }
%swift.refcounted = type { ptr, i64 }
%swift.opaque = type opaque
%swift.metadata_response = type { ptr, i64 }
%"$s3clt4MainV4mainyyYaFZ.Frame" = type { %T3clt5RangeV, ptr, ptr, i64, i64, ptr, ptr, ptr, ptr }
%"$s3clt4MainV5$mainyyYaFZ.Frame" = type { ptr, ptr, ptr, ptr }
%async_Main.Frame = type { ptr, ptr }
%swift.async_task_and_context = type { ptr, ptr }
%swift.executor = type { i64, i64 }
%"$sIetH_yts5Error_pIegHrzo_TR.Frame" = type { ptr, ptr }
%"$sIetH_yts5Error_pIegHrzo_TRTA.Frame" = type { ptr, ptr }

@"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu" = hidden global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF" to i64), i64 ptrtoint (ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu" to i64)) to i32), i32 336 }>, section "__TEXT,__const", no_sanitize_address, align 8
@"$sypN" = external global %swift.full_existential_type
@.str.6.before = private unnamed_addr constant [7 x i8] c"before\00"
@"$sSSN" = external global %swift.type, align 8
@"symbolic _____ 3clt5ExactV" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5ExactVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 3clt5ExactV", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"\01l__swift5_reflection_descriptor" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5ExactV" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor", i32 0, i32 3) to i64)) to i32) }, section "__TEXT,__swift5_capture, regular", no_sanitize_address, align 4
@metadata = private constant %swift.full_boxmetadata { ptr @objectdestroy, ptr null, %swift.type { i64 1024 }, i32 16, ptr @"\01l__swift5_reflection_descriptor" }, align 8
@"$sSiN" = external global %swift.type, align 8
@"$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu" = external global %swift.async_func_pointer, align 8
@.str.5.after = private unnamed_addr constant [6 x i8] c"after\00"
@"\01l__swift5_reflection_descriptor.1" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5ExactV" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor.1", i32 0, i32 3) to i64)) to i32) }, section "__TEXT,__swift5_capture, regular", no_sanitize_address, align 4
@"symbolic Say_____G 3clt5RangeV" = linkonce_odr hidden constant <{ [3 x i8], i8, i32, [1 x i8], i8 }> <{ [3 x i8] c"Say", i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ [3 x i8], i8, i32, [1 x i8], i8 }>, ptr @"symbolic Say_____G 3clt5RangeV", i32 0, i32 2) to i64)) to i32), [1 x i8] c"G", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$sSay3clt5RangeVGMd" = linkonce_odr hidden global { ptr } zeroinitializer, align 8
@"$sSay3clt5RangeVGMR" = linkonce_odr hidden constant { i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic Say_____G 3clt5RangeV" to i64), i64 ptrtoint (ptr @"$sSay3clt5RangeVGMR" to i64)) to i32), i32 9 }, align 8
@"$sSay3clt5RangeVGSayxGSlsWL" = linkonce_odr hidden global ptr null, align 8
@"$sSayxGSlsMc" = external global %swift.protocol_conformance_descriptor, align 4
@"$ss16IndexingIteratorVMn" = external global %swift.type_descriptor, align 4
@"got.$ss16IndexingIteratorVMn" = private unnamed_addr constant ptr @"$ss16IndexingIteratorVMn"
@"symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV" = linkonce_odr hidden constant <{ i8, i32, [4 x i8], i8, i32, [2 x i8], i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$ss16IndexingIteratorVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, [4 x i8], i8, i32, [2 x i8], i8 }>, ptr @"symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV", i32 0, i32 1) to i64)) to i32), [4 x i8] c"ySay", i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, [4 x i8], i8, i32, [2 x i8], i8 }>, ptr @"symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV", i32 0, i32 4) to i64)) to i32), [2 x i8] c"GG", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$ss16IndexingIteratorVySay3clt5RangeVGGMd" = linkonce_odr hidden global { ptr } zeroinitializer, align 8
@"$ss16IndexingIteratorVySay3clt5RangeVGGMR" = linkonce_odr hidden constant { i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ySay_____GG s16IndexingIteratorV 3clt5RangeV" to i64), i64 ptrtoint (ptr @"$ss16IndexingIteratorVySay3clt5RangeVGGMR" to i64)) to i32), i32 16 }, align 8
@"symbolic _____ 3clt5RangeV" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 3clt5RangeV", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"\01l__swift5_reflection_descriptor.3" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5RangeV" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor.3", i32 0, i32 3) to i64)) to i32) }, section "__TEXT,__swift5_capture, regular", no_sanitize_address, align 4
@metadata.5 = private constant %swift.full_boxmetadata { ptr @objectdestroy.4, ptr null, %swift.type { i64 1024 }, i32 16, ptr @"\01l__swift5_reflection_descriptor.3" }, align 8
@"$s3clt4MainV4mainyyYaFZTu" = hidden global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV4mainyyYaFZ" to i64), i64 ptrtoint (ptr @"$s3clt4MainV4mainyyYaFZTu" to i64)) to i32), i32 144 }>, section "__TEXT,__const", no_sanitize_address, align 8
@"$sScMScAsWP" = external global ptr, align 8
@".str.8./fixture" = private unnamed_addr constant [9 x i8] c"/fixture\00"
@.str.5.audio = private unnamed_addr constant [6 x i8] c"audio\00"
@"$s3clt4MainV5$mainyyYaFZTu" = hidden global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV5$mainyyYaFZ" to i64), i64 ptrtoint (ptr @"$s3clt4MainV5$mainyyYaFZTu" to i64)) to i32), i32 48 }>, section "__TEXT,__const", no_sanitize_address, align 8
@async_MainTu = internal global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @async_Main to i64), i64 ptrtoint (ptr @async_MainTu to i64)) to i32), i32 32 }>, section "__TEXT,__const", no_sanitize_address, align 8
@"$sIetH_yts5Error_pIegHrzo_TRTu" = linkonce_odr hidden global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TR" to i64), i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTu" to i64)) to i32), i32 32 }>, section "__TEXT,__const", no_sanitize_address, align 8
@"symbolic IetH_" = linkonce_odr hidden constant <{ [5 x i8], i8 }> <{ [5 x i8] c"IetH_", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"\01l__swift5_reflection_descriptor.8" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic IetH_" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor.8", i32 0, i32 3) to i64)) to i32) }, section "__TEXT,__swift5_capture, regular", no_sanitize_address, align 4
@metadata.10 = private constant %swift.full_boxmetadata { ptr @objectdestroy.9, ptr null, %swift.type { i64 1024 }, i32 16, ptr @"\01l__swift5_reflection_descriptor.8" }, align 8
@"$sIetH_yts5Error_pIegHrzo_TRTATu" = internal global %swift.async_func_pointer <{ i32 trunc (i64 sub (i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTA" to i64), i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTATu" to i64)) to i32), i32 32 }>, section "__TEXT,__const", no_sanitize_address, align 8
@"$sytN" = external global %swift.full_existential_type
@"\01l_entry_point" = private constant { i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @main to i64), i64 ptrtoint (ptr @"\01l_entry_point" to i64)) to i32), i32 1 }, section "__TEXT, __swift5_entry, regular, no_dead_strip", align 4
@"$s3clt5ExactVWV" = internal constant %swift.vwtable { ptr @"$s3clt5ExactVwCP", ptr @__swift_noop_void_return, ptr @__swift_memcpy32_16, ptr @__swift_memcpy32_16, ptr @__swift_memcpy32_16, ptr @__swift_memcpy32_16, ptr @"$s3clt5ExactVwet", ptr @"$s3clt5ExactVwst", i64 32, i64 32, i32 131087, i32 0 }, align 8
@.str.3.clt = private constant [4 x i8] c"clt\00"
@"$s3cltMXM" = linkonce_odr hidden constant <{ i32, i32, i32 }> <{ i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.3.clt to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32 }>, ptr @"$s3cltMXM", i32 0, i32 2) to i64)) to i32) }>, section "__TEXT,__constg_swiftt", align 4
@.str.5.Exact = private constant [6 x i8] c"Exact\00"
@"$s3clt5ExactVMn" = hidden constant <{ i32, i32, i32, i32, i32, i32, i32 }> <{ i32 81, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3cltMXM" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5ExactVMn", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.5.Exact to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5ExactVMn", i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5ExactVMa" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5ExactVMn", i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5ExactVMF" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5ExactVMn", i32 0, i32 4) to i64)) to i32), i32 2, i32 2 }>, section "__TEXT,__constg_swiftt", align 4
@"$s3clt5ExactVMf" = internal constant <{ ptr, ptr, i64, ptr, i32, i32 }> <{ ptr null, ptr @"$s3clt5ExactVWV", i64 512, ptr @"$s3clt5ExactVMn", i32 0, i32 16 }>, align 8
@"$ss6Int128VMn" = external global %swift.type_descriptor, align 4
@"got.$ss6Int128VMn" = private unnamed_addr constant ptr @"$ss6Int128VMn"
@"symbolic _____ s6Int128V" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$ss6Int128VMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ s6Int128V", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@0 = private constant [10 x i8] c"numerator\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@1 = private constant [12 x i8] c"denominator\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s3clt5ExactVMF" = internal constant { i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5ExactV" to i64), i64 ptrtoint (ptr @"$s3clt5ExactVMF" to i64)) to i32), i32 0, i16 0, i16 12, i32 2, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ s6Int128V" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5ExactVMF", i32 0, i32 6) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @0 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5ExactVMF", i32 0, i32 7) to i64)) to i32), i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ s6Int128V" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5ExactVMF", i32 0, i32 9) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @1 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5ExactVMF", i32 0, i32 10) to i64)) to i32) }, section "__TEXT,__swift5_fieldmd, regular", no_sanitize_address, align 4
@"$s3clt5RangeVWV" = internal constant %swift.vwtable { ptr @"$s3clt5RangeVwCP", ptr @__swift_noop_void_return, ptr @__swift_memcpy64_16, ptr @__swift_memcpy64_16, ptr @__swift_memcpy64_16, ptr @__swift_memcpy64_16, ptr @"$s3clt5RangeVwet", ptr @"$s3clt5RangeVwst", i64 64, i64 64, i32 131087, i32 0 }, align 8
@.str.5.Range = private constant [6 x i8] c"Range\00"
@"$s3clt5RangeVMn" = hidden constant <{ i32, i32, i32, i32, i32, i32, i32 }> <{ i32 81, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3cltMXM" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5RangeVMn", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.5.Range to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5RangeVMn", i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMa" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5RangeVMn", i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMF" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt5RangeVMn", i32 0, i32 4) to i64)) to i32), i32 2, i32 2 }>, section "__TEXT,__constg_swiftt", align 4
@"$s3clt5RangeVMf" = internal constant <{ ptr, ptr, i64, ptr, i32, i32 }> <{ ptr null, ptr @"$s3clt5RangeVWV", i64 512, ptr @"$s3clt5RangeVMn", i32 0, i32 32 }>, align 8
@2 = private constant [6 x i8] c"start\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@3 = private constant [4 x i8] c"end\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s3clt5RangeVMF" = internal constant { i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5RangeV" to i64), i64 ptrtoint (ptr @"$s3clt5RangeVMF" to i64)) to i32), i32 0, i16 0, i16 12, i32 2, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5ExactV" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5RangeVMF", i32 0, i32 6) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @2 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5RangeVMF", i32 0, i32 7) to i64)) to i32), i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt5ExactV" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5RangeVMF", i32 0, i32 9) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @3 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s3clt5RangeVMF", i32 0, i32 10) to i64)) to i32) }, section "__TEXT,__swift5_fieldmd, regular", no_sanitize_address, align 4
@"$sytWV" = external global ptr, align 8
@.str.4.Main = private constant [5 x i8] c"Main\00"
@"$s3clt4MainVMn" = hidden constant <{ i32, i32, i32, i32, i32, i32, i32 }> <{ i32 81, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3cltMXM" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt4MainVMn", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.4.Main to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt4MainVMn", i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainVMa" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt4MainVMn", i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainVMF" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s3clt4MainVMn", i32 0, i32 4) to i64)) to i32), i32 0, i32 2 }>, section "__TEXT,__constg_swiftt", align 4
@"$s3clt4MainVMf" = internal constant <{ ptr, ptr, i64, ptr }> <{ ptr null, ptr @"$sytWV", i64 512, ptr @"$s3clt4MainVMn" }>, align 8
@"symbolic _____ 3clt4MainV" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 3clt4MainV", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$s3clt4MainVMF" = internal constant { i32, i32, i16, i16, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 3clt4MainV" to i64), i64 ptrtoint (ptr @"$s3clt4MainVMF" to i64)) to i32), i32 0, i16 0, i16 12, i32 0 }, section "__TEXT,__swift5_fieldmd, regular", no_sanitize_address, align 4
@"_swift_FORCE_LOAD_$_swiftFoundation_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftFoundation"
@"_swift_FORCE_LOAD_$_swift_Builtin_float_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swift_Builtin_float"
@"_swift_FORCE_LOAD_$_swiftObjectiveC_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftObjectiveC"
@"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftCoreFoundation"
@"_swift_FORCE_LOAD_$_swiftDispatch_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftDispatch"
@"_swift_FORCE_LOAD_$_swiftXPC_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftXPC"
@"_swift_FORCE_LOAD_$_swiftIOKit_$_clt" = weak_odr hidden constant ptr @"_swift_FORCE_LOAD_$_swiftIOKit"
@".str.1.\0A" = private unnamed_addr constant [2 x i8] c"\0A\00"
@".str.1. " = private unnamed_addr constant [2 x i8] c" \00"
@"$s3clt5ExactVHn" = private constant %swift.type_metadata_record { i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5ExactVMn" to i64), i64 ptrtoint (ptr @"$s3clt5ExactVHn" to i64)) to i32) }, section "__TEXT, __swift5_types, regular", no_sanitize_address, align 4
@"$s3clt5RangeVHn" = private constant %swift.type_metadata_record { i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt5RangeVMn" to i64), i64 ptrtoint (ptr @"$s3clt5RangeVHn" to i64)) to i32) }, section "__TEXT, __swift5_types, regular", no_sanitize_address, align 4
@"$s3clt4MainVHn" = private constant %swift.type_metadata_record { i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainVMn" to i64), i64 ptrtoint (ptr @"$s3clt4MainVHn" to i64)) to i32) }, section "__TEXT, __swift5_types, regular", no_sanitize_address, align 4
@__swift_reflection_version = linkonce_odr hidden constant i16 3
@llvm.compiler.used = appending global [6 x ptr] [ptr @"$s3clt5ExactVMf", ptr @"$s3clt5ExactVN", ptr @"$s3clt5RangeVMf", ptr @"$s3clt5RangeVN", ptr @"$s3clt4MainVMf", ptr @"$s3clt4MainVN"], section "llvm.metadata"
@__swift_async_entry_functlets = internal constant [5 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF" to i64), i64 ptrtoint (ptr @__swift_async_entry_functlets to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV4mainyyYaFZ" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_entry_functlets, i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV5$mainyyYaFZ" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_entry_functlets, i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @async_Main to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_entry_functlets, i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TR" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_entry_functlets, i32 0, i32 4) to i64)) to i32)], section "__TEXT,__swift_as_entry, coalesced, no_dead_strip", no_sanitize_address, align 4
@__swift_async_ret_functlets = internal constant [5 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_" to i64), i64 ptrtoint (ptr @__swift_async_ret_functlets to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV4mainyyYaFZTQ1_" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_ret_functlets, i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s3clt4MainV5$mainyyYaFZTQ0_" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_ret_functlets, i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @async_MainTQ0_ to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_ret_functlets, i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTQ0_" to i64), i64 ptrtoint (ptr getelementptr inbounds ([5 x i32], ptr @__swift_async_ret_functlets, i32 0, i32 4) to i64)) to i32)], section "__TEXT,__swift_as_ret, coalesced, no_dead_strip", no_sanitize_address, align 4
@llvm.used = appending global [28 x ptr] [ptr @"$s3clt5ExactV9numerators6Int128Vvg", ptr @"$s3clt5ExactV11denominators6Int128Vvg", ptr @"$s3clt5RangeV5startAA5ExactVvg", ptr @"$s3clt5RangeV3endAA5ExactVvg", ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF", ptr @"\01l__swift5_reflection_descriptor", ptr @"\01l__swift5_reflection_descriptor.1", ptr @"\01l__swift5_reflection_descriptor.3", ptr @"$s3clt4MainV4mainyyYaFZ", ptr @main, ptr @"\01l__swift5_reflection_descriptor.8", ptr @"\01l_entry_point", ptr @"$s3clt5ExactVMF", ptr @"$s3clt5RangeVMF", ptr @"$s3clt4MainVMF", ptr @"_swift_FORCE_LOAD_$_swiftFoundation_$_clt", ptr @"_swift_FORCE_LOAD_$_swift_Builtin_float_$_clt", ptr @"_swift_FORCE_LOAD_$_swiftObjectiveC_$_clt", ptr @"_swift_FORCE_LOAD_$_swiftCoreFoundation_$_clt", ptr @"_swift_FORCE_LOAD_$_swiftDispatch_$_clt", ptr @"_swift_FORCE_LOAD_$_swiftXPC_$_clt", ptr @"_swift_FORCE_LOAD_$_swiftIOKit_$_clt", ptr @"$s3clt5ExactVHn", ptr @"$s3clt5RangeVHn", ptr @"$s3clt4MainVHn", ptr @__swift_reflection_version, ptr @__swift_async_entry_functlets, ptr @__swift_async_ret_functlets], section "llvm.metadata"

@"$s3clt5ExactVN" = hidden alias %swift.type, getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5ExactVMf", i32 0, i32 2)
@"$s3clt5RangeVN" = hidden alias %swift.type, getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2)
@"$s3clt4MainVN" = hidden alias %swift.type, getelementptr inbounds (<{ ptr, ptr, i64, ptr }>, ptr @"$s3clt4MainVMf", i32 0, i32 2)

define hidden swiftcc i128 @"$s3clt5ExactV9numerators6Int128Vvg"(i128 %0, i128 %1) #0 {
entry:
  ret i128 %0
}

define hidden swiftcc i128 @"$s3clt5ExactV11denominators6Int128Vvg"(i128 %0, i128 %1) #0 {
entry:
  ret i128 %1
}

define hidden swiftcc { i128, i128 } @"$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC"(i128 %0, i128 %1) #0 {
entry:
  %2 = insertvalue { i128, i128 } undef, i128 %0, 0
  %3 = insertvalue { i128, i128 } %2, i128 %1, 1
  ret { i128, i128 } %3
}

define hidden swiftcc { i128, i128 } @"$s3clt5RangeV5startAA5ExactVvg"(ptr noalias swiftself captures(none) dereferenceable(64) %0) #0 {
entry:
  %.start = getelementptr inbounds nuw %T3clt5RangeV, ptr %0, i32 0, i32 0
  %.start.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 0
  %.start.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.numerator, i32 0, i32 0
  %1 = load i128, ptr %.start.numerator._value, align 16
  %.start.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 1
  %.start.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.denominator, i32 0, i32 0
  %2 = load i128, ptr %.start.denominator._value, align 16
  %3 = insertvalue { i128, i128 } undef, i128 %1, 0
  %4 = insertvalue { i128, i128 } %3, i128 %2, 1
  ret { i128, i128 } %4
}

define hidden swiftcc { i128, i128 } @"$s3clt5RangeV3endAA5ExactVvg"(ptr noalias swiftself captures(none) dereferenceable(64) %0) #0 {
entry:
  %.end = getelementptr inbounds nuw %T3clt5RangeV, ptr %0, i32 0, i32 1
  %.end.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 0
  %.end.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.numerator, i32 0, i32 0
  %1 = load i128, ptr %.end.numerator._value, align 16
  %.end.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 1
  %.end.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.denominator, i32 0, i32 0
  %2 = load i128, ptr %.end.denominator._value, align 16
  %3 = insertvalue { i128, i128 } undef, i128 %1, 0
  %4 = insertvalue { i128, i128 } %3, i128 %2, 1
  ret { i128, i128 } %4
}

define hidden swiftcc void @"$s3clt5RangeV5start3endAcA5ExactV_AGtcfC"(ptr noalias sret(%T3clt5RangeV) captures(none) %0, i128 %1, i128 %2, i128 %3, i128 %4) #0 {
entry:
  %.start = getelementptr inbounds nuw %T3clt5RangeV, ptr %0, i32 0, i32 0
  %.start.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 0
  %.start.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.numerator, i32 0, i32 0
  store i128 %1, ptr %.start.numerator._value, align 16
  %.start.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 1
  %.start.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.denominator, i32 0, i32 0
  store i128 %2, ptr %.start.denominator._value, align 16
  %.end = getelementptr inbounds nuw %T3clt5RangeV, ptr %0, i32 0, i32 1
  %.end.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 0
  %.end.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.numerator, i32 0, i32 0
  store i128 %3, ptr %.end.numerator._value, align 16
  %.end.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 1
  %.end.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.denominator, i32 0, i32 0
  store i128 %4, ptr %.end.denominator._value, align 16
  ret void
}

define hidden swiftcc i1 @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_"() #0 {
entry:
  ret i1 false
}

; Function Attrs: noinline
define hidden swifttailcc void @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF"(ptr swiftasync %0, i64 %1, ptr %2, i64 %3, i64 %4, i128 %5, i128 %6, ptr %7, i1 %8) #1 {
entry:
  %9 = alloca %T3clt5RangeVSg, align 16
  %10 = alloca %T3clt5RangeVSg, align 16
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %11 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  %path.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %id.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %offset.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  %available.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 10
  %strict.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 16
  %12 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  %13 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 11
  %14 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %span.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  %.spill.addr30 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 14
  store ptr %7, ptr %.spill.addr30, align 8
  %.spill.addr25 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 9
  store i128 %6, ptr %.spill.addr25, align 16
  %.spill.addr20 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 8
  store i128 %5, ptr %.spill.addr20, align 16
  %.spill.addr15 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 13
  store ptr %2, ptr %.spill.addr15, align 8
  %.spill.addr = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 12
  store i64 %1, ptr %.spill.addr, align 8
  store ptr %0, ptr %11, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %path.debug, i8 0, i64 16, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %id.debug, i8 0, i64 16, i1 false)
  call void @llvm.memset.p0.i64(ptr align 16 %offset.debug, i8 0, i64 32, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %available.debug, i8 0, i64 8, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %strict.debug, i8 0, i64 1, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %12, i8 0, i64 16, i1 false)
  call void @llvm.memset.p0.i64(ptr align 16 %span.debug, i8 0, i64 64, i1 false)
  call void @llvm.lifetime.start.p0(i64 16, ptr %path.debug)
  %path.debug._guts = getelementptr inbounds nuw %TSS, ptr %path.debug, i32 0, i32 0
  %path.debug._guts._object = getelementptr inbounds nuw %Ts11_StringGutsV, ptr %path.debug._guts, i32 0, i32 0
  %path.debug._guts._object._countAndFlagsBits = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %path.debug._guts._object, i32 0, i32 0
  %path.debug._guts._object._countAndFlagsBits._value = getelementptr inbounds nuw %Ts6UInt64V, ptr %path.debug._guts._object._countAndFlagsBits, i32 0, i32 0
  store i64 %1, ptr %path.debug._guts._object._countAndFlagsBits._value, align 8
  %path.debug._guts._object._object = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %path.debug._guts._object, i32 0, i32 1
  store ptr %2, ptr %path.debug._guts._object._object, align 8
  call void asm sideeffect "", "r"(ptr %path.debug)
  call void @llvm.lifetime.start.p0(i64 16, ptr %id.debug)
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %id.debug, i32 0, i32 0
  store i64 %3, ptr %15, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %id.debug, i32 0, i32 1
  store i64 %4, ptr %16, align 8
  call void asm sideeffect "", "r"(ptr %id.debug)
  call void @llvm.lifetime.start.p0(i64 32, ptr %offset.debug)
  %offset.debug.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %offset.debug, i32 0, i32 0
  %offset.debug.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %offset.debug.numerator, i32 0, i32 0
  store i128 %5, ptr %offset.debug.numerator._value, align 16
  %offset.debug.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %offset.debug, i32 0, i32 1
  %offset.debug.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %offset.debug.denominator, i32 0, i32 0
  store i128 %6, ptr %offset.debug.denominator._value, align 16
  call void asm sideeffect "", "r"(ptr %offset.debug)
  store ptr %7, ptr %available.debug, align 8
  call void asm sideeffect "", "r"(ptr %available.debug)
  store i1 %8, ptr %strict.debug, align 8
  call void asm sideeffect "", "r"(ptr %strict.debug)
  %17 = load ptr, ptr %11, align 8
  %18 = load ptr, ptr %11, align 8
  musttail call swifttailcc void @swift_task_switch(ptr swiftasync %18, ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_", i64 0, i64 0) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY0_"(ptr swiftasync %0) #2 {
entryresume.0:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = alloca %T3clt5RangeVSg, align 16
  %2 = alloca %T3clt5RangeVSg, align 16
  %3 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  %path.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %id.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %offset.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  %available.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 10
  %strict.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 16
  %4 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  %5 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 11
  %6 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %span.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  %.reload.addr33 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 14
  %.reload34 = load ptr, ptr %.reload.addr33, align 8
  %.reload.addr28 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 9
  %.reload29 = load i128, ptr %.reload.addr28, align 16
  %.reload.addr23 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 8
  %.reload24 = load i128, ptr %.reload.addr23, align 16
  %.reload.addr18 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 13
  %.reload19 = load ptr, ptr %.reload.addr18, align 8
  %.reload.addr13 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 12
  %.reload14 = load i64, ptr %.reload.addr13, align 8
  store ptr %0, ptr %3, align 8
  %7 = call swiftcc { ptr, ptr } @"$ss27_allocateUninitializedArrayySayxG_BptBwlF"(i64 4, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %8 = extractvalue { ptr, ptr } %7, 0
  %9 = extractvalue { ptr, ptr } %7, 1
  %10 = getelementptr inbounds i8, ptr %8, i64 32
  %11 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @.str.6.before, i64 6, i1 true)
  %12 = extractvalue { i64, ptr } %11, 0
  %13 = extractvalue { i64, ptr } %11, 1
  %14 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 1
  store ptr @"$sSSN", ptr %14, align 8
  %15 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 0
  %16 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 0
  %._guts = getelementptr inbounds nuw %TSS, ptr %16, i32 0, i32 0
  %._guts._object = getelementptr inbounds nuw %Ts11_StringGutsV, ptr %._guts, i32 0, i32 0
  %._guts._object._countAndFlagsBits = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts._object, i32 0, i32 0
  %._guts._object._countAndFlagsBits._value = getelementptr inbounds nuw %Ts6UInt64V, ptr %._guts._object._countAndFlagsBits, i32 0, i32 0
  store i64 %12, ptr %._guts._object._countAndFlagsBits._value, align 8
  %._guts._object._object = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts._object, i32 0, i32 1
  store ptr %13, ptr %._guts._object._object, align 8
  %17 = getelementptr inbounds %Any, ptr %10, i64 1
  %18 = call ptr @swift_bridgeObjectRetain(ptr returned %.reload19) #6
  %19 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 1
  store ptr @"$sSSN", ptr %19, align 8
  %20 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 0
  %21 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 0
  %._guts1 = getelementptr inbounds nuw %TSS, ptr %21, i32 0, i32 0
  %._guts1._object = getelementptr inbounds nuw %Ts11_StringGutsV, ptr %._guts1, i32 0, i32 0
  %._guts1._object._countAndFlagsBits = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts1._object, i32 0, i32 0
  %._guts1._object._countAndFlagsBits._value = getelementptr inbounds nuw %Ts6UInt64V, ptr %._guts1._object._countAndFlagsBits, i32 0, i32 0
  store i64 %.reload14, ptr %._guts1._object._countAndFlagsBits._value, align 8
  %._guts1._object._object = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts1._object, i32 0, i32 1
  store ptr %.reload19, ptr %._guts1._object._object, align 8
  %22 = getelementptr inbounds %Any, ptr %10, i64 2
  %23 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 1
  store ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5ExactVMf", i32 0, i32 2), ptr %23, align 8
  %24 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 0
  %25 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 0
  %26 = call noalias ptr @swift_allocObject(ptr getelementptr inbounds (%swift.full_boxmetadata, ptr @metadata, i32 0, i32 2), i64 48, i64 15) #6
  %27 = getelementptr inbounds nuw <{ %swift.refcounted, [32 x i8] }>, ptr %26, i32 0, i32 1
  store ptr %26, ptr %25, align 8
  %.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %27, i32 0, i32 0
  %.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.numerator, i32 0, i32 0
  store i128 %.reload24, ptr %.numerator._value, align 16
  %.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %27, i32 0, i32 1
  %.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.denominator, i32 0, i32 0
  store i128 %.reload29, ptr %.denominator._value, align 16
  %28 = getelementptr inbounds %Any, ptr %10, i64 3
  %29 = call swiftcc i64 @"$sSa5countSivg"(ptr %.reload34, ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2))
  %30 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 1
  store ptr @"$sSiN", ptr %30, align 8
  %31 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 0
  %32 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 0
  %._value = getelementptr inbounds nuw %TSi, ptr %32, i32 0, i32 0
  store i64 %29, ptr %._value, align 8
  %33 = call swiftcc ptr @"$ss27_finalizeUninitializedArrayySayxGABnlF"(ptr %8, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %34 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA0_"()
  %35 = extractvalue { i64, ptr } %34, 0
  %36 = extractvalue { i64, ptr } %34, 1
  %37 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA1_"()
  %38 = extractvalue { i64, ptr } %37, 0
  %39 = extractvalue { i64, ptr } %37, 1
  call swiftcc void @"$ss5print_9separator10terminatoryypd_S2StF"(ptr %33, i64 %35, ptr %36, i64 %38, ptr %39)
  call void @swift_bridgeObjectRelease(ptr %39) #6
  call void @swift_bridgeObjectRelease(ptr %36) #6
  call void @swift_bridgeObjectRelease(ptr %33) #6
  %40 = load i32, ptr getelementptr inbounds nuw (%swift.async_func_pointer, ptr @"$sScTss5NeverORszABRs_rlE5yieldyyYaFZTu", i32 0, i32 1), align 4
  %41 = zext i32 %40 to i64
  %42 = call swiftcc ptr @swift_task_alloc(i64 %41) #7
  %.spill.addr35 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 15
  store ptr %42, ptr %.spill.addr35, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %42)
  %43 = load ptr, ptr %3, align 8
  %44 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %42, i32 0, i32 0
  store ptr %43, ptr %44, align 8
  %45 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %42, i32 0, i32 1
  store ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_", ptr %45, align 8
  musttail call swifttailcc void @"$sScTss5NeverORszABRs_rlE5yieldyyYaFZ"(ptr swiftasync %42) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTQ1_"(ptr swiftasync %0) #3 {
entryresume.1:
  %1 = load ptr, ptr %0, align 8
  %2 = call ptr @llvm.swift.async.context.addr()
  store ptr %1, ptr %2, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = alloca %T3clt5RangeVSg, align 16
  %4 = alloca %T3clt5RangeVSg, align 16
  %5 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  %path.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %id.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %offset.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  %available.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 10
  %strict.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 16
  %6 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  %7 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 11
  %8 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %span.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  %.reload.addr36 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 15
  %.reload37 = load ptr, ptr %.reload.addr36, align 8
  %9 = load ptr, ptr %0, align 8
  store ptr %9, ptr %5, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload37) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload37)
  %10 = load ptr, ptr %5, align 8
  musttail call swifttailcc void @swift_task_switch(ptr swiftasync %10, ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_", i64 0, i64 0) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTY2_"(ptr swiftasync %0) #2 {
entryresume.2:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = alloca %T3clt5RangeVSg, align 16
  %2 = alloca %T3clt5RangeVSg, align 16
  %3 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  %path.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %id.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %offset.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  %available.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 10
  %strict.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 16
  %4 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  %5 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 11
  %6 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %span.debug = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  %.reload.addr31 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 14
  %.reload32 = load ptr, ptr %.reload.addr31, align 8
  %.reload.addr26 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 9
  %.reload27 = load i128, ptr %.reload.addr26, align 16
  %.reload.addr21 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 8
  %.reload22 = load i128, ptr %.reload.addr21, align 16
  %.reload.addr16 = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 13
  %.reload17 = load ptr, ptr %.reload.addr16, align 8
  %.reload.addr = getelementptr inbounds %"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF.Frame", ptr %async.ctx.frameptr, i32 0, i32 12
  %.reload = load i64, ptr %.reload.addr, align 8
  store ptr %0, ptr %3, align 8
  %7 = call swiftcc { ptr, ptr } @"$ss27_allocateUninitializedArrayySayxG_BptBwlF"(i64 4, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %8 = extractvalue { ptr, ptr } %7, 0
  %9 = extractvalue { ptr, ptr } %7, 1
  %10 = getelementptr inbounds i8, ptr %8, i64 32
  %11 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @.str.5.after, i64 5, i1 true)
  %12 = extractvalue { i64, ptr } %11, 0
  %13 = extractvalue { i64, ptr } %11, 1
  %14 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 1
  store ptr @"$sSSN", ptr %14, align 8
  %15 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 0
  %16 = getelementptr inbounds nuw %Any, ptr %10, i32 0, i32 0
  %._guts2 = getelementptr inbounds nuw %TSS, ptr %16, i32 0, i32 0
  %._guts2._object = getelementptr inbounds nuw %Ts11_StringGutsV, ptr %._guts2, i32 0, i32 0
  %._guts2._object._countAndFlagsBits = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts2._object, i32 0, i32 0
  %._guts2._object._countAndFlagsBits._value = getelementptr inbounds nuw %Ts6UInt64V, ptr %._guts2._object._countAndFlagsBits, i32 0, i32 0
  store i64 %12, ptr %._guts2._object._countAndFlagsBits._value, align 8
  %._guts2._object._object = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts2._object, i32 0, i32 1
  store ptr %13, ptr %._guts2._object._object, align 8
  %17 = getelementptr inbounds %Any, ptr %10, i64 1
  %18 = call ptr @swift_bridgeObjectRetain(ptr returned %.reload17) #6
  %19 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 1
  store ptr @"$sSSN", ptr %19, align 8
  %20 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 0
  %21 = getelementptr inbounds nuw %Any, ptr %17, i32 0, i32 0
  %._guts3 = getelementptr inbounds nuw %TSS, ptr %21, i32 0, i32 0
  %._guts3._object = getelementptr inbounds nuw %Ts11_StringGutsV, ptr %._guts3, i32 0, i32 0
  %._guts3._object._countAndFlagsBits = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts3._object, i32 0, i32 0
  %._guts3._object._countAndFlagsBits._value = getelementptr inbounds nuw %Ts6UInt64V, ptr %._guts3._object._countAndFlagsBits, i32 0, i32 0
  store i64 %.reload, ptr %._guts3._object._countAndFlagsBits._value, align 8
  %._guts3._object._object = getelementptr inbounds nuw %Ts13_StringObjectV, ptr %._guts3._object, i32 0, i32 1
  store ptr %.reload17, ptr %._guts3._object._object, align 8
  %22 = getelementptr inbounds %Any, ptr %10, i64 2
  %23 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 1
  store ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5ExactVMf", i32 0, i32 2), ptr %23, align 8
  %24 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 0
  %25 = getelementptr inbounds nuw %Any, ptr %22, i32 0, i32 0
  %26 = call noalias ptr @swift_allocObject(ptr getelementptr inbounds (%swift.full_boxmetadata, ptr @metadata, i32 0, i32 2), i64 48, i64 15) #6
  %27 = getelementptr inbounds nuw <{ %swift.refcounted, [32 x i8] }>, ptr %26, i32 0, i32 1
  store ptr %26, ptr %25, align 8
  %.numerator4 = getelementptr inbounds nuw %T3clt5ExactV, ptr %27, i32 0, i32 0
  %.numerator4._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.numerator4, i32 0, i32 0
  store i128 %.reload22, ptr %.numerator4._value, align 16
  %.denominator5 = getelementptr inbounds nuw %T3clt5ExactV, ptr %27, i32 0, i32 1
  %.denominator5._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.denominator5, i32 0, i32 0
  store i128 %.reload27, ptr %.denominator5._value, align 16
  %28 = getelementptr inbounds %Any, ptr %10, i64 3
  %29 = call swiftcc i64 @"$sSa5countSivg"(ptr %.reload32, ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2))
  %30 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 1
  store ptr @"$sSiN", ptr %30, align 8
  %31 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 0
  %32 = getelementptr inbounds nuw %Any, ptr %28, i32 0, i32 0
  %._value6 = getelementptr inbounds nuw %TSi, ptr %32, i32 0, i32 0
  store i64 %29, ptr %._value6, align 8
  %33 = call swiftcc ptr @"$ss27_finalizeUninitializedArrayySayxGABnlF"(ptr %8, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %34 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA0_"()
  %35 = extractvalue { i64, ptr } %34, 0
  %36 = extractvalue { i64, ptr } %34, 1
  %37 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA1_"()
  %38 = extractvalue { i64, ptr } %37, 0
  %39 = extractvalue { i64, ptr } %37, 1
  call swiftcc void @"$ss5print_9separator10terminatoryypd_S2StF"(ptr %33, i64 %35, ptr %36, i64 %38, ptr %39)
  call void @swift_bridgeObjectRelease(ptr %39) #6
  call void @swift_bridgeObjectRelease(ptr %36) #6
  call void @swift_bridgeObjectRelease(ptr %33) #6
  call void @llvm.lifetime.start.p0(i64 16, ptr %4)
  %40 = call ptr @swift_bridgeObjectRetain(ptr returned %.reload32) #6
  call void @llvm.lifetime.start.p0(i64 8, ptr %5)
  %._buffer = getelementptr inbounds nuw %TSa, ptr %5, i32 0, i32 0
  %._buffer._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._buffer, i32 0, i32 0
  %._buffer._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._buffer._storage, i32 0, i32 0
  store ptr %.reload32, ptr %._buffer._storage.rawValue, align 8
  %41 = call ptr @__swift_instantiateConcreteTypeFromMangledNameV2(ptr @"$sSay3clt5RangeVGMd", ptr @"$sSay3clt5RangeVGMR") #11
  %42 = call ptr @"$sSay3clt5RangeVGSayxGSlsWl"() #19
  call swiftcc void @"$sSlss16IndexingIteratorVyxG0B0RtzrlE04makeB0ACyF"(ptr noalias sret(%swift.opaque) %4, ptr %41, ptr %42, ptr noalias swiftself %5)
  call void @llvm.lifetime.end.p0(i64 8, ptr %5)
  br label %43

43:                                               ; preds = %64, %entryresume.2
  call void @llvm.lifetime.start.p0(i64 65, ptr %2)
  call void @llvm.lifetime.start.p0(i64 65, ptr %1)
  call void @llvm.lifetime.start.p0(i64 65, ptr %6)
  %44 = call ptr @__swift_instantiateConcreteTypeFromMangledNameV2(ptr @"$ss16IndexingIteratorVySay3clt5RangeVGGMd", ptr @"$ss16IndexingIteratorVySay3clt5RangeVGGMR") #11
  call swiftcc void @"$ss16IndexingIteratorV4next7ElementQzSgyF"(ptr noalias sret(%swift.opaque) %6, ptr %44, ptr swiftself %4)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %1, ptr align 16 %6, i64 65, i1 false)
  call void @llvm.lifetime.end.p0(i64 65, ptr %6)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 %1, i64 65, i1 false)
  %45 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 0
  %46 = load i64, ptr %45, align 16
  %47 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 1
  %48 = load i64, ptr %47, align 8
  %49 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 2
  %50 = load i64, ptr %49, align 16
  %51 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 3
  %52 = load i64, ptr %51, align 8
  %53 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 4
  %54 = load i64, ptr %53, align 16
  %55 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 5
  %56 = load i64, ptr %55, align 8
  %57 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 6
  %58 = load i64, ptr %57, align 16
  %59 = getelementptr inbounds nuw { i64, i64, i64, i64, i64, i64, i64, i64 }, ptr %1, i32 0, i32 7
  %60 = load i64, ptr %59, align 8
  %61 = getelementptr inbounds nuw %T3clt5RangeVSg, ptr %1, i32 0, i32 1
  %62 = load i8, ptr %61, align 16
  %63 = icmp eq i8 %62, 1
  br i1 %63, label %MustTailCall.Before.CoroEnd, label %64

64:                                               ; preds = %43
  %.start = getelementptr inbounds nuw %T3clt5RangeV, ptr %2, i32 0, i32 0
  %.start.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 0
  %.start.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.numerator, i32 0, i32 0
  %65 = load i128, ptr %.start.numerator._value, align 16
  %.start.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start, i32 0, i32 1
  %.start.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start.denominator, i32 0, i32 0
  %66 = load i128, ptr %.start.denominator._value, align 16
  %.end = getelementptr inbounds nuw %T3clt5RangeV, ptr %2, i32 0, i32 1
  %.end.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 0
  %.end.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.numerator, i32 0, i32 0
  %67 = load i128, ptr %.end.numerator._value, align 16
  %.end.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end, i32 0, i32 1
  %.end.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end.denominator, i32 0, i32 0
  %68 = load i128, ptr %.end.denominator._value, align 16
  call void @llvm.lifetime.start.p0(i64 64, ptr %span.debug)
  %span.debug.start = getelementptr inbounds nuw %T3clt5RangeV, ptr %span.debug, i32 0, i32 0
  %span.debug.start.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %span.debug.start, i32 0, i32 0
  %span.debug.start.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %span.debug.start.numerator, i32 0, i32 0
  store i128 %65, ptr %span.debug.start.numerator._value, align 16
  %span.debug.start.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %span.debug.start, i32 0, i32 1
  %span.debug.start.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %span.debug.start.denominator, i32 0, i32 0
  store i128 %66, ptr %span.debug.start.denominator._value, align 16
  %span.debug.end = getelementptr inbounds nuw %T3clt5RangeV, ptr %span.debug, i32 0, i32 1
  %span.debug.end.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %span.debug.end, i32 0, i32 0
  %span.debug.end.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %span.debug.end.numerator, i32 0, i32 0
  store i128 %67, ptr %span.debug.end.numerator._value, align 16
  %span.debug.end.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %span.debug.end, i32 0, i32 1
  %span.debug.end.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %span.debug.end.denominator, i32 0, i32 0
  store i128 %68, ptr %span.debug.end.denominator._value, align 16
  call void asm sideeffect "", "r"(ptr %span.debug)
  %69 = call swiftcc { ptr, ptr } @"$ss27_allocateUninitializedArrayySayxG_BptBwlF"(i64 1, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %70 = extractvalue { ptr, ptr } %69, 0
  %71 = extractvalue { ptr, ptr } %69, 1
  %72 = getelementptr inbounds i8, ptr %70, i64 32
  %73 = getelementptr inbounds nuw %Any, ptr %72, i32 0, i32 1
  store ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2), ptr %73, align 8
  %74 = getelementptr inbounds nuw %Any, ptr %72, i32 0, i32 0
  %75 = getelementptr inbounds nuw %Any, ptr %72, i32 0, i32 0
  %76 = call noalias ptr @swift_allocObject(ptr getelementptr inbounds (%swift.full_boxmetadata, ptr @metadata.5, i32 0, i32 2), i64 80, i64 15) #6
  %77 = getelementptr inbounds nuw <{ %swift.refcounted, [64 x i8] }>, ptr %76, i32 0, i32 1
  store ptr %76, ptr %75, align 8
  %.start7 = getelementptr inbounds nuw %T3clt5RangeV, ptr %77, i32 0, i32 0
  %.start7.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start7, i32 0, i32 0
  %.start7.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start7.numerator, i32 0, i32 0
  store i128 %65, ptr %.start7.numerator._value, align 16
  %.start7.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.start7, i32 0, i32 1
  %.start7.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.start7.denominator, i32 0, i32 0
  store i128 %66, ptr %.start7.denominator._value, align 16
  %.end8 = getelementptr inbounds nuw %T3clt5RangeV, ptr %77, i32 0, i32 1
  %.end8.numerator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end8, i32 0, i32 0
  %.end8.numerator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end8.numerator, i32 0, i32 0
  store i128 %67, ptr %.end8.numerator._value, align 16
  %.end8.denominator = getelementptr inbounds nuw %T3clt5ExactV, ptr %.end8, i32 0, i32 1
  %.end8.denominator._value = getelementptr inbounds nuw %Ts6Int128V, ptr %.end8.denominator, i32 0, i32 0
  store i128 %68, ptr %.end8.denominator._value, align 16
  %78 = call swiftcc ptr @"$ss27_finalizeUninitializedArrayySayxGABnlF"(ptr %70, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sypN", i32 0, i32 1))
  %79 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA0_"()
  %80 = extractvalue { i64, ptr } %79, 0
  %81 = extractvalue { i64, ptr } %79, 1
  %82 = call swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA1_"()
  %83 = extractvalue { i64, ptr } %82, 0
  %84 = extractvalue { i64, ptr } %82, 1
  call swiftcc void @"$ss5print_9separator10terminatoryypd_S2StF"(ptr %78, i64 %80, ptr %81, i64 %83, ptr %84)
  call void @swift_bridgeObjectRelease(ptr %84) #6
  call void @swift_bridgeObjectRelease(ptr %81) #6
  call void @swift_bridgeObjectRelease(ptr %78) #6
  call void @llvm.lifetime.end.p0(i64 65, ptr %1)
  call void @llvm.lifetime.end.p0(i64 65, ptr %2)
  br label %43

MustTailCall.Before.CoroEnd:                      ; preds = %43
  %85 = call ptr @"$ss16IndexingIteratorVySay3clt5RangeVGGWOh"(ptr %4)
  call void @llvm.lifetime.end.p0(i64 65, ptr %1)
  call void @llvm.lifetime.end.p0(i64 65, ptr %2)
  call void @llvm.lifetime.end.p0(i64 16, ptr %4)
  %86 = load ptr, ptr %3, align 8
  %87 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %86, i32 0, i32 1
  %88 = load ptr, ptr %87, align 8
  %89 = load ptr, ptr %3, align 8
  musttail call swifttailcc void %88(ptr swiftasync %89) #6
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #5

; Function Attrs: nounwind
declare swifttailcc void @swift_task_switch(ptr, ptr, i64, i64) #6

; Function Attrs: nounwind
declare ptr @llvm.swift.async.context.addr() #6

declare swiftcc { ptr, ptr } @"$ss27_allocateUninitializedArrayySayxG_BptBwlF"(i64, ptr) #0

declare swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr, i64, i1) #0

; Function Attrs: nounwind
declare ptr @swift_bridgeObjectRetain(ptr returned) #6

define private swiftcc void @objectdestroy(ptr swiftself %0) #0 {
entry:
  call void @swift_deallocObject(ptr %0, i64 48, i64 15) #6
  ret void
}

; Function Attrs: nounwind
declare void @swift_deallocObject(ptr, i64, i64) #6

; Function Attrs: nounwind
declare ptr @swift_allocObject(ptr, i64, i64) #6

declare swiftcc i64 @"$sSa5countSivg"(ptr, ptr) #0

define linkonce_odr hidden swiftcc ptr @"$ss27_finalizeUninitializedArrayySayxGABnlF"(ptr %0, ptr %Element) #0 {
entry:
  %Element1 = alloca ptr, align 8
  %1 = alloca %TSa, align 8
  store ptr %Element, ptr %Element1, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr %1)
  %._buffer = getelementptr inbounds nuw %TSa, ptr %1, i32 0, i32 0
  %._buffer._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._buffer, i32 0, i32 0
  %._buffer._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._buffer._storage, i32 0, i32 0
  store ptr %0, ptr %._buffer._storage.rawValue, align 8
  %2 = call swiftcc %swift.metadata_response @"$sSaMa"(i64 0, ptr %Element) #19
  %3 = extractvalue %swift.metadata_response %2, 0
  call swiftcc void @"$sSa12_endMutationyyF"(ptr %3, ptr swiftself captures(none) dereferenceable(8) %1)
  %._buffer2 = getelementptr inbounds nuw %TSa, ptr %1, i32 0, i32 0
  %._buffer2._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._buffer2, i32 0, i32 0
  %._buffer2._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._buffer2._storage, i32 0, i32 0
  %4 = load ptr, ptr %._buffer2._storage.rawValue, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr %1)
  ret ptr %4
}

define linkonce_odr hidden swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA0_"() #0 {
entry:
  %0 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @".str.1. ", i64 1, i1 true)
  %1 = extractvalue { i64, ptr } %0, 0
  %2 = extractvalue { i64, ptr } %0, 1
  %3 = insertvalue { i64, ptr } undef, i64 %1, 0
  %4 = insertvalue { i64, ptr } %3, ptr %2, 1
  ret { i64, ptr } %4
}

define linkonce_odr hidden swiftcc { i64, ptr } @"$ss5print_9separator10terminatoryypd_S2StFfA1_"() #0 {
entry:
  %0 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @".str.1.\0A", i64 1, i1 true)
  %1 = extractvalue { i64, ptr } %0, 0
  %2 = extractvalue { i64, ptr } %0, 1
  %3 = insertvalue { i64, ptr } undef, i64 %1, 0
  %4 = insertvalue { i64, ptr } %3, ptr %2, 1
  ret { i64, ptr } %4
}

declare swiftcc void @"$ss5print_9separator10terminatoryypd_S2StF"(ptr, i64, ptr, i64, ptr) #0

; Function Attrs: nounwind
declare void @swift_bridgeObjectRelease(ptr) #6

declare swifttailcc void @"$sScTss5NeverORszABRs_rlE5yieldyyYaFZ"(ptr swiftasync) #0

; Function Attrs: nounwind memory(inaccessiblemem: readwrite)
declare swiftcc ptr @swift_task_alloc(i64) #7

; Function Attrs: nounwind memory(inaccessiblemem: readwrite)
declare swiftcc void @swift_task_dealloc(ptr) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #4

declare swiftcc void @"$sSlss16IndexingIteratorVyxG0B0RtzrlE04makeB0ACyF"(ptr noalias sret(%swift.opaque), ptr, ptr, ptr noalias swiftself) #0

; Function Attrs: noinline nounwind willreturn memory(read)
define linkonce_odr hidden ptr @__swift_instantiateConcreteTypeFromMangledNameV2(ptr %0, ptr %1) #8 {
entry:
  %2 = load atomic ptr, ptr %0 monotonic, align 8
  %3 = icmp eq ptr %2, null
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 1
  %7 = or i1 %6, %3
  br i1 %7, label %10, label %8

8:                                                ; preds = %10, %entry
  %9 = phi ptr [ %2, %entry ], [ %18, %10 ]
  ret ptr %9

10:                                               ; preds = %entry
  %11 = load i64, ptr %1, align 8
  %12 = ashr i64 %11, 32
  %13 = trunc i64 %11 to i32
  %14 = sext i32 %13 to i64
  %15 = ptrtoint ptr %1 to i64
  %16 = add i64 %15, %14
  %17 = inttoptr i64 %16 to ptr
  %18 = call swiftcc ptr @swift_getTypeByMangledNameInContext2(ptr %17, i64 %12, ptr null, ptr null) #20
  store atomic ptr %18, ptr %0 monotonic, align 8
  br label %8
}

; Function Attrs: nounwind memory(argmem: readwrite)
declare swiftcc ptr @swift_getTypeByMangledNameInContext2(ptr, i64, ptr, ptr) #9

; Function Attrs: noinline nounwind memory(none)
define linkonce_odr hidden ptr @"$sSay3clt5RangeVGSayxGSlsWl"() #10 {
entry:
  %0 = load ptr, ptr @"$sSay3clt5RangeVGSayxGSlsWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = call ptr @__swift_instantiateConcreteTypeFromMangledNameAbstractV2(ptr @"$sSay3clt5RangeVGMd", ptr @"$sSay3clt5RangeVGMR") #11
  %3 = call ptr @swift_getWitnessTable(ptr @"$sSayxGSlsMc", ptr %2, ptr undef) #11
  store atomic ptr %3, ptr @"$sSay3clt5RangeVGSayxGSlsWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %4 = phi ptr [ %0, %entry ], [ %3, %cacheIsNull ]
  ret ptr %4
}

; Function Attrs: noinline nounwind willreturn memory(read)
define linkonce_odr hidden ptr @__swift_instantiateConcreteTypeFromMangledNameAbstractV2(ptr %0, ptr %1) #8 {
entry:
  %2 = load atomic ptr, ptr %0 monotonic, align 8
  %3 = icmp eq ptr %2, null
  br i1 %3, label %9, label %4

4:                                                ; preds = %9, %entry
  %5 = phi ptr [ %2, %entry ], [ %20, %9 ]
  %6 = ptrtoint ptr %5 to i64
  %7 = and i64 %6, -2
  %8 = inttoptr i64 %7 to ptr
  ret ptr %8

9:                                                ; preds = %entry
  %10 = load i64, ptr %1, align 8
  %11 = ashr i64 %10, 32
  %12 = trunc i64 %10 to i32
  %13 = sext i32 %12 to i64
  %14 = ptrtoint ptr %1 to i64
  %15 = add i64 %14, %13
  %16 = inttoptr i64 %15 to ptr
  %17 = call swiftcc ptr @swift_getTypeByMangledNameInContextInMetadataState2(i64 255, ptr %16, i64 %11, ptr null, ptr null) #20
  %18 = ptrtoint ptr %17 to i64
  %19 = or i64 %18, 1
  %20 = inttoptr i64 %19 to ptr
  store atomic ptr %20, ptr %0 monotonic, align 8
  br label %4
}

; Function Attrs: nounwind memory(argmem: readwrite)
declare swiftcc ptr @swift_getTypeByMangledNameInContextInMetadataState2(i64, ptr, i64, ptr, ptr) #9

; Function Attrs: nounwind memory(read)
declare ptr @swift_getWitnessTable(ptr, ptr, ptr) #11

declare swiftcc void @"$ss16IndexingIteratorV4next7ElementQzSgyF"(ptr noalias sret(%swift.opaque), ptr, ptr swiftself) #0

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #12

; Function Attrs: noinline nounwind
define linkonce_odr hidden ptr @"$ss16IndexingIteratorVySay3clt5RangeVGGWOh"(ptr %0) #13 {
entry:
  %._elements = getelementptr inbounds nuw %Ts16IndexingIteratorVySay3clt5RangeVGG, ptr %0, i32 0, i32 0
  %._elements._buffer = getelementptr inbounds nuw %TSa, ptr %._elements, i32 0, i32 0
  %._elements._buffer._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._elements._buffer, i32 0, i32 0
  %._elements._buffer._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._elements._buffer._storage, i32 0, i32 0
  %toDestroy = load ptr, ptr %._elements._buffer._storage.rawValue, align 8
  call void @swift_bridgeObjectRelease(ptr %toDestroy) #6
  ret ptr %0
}

define private swiftcc void @objectdestroy.4(ptr swiftself %0) #0 {
entry:
  call void @swift_deallocObject(ptr %0, i64 80, i64 15) #6
  ret void
}

declare swiftcc { i64, i64 } @"$sScA15unownedExecutorScevgTj"(ptr swiftself, ptr, ptr) #0

; Function Attrs: noinline
define hidden swifttailcc void @"$s3clt4MainV4mainyyYaFZ"(ptr swiftasync %0) #1 {
entry:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %2 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %0, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr %2)
  %3 = call swiftcc %swift.metadata_response @"$sScMMa"(i64 0) #19
  %4 = extractvalue %swift.metadata_response %3, 0
  %5 = call swiftcc ptr @"$sScM6sharedScMvgZ"(ptr swiftself %4)
  %.spill.addr = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  store ptr %5, ptr %.spill.addr, align 8
  %6 = call swiftcc { i64, i64 } @"$sScA15unownedExecutorScevgTj"(ptr swiftself %5, ptr %4, ptr @"$sScMScAsWP")
  %7 = extractvalue { i64, i64 } %6, 0
  %.spill.addr5 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  store i64 %7, ptr %.spill.addr5, align 8
  %8 = extractvalue { i64, i64 } %6, 1
  %.spill.addr8 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  store i64 %8, ptr %.spill.addr8, align 8
  %9 = load ptr, ptr %1, align 8
  %10 = load ptr, ptr %1, align 8
  musttail call swifttailcc void @swift_task_switch(ptr swiftasync %10, ptr @"$s3clt4MainV4mainyyYaFZTY0_", i64 %7, i64 %8) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt4MainV4mainyyYaFZTY0_"(ptr swiftasync %0) #2 {
entryresume.0:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %2 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %0, ptr %1, align 8
  %3 = call swiftcc { i128, i128 } @"$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC"(i128 0, i128 1)
  %4 = extractvalue { i128, i128 } %3, 0
  %5 = extractvalue { i128, i128 } %3, 1
  %6 = call swiftcc { i128, i128 } @"$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC"(i128 10, i128 1)
  %7 = extractvalue { i128, i128 } %6, 0
  %8 = extractvalue { i128, i128 } %6, 1
  call swiftcc void @"$s3clt5RangeV5start3endAcA5ExactV_AGtcfC"(ptr noalias sret(%T3clt5RangeV) captures(none) %2, i128 %4, i128 %5, i128 %7, i128 %8)
  call void asm sideeffect "", "r"(ptr %2)
  %9 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @".str.8./fixture", i64 8, i1 true)
  %10 = extractvalue { i64, ptr } %9, 0
  %11 = extractvalue { i64, ptr } %9, 1
  %.spill.addr11 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  store ptr %11, ptr %.spill.addr11, align 8
  %12 = call swiftcc { i64, ptr } @"$sSS21_builtinStringLiteral17utf8CodeUnitCount7isASCIISSBp_BwBi1_tcfC"(ptr @.str.5.audio, i64 5, i1 true)
  %13 = extractvalue { i64, ptr } %12, 0
  %14 = extractvalue { i64, ptr } %12, 1
  %.spill.addr14 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  store ptr %14, ptr %.spill.addr14, align 8
  %15 = ptrtoint ptr %14 to i64
  %16 = call swiftcc { i128, i128 } @"$s3clt5ExactV9numerator11denominatorACs6Int128V_AGtcfC"(i128 -100, i128 1)
  %17 = extractvalue { i128, i128 } %16, 0
  %18 = extractvalue { i128, i128 } %16, 1
  %19 = call swiftcc { ptr, ptr } @"$ss27_allocateUninitializedArrayySayxG_BptBwlF"(i64 1, ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2))
  %20 = extractvalue { ptr, ptr } %19, 0
  %21 = extractvalue { ptr, ptr } %19, 1
  %22 = getelementptr inbounds i8, ptr %20, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 16 %2, i64 64, i1 false)
  %23 = call swiftcc ptr @"$ss27_finalizeUninitializedArrayySayxGABnlF"(ptr %20, ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2))
  %.spill.addr17 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  store ptr %23, ptr %.spill.addr17, align 8
  %24 = call swiftcc i1 @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFfA3_"()
  %25 = load i32, ptr getelementptr inbounds nuw (%swift.async_func_pointer, ptr @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaFTu", i32 0, i32 1), align 4
  %26 = zext i32 %25 to i64
  %27 = call swiftcc ptr @swift_task_alloc(i64 %26) #7
  %.spill.addr20 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 8
  store ptr %27, ptr %.spill.addr20, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %27)
  %28 = load ptr, ptr %1, align 8
  %29 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %27, i32 0, i32 0
  store ptr %28, ptr %29, align 8
  %30 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %27, i32 0, i32 1
  store ptr @"$s3clt4MainV4mainyyYaFZTQ1_", ptr %30, align 8
  musttail call swifttailcc void @"$s3clt7inspect4path2id6offset9available6strictySS_SSSgAA5ExactVSayAA5RangeVGSbtYaF"(ptr swiftasync %27, i64 %10, ptr %11, i64 %13, i64 %15, i128 %17, i128 %18, ptr %23, i1 %24) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt4MainV4mainyyYaFZTQ1_"(ptr swiftasync %0) #3 {
entryresume.1:
  %1 = load ptr, ptr %0, align 8
  %2 = call ptr @llvm.swift.async.context.addr()
  store ptr %1, ptr %2, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %4 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr21 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 8
  %.reload22 = load ptr, ptr %.reload.addr21, align 8
  %.reload.addr18 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 7
  %.reload19 = load ptr, ptr %.reload.addr18, align 8
  %.reload.addr15 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 6
  %.reload16 = load ptr, ptr %.reload.addr15, align 8
  %.reload.addr12 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 5
  %.reload13 = load ptr, ptr %.reload.addr12, align 8
  %5 = ptrtoint ptr %.reload16 to i64
  %6 = load ptr, ptr %0, align 8
  store ptr %6, ptr %3, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload22) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload22)
  call void @swift_bridgeObjectRelease(ptr %.reload19) #6
  %7 = inttoptr i64 %5 to ptr
  call void @swift_bridgeObjectRelease(ptr %7) #6
  call void @swift_bridgeObjectRelease(ptr %.reload13) #6
  %8 = load ptr, ptr %3, align 8
  %.reload.addr9 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 4
  %.reload10 = load i64, ptr %.reload.addr9, align 8
  %.reload.addr6 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %.reload7 = load i64, ptr %.reload.addr6, align 8
  musttail call swifttailcc void @swift_task_switch(ptr swiftasync %8, ptr @"$s3clt4MainV4mainyyYaFZTY2_", i64 %.reload7, i64 %.reload10) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt4MainV4mainyyYaFZTY2_"(ptr swiftasync %0) #2 {
entryresume.2:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %2 = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr = getelementptr inbounds %"$s3clt4MainV4mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %.reload = load ptr, ptr %.reload.addr, align 8
  store ptr %0, ptr %1, align 8
  call void @swift_release(ptr %.reload) #6
  call void @llvm.lifetime.end.p0(i64 64, ptr %2)
  %3 = load ptr, ptr %1, align 8
  %4 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %3, i32 0, i32 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %1, align 8
  musttail call swifttailcc void %5(ptr swiftasync %6) #6
  ret void
}

declare swiftcc %swift.metadata_response @"$sScMMa"(i64) #0

declare swiftcc ptr @"$sScM6sharedScMvgZ"(ptr swiftself) #0

; Function Attrs: nounwind
declare void @swift_release(ptr) #6

; Function Attrs: noinline
define hidden swifttailcc void @"$s3clt4MainV5$mainyyYaFZ"(ptr swiftasync %0) #1 {
entry:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %0, ptr %1, align 8
  %2 = call swiftcc %swift.metadata_response @"$sScMMa"(i64 0) #19
  %3 = extractvalue %swift.metadata_response %2, 0
  %.spill.addr = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  store ptr %3, ptr %.spill.addr, align 8
  %4 = call swiftcc ptr @"$sScM6sharedScMvgZ"(ptr swiftself %3)
  %.spill.addr3 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  store ptr %4, ptr %.spill.addr3, align 8
  %5 = load i32, ptr getelementptr inbounds nuw (%swift.async_func_pointer, ptr @"$s3clt4MainV4mainyyYaFZTu", i32 0, i32 1), align 4
  %6 = zext i32 %5 to i64
  %7 = call swiftcc ptr @swift_task_alloc(i64 %6) #7
  %.spill.addr8 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  store ptr %7, ptr %.spill.addr8, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %7)
  %8 = load ptr, ptr %1, align 8
  %9 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %7, i32 0, i32 0
  store ptr %8, ptr %9, align 8
  %10 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %7, i32 0, i32 1
  store ptr @"$s3clt4MainV5$mainyyYaFZTQ0_", ptr %10, align 8
  musttail call swifttailcc void @"$s3clt4MainV4mainyyYaFZ"(ptr swiftasync %7) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt4MainV5$mainyyYaFZTQ0_"(ptr swiftasync %0) #3 {
entryresume.0:
  %1 = load ptr, ptr %0, align 8
  %2 = call ptr @llvm.swift.async.context.addr()
  store ptr %1, ptr %2, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr9 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 3
  %.reload10 = load ptr, ptr %.reload.addr9, align 8
  %.reload.addr6 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %.reload7 = load ptr, ptr %.reload.addr6, align 8
  %.reload.addr = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %.reload = load ptr, ptr %.reload.addr, align 8
  %4 = load ptr, ptr %0, align 8
  store ptr %4, ptr %3, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload10) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload10)
  %5 = call swiftcc { i64, i64 } @"$sScA15unownedExecutorScevgTj"(ptr swiftself %.reload7, ptr %.reload, ptr @"$sScMScAsWP")
  %6 = extractvalue { i64, i64 } %5, 0
  %7 = extractvalue { i64, i64 } %5, 1
  %8 = load ptr, ptr %3, align 8
  %9 = load ptr, ptr %3, align 8
  musttail call swifttailcc void @swift_task_switch(ptr swiftasync %9, ptr @"$s3clt4MainV5$mainyyYaFZTY1_", i64 %6, i64 %7) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$s3clt4MainV5$mainyyYaFZTY1_"(ptr swiftasync %0) #2 {
entryresume.1:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr4 = getelementptr inbounds %"$s3clt4MainV5$mainyyYaFZ.Frame", ptr %async.ctx.frameptr, i32 0, i32 2
  %.reload5 = load ptr, ptr %.reload.addr4, align 8
  store ptr %0, ptr %1, align 8
  call void @swift_release(ptr %.reload5) #6
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %2, i32 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = load ptr, ptr %1, align 8
  musttail call swifttailcc void %4(ptr swiftasync %5) #6
  ret void
}

define hidden swiftcc void @"$s3clt4MainVACycfC"() #0 {
entry:
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @async_Main(ptr swiftasync %0) #1 {
entry:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %0, i32 16
  %1 = getelementptr inbounds %async_Main.Frame, ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %0, ptr %1, align 8
  %2 = load i32, ptr getelementptr inbounds nuw (%swift.async_func_pointer, ptr @"$s3clt4MainV5$mainyyYaFZTu", i32 0, i32 1), align 4
  %3 = zext i32 %2 to i64
  %4 = call swiftcc ptr @swift_task_alloc(i64 %3) #7
  %.spill.addr = getelementptr inbounds %async_Main.Frame, ptr %async.ctx.frameptr, i32 0, i32 1
  store ptr %4, ptr %.spill.addr, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %4)
  %5 = load ptr, ptr %1, align 8
  %6 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %4, i32 0, i32 0
  store ptr %5, ptr %6, align 8
  %7 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %4, i32 0, i32 1
  store ptr @async_MainTQ0_, ptr %7, align 8
  musttail call swifttailcc void @"$s3clt4MainV5$mainyyYaFZ"(ptr swiftasync %4) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @async_MainTQ0_(ptr swiftasync %0) #3 {
entryresume.0:
  %1 = load ptr, ptr %0, align 8
  %2 = call ptr @llvm.swift.async.context.addr()
  store ptr %1, ptr %2, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %async_Main.Frame, ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr = getelementptr inbounds %async_Main.Frame, ptr %async.ctx.frameptr, i32 0, i32 1
  %.reload = load ptr, ptr %.reload.addr, align 8
  %4 = load ptr, ptr %0, align 8
  store ptr %4, ptr %3, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload)
  call void @exit(i32 0)
  unreachable
}

define i32 @main(i32 %0, ptr %1) #0 {
entry:
  %2 = call noalias ptr @swift_allocObject(ptr getelementptr inbounds (%swift.full_boxmetadata, ptr @metadata.10, i32 0, i32 2), i64 24, i64 7) #6
  %3 = getelementptr inbounds nuw <{ %swift.refcounted, ptr }>, ptr %2, i32 0, i32 1
  store ptr @async_MainTu, ptr %3, align 8
  %4 = call swiftcc %swift.async_task_and_context @swift_task_create(i64 2048, ptr null, ptr getelementptr inbounds (%swift.full_existential_type, ptr @"$sytN", i32 0, i32 1), ptr @"$sIetH_yts5Error_pIegHrzo_TRTATu", ptr %2) #11
  %5 = extractvalue %swift.async_task_and_context %4, 0
  %6 = extractvalue %swift.async_task_and_context %4, 1
  %7 = call swiftcc %swift.executor @swift_task_getMainExecutor() #14
  %8 = extractvalue %swift.executor %7, 0
  %9 = extractvalue %swift.executor %7, 1
  call swiftcc void @swift_job_run(ptr %5, i64 %8, i64 %9)
  call swiftcc void @swift_task_asyncMainDrainQueue()
  unreachable
}

; Function Attrs: noinline
define linkonce_odr hidden swifttailcc void @"$sIetH_yts5Error_pIegHrzo_TR"(ptr noalias captures(none) %0, ptr swiftasync %1, ptr %2) #1 {
entry:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TR.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %1, ptr %3, align 8
  %4 = getelementptr inbounds nuw %swift.async_func_pointer, ptr %2, i32 0, i32 0
  %5 = load i32, ptr %4, align 8
  %6 = sext i32 %5 to i64
  %7 = ptrtoint ptr %4 to i64
  %8 = add i64 %7, %6
  %9 = inttoptr i64 %8 to ptr
  %10 = getelementptr inbounds nuw %swift.async_func_pointer, ptr %2, i32 0, i32 1
  %11 = load i32, ptr %10, align 4
  %12 = zext i32 %11 to i64
  %13 = call swiftcc ptr @swift_task_alloc(i64 %12) #7
  %.spill.addr = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TR.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  store ptr %13, ptr %.spill.addr, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %13)
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %13, i32 0, i32 0
  store ptr %14, ptr %15, align 8
  %16 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %13, i32 0, i32 1
  store ptr @"$sIetH_yts5Error_pIegHrzo_TRTQ0_", ptr %16, align 8
  musttail call swifttailcc void %9(ptr swiftasync %13) #6
  ret void
}

; Function Attrs: noinline
define internal swifttailcc void @"$sIetH_yts5Error_pIegHrzo_TRTQ0_"(ptr swiftasync %0) #3 {
entryresume.0:
  %1 = load ptr, ptr %0, align 8
  %2 = call ptr @llvm.swift.async.context.addr()
  store ptr %1, ptr %2, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TR.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TR.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %.reload = load ptr, ptr %.reload.addr, align 8
  %4 = load ptr, ptr %0, align 8
  store ptr %4, ptr %3, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload)
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %5, i32 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = load ptr, ptr %3, align 8
  musttail call swifttailcc void %7(ptr swiftasync %8, ptr swiftself null) #6
  ret void
}

define private swiftcc void @objectdestroy.9(ptr swiftself %0) #0 {
entry:
  call void @swift_deallocObject(ptr %0, i64 24, i64 7) #6
  ret void
}

define internal swifttailcc void @"$sIetH_yts5Error_pIegHrzo_TRTA"(ptr noalias captures(none) %0, ptr swiftasync %1, ptr swiftself %2) #0 {
entry:
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %1, i32 16
  %3 = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TRTA.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  store ptr %1, ptr %3, align 8
  %4 = getelementptr inbounds nuw <{ %swift.refcounted, ptr }>, ptr %2, i32 0, i32 1
  %5 = load ptr, ptr %4, align 8
  %6 = load i32, ptr @"$sIetH_yts5Error_pIegHrzo_TRTu", align 8
  %7 = sext i32 %6 to i64
  %8 = add i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTu" to i64), %7
  %9 = inttoptr i64 %8 to ptr
  %10 = load i32, ptr @"$sIetH_yts5Error_pIegHrzo_TRTu", align 8
  %11 = sext i32 %10 to i64
  %12 = add i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTu" to i64), %11
  %13 = inttoptr i64 %12 to ptr
  %14 = load i32, ptr getelementptr inbounds nuw (%swift.async_func_pointer, ptr @"$sIetH_yts5Error_pIegHrzo_TRTu", i32 0, i32 1), align 4
  %15 = zext i32 %14 to i64
  %16 = call swiftcc ptr @swift_task_alloc(i64 %15) #7
  %.spill.addr = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TRTA.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  store ptr %16, ptr %.spill.addr, align 8
  call void @llvm.lifetime.start.p0(i64 -1, ptr %16)
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %16, i32 0, i32 0
  store ptr %17, ptr %18, align 8
  %19 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %16, i32 0, i32 1
  store ptr @"$sIetH_yts5Error_pIegHrzo_TRTATQ0_", ptr %19, align 8
  %20 = load i32, ptr @"$sIetH_yts5Error_pIegHrzo_TRTu", align 8
  %21 = sext i32 %20 to i64
  %22 = add i64 ptrtoint (ptr @"$sIetH_yts5Error_pIegHrzo_TRTu" to i64), %21
  %23 = inttoptr i64 %22 to ptr
  musttail call swifttailcc void %23(ptr noalias captures(none) %0, ptr swiftasync %16, ptr %5) #6
  ret void
}

define internal swifttailcc void @"$sIetH_yts5Error_pIegHrzo_TRTATQ0_"(ptr swiftasync %0, ptr swiftself %1) #0 {
entryresume.0:
  %2 = load ptr, ptr %0, align 8
  %3 = call ptr @llvm.swift.async.context.addr()
  store ptr %2, ptr %3, align 8
  %async.ctx.frameptr = getelementptr inbounds i8, ptr %2, i32 16
  %4 = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TRTA.Frame", ptr %async.ctx.frameptr, i32 0, i32 0
  %.reload.addr = getelementptr inbounds %"$sIetH_yts5Error_pIegHrzo_TRTA.Frame", ptr %async.ctx.frameptr, i32 0, i32 1
  %.reload = load ptr, ptr %.reload.addr, align 8
  %5 = load ptr, ptr %0, align 8
  store ptr %5, ptr %4, align 8
  call swiftcc void @swift_task_dealloc(ptr %.reload) #7
  call void @llvm.lifetime.end.p0(i64 -1, ptr %.reload)
  %6 = load ptr, ptr %4, align 8
  %7 = getelementptr inbounds nuw <{ ptr, ptr }>, ptr %6, i32 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %4, align 8
  musttail call swifttailcc void %8(ptr swiftasync %9, ptr swiftself %1) #6
  ret void
}

; Function Attrs: nounwind memory(read)
declare swiftcc %swift.async_task_and_context @swift_task_create(i64, ptr, ptr, ptr, ptr) #11

declare swiftcc void @swift_job_run(ptr, i64, i64) #0

; Function Attrs: nounwind willreturn memory(argmem: readwrite)
declare swiftcc %swift.executor @swift_task_getMainExecutor() #14

declare swiftcc void @swift_task_asyncMainDrainQueue() #0

; Function Attrs: nounwind
define internal ptr @"$s3clt5ExactVwCP"(ptr noalias %dest, ptr noalias %src, ptr %Exact) #15 {
entry:
  %0 = load ptr, ptr %src, align 8
  %1 = call ptr @swift_retain(ptr returned %0) #16
  store ptr %0, ptr %dest, align 8
  %2 = load ptr, ptr %dest, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 16
  ret ptr %3
}

; Function Attrs: nounwind willreturn
declare ptr @swift_retain(ptr returned) #16

; Function Attrs: nounwind
define linkonce_odr hidden void @__swift_noop_void_return(ptr %0, ptr %1) #15 {
entry:
  ret void
}

; Function Attrs: nounwind
define linkonce_odr hidden ptr @__swift_memcpy32_16(ptr %0, ptr %1, ptr %2) #15 {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 32, i1 false)
  ret ptr %0
}

; Function Attrs: nounwind memory(read)
define internal i32 @"$s3clt5ExactVwet"(ptr noalias %value, i32 %numEmptyCases, ptr %Exact) #17 {
entry:
  %0 = icmp eq i32 0, %numEmptyCases
  br i1 %0, label %31, label %1

1:                                                ; preds = %entry
  %2 = icmp ugt i32 %numEmptyCases, 0
  br i1 %2, label %3, label %30

3:                                                ; preds = %1
  %4 = sub i32 %numEmptyCases, 0
  %5 = getelementptr inbounds i8, ptr %value, i32 32
  br i1 false, label %6, label %7

6:                                                ; preds = %3
  br label %19

7:                                                ; preds = %3
  br i1 true, label %8, label %11

8:                                                ; preds = %7
  %9 = load i8, ptr %5, align 1
  %10 = zext i8 %9 to i32
  br label %19

11:                                               ; preds = %7
  br i1 false, label %12, label %15

12:                                               ; preds = %11
  %13 = load i16, ptr %5, align 1
  %14 = zext i16 %13 to i32
  br label %19

15:                                               ; preds = %11
  br i1 false, label %16, label %18

16:                                               ; preds = %15
  %17 = load i32, ptr %5, align 1
  br label %19

18:                                               ; preds = %15
  unreachable

19:                                               ; preds = %16, %12, %8, %6
  %20 = phi i32 [ 0, %6 ], [ %10, %8 ], [ %14, %12 ], [ %17, %16 ]
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %30, label %22

22:                                               ; preds = %19
  %23 = sub i32 %20, 1
  %24 = shl i32 %23, 256
  %25 = select i1 true, i32 0, i32 %24
  %26 = load i256, ptr %value, align 1
  %27 = trunc i256 %26 to i32
  %28 = or i32 %27, %25
  %29 = add i32 0, %28
  br label %32

30:                                               ; preds = %19, %1
  br label %32

31:                                               ; preds = %entry
  br label %32

32:                                               ; preds = %31, %30, %22
  %33 = phi i32 [ -1, %30 ], [ %29, %22 ], [ -1, %31 ]
  %34 = add i32 %33, 1
  ret i32 %34
}

; Function Attrs: nounwind
define internal void @"$s3clt5ExactVwst"(ptr noalias %value, i32 %whichCase, i32 %numEmptyCases, ptr %Exact) #15 {
entry:
  %0 = getelementptr inbounds i8, ptr %value, i32 32
  %1 = icmp ugt i32 %numEmptyCases, 0
  br i1 %1, label %2, label %4

2:                                                ; preds = %entry
  %3 = sub i32 %numEmptyCases, 0
  br label %4

4:                                                ; preds = %2, %entry
  %5 = phi i32 [ 0, %entry ], [ 1, %2 ]
  %6 = icmp ule i32 %whichCase, 0
  br i1 %6, label %7, label %23

7:                                                ; preds = %4
  %8 = icmp eq i32 %5, 0
  br i1 %8, label %9, label %10

9:                                                ; preds = %7
  br label %20

10:                                               ; preds = %7
  %11 = icmp eq i32 %5, 1
  br i1 %11, label %12, label %13

12:                                               ; preds = %10
  store i8 0, ptr %0, align 16
  br label %20

13:                                               ; preds = %10
  %14 = icmp eq i32 %5, 2
  br i1 %14, label %15, label %16

15:                                               ; preds = %13
  store i16 0, ptr %0, align 16
  br label %20

16:                                               ; preds = %13
  %17 = icmp eq i32 %5, 4
  br i1 %17, label %18, label %19

18:                                               ; preds = %16
  store i32 0, ptr %0, align 16
  br label %20

19:                                               ; preds = %16
  unreachable

20:                                               ; preds = %18, %15, %12, %9
  %21 = icmp eq i32 %whichCase, 0
  br i1 %21, label %49, label %22

22:                                               ; preds = %20
  br label %49

23:                                               ; preds = %4
  %24 = sub i32 %whichCase, 1
  %25 = sub i32 %24, 0
  br i1 true, label %30, label %26

26:                                               ; preds = %23
  %27 = lshr i32 %25, 256
  %28 = add i32 1, %27
  %29 = and i32 poison, %25
  br label %30

30:                                               ; preds = %26, %23
  %31 = phi i32 [ 1, %23 ], [ %28, %26 ]
  %32 = phi i32 [ %25, %23 ], [ %29, %26 ]
  %33 = zext i32 %32 to i256
  store i256 %33, ptr %value, align 16
  %34 = icmp eq i32 %5, 0
  br i1 %34, label %35, label %36

35:                                               ; preds = %30
  br label %48

36:                                               ; preds = %30
  %37 = icmp eq i32 %5, 1
  br i1 %37, label %38, label %40

38:                                               ; preds = %36
  %39 = trunc i32 %31 to i8
  store i8 %39, ptr %0, align 16
  br label %48

40:                                               ; preds = %36
  %41 = icmp eq i32 %5, 2
  br i1 %41, label %42, label %44

42:                                               ; preds = %40
  %43 = trunc i32 %31 to i16
  store i16 %43, ptr %0, align 16
  br label %48

44:                                               ; preds = %40
  %45 = icmp eq i32 %5, 4
  br i1 %45, label %46, label %47

46:                                               ; preds = %44
  store i32 %31, ptr %0, align 16
  br label %48

47:                                               ; preds = %44
  unreachable

48:                                               ; preds = %46, %42, %38, %35
  br label %49

49:                                               ; preds = %48, %22, %20
  ret void
}

; Function Attrs: noinline nounwind memory(none)
define hidden swiftcc %swift.metadata_response @"$s3clt5ExactVMa"(i64 %0) #10 {
entry:
  ret %swift.metadata_response { ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5ExactVMf", i32 0, i32 2), i64 0 }
}

; Function Attrs: nounwind
define internal ptr @"$s3clt5RangeVwCP"(ptr noalias %dest, ptr noalias %src, ptr %Range) #15 {
entry:
  %0 = load ptr, ptr %src, align 8
  %1 = call ptr @swift_retain(ptr returned %0) #16
  store ptr %0, ptr %dest, align 8
  %2 = load ptr, ptr %dest, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 16
  ret ptr %3
}

; Function Attrs: nounwind
define linkonce_odr hidden ptr @__swift_memcpy64_16(ptr %0, ptr %1, ptr %2) #15 {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 64, i1 false)
  ret ptr %0
}

; Function Attrs: nounwind memory(read)
define internal i32 @"$s3clt5RangeVwet"(ptr noalias %value, i32 %numEmptyCases, ptr %Range) #17 {
entry:
  %0 = icmp eq i32 0, %numEmptyCases
  br i1 %0, label %31, label %1

1:                                                ; preds = %entry
  %2 = icmp ugt i32 %numEmptyCases, 0
  br i1 %2, label %3, label %30

3:                                                ; preds = %1
  %4 = sub i32 %numEmptyCases, 0
  %5 = getelementptr inbounds i8, ptr %value, i32 64
  br i1 false, label %6, label %7

6:                                                ; preds = %3
  br label %19

7:                                                ; preds = %3
  br i1 true, label %8, label %11

8:                                                ; preds = %7
  %9 = load i8, ptr %5, align 1
  %10 = zext i8 %9 to i32
  br label %19

11:                                               ; preds = %7
  br i1 false, label %12, label %15

12:                                               ; preds = %11
  %13 = load i16, ptr %5, align 1
  %14 = zext i16 %13 to i32
  br label %19

15:                                               ; preds = %11
  br i1 false, label %16, label %18

16:                                               ; preds = %15
  %17 = load i32, ptr %5, align 1
  br label %19

18:                                               ; preds = %15
  unreachable

19:                                               ; preds = %16, %12, %8, %6
  %20 = phi i32 [ 0, %6 ], [ %10, %8 ], [ %14, %12 ], [ %17, %16 ]
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %30, label %22

22:                                               ; preds = %19
  %23 = sub i32 %20, 1
  %24 = shl i32 %23, 512
  %25 = select i1 true, i32 0, i32 %24
  %26 = load i512, ptr %value, align 1
  %27 = trunc i512 %26 to i32
  %28 = or i32 %27, %25
  %29 = add i32 0, %28
  br label %32

30:                                               ; preds = %19, %1
  br label %32

31:                                               ; preds = %entry
  br label %32

32:                                               ; preds = %31, %30, %22
  %33 = phi i32 [ -1, %30 ], [ %29, %22 ], [ -1, %31 ]
  %34 = add i32 %33, 1
  ret i32 %34
}

; Function Attrs: nounwind
define internal void @"$s3clt5RangeVwst"(ptr noalias %value, i32 %whichCase, i32 %numEmptyCases, ptr %Range) #15 {
entry:
  %0 = getelementptr inbounds i8, ptr %value, i32 64
  %1 = icmp ugt i32 %numEmptyCases, 0
  br i1 %1, label %2, label %4

2:                                                ; preds = %entry
  %3 = sub i32 %numEmptyCases, 0
  br label %4

4:                                                ; preds = %2, %entry
  %5 = phi i32 [ 0, %entry ], [ 1, %2 ]
  %6 = icmp ule i32 %whichCase, 0
  br i1 %6, label %7, label %23

7:                                                ; preds = %4
  %8 = icmp eq i32 %5, 0
  br i1 %8, label %9, label %10

9:                                                ; preds = %7
  br label %20

10:                                               ; preds = %7
  %11 = icmp eq i32 %5, 1
  br i1 %11, label %12, label %13

12:                                               ; preds = %10
  store i8 0, ptr %0, align 16
  br label %20

13:                                               ; preds = %10
  %14 = icmp eq i32 %5, 2
  br i1 %14, label %15, label %16

15:                                               ; preds = %13
  store i16 0, ptr %0, align 16
  br label %20

16:                                               ; preds = %13
  %17 = icmp eq i32 %5, 4
  br i1 %17, label %18, label %19

18:                                               ; preds = %16
  store i32 0, ptr %0, align 16
  br label %20

19:                                               ; preds = %16
  unreachable

20:                                               ; preds = %18, %15, %12, %9
  %21 = icmp eq i32 %whichCase, 0
  br i1 %21, label %49, label %22

22:                                               ; preds = %20
  br label %49

23:                                               ; preds = %4
  %24 = sub i32 %whichCase, 1
  %25 = sub i32 %24, 0
  br i1 true, label %30, label %26

26:                                               ; preds = %23
  %27 = lshr i32 %25, 512
  %28 = add i32 1, %27
  %29 = and i32 poison, %25
  br label %30

30:                                               ; preds = %26, %23
  %31 = phi i32 [ 1, %23 ], [ %28, %26 ]
  %32 = phi i32 [ %25, %23 ], [ %29, %26 ]
  %33 = zext i32 %32 to i512
  store i512 %33, ptr %value, align 16
  %34 = icmp eq i32 %5, 0
  br i1 %34, label %35, label %36

35:                                               ; preds = %30
  br label %48

36:                                               ; preds = %30
  %37 = icmp eq i32 %5, 1
  br i1 %37, label %38, label %40

38:                                               ; preds = %36
  %39 = trunc i32 %31 to i8
  store i8 %39, ptr %0, align 16
  br label %48

40:                                               ; preds = %36
  %41 = icmp eq i32 %5, 2
  br i1 %41, label %42, label %44

42:                                               ; preds = %40
  %43 = trunc i32 %31 to i16
  store i16 %43, ptr %0, align 16
  br label %48

44:                                               ; preds = %40
  %45 = icmp eq i32 %5, 4
  br i1 %45, label %46, label %47

46:                                               ; preds = %44
  store i32 %31, ptr %0, align 16
  br label %48

47:                                               ; preds = %44
  unreachable

48:                                               ; preds = %46, %42, %38, %35
  br label %49

49:                                               ; preds = %48, %22, %20
  ret void
}

; Function Attrs: noinline nounwind memory(none)
define hidden swiftcc %swift.metadata_response @"$s3clt5RangeVMa"(i64 %0) #10 {
entry:
  ret %swift.metadata_response { ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s3clt5RangeVMf", i32 0, i32 2), i64 0 }
}

; Function Attrs: noinline nounwind memory(none)
define hidden swiftcc %swift.metadata_response @"$s3clt4MainVMa"(i64 %0) #10 {
entry:
  ret %swift.metadata_response { ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr }>, ptr @"$s3clt4MainVMf", i32 0, i32 2), i64 0 }
}

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftFoundation"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swift_Builtin_float"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftObjectiveC"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftCoreFoundation"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftDispatch"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftXPC"()

declare extern_weak void @"_swift_FORCE_LOAD_$_swiftIOKit"()

; Function Attrs: noreturn
declare void @exit(i32 noundef) #18

define linkonce_odr hidden swiftcc void @"$sSa12_endMutationyyF"(ptr %"Array<Element>", ptr swiftself captures(none) dereferenceable(8) %0) #0 {
entry:
  %._buffer = getelementptr inbounds nuw %TSa, ptr %0, i32 0, i32 0
  %._buffer._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._buffer, i32 0, i32 0
  %._buffer._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._buffer._storage, i32 0, i32 0
  %1 = load ptr, ptr %._buffer._storage.rawValue, align 8
  %._buffer1 = getelementptr inbounds nuw %TSa, ptr %0, i32 0, i32 0
  %._buffer1._storage = getelementptr inbounds nuw %Ts12_ArrayBufferV, ptr %._buffer1, i32 0, i32 0
  %._buffer1._storage.rawValue = getelementptr inbounds nuw %Ts14_BridgeStorageV, ptr %._buffer1._storage, i32 0, i32 0
  store ptr %1, ptr %._buffer1._storage.rawValue, align 8
  ret void
}

declare swiftcc %swift.metadata_response @"$sSaMa"(i64, ptr) #0

attributes #0 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { noinline "async_entry" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #2 = { noinline "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { noinline "async_ret" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { nounwind }
attributes #7 = { nounwind memory(inaccessiblemem: readwrite) }
attributes #8 = { noinline nounwind willreturn memory(read) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #9 = { nounwind memory(argmem: readwrite) }
attributes #10 = { noinline nounwind memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #11 = { nounwind memory(read) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #13 = { noinline nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #14 = { nounwind willreturn memory(argmem: readwrite) }
attributes #15 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #16 = { nounwind willreturn }
attributes #17 = { nounwind memory(read) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #18 = { noreturn "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #19 = { nounwind memory(none) }
attributes #20 = { nounwind memory(argmem: read) }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5, !6, !7, !8, !9, !10, !11}
!swift.module.flags = !{!12}
!llvm.linker.options = !{!13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !36, !37, !38}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 26, i32 5]}
!1 = !{i32 1, !"Objective-C Version", i32 2}
!2 = !{i32 1, !"Objective-C Image Info Version", i32 0}
!3 = !{i32 1, !"Objective-C Image Info Section", !"__DATA,__objc_imageinfo,regular,no_dead_strip"}
!4 = !{i32 4, !"Objective-C Garbage Collection", i32 100861696}
!5 = !{i32 1, !"Objective-C Class Properties", i32 64}
!6 = !{i32 1, !"Objective-C Enforce ClassRO Pointer Signing", i8 0}
!7 = !{i32 1, !"wchar_size", i32 4}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 1}
!10 = !{i32 7, !"frame-pointer", i32 1}
!11 = !{i32 1, !"Swift Version", i32 7}
!12 = !{!"standard-library", i1 false}
!13 = !{!"-lswiftFoundation"}
!14 = !{!"-framework", !"Foundation"}
!15 = !{!"-lswiftCore"}
!16 = !{!"-lswift_DarwinFoundation3"}
!17 = !{!"-lswift_DarwinFoundation1"}
!18 = !{!"-lswift_DarwinFoundation2"}
!19 = !{!"-lswift_StringProcessing"}
!20 = !{!"-lswift_Concurrency"}
!21 = !{!"-lswiftSystem"}
!22 = !{!"-lswiftDarwin"}
!23 = !{!"-lswift_Builtin_float"}
!24 = !{!"-lswiftObservation"}
!25 = !{!"-lswiftObjectiveC"}
!26 = !{!"-lswiftCoreFoundation"}
!27 = !{!"-framework", !"CoreFoundation"}
!28 = !{!"-lswiftDispatch"}
!29 = !{!"-framework", !"Combine"}
!30 = !{!"-framework", !"CoreServices"}
!31 = !{!"-framework", !"Security"}
!32 = !{!"-lswiftXPC"}
!33 = !{!"-framework", !"CFNetwork"}
!34 = !{!"-framework", !"DiskArbitration"}
!35 = !{!"-lswiftIOKit"}
!36 = !{!"-framework", !"IOKit"}
!37 = !{!"-lswiftSwiftOnoneSupport"}
!38 = !{!"-lobjc"}
