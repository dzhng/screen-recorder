@preconcurrency import AVFoundation
import Foundation
@testable import ScreenRecorderCapture
import ScreenRecorderMedia
@main enum Metadata {
 static func main() async throws {
  let asset = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]))
  let track = try await asset.loadTracks(withMediaType: .video).first!
  let segments = SourceSegment.occupied(of: try await track.load(.segments))
  let scale = try await track.load(.naturalTimeScale)
  let mapping = try CameraMedia.Mapping(URL(fileURLWithPath: CommandLine.arguments[2]))
  var count = 0
  var previous: CMTime?
  print("scale=\(scale) segments=\(segments)")
  try visitPresentedSamples(track: track, segments: segments) { native in
   let frame = try mapping.next()!
   let segment = segments.first { $0.asset.containsTime(native.start) }!
   let sought = segment.mediaTime(ofAsset: native.start)
   let cursor = track.makeSampleCursor(presentationTimeStamp: sought)!
   let range = try frame.acquisitionRange(scale: scale)
   let valid = range.start == native.start && (previous.map { $0 < frame.start.time } ?? true) && cursor.presentationTimeStamp == sought
   if !valid { print("MISMATCH row=\(count) range=\(range.start) native=\(native.start) previous=\(String(describing: previous)) map=\(frame.start.time) sought=\(sought) cursor=\(cursor.presentationTimeStamp)") }
   previous = frame.start.time
   if count < 4 { print("row=\(count) mapped=\(frame.start.time) native=\(native.start) sought=\(sought) cursor=\(cursor.presentationTimeStamp) fullSync=\(cursor.currentSampleSyncInfo.sampleIsFullSync.boolValue)") }
   count += 1
  }
  print("count=\(count)")
 }
}
