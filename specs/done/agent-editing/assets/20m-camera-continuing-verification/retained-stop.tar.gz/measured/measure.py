import datetime, hashlib, json, os, signal, subprocess, time
from pathlib import Path
r=Path(__file__).parent
source=Path('/Users/david/dev/screen-recorder/fixtures/screen-camera-timing/camera/camera.raw.mov')
cmd=[str(r/'probe'),str(r/'case'),str(source)]
link=json.loads((r/'plan.json').read_text())['link']
base=Path('/tmp/screenrec-camera-live-stop-scale')
paths={source,r/'probe',r/'measure.py',r/'Probe.swift',base/'settled/CameraMedia.swift',base/'settled/CameraMedia.o'}
paths.update(Path(x) for x in link if Path(x).is_file())
for folder in [base/'settled/Modules',Path('/tmp/screenrec-20f-camera-overlap/final/Modules')]: paths.update(p for p in folder.rglob('*') if p.is_file())
w=Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder')
paths.update((w/'helpers/mac/Sources/ScreenRecorderCapture').glob('*.swift'))
paths.add(w/'helpers/mac/Tests/ScreenRecorderCaptureTests/CameraLivePublicationTests.swift')
def pin(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
def pins():return [pin(p) for p in sorted(paths)]
before=pins();(r/'before.json').write_text(json.dumps(before,indent=2)+'\n')
original=next(p for p in before if p['path']==str(source))
assert original['bytes']==424848170 and original['sha256']=='dbeb5b1b8f9490d7bd0bad15f2fa006188c41e129904e264fd313bc9374af805'
assert (w/'helpers/mac/Sources/ScreenRecorderCapture/CameraMedia.swift').read_bytes()==(base/'settled/CameraMedia.swift').read_bytes()
t0=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat(); samples=[];reason=None
with (r/'native.stdout').open('wb') as out,(r/'native.stderr').open('wb') as err:
 child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
 active={'pid':child.pid,'command':cmd,'start':start,'wholeProcessBoundSeconds':420,'sampledRSSBoundBytes':4*1024**3,'sampleIntervalSeconds':0.25}
 (r/'active.json').write_text(json.dumps(active,indent=2)+'\n');print(json.dumps(active),flush=True)
 while child.poll() is None:
  elapsed=time.monotonic()-t0
  p=subprocess.run(['/bin/ps','-o','rss=','-p',str(child.pid)],capture_output=True,text=True)
  value=p.stdout.strip()
  if value:
   rss=int(value)*1024;samples.append({'seconds':elapsed,'rssBytes':rss})
   if rss>4*1024**3:reason='sampled-rss-bound'
  if elapsed>=420:reason='whole-process-bound'
  if reason:
   os.killpg(child.pid,signal.SIGKILL);break
  time.sleep(.25)
 code=child.wait()
 terminal={**active,'exitCode':code,'terminal':True,'waited':True,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-t0,'guardOutcome':reason or 'within-bounds','peakSampledRSSBytes':max((x['rssBytes'] for x in samples),default=0)}
 (r/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');(r/'rss.json').write_text(json.dumps(samples,indent=2)+'\n');print(json.dumps(terminal),flush=True)
after=pins();(r/'after.json').write_text(json.dumps(after,indent=2)+'\n')
(r/'preservation.json').write_text(json.dumps({'beforeEqualsAfter':before==after,'bindings':len(before)},indent=2)+'\n')
assert before==after,'Protected input or runtime changed'
raise SystemExit(0 if code==0 and reason is None else 1)
