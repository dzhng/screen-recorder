import Foundation
import Darwin
@main enum Probe {
 @MainActor static func main() async {
  do { try await runSelectedCaptureStopScale(output: CommandLine.arguments[1], sourcePath: CommandLine.arguments[2]) }
  catch { FileHandle.standardError.write(Data(String(describing: error).utf8)); exit(1) }
 }
}
