import Foundation
@main enum Probe { static func main() { runCameraCheckpointSchedulingTest() } }
