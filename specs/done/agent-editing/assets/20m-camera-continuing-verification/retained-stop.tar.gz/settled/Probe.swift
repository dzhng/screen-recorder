import Foundation
import Darwin
@main enum Probe { @MainActor static func main() async { runCameraCheckpointSchedulingTest(); do { try await runCameraStableMediaTest(output: CommandLine.arguments[1]) } catch { FileHandle.standardError.write(Data(String(describing:error).utf8)); exit(1) } } }
