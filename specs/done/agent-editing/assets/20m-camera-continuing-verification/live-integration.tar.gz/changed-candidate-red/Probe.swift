import Foundation
import Darwin
@main enum Probe {
    @MainActor static func main() async {
        do { try await runCameraLivePublicationTest(output: CommandLine.arguments[1], changedCandidateRetry: true); exit(0) }
        catch { FileHandle.standardError.write(Data(String(describing: error).utf8)); exit(1) }
    }
}
