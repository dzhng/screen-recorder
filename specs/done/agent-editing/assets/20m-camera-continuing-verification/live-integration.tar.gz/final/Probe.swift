import Foundation
import Darwin
@main enum Probe {
 @MainActor static func main() async {
  do {
   switch CommandLine.arguments[1] {
   case "live": try await runCameraLivePublicationTests(output: CommandLine.arguments[2])
   case "clock": try await runIndependentCameraClockTests(output: CommandLine.arguments[2])
   default:
    try await runProbeCameraPixelPublicationTests(widths: [32])
    try await runCameraPublicationClippedSupportTest()
    try await runCameraPublicationPrefixTests()
    try await runCameraPublicationErrorOrderTest()
    try runCameraPublicationDecisionTests()
    try await runCameraPublicationReplayTests()
   }
  } catch { FileHandle.standardError.write(Data(String(describing: error).utf8)); exit(1) }
 }
}
