import datetime,json,os,signal,subprocess,time
from pathlib import Path
r=Path(__file__).parent;p=json.loads((r/'plan.json').read_text());records=[]
for label,cmd in p.items():
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(label+'.stdout')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
  child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'phase':label,'pid':child.pid,'started':start}),flush=True)
  timeout=False
  try:code=child.wait(timeout=30 if label in ('test','live','clock','neighbors') else 150)
  except subprocess.TimeoutExpired:timeout=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 record={'phase':label,'pid':child.pid,'exitCode':code,'terminal':True,'waited':True,'timeout':timeout,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-t,'command':cmd};records.append(record);(r/'processes.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'phase':label,'exitCode':code,'elapsedSeconds':record['elapsedSeconds']}),flush=True)
 if code:raise SystemExit(1)
