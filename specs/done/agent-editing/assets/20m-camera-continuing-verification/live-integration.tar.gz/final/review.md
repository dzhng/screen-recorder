# Focused closeout

Shape: one CameraMedia verification lifetime reuses the existing full-scan states and digest; CameraWriter, ingress and ClosedCameraSource are its actual consumers. No unused continuation API or second picture verifier. The production delta is 525 added/15 removed lines across six capture owners; the test-only SDK observer always forwards the original call and restores its implementation.

Code: resolved raw-first fallback on speculative failure, canonical's own prefix binding, explicit media-to-asset clocks, completed-candidate byte rebinding, mapping-dependent eligibility, and unused stage cleanup. Actual open-tail and >64KiB mapping defects were corrected from saved witnesses. Cancellation checks, receipt/link replay and original generic raw-first publication remain. Source and object bindings in report.json match the final checkout. Digest is unchanged from 837f79df.

Docs: helpers/mac README states checkpoint qualification and lifetime contracts, and explicitly leaves latency unproved. Root owns the spec/handoff/evidence integration.

Verification: the five focused live cases passed through NativeCapture, including pre-stop actual SDK raw/canonical reader starts, same-candidate publication, delayed source start, pre-receipt changed-candidate retry, explicit discard, and terminal malformed-marker cleanup. Existing clock/fractional/pause controls and 32x16/clipped/prefix/raw-error/replay publication controls passed. All seven final processes were waited and exited zero; no timeout. No full suite, real device, model, audio, installed app or retained-take benchmark was run. Sustained backlog and the full ten-second stop gate remain open.
