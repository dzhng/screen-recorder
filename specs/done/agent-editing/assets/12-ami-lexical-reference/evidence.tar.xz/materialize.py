from pathlib import Path
import zipfile, xml.etree.ElementTree as ET, hashlib, json, re, collections, datetime
P=Path('/tmp/screenrec-ami-lexical-reference'); NS='{http://nite.sourceforge.net/}'
URL='https://groups.inf.ed.ac.uk/ami/AMICorpusAnnotations/ami_public_manual_1.6.2.zip'
MEETING='ES2004a'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda path,v:path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
archive=P/'original/ami_public_manual_1.6.2.zip'
assert archive.stat().st_size<=33554432
z=zipfile.ZipFile(archive)
members=[]
def retain(name):
 data=z.read(name); dest=P/'original'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 members.append({'archiveMember':name,'file':str(dest),'bytes':len(data),'sha256':sha(data),'crc32':format(z.getinfo(name).CRC,'08x'),'publisherArchiveURL':URL})
 return data
for name in ['LICENCE.txt','00README_MANUAL.txt','MANIFEST_MANUAL.txt','corpusResources/meetings.xml']:
 retain(name)
meetings=ET.fromstring((P/'original/corpusResources/meetings.xml').read_bytes())
meeting=next(m for m in meetings if m.get('observation')==MEETING)
identities={s.get('nxt_agent'):dict(s.attrib) for s in meeting}
rows=[]
for agent in 'ABCD':
 nodes=list(ET.fromstring(retain(f'words/{MEETING}.{agent}.words.xml')))
 byid={e.get(NS+'id'):i for i,e in enumerate(nodes)}
 segments=ET.fromstring(retain(f'segments/{MEETING}.{agent}.segments.xml'))
 # Retain publisher named entity annotations as context, not word-boundary authority.
 retain(f'namedEntities/{MEETING}.{agent}.ne.xml')
 for seg_index,seg in enumerate(segments):
  selected=[];seen=set();refs=[]
  for child in seg:
   href=child.get('href',''); ids=re.findall(r'id\(([^)]+)\)',href)
   if not ids: continue
   assert href.startswith(f'{MEETING}.{agent}.words.xml#')
   assert len(ids) in (1,2)
   lo,hi=byid[ids[0]],byid[ids[-1]];assert lo<=hi
   refs.append(href)
   for node in nodes[lo:hi+1]:
    assert node.get(NS+'id') not in seen
    seen.add(node.get(NS+'id')); selected.append(node)
  words=[n for n in selected if n.tag=='w' and n.get('punc')!='true']
  if not words: continue
  terms=[(n.text or '').casefold() for n in words] # exact publisher spellings; no scoring or normalization owner here.
  counts={t:terms.count(t) for t in ['um','uh']}
  rows.append({'id':f'{MEETING}.{agent}.segment{seg_index}','agent':agent,'sourceSegmentID':seg.get(NS+'id'),'sourceSegmentIndex':seg_index,'segmentAttributes':dict(seg.attrib),'childReferences':refs,'nodes':selected,'words':words,'terms':terms,'counts':counts,'fillers':sum(counts.values()),'start':float(seg.get('transcriber_start')),'fragments':sum(n.get('trunc')=='true' for n in words),'hasTechnicalTerm':any(t == 'teletext' for t in terms)})
rows.sort(key=lambda r:(r['start'],r['agent'],r['sourceSegmentIndex']))
# Reference-only selection; fixed without any model outputs. Select all complete segments
# with >=2 uh/um, then source-order >=1 segments until >=40. Add 2 earliest zero-uh/um
# segments per speaker and first missing structural/technical example.
chosen=[];reasons={}
def add(row,reason):
 if row['id'] not in reasons:chosen.append(row);reasons[row['id']]=[reason]
 else:reasons[row['id']].append(reason)
for row in rows:
 if row['fillers']>=2:add(row,'complete-source-segment-with-at-least-two-uh-um')
for row in rows:
 if sum(r['fillers'] for r in chosen)>=40:break
 if row['fillers']>=1:add(row,'source-order-filler-top-up-to-at-least-forty')
assert sum(r['fillers'] for r in chosen)>=40
for agent in 'ABCD':
 for row in [r for r in rows if r['agent']==agent and r['fillers']==0][:2]:add(row,'first-two-zero-uh-um-segments-per-speaker')
if not any(r['fragments'] for r in chosen):add(next(r for r in rows if r['fragments']),'first-source-fragment-segment')
if not any(r['hasTechnicalTerm'] for r in chosen):add(next(r for r in rows if r['hasTechnicalTerm']),'first-source-technical-term-segment')
chosen.sort(key=lambda r:(r['start'],r['agent'],r['sourceSegmentIndex']))
clips=[];anchors=[];repeat_pairs=[]
for r in chosen:
 reference=[]
 for i,node in enumerate(r['words']):
  # Deliberately omit all start/end fields. Preserve each original text and occurrence ID.
  attrs={k:v for k,v in node.attrib.items() if k not in ['starttime','endtime',NS+'id']}
  reference.append({'sourceWordID':node.get(NS+'id'),'text':node.text or '',**({'filler':True} if r['terms'][i] in ('um','uh') else {}),'publisherAttributesWithoutTimes':attrs})
 for i in range(1,len(reference)):
  if r['terms'][i]==r['terms'][i-1]:repeat_pairs.append({'clipId':r['id'],'leftSourceWordID':reference[i-1]['sourceWordID'],'rightSourceWordID':reference[i]['sourceWordID'],'text':reference[i]['text'],'scope':'adjacent identical lexical tokens; no unwanted-repetition/intent label'})
 clips.append({'id':r['id'],'kind':'lexical-diagnostic','origin':'human','meeting':MEETING,'speakerAgent':r['agent'],'speakerIdentity':identities[r['agent']],'sourceSegmentID':r['sourceSegmentID'],'selectionReasons':reasons[r['id']],'words':reference,'fillers':r['counts'],'sourceTruncatedWords':r['fragments'],'sourceDisfluencyMarkers':sum(n.tag=='disfmarker' for n in r['nodes']),'sourceNonLexicalNodes':[{'tag':n.tag,'text':n.text,'attributes':{k:v for k,v in n.attrib.items() if k not in ['starttime','endtime']}} for n in r['nodes'] if n.tag!='w' or n.get('punc')=='true'],'technicalTermOccurrences':[{'sourceWordID':n.get(NS+'id'),'text':n.text} for i,n in enumerate(r['words']) if r['terms'][i] in ('teletext','t_v_')]})
 anchors.append({'clipId':r['id'],'publisherSegmentAttributes':r['segmentAttributes'],'childReferences':r['childReferences'],'publisherNodes':[{'tag':n.tag,'text':n.text,'attributes':dict(n.attrib)} for n in r['nodes']],'timingAuthority':'word starttime/endtime automatic forced alignment; transcriber_start/end manually reviewed speech-segment anchors, not every word acoustic edge; locator only, not crop acceptance'})
reference={'corpus':'AMI Meeting Corpus','sourceArchiveURL':URL,'sourceArchiveSHA256':sha(archive.read_bytes()),'annotationPackage':'publisher v1.6.2; embedded README says release1.7 dated2014-06-16; preserve both declarations','license':'CC BY4.0, embedded LICENCE.txt','fillerTerms':['um','uh'],'wordTimingAuthority':'none in this lexical reference','modelTrainingExclusion':'unestablished','sampling':'single meeting; filler enriched; complete source segment token ranges; eight zero-uh/um controls; no model output consulted','clips':clips}
dump(P/'selected/reference.json',reference);dump(P/'selected/publisher-anchors.json',anchors);dump(P/'selected/adjacent-repetitions.json',repeat_pairs)
(P/'selected/transcripts.txt').write_text('\n\n'.join(f"{c['id']} [{c['speakerAgent']}]\n"+' '.join(w['text'] for w in c['words']) for c in clips)+'\n')
summary={'clips':len(clips),'positiveClips':sum(sum(c['fillers'].values())>0 for c in clips),'zeroUhUmClips':sum(sum(c['fillers'].values())==0 for c in clips),'speakers':len(set(c['speakerAgent'] for c in clips)),'referenceWords':sum(len(c['words']) for c in clips),'fillers':{t:sum(c['fillers'][t] for c in clips) for t in ['um','uh']},'fragmentWords':sum(c['sourceTruncatedWords'] for c in clips),'disfluencyMarkers':sum(c['sourceDisfluencyMarkers'] for c in clips),'adjacentIdenticalTokenPairs':len(repeat_pairs),'technicalTermOccurrences':sum(len(c['technicalTermOccurrences']) for c in clips),'scope':'word counts only; zero-uh/um is not absence of all hesitation phenomena','approximateSourceSegmentDurationsSum':sum(float(a['publisherSegmentAttributes']['transcriber_end'])-float(a['publisherSegmentAttributes']['transcriber_start']) for a in anchors),'sourceTimingNotHumanWordEdges':True,'noAudioFetched':True,'noInference':True}
dump(P/'selected/counts.json',summary)
files=[]
for f in sorted(P.rglob('*')):
 if f.is_file() and f.name not in ['manifest.json']:
  b=f.read_bytes();files.append({'file':str(f.relative_to(P)),'bytes':len(b),'sha256':sha(b)})
dump(P/'manifest.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveURL':URL,'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive.read_bytes()),'extractedMembers':members,'files':files})
print(json.dumps(summary,indent=2))
