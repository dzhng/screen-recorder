import { createServer, createConnection, type Socket } from "node:net";
import { once } from "node:events";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { afterEach, expect, test } from "vitest";
import { callLocal } from "@screenrec/client";
import { REQUEST_FRAME_BYTES, type OperationRequest, type OperationResponse } from "@screenrec/protocol";
import { projectServiceFixture } from "./project-service.fixture.js";

const cleanups: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const close of cleanups.splice(0).reverse()) await close();
});
const canvas = { width: 16, height: 16, fps: { numerator: 30, denominator: 1 }, background: "#000000ff" };
async function emptyProject() {
  const f = await projectServiceFixture(cleanups, async (operation) => {
    throw new Error(`Unexpected worker operation: ${operation}`);
  });
  const created = await f.call("project.create", { requestId: "create", canvas });
  expect(created.ok).toBe(true);
  if (!created.ok) throw new Error(created.error.message);
  const { project, revision } = created.data as { project: { projectId: string }; revision: { id: string } };
  const request = {
    id: "resize",
    operation: "edit.apply",
    params: { projectId: project.projectId, requestId: "resize", expectedRevisionId: revision.id,
      operations: [{ operation: "canvas.set", canvas: { ...canvas, width: 32 } }] },
  };
  const db = new DatabaseSync(join(f.home, "library", "catalog.sqlite"));
  cleanups.push(async () => db.close());
  async function state() {
    return {
      project: await f.call("project.get", { projectId: project.projectId }),
      history: await f.call("revision.history", { projectId: project.projectId }),
      requests: db.prepare("SELECT * FROM project_requests WHERE projectId=? ORDER BY createdAt,requestId").all(project.projectId),
    };
  }
  return { ...f, project, revision, request, state };
}
async function sendRaw(socketPath: string, bytes: Buffer) {
  await new Promise<void>((resolve, reject) => {
    const socket = createConnection(socketPath, () => socket.write(bytes));
    const timer = setTimeout(() => { socket.destroy(); reject(new Error("Framing refusal did not close socket")); }, 1000);
    socket.resume();
    socket.on("error", () => socket.destroy());
    socket.once("close", () => { clearTimeout(timer); resolve(); });
  });
}
test("oversized independently valid project mutation does not dispatch", async () => {
  const f = await emptyProject();
  const before = await f.state();
  // Whitespace, rather than an unknown field, keeps the domain request valid.
  await sendRaw(f.service.socketPath, Buffer.from(" ".repeat(REQUEST_FRAME_BYTES) + JSON.stringify(f.request) + "\n"));
  expect(await f.state()).toEqual(before);
  const applied = await callLocal(f.service.socketPath, f.request);
  expect(applied.ok).toBe(true);
  expect(await f.state()).not.toEqual(before);
});
