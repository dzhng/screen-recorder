import { createServer, createConnection, type Socket } from "node:net";
import { once } from "node:events";
import { chmod, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { afterEach, expect, test } from "vitest";
import { callLocal } from "@screenrec/client";
import { REQUEST_FRAME_BYTES, type OperationRequest, type OperationResponse } from "@screenrec/protocol";
import { projectServiceFixture } from "./project-service.fixture.js";

const cleanups: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const close of cleanups.splice(0).reverse()) await close();
});
const canvas = { width: 16, height: 16, fps: { numerator: 30, denominator: 1 }, background: "#000000ff" };
async function emptyProject() {
  const f = await projectServiceFixture(cleanups, async (operation) => {
    throw new Error(`Unexpected worker operation: ${operation}`);
  });
  const created = await f.call("project.create", { requestId: "create", canvas });
  expect(created.ok).toBe(true);
  if (!created.ok) throw new Error(created.error.message);
  const { project, revision } = created.data as { project: { projectId: string }; revision: { id: string } };
  const request = {
    id: "resize",
    operation: "edit.apply",
    params: { projectId: project.projectId, requestId: "resize", expectedRevisionId: revision.id,
      operations: [{ operation: "canvas.set", canvas: { ...canvas, width: 32 } }] },
  };
  const db = new DatabaseSync(join(f.home, "library", "catalog.sqlite"));
  cleanups.push(async () => db.close());
  async function state() {
    return {
      project: await f.call("project.get", { projectId: project.projectId }),
      history: await f.call("revision.history", { projectId: project.projectId }),
      requests: db.prepare("SELECT * FROM project_requests WHERE projectId=? ORDER BY requestId").all(project.projectId),
    };
  }
  return { ...f, project, revision, request, state };
}
async function sendRaw(socketPath: string, bytes: Buffer) {
  await new Promise<void>((resolve, reject) => {
    const socket = createConnection(socketPath, () => socket.write(bytes));
    const timer = setTimeout(() => { socket.destroy(); reject(new Error("Framing refusal did not close socket")); }, 1000);
    socket.resume();
    socket.on("error", () => socket.destroy());
    socket.once("close", () => { clearTimeout(timer); resolve(); });
  });
}
test("oversized independently valid project mutation does not dispatch", async () => {
  const f = await emptyProject();
  const before = await f.state();
  // Whitespace, rather than an unknown field, keeps the domain request valid.
  await sendRaw(f.service.socketPath, Buffer.from(" ".repeat(REQUEST_FRAME_BYTES) + JSON.stringify(f.request) + "\n"));
  expect(await f.state()).toEqual(before);
  const applied = await callLocal(f.service.socketPath, f.request);
  expect(applied.ok).toBe(true);
  expect(await f.state()).not.toEqual(before);
});

test("invalid UTF-8 in an otherwise valid project mutation does not dispatch", async () => {
  const f = await emptyProject();
  const before = await f.state();
  const bytes = Buffer.from(JSON.stringify(f.request) + "\n");
  const marker = bytes.indexOf(Buffer.from('"requestId":"resize"')) + '"requestId":"'.length;
  expect(marker).toBeGreaterThan(0);
  bytes[marker] = 0xff;
  await sendRaw(f.service.socketPath, bytes);
  expect(await f.state()).toEqual(before);
  expect((await callLocal(f.service.socketPath, f.request)).ok).toBe(true);
  expect(await f.state()).not.toEqual(before);
});

test("client TIMEOUT after a real committed reply preserves same-ID replay and history", async () => {
  const f = await emptyProject();
  const sockets = new Set<Socket>();
  const proxy = createServer((socket) => {
    sockets.add(socket);
    socket.on("error", () => socket.destroy());
    socket.on("close", () => sockets.delete(socket));
    let input = "";
    socket.on("data", (bytes) => {
      input += bytes.toString();
      if (!input.endsWith("\n")) return;
      socket.removeAllListeners("data");
      const request = JSON.parse(input) as OperationRequest;
      void callLocal(f.service.socketPath, request).then(
        (response) => committed.resolve({ response, at: performance.now() }),
        committed.reject,
      );
      // Hold the actual backend reply. The client, not the mutation owner, times out.
    });
  });
  cleanups.push(async () => {
    for (const socket of sockets) socket.destroy();
    await new Promise<void>((resolve, reject) => proxy.close((error) => error ? reject(error) : resolve()));
  });
  const path = join(f.home, "timeout.sock");
  proxy.listen(path);
  await once(proxy, "listening");
  const committed = Promise.withResolvers<{ response: OperationResponse; at: number }>();
  const started = performance.now();
  const pending = callLocal(path, f.request, { timeoutMs: 250 }).then(
    () => { throw new Error("Proxy unexpectedly delivered held reply"); },
    (error: unknown) => error,
  );
  const success = await committed.promise;
  expect(success.response.ok).toBe(true);
  expect(success.at - started).toBeLessThan(250);
  expect(await pending).toMatchObject({ code: "TIMEOUT" });
  const after = await f.state();
  expect(await callLocal(f.service.socketPath, f.request)).toEqual(success.response);
  expect(await f.state()).toEqual(after);
  expect(after.history).toMatchObject({ ok: true, data: { revisions: [
    { id: f.revision.id }, { document: { canvas: { width: 32 } } },
  ] } });
  expect(after.requests).toHaveLength(1);
  const stale = await callLocal(f.service.socketPath, { ...f.request,
    params: { ...f.request.params, requestId: "stale-resize" } });
  expect(stale).toMatchObject({ ok: false, error: { code: "STALE_REVISION", details: {
    currentRevisionId: (success.response.ok ? success.response.data as { revision: { id: string } } : null)?.revision.id,
  } } });
});


test("package-root refusal does not revoke unrelated canonical project dispatch", async () => {
  const f = await emptyProject();
  await mkdir(join(f.home, "run", "packages"), { mode: 0o755 });
  await chmod(join(f.home, "run", "packages"), 0o755);
  expect(await f.call("package.open", { path: "/absent.zip" })).toMatchObject({
    ok: false, error: { code: "INVALID_STORAGE" },
  });
  expect(await f.call("package.status", {})).toEqual({ id: "test", ok: true,
    data: { usage: null, admissions: [] } });
  expect(await f.call("project.get", { projectId: f.project.projectId })).toMatchObject({
    ok: true, data: { projectId: f.project.projectId, currentRevisionId: f.revision.id },
  });
  expect((await callLocal(f.service.socketPath, f.request)).ok).toBe(true);
});
