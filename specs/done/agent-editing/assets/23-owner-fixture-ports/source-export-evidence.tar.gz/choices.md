# Source export contract owner

**Sound, high confidence — source admission owns source normalization's type.** Acquisition import and portable source verification need the same native export contract even when the recording-edit processing class is removed. The exact declaration and its needed type-only dependencies now live in existing source-admission. Every caller imports it directly; the old recording processing class also consumes it there. No alias, reexport, runtime owner or public endpoint was added. This ownership choice was authorized explicitly; the existing package source-admission export path remains unchanged.

**Sound, high confidence — prove emitted byte parity instead of replaying media.** The declaration and imports are types only. Five affected emitted JavaScript files were pinned/copied before editing/building, rebuilt and compared in full afterward; all bytes match. Core/service build+typecheck cover both test and production imports. Replaying capture/normalization cannot improve this type-move proof. The seven actual TS paths—not inherited eight count—define scope.

No new uncertain product choice, behavioral requirement, schema/limit/cache/dependency or pipeline was introduced.
