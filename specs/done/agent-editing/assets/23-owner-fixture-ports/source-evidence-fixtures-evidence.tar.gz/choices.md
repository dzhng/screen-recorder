# Decisions

Sound, high confidence: group adjacent source-only fixture ports. The same captured facts back event/scene/trail/visual/transcript evidence; importing RevisionStore made them depend on an editor they never called. CaptureStore supplies their real facts, while every existing value/refusal/deletion/restart/pin/generation assertion stays unchanged. One affected cohort and type/emit proof suffice; no per-spelling fault ceremony.

Sound, high confidence: preserve pure numeric/presentation revision inputs in event/trail neighbors but exclude actual mixed editing fixtures. These passed-in plans test presentation mapping independently of the recording catalog. Transcript-pages, selection-evidence and portable-index actually request/edit stored revisions and need a later explicit owner port; this batch does not silently replace their meaning.

Sound, high confidence: narrow both actual source-only policy/store types and use true type imports. Visual cache already had an erased type import so its JS remains exact. Transcript had an empty runtime library import; deleting it is a named module-load change while its runtime body stays exact. No new dependency, policy, schema, cache, endpoint, limit or low-confidence architecture choice.
