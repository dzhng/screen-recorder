from pathlib import Path
import json,hashlib,struct,subprocess
b=Path(__file__).parent;root=Path('/Users/david/dev/screen-recorder');frozen=root/'specs/agent-editing/assets/06-pointer-writer';inputs=b/'derived';inputs.mkdir(mode=0o700)
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def shape(value,required,optional=()):
 assert isinstance(value,dict);assert set(required)<=value.keys(),('missing',set(required)-value.keys());assert value.keys()<=set(required)|set(optional),('unknown',value.keys()-set(required)-set(optional))
def target(t):shape(t,['kind'],['id']);assert t['kind']in['clip','track','group','output'];assert(t.get('id')is None)==(t['kind']=='output')
def span(s):shape(s,['startUs','endUs']);assert isinstance(s['startUs'],int)and isinstance(s['endUs'],int)and 0<=s['startUs']<s['endUs']<=9007199254740991
changes=[];shapeRows=[]
for name in ['full','range']:
 original=frozen/'input'/(name+'.frames.jsonl');rows=[json.loads(l)for l in original.read_text().splitlines()];derived=[]
 for frame in rows:
  f=json.loads(json.dumps(frame));shape(f,['index','sampleAtUs','visibleRange','layers','visual']);span(f['visibleRange']);assert isinstance(f['index'],int)and isinstance(f['sampleAtUs'],int)
  for layer in f['layers']:
   assert 'kind'not in layer;layer['kind']='video';shape(layer,['clipId','trackId','kind','availability','width','height'],['assetId','streamId','text','sourceUs']);assert layer['assetId']=='5283c719910a007185ec377be5b194fc92b885ad08bf814e7a35f2a604d36327'and layer['streamId']=='track:1'and layer['width']==256 and layer['height']==160 and layer['availability']=='available'and isinstance(layer['sourceUs'],int)
  for node in f['visual']:
   shape(node,['target','inputs','operations']);target(node['target'])
   for t in node['inputs']:target(t)
   for op in node['operations']:shape(op,['kind'],['points','x','y','width','height','matrix','opacity','stepId','trailUs','geometryPrefix'])
  restored=json.loads(json.dumps(f))
  for layer in restored['layers']:layer.pop('kind')
  assert restored==frame
  # Preserve dictionary order too, except the appended explicit type tag.
  for old,new in zip(frame['layers'],f['layers']):assert list(old)==[k for k in new if k!='kind']
  derived.append(f)
 dest=inputs/(name+'.frames.jsonl');dest.write_text(''.join(json.dumps(f,separators=(',',':'))+'\n'for f in derived));assert len(derived)==(20 if name=='full'else 3)
 changes.append({'original':pin(original),'derived':pin(dest),'rows':len(derived),'onlyChange':'Append kind:video to each layer','afterRemovingKindExactlyOriginal':True,'otherDictionaryOrderingPreserved':True})
# Read only this fixed MOV's ISO metadata; no packet read/decoder/newmedia interpretation.
data=(frozen/'input/source.mov').read_bytes()
def boxes(start,end):
 result=[]
 while start<end:
  size,typ=struct.unpack_from('>I4s',data,start);assert size>=8 and start+size<=end;result.append((typ.decode('ascii'),start,start+size));start+=size
 assert start==end;return result
moov=next(x for x in boxes(0,len(data))if x[0]=='moov');tracks=[]
for typ,a,z in boxes(moov[1]+8,moov[2]):
 if typ!='trak':continue
 tr=boxes(a+8,z);tkhd=next(x for x in tr if x[0]=='tkhd');assert data[tkhd[1]+8]==0;trackId=struct.unpack_from('>I',data,tkhd[1]+20)[0];mdia=next(x for x in tr if x[0]=='mdia');md=boxes(mdia[1]+8,mdia[2]);hdlr=next(x for x in md if x[0]=='hdlr');handler=data[hdlr[1]+16:hdlr[1]+20].decode('ascii');minf=next(x for x in md if x[0]=='minf');stbl=next(x for x in boxes(minf[1]+8,minf[2])if x[0]=='stbl');stsd=next(x for x in boxes(stbl[1]+8,stbl[2])if x[0]=='stsd');assert struct.unpack_from('>I',data,stsd[1]+12)[0]==1;entry=stsd[1]+16;codec=data[entry+4:entry+8].decode('ascii');width,height=struct.unpack_from('>HH',data,entry+32);tracks.append({'trackId':trackId,'handler':handler,'sampleEntry':codec,'width':width,'height':height})
assert tracks==[{'trackId':1,'handler':'vide','sampleEntry':'avc1','width':256,'height':160}]
originalReceipt=frozen/'results/baseline-full/receipt.json';receipt=json.loads(originalReceipt.read_text());assert receipt['decodedSamples']==20 and receipt['width']==256 and receipt['height']==160 and receipt['readerOpens']==1
sources=[root/'helpers/mac/Sources/ScreenRecorderFrames/CompositionPictureExecutor.swift',root/'helpers/mac/Sources/ScreenRecorderFrames/CompositionVideoRenderer.swift',root/'helpers/mac/Sources/ScreenRecorderMedia/CompositionProcessing.swift',root/'helpers/mac/Sources/ScreenRecorderFrames/PreparedPointers.swift',root/'helpers/mac/Sources/ScreenRecorderMedia/CompositionAsset.swift',root/'helpers/mac/Sources/ScreenRecorderFrames/OutputSettings.swift',root/'helpers/mac/Sources/ScreenRecorderMedia/TimeSpan.swift']
report={'status':'format-only shape preflight; no media execution','fieldChanges':changes,'sourceVideoAuthority':{'source':pin(frozen/'input/source.mov'),'fixedISOMetadata':tracks,'historicalActualDecodeReceipt':pin(originalReceipt),'decodedSamples':20,'meaning':'Known occupied H264 video track:1 at256x160, historical exact-source actual decoding; no current decoderquality inference'},'currentRequiredShapes':{'VideoRequest':['output','frames','range','canvas','settings','processing','assets'],'optionalVideoRequest':['fonts','pointers'],'Frame':['index','sampleAtUs','visibleRange','layers','visual'],'Layer':['clipId','trackId','kind','availability','width','height'],'optionalLayer':['assetId','streamId','text','sourceUs'],'Node':['target','inputs','operations'],'Operation':['kind'],'optionalOperation':['points','x','y','width','height','matrix','opacity','stepId','trailUs','geometryPrefix']},'sourcePins':[pin(p)for p in sources],'noOtherDefaultsAdded':True}
(b/'format-preflight.json').write_text(json.dumps(report,indent=2));print(json.dumps({'shapePreflight':True,'rows':[x['rows']for x in changes],'metadataTracks':tracks,'nativeCalls':0}))
