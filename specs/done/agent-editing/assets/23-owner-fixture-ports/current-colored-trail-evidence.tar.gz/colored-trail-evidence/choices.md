# Choices

## Current defaults, not a recreated historical encoder — sound, medium confidence
The frozen request named H264/Rec709 but omitted encoder settings. The current operation requires resolved settings, so the pair uses the existing balanced defaults with no overrides. It asks whether the current full and clipped outputs agree under the original mask, not whether their encoded bytes equal the historical writer. Recreating or tuning old omitted defaults would invent authority.

## Video-only owner — sound correction, high confidence
The first current experiment selected movie composition and added silent audio. Its frozen video graph had no audio/output tap, and it refused before encoding. The existing registered video-only primitive is the correct owner; that setup failure remains a separate actual execution, not a product regression.

## Required video tag and strict nil normalization — sound, high confidence
The old frame layers omitted media kind. Private copies add video only, backed by the unchanged source video track; removing that field reproduces the original frames exactly. The existing strict settings schema accounts for Swift omitted nil fields while every actual resolved value must equal the plan. No compatibility path or permissive filter is added to production.

## Reuse exact native sRGB oracle — sound, high confidence
The original failure already used native CG color conversion, so the separate FFmpeg PNG-surrogate finding cannot explain it. Reusing the unchanged pinned native reader and original mask/centroid threshold tests the same paired property; complete RGB differences remain diagnostics rather than a new tolerance.
