#!/usr/bin/env python3
"""One fixed current-production pair; --prepare is metadata-only, --run is separately authorized."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time,sys,shutil
base=Path(__file__).resolve().parent
root=Path('/Users/david/dev/screen-recorder')
frozen=root/'specs/agent-editing/assets/06-pointer-writer'
worker=Path('/Users/david/.cache/screen-recorder/verification/moving-pointer-preview-7f717b0d/screenrec-native')
pixels=Path('/Users/david/.cache/screen-recorder/verification/moving-pointer-preview-7f717b0d/final/output/frame-pixels')
workerSHA='40ece2d269b48a1aed5846e3e0a64bb1ece8f42f1f8e9996b47adbddb265dc55'
sourceSHA='5283c719910a007185ec377be5b194fc92b885ad08bf814e7a35f2a604d36327'
node=Path('/Users/david/.nvm/versions/node/v24.14.0/bin/node')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(name,obj): (base/name).write_text(json.dumps(obj,indent=2))
parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');args=parser.parse_args();assert args.prepare!=args.run
referenceSource=root/'packages/test-harness/editing/FrameColorReference.swift'
pixelSource=root/'packages/test-harness/editing/FrameImagePixels.swift'
assert sha(worker)==workerSHA and sha(frozen/'input/source.mov')==sourceSHA
assert sha(referenceSource)=='cba232f5f49e2c33a1dc8e8f5d4d19f0153a555beb762f9e1bfd77474e4036ba'
assert sha(pixelSource)=='fad481a23d56d34c6557b3dd599c4ccac9b55bd3dc028a935e72f86c6767e302'
protected=[worker,node,pixels,referenceSource,pixelSource,Path(__file__),frozen/'input/source.mov',frozen/'report.json',frozen/'run.mjs',root/'helpers/mac/Sources/ScreenRecorderWire/CompositionMovieOperation.swift',root/'helpers/mac/Sources/ScreenRecorderFrames/CompositionVideoRenderer.swift',root/'helpers/mac/Sources/ScreenRecorderMedia/CompositionProcessing.swift',root/'packages/composition/src/output-settings.ts',root/'packages/composition/src/sample-clock.ts',root/'packages/composition/dist/output-settings.js',root/'packages/composition/dist/sample-clock.js',root/'packages/composition/dist/index.js']
cohorts=[]
for name in ['full','range']:
 oldfile=frozen/'results'/('baseline-'+name)/'request.json';protected.append(oldfile)
 old=json.loads(oldfile.read_text());frames=frozen/'input'/(name+'.frames.jsonl');pointer=frozen/'input'/(name+'.pointers.jsonl');protected.extend([frames,pointer])
 expected=json.loads((frozen/'report.json').read_text())['inputSHA256'];assert sha(frames)==expected[frames.name] and sha(pointer)==expected[pointer.name]
 records=[json.loads(x)for x in frames.read_text().splitlines()];rows=[json.loads(x)for x in pointer.read_text().splitlines()]
 assert len(records)==len(rows)==(20 if name=='full' else 3)
 assert all(row['assetId']==sourceSHA and row['trailUs']==600000 for row in rows)
 assert old['range']==({'startUs':0,'endUs':2000000}if name=='full'else{'startUs':1050001,'endUs':1250001})
 selected=[frame for frame in records if frame['index']in[10,11,12]];assert [f['index']for f in selected]==[10,11,12]
 cohorts.append({'name':name,'old':old,'frames':str(frames),'pointers':str(pointer),'selected':selected,'referenceTimesUs':[f['visibleRange']['startUs']-old['range']['startUs']for f in selected]})
if args.prepare:
 assert not (base/'plan.json').exists(), 'Do not overwrite fixed preparation'
 expression="import {resolveOutputSettings,sampleAt,fromTime} from '"+(root/'packages/composition/dist/index.js').as_uri()+"'; console.log(JSON.stringify({settings:resolveOutputSettings(),sampleRanges:[{startUs:0,endUs:2000000},{startUs:1050001,endUs:1250001}].map(r=>({start:sampleAt(fromTime(r.startUs),48000),end:sampleAt(fromTime(r.endUs),48000)}))}));"
 p=subprocess.Popen([str(node),'--input-type=module','-e',expression],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(timeout=10);(base/'normalizer.stdout').write_bytes(out);(base/'normalizer.stderr').write_bytes(err);save('normalizer-process.json',{'pid':p.pid,'argv':[str(node),'--input-type=module','-e',expression],'exit':p.returncode});assert p.returncode==0
 resolved=json.loads(out);assert resolved['sampleRanges']==[{'start':0,'end':96000},{'start':50400,'end':60000}]
 requests=[]
 for i,c in enumerate(cohorts):
  q=json.loads(json.dumps(c['old']));del q['profile'];q['settings']=resolved['settings'];q['audio']={'range':resolved['sampleRanges'][i],'clips':[]}
  q['frames']=c['frames'];q['pointers']['file']=c['pointers'];q['assets'][0]['path']=str(frozen/'input/source.mov');q['output']=str(base/'run'/c['name']/'movie.mp4')
  assert q['processing']==c['old']['processing'] and q['range']==c['old']['range'] and q['canvas']==c['old']['canvas']
  assert q['settings']['video']['codec']=='h264'and q['settings']['video']['color']=='rec709'and q['settings']['video']['frameReordering']is False
  save(c['name']+'-request.json',{'id':'current-colored-trail-'+c['name'],'operation':'media.renderCompositionMovie','params':q});requests.append({'name':c['name'],'request':q,'matchedFrames':c['selected'],'referenceTimesUs':c['referenceTimesUs']})
 plan={'question':'Current-production full/clipped colored-trail membership under the unchanged original native-sRGB predicate','rootCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'producer':pin(Path(__file__)),'protectedPins':[pin(p)for p in protected],'operation':'media.renderCompositionMovie','requestChanges':['removed old profile field','explicit existing resolveOutputSettings() defaults, no overrides','required compiled48k audio sampleAt schedule, clips[]','owned output and immutable existing input paths relocated'],'defaultSettings':resolved['settings'],'equivalence':{'preserved':'H264/Rec709/no-frame-reordering; all source/compiled visual/processing/pointer bytes and clocks','notClaimed':'Exact oldAVFoundation defaults or encoded-byte equality. Old omitted bitrate/profile/level/keyframe controls; current balanced supplies8M/high/auto/120+2s/etc. AAC silence/currentmux are additional current-operation qualification.'},'cohorts':requests,'oracle':{'referenceSource':pin(referenceSource),'referenceBinary':'Compile only this unchanged source in ownedrun namespace,30s compile bound charged to90s producer','pixelSource':pin(pixelSource),'pixelBinary':pin(pixels),'sourceMatchesFrozen55a':True,'pipeline':'exact-time AVAssetImageGenerator→CoreGraphics sRGB PNG→unchanged FrameImagePixels sRGB RGBA','mask':'R>G+20 && B>G+10','acceptance':'each full/range centroid x/y delta abs<1px; count>20; original strict comparator unchanged'},'bounds':{'totalSeconds':90,'nativeCalls':2,'referenceFrames':6,'pixelReads':6,'sourceBytes':2057,'pictureSize':[256,160],'matchedIndices':[10,11,12],'stop':'first process/request/clock/pixel/centroid failure; no retry/tuning/settings sweep'}}
 save('plan.json',plan);print(json.dumps({'prepared':True,'path':str(base/'plan.json'),'nativeCalls':0}));sys.exit(0)
# Explicit --run only after parent reviews this frozen producer/plan.
plan=json.loads((base/'plan.json').read_text());assert pin(Path(__file__))==plan['producer'];assert [pin(Path(p['path']))for p in plan['protectedPins']]==plan['protectedPins']
runDir=base/'run';runDir.mkdir(mode=0o700);start=time.monotonic();deadline=start+90;report={'passed':False,'startUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':[],'before':plan['protectedPins'],'cohorts':[]}
def command(label,argv,input=None,limit=30):
 remaining=deadline-time.monotonic();assert remaining>0,'90s deadline';outpath=runDir/(label+'.stdout');errpath=runDir/(label+'.stderr');record={'label':label,'argv':argv,'startMonotonic':time.monotonic(),'timeoutSeconds':min(limit,remaining)};report['commands'].append(record)
 with outpath.open('wb')as stdout,errpath.open('wb')as stderr:
  p=subprocess.Popen(argv,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=stdout,stderr=stderr);record['pid']=p.pid;save('result.json',report)
  try:p.communicate(input=input,timeout=min(limit,remaining))
  except subprocess.TimeoutExpired:p.kill();p.communicate();record['deadline']=True
  record['exit']=p.returncode;record['endMonotonic']=time.monotonic();save('result.json',report)
 assert not record.get('deadline'),label+' deadline';assert p.returncode==0,label+' process failure';return outpath.read_bytes()
def mask(raw):
 points=[(x,y)for y in range(160)for x in range(256)if raw[(y*256+x)*4]>raw[(y*256+x)*4+1]+20 and raw[(y*256+x)*4+2]>raw[(y*256+x)*4+1]+10]
 return {'count':len(points),'centroid':[sum(p[0]for p in points)/len(points),sum(p[1]for p in points)/len(points)]}if points else {'count':0,'centroid':None}
try:
 command('swift-version',['/usr/bin/xcrun','swiftc','--version'],limit=5)
 reference=runDir/'frame-reference';command('reference-compile',['/usr/bin/xcrun','swiftc','-parse-as-library',str(referenceSource),'-o',str(reference)],limit=30);report['referenceBinary']=pin(reference);save('result.json',report)
 for c in plan['cohorts']:
  directory=runDir/c['name'];directory.mkdir(mode=0o700);request=json.loads((base/(c['name']+'-request.json')).read_text());assert request['params']==c['request'];reply=json.loads(command(c['name']+'-native',[str(worker)],input=(json.dumps(request)+'\n').encode()));save(c['name']+'-reply.json',reply);assert reply['ok'],json.dumps(reply)
  data=reply['data'];assert data['frameCount']==(20 if c['name']=='full'else3)and data['durationUs']==c['request']['range']['endUs']-c['request']['range']['startUs'];assert data['settings']==plan['defaultSettings']
  images=directory/'decoded';images.mkdir();ref={'movie':data['file'],'output':str(images),'timesUs':c['referenceTimesUs']};refFile=directory/'reference.json';refFile.write_text(json.dumps(ref));selected=json.loads(command(c['name']+'-reference',[str(reference),str(refFile)]));save(c['name']+'-reference-reply.json',selected)
  outcomes=[]
  for i,item in enumerate(selected):
   raw=Path(item['file']+'.rgba');receipt=json.loads(command(c['name']+'-pixels-'+str(i),[str(pixels),item['file'],str(raw)]));outcomes.append({'frameIndex':10+i,'reference':item,'pixelReceipt':receipt,'png':pin(Path(item['file'])),'rgba':pin(raw),'mask':mask(raw.read_bytes())})
  report['cohorts'].append({'name':c['name'],'request':request,'reply':reply,'movie':pin(Path(data['file'])),'samples':outcomes});save('result.json',report)
  assert len(outcomes)==3
  for i,sample in enumerate(outcomes):
   assert sample['reference']['requestedUs']==c['referenceTimesUs'][i]and int(sample['reference']['actualValue'])*1000000==c['referenceTimesUs'][i]*sample['reference']['actualTimescale']
   assert sample['pixelReceipt']['width']==256 and sample['pixelReceipt']['height']==160 and sample['rgba']['bytes']==256*160*4
   assert sample['mask']['count']>20,'Encoded movie lost pointer trail'
 report['comparisons']=[]
 for a,b in zip(report['cohorts'][0]['samples'],report['cohorts'][1]['samples']):
  assert a['frameIndex']==b['frameIndex'];delta=[b['mask']['centroid'][i]-a['mask']['centroid'][i]for i in range(2)];report['comparisons'].append({'frameIndex':a['frameIndex'],'full':a['mask'],'range':b['mask'],'centroidDelta':delta})
 save('result.json',report)
 assert all(abs(d)<1 for pair in report['comparisons']for d in pair['centroidDelta']),'Original strict colored-trail centroid criterion failed'
 report['passed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:
 report['elapsedSeconds']=time.monotonic()-start;report['after']=[pin(Path(p['path']))for p in plan['protectedPins']];report['protectedEqual']=report['after']==report['before'];save('result.json',report)
