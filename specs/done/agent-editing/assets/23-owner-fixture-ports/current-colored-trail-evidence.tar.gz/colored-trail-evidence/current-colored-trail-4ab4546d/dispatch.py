from pathlib import Path
import subprocess,time,json,os,signal,hashlib
b=Path(__file__).parent;argv=['/opt/homebrew/bin/python3',str(b/'producer.py'),'--run'];record={'argv':argv,'startUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'producerSHA':hashlib.sha256((b/'producer.py').read_bytes()).hexdigest(),'outerBoundSeconds':96};start=time.monotonic()
with (b/'producer.stdout').open('wb')as stdout,(b/'producer.stderr').open('wb')as stderr:
 p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True);record['pid']=p.pid;(b/'producer-process.json').write_text(json.dumps(record,indent=2));print(json.dumps({'pid':p.pid,'record':str(b/'producer-process.json')}),flush=True)
 try:record['exit']=p.wait(timeout=96)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);record['exit']=p.wait();record['outerDeadline']=True
record['elapsedSeconds']=time.monotonic()-start;record['endUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(b/'producer-process.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
