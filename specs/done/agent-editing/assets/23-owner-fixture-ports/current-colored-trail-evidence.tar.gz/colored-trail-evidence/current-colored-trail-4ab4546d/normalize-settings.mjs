import { readFile } from "node:fs/promises";
import { resolvedOutputSettingsSchema } from "/Users/david/dev/screen-recorder/packages/composition/dist/index.js";
const reply = JSON.parse(await readFile(process.argv[2], "utf8"));
process.stdout.write(JSON.stringify(resolvedOutputSettingsSchema.parse(reply.data.settings)));
