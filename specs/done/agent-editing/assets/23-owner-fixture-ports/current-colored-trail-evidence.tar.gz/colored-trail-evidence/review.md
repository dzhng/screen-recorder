# Review

Shape: one evidence archive and one registry wrapper, no production verifier, adapter or copied worker. Frozen inputs and original failures are immutable; derived layers add the required media-kind tag only.

Diff: current video-only owner, receipt `frames`, strict settings schema and complete required Codable shapes were inspected before the one approved format successor. Both setup refusals preserve actual request, reply and zero child exit independently of producer exit1. Green records twelve zero child exits and thirty equal before/after pins. Pixel/profile receipts, every selected clock and signed centroid remain available.

Docs: current paired acceptance is separated from historical encoder defaults and wider presentation. Fresh critique inspects all six frames and crops; no claim of exact full-image equality or installed acceptance. Root independently rehashed thirty protected inputs. Local links and every archive payload are verified at closeout.
