from pathlib import Path
import hashlib,json,re
root=Path('/Users/david/dev/screen-recorder');bank=Path(__file__).parent
paths=['apps/service/src/capture-finalizing.test.ts','apps/service/src/delivery.test.ts','packages/core/src/recording-deletion.test.ts','packages/core/src/storage.test.ts','packages/core/src/storage.ts']
tests=[]
for path in paths[:-1]:
 before=(bank/'before'/path).read_text();after=(root/path).read_text()
 # Review aid, not a claim to parse complete JavaScript assertions.
 lines=lambda s:[line.strip() for line in s.splitlines() if re.search(r'\bexpect\b|\.to[A-Z]',line)]
 old,new=lines(before),lines(after);assert old==new,path
 tests.append({'path':path,'expectationBearingLines':len(old),'linesExact':True,'allAssertionsUnchanged':'confirmed by complete diff review'})
before=(bank/'before/packages/core/dist/storage.js').read_text();after=(root/'packages/core/dist/storage.js').read_text()
removed=['import {} from "./library.js";\n','import {} from "./capture-store.js";\n'];expected=before
for line in removed:
 assert line in expected;expected=expected.replace(line,'')
assert expected==after
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=[]
for path in paths+['packages/core/dist/storage.js']:
 data=(root/path).read_bytes();dest=bank/'final'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);pins.append({'path':path,'bytes':len(data),'sha256':sha(data)})
(bank/'parity.json').write_text(json.dumps({'tests':tests,'storage':{'beforeSha256':sha(before.encode()),'afterSha256':sha(after.encode()),'removedImports':removed,'remainingBodyExact':True},'finalPins':pins},indent=2)+'\n')
print(json.dumps({'expectationLinesEqual':True,'storageRemainingBodyExact':True,'finalPins':len(pins)}))
