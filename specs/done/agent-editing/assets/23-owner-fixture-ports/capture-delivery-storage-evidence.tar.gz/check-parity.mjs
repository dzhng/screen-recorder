import ts from '/Users/david/dev/screen-recorder/node_modules/typescript/lib/typescript.js';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/Users/david/dev/screen-recorder';
const bank=new URL('./',import.meta.url);
const paths=['apps/service/src/capture-finalizing.test.ts','apps/service/src/delivery.test.ts','packages/core/src/recording-deletion.test.ts','packages/core/src/storage.test.ts'];
function facts(text){
 const sf=ts.createSourceFile('fixture.ts',text,ts.ScriptTarget.Latest,true); const assertions=[],titles=[];
 function walk(n){
  if(ts.isCallExpression(n)){
   const expr=n.expression.getText(sf);
   if(/^expect(?:\b|\.)/.test(expr)) assertions.push(n.getText(sf).replace(/\s+/g,' '));
   if(expr==='test'||expr.startsWith('test.each'))titles.push(n.arguments[0]?.getText(sf));
  }
  ts.forEachChild(n,walk);
 }
 walk(sf);return {assertions,titles};
}
const tests=[];
for(const path of paths){const before=facts(await readFile(new URL('before/'+path,bank),'utf8'));const after=facts(await readFile(root+'/'+path,'utf8')); const equal=JSON.stringify(before)===JSON.stringify(after); tests.push({path,assertions:before.assertions.length,titles:before.titles.length,equal});if(!equal)throw Error('Fixture assertions changed: '+path);}
const before=await readFile(new URL('before/packages/core/dist/storage.js',bank),'utf8'); const after=await readFile(root+'/packages/core/dist/storage.js','utf8');
const removed=['import {} from "./library.js";\n','import {} from "./capture-store.js";\n'];
let expected=before;for(const line of removed){if(!expected.includes(line))throw Error('Missing old empty import');expected=expected.replace(line,'');}
if(expected!==after)throw Error('Storage runtime body changed');
const sha=s=>createHash('sha256').update(s).digest('hex');
await writeFile(new URL('parity.json',bank),JSON.stringify({tests,storage:{beforeSha256:sha(before),afterSha256:sha(after),removedImports:removed,remainingBodyExact:true}},null,2)+'\n');
console.log(JSON.stringify({tests,storageRemainingBodyExact:true}));
