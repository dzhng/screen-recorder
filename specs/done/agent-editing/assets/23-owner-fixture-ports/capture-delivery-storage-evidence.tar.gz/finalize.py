from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/Users/david/dev/screen-recorder');bank=Path(__file__).parent
j=lambda p:json.loads((bank/p).read_text())
parity=j('parity.json');phases=['affected-files','recovery-attribution','recovery-corrected','core-build','core-types','lint','format','final-affected','service-types','final-lint','final-format']
checks=[]
for name in phases:
 process=j(name+'/process.json');terminal=j(name+'/terminal.json');assert process['pid']==terminal['pid'] and terminal['waited'] and not terminal['deadlineExpired'];checks.append({'phase':name,'process':process,'terminal':terminal})
for name in ['final-affected','service-types','final-lint','final-format']:
 record=j(name+'/process.json');assert record['sources']==parity['finalPins'][:-1]
for p in ['apps/service/src/capture.ts','packages/core/src/capture-store.ts']:
 data=(root/p).read_bytes();assert data==subprocess.check_output(['git','show','ee597d0e:'+p],cwd=root)
 target=bank/'unchanged-owners'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
report={'base':'ee597d0e','scope':'Five fact-only CaptureStore fixture/ManagedStorage type ports; recovery success fixtures repaired to current closure/publication envelope','finalAffectedCases':43,'initialAffected':{'passed':37,'failed':6,'failure':'Current recovery success fixtures omitted closure/publication authority'},'attribution':'Saved public state from PID85898 confirms Source recovery omitted closure authority; no CaptureStore fault or historical baseline execution claim','assertions':'All original assertions and test rows unchanged, complete diff reviewed; expectation-bearing line comparison is a review aid only','runtime':'ManagedStorage body exact except removal of empty library/capture-store imports; only constructor type changed','limits':['Scripted journal/video bytes; no native media validity or capture proof','No native/media/model/full suite','Original failure and throwaway attribution source retained','Optional TypeScript-AST review helper failed before parsing: installed TypeScript7 package lacks lib/typescript.js; no install/retry, complete diff reviewed instead','Previously banked local Codex review environment failure not retried; self/root review used'], 'checks':checks,'parity':parity}
(bank/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(bank/'review.md').write_text('''The five-file scope is coherent: capture/deletion/storage fixtures use the source owner, and ManagedStorage requires only its current get/deleting facts. No project/edit compatibility helper or new runtime owner was introduced. All original lifecycle ordering, retry, cancellation, delivery, held-reader, deletion, transaction and storage accounting assertions remain. Full diff and names reviewed; no old RevisionStore imports remain in these paths.

Six old recovery-success fixtures lacked the current media.recover closure/publication fields. Saved public state identifies the exact refusal. The local helper follows the existing capture-lifetime/project-capture scripted-byte pattern and supplies real byte counts/hashes for its controlled files. It makes no native validity claim. The original missing-authority red and public-state diagnostic remain separate from corrected green; no historical RevisionStore baseline run is claimed.

Final four-file cohort:43/43. Core build/types, service types, scoped lint/format pass. Emitted storage body differs only by two removed empty imports. No build/API/schema/budget changes. Root owns global documentation; this private report is the integration authority. Local Codex review was not retried after the already banked configured-model environment limitation. Self-review is clean; parent independently reviews before integration.
''')
(bank/'choices.md').write_text('''Sound, medium confidence — Author a local scripted publication fixture rather than weaken recovery authority. When a held recovery completes, the service now requires proof that inputs closed and a published/unavailable outcome; old positive stubs supplied only duration. The helper writes small scripted journal/video bytes and reports their actual hashes, following existing lifecycle fixtures. It preserves every outcome/retry/cleanup oracle without claiming those bytes are decodable media. The plan did not specify the fixture envelope repair; this is the least-confident choice because the test boundary is service lifecycle, not physical publication. A reusable helper across files was not created: that would widen a local repair into a new fixture owner without need.

Sound, high confidence — Use CaptureStore directly and narrow ManagedStorage's constructor type. Storage needs only source facts and deletion state; retaining RevisionStore loads an obsolete editing owner. Runtime storage computation remains exact apart from erased-import cleanup. No hidden currentRevisionId field filtering, compatibility adapter or project creation is added. Pure spelling/type ports reuse unchanged assertions rather than new artificial faults; the actual missing-authority red proves the repaired success-envelope path.

No new public schema, setting, cache, endpoint, resource limit or dependency; no uncertain product choice or user-only decision remains. Mixed round-trip/job-target/index-domain consumers stay mapped outside this pass.
''')
(bank/'source.diff').write_bytes(subprocess.check_output(['git','diff','--']+[p['path'] for p in parity['finalPins'][:-1]],cwd=root))
# Payload selection freezes one self-contained private bank. Full original logs/sources stay included.
exclude={'evidence.tar.gz','manifest.json'}
files=sorted(p for p in bank.rglob('*') if p.is_file() and p.name not in exclude)
entries=[{'path':str(p.relative_to(bank)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with tarfile.open(bank/'evidence.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(bank)),recursive=False)
blob=(bank/'evidence.tar.gz').read_bytes();manifest={'members':entries,'archive':{'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}}
(bank/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'archive':manifest['archive'],'report':str(bank/'report.json')}))
