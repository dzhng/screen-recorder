from pathlib import Path
import subprocess,sys,os,json,time,hashlib
b=Path(__file__).parent;wt=Path('/Users/david/.codex/worktrees/source-native-consumers/screen-recorder');phase=sys.argv[1];d=b/phase;d.mkdir(exist_ok=False)
reference=json.loads((b/'native-pin-reference.json').read_text());pins=json.loads(Path(reference['path']).read_text())
for row in pins['files']:assert hashlib.sha256((wt/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert hashlib.sha256(Path(pins['binary']).read_bytes()).hexdigest()==pins['binarySHA256']
args=['node','--require',str(b/'observe.cjs'),'--test','--test-concurrency=1','--test-name-pattern=an owner that dies mid-operation','helpers/mac/Tests/lifetime.test.mjs'];env={**os.environ,'SCREENREC_NATIVE':pins['binary'],'PROOF_BANK':str(b),'PROOF_PHASE':phase}
start=time.time();p=subprocess.Popen(args,cwd=wt,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'process.json').write_text(json.dumps({'argv':args,'pid':p.pid,'start':start,'sourceSHA256':hashlib.sha256((wt/'helpers/mac/Tests/lifetime.test.mjs').read_bytes()).hexdigest(),'binarySHA256':pins['binarySHA256']},indent=2)+'\n')
try:out,_=p.communicate(timeout=45)
except subprocess.TimeoutExpired:p.kill();out,_=p.communicate();raise
finally:
 if p.returncode is not None:(d/'terminal.json').write_text(json.dumps({'exit':p.returncode,'seconds':time.time()-start,'waited':True},indent=2)+'\n')
(d/'terminal.log').write_bytes(out);print(out.decode(),end='');sys.exit(p.returncode)
