import { writeFile } from "node:fs/promises";
import { JourneyService } from "/Users/david/.codex/worktrees/continuous-preview/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs";
const call = JourneyService.prototype.call;
const captured = new Set();
JourneyService.prototype.call = async function (operation, params, options) {
  const key = operation === "edit.apply"
    ? params.requestId === "preview-layout" ? "preview-layout" : "setup"
    : operation === "timeline.events" && params.range?.endUs === 7199000000 ? "query" : null;
  if (!key || captured.has(key) || this.report.exchanges)
    return call.call(this, operation, params, options);
  const prior = this.report.exchanges;
  this.report.exchanges = [];
  const started = performance.now();
  try {
    return await call.call(this, operation, params, options);
  } finally {
    const exchanges = this.report.exchanges;
    this.report.exchanges = prior;
    if (exchanges.some((exchange) => exchange.response?.structuredContent?.resultDelivery)) {
      captured.add(key);
      const path = new URL(`captures/${key}.json`, import.meta.url);
      await writeFile(path, JSON.stringify({ scope: "First delivered reply only; cold/setup observer included, warm repetitions unobserved", elapsedWithCaptureMs: performance.now() - started, exchanges }, null, 2));
      console.log(`CAPTURED first ${key} complete-result exchange`);
    }
  }
};
