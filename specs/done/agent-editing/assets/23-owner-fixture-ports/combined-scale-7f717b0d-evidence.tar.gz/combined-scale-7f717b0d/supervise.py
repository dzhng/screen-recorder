from pathlib import Path
import os,sys,json,time,subprocess,signal,hashlib,shutil
bank=Path(__file__).parent; root=Path('/Users/david/dev/screen-recorder'); plan=json.loads((bank/'plan.json').read_text()); out=bank/'output';out.mkdir()
node=shutil.which('node'); argv=[node,'packages/test-harness/editing/scale.mjs','--case','long-project','--out',str(out)]
env=os.environ.copy();env['SCREENREC_NATIVE']=plan['worker'];start=time.monotonic();wall=time.time();log=open(bank/'producer.log','wb');p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(bank/'process.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'pid':p.pid,'pgid':p.pid,'started':wall,'SCREENREC_NATIVE':env['SCREENREC_NATIVE']},indent=2));print('producer PID',p.pid,flush=True)
progress=open(bank/'progress.jsonl','w');timedout=False
while p.poll() is None:
 elapsed=time.monotonic()-start
 rows=subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,etime=,rss=,command='],text=True).splitlines();parsed=[]
 for row in rows:
  f=row.strip().split(None,5)
  if len(f)==6:parsed.append({'pid':int(f[0]),'ppid':int(f[1]),'pgid':int(f[2]),'elapsed':f[3],'rssKiB':int(f[4]),'command':f[5]})
 owned={p.pid}
 for _ in range(5):owned.update(x['pid'] for x in parsed if x['ppid'] in owned)
 snapshot={'elapsedSeconds':elapsed,'processes':[x for x in parsed if x['pid'] in owned],'files':[{'name':str(x.relative_to(out)),'bytes':x.stat().st_size} for x in out.rglob('*') if x.is_file()]}
 progress.write(json.dumps(snapshot)+'\n');progress.flush();(bank/'progress.json').write_text(json.dumps(snapshot,indent=2))
 if elapsed>=180:
  timedout=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
  break
 if int(elapsed)%15==0:print('elapsed',round(elapsed,1),'files',len(snapshot['files']),'processes',len(snapshot['processes']),flush=True)
 time.sleep(1)
code=p.wait();log.close();progress.close();terminal={'exitCode':code,'timedOut':timedout,'seconds':time.monotonic()-start,'ended':time.time()};(bank/'terminal.json').write_text(json.dumps(terminal,indent=2));print(json.dumps(terminal),flush=True)
pins=json.loads((bank/'before-pins.json').read_text());changed=[]
for pin in pins:
 path=Path(pin['path']);sha=hashlib.sha256(path.read_bytes()).hexdigest()
 if sha!=pin['sha256']:changed.append({'path':str(path),'before':pin['sha256'],'after':sha})
(bank/'after-pins.json').write_text(json.dumps({'count':len(pins),'changed':changed},indent=2));print('changed pins',len(changed),flush=True)
report=out/'report.json'
if report.exists():
 result=json.loads(report.read_text());home=Path(result['home'])
 if home.is_dir():
  shutil.copytree(home,bank/'retained-home',ignore=shutil.ignore_patterns('*.sock'))
  (bank/'retained-home-source.json').write_text(json.dumps({'path':str(home),'scope':'Post-terminal complete scratch library; sockets excluded'},indent=2));shutil.rmtree(home)
 print('report error',result.get('error'),'passed',result['passed'],flush=True)
sys.exit(0)
