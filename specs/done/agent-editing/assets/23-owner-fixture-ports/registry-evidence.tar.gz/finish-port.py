from pathlib import Path
p=Path('apps/service/tests/package-registry.mjs');s=p.read_text();start=s.index('test("same-provenance');end=s.index('\ntest("startup remains',start)
s=s[:start]+'''test("same-provenance project deletion and package close revoke only their own delivery namespaces", async (t) => {
  const [
    { DerivedCache }, { AcquisitionStore }, { SceneEvidenceStore, assetSceneOwner },
    { ScreenshotIndexStore }, { projectIndexDomain }, { projectComposition }, { selectSource },
    { ProjectDeletion }, { ManagedFiles },
  ] = await Promise.all([
    import("../../../packages/core/dist/cache.js"), import("../../../packages/core/dist/acquisitions.js"),
    import("../../../packages/core/dist/scene-evidence.js"), import("../../../packages/core/dist/screenshot-index.js"),
    import("../../../packages/core/dist/project-index.js"), import("../../../packages/core/dist/project-window.js"),
    import("../../../packages/core/dist/source-selection.js"), import("../dist/project-deletion.js"), import("../dist/managed-files.js"),
  ]);
  const f = await fixture(t), projectId = f.snapshot.project.projectId;
  const acquisitions = new AcquisitionStore(f.store);
  const scenes = new SceneEvidenceStore(f.store, assetSceneOwner(f.assets, acquisitions));
  const index = new ScreenshotIndexStore(f.store, f.home, projectIndexDomain({
    composition: (identity) => projectComposition(f.projects, f.assets, identity),
    source: (selection) => selectSource(f.assets, acquisitions, selection), scenes,
    isDeleting: (id) => f.projects.isDeleting(id),
  }, { implementationId: "registry-deletion" }));
  const cache = new DerivedCache(f.store, f.home, (owner) => {
    assert.equal(owner.kind, "project"); f.projects.get(owner.projectId);
  });
  await cache.reconcile();
  // No exports exist; export retirement is the external edge, not a simulated project deletion.
  const deletion = new ProjectDeletion(f.projects, f.jobs, cache, new ManagedFiles(f.home, worker),
    f.delivery, { retireOwner: async () => {} }, index);
  try {
    await f.registry.recover();
    const a = await f.registry.open(f.input), b = await f.registry.open(f.input);
    const first = await ready(f, a.id), second = await ready(f, b.id);
    const lease = (handle) => {
      const file = f.registry.lookup(handle).files.open(f.mediaPath);
      return { bytes: fstatSync(file.fd).size,
        read: (buffer, position) => readSync(file.fd, buffer, 0, buffer.length, position),
        release: () => file.close() };
    };
    const target = f.delivery.open({ kind: "package", id: first }, () => lease(first));
    const sibling = f.delivery.open({ kind: "package", id: second }, () => lease(second));
    const library = f.delivery.open({ kind: "project", id: projectId }, () => lease(first));
    assert.deepEqual(f.registry.lookup(first).manifest.snapshot, f.snapshot);
    await deletion.delete(projectId);
    assert.throws(() => f.projects.get(projectId), { code: "NOT_FOUND" });
    assert.deepEqual(f.assets.get(f.asset.id), f.asset);
    assert.throws(() => f.delivery.read(library.token, 0, 20), { code: "ARTIFACT_EXPIRED" });
    assert.equal(Buffer.from(f.delivery.read(target.token, 0, 20).data, "base64").toString(), "generated source");
    await f.registry.close(a.id);
    assert.throws(() => f.delivery.read(target.token, 0, 20), { code: "ARTIFACT_EXPIRED" });
    assert.equal(Buffer.from(f.delivery.read(sibling.token, 0, 20).data, "base64").toString(), "generated source");
    assert.deepEqual(f.registry.lookup(second).manifest.snapshot, f.snapshot);
  } finally { await deletion.close(); }
});
''' +s[end:]
start=s.index('test("correctly hashed');end=s.index('\ntest("default peak',start)
s=s[:start]+'''test("correctly hashed malformed project resource metadata fails before readiness and releases its owner", async (t) => {
  const f = await fixture(t);
  const manifest = JSON.parse(f.files["manifest.json"]);
  const reference = manifest.resources[0].metadata;
  const resource = JSON.parse(f.files[reference.path]);
  resource.asset.streams[0].width = "invalid";
  const body = JSON.stringify(resource);
  f.files[reference.path] = body;
  reference.bytes = Buffer.byteLength(body);
  reference.sha256 = createHash("sha256").update(body).digest("hex");
  Object.assign(manifest.inventory.find((member) => member.path === reference.path), reference);
  f.files["manifest.json"] = JSON.stringify(manifest);
  // Structural admission and exact hashes succeed; the canonical typed resource owner refuses.
  assert.equal(parseProjectPackageManifest(f.files["manifest.json"], new Map(), archiveLimits).format, "screenrec-project");
  await f.writeArchive();
  await f.registry.recover();
  const admission = await f.registry.open(f.input);
  const result = await waitFor(() => f.registry.status(admission.id), (value) => value.state === "failed");
  assert.equal(result.packageHandle, null);
  assert.equal(result.error.code, "INVALID_PACKAGE");
  assert.equal(result.error.message, "Invalid portable resource metadata identity or schema");
  await waitFor(() => f.registry.usage(), (value) => value.owners === 0);
  assert.equal(f.registry.usage().budgetBytes, 0);
  assert.deepEqual(await readdir(f.directory), []);
  assert.deepEqual(f.projects.snapshot(f.snapshot.project.projectId), f.snapshot);
});
''' +s[end:]
s=s.replace('target: { kind: "recording", recordingId: recording.recordingId },','target: { kind: "recording", recordingId: recording.recordingId, revisionId: null },')
s=s.replace('manifest.inventory.find((item) => item.role === "video")','manifest.inventory.find((item) => item.path === f.mediaPath)')
# actual catalog state, not old revision-store table shape
s=s.replace('assert.equal(f.store.catalog.prepare("SELECT COUNT(*) AS n FROM recordings").get().n, 0);','''assert.equal(f.store.catalog.prepare("SELECT COUNT(*) AS n FROM recordings").get().n, 0);
  assert.deepEqual(context.manifest.snapshot, f.snapshot);
  assert.deepEqual(f.projects.snapshot(f.snapshot.project.projectId), f.snapshot);
  assert.deepEqual(f.assets.get(f.asset.id), f.asset);''')
s=s.replace('closes without library rows','closes without changing authored library state')
p.write_text(s)
