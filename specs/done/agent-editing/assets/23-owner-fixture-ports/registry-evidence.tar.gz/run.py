import subprocess, pathlib, json, time, hashlib, os, sys
root=pathlib.Path('/Users/david/dev/screen-recorder'); out=pathlib.Path('/tmp/screenrec-package-registry-port')/sys.argv[1];out.mkdir()
argv=sys.argv[2:]; start=time.time(); env=os.environ.copy();env['SCREENREC_NATIVE']=str(root/'helpers/mac/.build/debug/screenrec-native')
pins={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'apps/service/tests/package-registry.mjs',root/'apps/service/dist/package-registry.js',root/'apps/service/dist/package-archive.js',root/'helpers/mac/.build/debug/screenrec-native']}
for name in pins:
 src=root/name; dest=out/"executed"/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if src.suffix in [".mjs",".js"]: dest.write_bytes(src.read_bytes())
with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=so,stderr=se); (out/'process.json').write_text(json.dumps({'argv':argv,'pid':p.pid,'start':start,'pins':pins},indent=2));
 try: code=p.wait(timeout=120)
 except subprocess.TimeoutExpired: p.kill();code=p.wait()
(out/'terminal.json').write_text(json.dumps({'pid':p.pid,'exit':code,'waited':True,'end':time.time()},indent=2));print(json.dumps({'path':str(out),'pid':p.pid,'exit':code}));sys.exit(code)
