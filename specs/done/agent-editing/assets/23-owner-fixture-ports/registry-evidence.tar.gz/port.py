from pathlib import Path
p=Path('apps/service/tests/package-registry.mjs');s=p.read_text();s=s.replace('import { validatePackageTranscript } from "../dist/package-transcript.js";\n','').replace('import { validateManifest } from "@screenrec/core/package-manifest";\n','');s=s.replace('import { RevisionStore } from "../../../packages/core/dist/library.js";','''import { CaptureStore } from "../../../packages/core/dist/capture-store.js";
import { AssetStore } from "../../../packages/core/dist/assets.js";
import { ProjectStore } from "../../../packages/core/dist/projects.js";
import { TranscriptStore } from "../../../packages/core/dist/transcript.js";
import { assetTranscriptOwner } from "../../../packages/core/dist/transcript-processing.js";
import { parseProjectPackageManifest, projectPackageManifest, resourceMetadataMember } from "../../../packages/core/dist/project-package.js";
import { resolveProjectPackageMetadata } from "../dist/project-package-metadata.js";''');s=s.replace('import { JobQueue, recordingJobTargets }','import { JobQueue }');s=s.replace('import { archiveContents } from "../../macos/tests/fixtures/archive-contents.mjs";\n','');s=s.replace('new RevisionStore','new CaptureStore');s=s.replace('    targets: recordingJobTargets(store),','''    targets: {
      pin(target) {
        assert.equal(target.kind, "recording");
        assert.equal(target.revisionId, null);
        assert.equal(store.isAvailable(target.recordingId), true);
        return target;
      },
      isAvailable: (target) => store.isAvailable(target.recordingId),
      isDeleting: (owner) => owner.kind === "recording" && store.isDeleting(owner.recordingId),
      isCapturing: () => store.isCapturing(),
    },''');s=s.replace('''    validate: validateManifest,
    inspect: validatePackageTranscript,
    mediaPaths: (manifest) =>
      manifest.inventory
        .filter((member) => ["video", "system", "narration"].includes(member.role))
        .map((member) => member.path),''','''    validate: parseProjectPackageManifest,
    resolve: resolveProjectPackageMetadata,
    inlineRevisions: false,
    mediaPaths: (manifest) => manifest.resources.filter((resource) => resource.kind === "asset")
      .map((resource) => `assets/${resource.asset.asset.fileName}`),''');s=s.replace('''  const files = archiveContents(),
    input = join(home, "input.zip");''','''  const assets = new AssetStore(store, home);
  await assets.recover();
  const content = "generated source";
  const source = join(home, "source.mov");
  await writeFile(source, content);
  // Source bytes and probe metadata are controlled; no media decoding is requested.
  const asset = await assets.import(source, { kind: "import" }, async () => ({
    originUs: 0,
    streams: [{ id: "video", kind: "video", codec: "fixture", decodable: true,
      width: 32, height: 16, startUs: 0, endUs: 100,
      segments: [{ startUs: 0, endUs: 100, empty: false }] }],
  }));
  const projects = new ProjectStore(store, assets, new TranscriptStore(store, home, assetTranscriptOwner(assets)));
  const created = projects.create({ requestId: "create", title: "Portable fixture", canvas: {
    width: 32, height: 16, fps: { numerator: 30, denominator: 1 }, background: "#000000ff",
  }});
  projects.apply(created.project.projectId, { requestId: "place", expectedRevisionId: created.revision.id,
    operations: [{ operation: "track.add", track: { kind: "video", order: 0 }, label: "video" },
      { operation: "place", clip: { trackId: { label: "video" }, assetId: asset.id, streamId: "video",
        source: { kind: "range", range: { startUs: 0, endUs: 100 } },
        placement: { kind: "project", range: { startUs: 0, endUs: 100 } } } }],
  });
  const snapshot = projects.snapshot(created.project.projectId);
  const resource = { kind: "asset", ...assets.portable(asset.id) };
  const metadata = resourceMetadataMember(resource);
  const mediaPath = `assets/${asset.fileName}`;
  const files = { [mediaPath]: content, [metadata.reference.metadata.path]: metadata.body };
  for (const [ordinal, revision] of snapshot.revisions.entries()) files[`revisions/${ordinal}.json`] = JSON.stringify(revision);
  const inventory = Object.entries(files).map(([path, value]) => ({ path, bytes: Buffer.byteLength(value), sha256: createHash("sha256").update(value).digest("hex") }));
  const manifest = projectPackageManifest(snapshot, [resource], inventory);
  files["manifest.json"] = JSON.stringify(manifest);
  const input = join(home, "input.zip");''');s=s.replace('return { home, directory, handle, store, jobs, delivery, registry, input, files, writeArchive };','return { home, directory, handle, store, assets, projects, snapshot, asset, mediaPath, jobs, delivery, registry, input, files, writeArchive };');s=s.replace('"closes without library rows"','"closes without library rows"');s=s.replace('source/video.mov','PLACEHOLDER_MEDIA');s=s.replace('"PLACEHOLDER_MEDIA"','f.mediaPath');p.write_text(s)
