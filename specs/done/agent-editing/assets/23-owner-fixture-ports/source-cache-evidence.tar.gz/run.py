from pathlib import Path
import subprocess,hashlib,json,time,sys,os,signal
root=Path('/Users/david/dev/screen-recorder');bank=Path(__file__).parent;out=bank/sys.argv[1];out.mkdir();argv=sys.argv[2:]
paths=['packages/core/src/cache.ts', 'packages/core/src/cache.test.ts', 'packages/core/src/evidence.ts', 'packages/core/src/evidence.test.ts', 'packages/core/src/evidence-pages.test.ts']
pins=[]
for name in paths:
 p=root/name;data=p.read_bytes();dest=out/'sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);pins.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
start=time.time()
with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:
 p=subprocess.Popen(argv,cwd=root,stdout=so,stderr=se,start_new_session=True)
 (out/'process.json').write_text(json.dumps({'argv':argv,'pid':p.pid,'start':start,'sources':pins,'boundSeconds':30,'terminationGraceSeconds':2},indent=2))
 timed=False
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
(out/'terminal.json').write_text(json.dumps({'pid':p.pid,'end':time.time(),'exit':code,'waited':True,'deadlineExpired':timed},indent=2))
print(json.dumps({'output':str(out),'pid':p.pid,'exit':code,'deadlineExpired':timed}));sys.exit(code)
