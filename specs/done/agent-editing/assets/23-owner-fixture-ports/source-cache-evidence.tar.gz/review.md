# Cache and evidence source-owner port

Clean shape/code/docs review. The source policy still only reads recording identity and state; CaptureStore is its actual owner. Existing RevisionStore subclasses remain accepted structurally for unmapped consumers; no wrapper or new helper was introduced. All three test files change only imported store names, constructor names and store type annotations. Every prior assertion, sparse >1 GiB tail check, streaming/paging bound, sibling/deletion/restart/fence check remains. 17 + 22 + 7 = 46 declarations.

The held-file lifetime control was meaningful: deleting held protection after the first release let replacement publication succeed while the second read was live. Actual narrow red and exact restoration green are retained. Final 46 cases and core build/type/tool commands are terminal zero. Emitted JS function bodies are exact; explicit type imports delete only the obsolete empty library module load. The first parity assertion failed because inline type syntax emits an empty runtime import; it was not a product/test failure.

No owner README contract changed. Root owns spec/handoff reconciliation. Existing r0 raw cursor response and pure audio-plan input remain named pending mixed-contract work. No native, decoder, model, capture or full suite was invoked.
