# Decisions

Sound, high confidence: use explicit type imports. When a recording cache/evidence policy needs only CaptureStore's type, its emitted module should not load the retired editing library. Inline `{ type X }` retains an empty runtime import; `import type` removes it. This is a named module-load deletion; emitted algorithm bodies are unchanged, rather than falsely claiming byte equality.

Sound, high confidence: preserve the existing r0 raw-cursor response and pure original-revision audio-plan comparison in the portable-page suite. These are still consumed public/pure contracts, not CaptureStore editing facts. Removing them here would expand this fixture port into a separate contract purge.

Sound, high confidence: falsify held-reader reference counting through the existing public cache operation. Two handles provide a concrete early-release error; no extra production accessor/test framework is needed. All other transferred assertions are unchanged, not new behavior claims. No low-confidence architecture choice, schema, dependency, cache or public interface was added.
