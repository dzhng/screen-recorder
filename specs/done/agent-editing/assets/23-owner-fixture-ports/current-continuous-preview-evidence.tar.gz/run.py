from pathlib import Path
import os,json,subprocess,time,sys,hashlib
b=Path('/Users/david/.cache/screen-recorder/verification/continuous-preview-72a737a4');w=Path('/Users/david/.codex/worktrees/continuous-preview/screen-recorder');phase=b/sys.argv[1];producer=Path(sys.argv[2]);env=os.environ|{'SCREENREC_PREVIEW_CONTINUOUS_EVIDENCE':str(phase)};argv=['/Users/david/.nvm/versions/node/v24.14.0/bin/node','--test','--test-name-pattern=advances continuously',str(producer)];inputs=[producer,w/'apps/macos/tests/fixtures/swift-controls.mjs',w/'apps/macos/Sources/ScreenRecorder/PreviewController.swift',w/'apps/macos/Sources/ScreenRecorder/PreviewWindow.swift',*sorted((w/'apps/macos/Sources/ScreenRecorderControls').glob('*.swift'))]
def pins():return [{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs]
before=pins();(phase/'before.json').write_text(json.dumps(before,indent=2));(phase/'executed-producer.mjs').write_bytes(producer.read_bytes());start=time.time()
with (phase/'stdout.log').open('wb') as out,(phase/'stderr.log').open('wb') as err:
 p=subprocess.Popen(argv,cwd=w,env=env,stdout=out,stderr=err);r={'argv':argv,'pid':p.pid,'start':start};(phase/'outer-process.json').write_text(json.dumps(r,indent=2));print(sys.argv[1],'node PID',p.pid,flush=True)
 try:code=p.wait(timeout=90)
 except subprocess.TimeoutExpired:p.kill();code=p.wait();r['timeout']=True
r.update(exitCode=code,end=time.time(),seconds=time.time()-start);(phase/'outer-process.json').write_text(json.dumps(r,indent=2));after=pins();(phase/'after.json').write_text(json.dumps(after,indent=2));assert before==after;print('exit',code,flush=True);print((phase/'stdout.log').read_text()[-4000:]);print((phase/'stderr.log').read_text()[-1500:])
