
import AppKit
import AVKit

struct PlaybackFailure: LocalizedError {
    let errorDescription: String?
    init(_ message: String) { errorDescription = message }
}
@MainActor final class PinnedService {
    let file: String
    let project = "36c7e994-a477-4b0b-8ef1-130c29fb4f70"
    let revision = "6fd2ef65-89b5-470f-b553-a49dbf25e7d3"
    var closed: [String] = []
    init(_ file: String) { self.file = file }
    func call(_ operation: String, _ params: [String: Any]) async throws -> Data {
        if operation == "artifact.close" {
            guard params["token"] as? String == "continuous-token" else { throw PlaybackFailure("Wrong released token") }
            closed.append("continuous-token")
            return Data("{}".utf8)
        }
        guard params["projectId"] as? String == project else { throw PlaybackFailure("Changed project target") }
        if operation == "project.get" { return Data("{}".utf8) }
        guard operation == "preview.get", params["revisionId"] as? String == revision else {
            throw PlaybackFailure("Changed pinned revision")
        }
        return try JSONSerialization.data(withJSONObject: [
            "projectId": project, "revisionId": revision, "state": "ready",
            "delivery": ["token": "continuous-token", "bytes": 167145,
                "expiresAt": (Date().timeIntervalSince1970 + 30) * 1000],
            "published": ["preview": ["projectId": project, "revisionId": revision,
                "mediaType": "video/mp4", "file": file, "bytes": 167145]],
        ])
    }
}
@main struct ContinuousPlayback {
    @MainActor static func main() async throws {
        _ = NSApplication.shared
        NSApp.setActivationPolicy(.accessory)
        let service = PinnedService(CommandLine.arguments[1])
        var failures: [String] = []
        var observations: [[String: Any]] = []
        var report: [String: Any] = ["passed": false, "pid": ProcessInfo.processInfo.processIdentifier,
            "scope": "Unchanged production controller/presenter; controlled ready receipt; muted retained current A/V movie, not listening or moving-pointer verification"]
        let owner = PreviewController(call: service.call, failure: { failures.append($0) })
        owner.open(service.project, revisionId: service.revision)
        let window = NSApp.windows.first { $0.isVisible && $0.title.hasPrefix("Preview —") || $0.isVisible && $0.title.hasPrefix("Preparing Preview —") }!
        let view = window.contentView as! AVPlayerView
        // The ready task cannot run on this actor until the first await below. KVO delivery
        // from this actor's player assignment mutes it before PreviewWindow calls play().
        var mutedAssignments = 0
        let muting = view.observe(\.player, options: [.new]) { view, _ in
            MainActor.assumeIsolated {
                if let player = view.player { player.isMuted = true; mutedAssignments += 1 }
            }
        }
        var endedIdentity: ObjectIdentifier?
        let ending = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime,
            object: nil, queue: .main) { notification in
                let identity = (notification.object as? AVPlayerItem).map(ObjectIdentifier.init)
                MainActor.assumeIsolated { endedIdentity = identity }
            }
        var failure: Error?
        do {
            let readiness = ContinuousClock.now.advanced(by: .seconds(5))
            while view.player?.currentItem?.status != .readyToPlay {
                guard failures.isEmpty, ContinuousClock.now < readiness else {
                    throw PlaybackFailure("Retained movie did not become ready: (failures)")
                }
                try await Task.sleep(for: .milliseconds(25))
            }
            let player = view.player!, item = player.currentItem!
            player.pause()
            guard mutedAssignments == 1, player.isMuted else { throw PlaybackFailure("Player was not muted at assignment") }
            guard abs(item.duration.seconds - 6) < 0.001 else { throw PlaybackFailure("Wrong retained duration") }
            let title = "Preview — (service.project) — (service.revision)"
            guard window.title == title else { throw PlaybackFailure("Wrong pinned title") }
            let advanceDeadline = ContinuousClock.now.advanced(by: .seconds(2))
            let completionDeadline = ContinuousClock.now.advanced(by: .seconds(10))
            var advanced = false
            while endedIdentity == nil {
                let seconds = player.currentTime().seconds
                observations.append(["seconds": seconds, "timeControlStatus": player.timeControlStatus.rawValue,
                    "rate": player.rate, "itemStatus": item.status.rawValue])
                guard failures.isEmpty, item.status != .failed, window.isVisible,
                    view.player === player, player.currentItem === item, window.title == title, player.isMuted else {
                    throw PlaybackFailure("Pinned player changed or failed: (failures)")
                }
                if seconds > 0.5 { advanced = true }
                guard advanced || ContinuousClock.now < advanceDeadline else { throw PlaybackFailure("Player did not advance") }
                guard ContinuousClock.now < completionDeadline else { throw PlaybackFailure("Player did not reach end") }
                owner.tick()
                try await Task.sleep(for: .milliseconds(50))
            }
            guard advanced, endedIdentity == ObjectIdentifier(item) else { throw PlaybackFailure("Wrong end notification or no advance") }
            report["passed"] = true
            report["endedSeconds"] = player.currentTime().seconds
            report["durationSeconds"] = item.duration.seconds
            report["sameItemThroughEnd"] = true
            report["revisionId"] = service.revision
        } catch { failure = error; report["error"] = error.localizedDescription }
        owner.close()
        let releaseDeadline = ContinuousClock.now.advanced(by: .seconds(2))
        while service.closed.isEmpty && ContinuousClock.now < releaseDeadline {
            try await Task.sleep(for: .milliseconds(10))
        }
        muting.invalidate()
        NotificationCenter.default.removeObserver(ending)
        report["observations"] = observations
        report["failures"] = failures
        report["mutedAssignments"] = mutedAssignments
        report["closedTokens"] = service.closed
        report["windowClosed"] = !window.isVisible
        report["playerReleased"] = view.player == nil
        if service.closed != ["continuous-token"] || window.isVisible || view.player != nil {
            report["passed"] = false
            if failure == nil { failure = PlaybackFailure("Player teardown did not release ownership") }
        }
        try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
            .write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
        if let failure { throw failure }
        print("PASS muted pinned current A/V playback advances to end and releases player/window/lease")
    }
}
