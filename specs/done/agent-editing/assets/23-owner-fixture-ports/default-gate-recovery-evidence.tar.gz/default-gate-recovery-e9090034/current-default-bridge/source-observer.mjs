import {appendFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
const log=x=>appendFileSync(process.env.SCREENREC_23K_CONTROL,JSON.stringify(x)+'\n');
process.stdin.on('data',b=>log({direction:'request',base64:b.toString('base64')}));
const write=process.stdout.write.bind(process.stdout);process.stdout.write=(b,...args)=>{log({direction:'response',base64:Buffer.from(b).toString('base64')});return write(b,...args)};
process.on('exit',code=>log({event:'source-node-exit',pid:process.pid,code}));
await import(pathToFileURL(process.env.SCREENREC_23K_SERVICE).href);
