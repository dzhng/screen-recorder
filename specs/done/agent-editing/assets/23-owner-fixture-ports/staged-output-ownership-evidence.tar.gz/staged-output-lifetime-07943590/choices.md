# Decisions audited before commit

## Sound, medium confidence

**One held-parent scan is the cleanup bound.** A staging directory may be renamed while NewFile still holds its directory descriptor (an open handle to that actual directory). Discard empties that actual directory, then looks once through its retained parent for the same device/inode pair (filesystem identity), and removes only that empty entry. A different real directory at the former name survives with its exact bytes. If the owned directory moves outside this parent, this pass does not search the filesystem for it. The task authorized this bound; future cleanup must retain that limitation instead of adding repeated or recursive locator searches.

**Only direct writes have an earlier known leaf identity.** When NewFile.write creates bytes, it records the file identity and refuses a replaced leaf before publication. Platform media writers instead receive a pathname and assemble their file themselves; NewFile does not have that writer's initial file identity. They still benefit from the held stage directory and post-link exact inode/size receipt, but this pass does not promise arbitrary concurrent leaf replacement is fenced. That is a concrete API limitation, not a new optional policy.

## Sound, high confidence

**One descriptor-relative publisher serves new and retained outputs.** The old instance reopened the staging pathname and could accidentally publish foreign replacement bytes. The instance now uses retained directory handles; a resumed static candidate opens its roots when called, and both use the same link-and-confirm algorithm. A repeat publication succeeds only when the requested path names the selected inode. A late failed receipt removes only a new link made by this call that still names that inode; a prior successful link survives. This avoids parallel implementations and preserves no-overwrite/idempotent resume.

**Destruction closes; discard deletes.** Camera recovery intentionally keeps a failed candidate for diagnosis and resume. Deleting on NewFile destruction would erase that evidence. A compact control releases NewFile, verifies the retained exact bytes remain, and verifies the stage descriptor closed. Explicit discard remains the owner of cleanup and closes handles even if cleanup fails.

**Generic cleanup lives in Media once.** Media needs safe cleanup but cannot import Wire. The existing directory iterator and removal implementation moved literally to Media, and Wire consumers directly import it. Wire keeps its operation-specific locks and identity checks. No second remover, forwarding wrapper, new dependency or policy owner remains.

No unsound or user-only choices remain. Internal naming/fixture dispatch are routine discretion. Root owns promotion of these invariants into the canonical handoff and choices ledger.
