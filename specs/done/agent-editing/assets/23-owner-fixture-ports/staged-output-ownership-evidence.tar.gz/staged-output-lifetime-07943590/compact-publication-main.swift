import Foundation
@main struct Control { static func main() throws { try checkNewFilePublication(at: URL(fileURLWithPath: CommandLine.arguments[1])) } }
