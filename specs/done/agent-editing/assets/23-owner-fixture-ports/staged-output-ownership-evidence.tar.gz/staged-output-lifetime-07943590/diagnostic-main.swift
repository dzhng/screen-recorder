import Foundation
import ScreenRecorderWire
@main struct Diagnostic { static func main() async throws {
 let params = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
 let request = try JSONSerialization.data(withJSONObject: ["id":"diagnostic", "operation":"media.renderCompositionMovie", "params":params])
 let response = await NativeWire.respond(to: String(data:request,encoding:.utf8)!)
 print(String(data:response,encoding:.utf8)!)
} }
