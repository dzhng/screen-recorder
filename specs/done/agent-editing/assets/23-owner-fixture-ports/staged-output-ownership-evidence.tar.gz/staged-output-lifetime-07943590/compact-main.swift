import Foundation
@main struct Control { static func main() throws { try checkNewFileCleanup(at: URL(fileURLWithPath: CommandLine.arguments[1])) } }
