import {mkdirSync,writeFileSync} from "node:fs";
import {join} from "node:path";
import {createCompiler,validateComposition,resolveOutputSettings} from "/Users/david/dev/screen-recorder/packages/composition/dist/index.js";
import {nativeProcessing} from "/Users/david/dev/screen-recorder/apps/service/dist/native-processing.js";
const bank=process.argv[2];
const document={canvas:{width:160,height:128,fps:{numerator:20,denominator:1},background:"#000000ff"},tracks:[],groups:[],syncGroups:[],clips:[],processing:[]};
for(const [mode,endUs] of [["cancel",100000000],["collision",1000000]]) {
 const directory=join(bank,mode);mkdirSync(directory,{recursive:true});
 const range={startUs:0,endUs};
 const window=createCompiler(validateComposition(document,[]),mode).window({range,rendition:{sampleRate:48000,channels:2},tap:{target:{kind:"output"},point:{kind:"processed"}}});
 const frames=join(directory,"frames.jsonl");
 writeFileSync(frames,[...window.frames()].map(frame=>JSON.stringify(frame)+"\n").join(""));
 writeFileSync(join(directory,"request.json"),JSON.stringify({output:join(directory,"output.mp4"),frames,range,canvas:document.canvas,settings:resolveOutputSettings(),processing:nativeProcessing(window.processing()),assets:[],audio:{range:{start:0,end:endUs*48000/1000000},clips:[]}}));
}
