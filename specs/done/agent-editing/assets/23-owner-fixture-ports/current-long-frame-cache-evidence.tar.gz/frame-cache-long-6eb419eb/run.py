from pathlib import Path
import subprocess,os,time,json,hashlib,signal
b=Path(__file__).parent;r=Path('/Users/david/dev/screen-recorder')
def stage(name,cmd,budget,env=None):
 start=time.time();log=(b/(name+'.log')).open('w');p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);seen={}
 (b/(name+'-process.json')).write_text(json.dumps({'argv':cmd,'cwd':str(r),'pid':p.pid,'start':start,'budgetSeconds':budget},indent=2))
 timedout=False
 while p.poll() is None:
  rows=[]
  for line in subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,command='],text=True).splitlines():
   v=line.strip().split(None,3)
   if len(v)==4:rows.append((int(v[0]),int(v[1]),int(v[2]),v[3]))
  owned={p.pid};again=True
  while again:
   again=False
   for pid,ppid,pgid,command in rows:
    if ppid in owned and pid not in owned:owned.add(pid);again=True
  for row in rows:
   if row[0] in owned:seen[row[0]]=row
  elapsed=time.time()-start
  (b/(name+'-progress.json')).write_text(json.dumps({'seconds':elapsed,'logBytes':(b/(name+'.log')).stat().st_size,'inputBytes':(b/'video.mov').stat().st_size if (b/'video.mov').exists() else 0,'observedPids':list(seen)},indent=2))
  if elapsed>budget:
   timedout=True
   for pid,ppid,pgid,command in rows:
    if pid in seen and seen[pid][3]==command:
     try:os.kill(pid,signal.SIGKILL)
     except ProcessLookupError:pass
   break
  time.sleep(.2 if name=='cache' else 1)
 code=p.wait();log.close();terminal={'exitCode':code,'seconds':time.time()-start,'timedOut':timedout,'observedProcesses':list(seen.values())};(b/(name+'-terminal.json')).write_text(json.dumps(terminal,indent=2)+'\n');print(name,json.dumps({k:v for k,v in terminal.items() if k!='observedProcesses'}),flush=True)
 if code:print((b/(name+'.log')).read_text(),flush=True)
 return code
cmd=['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=30:duration=1800','-an','-c:v','libx264','-preset','ultrafast','-crf','30','-g','30','-bf','0',str(b/'video.mov')]
if stage('generate',cmd,120):raise SystemExit(1)
p=b/'video.mov';(b/'input.json').write_text(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ffmpeg':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0]},indent=2)+'\n')
env=dict(os.environ,SCREENREC_FRAME_CACHE_VIDEO=str(p),SCREENREC_FRAME_CACHE_EVIDENCE=str(b/'cache-receipt.json'))
code=stage('cache',['node','--test','--test-concurrency=1','apps/macos/tests/frame-cache-scale.mjs'],105,env)
print((b/'cache.log').read_text(),flush=True)
raise SystemExit(code)
