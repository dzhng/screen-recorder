# Lifetime checkpoint dispositions

- Old video-export.mjs:1693: port complete; current test `committed history survives`; deliberate defect `receipt nulled in retry` failed at `receipt differs`, restored green.
- Old video-export.mjs:1941: port complete; current test `one unsafe export staging entry`; deliberate defect `retireOwner throws first failure immediately` failed at `second intent remains`, restored green.
- Old video-export.mjs:1979: port complete; current test `an unreadable unrelated destination`; deliberate defect `retirement reconciles external file` failed at `permission-denied DELETE_FAILED`, restored green.
- Old video-export.mjs:1742: port complete; current test `lost retirement acknowledgement`; deliberate defect `absent staging opened during retirement` failed at `ENOENT DELETE_FAILED`, restored green.
- Old video-export.mjs:1318: port complete; current test `canceled intents keep exact-retry pins`; deliberate defect `allowance increased32to33` failed at `missing LIMIT_EXCEEDED`, restored green.
- Old video-export.mjs:1885: port complete; current test `managed source directories cannot`; deliberate defect `native external-directory check bypassed` failed at `missing INVALID_STORAGE`, restored green.
- Old video-export.mjs:2217: port complete; current test `export kind is persisted`; deliberate defect `kind fixed to video in request identity` failed at `missing REQUEST_CONFLICT`, restored green.
- Old video-export.mjs:3298: port complete; current test `shutdown fences and drains`; deliberate defect `close skips creating calls` failed at `closed prematurely`, restored green.
- Old video-export.mjs:2145: port complete; current test `abandonment drains in-flight`; deliberate defect `remove skips creating calls` failed at `removed prematurely`, restored green.
- Old video-export.mjs:1278: previous partial gap closed; current test `polling and export retry leave`; deliberate defect `replay retries preview automatically` failed at `failed attempt identity changed`, restored green.
- Old video-export.mjs:1536: previous partial gap closed; current test `project export pins an omitted revision`; deliberate defect `status receipt hash zeroed` failed at `independent hash differs`, restored green.

- V1005,1061,1212 resource-reference lifecycle assertions move with currentProjectPackages pin tests
- V1424 old recording-generation retention retired; corresponding currentresource pin preservation remains
- V1501 waiting pin+V1817combined canceled evicted edited revision+V1372exportattempt change still need accounting
- V3361bundledstartup cache ordering remains
- Package workspace+resource pins+copy receipt mutation remain per exhaustive map
