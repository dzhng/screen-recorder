# Shared index policy ownership review

Clean shape/code/docs review. ScreenshotIndex already owns the shared image/coverage receipt boundary. Its policy belongs beside that boundary, independent of the old recorded-span selector. The exact frozen object moves once; old declaration deleted, no wrapper/reexport/newmodule/packageexport. All seven direct maintained consumers use the existing exported owner. Type-only selector imports from ScreenshotIndex produce no runtime backedge. Existing focused modules load and produce matching expected results.

Policy source/emission bytes and all six executable module bodies match exactly after only imports and policy declaration relocation. 25 existing source/project/portable tests and core/service build/types plus tools/MJS syntax pass. The initial interrupted edit left three stale imports; five portable failures and executed source remain, then corrected direct imports earned green. This is an implementation/setup failure, not an invented behavior red control.

Remaining ScreenshotIndex recordingIndexDomain/Timeline runtime and inline RevisionStore import plus legacy portable scene/frame/trail validators are named pending dependencies. Their current consumers prevent deletion now. No README contract changed; root owns shared plan/handoff. No native/media/model/capture/fullsuite or wholesale old interpreter removal is claimed.
