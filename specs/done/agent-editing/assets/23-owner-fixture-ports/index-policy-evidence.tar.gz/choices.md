# Decisions

Sound, high confidence: keep the frozen index selection policy in existing ScreenshotIndex. A source or project sampler needs the common sampling/bounded-pending defaults, not the old recording edit selector. Moving the exact object to the shared image/coverage owner gives every caller one definition, without a policy-only wrapper or new public package path. Object bytes, IDs, thresholds and defaults stay exact.

Sound, high confidence: update all maintained consumers directly and delete the old export. The old selector still uses the same policy and its algorithm remains until mapped deletion; no compatibility alias remains. Old recording-domain ScreenshotIndex/portable validators retain their named Timeline/scene/trail/frame dependencies separately, so this is a real prerequisite rather than a false claim all old runtime dependencies disappeared.

Sound, high confidence: import/declaration body parity plus existing25 output/refusal cases is the proof for this behavior-preserving ownership move. No new compiler-only test, threshold mutation, native/decoder cohort or public capability was added. No uncertain policy/architecture choice beyond the explicitly approved existing owner.
