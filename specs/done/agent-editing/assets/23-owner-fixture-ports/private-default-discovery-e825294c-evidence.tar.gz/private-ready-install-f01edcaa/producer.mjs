import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawn, spawnSync } from "node:child_process";
import { once } from "node:events";
import { createRequire } from "node:module";
import { DatabaseSync } from "node:sqlite";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { lstatSync, readdirSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync, rmSync, cpSync, openSync, closeSync, existsSync } from "node:fs";
import { setTimeout as delay } from "node:timers/promises";
const bank = fileURLToPath(new URL(".", import.meta.url));
const root = "/Users/david/dev/screen-recorder";
const require = createRequire(join(root, "apps/macos/package.json"));
const { Client } = require("@modelcontextprotocol/sdk/client/index.js");
const { StdioClientTransport } = require("@modelcontextprotocol/sdk/client/stdio.js");
const save = (name, value) => writeFileSync(join(bank, name), JSON.stringify(value, null, 2));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const hashFile = (path) => sha(readFileSync(path));
const commands = [];
function run(command, args, options = {}) {
  const start = performance.now();
  const result = spawnSync(command, args, { cwd: "/", encoding: "utf8", timeout: 15000, maxBuffer: 4 * 1024 ** 2, ...options });
  commands.push({ command, args, cwd: options.cwd ?? "/", pid: result.pid, status: result.status, signal: result.signal, error: result.error?.message, ms: performance.now() - start, stdout: result.stdout, stderr: result.stderr });
  save("commands.json", commands);
  assert.equal(result.error, undefined, result.error?.message);
  assert.equal(result.status, 0, `${command}: ${result.stderr}`);
  return result.stdout;
}
function tree(path, hashAll = false) {
  const rows = [];
  if (!existsSync(path)) return rows;
  const visit = (p) => {
    const s = lstatSync(p, { bigint: true });
    if (s.isSocket() || p.endsWith("-shm")) return;
    const row = { path: p, mode: String(s.mode), inode: String(s.ino), bytes: String(s.size), mtimeNs: String(s.mtimeNs), ctimeNs: String(s.ctimeNs), kind: s.isDirectory() ? "directory" : s.isFile() ? "file" : "other" };
    if (s.isFile() && (hashAll || s.size <= 1048576n || p.endsWith(".sqlite") || p.endsWith(".sqlite-wal"))) row.sha256 = hashFile(p);
    rows.push(row);
    if (s.isDirectory()) for (const name of readdirSync(p).sort()) visit(join(p, name));
  };
  visit(path); return rows;
}
function personalSnapshot() {
  const processIdentity = run("/bin/ps", ["-p", "811,850", "-o", "pid=,ppid=,lstart=,command="]);
  assert.match(processIdentity, /811\s+1\s+.*\/Users\/david\/Applications\/Screen Recorder.app\/Contents\/MacOS\/ScreenRecorder/);
  assert.match(processIdentity, /850\s+811\s+/);
  const prefs = [];
  for (const dir of ["/Users/david/Library/Preferences", "/Users/david/Library/Preferences/ByHost"])
    for (const name of readdirSync(dir).filter((n) => n.startsWith("com.david.screenrec.personal")).sort()) prefs.push(...tree(join(dir, name), true));
  // Read the effective domain as well as on-disk files; never set or synchronize it.
  const exported = spawnSync("/usr/bin/defaults", ["export", "com.david.screenrec.personal", "-"], { encoding: "buffer", timeout: 5000 });
  assert.equal(exported.error, undefined);
  let effectivePreferences;
  if (exported.status === 0) {
    const canonical = spawnSync("/usr/bin/python3", ["-c", "import sys,plistlib,json; print(json.dumps(plistlib.loads(sys.stdin.buffer.read()),sort_keys=True,default=str,separators=(',',':')))"], { input: exported.stdout, timeout: 5000 });
    assert.equal(canonical.status, 0, canonical.stderr?.toString());
    effectivePreferences = sha(canonical.stdout);
  } else effectivePreferences = { status: exported.status, stderr: exported.stderr.toString() };
  return { processIdentity, app: tree("/Users/david/Applications/Screen Recorder.app", true), preferences: prefs, effectivePreferences, library: tree("/Users/david/.screen-recorder") };
}
const report = { passed: false, claim: "Private installed candidate and default ready-service CLI/MCP only; no cold LaunchServices claim", commands: "commands.json" };
let scratch, appChild, appExit, servicePid, client, transport, before;
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(read, label, ms = 15000) {
  const end = performance.now() + ms;
  for (;;) { const value = read(); if (value) return value; assert.ok(performance.now() < end, `${label}: timeout`); await delay(50); }
}
try {
  const expected = JSON.parse(readFileSync(join(bank, "candidate-before.json")));
  for (const p of expected) assert.equal(hashFile(p.path), p.sha256, p.path);
  before = personalSnapshot(); save("personal-before.json", before);
  scratch = realpathSync(mkdtempSync("/tmp/sr-ready-"));
  const home = join(scratch, "home"); mkdirSync(home, { mode: 0o700 });
  const app = join(scratch, "Applications/Screen Recorder.app"), bin = join(scratch, "bin");
  const launcher = join(bin, "screenrec"), executable = join(app, "Contents/MacOS/ScreenRecorder");
  const preferences = join(home, "preferences");
  const env = { HOME: process.env.HOME, PATH: "/usr/bin:/bin:/usr/sbin:/sbin", TMPDIR: process.env.TMPDIR ?? "/tmp", SCREENREC_HOME: home, SCREENREC_DEFAULTS: preferences, SCREENREC_SERVICE_LAUNCH: "1" };
  report.pointers = { scratch, app, bin, launcher, executable, home, preferences, service: join(app, "Contents/Resources/service/main.mjs"), native: join(app, "Contents/MacOS/screenrec-native"), expectedSocket: join(home, "run/service.sock") };
  save("pointers.json", report.pointers);
  run(process.execPath, [join(root, "scripts/install-personal.mjs"), "--app", app, "--bin", bin], { timeout: 60000 });
  const identity = run("/usr/libexec/PlistBuddy", ["-c", "Print :CFBundleIdentifier", join(app, "Contents/Info.plist")]).trim();
  assert.equal(identity, "com.david.screenrec.personal");
  run("/usr/bin/codesign", ["--verify", "--strict", app]);
  report.installedIdentity = identity;
  report.installed = tree(app, true); save("installed.json", report.installed);
  for (const rel of ["Contents/MacOS/screenrec-native", "Contents/Resources/service/main.mjs", "Contents/Resources/cli/main.mjs", "Contents/Resources/service/runtime.json"])
    assert.equal(hashFile(join(app, rel)), hashFile(join(root, "dist/ScreenRecorder.app", rel)), rel);
  for (const file of [launcher, join(app, "Contents/Resources/cli/main.mjs")]) assert.ok(!readFileSync(file, "utf8").includes(root), file);
  const launchAt = performance.now(), logPath = join(bank, "app.log"), log = openSync(logPath, "w");
  appChild = spawn(executable, [], { cwd: "/", env, stdio: ["ignore", log, log] }); closeSync(log);
  appExit = once(appChild, "exit");
  report.appPid = appChild.pid; save("launch.json", { executable, args: [], cwd: "/", env, pid: appChild.pid });
  const ready = await waitFor(() => {
    assert.equal(appChild.exitCode, null, "Private app exited during startup");
    return readFileSync(logPath, "utf8").match(/service ready pid=(\d+) socket=(\S+)/);
  }, "private service ready");
  servicePid = Number(ready[1]); report.servicePid = servicePid; report.startupMs = performance.now() - launchAt;
  assert.notEqual(appChild.pid, 811); assert.notEqual(servicePid, 850); assert.equal(ready[2], report.pointers.expectedSocket);
  const processLine = run("/bin/ps", ["-p", String(servicePid), "-o", "ppid=,command="]);
  assert.equal(Number(processLine.trim().split(/\s+/)[0]), appChild.pid); assert.ok(processLine.includes(report.pointers.service));
  const clientEnv = { ...env, SCREENREC_APP: join(scratch, "Never Launch.app") };
  assert.equal(existsSync(clientEnv.SCREENREC_APP), false);
  report.clientEnvironment = clientEnv;
  const call = (operation) => {
    assert.ok(alive(appChild.pid) && alive(servicePid));
    const result = JSON.parse(run(launcher, [operation, "--params", "{}"], { env: clientEnv, timeout: 15000 }));
    assert.equal(result.ok, true, JSON.stringify(result)); return result.data;
  };
  report.cli = { health: call("service.health"), capture: call("capture.status"), recordings: call("recording.list") };
  assert.equal(report.cli.health.pid, servicePid); assert.equal(report.cli.capture.device.state, "idle"); assert.deepEqual(report.cli.recordings.recordings, []);
  client = new Client({ name: "private-ready-install", version: "1" });
  transport = new StdioClientTransport({ command: launcher, args: ["mcp"], cwd: "/", env: clientEnv, stderr: "pipe" });
  await client.connect(transport); report.mcpPid = transport.pid;
  const tools = await client.listTools(); save("mcp-tools.json", tools); assert.ok(tools.tools.some((x) => x.name === "export.create"));
  const health = await client.callTool({ name: "service.health", arguments: {} });
  const capture = await client.callTool({ name: "capture.status", arguments: {} });
  save("mcp-replies.json", { health, capture });
  assert.equal(health.structuredContent.ok, true); assert.equal(health.structuredContent.data.pid, servicePid);
  assert.equal(capture.structuredContent.ok, true); assert.equal(capture.structuredContent.data.device.state, "idle");
  report.mcp = { defaultTransport: true, tools: tools.tools.length, health: health.structuredContent, capture: capture.structuredContent };
  await client.close(); client = undefined;
  if (report.mcpPid) await waitFor(() => !alive(report.mcpPid), "MCP child drain", 5000);
  process.kill(appChild.pid, "SIGTERM"); const [code, signal] = await Promise.race([appExit, delay(15000).then(() => { throw Error("Private app drain deadline"); })]);
  assert.equal(code, 0, `app exit ${code}/${signal}`); await waitFor(() => !alive(servicePid), "service child drain", 5000);
  report.appExit = { code, signal }; report.ownedChildrenDrained = true;
  const catalog = join(home, "library/catalog.sqlite"), db = new DatabaseSync(catalog, { readOnly: true });
  report.catalog = { path: catalog, format: db.prepare("PRAGMA user_version").get().user_version, databases: db.prepare("PRAGMA database_list").all() }; db.close(); assert.equal(report.catalog.format, 23);
  for (const p of expected) assert.equal(hashFile(p.path), p.sha256, p.path);
  const after = personalSnapshot(); save("personal-after.json", after); assert.deepEqual(after, before, "Personal app/library/preferences/processes must stay unchanged");
  report.personalUnchanged = true; report.candidateUnchanged = true; report.passed = true;
} catch (error) {
  report.error = { message: error.message, stack: error.stack }; process.exitCode = 1;
} finally {
  await client?.close().catch((e) => report.mcpCleanupError = e.message);
  if (appChild && alive(appChild.pid)) {
    process.kill(appChild.pid, "SIGTERM");
    await Promise.race([appExit, delay(15000)]);
    if (alive(appChild.pid)) process.kill(appChild.pid, "SIGKILL");
  }
  if (servicePid && alive(servicePid)) {
    const line = run("/bin/ps", ["-p", String(servicePid), "-o", "command="]);
    assert.ok(line.includes(report.pointers.service)); process.kill(servicePid, "SIGTERM");
    await waitFor(() => !alive(servicePid), "owned service cleanup", 5000).catch(() => process.kill(servicePid, "SIGKILL"));
  }
  if (scratch) {
    cpSync(join(scratch, "home"), join(bank, "retained-home"), { recursive: true, filter: (p) => !lstatSync(p).isSocket() });
    if (existsSync(join(scratch, "bin/screenrec"))) cpSync(join(scratch, "bin/screenrec"), join(bank, "installed-launcher"));
    rmSync(scratch, { recursive: true, force: true }); report.scratchRemoved = true;
  }
  if (before && !report.personalUnchanged) {
    const after = personalSnapshot(); save("personal-after.json", after); report.personalUnchanged = JSON.stringify(after) === JSON.stringify(before);
  }
  save("report.json", report);
}
console.log(JSON.stringify({ passed: report.passed, appPid: report.appPid, servicePid: report.servicePid, error: report.error?.message }));
