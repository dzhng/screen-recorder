import subprocess,time,json,os,signal
from pathlib import Path
bank=Path(__file__).parent
started=time.monotonic()
with (bank/'producer.log').open('w') as log:
 p=subprocess.Popen(['/Users/david/.nvm/versions/node/v24.14.0/bin/node',str(bank/'producer.mjs')],stdout=log,stderr=subprocess.STDOUT)
 print('Private cold-install probe started PID',p.pid,flush=True)
 timed_out=False
 while p.poll() is None:
  elapsed=time.monotonic()-started
  if elapsed>=120:
   timed_out=True;p.terminate()
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   break
  if int(elapsed)%5==0:print('Private probe elapsed %.1fs'%elapsed,flush=True)
  time.sleep(1)
 result={'pid':p.pid,'exit':p.returncode,'timeout':timed_out,'seconds':time.monotonic()-started}
 if timed_out:
  pointers=json.loads((bank/'pointers.json').read_text()) if (bank/'pointers.json').exists() else {}
  rows=subprocess.check_output(['/bin/ps','-axo','pid=,command='],text=True).splitlines()
  for line in rows:
   parts=line.strip().split(None,1)
   if len(parts)!=2:continue
   pid,command=int(parts[0]),parts[1]
   owned=command==pointers.get('executable') or (pointers.get('service') and pointers['service'] in command)
   if owned:
    assert pid not in [811,850];os.kill(pid,signal.SIGTERM)
    result.setdefault('emergencyPrivateTerminations',[]).append(pid)
  result['scratchRetainedForManualInspection']=pointers.get('scratch')
 (bank/'process.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result),flush=True)
 print((bank/'producer.log').read_text(),flush=True)
 raise SystemExit(1 if timed_out else p.returncode)
