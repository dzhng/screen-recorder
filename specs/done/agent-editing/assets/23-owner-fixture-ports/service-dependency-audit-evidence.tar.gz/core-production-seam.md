# Core recording-edit dependency seam

Read-only source map at primary `/Users/david/dev/screen-recorder`, originally
`ea62d9bd91c28da1e950d7ef770e85fc2f4273f6`. No implementation, test, build, capture,
index mutation or consumer screenrec invocation. Package-manifest and
pinPackageSnapshot are deliberately excluded; acquisition owner owns them.

Read repository/service README; no core README exists. The build includes all
core src TypeScript except tests and fixtures, so type-only orphan references
still need closure even where they do not execute. This map distinguishes static
runtime import reachability from calls to a live branch. Static reachability was
checked from `apps/service/src/main.ts` through workspace imports; named type-only
imports were excluded. Dynamic/reflection exports were not assumed to be called.
The actual canonical service constructions and dispatches were then inspected.
This is not a test or bundled-output verification.

## Top prerequisites

1. Prune recording branches from the **existing** TranscriptProcessing,
   SceneProcessing, IndexProcessing and ScreenshotIndexStore owners. Do not
   replace their current asset/project owners or portable-generation lifetimes.
2. Retain the source transcript reader/traversal/search declarations while
   removing recording TranscriptRead and its timeline imports.
3. Sever only obsolete type coupling: generic retained-image/index receipt shape
   currently derives from old MaterializedFrame; index generics default to
   RecordingIndexRecords; TrailScene derives its type from an old decoder wrapper.
4. Remove TimelineError's now-dead service mapping once no canonical owner can
   throw it. TimeRange/RenderSpan and exact presentation helpers already have
   `presentation-time.ts`; no duplicate time utility is needed.
5. Remove the canonical model.prepare callback's `transcripts.resume()` call
   (`project-service.ts:819`) with the old resume method. It only backfills
   recording jobs and returns immediately for the current asset-only owner.
6. Preserve recording **source** lifetime: CaptureStore, CaptureSources,
   CaptureCleanup, RecordingDeletion's sources branch and null-revision recording
   job target remain canonical. Removing the recording edit specialization does
   not authorize deleting capture/source ownership.

## Entry and real dispatch

`main.ts:3` constructs only startProjectService. The canonical composition uses
CaptureStore, AssetStore, AcquisitionStore, ProjectStore and shared queue/cache.
At project-service.ts:195–222 its target resolver accepts recording jobs only
with `revisionId:null`, against settled capture facts; it does not resolve a
recording edit revision. Current execute dispatch at :263–311 accepts:

- asset/project screenshot-index -> IndexProcessing;
- asset source-scenes -> SceneProcessing;
- asset/project frame/audio and project preview -> current media/project owners;
- transcript -> TranscriptProcessing, whose constructed configuration has only
  asset authority;
- acquisition import, asset import and capture-cleanup -> their existing owners.

Constructions: TranscriptProcessing :328 uses `asset:{assets,acquisitions}`;
SceneProcessing :455 uses asset-only selected-source sampler;
IndexProcessing :562 supplies asset/project domains, no recording domain.
Project/source screenshot stores at :533–560 use projectIndexDomain and
sourceIndexDomain explicitly. ProjectPackages consumes their portable resources,
not old recording artifacts. Cleanup calls :653–655 remain live for current
asset/project generations.

## File decisions and why

### library.ts — old editing owner, no live runtime consumer

RevisionStore extends CaptureStore solely to add old recording revision/history,
edit receipt/undo behavior and recording source settlement revision creation.
Canonical main does not instantiate or runtime-import it. Production imports in
other old core modules are type-only. `jobs.ts` imports RevisionStore only for
recordingJobTargets, an old adapter not used by canonical service (which supplies
its own JobTargets). Remove that adapter and type import with old suites. Keep
JobQueue, JobOwner and null-revision recording source targets. No generic
RevisionStore declaration needs to move into the current capture owner.

Do not inspect or alter pinPackageSnapshot under this map; acquisition owner owns
that closure.

### frames.ts — wholly old derivative/recording/package frame owner

LibraryFrameInspection, FrameInspection, renderFrame and their backend/request
shapes have no canonical main runtime import. Consumers are old package-frames
and old tests. Current service uses MediaFrameInspection in frame-inspection.ts,
with projectFrameRenderer and selected source image/frame renderers. These are
already the real owners; no subclass bridge is needed. Old FrameRequest and clean
recording/trail options do not define current selected source/project requests.

### preview.ts — wholly old movie-preview policy/adapter

PreviewInspection/PreviewInspectionBase, old PreviewRenderer/PreviewMovie,
previewPolicy and source rendition use recording spans/fixed audio roles and are
not canonical runtime owners. Current service uses ProjectPreviewInspection and
projectMovieRenderer. Retain shared checkRenderedMovie/RenderedMovie in
`rendered-movie.ts`, already imported by the current preview owner.

Type-only legacy imports remain in service render.ts and old package-preview;
remove those legacy renderer declarations, not generic render workspace support.

### audio.ts — imported at runtime only through dead recording transcription

Canonical import graph currently reaches this module via
TranscriptProcessing -> planAudioTracks. The call is inside private narration(),
which is used only by recording status/execute branches. Current source
transcription already obtains exact selected.track from selectSource. Current
MediaAudioInspection/audio-inspection.ts and projectAudioRenderer own live audio.
No canonical call needs AudioRole, planAudioTracks/Excerpt, renderAudio,
AudioInspection/LibraryAudioInspection or their fixed narration/system types.

After pruning TranscriptProcessing's recording branch and old service movie
renderer/package adapters, audio.ts can retire. Do not promote AudioTrackPlan to a
new generic abstraction just to preserve old render signatures.

### processing.ts — old recording SourceProcessing only

SourceProcessing/sourceArtifact/sourcePolicy are runtime-imported by
TranscriptProcessing solely for recording startup backfill. Other production
consumer is old package-assembly. Current acquisition import owns native
source-evidence generation; CaptureSources owns donor admission and source jobs;
CaptureSourceRead owns selected acquisition evidence. Do not retain
SourceProcessing under a renamed wrapper. Remove sourceArtifact/sourcePolicy
imports with the dead recording resume policy.

### derivative-inspection.ts — orphan abstraction after old media retirement

DerivativeInspection and LibraryDerivatives resolve TimelineRevision and recording
source readiness. The apparent runtime reach comes only from old audio.ts. Old
frames/preview/package adapters supply its other consumers. Current cached media
already uses `cached-derivative.ts` and its actual owners. There is no generic
current consumer requiring this abstraction to move.

### transcript-processing.ts — KEEP owner, remove recording branch

Keep assetTranscriptOwner; selectedAudio/sourceDescriptor; TranscriptionModels;
portable/adopt publication behavior; execution identity (decoder/model pins);
sourceIdentity/sourceStatus/prepareSource/publishedSource/retrySource;
executeSource, transcribeSource, cleanupAsset and asset traversal. Those serve
current public source transcript reads, project evidence dependencies and portable
resources.

Remove recording options/RecordingDomain/ReadInput, recording getter, old input
string, identity(recordingId), narration, status/prepare/resume/retry(recordingId),
recording resolve/get/search, cleanupRecording and the recording tail of execute.
Keep source-side job/selection/model validation and cleanup fences. Source get and
search already live in SourceTranscriptRead, so no new read facade is needed.
Remove old planAudioTracks, SourceProcessing/source policy, RevisionStore,
recordingTranscript and TranscriptRead/continuation imports when their last use
is gone. `resume()` is not an asset resumption contract: source preparation is
request-owned; current callback is an intentional no-op today.

### transcript-read.ts — mixed owner; shared declarations must survive

Remove recording page/search cursor schemas, transcriptContinuation and
TranscriptRead (projection through TimelineRevision, :103 onward). Keep
SourceTranscriptRead (:422), transcriptSearchTerms (:552), TranscriptTraversal
(private class near :251), bounded ordered words/gaps/search, foldWord use,
limit/parse/wordId helpers and source cursor identity. Current service imports
SourceTranscriptRead directly; project-transcript.ts imports it and search terms;
project-evidence.ts uses search terms.

SourceTranscriptRow currently uses Omit of old TranscriptWordRow/GapRow, and
SourceTranscriptSearchEntry uses Omit of old TranscriptSearchEntry. Refactor those
base type declarations to the actual source row/search contract so removing
recording fragments does not strand compile-only references. ProjectTranscriptRow
already adds current occurrence fragments itself. No need to move the live
reader into a new module simply to delete old code; keeping its existing owner
avoids churn. Removing old imports then severs this path to timeline.ts.

### scene-processing.ts — KEEP selected-source analysis/publication

Keep portableScenePublicationSchema/type, sourceStatus/prepareSource/
publishedSource/retrySource, sourceIdentity, selected authority, portable/adopt
publication, cleanupAsset and asset cleanup loop, executeSource and shared
analyze commit/rollback loop. ProjectPackages and project-package.ts consume the
portable schema/publication, and service source/index/event readers use this owner.

Remove options.recording, recording getter and status/identity/prepare/resume/
retry(recordingId), cleanupRecording, recording cleanup traversal and execute's
recording branch. Canonical service explicitly dispatches scenes only for asset
jobs. Narrow analyze's union of SourceSceneAnalysis | SelectedSourceSceneAnalysis
to the live selected-source implementation/needed analyze interface. Do not
remove scenePolicy.maximumRangeUs or shared raster/clock policy.

### index-processing.ts — KEEP source/project processing/publication

Keep source and project option domains; current request/retry/published/get/
coverage/frame/openRead paths; portable/adopt publication; source-scene retention;
materializeSourceIndex/materializeProjectIndex; source/project cleanup and
admitProject. Service and ProjectPackages use them directly.

Remove recording option/getter; old IndexReference/IndexFrameReference/IndexEvidence
and IndexInput; request/get/coverage/frame/openRead/read/published/retry(recording)
block (:643–804); recording execute tail (:818–910); cleanupRecording and its
cleanup branch. Remove requireSlot (:805) too: its only callers are old recording request
(:700) and retry (:801); current source/project branches use their existing
admission paths. Remove resulting selectIndex, selectionEvidence, materializeFrame,
framePolicy, recording trailPolicy, source metadata and RevisionStore imports.
Those imports currently load whole old timeline/render modules despite no live
recording branch being configured. Retain encodeIndexRecord and live policy
references until their exact current uses are checked.

### screenshot-index.ts — KEEP generic storage and current domains

Current service constructs ScreenshotIndexStore<ProjectIndexRecords> and
<SourceIndexRecords>. Keep IndexRecords, IndexDomain, ScreenshotIndexStore,
metadata/entry generic types, portable record/admission types,
indexGenerationResource, encodeIndexRecord, generation staging/validation,
contained image identity/read/reclaim and resource-reference ownership.

`selectionPolicy` is shared live configuration: source-index-selection.ts and
project-index-selection.ts use its numeric budgets/thresholds. Do not delete it
with old selectIndex. Its existing generic storage module can keep ownership;
there is no necessity to introduce a second policy copy.

Remove ScreenshotIndexIdentity/RecordingIndexRecords, recording source/scene
identity helpers, pinnedIdentity, validateIndexEntry (:204), recordingIndexDomain
(:247–319), recording owner path branches when artifact-retirement closure permits.
Those alone use timeline editedToSource/sourceToEdited and recording revision
metadata. Keep source/project IndexDomain implementations already in source-index.ts
and project-index.ts.

Type closure prerequisites:

- IndexRecords.frame is currently Pick<MaterializedFrame, file/bytes/mediaType/
  width/height>. This generic PNG receipt shape survives; express it against the
  current receipt/retained-image owner or directly as that minimal structure.
- ScreenshotIndexMetadata/Entry/Store and neighboring index-read.ts and
  screenshot-index-read.ts default generic D to RecordingIndexRecords. Remove
  obsolete defaults or use genuine generic IndexRecords where suitable; current
  domain call sites already supply source/project records. Do not keep an empty
  recording type to placate inference.
- retained-image.ts only imports MaterializedFrame for bytes/mediaType/width/height.
  Its real contained PNG validation is live and must survive. Decouple this tiny
  receipt type from old rendering rather than deleting image validation.

### timeline.ts — no uniquely shared current logic to transplant

Static import paths still exist through operation-errors.ts, screenshot-index.ts,
transcript-read.ts and the old IndexProcessing/materializeFrame or
TranscriptProcessing/audio branches. Their live usage is entirely removable
recording specialization, not current project editing.

`operation-errors.ts:3` unconditionally imports TimelineError, but current
project/source owners use CatalogError or CompositionError. Remove that mapping
when obsolete callers are gone; don't make a second shared invalid-range class.
Shared TimeRange, RenderSpan, renderPlan and exact presentation comparison already
live in presentation-time.ts and must remain. Old span/r0 projection and history
parsing need no replacement inside canonical composition, which already owns
rational project timing and source projection.

Old event-pages/index-pages/selection/frame-materialization paths are outside the
canonical live branch graph once recording adapters are removed. Their suites
and package adapter callers still need retirement, not a hidden compatibility
entry. package-manifest is excluded from this map and must be coordinated with its
owner before final timeline file deletion.

## Adjacent production seams that must not be swept up

### Service render.ts is mixed

Current main/project-render/voice/media-probe use clearRenderWorkspace,
withRenderedFile and withRenderAttempt. Keep their descriptor lifetime,
containment, bounded timeout/drain and cleanup implementation.

previewRenderer, PreviewEvidence, withRenderedMedia, renderDeadlineMs's
recording-span formula and fixed AudioTrackPlan/PreviewMovie signatures only serve
the old recording renderer/package wrapper or legacy test harness. No current
production caller invokes them. Remove those declarations separately once their
legacy render-timing/movie-lifetime proof has current owners. Do not delete
render.ts wholesale or carry old core audio/preview types merely for compile
convenience. Current render deadlines have their own worker/project owner.

### scenes.ts and trails.ts have real shared algorithms

Do not delete scenes.ts with recording SceneProcessing. SelectedSourceSceneAnalysis
in source-scenes.ts uses compareVisualRasters, scenePolicy and sceneSampleTimes.
Current PresentationPointer uses analyzeSceneObservations; presentation-pointer-
history uses compareVisualRasters. scene-evidence validation retains shared policy
and clocks. SourceSceneAnalysis is the old recording sampler; it can disappear
once recording metadata/SceneChunkReport consumers close, but shared helpers stay.

Do not delete trails.ts with planFrameTrail. Current PresentationPointer invokes
planVisualTrail; current pointer-schedule and presentation history use trailPolicy,
CursorPoint and PointerResetFloor. planFrameTrail/analyzeFrameScene's old native
nearest-sample wrapper is removable after old frame owner closure, but TrailScene
currently derives its type from analyzeFrameScene. Give the current scene-result
shape its actual owner if removing that wrapper. Keep shared planVisualTrail's
scene comparison, pause/geometry reset and exact presentation clock behavior.

### Capture and source facts remain recording-owned where appropriate

Canonical project-service.ts:1302 constructs RecordingDeletion with
`sources:captureSources`, not `artifacts:RecordingArtifactRetirement`.
recording-artifact-retirement.ts is a compile-time old alternate branch in
service deletion.ts, with no canonical construction. Its cache/source/scene/index/
transcript cleanup can retire with old editing artifacts; preserve current donor
retirement, admission borrowers, native directory lock/drain and capture rows.

`jobs.ts` recordingJobTargets is old; generic recording JobOwner and null revision
source work are not. `cache.ts` recordingCacheOwnerCheck is an old helper, but
DerivedCache itself is fully current. Likewise generic scene/transcript stores
have asset owners and portable resource meanings that must not be discarded
because their unions still mention recording. A final type/union cleanup can
remove recording-specific metadata adapters/path branches only after their old
retirement callers and tests have closed.

VisualObservationCache has no current production constructor. It is a recording
media observation cache, not the current pointer/source-scene owner; it is a
candidate for retirement with old rendering tests, not a prerequisite to invent
another current cache.

## Minimal removal order

1. Current owner ports first (service fixture map and source lane test work).
2. Remove optional recording branches from transcript/scene/index processing,
   dead canonical resume callback and old recording media adapters.
3. Strip recording read/domain/type defaults from transcript-read and screenshot
   storage/readers while retaining generic current algorithms and receipts.
4. Delete old frames/audio/preview/processing/derivative-inspection modules,
   old service renderer portions, and recording-artifact deletion option when
   their actual consumers are gone. Retain generic render workspace support.
5. Remove TimelineError mapping and final timeline/library import/export entries
   only after package owner closure. Update core package exports and build/type
   consumers honestly; exported names alone are not runtime callers.
6. Run the lane's required focused checks after implementation; none ran here.

This map authorizes no file deletion by itself. It identifies live owners and
orphan branches so the implementing lane can complete one-owner closure without
rebuilding an obsolete abstraction.
