# Service fixture contract audit

Read-only audit of `apps/service/src/operations.test.ts`,
`apps/service/src/round-trip.test.ts`, and
`apps/service/fixtures/edit-server.mjs`, at primary checkout
`/Users/david/dev/screen-recorder`, baseline
`ea62d9bd91c28da1e950d7ef770e85fc2f4273f6`.

The audit read repository/service README instructions and the audit-tests skill.
No tests, builds, capture, consumer screenrec invocation, repository edits,
staging, or commits were performed. This is source correspondence, not a runtime
verification result. The companion source pin file records baseline and observed
bytes independently, so subsequent implementation can distinguish this audit's
sources from later changes.

Scope is exactly the two suites and their fixture dependencies. Capture.test.ts
and package closure implementation are outside scope. The original inventory is
seven declarations in operations, four in round-trip, plus a subprocess fixture.
Operations contains two recording-list invalid-parameter rows and three
completed-job operation rows, all accounted for below. Seeding loops are setup,
not additional cases.

## Decision and architecture

Retire the old recording editing owner rather than reconstructing it under a new
fixture name. Keep public edit persistence, replay, stale rejection, concurrency,
framing, capture discovery, model/transcript evidence, and source-job lifetime in
the current canonical service owners.

`specs/agent-editing/slices/23-cutover.md:30–39` explicitly removes the old span
revision interpreter, fixed-role movie/package requests and recording
`currentRevisionId`, while keeping the retained old library intact and not
migrating old history or jobs. `apps/service/src/project-service.test.ts:146`
checks that a fresh canonical service creates neither projects nor old
`revisions`, `edit_requests`, or `undo_stack` tables just by owning capture facts.
A fresh recording does not implicitly become an editable project.

References below are repository-relative baseline locators. Later line movement
must not be confused with changed coverage. The precise assertions, not the test
names, decide whether a port is needed.

## operations.test.ts: complete matched inventory

### O140 — catalog, trim/cut/undo/restore, relaunch replay

Actual old assertions:

- Latest discovery selects the unfinished take, whose current revision is null.
- Revision inspection of unfinished, failed-without-source, and canceled takes
  answers NOT_READY or UNAVAILABLE (including START_FAILED diagnostic).
- A completed take exposes its source duration.
- Recording cut and trim produce exact source spans and durations.
- Undo creates a new revision rather than restoring an old ID; restore returns
  the original whole-source span.
- A new stale edit fails. Relaunch preserves the restored head; replay of an
  earlier request returns its original complete result without moving that head.
- Explicit historical r0 remains readable; two-row history includes pinned
  throughOrdinal 4.

Disposition: remove the old recording revision representation and automatic
revision-readiness semantics. Keep source discovery under CaptureStore and public
capture operations. Do not make canonical project queries depend on recording
state merely to retain the old NOT_READY/UNAVAILABLE matrix.

Existing current public proof:

- `packages/test-harness/editing/projects.mjs:80–140` applies via actual CLI,
  replays the complete result through MCP, rejects a new stale request, rejects a
  late invalid operation without changing the head, restarts the current service,
  replays the original complete result, undoes to the original document with a
  different ID, and restores the applied document.
- `projects.mjs:368–398` starts a history traversal, commits one of two concurrent
  edits, checks the winner's exact document/head, then finishes the earlier
  history traversal without including the newly inserted edit. It also replays a
  no-op receipt after head advancement without moving the head.
- `packages/test-harness/editing/cutover-state.mjs:470–645` matches current public
  project edit/replay/stale/history/undo/restore behavior against a frozen legacy
  app. The modern side uses the selected current source bundle; legacy production
  code in this checkout is not its dependency.

These preserve durable edit meaning at the current project boundary. Exact old
recording span/r0 output is deliberately not a canonical project contract.

### O258 — malformed edits, domain errors, concurrent winner

Actual rows are unknown `typo`, reversed range, missing recording.get, and two
concurrent edits with distinct request IDs but the same expected revision. Exactly
one wins; the loser is STALE_REVISION; persisted head has the winning duration and
source span.

Disposition:

- Concurrent winner and stale refusal are covered through real CLI writers by
  `projects.mjs:368–398`; exact current rollback is public at `:100–118`.
- Recording trim INVALID_RANGE and its exact recording document are obsolete
  operation semantics; current atomic edits return their current typed errors.
- The exact unknown-parameter INVALID_PARAMS dispatch assertion and missing
  recording.get NOT_FOUND assertion were not found in the inspected current
  public cases. Add cheap rows to the grouped canonical source/project service
  case if preserving these public dispatch claims. Strict protocol schema tests
  alone are adjacent proof, not this boundary.

### O293 — recording discovery pagination and restart

Actual assertions: newest unfinished take first with limit 1, canceled take
excluded, continuation beforeSequence 3, service relaunch, next two rows are
failed then completed, null end cursor. Invalid parameter table has exactly:

1. `{ limit: 101 }`
2. `{ cursor: { beforeSequence: 0 } }`

Disposition: PORT. This contract remains live at
`apps/service/src/project-service.ts:753`. `CaptureStore.list` at
`packages/core/src/capture-store.ts:335–356` uses descending immutable creation
sequences, excludes canceled/deleting takes, and validates these bounds.
`capture-store.test.ts:449,490` proves storage behavior including continuation and
reopen. Current `project-capture.test.ts` cases inspect unpaged lists; they do not
replace public continuation across restart.

Small owner port: one actual canonical subprocess source-discovery case seeded
with capture facts only. Keep latest incomplete > completed, canceled omission,
limit-1 first page, reopen, continuation and null end, plus the two malformed
rows. Do not carry `currentRevisionId` into the fresh capture type. The same case
can absorb missing recording.get NOT_FOUND and unknown-parameter rejection.

### O323 — package-root failure isolates unrelated library operations

Actual assertions: nonprivate run/packages (0755) causes package.open
INVALID_STORAGE; package.status is recovery; recording.get remains available.
The final row rejects simultaneous recordingId and packageHandle on revision.get.

Disposition: small PORT for canonical startup/dispatch isolation. Registry tests
are lower-level and do not prove that an invalid package root leaves the actual
service serving unrelated operations. Use project.get or capture source facts as
the unrelated operation. Preserve package.open error and public recovery status.
The old dual recording/package revision selector is retired; preserve only any
corresponding current selector exclusivity contract, not the old selector union.
Package closure implementation remains outside this audit's scope.

### O428 — positive transcript, model readiness, pages/search/cut/retry

Actual old assertions:

- Sparse pinned model files plus a receipt cause model.status and model.prepare
  to report ready without download.
- Startup automatically admits every narrated recording after source evidence;
  silent recording returns unavailable/no_narration/nonretryable.
- Paginated transcript has exact seven words and two not_acquired gaps; generation
  and r0 remain fixed. `Um,` is filler at an exact source interval.
- Case-insensitive/punctuation phrase `settings PANEL` yields w2/w3 and exact
  source interval.
- A recording cut inside Settings yields a partial word and two exact
  source/playback fragments without changing transcript generation.
- processing.retry on ready transcript keeps job/publication and invokes native
  transcription only once. Native request carries exact managed model directory,
  pinned model file descriptors and acquired narration intervals.

Disposition: retire automatic recording startup transcription, no_narration
recording status, and recording cut mapping. Selected source requests now own
transcript preparation; project occurrences own editing/projection.

Existing current public proof:

- `packages/test-harness/editing/source-evidence.mjs:90–180`: actual model absent
  then ready observations; one-row transcript pages through CLI and MCP compare
  completely; generation remains fixed; all source words/ranges/confidence match
  retained native oracle; exact physical gap is present; phrase result word IDs
  are checked; phrase cannot cross the gap; foreign selection cursor is refused.
- `source-evidence.mjs:193–216`: actual selected native request uses the selected
  stream and correct origin offset, with no fixed recording-role substitution.
- `source-evidence.mjs:278–326`: actual canceled source attempt, explicit retry,
  complete acquired-support words and CLI/MCP equality. Later restart checks
  preserve complete source transcript results.
- `packages/test-harness/editing/cutover-words.mjs:795–838`: complete current public
  project partial-word rows through CLI and MCP independently equal
  expectedProject; exact retained fragment intervals are compared. `:857–891`
  independently checks current project phrase matches. This is a real public
  query proof; its frozen ASR is explicitly not an inference-quality claim.
- `cutover-words.mjs:582–594` performs public model preparation and compares ready
  status through CLI and MCP. It does not assert a second prepare of an already
  ready Parakeet model is a no-op.

Do NOT cite `source-evidence-project.mjs`'s partial projection assertion as public
transcript proof: that helper invokes the pure projection engine directly and
labels it accordingly.

Residual exact public assertions not located in independent surviving owners:

- `Um,` filler classification (classification is evidence, not permission to edit).
- Mixed-case/punctuation phrase normalization.
- Ready `transcript.retry` returns the same source job/publication without another
  worker call. `generation-evidence.mjs:128–136` proves ready `job.retry` is the
  exact same public receipt, but that is a different operation dispatch.
- Ready `model.prepare` is a no-op and the actual Models owner supplies the precise
  managed native request fields. The current transcription fixture declares model
  readiness; it cannot independently prove real Models readiness.

Small owner port: one controlled canonical selected-source transcript case can
retain these residual assertions without bringing back recording SourceProcessing
or another media corpus. Use current asset/stream/acquisition authority and a
small worker-written transcript. Preserve explicit gap/source support as needed
for the native request assertion. `word-kind.test.ts`, asset-transcript tests and
transcript core tests are adjacent lower-level evidence, not substitutes for the
public wiring claims. Existing fixed sparse model receipt setup is a fixture
technique, not a new requirement to download or infer during a test.

### O568 — unprepared model does no transcript work

Actual assertions: absent model; unavailable/model_not_prepared/retryable with
null job; transcript.get page null; processing.retry MODEL_NOT_PREPARED; no native
transcription log exists.

Disposition: combine with existing
`apps/service/src/project-service.test.ts:638–690`. That real-socket case imports
a selected source, checks model absent, source get/search model_not_prepared with
null page, transcript.retry MODEL_NOT_PREPARED, model still absent, and zero
speech.transcribe calls. It also verifies acquisition authority refusal.
Original `retryable`/`jobId:null` fields are not explicitly asserted there; add the
current equivalent fields to the existing assertion if those remain in the
current response schema. Do not reintroduce startup transcription or r0.

### O600 — public source/revision jobs across restart

Actual old assertions: seed one failed source-owned recording job with null
revision, one ready recording revision job pinned to r0. Public source get retains
failure/target; retry queues same target; cancel returns canceled; each operation
in `[job.get, job.retry, job.cancel]` on ready revision job preserves state,
attempt and r0 target. Absent job returns NOT_FOUND. Relaunch preserves canceled
source target; retry and cancel still work on that identity.

Disposition: retire recording revision job/r0 and fake unsupported
`target-contract-proof` artifact. No old jobs are migrated. Preserve current
source-job public state and identity under acquisition/asset owners.

Current public proof:

- `project-capture.test.ts:173–217`: failed source admission remains discoverable
  through stop replay and reopen.
- `project-capture.test.ts:318–377`: explicit source retry keeps job/acquisition,
  changes attempt, becomes ready, and remains ready without donor files.
- `packages/test-harness/editing/source-acquisition.mjs:224–281`: public canceled
  acquisition job, retry with changed attempt, actual crash/restart observed as
  JOB_INTERRUPTED, retry of same job with another attempt, and ready acquisition.
- `project-service.test.ts:293–329`: actual public cancel drains a source probe;
  retry of same job refuses changed frozen source.
- `project-service.test.ts:1067`: ready public job.retry leaves entire SQL job
  inventory unchanged, even while unrelated detailed metadata is malformed.
- `generation-evidence.mjs:128–136`: public ready source transcript job retry equals
  its complete prior receipt exactly.

Remaining exact public rows not found: `job.cancel` on already-ready job preserves
attempt/result, canceled source job stays canceled across clean restart and then
same-ID retry/cancel works, absent-job NOT_FOUND. Fold these into one existing
canonical source-job lifecycle case. Preserve both readiness idempotence and
canceled restart continuity; the latter is not identical to interrupted-running
job recovery.

## round-trip.test.ts: complete matched inventory

### R60 — subprocess persistence, complete replay and new stale edit

Old `edit-server.mjs` directly dispatches recording store.edit through listenLocal;
subprocess call fixture invokes callLocal. Assertions independently inspect SQLite
spans, equal complete replay, stale error correlation and currentRevisionId detail,
then history length exactly two.

Disposition: remove old manual editing fixture. Current public edit persistence,
replay, stale and unchanged head have the exact owners cited under O140/O258.
Current `projects.mjs` only checks stale code, not
`error.details.currentRevisionId`; strengthen that existing public assertion if
the current field contract is intended. Do not copy the old response shape, which
returned a bare recording revision instead of the canonical edit result.

### R103 — oversized otherwise-valid mutation never reaches SQLite

Old custom handler ignores a padding property, making the payload semantically
acceptable to that fixture if framing protection fails. After socket close, the
store must still show r0/full source.

Disposition: PORT at real socket/current canonical project service boundary.
`index.test.ts` transport cases and `lifetime.test.ts:300` control-pipe oversized
resynchronization do not show this socket mutation cannot commit. Protocol parser
unit tests are also adjacent.

### R140 — invalid UTF-8 mutation never reaches SQLite

Same as R103 but changes a byte inside a JSON string to 0xff. The fixture's padding
field would be ignored by its domain handler if malformed bytes were replaced
rather than rejected. Persisted recording revision must not change.

Disposition: PORT with R103 as two parameter rows. Use a valid canonical project
edit. For oversized bytes, JSON whitespace padding keeps the decoded mutation
schema-valid; for invalid UTF-8, corrupt a byte within a string of an otherwise
valid mutation. Unknown current-schema `padding` would create a second refusal
cause and weaken falsification. Wait for the connection to close, assert current
revision/history/request receipt remain unchanged, then send the valid control
mutation to show the mutation route actually works. Do not merely assert a
transport error or test a harmless service.health call.

### R163 — timeout after commit leaves one replayable mutation

Old fixture commits store.edit, then awaits a delay under the request signal.
Caller deadline produces TIMEOUT; independent store read sees committed spans;
same request ID later returns that original revision and history stays length two.

Existing current public owner:

`cutover-state.mjs:268–314` puts a socket proxy in front of the actual current
service. It receives a successful backend response, discards it, asserts the CLI
client did not receive success, and retains the observed committed reply.
`:477–485` restarts and replays the same current project edit through MCP, asserting
complete result equality. This is strong committed lost-acknowledgement proof;
it does not merely call an internal store or infer commit from a timeout.

Distinction: the existing proxy disconnects; it does not produce the exact client
TIMEOUT path. If timeout causality is retained as a distinct requirement, extend
that same proxy pattern to hold the successful response past the client deadline
around canonical service, then verify replay and one history row. Do not retain
manual recording edit dispatch to obtain the delay. The underlying durable
commit/lost-response guarantee already has exact current public proof.

## Fixture ownership and cleanup

- `apps/service/fixtures/edit-server.mjs`: sole consumer is round-trip.test.ts.
  Contains manual recording RevisionStore allocation, source registration,
  edit.cut dispatch, CatalogError mapping, optional postcommit delay and IPC
  shutdown. Remove with old round-trip after surviving ports are in place.
- `apps/service/fixtures/call.mjs`: reference search found **only**
  round-trip.test.ts. It is not shared. Remove with that suite unless deliberately
  reused by the new current-boundary test. This corrects an earlier preliminary
  statement that it had other consumers.
- `apps/service/fixtures/speech-worker.mjs`: reference search found **only**
  operations.test.ts. It fabricates recording media.sourceEvidence and old
  narration intervals plus raw speech. Remove once positive transcript residuals
  have a current source owner; do not carry the recording evidence adapter.
- `packages/test-harness/editing/transcript-fixture-service.mjs` is a current
  controlled transcription fixture, but its Models overrides explicitly declare
  scratch readiness. It cannot serve as proof of real Models-owner installation
  or idempotent ready preparation without a separate observation.

## Coherent grouped implementation plan

1. Extend current canonical service cases with capture-source discovery and
   restart pagination (including both invalid rows, missing owner and strict
   unknown-param refusal), plus the remaining source-job lifecycle rows.
2. Add a small canonical package-root startup/dispatch isolation case without
   expanding package closure scope.
3. Put the residual positive transcript/model assertions into one controlled
   selected-source public case, or extend the corresponding current fixture;
   preserve the independent distinctions above. Existing complete public
   words/partial/search evidence remains the owner of those broader contracts.
4. Port two raw malformed socket rows into current service/transport ownership,
   using valid canonical mutation controls and persistent-state assertions.
5. Keep complete durable replay/concurrent winner/undo/restore in projects and
   cutover-state. Strengthen stale detail there if required. Do not clone their
   full edit matrix. Treat exact TIMEOUT versus discarded reply deliberately.
6. Delete operations.test.ts, old round-trip.test.ts, edit-server.mjs,
   call.mjs and speech-worker.mjs after the small ports are proven. No new legacy
   RevisionStore or unsupported artifact dispatcher is necessary.

Implementation must use test-first falsification under write-tests. This audit
has not run any candidate or survivor, and cannot certify a port's green result.
A source match justifies which gate to run; it is not that gate's outcome.
