import { resolve, dirname } from "node:path";
import { writeFile } from "node:fs/promises";
const [root, phase] = process.argv.slice(2);
// Compilation substitutes each local dist import with its owning source file.
// Workspace/package dependencies remain external; no generated bundle is executed.
const result = await Bun.build({
 entrypoints: [resolve(root, "apps/service/tests/source-lifetime.mjs"), resolve(root, "apps/macos/tests/source-processing.test.mjs"), resolve(root, "apps/macos/tests/index-scale-metrics.test.mjs"), resolve(root,"apps/macos/tests/capture-service.test.mjs"), resolve(root,"apps/macos/tests/recovery-lab.mjs")],
 target: "node", packages: "external", outdir: resolve(import.meta.dir, phase + "-output"),
 plugins: [{name: "local-source-linking", setup(build) {
   build.onResolve({filter: /\/dist\//}, args => {
    if (!args.path.startsWith(".")) return;
    const path = resolve(dirname(args.importer), args.path).replace("/dist/", "/src/").replace(/\.js$/, ".ts");
    return {path};
   });
 }}]
});
await writeFile(resolve(import.meta.dir, phase + "-linker-result.json"), JSON.stringify({success: result.success, outputs: result.outputs.map(out => ({path: out.path, bytes: out.size})), logs: result.logs.map(log => ({level: log.level, message: log.message, position: log.position}))}, null, 2));
for (const log of result.logs) console.error(String(log));
process.exitCode = result.success ? 0 : 1;
