# Boundary choices

## Sound, medium confidence

- **Use explicit project movies for the public pointer fixture.** A caller imports a captured donor, creates its own project and selects pointer processing. The fixture requests 10 fps so its existing half-second and 3.1-second pointer observations remain visible. Automatic recording audition/r0 is removed. This is a current CFR rendition decision, not a claim that old source-event sampling and new output are identical. The numerical pixel checks remain unrun here.
- **Use unity selected-source output for single acquired audio roles.** The fixture selects the real imported stream and compares its complete PCM to the authored donor. Missing captured roles remain absent facts, and an unknown stream is refused. An automatic fixed-role mix would rebuild the deleted editorial representation, so the prior missingRoles response is explicitly retired.
- **Use current project PCM as the AAC timing reference.** The movie lab keeps its independent FFmpeg AAC decode and absolute RMS<.01; lossless expected output comes from the same explicitly selected project recipe. Stereo interleaving doubles sample indices, preserving the old 500-frame excluded edges and <1024-frame tail bound per channel. This checks encoded versus lossless output, but cannot alone rule out a common composition/mux bug; the native actor's independent analytic/priming gates remain separate.

## Sound, high confidence

- **Exercise retry failure after legitimate source import, restoring exact bytes.** The public source-audio fixture first imports through the real owner, then temporarily renames its managed media and restores the exact file in finally. Catalog/address reads are not a promise of fresh media bytes. A real native failure followed by explicit retry is the observable contract; no metadata rewrite or fabricated validator is used. This native gate remains unrun.
- **Put late native acknowledgement behind the real queue cancellation.** The movie lab gates only its test worker boundary, lets the actual current movie finish, then sends public job.cancel before returning the reply. It preserves late-publication refusal on a valid explicit project. Old thousand-span workloads and source-prefix deadline planning are retired; current native cancellation/resource/finishing gates remain explicitly deferred rather than duplicated.
- **Keep one generic render lifetime.** Direct current renderers consume unchanged withRenderAttempt/withRenderedFile; obsolete withRenderedMedia and its recording plan deadline are deleted. No wrapper, configuration, endpoint, schema or new runtime owner is added.

No user-only decision is pending. The least-certain items are unexecuted CFR/pointer and numerical native fixtures; these are named future checks, not current pass claims.
