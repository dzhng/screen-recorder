# Exact caller program executed through stdin; retained for review, not rerun.
import zipfile,json,pathlib
p='/Users/david/.codex/artifacts/screen-recorder/25b-fresh-caller/primitive-fixture.zip';d=pathlib.Path('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller/bridge')
with zipfile.ZipFile(p) as z:
 m=json.loads(z.read('manifest.json'));d.joinpath('package-manifest-authority.json').write_text(json.dumps(m,indent=2));
 rows=[json.loads(z.read(f'revisions/{n}.json')) for n in range(51)];d.joinpath('package-revisions-authority.json').write_text(json.dumps(rows,indent=2));
 print('manifest keys',m.keys());print('manifest project',m.get('project'));print('rev0',rows[0]);print('rev50 keys',rows[-1].keys());print('resource selected',[r for r in m.get('resources',[]) if 'e14187038769cbe72b0f1bcef204296e96e4f908af2b96dcc708195738f735ca' in json.dumps(r)])
