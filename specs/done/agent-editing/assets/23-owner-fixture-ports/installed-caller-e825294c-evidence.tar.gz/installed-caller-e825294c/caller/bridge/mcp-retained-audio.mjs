import fs from 'node:fs';
import cp from 'node:child_process';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {syncBuiltinESMExports} from 'node:module';
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d=i.outputDirectory+'/bridge';
const originalSpawn=cp.spawn;
const exits=[];
cp.spawn=function(...args){
 const child=originalSpawn.apply(this,args);
 fs.writeFileSync(`${d}/mcp-exercise-spawn.json`,JSON.stringify({command:args[0],args:args[1],options:args[2],pid:child.pid},null,2));
 child.on('exit',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'exit'});fs.writeFileSync(`${d}/mcp-exercise-child-exits.json`,JSON.stringify(exits,null,2));});
 child.on('close',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'close'});fs.writeFileSync(`${d}/mcp-exercise-child-exits.json`,JSON.stringify(exits,null,2));});
 child.stdout?.on('data',b=>fs.appendFileSync(`${d}/mcp-exercise-stdout-wire`,b));
 child.stderr?.on('data',b=>fs.appendFileSync(`${d}/mcp-exercise-stderr-wire`,b));
 const write=child.stdin.write.bind(child.stdin);
 child.stdin.write=function(b,...rest){fs.appendFileSync(`${d}/mcp-exercise-stdin-wire`,b);return write(b,...rest);};
 return child;
};
syncBuiltinESMExports();
const {Client}=await import(`${i.sdk}/dist/esm/client/index.js`);
const {StdioClientTransport}=await import(`${i.sdk}/dist/esm/client/stdio.js`);
const transport=new StdioClientTransport({command:i.mcp.command,args:i.mcp.args,cwd:i.mcp.cwd,env:i.mcp.env});
const client=new Client({name:'fresh-independent-installed-caller',version:'1.0.0'});
async function rawCall(label,name,args){
 const request={name,arguments:args};fs.writeFileSync(`${d}/${label}.request.json`,JSON.stringify(request,null,2));
 try{const reply=await client.callTool(request);fs.writeFileSync(`${d}/${label}.reply.json`,JSON.stringify(reply,null,2));return reply;}
 catch(e){fs.writeFileSync(`${d}/${label}.error.json`,JSON.stringify({message:e.message,stack:e.stack},null,2));throw e;}
}
function envelope(r){
 if(r.structuredContent && typeof r.structuredContent.ok==='boolean')return r.structuredContent;
 for(const c of r.content??[])if(c.type==='text'){try{const x=JSON.parse(c.text);if(typeof x.ok==='boolean')return x;}catch{}}
 throw new Error('No complete JSON operation envelope found');
}

try{
 await client.connect(transport);
 fs.writeFileSync(d+'/mcp-server.json',JSON.stringify({version:client.getServerVersion(),capabilities:client.getServerCapabilities()},null,2));
 fs.writeFileSync(d+'/mcp-list-tools.request.json','{}');
 const tools=await client.listTools({});fs.writeFileSync(d+'/mcp-list-tools.reply.json',JSON.stringify(tools,null,2));
 const adopted=JSON.parse(fs.readFileSync(d+'/ready-adoption.json')).result;
 const current=envelope(await rawCall('mcp-adopted-current','revision.get',{projectId:adopted.projectId}));assert.equal(current.ok,true);assert.deepEqual(current.data,JSON.parse(fs.readFileSync(d+'/adopted-current.reply.json')).data);
 const ref=JSON.parse(fs.readFileSync(d+'/reference.json'));
 const audioReply=await rawCall('mcp-retained-source-audio','audio.get',{...ref.sourceSelection,range:{startUs:0,endUs:ref.entireSourceDurationUs}});
 const audio=envelope(audioReply);assert.equal(audio.ok,true);assert.equal(audio.data.state,'ready');
 const blocks=audioReply.content.filter(c=>c.type==='audio');let bytes;let deliveredVia;
 if(blocks.length){assert.equal(blocks.length,1);bytes=Buffer.from(blocks[0].data,'base64');deliveredVia='inline audio';}
 else{
  const lease=audio.data.delivery;assert.ok(lease?.token);let offset=0;const chunks=[];
  while(offset<lease.bytes){const part=envelope(await rawCall('mcp-source-audio-artifact-'+offset,'artifact.read',{token:lease.token,offset,maxBytes:524288}));assert.equal(part.ok,true);const body=part.data;fs.writeFileSync(d+'/mcp-source-audio-artifact-'+offset+'.envelope.json',JSON.stringify(part,null,2));const chunk=Buffer.from(body.base64??body.data??body.bytesBase64,'base64');assert.ok(chunk.length);chunks.push(chunk);offset+=chunk.length;}
  bytes=Buffer.concat(chunks);const closed=envelope(await rawCall('mcp-source-audio-close','artifact.close',{token:lease.token}));assert.equal(closed.ok,true);deliveredVia='artifact';
 }
 fs.writeFileSync(d+'/received-source-mcp.wav',bytes);
 const cliBytes=fs.readFileSync(d+'/received-source-cli.wav');assert.deepEqual(bytes,cliBytes);
 const checks={passed:true,standardUnconfiguredDefaultSDK:true,explicitSocket:false,currentRevisionUnchanged:true,bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),matchesCLIBytes:true,deliveredVia};
 fs.writeFileSync(d+'/mcp-checks.json',JSON.stringify(checks,null,2));console.log(JSON.stringify(checks,null,2));
}catch(error){fs.writeFileSync(d+'/mcp-exercise-error.json',JSON.stringify({message:error.message,stack:error.stack},null,2));console.error(error);process.exitCode=1;}
finally{await client.close();}
