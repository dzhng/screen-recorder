const fs = require('node:fs');
const cp = require('node:child_process');
const i = JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d = i.outputDirectory;
function cli(label, op, params, help = false) {
  const args = [op, ...(help ? ['--help'] : ['--params', '-'])];
  fs.writeFileSync(`${d}/${label}.command.json`, JSON.stringify({command:i.launcher,args,cwd:i.cwd,env:i.env},null,2));
  if (!help) fs.writeFileSync(`${d}/${label}.request.json`, JSON.stringify(params,null,2));
  const r = cp.spawnSync(i.launcher,args,{cwd:i.cwd,env:i.env,input:help?undefined:JSON.stringify(params),encoding:'utf8',maxBuffer:32*1024*1024});
  fs.writeFileSync(`${d}/${label}.reply.json`, r.stdout || '');
  fs.writeFileSync(`${d}/${label}.stderr`,r.stderr || '');
  fs.writeFileSync(`${d}/${label}.exit.json`,JSON.stringify({status:r.status,signal:r.signal,error:r.error?.message}));
  if (r.error) throw r.error;
  return {exit:r.status,response:JSON.parse(r.stdout)};
}
for (const op of ['project.get','revision.get','revision.history','edit.apply','asset.get','frame.get','artifact.read','artifact.renew','artifact.close']) cli(`help-${op}`,op,null,true);
for (const [label,op,params] of [
 ['prior-project','project.get',{projectId:i.projectId}],
 ['prior-revision','revision.get',{projectId:i.projectId,revisionId:i.revisionId}],
 ['prior-current','revision.get',{projectId:i.projectId}],
 ['prior-history','revision.history',{projectId:i.projectId,limit:1000}],
 ['source-header','asset.get',{assetId:i.assetId}]
]) console.log(label,JSON.stringify(cli(label,op,params)));
