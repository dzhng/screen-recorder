const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d=i.outputDirectory;
function cli(label,op,params){
 const args=[op,'--params','-'];
 fs.writeFileSync(`${d}/${label}.command.json`,JSON.stringify({command:i.launcher,args,cwd:i.cwd,env:i.env},null,2));
 fs.writeFileSync(`${d}/${label}.request.json`,JSON.stringify(params,null,2));
 const r=cp.spawnSync(i.launcher,args,{cwd:i.cwd,env:i.env,input:JSON.stringify(params),encoding:'utf8',maxBuffer:32*1024*1024});
 fs.writeFileSync(`${d}/${label}.reply.json`,r.stdout||'');fs.writeFileSync(`${d}/${label}.stderr`,r.stderr||'');
 fs.writeFileSync(`${d}/${label}.exit.json`,JSON.stringify({status:r.status,signal:r.signal,error:r.error?.message}));
 if(r.error)throw r.error;return {exit:r.status,response:JSON.parse(r.stdout)};
}
try{
 const prior=JSON.parse(fs.readFileSync(`${d}/prior-current.reply.json`)).data.revision;
 assert.equal(prior.id,i.revisionId);
 const request={projectId:i.projectId,requestId:crypto.randomUUID(),expectedRevisionId:prior.id,operations:[{operation:'split',clipIds:[i.clipId],atUs:i.splitAtUs,scope:'selected'}]};
 fs.writeFileSync(`${d}/saved-split-identity.json`,JSON.stringify(request,null,2));
 const applied=cli('split','edit.apply',request);assert.equal(applied.exit,0);assert.equal(applied.response.ok,true);
 const current=cli('post-split-current','revision.get',{projectId:i.projectId});assert.equal(current.response.ok,true);
 const revision=current.response.data.revision;
 assert.notEqual(revision.id,prior.id);assert.equal(revision.ordinal,prior.ordinal+1);
 const beforeRest={...prior.document},afterRest={...revision.document};delete beforeRest.clips;delete afterRest.clips;assert.deepEqual(afterRest,beforeRest);
 assert.equal(revision.document.clips.length,2);
 const halves=[...revision.document.clips].sort((a,b)=>a.placement.range.startUs-b.placement.range.startUs);
 assert.deepEqual(halves.map(c=>c.placement),[{kind:'project',range:{startUs:0,endUs:500000}},{kind:'project',range:{startUs:500000,endUs:1000000}}]);
 const protectedBefore={...prior.document.clips[0]};delete protectedBefore.id;delete protectedBefore.placement;
 for(const c of halves){const protectedAfter={...c};delete protectedAfter.id;delete protectedAfter.placement;assert.deepEqual(protectedAfter,protectedBefore);}
 const reread=cli('post-split-prior','revision.get',{projectId:i.projectId,revisionId:prior.id});assert.deepEqual(reread.response.data.revision,prior);
 const replay=cli('split-replay-cli','edit.apply',request);assert.equal(replay.exit,0);assert.deepEqual(replay.response.data,applied.response.data);
 const afterReplay=cli('post-cli-replay-current','revision.get',{projectId:i.projectId});assert.deepEqual(afterReplay.response.data.revision,revision);
 const stale={...request,requestId:crypto.randomUUID(),operations:[{operation:'split',clipIds:[i.clipId],atUs:250000,scope:'selected'}]};
 const refused=cli('different-stale-split','edit.apply',stale);assert.notEqual(refused.exit,0);assert.equal(refused.response.ok,false);
 const afterStale=cli('post-stale-current','revision.get',{projectId:i.projectId});assert.deepEqual(afterStale.response.data.revision,revision);
 const history=cli('post-stale-history','revision.history',{projectId:i.projectId,limit:1000});assert.equal(history.response.data.revisions.length,3);assert.equal(history.response.data.nextCursor,null);
 const source=cli('post-stale-source-header','asset.get',{assetId:i.assetId});assert.deepEqual(source.response.data,JSON.parse(fs.readFileSync(`${d}/source-header.reply.json`)).data);
 const checks={passed:true,splitRevisionId:revision.id,splitRequestId:request.requestId,splitOrdinal:revision.ordinal,protectedDocumentFields:Object.keys(beforeRest),protectedClipFields:Object.keys(protectedBefore),placementSupport:[[0,500000],[500000,1000000]],priorUnchanged:true,cliReplaySameReceipt:true,staleError:refused.response.error,staleExit:refused.exit,staleDocumentUnchanged:true,historyCount:history.response.data.revisions.length,sourceHeaderUnchanged:true};
 fs.writeFileSync(`${d}/cli-checks.json`,JSON.stringify(checks,null,2));console.log(JSON.stringify(checks,null,2));
}catch(e){fs.writeFileSync(`${d}/cli-exercise-error.json`,JSON.stringify({message:e.message,stack:e.stack},null,2));console.error(e);process.exitCode=1;}
