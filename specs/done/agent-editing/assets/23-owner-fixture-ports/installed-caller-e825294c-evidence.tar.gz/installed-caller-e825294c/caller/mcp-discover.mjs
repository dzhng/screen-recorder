import fs from 'node:fs';
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d=i.outputDirectory;
const originalSpawn=cp.spawn;
const exits=[];
cp.spawn=function(...args){
 const child=originalSpawn.apply(this,args);
 fs.writeFileSync(`${d}/mcp-discovery-spawn.json`,JSON.stringify({command:args[0],args:args[1],options:args[2],pid:child.pid},null,2));
 child.on('exit',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'exit'});fs.writeFileSync(`${d}/mcp-discovery-child-exits.json`,JSON.stringify(exits,null,2));});
 child.on('close',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'close'});fs.writeFileSync(`${d}/mcp-discovery-child-exits.json`,JSON.stringify(exits,null,2));});
 child.stdout?.on('data',b=>fs.appendFileSync(`${d}/mcp-discovery-stdout-wire`,b));
 child.stderr?.on('data',b=>fs.appendFileSync(`${d}/mcp-discovery-stderr-wire`,b));
 const write=child.stdin.write.bind(child.stdin);
 child.stdin.write=function(b,...rest){fs.appendFileSync(`${d}/mcp-discovery-stdin-wire`,b);return write(b,...rest);};
 return child;
};
syncBuiltinESMExports();
const {Client}=await import(`${i.sdk}/dist/esm/client/index.js`);
const {StdioClientTransport}=await import(`${i.sdk}/dist/esm/client/stdio.js`);
const transport=new StdioClientTransport({command:i.mcp.command,args:i.mcp.args,cwd:i.mcp.cwd,env:i.mcp.env});
const client=new Client({name:'fresh-independent-installed-caller',version:'1.0.0'});
try{
 await client.connect(transport);
 fs.writeFileSync(`${d}/mcp-discovery-server.json`,JSON.stringify({version:client.getServerVersion(),capabilities:client.getServerCapabilities()},null,2));
 const req={};fs.writeFileSync(`${d}/mcp-list-tools.request.json`,JSON.stringify(req));
 const reply=await client.listTools(req);fs.writeFileSync(`${d}/mcp-list-tools.reply.json`,JSON.stringify(reply,null,2));
 console.log(JSON.stringify(reply.tools.filter(t=>/edit.apply|revision.get|frame.get|artifact/.test(t.name)).map(t=>({name:t.name,description:t.description,inputSchema:t.inputSchema})),null,2));
}catch(error){fs.writeFileSync(`${d}/mcp-discovery-error.json`,JSON.stringify({message:error.message,stack:error.stack},null,2));process.exitCode=1;}
finally{await client.close();}
