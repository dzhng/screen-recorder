import fs from 'node:fs';
import cp from 'node:child_process';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {syncBuiltinESMExports} from 'node:module';
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d=i.outputDirectory;
const originalSpawn=cp.spawn;
const exits=[];
cp.spawn=function(...args){
 const child=originalSpawn.apply(this,args);
 fs.writeFileSync(`${d}/mcp-exercise-spawn.json`,JSON.stringify({command:args[0],args:args[1],options:args[2],pid:child.pid},null,2));
 child.on('exit',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'exit'});fs.writeFileSync(`${d}/mcp-exercise-child-exits.json`,JSON.stringify(exits,null,2));});
 child.on('close',(code,signal)=>{exits.push({pid:child.pid,code,signal,event:'close'});fs.writeFileSync(`${d}/mcp-exercise-child-exits.json`,JSON.stringify(exits,null,2));});
 child.stdout?.on('data',b=>fs.appendFileSync(`${d}/mcp-exercise-stdout-wire`,b));
 child.stderr?.on('data',b=>fs.appendFileSync(`${d}/mcp-exercise-stderr-wire`,b));
 const write=child.stdin.write.bind(child.stdin);
 child.stdin.write=function(b,...rest){fs.appendFileSync(`${d}/mcp-exercise-stdin-wire`,b);return write(b,...rest);};
 return child;
};
syncBuiltinESMExports();
const {Client}=await import(`${i.sdk}/dist/esm/client/index.js`);
const {StdioClientTransport}=await import(`${i.sdk}/dist/esm/client/stdio.js`);
const transport=new StdioClientTransport({command:i.mcp.command,args:i.mcp.args,cwd:i.mcp.cwd,env:i.mcp.env});
const client=new Client({name:'fresh-independent-installed-caller',version:'1.0.0'});
async function rawCall(label,name,args){
 const request={name,arguments:args};fs.writeFileSync(`${d}/${label}.request.json`,JSON.stringify(request,null,2));
 try{const reply=await client.callTool(request);fs.writeFileSync(`${d}/${label}.reply.json`,JSON.stringify(reply,null,2));return reply;}
 catch(e){fs.writeFileSync(`${d}/${label}.error.json`,JSON.stringify({message:e.message,stack:e.stack},null,2));throw e;}
}
function envelope(r){
 if(r.structuredContent && typeof r.structuredContent.ok==='boolean')return r.structuredContent;
 for(const c of r.content??[])if(c.type==='text'){try{const x=JSON.parse(c.text);if(typeof x.ok==='boolean')return x;}catch{}}
 throw new Error('No complete JSON operation envelope found');
}
try{
 await client.connect(transport);
 fs.writeFileSync(`${d}/mcp-exercise-server.json`,JSON.stringify({version:client.getServerVersion(),capabilities:client.getServerCapabilities()},null,2));
 const saved=JSON.parse(fs.readFileSync(`${d}/saved-split-identity.json`));
 const original=JSON.parse(fs.readFileSync(`${d}/split.reply.json`));
 const replay=envelope(await rawCall('mcp-split-replay','edit.apply',saved));assert.equal(replay.ok,true);assert.deepEqual(replay.data,original.data);
 const prior=envelope(await rawCall('mcp-prior-revision','revision.get',{projectId:i.projectId,revisionId:i.revisionId}));assert.equal(prior.ok,true);assert.deepEqual(prior.data,JSON.parse(fs.readFileSync(`${d}/prior-revision.reply.json`)).data);
 const current=envelope(await rawCall('mcp-current-revision','revision.get',{projectId:i.projectId}));assert.equal(current.ok,true);assert.deepEqual(current.data,JSON.parse(fs.readFileSync(`${d}/post-stale-current.reply.json`)).data);
 const frameReply=await rawCall('mcp-raw-source-frame','frame.get',{...i.sourceSelection,maxLongEdge:1600});
 const frame=envelope(frameReply);assert.equal(frame.ok,true);fs.writeFileSync(`${d}/mcp-raw-source-frame.envelope.json`,JSON.stringify(frame,null,2));
 assert.equal(frame.data.state,'ready');
 console.log(JSON.stringify({frame:frame.data,content:frameReply.content.map(c=>({type:c.type,mimeType:c.mimeType,encodedBytes:c.data?.length}))},null,2));
 const images=frameReply.content.filter(c=>c.type==='image');
 assert.equal(images.length,1);
 const bytes=Buffer.from(images[0].data,'base64');fs.writeFileSync(`${d}/received-raw-source.png`,bytes);
 assert.equal(bytes.length,i.preparedImage.bytes);
 const hash=crypto.createHash('sha256').update(bytes).digest('hex');assert.equal(hash,i.preparedImage.sha256);
 const token=frame.data.delivery?.token;
 if(token){
  let offset=0;const chunks=[];
  while(offset<frame.data.delivery.bytes){
   const response=envelope(await rawCall(`mcp-image-artifact-${offset}`,'artifact.read',{token,offset,maxBytes:128}));
   assert.equal(response.ok,true);
   fs.writeFileSync(`${d}/mcp-image-artifact-${offset}.envelope.json`,JSON.stringify(response,null,2));
   const payload=response.data;
   console.log('artifact fields',Object.keys(payload));
   const chunk=Buffer.from(payload.base64??payload.data??payload.bytesBase64,'base64');
   assert.ok(chunk.length>0);chunks.push(chunk);offset+=chunk.length;
  }
  const artifactBytes=Buffer.concat(chunks);fs.writeFileSync(`${d}/received-raw-source-artifact.png`,artifactBytes);assert.deepEqual(artifactBytes,bytes);
  const closed=envelope(await rawCall('mcp-image-artifact-close','artifact.close',{token}));assert.equal(closed.ok,true);
 }
 const checks={passed:true,unconfiguredDefaultSDK:true,explicitSocket:false,sameReplayReceipt:true,currentRevisionUnchanged:true,priorRevisionUnchanged:true,pngBytes:bytes.length,pngSHA256:hash,sourceSelection:i.sourceSelection,artifactReadAlsoVerified:!!token};
 fs.writeFileSync(`${d}/mcp-checks.json`,JSON.stringify(checks,null,2));console.log(JSON.stringify(checks,null,2));
}catch(error){fs.writeFileSync(`${d}/mcp-exercise-error.json`,JSON.stringify({message:error.message,stack:error.stack},null,2));console.error(error);process.exitCode=1;}
finally{await client.close();}
