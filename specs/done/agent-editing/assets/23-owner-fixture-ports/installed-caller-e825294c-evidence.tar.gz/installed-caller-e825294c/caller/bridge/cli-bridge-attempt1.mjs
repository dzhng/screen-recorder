import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const ref=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/package-bridge-reference.json'));
const d=i.outputDirectory+'/bridge';fs.mkdirSync(d,{recursive:true});
fs.writeFileSync(d+'/reference.json',JSON.stringify(ref,null,2));
fs.copyFileSync(ref.reference.path,d+'/reference-authority.wav');
const deadline=Date.parse(i.shutdownDeadlineUTC)-60000;
function cli(label,op,params,output,help=false){
 const args=[op,...(help?['--help']:['--params','-']),...(output?['--output',output]:[])];
 fs.writeFileSync(`${d}/${label}.command.json`,JSON.stringify({command:i.launcher,args,cwd:i.cwd,env:i.env},null,2));
 if(!help)fs.writeFileSync(`${d}/${label}.request.json`,JSON.stringify(params,null,2));
 const r=cp.spawnSync(i.launcher,args,{cwd:i.cwd,env:i.env,input:help?undefined:JSON.stringify(params),encoding:'utf8',maxBuffer:64*1024*1024,timeout:Math.max(1,deadline-Date.now())});
 fs.writeFileSync(`${d}/${label}.reply.json`,r.stdout||'');fs.writeFileSync(`${d}/${label}.stderr`,r.stderr||'');fs.writeFileSync(`${d}/${label}.exit.json`,JSON.stringify({status:r.status,signal:r.signal,error:r.error?.message}));
 if(r.error)throw r.error;const reply=JSON.parse(r.stdout);assert.equal(r.status,0);assert.equal(reply.ok,true);return reply.data;
}
const pause=()=>new Promise(r=>setTimeout(r,1000));
try{
 const pkg=fs.statSync(ref.package);assert.equal(pkg.size,i.separatePackageBridge.bytes);
 const hash=crypto.createHash('sha256');for await(const b of fs.createReadStream(ref.package))hash.update(b);const sha=hash.digest('hex');
 fs.writeFileSync(d+'/package-integrity-before.json',JSON.stringify({path:ref.package,bytes:pkg.size,sha256:sha},null,2));assert.equal(sha,ref.expectedPackageSHA256);
 for(const op of ['package.open','package.status','package.adopt','package.close','revision.get','revision.history','asset.get','asset.segments','audio.get'])cli(`help-${op}`,op,null,null,true);
 const opened=cli('package-open','package.open',{path:ref.package});fs.writeFileSync(d+'/open-data.json',JSON.stringify(opened,null,2));console.log('opened',JSON.stringify(opened));
 let status;for(let n=0;;n++){assert.ok(Date.now()<deadline,'Bridge deadline');status=cli(`package-status-${n}`,'package.status',{admissionId:opened.admissionId});console.log('status',JSON.stringify(status));if(status.state==='ready')break;if(['failed','canceled','closed'].includes(status.state))throw new Error('Package admission terminal '+status.state);await pause();}
 fs.writeFileSync(d+'/ready-admission.json',JSON.stringify(status,null,2));
}catch(e){fs.writeFileSync(d+'/bridge-first-stage-error.json',JSON.stringify({message:e.message,stack:e.stack},null,2));console.error(e);process.exitCode=1;}
