const fs=require('node:fs'),assert=require('node:assert/strict');
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const ref=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/package-bridge-reference.json'));
const d=i.outputDirectory+'/bridge',cli=require(d+'/cli-public.cjs');
const request=JSON.parse(fs.readFileSync(d+'/saved-adoption-identity.json'));
(async()=>{try{
 let job;for(let n=0;;n++){assert.ok(Date.now()<Date.parse(i.shutdownDeadlineUTC)-60000);job=cli(`adopt-poll-${n}`,'package.adopt',request);console.log('adoption',JSON.stringify(job));if(job.state==='ready')break;if(['failed','canceled'].includes(job.state))throw new Error('Adoption terminal '+job.state);await new Promise(r=>setTimeout(r,1000));}
 fs.writeFileSync(d+'/ready-adoption.json',JSON.stringify(job,null,2));
 const result=job.result;assert.ok(result.projectId);assert.ok(result.revisionId);
 const p=cli('adopted-project','project.get',{projectId:result.projectId});
 const current=cli('adopted-current','revision.get',{projectId:result.projectId});
 const history=cli('adopted-history','revision.history',{projectId:result.projectId,limit:1000});
 assert.equal(history.revisions.length,51);assert.equal(history.nextCursor,null);assert.equal(current.revision.id,result.revisionId);assert.equal(p.currentRevisionId,result.revisionId);
 const prior=history.revisions.filter(r=>r.id!==current.revision.id).sort((a,b)=>a.ordinal-b.ordinal).at(-1);assert.ok(prior);
 const priorRead=cli('adopted-prior','revision.get',{projectId:result.projectId,revisionId:prior.id});assert.deepEqual(priorRead.revision,prior);
 const asset=cli('adopted-voice-header','asset.get',{assetId:ref.sourceSelection.assetId});console.log('source header',JSON.stringify(asset));
 const segments=cli('adopted-voice-segments','asset.segments',{...ref.sourceSelection});console.log('source segments',JSON.stringify(segments));
 const audio=cli('source-audio-first','audio.get',{...ref.sourceSelection,range:{startUs:0,endUs:ref.entireSourceDurationUs}});console.log('source audio',JSON.stringify(audio));
 fs.writeFileSync(d+'/inspection-summary.json',JSON.stringify({project:p,currentRevision:current.revision.id,priorRevision:prior.id,historyCount:history.revisions.length,sourceHeader:asset,sourceSegments:segments,audio},null,2));
}catch(e){fs.writeFileSync(d+'/adopt-and-inspect-error.json',JSON.stringify({message:e.message,stack:e.stack},null,2));console.error(e);process.exitCode=1;}})();
