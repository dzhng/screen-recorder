const fs=require('node:fs'),cp=require('node:child_process'),assert=require('node:assert/strict');
const i=JSON.parse(fs.readFileSync('/Users/david/.cache/screen-recorder/verification/installed-caller-e825294c/caller-inputs.json'));
const d=i.outputDirectory+'/bridge';
module.exports=function cli(label,op,params,output){
 const args=[op,'--params','-',...(output?['--output',output]:[])];
 fs.writeFileSync(`${d}/${label}.command.json`,JSON.stringify({command:i.launcher,args,cwd:i.cwd,env:i.env},null,2));
 fs.writeFileSync(`${d}/${label}.request.json`,JSON.stringify(params,null,2));
 const r=cp.spawnSync(i.launcher,args,{cwd:i.cwd,env:i.env,input:JSON.stringify(params),encoding:'utf8',maxBuffer:64*1024*1024,timeout:60000});
 fs.writeFileSync(`${d}/${label}.reply.json`,r.stdout||'');fs.writeFileSync(`${d}/${label}.stderr`,r.stderr||'');fs.writeFileSync(`${d}/${label}.exit.json`,JSON.stringify({status:r.status,signal:r.signal,error:r.error?.message}));
 if(r.error)throw r.error;const reply=JSON.parse(r.stdout);assert.equal(r.status,0);assert.equal(reply.ok,true);return reply.data;
};
