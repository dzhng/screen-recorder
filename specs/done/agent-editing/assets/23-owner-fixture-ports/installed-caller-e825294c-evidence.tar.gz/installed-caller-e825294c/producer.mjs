import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { DatabaseSync } from "node:sqlite";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { lstatSync, readdirSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync, rmSync, cpSync, openSync, closeSync, existsSync } from "node:fs";
import { setTimeout as delay } from "node:timers/promises";
const bank = fileURLToPath(new URL(".", import.meta.url));
const root = "/Users/david/dev/screen-recorder";
const require = createRequire(join(root, "apps/macos/package.json"));
const { Client } = require("@modelcontextprotocol/sdk/client/index.js");
const { StdioClientTransport } = require("@modelcontextprotocol/sdk/client/stdio.js");
const save = (name, value) => writeFileSync(join(bank, name), JSON.stringify(value, null, 2));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const hashFile = (path) => sha(readFileSync(path));
const commands = [];
function run(command, args, options = {}) {
  const start = performance.now();
  const result = spawnSync(command, args, { cwd: "/", encoding: "utf8", timeout: 15000, maxBuffer: 4 * 1024 ** 2, ...options });
  commands.push({ command, args, cwd: options.cwd ?? "/", pid: result.pid, status: result.status, signal: result.signal, error: result.error?.message, ms: performance.now() - start, stdout: result.stdout, stderr: result.stderr });
  save("commands.json", commands);
  assert.equal(result.error, undefined, result.error?.message);
  assert.equal(result.status, 0, `${command}: ${result.stderr}`);
  return result.stdout;
}
function tree(path, hashAll = false) {
  const rows = [];
  if (!existsSync(path)) return rows;
  const visit = (p) => {
    const s = lstatSync(p, { bigint: true });
    if (s.isSocket() || p.endsWith("-shm")) return;
    const row = { path: p, mode: String(s.mode), inode: String(s.ino), bytes: String(s.size), mtimeNs: String(s.mtimeNs), ctimeNs: String(s.ctimeNs), kind: s.isDirectory() ? "directory" : s.isFile() ? "file" : "other" };
    if (s.isFile() && (hashAll || s.size <= 1048576n || p.endsWith(".sqlite") || p.endsWith(".sqlite-wal"))) row.sha256 = hashFile(p);
    rows.push(row);
    if (s.isDirectory()) for (const name of readdirSync(p).sort()) visit(join(p, name));
  };
  visit(path); return rows;
}
function personalSnapshot() {
  const processIdentity = run("/bin/ps", ["-p", "811,850", "-o", "pid=,ppid=,lstart=,command="]);
  assert.match(processIdentity, /811\s+1\s+.*\/Users\/david\/Applications\/Screen Recorder.app\/Contents\/MacOS\/ScreenRecorder/);
  assert.match(processIdentity, /850\s+811\s+/);
  const prefs = [];
  for (const dir of ["/Users/david/Library/Preferences", "/Users/david/Library/Preferences/ByHost"])
    for (const name of readdirSync(dir).filter((n) => n.startsWith("com.david.screenrec.personal")).sort()) prefs.push(...tree(join(dir, name), true));
  // Read the effective domain as well as on-disk files; never set or synchronize it.
  const exported = spawnSync("/usr/bin/defaults", ["export", "com.david.screenrec.personal", "-"], { encoding: "buffer", timeout: 5000 });
  assert.equal(exported.error, undefined);
  let effectivePreferences;
  if (exported.status === 0) {
    const canonical = spawnSync("/usr/bin/python3", ["-c", "import sys,plistlib,json; print(json.dumps(plistlib.loads(sys.stdin.buffer.read()),sort_keys=True,default=str,separators=(',',':')))"], { input: exported.stdout, timeout: 5000 });
    assert.equal(canonical.status, 0, canonical.stderr?.toString());
    effectivePreferences = sha(canonical.stdout);
  } else { assert.match(exported.stderr.toString(), /does not exist/); effectivePreferences = { missing: true }; }
  return { processIdentity, app: tree("/Users/david/Applications/Screen Recorder.app", true), preferences: prefs, effectivePreferences, library: tree("/Users/david/.screen-recorder") };
}
const lifecycleStarted = performance.now();
const lifecycleDeadline = Date.now() + 885000;
const report = { passed: false, claim: "Developer preparation only: private cold installed public tiny still fixture; independent caller is separate", commands: "commands.json" };
let scratch, appPid, servicePid, client, transport, before;
const processes = () => spawnSync("/bin/ps", ["-axo", "pid=,ppid=,command="], { encoding: "utf8", timeout: 3000 }).stdout.split("\n").map((line) => line.trim().match(/^(\d+)\s+(\d+)\s+(.+)$/)).filter(Boolean).map(([, pid, ppid, command]) => ({ pid: Number(pid), ppid: Number(ppid), command }));
function findOwned() {
  const rows = processes();
  const app = rows.find((p) => p.command === report.pointers?.executable);
  const service = rows.find((p) => p.command.includes(report.pointers?.service ?? "IMPOSSIBLE-OWNED-SERVICE"));
  if (app) { assert.notEqual(app.pid, 811); appPid = app.pid; }
  if (service) { assert.notEqual(service.pid, 850); assert.equal(service.ppid, appPid); servicePid = service.pid; }
  return { app, service };
}
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(read, label, ms = 15000) {
  const end = performance.now() + ms;
  for (;;) { const value = read(); if (value) return value; assert.ok(performance.now() < end, `${label}: timeout`); await delay(50); }
}
try {
  const expected = JSON.parse(readFileSync(join(bank, "candidate-before.json")));
  for (const p of expected) assert.equal(hashFile(p.path), p.sha256, p.path);
  before = personalSnapshot(); save("personal-before.json", before);
  scratch = realpathSync(mkdtempSync("/tmp/sr-caller-"));
  const home = join(scratch, "home"); mkdirSync(home, { mode: 0o700 });
  const app = join(scratch, "Applications/Screen Recorder.app"), bin = join(scratch, "bin");
  const launcher = join(bin, "screenrec"), executable = join(app, "Contents/MacOS/ScreenRecorder");
  const preferences = join(home, "preferences");
  const env = { HOME: process.env.HOME, PATH: "/usr/bin:/bin:/usr/sbin:/sbin", TMPDIR: process.env.TMPDIR ?? "/tmp", SCREENREC_HOME: home, SCREENREC_DEFAULTS: preferences, SCREENREC_SERVICE_LAUNCH: "1" };
  report.pointers = { scratch, app, bin, launcher, executable, home, preferences, service: join(app, "Contents/Resources/service/main.mjs"), native: join(app, "Contents/MacOS/screenrec-native"), expectedSocket: join(home, "run/service.sock") };
  save("pointers.json", report.pointers);
  run(process.execPath, [join(root, "scripts/install-personal.mjs"), "--app", app, "--bin", bin], { timeout: 60000 });
  const identity = run("/usr/libexec/PlistBuddy", ["-c", "Print :CFBundleIdentifier", join(app, "Contents/Info.plist")]).trim();
  assert.equal(identity, "com.david.screenrec.personal");
  run("/usr/bin/codesign", ["--verify", "--strict", app]);
  report.installedIdentity = identity;
  report.installed = tree(app, true); save("installed.json", report.installed);
  for (const rel of ["Contents/MacOS/screenrec-native", "Contents/Resources/service/main.mjs", "Contents/Resources/cli/main.mjs", "Contents/Resources/service/runtime.json"])
    assert.equal(hashFile(join(app, rel)), hashFile(join(root, "dist/ScreenRecorder.app", rel)), rel);
  for (const file of [launcher, join(app, "Contents/Resources/cli/main.mjs")]) assert.ok(!readFileSync(file, "utf8").includes(root), file);
  const clientEnv = { ...env, SCREENREC_APP: app };
  report.clientEnvironment = clientEnv;
  assert.equal(existsSync(report.pointers.expectedSocket), false);
  assert.equal(processes().some((p) => p.command === executable), false);
  const launchAt = performance.now();
  const first = JSON.parse(run(launcher, ["service.health", "--params", "{}"], { env: clientEnv, timeout: 30000 }));
  assert.equal(first.ok, true, JSON.stringify(first));
  const owned = findOwned();
  assert.ok(owned.app && owned.service, "Cold discovery must launch exact private bundle and its bundled service; no retry if LaunchServices reused personal app");
  report.appPid = appPid; report.servicePid = servicePid; report.startupMs = performance.now() - launchAt;
  report.coldProcesses = owned;
  assert.equal(first.data.pid, servicePid);
  report.coldCli = first;
  save("cold-launch.json", { operation: "service.health", cwd: "/", env: clientEnv, response: first, processes: owned, startupMs: report.startupMs });
  const exchanges = []; report.exchanges = exchanges;
  const call = (operation, params = {}, options = {}) => {
    assert.ok(alive(appPid) && alive(servicePid));
    const args = [operation, "--params", JSON.stringify(params), ...(options.output ? ["--output", options.output] : [])];
    const raw = run(launcher, args, { env: clientEnv, timeout: 30000 });
    const result = JSON.parse(raw);
    exchanges.push({ operation, params, args, raw, result }); save("preparation-exchanges.json", exchanges);
    assert.equal(result.ok, true, JSON.stringify(result)); return result.data;
  };
  const poll = async (read, ready, label) => {
    const until = performance.now() + 20000;
    for (;;) {
      const value = read();
      assert.ok(value.state !== "failed" && value.state !== "canceled", label + ": " + JSON.stringify(value));
      if (ready(value)) return value;
      assert.ok(performance.now() < until, label + ": deadline"); await delay(100);
    }
  };
  report.capture = call("capture.status"); assert.equal(report.capture.device.state, "idle");
  assert.deepEqual(call("recording.list").recordings, []);
  const source = join(root, "specs/agent-editing/assets/10d-still-image-native/sources/png-1.png");
  const accepted = join(root, "specs/agent-editing/assets/10d-still-image-native/png-1.png");
  const assetId = hashFile(source); assert.equal(assetId, "c22686998b3cf2f836f9c35bb281e3248ef38b652141591075f18d760823fe97");
  assert.equal(hashFile(accepted), "0c6b78bd6f1ef24e20f2c1cd4a8854511a7fb0be74d6f1a84c5308e7eb5b6b8d");
  const admission = call("asset.import", { requestId: "installed-caller-fixture-image", path: source });
  await poll(() => call("job.get", { jobId: admission.jobId }), (v) => v.state === "ready", "source admission");
  const asset = call("asset.get", { assetId }); assert.equal(asset.streams.length, 1);
  const selection = { assetId, streamId: asset.streams[0].id }; assert.equal(selection.streamId, "image:0");
  const created = call("project.create", { requestId: "installed-caller-fixture-project", title: "Installed caller technical fixture", canvas: { width: 160, height: 96, fps: { numerator: 30, denominator: 1 }, background: "#000000ff" } });
  const placed = call("edit.apply", { projectId: created.project.projectId, requestId: "installed-caller-fixture-placement", expectedRevisionId: created.revision.id, operations: [ { operation: "track.add", track: { kind: "video", order: 0 }, label: "picture" }, { operation: "place", label: "subject", clip: { ...selection, trackId: { label: "picture" }, source: { kind: "hold", atUs: 0 }, placement: { kind: "project", range: { startUs: 0, endUs: 1000000 } } } } ] });
  const ready = await poll(() => call("frame.get", selection), (v) => v.state === "ready", "raw source PNG");
  const reference = join(bank, "prepared-source.png");
  const delivered = call("frame.get", selection, { output: reference });
  assert.deepEqual(readFileSync(reference), readFileSync(accepted), "Prepared raw PNG must preserve accepted bytes");
  const catalog = join(home, "library/catalog.sqlite"), db = new DatabaseSync(catalog, { readOnly: true });
  report.catalog = { path: catalog, format: db.prepare("PRAGMA user_version").get().user_version }; db.close(); assert.equal(report.catalog.format, 23);
  report.fixture = { source: { path: source, sha256: assetId, bytes: readFileSync(source).length }, asset, selection, created, placed, ready, delivered, reference: { path: reference, bytes: readFileSync(reference).length, sha256: hashFile(reference) } };
  const afterPreparation = personalSnapshot(); save("personal-after-preparation.json", afterPreparation); assert.deepEqual(afterPreparation, before);
  for (const p of expected) assert.equal(hashFile(p.path), p.sha256, p.path);
  report.personalUnchangedAfterPreparation = true;
  const outputDirectory = join(bank, "caller"); mkdirSync(outputDirectory, { recursive: true });
  const technical = JSON.parse(readFileSync(join(bank, "technical-request.json")));
  const inputs = { scope: "Fresh independent installed caller; default CLI and default MCP SDK, no explicit socket", node: process.execPath, launcher, mcp: { command: launcher, args: ["mcp"], cwd: "/", env: clientEnv }, env: clientEnv, cwd: "/", sdk: "/Users/david/dev/screen-recorder/node_modules/.bun/@modelcontextprotocol+sdk@1.30.0/node_modules/@modelcontextprotocol/sdk", projectId: created.project.projectId, revisionId: placed.revision.id, clipId: placed.edit.labels.subject, trackId: placed.edit.labels.picture, assetId, streamId: selection.streamId, sourceSelection: selection, range: { startUs: 0, endUs: 1000000 }, splitAtUs: 500000, preparedImage: { ready, path: reference, bytes: readFileSync(reference).length, sha256: hashFile(reference) }, outputDirectory, consumerSkill: join(root, "skills/screenrec/SKILL.md"), technicalRequest: technical.compactRequest, separatePackageBridge: technical.separatePackageBridge, shutdownDeadlineUTC: new Date(lifecycleDeadline).toISOString(), appPid, servicePid };
  save("caller-inputs.json", inputs);
  report.prepared = true; report.preparedUTC = new Date().toISOString(); report.deadlineUTC = inputs.shutdownDeadlineUTC; save("preparation.json", report);
  console.log(JSON.stringify({ prepared: true, inputs: join(bank, "caller-inputs.json"), appPid, servicePid, deadlineUTC: inputs.shutdownDeadlineUTC }));
  let lastProgress = 0;
  while (!existsSync(join(bank, "stop"))) {
    assert.ok(alive(appPid) && alive(servicePid), "Owned installed app/service exited before caller finished");
    if (Date.now() >= lifecycleDeadline) { report.closureReason = "bounded lifecycle deadline"; break; }
    if (performance.now() - lastProgress > 30000) { console.log(JSON.stringify({ waitingForCaller: true, remainingSeconds: Math.round((lifecycleDeadline - Date.now()) / 1000) })); lastProgress = performance.now(); }
    await delay(200);
  }
  report.closureReason ??= "root stop request";
  process.kill(appPid, "SIGTERM");
  await waitFor(() => !alive(appPid), "private app drain", 15000);
  await waitFor(() => !alive(servicePid), "service child drain", 5000);
  report.ownedChildrenDrained = true;

  for (const p of expected) assert.equal(hashFile(p.path), p.sha256, p.path);
  const after = personalSnapshot(); save("personal-after.json", after); assert.deepEqual(after, before, "Personal app/library/preferences/processes must stay unchanged");
  report.personalUnchanged = true; report.candidateUnchanged = true; report.passed = true;
} catch (error) {
  report.error = { message: error.message, stack: error.stack }; process.exitCode = 1;
} finally {
  try {
    await client?.close().catch((e) => report.mcpCleanupError = e.message);
    if (report.pointers) findOwned();
    for (const [pid, expectedPath] of [[appPid, report.pointers?.executable], [servicePid, report.pointers?.service]]) {
      if (!pid || !alive(pid)) continue;
      assert.ok(pid !== 811 && pid !== 850);
      const process = processes().find((p) => p.pid === pid);
      assert.ok(process?.command.includes(expectedPath), "Cleanup must target exact private executable");
      globalThis.process.kill(pid, "SIGTERM");
      await waitFor(() => !alive(pid), "private cleanup", 5000).catch(async () => {
        globalThis.process.kill(pid, "SIGKILL");
        await waitFor(() => !alive(pid), "private kill drain", 5000);
      });
    }
    if (report.mcpPid) await waitFor(() => !alive(report.mcpPid), "MCP cleanup", 5000);
    report.ownedChildrenDrained = !appPid || (!alive(appPid) && (!servicePid || !alive(servicePid)));
    if (scratch && report.ownedChildrenDrained) {
      cpSync(join(scratch, "home"), join(bank, "retained-home"), { recursive: true, filter: (p) => !lstatSync(p).isSocket() });
      if (existsSync(join(scratch, "bin/screenrec"))) cpSync(join(scratch, "bin/screenrec"), join(bank, "installed-launcher"));
      rmSync(scratch, { recursive: true, force: true }); report.scratchRemoved = true;
    }
  } catch (error) { report.cleanupError = { message: error.message, stack: error.stack }; report.passed = false; process.exitCode = 1; }
  try {
    if (before) {
      const after = personalSnapshot(); save("personal-after.json", after);
      assert.deepEqual(after, before, "Personal app/library/preferences/processes must stay unchanged");
      report.personalUnchanged = true;
    }
  } catch (error) { report.personalProtectionError = { message: error.message, stack: error.stack }; report.passed = false; process.exitCode = 1; }
  save("report.json", report);
}
console.log(JSON.stringify({ passed: report.passed, appPid: report.appPid, servicePid: report.servicePid, error: report.error?.message, cleanupError: report.cleanupError?.message, personalProtectionError: report.personalProtectionError?.message }));
