from pathlib import Path
import json, hashlib, copy, base64, struct, zipfile, sqlite3, subprocess, os
b=Path(__file__).parent;c=b/'caller';br=c/'bridge'
def read(p):return json.loads(p.read_text())
def data(p):
 r=read(p);assert r['ok'] is True,(p,r);return r['data']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def mcp(p):
 r=read(p);texts=[json.loads(x['text']) for x in r['content'] if x['type']=='text'];assert len(texts)==1 and texts[0]==r['structuredContent'];return r,r['structuredContent']
r=read(b/'report.json');inp=read(b/'caller-inputs.json');checks=read(c/'required-request-checks.json');bridge=read(br/'bridge-checks.json')
assert r['passed'] and r['closureReason']=='root stop request' and r['ownedChildrenDrained'] and r['scratchRemoved']
assert read(b/'personal-before.json')==read(b/'personal-after-preparation.json')==read(b/'personal-after.json')
for pin in read(b/'candidate-before.json'):assert sha(Path(pin['path']))==pin['sha256']
for pin in read(b/'preparation-pins.json')['frozen']:assert sha(b/pin['path'])==pin['sha256']
prior=data(c/'prior-current.reply.json')['revision'];current=data(c/'post-split-current.reply.json')['revision'];pd=prior['document'];cd=current['document']
assert prior['id']==inp['revisionId'];assert len(pd['clips'])==1 and len(cd['clips'])==2
assert {k:v for k,v in pd.items() if k!='clips'}=={k:v for k,v in cd.items() if k!='clips'}
clip=pd['clips'][0];assert clip['id']==inp['clipId'] and clip['source']=={'kind':'hold','atUs':0}
assert cd['clips'][0]['id']==clip['id'] and cd['clips'][1]['id']!=clip['id']
for i,new in enumerate(cd['clips']):
 assert {k:v for k,v in new.items() if k not in ['id','placement']}=={k:v for k,v in clip.items() if k not in ['id','placement']}
 assert new['placement']=={'kind':'project','range':{'startUs':i*500000,'endUs':(i+1)*500000}}
assert current['ordinal']==prior['ordinal']+1==2
split=data(c/'split.reply.json');assert split['revision']==current and split==data(c/'split-replay-cli.reply.json')
assert read(c/'split.request.json')==read(c/'split-replay-cli.request.json')
assert data(c/'post-split-prior.reply.json')['revision']==prior
for name in ['post-cli-replay-current','post-stale-current']:assert data(c/(name+'.reply.json'))['revision']==current
stale=read(c/'different-stale-split.reply.json');assert stale['ok'] is False and stale['error']['code']=='STALE_REVISION'
assert read(c/'different-stale-split.request.json')['requestId']!=read(c/'split.request.json')['requestId']
assert data(c/'source-header.reply.json')==data(c/'post-stale-source-header.reply.json')
for name,expected in [('mcp-split-replay',split),('mcp-prior-revision',{'projectId':inp['projectId'],'revision':prior}),('mcp-current-revision',{'projectId':inp['projectId'],'revision':current})]:
 p=c/(name+'.reply.json')
 if not p.exists() and name=='mcp-current-revision':p=c/'mcp-current.reply.json'
 env=mcp(p)[1];assert env['ok'] and env['data']==expected,(p,env)
frame,frameEnv=mcp(c/'mcp-raw-source-frame.reply.json');png=base64.b64decode(next(x['data'] for x in frame['content'] if x['type']=='image'),validate=True)
assert png==(b/'prepared-source.png').read_bytes()==(c/'received-raw-source.png').read_bytes()
assert len(png)==329 and hashlib.sha256(png).hexdigest()=='0c6b78bd6f1ef24e20f2c1cd4a8854511a7fb0be74d6f1a84c5308e7eb5b6b8d'
assert frameEnv['data']['published']['generation']==inp['preparedImage']['ready']['published']['generation']==1
assert frameEnv['data']['jobId']==inp['preparedImage']['ready']['jobId']
optional=mcp(c/'mcp-image-artifact-0.reply.json')[1];assert optional['ok'] is False and optional['error']['code']=='ARTIFACT_EXPIRED'
package=Path(bridge['package']['path']);assert package.stat().st_size==650728645 and sha(package)==bridge['package']['sha256']=='45ae2611531762386b09b6850b8ed24061d5b6511e9f52852ef536d5ee5a5616'
assert read(br/'package-integrity-before.json')==read(br/'package-integrity-after.json')==bridge['package']
with zipfile.ZipFile(package) as z:
 manifest=json.loads(z.read('manifest.json')); originals=[json.loads(z.read(p)) for p in manifest['revisions']];resources=[json.loads(z.read(x['metadata']['path'])) for x in manifest['resources']]
assert manifest==read(br/'package-manifest-authority.json') and originals==read(br/'package-revisions-authority.json')
history=data(br/'adopted-history.reply.json');assert history['nextCursor'] is None and len(history['revisions'])==len(originals)==51
for old,new in zip(originals,history['revisions']):
 assert {k:v for k,v in old.items() if k not in ['id','projectId']}=={k:v for k,v in new.items() if k not in ['id','projectId']}
 assert old['id']!=new['id'] and old['projectId']!=new['projectId']
assert set(x['id'] for x in originals).isdisjoint(x['id'] for x in history['revisions'])
asset_checks=[]
for i,res in enumerate(sorted(resources,key=lambda r:r['asset']['id'])):
 assert res['kind']=='asset';old=res['asset'];actual=data(br/f'adopted-asset-{i}.reply.json')
 expected=copy.deepcopy(old)
 for stream in expected['streams']:
  stream['segmentCount']=len(stream.pop('segments',[]))
 assert actual==expected,(i,actual,expected)
 p=b/'retained-home/library/assets'/actual['fileName'];assert p.stat().st_size==actual['bytes'] and sha(p)==actual['id']
 asset_checks.append({'id':actual['id'],'bytes':actual['bytes'],'sha256':actual['id'],'headerEqualsPackage':True})
assert len(asset_checks)==14
assert data(br/'package-close.reply.json')['state']=='closed'
assert data(br/'after-close-adopted-project.reply.json')==data(br/'adopted-project.reply.json')
assert data(br/'protected-compact-current.reply.json')['revision']==current
blob=(b/'accepted-package-voice.wav').read_bytes();assert blob==(br/'reference-authority.wav').read_bytes()==(br/'received-source-cli.wav').read_bytes()==(br/'received-source-mcp.wav').read_bytes()
audio,audioEnv=mcp(br/'mcp-retained-source-audio.reply.json');assert base64.b64decode(next(x['data'] for x in audio['content'] if x['type']=='audio'),validate=True)==blob
assert len(blob)==88576 and hashlib.sha256(blob).hexdigest()=='e2f894f3c9479f72de6b937aadec2da8cedcd2b84aaf212a9bdb7c6bdeb23210'
assert blob[:4]==b'RIFF' and blob[8:12]==b'WAVE';pos=12;chunks={}
while pos<len(blob):
 kind=blob[pos:pos+4].decode();size=struct.unpack_from('<I',blob,pos+4)[0];chunks[kind]=blob[pos+8:pos+8+size];pos+=8+size+(size&1)
assert struct.unpack('<HHIIHH',chunks['fmt '])==(3,1,24000,96000,4,32)
assert len(chunks['data'])==84480 and hashlib.sha256(chunks['data']).hexdigest()=='b8d1ad6ac628d9d109970b36383578f7752250618da73e02c7deed1e953cc969'
cat=b/'retained-home/library/catalog.sqlite';db=sqlite3.connect('file:'+str(cat)+'?mode=ro',uri=True)
assert db.execute('pragma user_version').fetchone()[0]==23
for resource in resources:
 for stream in resource['asset']['streams']:
  segments=[json.loads(x[0]) for x in db.execute('select value from asset_segments where assetId=? and streamId=? order by ordinal',(resource['asset']['id'],stream['id']))]
  assert segments==stream.get('segments',[])
assert [json.loads(x[0]) for x in db.execute('select content from project_revisions where projectId=? order by ordinal',(inp['projectId'],))]==data(c/'post-stale-history.reply.json')['revisions']
assert len(list(db.execute('select 1 from project_revisions where projectId=?',(inp['projectId'],))))==3
requests=list(db.execute('select requestId from project_requests where projectId=?',(inp['projectId'],)));assert set(x[0] for x in requests)=={'installed-caller-fixture-placement',read(c/'split.request.json')['requestId']}
assert db.execute('select currentRevisionId from projects where projectId=?',(inp['projectId'],)).fetchone()[0]==current['id']
adoptedId=bridge['adoption']['projectId'];assert [json.loads(x[0]) for x in db.execute('select content from project_revisions where projectId=? order by ordinal',(adoptedId,))]==history['revisions']
assert db.execute('select currentRevisionId from projects where projectId=?',(adoptedId,)).fetchone()[0]==bridge['adoption']['revisionId'];db.close()
children=[]
for p in [c/'mcp-discovery-child-exits.json',c/'mcp-exercise-child-exits.json',br/'mcp-exercise-child-exits.json']:
 events=read(p);assert len(events)==2 and {e['event'] for e in events}=={'exit','close'} and all(e['code']==0 and e['signal'] is None for e in events);children.append(events[0]['pid'])
for pid in children+[r['appPid'],r['servicePid']]:
 try:os.kill(pid,0)
 except ProcessLookupError:pass
 else:raise AssertionError(f'Owned PID still live {pid}')
cli_exits=[{'path':str(p.relative_to(b)),**read(p)} for p in c.rglob('*.exit.json')]
assert all(x['signal'] is None and x['status'] in [0,1] for x in cli_exits)
nonzero=[x for x in cli_exits if x['status']!=0];assert len(nonzero)==1 and nonzero[0]['path']=='caller/different-stale-split.exit.json'
result={'passed':True,'scope':'Independent saved-data, original-byte and stopped-catalog verification; no service, native, app, rendering, playback or model rerun','compact':{'allProtectedDocumentAndClipFieldsEqual':True,'exactRequestedSplit':True,'soleCallerMutation':True,'cliAndMcpReplaySameCompleteReceipt':True,'priorRevisionUnchanged':True,'staleRefusalNoMutation':True,'sourceHeaderUnchanged':True,'pngBytes':329,'pngSHA256':hashlib.sha256(png).hexdigest(),'originalGenerationReused':True},'bridge':{'package':bridge['package'],'completeHistoryDocuments':51,'completeHistoryFieldsExceptRemappedIdsEqual':True,'assets':asset_checks,'allStoredSegmentsEqualPackage':True,'headerNormalization':'Current public header replaces optional segments with segmentCount; absent image segments mean count0, as defined by AssetStore.describe.','adoptedCatalogSurvivesClosedHandleAndServiceShutdown':True,'compactProjectUnchanged':True,'wavBytes':len(blob),'wavSHA256':hashlib.sha256(blob).hexdigest(),'pcmFrames':21120,'pcmBytes':len(chunks['data']),'pcmSHA256':hashlib.sha256(chunks['data']).hexdigest(),'sampleRate':24000,'channels':1,'exactCliMcpReferenceContainers':True,'sourceContainerBytes':84538,'sourceContainerEqualityClaim':False},'teardown':{'producer':read(b/'process.json'),'mcpChildPidsExitedAndClosed':children,'cliChildExitReceipts':len(cli_exits),'expectedStaleExit1':nonzero,'privateAppServicePidsGone':[r['appPid'],r['servicePid']],'personalBeforePreparationAfterEqual':True,'candidatePinsUnchanged':True,'scratchRemoved':True},'qualifications':['Compact caller outer exit1 is retained: optional second artifact.read used token already consumed/closed by buffered MCP delivery. Complete inline PNG was already received; no product capability refusal.','Bridge caller help-envelope assertion exit1 and incorrect admission polling143 are retained caller mistakes; later actual same admission/adoption succeeded, with no repeat package.open.','Outer caller tool-terminal authority is separate from individual CLI receipt and MCP child event authority.','No full integrated project render, listening, physical synchronization or personal app replacement claim; original650MB package remains external authority.']}
(b/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'historyDocuments':51,'assets':14,'cliExitReceipts':len(cli_exits),'mcpChildren':children,'producerExit':read(b/'process.json')['exit']}))
