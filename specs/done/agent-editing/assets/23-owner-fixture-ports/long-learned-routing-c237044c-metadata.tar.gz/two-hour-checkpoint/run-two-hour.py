import pathlib,json,subprocess,os,time,signal
b=pathlib.Path('/Users/david/.cache/screen-recorder/verification/long-learned-routing-two-hour-c237044c'); wt='/Users/david/.codex/worktrees/long-learned-routing/screen-recorder'
args=['/Users/david/.nvm/versions/node/v24.14.0/bin/node','packages/test-harness/editing/denoise-topology.mjs','--case','two-hour','--source','/Users/david/.cache/screen-recorder/verification/combined-scale-mcp-2dc8ab6e/retained-home/library/assets/7216ee4f02580d52c2ae3ce5a59588b68d4e874a8cf2053e4b61b63f782281d4.wav','--reference','/Users/david/.cache/screen-recorder/test-prerequisites/rnnoise-api-697657e249b1','--out',str(b/'two-hour')]
env=os.environ.copy();env['SCREENREC_NATIVE']='/Users/david/.cache/screen-recorder/verification/moving-pointer-preview-7f717b0d/screenrec-native';env.pop('SCREENREC_TEST_UNAVAILABLE_OPERATIONS',None);env.pop('SCREENREC_TEST_PROBE_OVERRIDES',None)
start=time.time();r={'argv':args,'cwd':wt,'worker':env['SCREENREC_NATIVE'],'start':start,'wholeCaseBoundSeconds':3600}
with (b/'two-hour.log').open('w') as log:
 p=subprocess.Popen(args,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid;(b/'dispatch.json').write_text(json.dumps(r,indent=2));
 try:r['exit']=p.wait(timeout=3600);r['timedOut']=False
 except subprocess.TimeoutExpired:
  r['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
  try:r['exit']=p.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);r['exit']=p.wait(timeout=15)
 r['seconds']=time.time()-start
 (b/'run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
