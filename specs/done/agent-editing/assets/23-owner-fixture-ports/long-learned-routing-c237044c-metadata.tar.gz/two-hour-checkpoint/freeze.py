import pathlib,json,hashlib,os,subprocess,tarfile
b=pathlib.Path(__file__).parent; w=pathlib.Path('/Users/david/.codex/worktrees/long-learned-routing/screen-recorder')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while c:=f.read(1024*1024):h.update(c)
 return h.hexdigest()
r=json.loads((b/'two-hour/report.json').read_text());run=json.loads((b/'run.json').read_text());assert r['passed'] and run['exit']==0 and not run['timedOut']
rows=json.loads((b/'before-pins.json').read_text());after=[]
for row in rows:
 p=pathlib.Path(row['path']);v={'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)};assert v==row,str(p);after.append(v)
(b/'after-pins.json').write_text(json.dumps(after,indent=2)+'\n')
s=b/'settled-sources'
for row in json.loads((b/'settled-source-pins.json').read_text()):
 p=w/row['path'];assert digest(p)==row['sha256'];q=s/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
state=r['checks']['state'];assert state['clips']==10000 and state['sampleRanges']==[{'start':0,'end':345600000}]
prepared=r['prepared']['published']['audio'];assert prepared['sampleRange']=={'start':0,'end':345600000}
assert r['source']['before']==r['source']['after'];assert not list((pathlib.Path(r['home'])/'library/render').rglob('*'))
try:os.killpg(run['pid'],0);raise AssertionError('Owned process group still exists')
except ProcessLookupError:pass
native=json.loads((b/'two-hour/native/mix-1.json').read_text());replay=json.loads((b/'two-hour/native-restart/mix-0.json').read_text());assert replay['request'].get('retained') and 'state' not in replay['request']
assert native['response']['ok'] and len(native['request']['state']['clips'])==10000
summary={'passed':True,'fixture':r['fixture'],'wholeCaseSeconds':run['seconds'],'nativeSha256':r['nativeSha256'],'referenceSha256':r['referenceSha256'],'checks':{k:v for k,v in r['checks'].items() if k in ['independentDry','independentLearned','inspection','nativePreparationPeakRSS','restart','state']},'observations':r['observations'],'source':r['source'],'processGroupGone':True,'renderStageEmpty':True,'runtimePinRowsUnchanged':len(after),'scope':'Full two-hour current learned processing on original deep/wide distributed routing; complete authored dry and frozen C wet comparison. Separate from installed acceptance, listening, diverse models, contention or disk-byte cost.'}
(b/'result-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();(b/'commit.json').write_text(json.dumps({'commit':commit,'worktree':str(w)},indent=2)+'\n')
files=[(p,'checkpoint/'+str(p.relative_to(b))) for p in sorted(b.rglob('*')) if p.is_file() and p.name!='manifest.json']
p=pathlib.Path(r['checks']['independentLearned']['file']);files.append((p,'prepared-output/'+p.name));source=pathlib.Path(r['source']['path']);files.append((source,'source/'+source.name))
manifest=[{'member':member,'bytes':p.stat().st_size,'sha256':digest(p)} for p,member in files];(b/'manifest.json').write_text(json.dumps({'payloads':manifest,'payloadCount':len(manifest)},indent=2)+'\n')
archive=b.parent/'long-learned-routing-two-hour-c237044c.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p,member in files:t.add(p,arcname=member,recursive=False)
 t.add(b/'manifest.json',arcname='checkpoint/manifest.json',recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(manifest)+1
 for row in manifest:
  h=hashlib.sha256();f=t.extractfile(row['member'])
  while c:=f.read(1024*1024):h.update(c)
  assert h.hexdigest()==row['sha256'],row['member']
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'payloadCount':len(manifest),'fileCount':len(manifest)+1,'manifestMember':'checkpoint/manifest.json','commit':commit,'verifiedAllPayloads':True,'passed':True};(b.parent/'long-learned-routing-two-hour-c237044c-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
