# Examined fixture choices

The long cohort shares the original combined graph placement rule, not its old prepared wet WAV. Sequential occurrences plus the final 32 simultaneous lanes preserve original authoring clocks; gains and 128 ancestor depth are unchanged. Independent authored Float32 dry PCM is compared in full before RNNoise, then feeds only the frozen C oracle, never native actual output.

The streaming PCM extraction is the original denoise-scale comparison owner shared with the new long cohort. It retains stereo, 960-frame compensation, full sample count and exact equality; only diagnostics and read buffers are bounded. Shared source-evidence run now owns both fixtures’ process execution. This last execution-only cleanup happened after 300 media and has a narrow helper pass, not repeated DSP proof.

A long project retained replay disables only capabilities. The mix operation stays available to consume the prepared descriptor; actual captured request must contain matching prepared fd and no fresh learned state. Short fixture asset replay remains distinct.

The first 300 failure was the independent oracle discarding an intersecting fractional terminal source cell. Project endpoints floor; source end ceil. A hand fractional case rejects the old floor, and all original failed operands remain retained. No product or threshold changed.

Full-case one-hour stop belongs to the private process-group driver; fixture phase progress remains visible. Source-work counters are decoded sample bytes, not disk-byte measurements. Native peak retains the original 4 GiB bound and cached 250-row p95 retains 250 ms. No causal speedup claim follows the observed preparation duration.
