import assert from 'node:assert/strict';
import { writeFile, readFile, readdir } from 'node:fs/promises';
import { createCompiler, validateComposition, applyBatch } from '/Users/david/dev/screen-recorder/packages/composition/dist/index.js';
import { routingTopology, longRoutingPlacements } from '/Users/david/.codex/worktrees/long-learned-routing/screen-recorder/packages/test-harness/editing/routing-topology.mjs';
const assets=[{id:'source',streams:[{id:'a',kind:'audio',bounds:{startUs:0,endUs:1000000},available:[{startUs:0,endUs:1000000}],channels:2,sampleRate:48000}]}];
const reports=[];
for(const [seconds,count] of [[300,500],[7200,10000]]){
 const at=performance.now();
 let document={canvas:{width:16,height:16,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:[],clips:[],syncGroups:[],processing:[],groups:[]};
 const top=applyBatch(document,routingTopology(128,32),{namespace:'top',assets});document=top.document;
 const placements=longRoutingPlacements(seconds,count,32);
 for(let first=0;first<count;first+=500){
  const ops=placements.slice(first,first+500).map(c=>({operation:'place',clip:{trackId:top.labels['t'+c.lane],assetId:'source',streamId:'a',source:{kind:'range',range:{startUs:0,endUs:c.endUs-c.startUs}},placement:{kind:'project',range:{startUs:c.startUs,endUs:c.endUs}}}}));
  document=applyBatch(document,ops,{namespace:'place'+first,assets}).document;
 }
 const target={kind:'group',id:top.labels.g0};
 const steps=document.processing.find(s=>s.target.kind==='group'&&s.target.id===target.id).steps;
 document=applyBatch(document,[{operation:'processing.set',target,steps:[...steps,{processor:{type:'rnnoise'}}]}],{namespace:'learned',assets}).document;
 const compiler=createCompiler(validateComposition(document,assets),'forecast');
 const window=compiler.audioWindow({range:{startUs:(seconds-1)*1e6,endUs:seconds*1e6},rendition:{sampleRate:48000,channels:2},tap:{target:{kind:'output'},point:{kind:'processed'}}});
 assert.deepEqual(window.manifest.state.domains.map(x=>x.sampleRange),[{start:0,end:seconds*48000}]);
 assert.equal(window.manifest.state.inputs.length,count);
 const state=window.audioState();
 assert.equal(state.clips.length,count);
 const root='/Users/david/.cache/screen-recorder/verification/combined-scale-mcp-2dc8ab6e/output';
 const names=(await readdir(root)).filter(n=>n.startsWith('request-'+seconds+'-place-')).sort((a,b)=>Number(a.match(/place-(\d+)/)[1])-Number(b.match(/place-(\d+)/)[1]));
 const old=[];
 for(const name of names) old.push(...JSON.parse(await readFile(root+'/'+name,'utf8')).operations);
 assert.equal(old.length,count);
 const tracks=old.slice(0,32).map(x=>x.clip.trackId);
 for(let i=0;i<count;i++){
  assert.deepEqual(old[i].clip.source,{kind:'range',range:{startUs:0,endUs:placements[i].endUs-placements[i].startUs}});
  assert.deepEqual(old[i].clip.placement,{kind:'project',range:{startUs:placements[i].startUs,endUs:placements[i].endUs}});
  assert.equal(old[i].clip.trackId,tracks[placements[i].lane]);
 }
 reports.push({seconds,count,depth:128,width:32,rootGainSteps:steps.length,lateOutputFrames:window.manifest.sampleRange.end-window.manifest.sampleRange.start,stateRanges:state.domains.map(x=>x.sampleRange),stateClipCount:state.clips.length,processingNodes:state.processing.length,serializedStateBytes:Buffer.byteLength(JSON.stringify(state)),ms:performance.now()-at,allOriginalAuthoringClocksSourcesTracksEqual:true,scope:'pure compiler forecast only; no source decode or learned DSP'});
}
await writeFile('/Users/david/.cache/screen-recorder/verification/long-learned-routing-88d09f9a/preflight.json',JSON.stringify(reports,null,2));console.log(JSON.stringify(reports));
