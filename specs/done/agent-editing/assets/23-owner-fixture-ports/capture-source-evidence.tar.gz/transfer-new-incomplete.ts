test("new incomplete allocation remains latest ahead of a finalized older take", () => {
  const { store } = fixture();
  const first = store.allocate().recording;
  store.registerSource(first.recordingId, 20);
  const second = store.allocate().recording;
  expect(store.latest()).toEqual({ ...second, sourceDurationUs: null, currentRevisionId: null });
  expect(store.get(first.recordingId)).toEqual({
    ...first,
    sourceDurationUs: 20,
    currentRevisionId: null,
  });
  expect(second.state).toBe("preparing");
  expect(second.lifecycleSequence).toBe(0);
  expect(store.isAvailable(second.recordingId)).toBe(false);
  expect(second.creationSequence).toBeGreaterThan(first.creationSequence);
});
