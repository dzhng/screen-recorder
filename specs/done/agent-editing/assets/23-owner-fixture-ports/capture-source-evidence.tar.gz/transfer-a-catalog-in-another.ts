test("a catalog in another format, or unstamped with tables, is refused without migrating its data", () => {
  const { store, path, providers } = fixture();
  const { recording } = store.allocate();
  store.registerSource(recording.recordingId, 20);
  store.close();
  const reopened = new CaptureStore(path, providers);
  expect(reopened.get(recording.recordingId).sourceDurationUs).toBe(20);
  reopened.close();
  for (const format of [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 2147483647,
  ]) {
    const other = new DatabaseSync(path);
    other.exec(`PRAGMA user_version=${format}`);
    other.close();
    const before = readFileSync(path);
    expect(() => new CaptureStore(path, providers)).toThrow(
      expect.objectContaining({ code: "UNSUPPORTED_CATALOG" }),
    );
    expect(readFileSync(path).equals(before)).toBe(true);
  }
});
