test("final deletion requires intent and rolls back if another owner retains a reference", () => {
  const { store } = fixture();
  const first = store.allocate().recording,
    sibling = store.allocate().recording;
  store.registerSource(first.recordingId, 20);
  expect(() => store.finishDeletion(first.recordingId)).toThrowError(
    expect.objectContaining({ code: "INVALID_STATE" }),
  );
  store.catalog.exec(
    "CREATE TABLE deletion_sentinel(recordingId TEXT REFERENCES recordings(recordingId))",
  );
  store.catalog.prepare("INSERT INTO deletion_sentinel VALUES(?)").run(first.recordingId);
  store.markDeleting(first.recordingId);
  expect(() => store.finishDeletion(first.recordingId)).toThrow();
  expect(store.deleting(first.recordingId)?.sourceId).toBe(first.sourceId);
  expect(store.deleting(first.recordingId)?.sourceDurationUs).toBe(20);
  store.catalog.exec("DELETE FROM deletion_sentinel");
  store.finishDeletion(first.recordingId);
  store.finishDeletion(first.recordingId);
  expect(store.deleting(first.recordingId)).toBeNull();
  expect(store.isDeleting(first.recordingId)).toBe(false);
  expect(store.get(sibling.recordingId)).toEqual(sibling);
  for (const table of ["recordings", "recording_deletions"])
    expect(
      store.catalog
        .prepare(`SELECT count(*) AS n FROM ${table} WHERE recordingId=?`)
        .get(first.recordingId),
    ).toEqual({ n: 0 });
});
