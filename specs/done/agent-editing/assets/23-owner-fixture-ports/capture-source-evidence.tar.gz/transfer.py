from pathlib import Path
import re,subprocess,json,sys
root=Path('/Users/david/dev/screen-recorder');b=Path(__file__).parent;old=(b/'library.test.ts').read_text();target=root/'packages/core/src/capture-store.test.ts'
name=sys.argv[1];matches=list(re.finditer(r'\ntest\("([^"\n]+)"',old));match=next(m for m in matches if m.group(1).startswith(name));index=matches.index(match);block=old[match.start()+1:matches[index+1].start() if index+1<len(matches) else len(old)];block=block.replace('new RevisionStore','new CaptureStore')
if name=='new incomplete':
 block=block.replace('currentRevisionId: "r0"','currentRevisionId: null').replace('  expect(second.creationSequence)', '  expect(second.state).toBe("preparing");\n  expect(second.lifecycleSequence).toBe(0);\n  expect(store.isAvailable(second.recordingId)).toBe(false);\n  expect(second.creationSequence)')
elif name=='a settled take':block=block.replace('  expect(store.revision(recordingId).sourceDurationUs).toBe(8);','  expect(settled.currentRevisionId).toBeNull();')
elif name=='a completion':block=block.replace('  expect(store.history(recordingId).revisions).toEqual([]);','  expect(store.get(recordingId).currentRevisionId).toBeNull();')
elif name=='deletion intent':
 block=block.replace('currentRevisionId: "r0"','currentRevisionId: null').replace('expect(() => reopened.revision(recording.recordingId))','expect(() => reopened.get(recording.recordingId))')
elif name=='final deletion':
 a=block.index('  const edited =');z=block.index('  expect(() => store.finishDeletion',a);block=block[:a]+block[z:]
 a=block.index('  expect(\n    store.catalog');z=block.index('  store.catalog.exec("DELETE FROM deletion_sentinel");',a);block=block[:a]+'  expect(store.deleting(first.recordingId)?.sourceDurationUs).toBe(20);\n'+block[z:]
 block=block.replace('["recordings", "revisions", "edit_requests", "undo_stack"]','["recordings", "recording_deletions"]')
elif name=='recording pages':
 block=block.replace('across new takes, edits and relaunch','across new takes, source updates and relaunch')
 a=block.index('  const edited =');z=block.index('  store.close();',a);block=block[:a]+'  store.ingestLifecycle(oldest.recordingId, { sourceId: oldest.sourceId, sequence: 1, state: "interrupted", sourceDurationUs: 20, reason: "SOURCE_LOST" });\n'+block[z:]
 block=block.replace('expect(rest.recordings[1]?.currentRevisionId).toBe(edited.id);','expect(rest.recordings[1]).toMatchObject({ state: "interrupted", sourceDurationUs: 20, currentRevisionId: null, interruptionReason: "SOURCE_LOST" });')
# Persist transferred operand before first gate; failure stops authoring next test.
(b/('transfer-'+name.replace(' ','-')+'.ts')).write_text(block)
target.write_text(target.read_text()+'\n'+block)
result=subprocess.run(['python3',str(b/'run.py'),'port-'+name.replace(' ','-'),'node_modules/.bin/vitest','run','packages/core/src/capture-store.test.ts','-t',re.escape(block.split('test("',1)[1].split('"',1)[0])],cwd=root)
sys.exit(result.returncode)
