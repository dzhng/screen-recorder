test("an event stamped with another capture session leaves the recording untouched", () => {
  const { store } = fixture();
  const first = store.allocate().recording;
  const second = store.allocate().recording;
  expect(() =>
    store.ingestLifecycle(first.recordingId, {
      sourceId: second.sourceId,
      sequence: 1,
      state: "recording",
    }),
  ).toThrow(
    expect.objectContaining({
      code: "INVALID_STATE",
      details: { sourceId: first.sourceId, reportedSourceId: second.sourceId },
    }),
  );
  expect(store.get(first.recordingId)).toEqual(first);
});
