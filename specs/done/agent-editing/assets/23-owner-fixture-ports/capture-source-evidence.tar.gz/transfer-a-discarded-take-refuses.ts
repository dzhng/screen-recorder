test("a discarded take refuses a source registered after the fact", () => {
  const { store } = fixture();
  const { recordingId, sourceId } = store.allocate().recording;
  store.ingestLifecycle(recordingId, { sourceId, sequence: 1, state: "canceled" });
  expect(() => store.registerSource(recordingId, 20)).toThrow(
    expect.objectContaining({ code: "INVALID_STATE", details: { state: "canceled" } }),
  );
  expect(store.get(recordingId)).toEqual(
    expect.objectContaining({ sourceDurationUs: null, currentRevisionId: null }),
  );
});
