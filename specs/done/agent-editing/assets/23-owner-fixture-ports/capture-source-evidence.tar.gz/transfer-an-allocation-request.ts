test("an allocation request is a durable receipt that replays and refuses different arguments", () => {
  const { store, path, providers } = fixture();
  const window = JSON.stringify(["window", 7, false]);
  const first = store.allocate({ requestId: "take-1", arguments: window });
  expect(first.replay).toBe(false);
  expect(store.allocate({ requestId: "take-1", arguments: window })).toEqual({
    recording: first.recording,
    replay: true,
  });
  // The same request ID asking for a different take is a caller mistake, not a second take.
  expect(() =>
    store.allocate({ requestId: "take-1", arguments: JSON.stringify(["window", 7, true]) }),
  ).toThrow(expect.objectContaining({ code: "REQUEST_CONFLICT" }));
  expect(store.latest()).toEqual(first.recording);
  // A request with no receipt of its own is always a fresh take.
  expect(store.allocate({ requestId: "take-2", arguments: window }).replay).toBe(false);
  expect(store.allocate().replay).toBe(false);

  const reopened = new CaptureStore(path, providers);
  stores.push(reopened);
  expect(reopened.allocate({ requestId: "take-1", arguments: window })).toEqual({
    recording: first.recording,
    replay: true,
  });
  expect(() =>
    reopened.allocate({ requestId: "take-1", arguments: JSON.stringify(["display", 1, false]) }),
  ).toThrow(expect.objectContaining({ code: "REQUEST_CONFLICT" }));
});
