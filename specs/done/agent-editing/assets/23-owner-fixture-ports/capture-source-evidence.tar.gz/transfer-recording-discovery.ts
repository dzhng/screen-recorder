test("recording discovery has an empty end page and the specified default page bound", () => {
  const { store } = fixture();
  expect(store.list()).toEqual({ recordings: [], nextCursor: null });
  const recordings = Array.from({ length: 21 }, () => store.allocate().recording);
  const first = store.list();
  expect(first.recordings).toEqual(recordings.slice(1).reverse());
  expect(store.list(first.nextCursor)).toEqual({ recordings: [recordings[0]], nextCursor: null });
  expect(() => store.list(null, 101)).toThrow(expect.objectContaining({ code: "INVALID_PARAMS" }));
});
