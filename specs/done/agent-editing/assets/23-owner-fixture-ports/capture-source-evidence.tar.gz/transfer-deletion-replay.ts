test("deletion replay pages use stable recording IDs and survive restart", () => {
  const { store, path, providers } = fixture();
  const records = Array.from({ length: 5 }, () => store.allocate().recording);
  for (const recording of [records[3]!, records[0]!, records[4]!])
    store.markDeleting(recording.recordingId);
  const expected = [records[0]!, records[3]!, records[4]!].sort((a, b) =>
    a.recordingId.localeCompare(b.recordingId),
  );
  const first = store.deletionsPage(undefined, 2);
  expect(first).toEqual({
    recordings: expected.slice(0, 2),
    nextAfterId: expected[1]!.recordingId,
  });
  store.close();
  const reopened = new CaptureStore(path, providers);
  stores.push(reopened);
  reopened.finishDeletion(expected[0]!.recordingId);
  expect(reopened.deletionsPage(first.nextAfterId!, 2)).toEqual({
    recordings: [expected[2]],
    nextAfterId: null,
  });
  expect(() => reopened.deletionsPage(undefined, 201)).toThrowError(
    expect.objectContaining({ code: "INVALID_PARAMS" }),
  );
});
