# Source-only fixture pickup

Read-only comparison at main fd6e74d7; no test run or completion claim.
Original locators are packages/core/src/library.test.ts at that commit. Current
owner is CaptureStore; ProjectStore owns all edits/history independently.

| Original line | Required retained claim | Current capture-store.test.ts correspondence |
| --- | --- | --- |
| 23 | Terminal diagnostics survive reopen, all discovery reads and duplicate sequence | Pending exact diagnostic fields/read paths; obsolete package snapshot tail belongs to retained old format only |
| 61 | New preparing allocation remains latest ahead of older finalized source | Pending; r0 changes intentionally to no recording revision |
| 291 | Preparing allocation is discoverable before native start | Pending exact sequence/latest; no revision lookup in fresh contract |
| 302 | Full pause/resume/finalize journal survives reopen and replay | Partial existing settle/reopen case line167; pause/resume sequence not covered |
| 330 | Old sequence replay preserves settled state; newer contradiction cannot alter outcome/duration | Partial existing line167 covers changed duration only; preserve full state/sequence/errors |
| 384 | Discarded capture refuses late source registration and leaves no source | Pending canceled-state guard; fresh deletion test is different fence |
| 396 | Failing lifecycle write after source attach atomically rolls back source and state | Pending; old revision insertion removed; retain actual source/state rollback and successful retry |
| 425 | Wrong source session refuses before mutation with exact source IDs | Pending |
| 444 | Never-started capture refuses direct completion; all capture facts unchanged | Pending; absence of timeline is already fresh-owner invariant |
| 466 | Canceled take leaves discovery; separate restart request creates one new id and replays | Pending discovery/restart receipts; replace obsolete edit/history refusal with actual isAvailable false |
| 504 | No-video identity/diagnostics preserved; later duration contradictions refused | Partial existing line207; exact discoverability/errors pending; obsolete edit/history queries removed |
| 555 | Repeated finalization is idempotent | Existing line167 keeps no revision/project; old exactly-one-r0 assertion obsolete |
| 589 | Stable newest-first continuation excludes later allocations across reopen | Pending; mutate lifecycle/source facts rather than restore obsolete edit interpreter |
| 624 | Empty/default-bounded/end recording pages and invalid limit | Pending |
| 634 | Allocation receipt replays and conflicts across reopen; new request creates new take | Partial line24 camera/line167 basic replay; preserve actual fresh receipts/arguments |
| 663 | Different formats and unstamped nonempty catalog refused, original bytes unchanged | Pending at actual Catalog/CaptureStore; current format22, later joint schema bump includes previous22 refusal |
| 685 | Deletion intent hides take, fences all source writes/replays, settles while preserving source duration, survives reopen | Partial line235; actual late lifecycle/registration/get/latest fences pending |
| 727 | Intent required; actual FK-held reference blocks final deletion transaction; retry deletes only named source | Partial line235 intent/sibling; real FK rollback pending; obsolete revision/edit tables not recreated |
| 768 | Deletion replay continuation is stable across removed row/reopen and invalid bound | Pending |
| 794 | Finalization error persists through reads/reopen until explicit retry or terminal result | Pending |

Do not port removed edit/history/trim/undo declarations or pretend old r0 remains.
Port one useful behavior at a time, prove deliberate defects red at its asserted
contract, keep original suite until generic claims are assigned and delete the old
interpreter/schema together with remaining consumers. This is next after focused
capture-lifetime service fixture port; no new public schema or migration here.
