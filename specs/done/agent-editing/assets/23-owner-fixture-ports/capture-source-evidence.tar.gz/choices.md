# Source-only fixture decisions

**Sound, medium confidence — actual late SQLite failure for atomic rollback.** The transferred rollback case uses a valid lifecycle report and a SQLite trigger that refuses the later state update after source duration is attached; the test checks all original capture facts remain, drops the trigger and repeats the same valid report successfully. A production rollback omission makes this exact case red. This avoids depending on malformed-value binding behavior, a fake store or a production fault hook. CaptureStore has no reason-type guard before source attachment; no earlier-validation cause is inferred. The FK deletion case similarly keeps a real reference.

**Sound, high confidence — combine already-owned source claims.** The original five tests remain. Full pause/resume journal and no-video discovery/error cases deepen existing tests; preparing discovery and creation order share one transferred case. The twenty-row map records exact counterparts; sixteen new declarations give21 total. Each added source behavior ran a focused selector; actual narrow production fault controls detect the transferred refusal, ordering, rollback and persistence claims.

**Sound, high confidence — source facts replace retired recording edits.** Discovery is tested across source lifecycle updates, later allocations and reopen. Fresh sources expect null editing identity; no r0/history/edit tables or recording package snapshot is recreated. Project editing remains outside this source fixture. The public Recording field and catalog22 remain unchanged. Original library tests stay until their separate mapped deletion.

**Rejected — preparing catalog availability equals publication readiness.** An added availability=false assertion failed because isAvailable means the row is not discarded/deleting, not that media is ready. That unrequested assertion was removed; exact preparing/latest/sequence/source facts remain. Its original red and corrected green are preserved.

No new schema, limit, production helper, retry, renderer or compatibility path was introduced.
