test("a settled take keeps its outcome when late or contradicting reports arrive", () => {
  const { store } = fixture();
  const { recordingId, sourceId } = store.allocate().recording;
  store.ingestLifecycle(recordingId, { sourceId, sequence: 4, state: "recording" });
  store.ingestLifecycle(recordingId, {
    sourceId,
    sequence: 6,
    state: "interrupted",
    reason: "service_died",
    sourceDurationUs: 8,
  });
  const settled = store.get(recordingId);
  expect(settled).toEqual(
    expect.objectContaining({
      state: "interrupted",
      interruptionReason: "service_died",
      sourceDurationUs: 8,
      lifecycleSequence: 6,
    }),
  );
  expect(
    store.ingestLifecycle(recordingId, {
      sourceId,
      sequence: 5,
      state: "complete",
      sourceDurationUs: 20,
    }),
  ).toEqual(settled);
  expect(() =>
    store.ingestLifecycle(recordingId, {
      sourceId,
      sequence: 7,
      state: "complete",
      sourceDurationUs: 20,
    }),
  ).toThrow(
    expect.objectContaining({
      code: "INVALID_STATE",
      details: { state: "interrupted", reportedState: "complete" },
    }),
  );
  expect(() =>
    store.ingestLifecycle(recordingId, {
      sourceId,
      sequence: 8,
      state: "interrupted",
      reason: "no_decodable_video",
      sourceDurationUs: null,
    }),
  ).toThrow(expect.objectContaining({ code: "INVALID_STATE", details: { sourceDurationUs: 8 } }));
  expect(store.get(recordingId)).toEqual(settled);
  expect(settled.currentRevisionId).toBeNull();
});
