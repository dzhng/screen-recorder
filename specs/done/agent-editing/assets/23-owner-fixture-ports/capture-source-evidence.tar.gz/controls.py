from pathlib import Path
import subprocess,json,re,hashlib
root=Path('/Users/david/dev/screen-recorder');b=Path(__file__).parent
cases=[
('rollback','catalog.ts',[( 'if (began) this.catalog.exec("ROLLBACK");','void began;')],['a lifecycle write that fails']),
('wrong-source','capture-store.ts',[( 'if (event.sourceId !== recording.sourceId)','if (false)')],['an event stamped']),
('invalid-state','capture-store.ts',[( 'if (!nextStates[recording.state].includes(event.state))','if (false)')],['a settled take','a completion for a take']),
('source-finality','capture-store.ts',[( 'if (recording.state === "canceled")\n      throw new CatalogError("INVALID_STATE", "A canceled take keeps no source"','if (false)\n      throw new CatalogError("INVALID_STATE", "A canceled take keeps no source"'),('if (isSettled(recording.state))\n      throw new CatalogError("INVALID_STATE", "This take already reported no usable video"','if (false)\n      throw new CatalogError("INVALID_STATE", "This take already reported no usable video"')],['a discarded take refuses','invalid source durations']),
('journal-replay','capture-store.ts',[( 'if (event.sequence <= recording.lifecycleSequence) return recording;','// Fault: do not honor already-applied journal sequences.')],['fresh capture settles']),
('creation-order','capture-store.ts',[( 'ORDER BY creationSequence DESC','ORDER BY creationSequence ASC')],['new incomplete allocation','recording pages keep','recording discovery has']),
('discovery-discard','capture-store.ts',[( "state!='canceled'",'1=1')],['a discarded take leaves discovery']),
('allocation-replay','capture-store.ts',[( 'if (stored) {','if (false) {')],['an allocation request']),
('format-refusal','catalog.ts',[( 'else if (format !== catalogFormat)','else if (false)')],['a catalog in another']),
('deletion-fence','capture-store.ts',[( 'WHERE recordingId=? AND recordingId NOT IN (SELECT recordingId FROM recording_deletions)','WHERE recordingId=?')],['deletion intent hides']),
('fk-rollback','catalog.ts',[( 'this.catalog = new DatabaseSync(path, { timeout: busyTimeoutMs });','this.catalog = new DatabaseSync(path, { timeout: busyTimeoutMs });\n    this.catalog.exec("PRAGMA foreign_keys=OFF");')],['final deletion requires']),
('deletion-continuation','capture-store.ts',[( 'WHERE recordingId>?\n      ORDER BY recordingId LIMIT ?','WHERE recordingId>=?\n      ORDER BY recordingId LIMIT ?')],['deletion replay pages']),
('error-preservation','capture-store.ts',[( 'event.finalizationError === undefined\n                  ? recording.finalizationError\n                  : event.finalizationError','null')],['finalization failure survives']),
]
results=[]
for name,file,replacements,selectors in cases:
 p=root/'packages/core/src'/file;original=p.read_bytes();mutated=original.decode()
 for before,after in replacements:
  assert before in mutated,(name,before)
  mutated=mutated.replace(before,after)
 assert mutated.encode()!=original
 try:
  p.write_text(mutated)
  pattern='|'.join(re.escape(s) for s in selectors)
  r=subprocess.run(['python3',str(b/'run.py'),'control-'+name,'node_modules/.bin/vitest','run','packages/core/src/capture-store.test.ts','-t',pattern],cwd=root)
 finally:p.write_bytes(original);assert p.read_bytes()==original
 phase=b/('control-'+name);text=(phase/'stderr').read_text();failed=re.findall(r' FAIL  packages/core/src/capture-store.test.ts > ([^\n]+)',text)
 record={'control':name,'file':str(p),'replacements':replacements,'selectors':selectors,'failedCases':failed,'exit':r.returncode,'productionRestoredSHA256':hashlib.sha256(original).hexdigest()};results.append(record);(b/'controls.json').write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode!=1 or len(failed)!=len(selectors):
  print(json.dumps({'stop':record}));raise SystemExit(2)
print(json.dumps({'controls':len(results),'allSelectedOraclesRed':True}))
