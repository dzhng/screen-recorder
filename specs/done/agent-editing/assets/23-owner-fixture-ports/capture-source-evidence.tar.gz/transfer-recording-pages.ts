test("recording pages keep newest-first identity across new takes, source updates and relaunch", () => {
  const { store, path, providers } = fixture();
  const oldest = store.allocate().recording;
  store.registerSource(oldest.recordingId, 20);
  const canceled = store.allocate().recording;
  store.ingestLifecycle(canceled.recordingId, {
    sourceId: canceled.sourceId,
    sequence: 1,
    state: "canceled",
  });
  const middle = store.allocate().recording;
  const newest = store.allocate().recording;
  const first = store.list(null, 1);
  expect(first.recordings).toEqual([newest]);
  expect(first.nextCursor).not.toBeNull();
  const added = store.allocate().recording;
  store.ingestLifecycle(oldest.recordingId, { sourceId: oldest.sourceId, sequence: 1, state: "interrupted", sourceDurationUs: 20, reason: "SOURCE_LOST" });
  store.close();
  const reopened = new CaptureStore(path, providers);
  stores.push(reopened);
  const rest = reopened.list(first.nextCursor, 2);
  expect(rest.recordings.map((recording) => recording.recordingId)).toEqual([
    middle.recordingId,
    oldest.recordingId,
  ]);
  expect(rest.recordings[1]).toMatchObject({ state: "interrupted", sourceDurationUs: 20, currentRevisionId: null, interruptionReason: "SOURCE_LOST" });
  expect(rest.nextCursor).toBeNull();
  expect(reopened.list(null, 1).recordings).toEqual([added]);
});
