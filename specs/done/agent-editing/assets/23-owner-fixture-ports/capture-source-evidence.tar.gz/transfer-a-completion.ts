test("a completion for a take that never started capturing creates no timeline", () => {
  const { store } = fixture();
  const { recordingId, sourceId } = store.allocate().recording;
  expect(() =>
    store.ingestLifecycle(recordingId, {
      sourceId,
      sequence: 1,
      state: "complete",
      sourceDurationUs: 20,
    }),
  ).toThrow(
    expect.objectContaining({
      code: "INVALID_STATE",
      details: { state: "preparing", reportedState: "complete" },
    }),
  );
  expect(store.get(recordingId)).toEqual(
    expect.objectContaining({ state: "preparing", sourceDurationUs: null, lifecycleSequence: 0 }),
  );
  expect(store.get(recordingId).currentRevisionId).toBeNull();
});
