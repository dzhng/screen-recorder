import { type FileAccess } from "./files.js";
import { type ScreenshotIndexIdentity, type RecordingIndexRecords, type ScreenshotIndexMetadata, type ScreenshotIndexEntry, type ScreenshotIndexStore } from "./screenshot-index.js";
import { ScreenshotIndexReader, type EntryQuery, type CoverageQuery, type IndexCoverage } from "./screenshot-index-read.js";
import { type TimelineRevision } from "./timeline.js";
export declare function writeScreenshotIndexPages(index: Pick<ScreenshotIndexStore<RecordingIndexRecords>, "page" | "coveragePage" | "openRead">, identity: ScreenshotIndexIdentity, revision: TimelineRevision, directory: string, signal?: AbortSignal): Promise<void>;
export declare class FileScreenshotIndex extends ScreenshotIndexReader<RecordingIndexRecords> {
    private readonly pages;
    private readonly root;
    constructor(root: string | FileAccess, identity: ScreenshotIndexIdentity, revision: TimelineRevision);
    protected readMetadata(identity: ScreenshotIndexIdentity): ScreenshotIndexMetadata<RecordingIndexRecords>;
    private portableEntry;
    protected entryRows(identity: ScreenshotIndexIdentity, query: EntryQuery): ScreenshotIndexEntry<RecordingIndexRecords>[];
    protected coverageRows(identity: ScreenshotIndexIdentity, query: CoverageQuery): IndexCoverage<RecordingIndexRecords>[];
    openRead(identity: ScreenshotIndexIdentity, ordinal: number): Readonly<{
        bytes: number;
        read(buffer: Uint8Array, position: number): number;
        release(): void;
    }>;
}
