import { evidenceIdentitySchema } from "./evidence-pages.js";
import { retainedFileRead, copyRetainedFile } from "./files.js";
import { z } from "zod";
import { createHash } from "node:crypto";
import { readSync } from "node:fs";
import { fileAccess } from "./files.js";
import { mkdir } from "node:fs/promises";
import { join } from "node:path";
import { isDeepStrictEqual } from "node:util";
import { CatalogError } from "./catalog.js";
import { selectionPolicy, validateIndexEntry, } from "./screenshot-index.js";
import { ScreenshotIndexReader, } from "./screenshot-index-read.js";
import { framePolicy } from "./frame-materialization.js";
import { scenePolicy } from "./scenes.js";
import { trailPolicy } from "./trails.js";
import { sourceToEdited } from "./timeline.js";
import { openRetainedImage } from "./retained-image.js";
import { OrderedPages, writeOrderedPages } from "./ordered-pages.js";
const integer = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER), text = z.string().min(1).max(256);
const sourceIdentity = z.strictObject({ recordingId: text, sourceId: text, generation: text });
const identitySchema = sourceIdentity
    .extend({
    revisionId: text,
    sourceIdentity: evidenceIdentitySchema,
    sceneIdentity: sourceIdentity.extend({ policy: text }),
    selectionPolicy: text,
    framePolicy: text,
    trailPolicy: text,
})
    .strip();
const metadataSchema = identitySchema.extend({
    durationUs: integer,
    candidateCount: integer,
    coverageCount: integer,
    bytes: integer,
});
const imageSchema = z.strictObject({
    file: z.string().regex(/^images\/\d+\.png$/),
    bytes: integer.min(33).max(32 * 1024 * 1024),
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
});
const range = z.strictObject({ startUs: integer, endUs: integer });
const coverageSchema = z.strictObject({
    kind: z.literal("coverage"),
    ordinal: integer,
    sequence: integer,
    source: range,
    playback: range,
    equality: z.enum(["sampled", "unproven"]),
});
function invalid(message) {
    throw new CatalogError("INVALID_EVIDENCE", message);
}
function pinned(identity) {
    return identitySchema.parse(identity);
}
function codec(revision, resolveImage) {
    return {
        metadata: metadataSchema,
        orders: { entries: 1, coverage: 1, candidateCoverage: 2 },
        decode(value, { index, metadata }) {
            if (!value || typeof value !== "object")
                invalid("Invalid retained index row");
            const row = value;
            if (index === "entries") {
                if (row.kind !== "entry" || !row.entry?.frame || "file" in row.entry.frame)
                    invalid("Portable frames require an image reference, not an original path");
                const image = imageSchema.parse(row.entry.image), frame = row.entry.frame;
                if (!Number.isSafeInteger(row.entry.candidate.ordinal) ||
                    row.entry.candidate.ordinal < 0 ||
                    row.entry.candidate.ordinal >= metadata.candidateCount ||
                    image.file !== `images/${row.entry.candidate.ordinal}.png` ||
                    image.bytes !== frame.bytes ||
                    !Number.isSafeInteger(row.entry.coverageCount) ||
                    row.entry.coverageCount < 0)
                    invalid("Invalid portable image receipt");
                if (!Number.isSafeInteger(frame.width) ||
                    frame.width < 1 ||
                    !Number.isSafeInteger(frame.height) ||
                    frame.height < 1 ||
                    frame.mediaType !== "image/png" ||
                    typeof frame.clean !== "boolean")
                    invalid("Invalid portable frame dimensions or mode");
                validateIndexEntry(metadata, revision, row.entry.candidate, { ...frame, file: resolveImage(image.file) }, resolveImage(image.file));
            }
            else {
                if (row.kind !== "coverage")
                    invalid("Wrong retained index order");
                const coverage = coverageSchema.parse(row.coverage);
                if (coverage.ordinal >= metadata.candidateCount ||
                    coverage.playback.endUs <= coverage.playback.startUs ||
                    coverage.source.endUs <= coverage.source.startUs ||
                    coverage.playback.endUs > revision.durationUs ||
                    coverage.source.endUs - coverage.source.startUs !==
                        coverage.playback.endUs - coverage.playback.startUs ||
                    sourceToEdited(revision, coverage.source.startUs) !== coverage.playback.startUs ||
                    sourceToEdited(revision, coverage.source.endUs - 1) !== coverage.playback.endUs - 1)
                    invalid("Coverage is outside the pinned revision");
            }
            return row;
        },
        key(row, index) {
            if (row.kind === "entry")
                return [row.entry.candidate.ordinal];
            return index === "candidateCoverage"
                ? [row.coverage.ordinal, row.coverage.sequence]
                : [row.coverage.sequence];
        },
    };
}
async function copyImage(index, identity, ordinal, directory, signal) {
    const source = index.openRead(identity, ordinal), file = `images/${ordinal}.png`;
    try {
        return { file, ...(await copyRetainedFile(source, join(directory, file), signal)) };
    }
    finally {
        source.release();
    }
}
export async function writeScreenshotIndexPages(index, identity, revision, directory, signal) {
    const first = index.page({ identity, limit: 1 }), metadata = first.metadata;
    if (identity.revisionId !== revision.id || metadata.durationUs !== revision.durationUs)
        invalid("Index revision does not match export");
    async function* batches(order) {
        if (order === "entries") {
            await mkdir(join(directory, "images"));
            let page = first;
            for (;;) {
                const rows = [];
                for (const entry of page.entries) {
                    const { file, ...frame } = entry.frame;
                    if (!file)
                        invalid("Retained frame has no source file");
                    rows.push({
                        kind: "entry",
                        entry: {
                            ...entry,
                            frame,
                            image: await copyImage(index, identity, entry.candidate.ordinal, directory, signal),
                        },
                    });
                }
                yield rows;
                if (page.nextOrdinal === null)
                    return;
                page = index.page({ identity, afterOrdinal: page.nextOrdinal, limit: 50 });
            }
        }
        const count = order === "coverage" ? 1 : metadata.candidateCount;
        for (let candidate = 0; candidate < count; candidate++) {
            const ordinal = order === "coverage" ? undefined : candidate;
            let afterSequence;
            for (;;) {
                const page = index.coveragePage({
                    identity,
                    ...(ordinal === undefined ? {} : { candidateOrdinal: ordinal }),
                    ...(afterSequence === undefined ? {} : { afterSequence }),
                });
                yield page.coverage.map((coverage) => ({ kind: "coverage", coverage }));
                if (page.nextSequence === null)
                    break;
                afterSequence = page.nextSequence;
            }
        }
    }
    await writeOrderedPages(directory, metadata, codec(revision, (file) => join(directory, file)), batches, signal);
}
export class FileScreenshotIndex extends ScreenshotIndexReader {
    pages;
    root;
    constructor(root, identity, revision) {
        super();
        this.root = fileAccess(root);
        this.pages = new OrderedPages(this.root, codec(revision, (file) => this.root.path(file)));
        const metadata = this.pages.metadata;
        if (metadata.selectionPolicy !== selectionPolicy.id ||
            metadata.framePolicy !== framePolicy ||
            metadata.trailPolicy !== trailPolicy.id ||
            metadata.sceneIdentity.policy !== scenePolicy.id)
            throw new CatalogError("UNSUPPORTED_POLICY", "Unsupported portable index policy");
        if (metadata.revisionId !== revision.id || metadata.durationUs !== revision.durationUs)
            invalid("Portable index requires its pinned revision");
        if (this.pages.rowCount("entries") !== metadata.candidateCount ||
            this.pages.rowCount("coverage") !== metadata.coverageCount ||
            this.pages.rowCount("candidateCoverage") !== metadata.coverageCount)
            invalid("Index page counts differ from their metadata");
        this.readMetadata(identity);
    }
    readMetadata(identity) {
        if (!isDeepStrictEqual(pinned(identity), pinned(this.pages.metadata)))
            invalid("Index identity does not match retained generation");
        return structuredClone(this.pages.metadata);
    }
    portableEntry(identity, ordinal) {
        this.readMetadata(identity);
        const row = this.pages.read({
            index: "entries",
            lower: { key: [ordinal], inclusive: true },
            upper: { key: [ordinal], inclusive: true },
            limit: 1,
        })[0];
        if (row?.kind !== "entry")
            invalid("Unknown selected image");
        return row.entry;
    }
    entryRows(identity, query) {
        this.readMetadata(identity);
        return this.pages
            .read({
            index: "entries",
            ...(query.after < 0 ? {} : { lower: { key: [query.after], inclusive: false } }),
            ...(query.through === undefined
                ? {}
                : { upper: { key: [query.through], inclusive: true } }),
            limit: query.limit,
        })
            .map((row) => {
            if (row.kind !== "entry")
                invalid("Wrong retained entry order");
            return {
                candidate: row.entry.candidate,
                frame: { ...row.entry.frame, file: this.root.path(row.entry.image.file) },
                coverageCount: row.entry.coverageCount,
            };
        });
    }
    coverageRows(identity, query) {
        this.readMetadata(identity);
        const ordinal = query.ordinal, prefix = ordinal === undefined ? [] : [ordinal];
        return this.pages
            .read({
            index: ordinal === undefined ? "coverage" : "candidateCoverage",
            ...(query.after < 0 && ordinal === undefined
                ? {}
                : { lower: { key: [...prefix, Math.max(0, query.after)], inclusive: query.after < 0 } }),
            ...(query.through === undefined && ordinal === undefined
                ? {}
                : {
                    upper: {
                        key: [...prefix, query.through ?? Number.MAX_SAFE_INTEGER],
                        inclusive: true,
                    },
                }),
            limit: query.limit,
        })
            .map((row) => {
            if (row.kind !== "coverage")
                invalid("Wrong coverage order");
            return row.coverage;
        });
    }
    openRead(identity, ordinal) {
        this.readEntry(identity, ordinal);
        const entry = this.portableEntry(identity, ordinal), { file } = openRetainedImage(this.root.open(entry.image.file), entry.frame);
        try {
            const hash = createHash("sha256"), buffer = Buffer.alloc(65536);
            for (let position = 0; position < entry.image.bytes;) {
                const bytes = readSync(file.fd, buffer, 0, Math.min(buffer.length, entry.image.bytes - position), position);
                if (!bytes)
                    invalid("Portable image ended during verification");
                hash.update(buffer.subarray(0, bytes));
                position += bytes;
            }
            if (hash.digest("hex") !== entry.image.sha256)
                invalid("Portable image differs from its receipt");
            return retainedFileRead(file, entry.image.bytes);
        }
        catch (error) {
            file.close();
            throw error;
        }
    }
}
