from pathlib import Path
import json,hashlib,subprocess,time
r=Path('/Users/david/dev/screen-recorder');b=Path(__file__).parent
read=lambda p:json.loads((b/p).read_text())
rows=[
 ('restart','Complete PNG bytes, full rows and merged coverage after catalog reopen.','source ScreenshotIndexStore'),
 ('remount','Held/read/remove after persisted device values change.','source ScreenshotIndexStore'),
 ('pages','Candidate and filtered coverage continuations, unrelated anchors, generation/reference identity.','source ScreenshotIndexStore + RetainedIndexRead'),
 ('incomplete','Partial coverage/missing retained file cannot become complete.','source ScreenshotIndexStore'),
 ('refused begin','Removal stays idempotent after refused metadata. Initial sourceId mutation hit missing scenes; final mismatched selected supportDigest reaches intended published-scenes guard.','sourceIndexDomain'),
 ('cancel','Canceled finish hides partial rows and blocks late append; owner-directed reclaim.','source ScreenshotIndexStore'),
 ('held read','FD-backed read survives removal, new read fails, exact partial read/release behavior.','source ScreenshotIndexStore'),
 ('cache','Retained PNG survives unrelated asset DerivedCache eviction; partial generation reclaim keeps chosen complete generation.','actual asset cache + source index'),
 ('replacement','Symlink/hardlink/replacement refusals with ordinary/remounted persisted devices.','source ScreenshotIndexStore'),
 ('directory','Replaced generation parent containment; original image bytes retained.','source ScreenshotIndexStore'),
 ('FIFO','Real Node child rejects substituted FIFO without blocking, exact error, 1s child bound.','actual sourceIndexDomain in child'),
 ('reclaim isolation','Damaged generation does not starve unrelated reclaim.','source ScreenshotIndexStore'),
 ('page caps','205 candidates and independent candidate/coverage default50/max200 outputs.','source ScreenshotIndexStore'),
 ('receipt authority','Former recording sourceEvidence.generation negative becomes current selected-supportDigest negative. Both bind their own current authority; not identical raw/annotation provenance semantics.','sourceIndexDomain'),
 ('compact metadata','Finish metadata works as exact admitted page/read identity; wrong implementation refuses.','sourceIndexDomain'),
 ('forgetRecording','Retired metadata-only recording-edit cleanup with removed artifact-deletion branch; no actual consumer. Canonical project/source cleanup retains reclaim/full resource ownership.','retired'),
 ('portable relocation','Former scene+index combined row split: 4 scene carriers preserved in scene-pages.test; actual staged source index has260 PNGs/520 rows, donor removed, receiver reopened, every byte/row/filter/cursor checked.','current source stagePortable + RetainedIndexRead'),
 ('portable policy/context/hash','Scene policy/context/member and matching-hash semantic/continuity rows unchanged; old recording frame/trail carrier policies retire. Current source portable hash/geometry/equality/cancel/replay/rollback/recover checks reused in existing source-index.test.','current source domains + FileSceneEvidence'),
 ('package index reader','Retired packageHandle FileScreenshotIndex representation. Same shared reader contract now binds actual adopted/source assetId+streamId+generation, filters, metadata snapshot, absent frame/read, released FD.','actual source RetainedIndexRead'),
 ('namespace','Actual asset and explicitly authored ProjectStore share controlled internal ID and attempt; asset reclaim preserves project file/rows. Crypto override only across project creation, original randomness otherwise.','actual sourceIndexDomain + projectIndexDomain'),
 ('macOS deletion restart','Fixture now seeds CaptureStore in actual library/catalog.sqlite and independent asset cache; source deletion/startup/restart/sentinels unchanged. Only syntax/default-entry compile here; actual app proof not rerun. Old recording-edit index/cache cleanup explicitly retires.','current canonical source deletion fixture'),
 ('frame scale','Old frame-cache-scale.mjs still requires a separate current native/source fixture port; untouched and not runnable proof in this wave.','pending')]
coverage={'baseCommit':'cadb2e30','rows':[{'contract':a,'disposition':c,'proof':d} for a,c,d in rows], 'counts':{'oldScreenshotDeclarations':16,'oldScreenshotExpanded':17,'currentScreenshotDeclarations':15,'currentScreenshotExpanded':16,'oldPortableDeclarations':5,'currentPortableDeclarations':1,'preservedSceneCarrierDeclarations':4,'currentAffectedCohort':42,'finalSelectedAssertions':2}}
(b/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
choices='''The least certain choice is the narrow entropy mock (medium confidence, sound). A real source and a real project need the same internal identifier to test that owner-kind participates in SQL and file keys. Only actual ProjectStore.create runs under the chosen value, restored in finally; every other crypto call delegates to the original. This does not qualify public project-ID formatting. Native ESM spy setup failed before project creation and is retained separately.

The shared test fixture uses a real imported asset, acquisitions, scene store and sourceIndexDomain with controlled held-sample receipts (high confidence, sound). The two generic suites need identical admitted metadata; sharing those facts avoids maintaining a synthetic IndexDomain. The toy MOV bytes and valid fixed PNG prove ownership/format/lifetime, not decoder or image quality.

Portable source index proof uses the current stagePortable/adopted managed store and shared RetainedIndexRead (high confidence, sound). A donor is removed and a receiver reopened before all260 PNGs and520 coverage rows are read. Keeping FileScreenshotIndex just for tests would preserve a second unconsumed format. The four independent scene carrier contracts remain in their natural scene-pages test owner because event-pages still consumes that source carrier; their recording-backed CaptureStore facts are legitimate source provenance.

Receipt authority is deliberately current selected supportDigest, not old recording evidence generation (high confidence, sound). A source frame no longer reports recording annotations; recreating those fields would be a compatibility model. The same invalid receipt/refused-begin behavior now tests the actual admitted source support, with the old semantics and first earlier missing-scene fixture failure explicitly dispositioned.

Unused metadata-only forgetOwner and hasGenerations are deleted (high confidence, sound). No actual caller survives the canonical source deletion port. Current resource-owning reclamation remains; recreating a recording deletion domain only to retain its obsolete helper would duplicate ownership.

macOS deletion remains a mechanical current-owner fixture port with syntax/default-entry compile scope, while frame-cache-scale remains pending (high confidence, sound). A native/media run would exceed this wave's question; these limits prevent a fixture compile from becoming an installed/restart/performance claim.

No new production cache, domain, endpoint, flag, schema, format, capacity or numerical algorithm was chosen. No unresolved user-only decision. Root owns global docs and next native fixture disposition.
'''
(b/'choices.md').write_text(choices)
review='''Review is clean within the declared scope. Shape: one generic ScreenshotIndexStore and actual source/project domains remain; orphan recording specialization and standalone index carrier are deleted, no adapter/synthetic domain. Generic class bytes are exact after the named method deletions and recording-only path conditional removal; frozen selectionPolicy is exact. The new fixture is test-only under existing tsconfig exclusion.

Diff: old generic file/FD/FIFO/remount/reclaim/page bounds are present on actual source facts; equal-ID owner-kind isolation is retained on actual ProjectStore; portable relocation checks every260 PNG and520 rows plus current reference/cursor/read lifetime. Four scene carrier oracles retained with CaptureStore rather than edit state. No dead-generation semantic claim is disguised as source provenance parity. Production data format/catalog and source/project numerical paths are unchanged.

Proof: baseline22; current affected42 before formatting and two union-aware assertion corrections; final selected2 on those corrections. Remaining changes from42 are formatting, plus unreferenced macOS PNG-constant removal. Full proof-to-final diff is retained. Core/service builds/types, harness types, lint/format and actual default-entry Bun bundle passed. MacOS fixture syntax only, no app/native execution. No cohort rerun, capture/model/media/installed switch; frame-cache-scale and event/scene carrier closure remain named.

Docs: no code-owner prose needs duplication. Global status, remaining graph and native fixture limitations are parent-owned. Private coverage/choices/report provide one source of the exact mapping and evidence. Removed symbols have no live source consumers; known two orphan dist emits removed only after preservation.

Independent Codex CLI 400 failure is already banked and parent explicitly forbids retry; self review and parent review apply.
'''
(b/'review.md').write_text(review)
phases=read('phases.json')
report={'kind':'generic-index-owner-purge','baseCommit':'cadb2e30','status':'focused current consumer proof; native fixture execution pending','created':time.time(),'scope':['generic ScreenshotIndexStore source/project','current portable source index','independent source scene carrier oracles','macOS deletion fixture compile'],'coverage':'coverage.json','choices':'choices.md','review':'review.md','finalPins':'final-pins.json','phases':'phases.json','proofToFinal':'proof-final-differences.json','parity':'consumer-sweep.json','failureClassification':{'source-retention-file':'fixture authority mutation reaches earlier scene-completeness guard; corrected supportDigest negative','current-portable-first':'missing CaptureStore interrupted reason; canonical temp address alias expectation; no product defect','current-namespace-first':'native ESM namespace spy not configurable before project creation','core-types-first':'two test-only discriminated union accesses corrected to assert available state'},'checks':[{'phase':x['name'],'pid':x['terminal']['pid'],'exit':x['terminal']['exit'],'waited':x['terminal']['waited'],'deadlineExpired':x['terminal']['deadlineExpired']} for x in phases],'proofCounts':coverage['counts'],'limits':['controlled metadata/valid fixed PNG receipts, not native decode/pixel quality','current42 earlier source; final2 corrected assertion source; full diff retained','default service compiled/bundled, not launched','macOS deletion syntax only; frame-cache-scale untouched pending','no full suite, native/model/media/capture/UI or installed adoption','catalog format/schema/recovery unaffected'],'archiveExclusion':{'path':'default-entry/main.mjs','reason':'actual bundle retained privately; scalar hash in final-pins, no duplicate large emit in archive'}}
(b/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Wrote report, full coverage dispositions, choices and review.')
