from pathlib import Path
import json,subprocess,time,hashlib,sys
bank=Path('/Users/david/.cache/screen-recorder/verification/movie-audio-support-a6f96205');wt=Path('/Users/david/.codex/worktrees/movie-audio-support/screen-recorder');root=Path('/Users/david/dev/screen-recorder');build=wt/'helpers/mac/.build/mux'/sys.argv[1];stage=bank/(sys.argv[1]+'-helper-linked');stage.mkdir()
a=json.loads((bank/sys.argv[1]/'link.json').read_text())['argv'];i=a.index('-alias')-1;del a[i:i+6];a[a.index('-module-name')+1]='ScreenRecorderCompositionVideoTests';a[a.index('-o')+1]=str(build/'ScreenRecorderCompositionVideoTests')
objects=[x for x in (build/'Objects.LinkFileList').read_text().splitlines() if '/ScreenRecorderNative.build/' not in x];obj=stage/'objects.txt';obj.write_text('\n'.join(objects));a=[('@'+str(obj)) if x.startswith('@') and x.endswith('Objects.LinkFileList') else x for x in a];sources=sorted((wt/'helpers/mac/Tests/CompositionVideo').glob('*.swift'));a.extend(map(str,sources));a.extend(['-I',str(build/'Modules'),'-I',str(root/'helpers/mac/.build/arm64-apple-macosx/debug/Modules'),'-module-cache-path',str(wt/'helpers/mac/.build/mux/bound-iso-tail/ModuleCache')])
def pin(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(stage/'sources.json').write_text(json.dumps([pin(p) for p in sources],indent=2))
for p in sources:(stage/p.name).write_bytes(p.read_bytes())
c=json.loads((bank/sys.argv[1]/'compile.json').read_text())['argv']
for i,x in enumerate(c):
 if x == '-Xcc':a.extend([x,c[i+1]])
start=time.time()
with (stage/'stdout').open('wb') as out,(stage/'stderr').open('wb') as err:
 p=subprocess.Popen(a,stdout=out,stderr=err);r={'argv':a,'pid':p.pid,'start':start};(stage/'process.json').write_text(json.dumps(r,indent=2));print('helper compile PID',p.pid,flush=True)
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:p.kill();code=p.wait();r['timeout']=True
r.update(exitCode=code,end=time.time());(stage/'process.json').write_text(json.dumps(r,indent=2));print('exit',code,flush=True);print((stage/'stderr').read_text()[-4000:]);sys.exit(code)
