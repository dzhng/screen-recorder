from pathlib import Path
import struct,shutil,json,hashlib,time
b=Path('/Users/david/.cache/screen-recorder/verification/movie-audio-support-a6f96205');case=b/'empty-edit-trial';case.mkdir();src=Path('/var/folders/3p/k21gnpt573b8yy45xvy27nd00000gn/T/sr-composition-movie-DDSfBV/movie-2.mp4');dst=case/'movie.mp4';shutil.copyfile(src,dst)
def parts(d):
 p=0
 while p<len(d):
  n,t=struct.unpack_from('>I4s',d,p);h=8
  if n==1:n=struct.unpack_from('>Q',d,p+8)[0];h=16
  if not n:n=len(d)-p
  assert n>=h and p+n<=len(d)
  yield t,d[p+h:p+n],d[p:p+n];p+=n
 assert p==len(d)
def atom(t,d):return struct.pack('>I4s',len(d)+8,t)+d
def descendant(d,t):return next(x for k,x,_ in parts(d) if k==t)
with dst.open('r+b') as f:
 end=f.seek(0,2);p=0;moov=None;mdat=[]
 while p<end:
  f.seek(p);raw=f.read(8);n,t=struct.unpack('>I4s',raw);h=8
  if n==1:n=struct.unpack('>Q',f.read(8))[0];h=16
  if not n:n=end-p
  assert n>=h and p+n<=end
  if t==b'moov':assert moov is None;moov=(p,h,f.read(n-h))
  if t==b'mdat':mdat.append((p+h,n-h))
  p+=n
 assert moov is not None
 offset,header,data=moov;mvhd=descendant(data,b'mvhd');off=20 if mvhd[0]==1 else 12;scale=struct.unpack_from('>I',mvhd,off)[0];duration=int.from_bytes(mvhd[off+4:off+4+(8 if mvhd[0] else 4)],'big');assert scale==6000000 and duration==600120
 new=[];changed=0
 for t,d,raw in parts(data):
  if t!=b'trak':new.append(raw);continue
  mdia=descendant(d,b'mdia');handler=descendant(mdia,b'hdlr')[8:12]
  if handler!=b'soun':new.append(raw);continue
  track=[]
  for typ,body,r in parts(d):
   if typ==b'tkhd':
    x=bytearray(body);o=28 if x[0] else 20;size=8 if x[0] else 4;x[o:o+size]=duration.to_bytes(size,'big');r=atom(typ,x)
   elif typ==b'edts':
    children=[]
    for tag,x,rr in parts(body):
     if tag==b'elst':
      assert x[0] in [0,1];width=8 if x[0] else 4;stride=20 if x[0] else 12;count=struct.unpack_from('>I',x,4)[0];assert len(x)==8+count*stride;total=sum(int.from_bytes(x[8+i*stride:8+i*stride+width],'big') for i in range(count));assert total==600000
      x=x[:4]+struct.pack('>I',count+1)+x[8:]+(duration-total).to_bytes(width,'big')+(-1).to_bytes(width,'big',signed=True)+struct.pack('>hh',1,0);rr=atom(tag,x);changed+=1
     children.append(rr)
    r=atom(typ,b''.join(children))
   track.append(r)
  new.append(atom(t,b''.join(track)))
 assert changed==1
 f.seek(0,2);f.write(atom(b'moov',b''.join(new)));f.seek(offset+4);f.write(b'free');f.flush()
def payload(path):
 out=[]
 with path.open('rb') as f:
  for pos,size in mdat:
   f.seek(pos);h=hashlib.sha256();left=size
   while left:
    chunk=f.read(min(left,65536));assert chunk;left-=len(chunk);h.update(chunk)
   out.append({'offset':pos,'bytes':size,'sha256':h.hexdigest()})
 return out
facts={'input':str(src),'output':str(dst),'movieTicks':duration,'timescale':scale,'audioEdits':[600000,120],'beforePayload':payload(src),'afterPayload':payload(dst)};assert facts['beforePayload']==facts['afterPayload'];(case/'facts.json').write_text(json.dumps(facts,indent=2));print(json.dumps(facts,indent=2))
