import AVFoundation
import Foundation
@main struct Probe {
 static func main() async throws {
  let input = URL(fileURLWithPath: CommandLine.arguments[1])
  let output = URL(fileURLWithPath: CommandLine.arguments[2])
  try FileManager.default.copyItem(at: input, to: output)
  let movie = AVMutableMovie(url: output)
  print("types", AVMovie.movieTypes().map { $0.rawValue })
  guard AVMovie.movieTypes().contains(.mp4) else { fatalError("MP4 header unsupported") }
  let tracks = try await movie.loadTracks(withMediaType: .audio)
  guard let track = tracks.first else { fatalError("Missing mutable sound track") }
  let range = try await track.load(.timeRange)
  let end = CMTime(value: 100020, timescale: 1000000)
  print("before", range.end.value, range.end.timescale)
  track.insertEmptyTimeRange(CMTimeRange(start: range.end, duration: CMTimeSubtract(end, range.end)))
  try movie.writeHeader(to: output, fileType: .mp4, options: .addMovieHeaderToDestination)
  print("wrote", output.path)
 }
}
