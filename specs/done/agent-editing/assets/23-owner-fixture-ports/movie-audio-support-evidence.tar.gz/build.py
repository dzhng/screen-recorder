from pathlib import Path
import hashlib,json,os,subprocess,time,sys
root=Path('/Users/david/dev/screen-recorder');wt=Path('/Users/david/.codex/worktrees/movie-audio-support/screen-recorder');bank=Path('/Users/david/.cache/screen-recorder/verification/movie-audio-support-a6f96205')
case=sys.argv[1];stage=bank/case;stage.mkdir();build=wt/'helpers/mac/.build/mux'/case;build.mkdir(parents=True)
manifest=json.loads(Path('/Users/david/.codex/artifacts/screen-recorder/current-native-workers/479676ca8fde43b0ae44bc308a4e71fd84f3e6a80c3e51f317253ebb5a3cdd8d/manifest.json').read_text())
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for rel,sha in manifest['nativeSourcePins'].items():
 if rel.startswith('helpers/mac/Sources/') and rel!='helpers/mac/Sources/ScreenRecorderWire/MovieMux.swift':assert pin(wt/rel)['sha256']==sha,(rel,'WT dependency source differs')
lines=(root/'helpers/mac/.build/debug.yaml').read_text().splitlines();commands=[json.loads(x.strip()[6:]) for x in lines if x.strip().startswith('args: [')]
a=next(x for x in commands if '-module-name' in x and x[x.index('-module-name')+1]=='ScreenRecorderWire')
link=next(x for x in commands if '-o' in x and x[x.index('-o')+1].endswith('/screenrec-native'))
base=root/'helpers/mac/.build/arm64-apple-macosx/debug';wire=build/'ScreenRecorderWire.build';wire.mkdir();modules=build/'Modules';modules.mkdir()
def outpath(v):return v.replace(str(base/'ScreenRecorderWire.build'),str(wire)).replace(str(base/'Modules/ScreenRecorderWire'),str(modules/'ScreenRecorderWire'))
fm=json.loads((base/'ScreenRecorderWire.build/output-file-map.json').read_text());fm={k.replace(str(root),str(wt)):{x:outpath(v) for x,v in values.items()} for k,values in fm.items()};(wire/'output-file-map.json').write_text(json.dumps(fm))
sources=sorted((wt/'helpers/mac/Sources/ScreenRecorderWire').glob('*.swift'));
for s in sources:
 if str(s) not in fm:fm[str(s)]={'object':str(wire/(s.name+'.o')),'dependencies':str(wire/(s.stem+'.d')),'swift-dependencies':str(wire/(s.stem+'.swiftdeps')),'diagnostics':str(wire/(s.stem+'.dia'))}
(wire/'output-file-map.json').write_text(json.dumps(fm));(wire/'sources').write_text('\n'.join(map(str,sources)))
a=[outpath(x) for x in a if x!='-incremental'];a[a.index('-module-cache-path')+1]=str(wt/'helpers/mac/.build/mux/bound-iso-tail/ModuleCache');a[a.index('-index-store-path')+1]=str(build/'index');a=[x.replace('-j18','-j4') for x in a]
objs=[Path(x) for x in (base/'screenrec-native.product/Objects.LinkFileList').read_text().splitlines()];unchanged=[p for p in objs if p.parent!=base/'ScreenRecorderWire.build'];pins=[pin(p) for p in unchanged]+[pin(p) for p in (base/'Modules').glob('*.swiftmodule') if p.name!='ScreenRecorderWire.swiftmodule'];(stage/'dependency-before.json').write_text(json.dumps(pins,indent=2));(stage/'sources.json').write_text(json.dumps([pin(p) for p in sources],indent=2));(stage/'MovieMux.swift').write_bytes((wt/'helpers/mac/Sources/ScreenRecorderWire/MovieMux.swift').read_bytes())
link=[outpath(x) for x in link];link[link.index('-o')+1]=str(build/'screenrec-native');objectlist=build/'Objects.LinkFileList';objectlist.write_text('\n'.join([outpath(str(p)) for p in objs]+[str(wire/(s.name+'.o')) for s in sources if not (base/'ScreenRecorderWire.build'/(s.name+'.o')).exists()]));link=[('@'+str(objectlist)) if x.startswith('@') and x.endswith('Objects.LinkFileList') else x for x in link]
def run(name,argv,timeout):
 start=time.time()
 with (stage/(name+'.stdout')).open('wb') as out,(stage/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=wt,stdout=out,stderr=err);r={'argv':argv,'pid':p.pid,'start':start};(stage/(name+'.json')).write_text(json.dumps(r,indent=2));print(name,'PID',p.pid,flush=True)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:p.kill();code=p.wait();r['timeout']=True
 r.update(exitCode=code,end=time.time(),seconds=time.time()-start);(stage/(name+'.json')).write_text(json.dumps(r,indent=2));print(name,'exit',code,flush=True)
 if code:print((stage/(name+'.stderr')).read_text()[-2500:]);sys.exit(1)
run('compile',a,150);run('link',link,30);run('sign',['/usr/bin/codesign','--force','--sign','-','--entitlements',str(root/'helpers/mac/.build/arm64-apple-macosx/debug/screenrec-native-entitlement.plist'),str(build/'screenrec-native')],10)
assert pins==[pin(Path(p['path'])) for p in pins],'Immutable dependency changed';(stage/'dependency-after.json').write_text(json.dumps(pins,indent=2));(stage/'worker.json').write_text(json.dumps(pin(build/'screenrec-native'),indent=2));print('worker',build/'screenrec-native',flush=True)
