# Review

Shape: one Wire-private finalizer called by the existing MovieMux finishing owner; no public API, wrapper, dependency, PCM writer or movie decoder. Its fixed-depth bounded header logic is separate from the existing streaming pumps.

Diff: exact sub-sample arithmetic, positive-size/unique clock/edit grammar, overflow and cancellation gates reviewed. The descriptor prevents the newly introduced finalization write from following a changed locator. Generated EOF acceptance mutation demonstrably breaks the refusal oracle. Independent peer review found no numerical/parser issue; inherited NewFile directory replacement cleanup and later publication reopen are explicitly outside the proven sentinel case.

Docs: native README states why container support can outlast floored PCM and points to the finalizer, without duplicating its grammar. Root-owned specification and global evidence remain untouched.

Checks: public tiny old worker red; final tiny green; affected existing small composition cohort green, with all original picture/AAC/poison/settings/collision/cancellation gates. Source/compiler/objects before-after bindings retained. JavaScript final formatting normalizes byte-identically from the executed source. Known Codex CLI unsupported-account/model limitation is already banked; no retry or model override. Long scale remains the next root-owned gate.
