from pathlib import Path
import hashlib,json,os,subprocess,time,sys
wt=Path('/Users/david/.codex/worktrees/movie-audio-support/screen-recorder');bank=Path('/Users/david/.cache/screen-recorder/verification/movie-audio-support-a6f96205');phase=bank/sys.argv[1];phase.mkdir();worker=Path(sys.argv[2]);producer=wt/'packages/test-harness/editing/composition-movie.mjs'
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
inputs=[producer,worker,wt/'helpers/mac/Sources/ScreenRecorderWire/MovieMux.swift',wt/'specs/agent-editing/assets/00-corpus/a.mov',Path('/Users/david/.cache/screen-recorder/verification/movie-audio-support-a6f96205/inspect-empty-aware')];before=[pin(p) for p in inputs];(phase/'before.json').write_text(json.dumps(before,indent=2));(phase/'executed-producer.mjs').write_bytes(producer.read_bytes())
env=os.environ|{'SCREENREC_NATIVE':str(worker),'SCREENREC_MOVIE_INSPECT':str(inputs[-1]),'SCREENREC_KEEP_TEST_FILES':'1'};argv=['/Users/david/.nvm/versions/node/v24.14.0/bin/node',str(producer),'--fractional-tail'];start=time.time()
with (phase/'stdout.log').open('wb') as out,(phase/'stderr.log').open('wb') as err:
 p=subprocess.Popen(argv,cwd=wt,env=env,stdout=out,stderr=err);r={'argv':argv,'pid':p.pid,'start':start};(phase/'process.json').write_text(json.dumps(r,indent=2));print(sys.argv[1],'PID',p.pid,flush=True)
 try:code=p.wait(timeout=90)
 except subprocess.TimeoutExpired:p.kill();code=p.wait();r['timeout']=True
r.update(exitCode=code,end=time.time(),seconds=time.time()-start);(phase/'process.json').write_text(json.dumps(r,indent=2));after=[pin(p) for p in inputs];(phase/'after.json').write_text(json.dumps(after,indent=2));assert before==after
print('exit',code,flush=True);print((phase/'stderr.log').read_text()[-2200:]);print((phase/'stdout.log').read_text()[-1400:])
