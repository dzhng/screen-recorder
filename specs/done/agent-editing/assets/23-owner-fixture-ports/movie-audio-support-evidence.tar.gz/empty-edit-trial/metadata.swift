import AVFoundation
import Foundation
@main struct Metadata {
 static func time(_ t: CMTime) -> [String: Any] { ["value": t.value, "timescale": t.timescale, "flags": t.flags.rawValue] }
 static func main() async throws {
  let asset = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]))
  let wanted = CMTime(value: 100020, timescale: 1000000)
  let duration = try await asset.load(.duration)
  precondition(CMTimeCompare(duration, wanted) == 0)
  var rows: [[String: Any]] = []
  for track in try await asset.load(.tracks) {
   let range = try await track.load(.timeRange)
   precondition(CMTimeCompare(range.duration, wanted) == 0)
   let segments = try await track.load(.segments)
   rows.append(["type": track.mediaType.rawValue, "start": time(range.start), "duration": time(range.duration), "segments": segments.map { ["empty": $0.isEmpty, "sourceStart": time($0.timeMapping.source.start), "targetStart": time($0.timeMapping.target.start), "targetDuration": time($0.timeMapping.target.duration)] }])
  }
  print(String(data: try JSONSerialization.data(withJSONObject: ["duration":time(duration),"tracks":rows], options:.sortedKeys), encoding:.utf8)!)
 }
}
