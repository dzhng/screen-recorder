# Audited choices

## Sound, medium confidence

**Declare the readiness interleave.** The natural tiny and1s recordings never had a video append after audio started but before it finished. The test therefore invokes the original SDK readiness getter but temporarily deliversfalse for video until the first accepted audio block; if later audio readiness arrives before video handoff, it deliversfalse there too. Production ready's existing asynchronous1ms wait yields its actor instead of blocking a callback. The first qualifying video append releases both gates, then faults (or acts as no-fault control). This is deliberately controlled task scheduling, not natural SDK readiness or producer-sample alteration. The original getter results are retained in the log. Future readers must keep that qualification rather than turn this proof into an unmodified scheduling claim.

## Sound, high confidence

**Use the existing1s operands with remaining audio.** The100020us tiny case has a single4800-frame block and no later audio readiness call to hold. The existing1s neighbor has48000 frames. At handoff the SDK had accepted8192, leaving real data to deliver, and neither input was marked finished. Requiring accepted frames below the declared full count avoids qualifying a last-block/finish-queue gap. The same retained picture/tone bytes and20-row compiled frame schedule are reused; no capture/media copy or larger run was introduced.

**Require the first video cause, not just fast refusal.** Both current and mutant SDK refusals drain in milliseconds and have NATIVE_DECODE_FAILED, so those assertions alone cannot prove causal preservation. Removing only MovieMux.firstFailure storage produces generic audio-side Movie writer stopped making progress. The test rejects that and requires the native owner's first-video append failure prefix. This proves the existing shared first-error ownership earns its place without adding a new owner.

**Cancel the SDK writer, not the caller.** At the real selected video append with both inputs active, the test calls that actual writer's cancelWriting and forwards the unchanged original CMSampleBuffer into the original SDK append. Its realfalse/terminal status is observed. The caller Task remains uncanceled, so a CANCELED reply cannot masquerade as the decoder failure contract. Source bytes, no output/stage, active calls and method restoration are checked independently.

**Keep natural recon separate.** The earlier unmodified scheduling attempts are negative information about eligibility, not sibling-pump closure. Their separate frozen bank remains qualifiedfalse. The controlled proof retains the original3s budget from the actual fault and does not infer a broader scale, capture, shutdown or installed guarantee.

No unsound or user-only choice remains. Initial unused-hold assertion was an implementation-coupling mistake and was resolved before final proof; it did not relax the requested overlap contract. Shared spec/docs/ledger promotion belong to root.
