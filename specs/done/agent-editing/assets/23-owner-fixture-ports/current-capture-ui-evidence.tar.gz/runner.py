import sys,os,json,time,subprocess,signal
from pathlib import Path
bank=Path(__file__).parent
name=sys.argv[1];args=sys.argv[2:];start=time.time()
env=dict(os.environ);env.pop("SCREENREC_NATIVE",None)
with (bank/(name+".stdout")).open("w") as out,(bank/(name+".stderr")).open("w") as err:
 p=subprocess.Popen(args,stdout=out,stderr=err,env=env,start_new_session=True)
 (bank/(name+"-process.json")).write_text(json.dumps({"argv":args,"pid":p.pid,"start":start,"outerBudgetSeconds":210,"environmentNativeOverride":None}))
 timedout=False
 try:code=p.wait(timeout=210)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 (bank/(name+"-terminal.json")).write_text(json.dumps({"pid":p.pid,"exit":code,"outerTimeout":timedout,"waited":True,"end":time.time()}))
print((bank/(name+".stdout")).read_text(),(bank/(name+".stderr")).read_text())
sys.exit(code)
