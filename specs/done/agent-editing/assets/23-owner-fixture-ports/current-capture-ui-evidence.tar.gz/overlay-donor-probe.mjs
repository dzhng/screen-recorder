import assert from "node:assert/strict";
import {existsSync,readdirSync,mkdtempSync,mkdirSync,readFileSync,rmSync} from "node:fs";
import {join} from "node:path";
import {runInNewContext} from "node:vm";
const text=readFileSync(process.argv[2],"utf8");
const body=text.match(/function takes\(home\) \{[\s\S]*?\n\}/)?.[0];
assert.ok(body);
const takes=runInNewContext(body+";takes",{existsSync,readdirSync,join});
const home=mkdtempSync("/tmp/scr-overlay-donor-");
try {mkdirSync(join(home,"library","recordings","donor"),{recursive:true});
 const actual=takes(home);console.log(JSON.stringify({actual,expected:["donor"],helper:body}));
 assert.deepEqual(actual,["donor"]);
} finally {rmSync(home,{recursive:true,force:true});}
