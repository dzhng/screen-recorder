import { z } from "zod";
import type { EvidenceIdentity } from "./evidence.js";
import type { SourceEvidenceReader } from "./evidence-read.js";
import { type RecordingSceneEvidenceIdentity, type SceneEvidenceRead } from "./scene-evidence.js";
import type { FileAccess } from "./files.js";
import { type TimelineRevision, type SourceEvent, type CutEvent } from "./timeline.js";
export declare const timelineEventPolicy = "timeline-v1";
export type TimelineEventMetadata = {
    sourceIdentity: EvidenceIdentity;
    sceneIdentity: RecordingSceneEvidenceIdentity;
    revision: TimelineRevision;
    interrupted: boolean;
};
export type TimelineEventRow = {
    ordinal: number;
    atUs: number;
    event: SourceEvent | CutEvent;
};
export type TimelineEventInput = TimelineEventMetadata & {
    source: SourceEvidenceReader;
    scenes: SceneEvidenceRead;
};
export declare const timelineEventCursorSchema: z.ZodObject<{
    pauses: z.ZodObject<{
        after: z.ZodNullable<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
        done: z.ZodBoolean;
    }, z.core.$strict>;
    geometry: z.ZodObject<{
        after: z.ZodNullable<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
        done: z.ZodBoolean;
    }, z.core.$strict>;
    scenes: z.ZodObject<{
        afterChunkStartUs: z.ZodNullable<z.ZodNumber>;
        boundaryOffset: z.ZodNumber;
        done: z.ZodBoolean;
    }, z.core.$strict>;
    cut: z.ZodNumber;
    interruption: z.ZodBoolean;
    ordinal: z.ZodNumber;
}, z.core.$strict>;
export type TimelineEventCursor = z.infer<typeof timelineEventCursorSchema>;
/** Stateless checkpoints bound both returned rows and work consumed while skipping removed evidence. */
export declare class TimelineEventRead {
    private readonly project;
    private readonly cuts;
    private readonly input;
    constructor(input: TimelineEventInput);
    page({ cursor, limit, }?: {
        cursor?: TimelineEventCursor | undefined;
        limit?: number | undefined;
    }, signal?: AbortSignal): Promise<{
        rows: TimelineEventRow[];
        nextCursor: TimelineEventCursor | null;
    }>;
}
export declare function writeTimelineEventPages(input: TimelineEventInput, directory: string, signal?: AbortSignal): Promise<void>;
/** Equal-time groups may cross pages. Continue by ordinal, retaining atUs to coalesce them. */
export declare class FileTimelineEvents {
    private readonly pages;
    constructor(root: string | FileAccess, expected: TimelineEventMetadata);
    page({ afterOrdinal, limit }?: {
        afterOrdinal?: number;
        limit?: number;
    }): {
        rows: TimelineEventRow[];
        nextOrdinal: number | null;
    };
}
/** Full bounded semantic admission compares every portable event with pinned evidence. */
export declare function validateTimelineEventPages(reader: FileTimelineEvents, input: TimelineEventInput, signal?: AbortSignal): Promise<void>;
