import { CatalogError } from "./catalog.js";
import { PresentationEvidence, } from "./presentation-evidence.js";
import { analyzeSceneObservations } from "./scenes.js";
import { planVisualTrail } from "./trails.js";
import { comparePresentationTimes, floorMicroseconds, } from "./presentation-time.js";
/** Integer times here are cursor-query cutoffs. Exact event support stays with the caller;
 * a fractional movie event does not claim its picture supports the earlier integer cutoff. */
function pointScene(picture, at, kept, source, trailUs = 0) {
    const sample = {
        requestedSourceUs: at,
        actualSourceUs: picture.actualSourceUs,
        distanceUs: Math.abs(at - picture.actualSourceUs),
        width: picture.width,
        height: picture.height,
        rgbBase64: picture.rgbBase64,
    };
    return {
        ...analyzeSceneObservations({
            sourceWidth: source.receipt.sourceWidth,
            sourceHeight: source.receipt.sourceHeight,
            samples: [sample],
        }, { kept, range: { startUs: Math.max(kept.startUs, at - trailUs), endUs: at } }),
        reference: sample,
        futureComparison: null,
    };
}
/** Sequential point inspection only; the pointer schedule decides which moments to request. */
export class PresentationPointer {
    source;
    evidence;
    identity;
    signal;
    busy = false;
    current;
    prior;
    constructor(source, evidence, identity, signal) {
        this.source = source;
        this.evidence = evidence;
        this.identity = identity;
        this.signal = signal;
        this.current = source.cursor(signal);
        this.prior = source.cursor(signal);
    }
    async exclusive(run) {
        if (this.busy)
            throw new CatalogError("INVALID_RANGE", "Pointer inspection requests must be sequential");
        this.busy = true;
        try {
            return await run();
        }
        finally {
            this.busy = false;
        }
    }
    at(spanIndex, sourceUs) {
        return this.exclusive(async () => this.inspect((await this.current.at(spanIndex, sourceUs)).record, sourceUs));
    }
    /** Exact event membership stays separate from the integer observation-query cutoff. */
    atEvent(record, at, resetFloor, trailUs = 0) {
        return this.exclusive(async () => {
            if (comparePresentationTimes(at, record.start) < 0 ||
                comparePresentationTimes(at, record.end) >= 0)
                throw new CatalogError("INVALID_RANGE", "Pointer event escapes its exact presentation support");
            return {
                at,
                observationCutoffUs: floorMicroseconds(at),
                inspection: await this.inspect(record, floorMicroseconds(at), resetFloor, at, trailUs),
            };
        });
    }
    async inspect(record, sourceUs, resetFloor, eventTime, trailUs = 0) {
        const spanIndex = record.spanIndex;
        if (record.empty)
            return {
                kind: "empty",
                requestedSourceUs: sourceUs,
                record,
                pointer: null,
            };
        const kept = this.source.spans[spanIndex];
        const plan = await planVisualTrail({ kept, requestedSourceUs: sourceUs, trailUs }, {
            evidence: this.evidence,
            identity: this.identity,
            scene: pointScene(record, sourceUs, kept, this.source, trailUs),
            ...(resetFloor ? { resetFloor } : {}),
            ...(eventTime
                ? { presentationClock: { at: eventTime, sampleTime: record.sampleTime } }
                : {}),
            readScene: async (at) => {
                const { record: previous } = await this.prior.at(spanIndex, at);
                return previous.empty
                    ? { scene: null }
                    : {
                        scene: pointScene(previous, at, kept, this.source),
                        presentationTime: previous.sampleTime,
                    };
            },
        }, this.signal);
        return { kind: "picture", record, plan };
    }
}
