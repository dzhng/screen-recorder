import { type TimelineEventInput } from "./event-pages.js";
export type TimelineContext<Target> = {
    target: Target;
    events: TimelineEventInput;
};
/** Both adapters resolve authority again after awaited reads; continuations pin their selected revision. */
export declare abstract class TimelineInspection<Target extends object> {
    protected abstract resolve(input: Target & {
        revisionId?: string | undefined;
    }): TimelineContext<Target>;
    get(input: Target & {
        revisionId?: string | undefined;
        cursor?: string | undefined;
        limit?: number | undefined;
    }, signal?: AbortSignal): Promise<{
        target: Target;
        recordingId: string;
        sourceId: string;
        revisionId: string;
        sourceGeneration: string;
        sceneGeneration: string;
        scenePolicy: string;
        interrupted: boolean;
        policy: string;
        state: "ready";
        timeDomain: "playback";
        rows: import("./event-pages.js").TimelineEventRow[];
        nextCursor: string | null;
    }>;
}
