import type { FileAccess } from "./files.js";
import { SceneEvidenceReader, type SceneEvidenceRead, type SceneEvidenceIdentity, type SceneEvidenceMetadata, type SceneChunkReport } from "./scene-evidence.js";
export declare function writeSceneEvidencePages(reader: SceneEvidenceRead, identity: SceneEvidenceIdentity, directory: string, signal?: AbortSignal): Promise<void>;
export declare class FileSceneEvidence extends SceneEvidenceReader {
    private readonly pages;
    constructor(root: string | FileAccess, identity: SceneEvidenceIdentity);
    protected readMetadata(identity: SceneEvidenceIdentity): SceneEvidenceMetadata;
    protected readChunks(identity: SceneEvidenceIdentity, afterStartUs: number, limit: number): SceneChunkReport[];
}
