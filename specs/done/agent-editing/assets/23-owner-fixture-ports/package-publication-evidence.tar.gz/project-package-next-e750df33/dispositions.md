# Bounded actual project-package checkpoint

- Legacy video-export.mjs:2391 ported to actual project package workspace cleanup. Shared bytes are counted from independent physical regular-file totals; external destination moves do not gate private cleanup.
- Legacy video-export.mjs:3017 loop ported at create/copy/write/commit/cleanup actual SIGKILL boundaries. Copy phase follows current copyImportedFile work before archive.write. Source identity remains intact, and committed bytes survive abandonment.
- Basic admission pin now proves the export asset resource dependency via ResourceReferences and native archive open/adopt via real ProjectPackages. This does not establish transcript/index/audio generation retention.
- Remaining: package resource generation pins, native surviving writer/locator substitution cases, package-media-failures positive frames/audio retry/generation/content/drain, bundled startup. Do not delete old fixtures until contract map is complete.
