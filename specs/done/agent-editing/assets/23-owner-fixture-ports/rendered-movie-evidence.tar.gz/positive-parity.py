from pathlib import Path
import subprocess
root=Path('/Users/david/dev/screen-recorder');bank=Path(__file__).parent
paths=['packages/core/src/preview.ts','packages/core/src/project-preview.ts']
current={n:(root/n).read_bytes() for n in paths}
try:
 for n in paths:(root/n).write_bytes((bank/'before'/n).read_bytes())
 code=subprocess.call(['python3',str(bank/'run.py'),'original-positive','node_modules/.bin/vitest','run','packages/core/src/project-preview.test.ts','-t','pins an old revision through edits'])
finally:
 for n,data in current.items():(root/n).write_bytes(data)
if code:raise SystemExit(code)
raise SystemExit(subprocess.call(['python3',str(bank/'run.py'),'relocated-positive','node_modules/.bin/vitest','run','packages/core/src/project-preview.test.ts','-t','pins an old revision through edits']))
