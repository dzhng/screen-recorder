# Decisions

Sound, high confidence: a small rendered-movie owner rather than a project-specific helper. A recording renderer and a project renderer both return H264 MP4 video facts; neither domain should load the other's processing classes just to check those facts. The new module owns only the common receipt and validator, and the service gets a direct package export. This new export is a load-bearing module boundary, not a new service/API/media contract.

Sound, high confidence: keep fixed-role audio with PreviewMovie. Old recording/package rendering receipts carry specific NativeAudio tracks. Project composition audio has different facts; importing the old audio model would recreate the dependency. The old owner extends the shared video receipt with its own audio fields while project CompositionMovie extends it independently.

Sound, high confidence: rename the validator to checkRenderedMovie but retain existing error text and rendition defaults. Its code serves both callers; changing observable errors or bound policy during ownership extraction would be unrelated behavior. No alias/reexport remains under the old name. PreviewInspectionBase stays until both real old consumers are ported/deleted.

No uncertain product/architecture choice, new schema or limit. Existing invalid-receipt and positive publication tests provide behavior proof; no compiler-only test or native renderer rerun added.
