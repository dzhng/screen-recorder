from pathlib import Path
import subprocess,sys,json,hashlib,time
bank=Path(__file__).parent;work=Path('/Users/david/.codex/worktrees/generic-render-lifetime/screen-recorder');label,pattern,*fault=sys.argv[1:];folder=bank/label;folder.mkdir(exist_ok=True)
p=work/'apps/service/src/render.ts';before=p.read_bytes()
try:
 if fault:
  s=before.decode()
  if fault[0]=='cleanup':
   a='''          } finally {
            await clear();
          }''';z='''          } finally {
            // Deliberate control: omit owned cleanup.
          }'''
  elif fault[0]=='consume-fence':
   a='''            const artifact = await render(attempt, boundWorker);
            checkCanceled();
            const result = await consume(artifact);''';z='''            const artifact = await render(attempt, boundWorker);
            const result = await consume(artifact);'''
  elif fault[0]=='private-root':
   a='''    !before.isDirectory() ||
    (before.mode & 0o777n) !== 0o700n ||
    before.uid !== BigInt(process.getuid!())''';z='false'
  elif fault[0]=='cancellation':
   a='if (signal.aborted) throw new CatalogError("CANCELED", "Media render was canceled");';z='// Deliberate control: omit cancellation fences.'
  else:raise RuntimeError(fault)
  assert s.count(a)>=1 if fault[0]=='cancellation' else s.count(a)==1
  p.write_text(s.replace(a,z))
 sources=[]
 for f in ['apps/service/src/render.ts','apps/service/src/render.test.ts']:
  data=(work/f).read_bytes();saved=folder/f;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(data);sources.append({'path':f,'sha256':hashlib.sha256(data).hexdigest()})
 argv=['node_modules/.bin/vitest','run','apps/service/src/render.test.ts','-t',pattern]
 with (folder/'stdout').open('w') as out,(folder/'stderr').open('w') as err:
  child=subprocess.Popen(argv,cwd=work,stdout=out,stderr=err);start=time.time();(folder/'process.json').write_text(json.dumps({'argv':argv,'pid':child.pid,'start':start,'sourcePins':sources,'control':fault},indent=2)+'\n')
  try:code=child.wait(timeout=30)
  except subprocess.TimeoutExpired:
   child.terminate();code=child.wait(timeout=5)
  (folder/'terminal.json').write_text(json.dumps({'exit':code,'end':time.time(),'seconds':time.time()-start,'waited':True})+'\n')
 print(json.dumps({'label':label,'exit':code,'seconds':time.time()-start}))
finally:
 p.write_bytes(before)
