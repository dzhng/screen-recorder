import subprocess,os,json,time,signal
from pathlib import Path
bank=Path(__file__).parent;root=Path.cwd();results=[]
for target,key in [('ScreenRecorderCompositionAudioTests','SCREENREC_COMPOSITION_AUDIO_EVIDENCE'),('ScreenRecorderSelectedAudioTests','SCREENREC_SELECTED_AUDIO_EVIDENCE')]:
    for phase,args,env in [('build',['swift','build','--package-path','helpers/mac','--disable-automatic-resolution','--skip-update','-j','2','--product',target],os.environ),('run',[str(root/'helpers/mac/.build/debug'/target)],dict(os.environ,**{key:str(bank/target)}))]:
        print(phase+' '+target,flush=True);start=time.monotonic()
        with (bank/(target+'-'+phase+'.log')).open('w') as log:
            child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
            try: code=child.wait(timeout=90)
            except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
        results.append({'target':target,'phase':phase,'exitCode':code,'seconds':time.monotonic()-start})
        (bank/'audio-defaults-status.json').write_text(json.dumps(results,indent=2)+'\n')
        print('END '+str(code),flush=True)
        if code: raise SystemExit(code)
