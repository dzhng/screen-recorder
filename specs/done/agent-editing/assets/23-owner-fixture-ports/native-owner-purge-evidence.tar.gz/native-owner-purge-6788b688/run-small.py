import subprocess,time,os,signal,json
from pathlib import Path
bank=Path(__file__).parent
root=Path.cwd()
commands=[('retirement-green',['node','--test','--test-name-pattern=retired recording render','helpers/mac/Tests/wire.test.mjs'],{}),('current-frames',[str(root/'helpers/mac/.build/debug/ScreenRecorderFrameTests')],{'SCREENREC_FRAME_EVIDENCE':str(bank/'current-frames')}),('current-source-audio',[str(root/'helpers/mac/.build/debug/ScreenRecorderSourceAudioTests')],{'SCREENREC_SOURCE_AUDIO_EVIDENCE':str(bank/'current-source-audio')}),('current-composition-movie',['node','packages/test-harness/editing/composition-movie.mjs'],{'SCREENREC_KEEP_TEST_FILES':'1'})]
results=[]
for label,args,extra in commands:
    env=dict(os.environ,SCREENREC_NATIVE=str(root/'helpers/mac/.build/debug/screenrec-native'),**extra)
    start=time.monotonic();print('RUN '+label,flush=True)
    with (bank/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=child.wait(timeout=90)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
    results.append({'case':label,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'args':args,'environment':extra})
    (bank/'runtime-status.json').write_text(json.dumps(results,indent=2)+'\n')
    print('END '+label+' '+str(code),flush=True)
    if code: raise SystemExit(code)
