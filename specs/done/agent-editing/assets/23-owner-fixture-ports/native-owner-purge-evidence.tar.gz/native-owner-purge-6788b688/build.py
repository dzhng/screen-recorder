import subprocess,time,os,signal,json
from pathlib import Path
bank=Path(__file__).parent
started=time.monotonic()
products=['ScreenRecorderFrameTests','ScreenRecorderSourceAudioTests','ScreenRecorderCompositionVideoTests','screenrec-native']
records=[]
for product in products:
    args=['swift','build','--package-path','helpers/mac','--disable-automatic-resolution','--skip-update','-j','2','--product',product]
    print('BUILD '+product,flush=True)
    with (bank/(product+'-build.log')).open('w') as log:
        child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=child.wait(timeout=max(1,300-(time.monotonic()-started)))
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
    records.append({'product':product,'args':args,'exitCode':code,'elapsedSeconds':time.monotonic()-started})
    (bank/'build-status.json').write_text(json.dumps(records,indent=2)+'\n')
    print('END '+product+' '+str(code),flush=True)
    if code: raise SystemExit(code)
