# Choices audited

## Sound, medium confidence

**Eligibility is observed, never forced.** The SDK method is actually invoked before the caller is canceled. The observer then requires writing status and no observed completion. Its callback must see the actual caller Task already canceled. If the SDK completes synchronously or timing is missed, this probe refuses qualification instead of reporting a cancellation pass or slowing the SDK through a fake gate. This keeps the production SDK invocation/callback/executor unchanged, but means this opt-in observation is tied to an eligible actual scheduling boundary rather than a promise every machine will provide it.

## Sound, high confidence

**Classify the actual error once.** Swift CancellationError means the operation was canceled; it should not become a retryable media decode failure because the operation table uses a media fallback. NativeWire now reports CANCELED with the existing default non-retryable refusal and operation details, matching service worker cancellation's default. It does not inspect a canceled-task flag to overwrite a genuine decode/storage failure. Three lines at the common boundary serve every registered operation; no per-movie mapper remains.

**Only the outer writer is the finishing operand.** Movie assembly also has an inner video writer. The observer limits itself to movie.mp4 directly under the owned outer stage in this one scratch parent. Other writers are forwarded unchanged. This makes entered/writing and completion evidence describe the mux writer rather than an earlier encoder stage.

**Callback forwarding stays on the SDK executor.** A Swift closure created in top-level actor context can trap when Objective-C invokes it elsewhere. The observer is constructed in a nonisolated class; only locked Sendable state crosses callbacks. It records state and then invokes the unchanged original completion immediately on that callback's executor. No actor hop or fake completion is introduced.

**Use both fractional and aligned tiny windows.** Fractional100020us coverage could receive its CancellationError from MovieAudioTail; the aligned100000us case omits that branch and exercises the later assembled-movie path. It uses the first two identical retained frame rows, same picture/tone bytes and same4800-frame PCM schedule. This is the smallest distinct neighbor needed, not another movie scale/cohort or capture run.

**Preserve and qualify historical evidence.** The previous NewFile bank's actual refusal was NATIVE_DECODE_FAILED and its helper did not assert exact CANCELED. Root appends a qualification rather than rewriting the frozen archive. This new bank retains that actual old reply and the exact finishing red/green so later callers can distinguish cleanup proof from error-classification proof.

No unsound or user-only choices remain. No new product editorial decision, external cost, compatibility API or runtime setting was introduced. Root owns canonical promotion of this ledger.
