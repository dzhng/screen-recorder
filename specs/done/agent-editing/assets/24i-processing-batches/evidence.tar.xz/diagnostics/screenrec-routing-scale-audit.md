# Remaining24 routing pressure audit

Bound contracts: verification.md's cached250-row p95<=250ms and warm10s1080p<=15s/4GiB are proposed explicit budgets; this0.1s audio probe does not substitute for them. Public edit.apply uses the existing10s default plus5s transport margin (operationDeadlineMs); actual public refusal is15s. No deadline changed. Public group depth and stack length have no numeric ceiling; native audio plan allows20k processing nodes,10k clip occurrences and256 simultaneously active source occurrences. Refusal at these domains must remain visible; no new ceiling was selected.

Existing full2h gate proves shallow sequential preparation, not deep routing/stack work. Public denoise cancellation proves real abort/cleanup; queue owner tests already cover saturation/admission semantics. Thus first missing interaction chosen was deep ancestors plus a long ordered gain stack, rather than another model workload or queue-unit duplicate.

Actual public setup/media: one0.1s stereo source occurrence;16,128,1024,4096 nested groups. Outer group has128 alternating0.5/2 gains; others two. Exact Float32 oracle uses existing fixed source samples and binary factors. Complete4,800-frame output and2,400-frame late excerpt match at every tested depth. Removing final gain at128 depth gives exact half-amplitude and differs from identity; no all-ignored-stack acceptance. No noncommutative DSP claim (owned elsewhere).

At4096 depth, native full/late end-to-end reads6.64/3.56s, receipt peak59.8MB. Public500-operation processing batches grow2.95→9.92s as retained stacks accumulate. All edits in that progression return within10s, total61.0s. These are local concurrent-development observations, not isolated comparative benchmarks or whole24 acceptance.

The next minimal selected red candidate is one500-group processing.set pair-order update on the already returned4096-depth document, preserving step IDs and net dyadic gain. Exact request is saved before dispatch. On timeout, inspect current revision and replay that request rather than rerunning fresh work. No further native work is needed to localize an authoring budget failure.

Evidence scratch: /tmp/screenrec-routing-probe (16/128+negative full media/receipts), /tmp/screenrec-routing-depth (1024/4096 exact requests/media/receipts and pressure request/report), associated /tmp/screenrec-routing-*.mjs/.log. Production tree remains clean; no new schema/backend/limit or source-admission/package-owner changes.


## Concrete red and localization

The500-set pair reversal succeeds at10,031ms end-to-end MCP; this is pressure evidence, not a deadline refusal. A scratch assertion wrongly expected revision.parentId; that harness red is preserved. A separate exact replay checked ordinal+1 and unchanged current head without executing again.

The maximum-admitted1000-set batch returns actual TIMEOUT at15,012ms. Public current-head inspection then finds its committed revision; replay returns that identical revision in74.5ms and keeps the head unchanged. All request IDs, operations and step IDs are retained. No rollback or cancellation is falsely inferred from timeout.

A pre-edit COW clone of this public fixture received the exact1000 request under Node CPU profiling, separately from uninstrumented timing. It also times out and subsequently replays its one commit. Of20.83s sampled serviceCPU, applyBatch is19.51s inclusive (93.6%), resolveComposition9.08s (43.6%), changes7.42s (35.6%,5.37s self). validateProcessing1.99s self, freeze1.34s self/7.14s inclusive; routing0.52s self. Inclusive values overlap and must not be summed. JSON stack diffing and repeated complete resolve/validation/freezing dominate; no native processing occurs in this pressure test.

Owner: composition applyBatch. Recommendation for independent design review: generalize its existing independent-operation batching mechanism to consecutive independent processing.set updates, with narrow explicit eligibility and scalar fallback. Preserve operation construction order, target-owned step IDs, allocation/labels, normalized per-operation changes, state continuity side effects, earliest error, atomicity and a dependent operation immediately afterward. Do not introduce a trusted-model bypass, second editor, timeout increase or fixture-count exception. A local-diff-only patch removes much measured cost but leaves complete validation/freezing per set; it is not the whole amplification repair.

Before code, establish exact eligibility: distinct existing targets, no repeated dependent target/step references across the grouped span, and no structural state normalization effects. General stateful/window/clip lifecycle cases retain scalar semantics unless proven independent. Comparison must include accepted noncommuting/stateful preservation fixtures and exact error/receipt/ID differential controls, not just commuting gains. Root approval/design review will settle this seam.

The source-admission and package-model lanes remain untouched. Pending24 wide routing, queued cancellation/saturation public join, cached250-row budgets, warm1080p preview budget and whole-history/storage costs remain open.
