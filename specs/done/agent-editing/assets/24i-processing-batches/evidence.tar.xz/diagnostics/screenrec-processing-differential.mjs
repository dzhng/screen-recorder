import assert from 'node:assert/strict';import {readFile,writeFile} from 'node:fs/promises';
import {applyBatch as original} from '/tmp/screenrec-scalar-edits.mjs';
import {applyBatch as changed} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/dist/edits.js';
const base={canvas:{width:160,height:96,fps:{numerator:30,denominator:1},background:'#000000ff'},groups:[{id:'a',kind:'audio',order:0},{id:'b',kind:'audio',order:1},{id:'v',kind:'video',order:0},{id:'w',kind:'video',order:1}],tracks:[{id:'t',kind:'audio',order:0,parentId:'a'}],clips:[{id:'c',trackId:'t',source:{kind:'silence'},placement:{kind:'project',range:{startUs:0,endUs:100000}}}],syncGroups:[],processing:[]};
const ctx={assets:[],namespace:'differential'};
const set=(id,steps)=>({operation:'processing.set',target:id==='output'?{kind:'output'}:{kind:'group',id},steps});const gain=(gain=0.5,extra={})=>({processor:{type:'gain',gain},...extra});
const cases=[];const add=(name,ops,input=base)=>cases.push({name,input,operations:ops});
for(let n=1;n<=8;n++){add('ordered gains '+n,[set('a',Array.from({length:n},(_,i)=>gain(i%2?2:0.5))),set('b',[gain(0.25)]),set('output',[gain(2)])]);}
add('labels then dependent',[set('a',[gain(.5,{label:'first'})]),set('b',[gain(2,{label:'second'})]),set('a',[gain(.25,{id:{label:'first'}})])]);
add('repeated target',[set('a',[gain(.5)]),set('a',[gain(2)]),set('b',[gain(.5)])]);
add('invalid prefix later repair',[set('a',[{processor:{type:'opacity',opacity:.5}}]),set('a',[gain(1)])]);
add('invalid prefix vs later constructor',[set('b',[{processor:{type:'opacity',opacity:.5}}]),set('a',[gain(1,{id:'not-owned'})])]);
add('lexical error ordering',[set('b',[{processor:{type:'opacity',opacity:.5}}]),set('a',[{processor:{type:'opacity',opacity:.25}}])]);
add('unknown later target',[set('a',[gain(.5)]),set('missing',[gain(1)])]);
add('duplicate labels',[set('a',[gain(.5,{label:'same'})]),set('b',[gain(2,{label:'same'})])]);
add('cross-target symbolic id',[set('a',[gain(.5,{label:'first'})]),set('b',[gain(2,{id:{label:'first'}})])]);
add('clear absent noop',[set('a',[]),set('b',[]),set('output',[])]);
add('stateful fallback new',[set('a',[{processor:{type:'rnnoise'}}]),set('b',[gain(.5)])]);
const existing=original(base,[set('a',[gain(.5,{label:'a-step'})]),set('b',[gain(2,{label:'b-step'})])],{...ctx,namespace:'setup'});
const a=existing.labels['a-step'],b=existing.labels['b-step'];
add('existing ids',[set('a',[gain(2,{id:a})]),set('b',[gain(.5,{id:b})])],existing.document);
add('repeated ids',[set('a',[gain(2,{id:a}),gain(.5,{id:a})]),set('b',[])],existing.document);
add('foreign literal id',[set('a',[gain(2,{id:b})]),set('b',[])],existing.document);
add('exact noop and clear',[set('a',existing.document.processing.find(s=>s.target.id==='a').steps),set('b',[])],existing.document);
const state=original(base,[set('a',[{processor:{type:'rnnoise'}}])],{...ctx,namespace:'state'}).document;
add('stateful fallback retained',[set('b',[gain(.5)]),set('output',[gain(2)])],state);
const geometry=[{processor:{type:'geometry',crop:{x:1,y:2,width:10,height:12}}},{processor:{type:'geometry',scale:{x:2,y:.5}}}];
add('noncommuting geometry order',[set('v',geometry),set('w',[...geometry].reverse())]);
for(const index of [0,1,2]){const ops=[set('a',[gain(.5)]),set('b',[gain(2)]),set('output',[gain(.25)])];ops[index].steps=[{processor:{type:'opacity',opacity:.5}}];add('earliest invalid '+index,ops);}
add('following label target',[{operation:'group.add',label:'fresh',group:{kind:'audio',order:2}},set('a',[gain(.5)]),set('b',[gain(2)]),set({label:'fresh'},[gain(.25)])]);
add('malformed early schema',[set('a',[{processor:{type:'gain',gain:-1}}]),set('b',[gain(.5)])]);
function run(fn,c){try{return {ok:true,value:fn(structuredClone(c.input),structuredClone(c.operations),ctx)}}catch(e){return {ok:false,error:{code:e.code,message:e.message,details:e.details}}}}
const records=[];
for(const c of cases){const expected=run(original,c),actual=run(changed,c);assert.deepEqual(actual,expected,c.name);records.push({...c,expected});}
await writeFile('/tmp/screenrec-processing-differential.json',JSON.stringify({passed:true,cases:records},null,2));console.log('Exact differential cases:',records.length);
