import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomUUID,createHash} from 'node:crypto';
const run=promisify(execFile),base='/tmp/screenrec-opacity-skill-trial',out=base+'/examiner';await mkdir(out);
const setup=JSON.parse(await readFile(base+'/setup.json'));const saved=async name=>JSON.parse(await readFile(base+'/consumer/'+name));
const final=(await saved('restore-final-valid.response.json')).data,donor=(await saved('donor-final-get.response.json')).data,exported=(await saved('final-export-v2-status-poll.response.json')).data;
const report={passed:false,trace:[],checks:[],finalRevisionId:final.id,exportRevisionId:exported.snapshot.revisionId};
async function call(operation,params,output){
 const args=['/Users/david/dev/screen-recorder/apps/cli/dist/main.js',operation,'--socket',setup.socket,'--params',JSON.stringify(params),...(output?['--output',output]:[])];
 const {stdout}=await run('node',args,{maxBuffer:8*1024**2});const response=JSON.parse(stdout);report.trace.push({operation,params,response});assert.equal(response.ok,true);return response.data;
}
async function frame(projectId,revisionId,atUs,name){
 let result;for(let i=0;i<100;i++){result=await call('frame.get',{projectId,revisionId,atUs});if(result.state==='ready')break;assert.equal(result.state,'processing');await new Promise(r=>setTimeout(r,100));}
 assert.equal(result.state,'ready');const path=out+'/'+name+'.png';await call('frame.get',{projectId,revisionId,atUs},path);return readFile(path);
}
try{
 assert.equal((await call('project.get',{projectId:setup.projectId})).currentRevisionId,setup.revisionId);
 assert.equal((await call('project.get',{projectId:final.projectId})).currentRevisionId,final.id);
 const restoredFrom=(await saved('restore-final-valid.request.json')).targetRevisionId;assert.equal(restoredFrom,exported.snapshot.revisionId);
 assert.equal(createHash('sha256').update(await readFile(exported.output)).digest('hex'),exported.receipt.sha256);
 const original=(await saved('project-get.response.json')).data;
 const created=await call('project.create',{requestId:randomUUID(),canvas:final.document.canvas,title:'Independent fade controls'});let head=created.revision.id;const id=created.project.projectId;
 const edit=async operations=>{const r=await call('edit.apply',{projectId:id,expectedRevisionId:head,requestId:randomUUID(),operations});head=r.revision.id;return r;};
 const placed=await edit([{operation:'track.add',label:'v',track:{kind:'video',order:0}},{operation:'place',label:'c',clip:{trackId:{label:'v'},assetId:setup.assetId,streamId:'image:0',source:{kind:'hold',atUs:0},placement:{kind:'project',range:{startUs:0,endUs:2000000}}}}]);
 for(const at of [0,250000,500000,875000,1000000,1250000,1500000,1875000]){
  const opacity=at/2000000*(at>=1000000?.5:1);await edit([{operation:'processing.set',target:{kind:'clip',id:placed.edit.labels.c},steps:[{processor:{type:'opacity',opacity}}]}]);
  const actual=await frame(final.projectId,final.id,at,'actual-'+at),expected=await frame(id,head,at,'constant-'+at);
  assert.deepEqual(actual,expected,'Direct PNG differs from independent constant opacity at '+at);
  if(at<1000000)assert.deepEqual(actual,await frame(setup.projectId,setup.revisionId,at,'donor-'+at));
  report.checks.push({atUs:at,opacity,exactConstantPng:true,sha256:createHash('sha256').update(actual).digest('hex')});
 }
 await call('project.delete',{projectId:id});report.passed=true;
}finally{await writeFile(out+'/report.json',JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({passed:report.passed,checks:report.checks}));
