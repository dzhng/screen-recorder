# L2-ARCTIC broader-reference eligibility

Verdict: additional scripted sentences would add accented ordinary-word examples, but cannot solve the missing independently reviewed filler/restart reference. The separate spontaneous suitcase subset is a plausible lead; no directly available small official metadata artifact was found within the permitted access route, so no selection or inference is eligible yet.

## Word versus phone authority

The [official current homepage](https://psi.engr.tamu.edu/l2-arctic-corpus/) explicitly separates forced-aligned word/phone transcripts from the selected manual subset with corrected word AND phone boundaries. The [original corpus paper](https://psi.engr.tamu.edu/wp-content/uploads/2018/08/zhao2018interspeech.pdf), §3.3, describes manually adjusted word/phone boundaries and experienced annotators. Thus manual /annotation TextGrids have stronger authority than automatic /textgrid files; phone error tags alone are not evidence of independent word edges. A phone UH is an ARPAbet vowel symbol, not a lexical uh filler label.

## Scripted branch and original omissions

Paper §3.2 states speakers re-recorded sentences with significant disfluency or deviation from the prompt; repetitions and false starts were then removed, audio normalized and leading/trailing silence/non-speech trimmed. The published source is edited read speech, not the original complete disfluent production. Current docs also say some speakers did not read every sentence and some recordings were removed for quality. These are source curation facts, not recognition omissions. Expected-phone deletion tags describe pronunciation relative to the prompt and cannot independently establish an omitted-word inventory.

The retained official LXC/arctic_a0018 TextGrid supplies5 lexical words,10 edge observations at6 distinct times,1 speaker and0 literal um/uh. That existing isolated evidence is preserved without revalidation/scoring/inference. No other official small annotation example was found; zero observed fillers in this example must not be reported as zero fillers across the corpus. Current read-branch counts (24 speakers,3,599 manual utterances) do not establish filler/restart coverage.

## Spontaneous suitcase branch

The [current documentation](https://psi.engr.tamu.edu/l2-arctic-corpus-docs/), “About the suitcase corpus” and “Directory structure,” describes22 speakers (excluding SKA/ASI),26.1minutes, approximately3,083 word segments, and manual TextGrids containing words/phones. Two trained assistants each transcribed half and checked the other half; John Levis checked all transcriptions. No automatic TextGrid set is distributed for suitcase because manual annotations supply more accurate alignments. This establishes promising human-review provenance, not exact filler counts, every-word inventory, filler/neighbor boundary validity or retention of all restarts. It is inappropriate to apply scripted recording edits to suitcase solely by inference.

Public docs report phoneme-error counts, not literal um/uh, repetition/false-start or protected-word counts. No published filler spellings, omissions/repair conventions or uncertainty bounds were found. There is no justified category-complete selected reference from metadata alone.

## Access and license boundary

Reuse the existing12k personal/local noncommercial research authority under the publisher's CC BY-NC4.0 declaration; no commercial authority or redistribution is inferred. Source and annotation rows stay outside Git.

Saved official HTML exposes no direct suitcase TextGrid, transcript or metadata-only ZIP link. The only direct annotation download is the previously qualified LXC read example. Current official access instructions require a form with name/email/affiliation and an emailed Google Drive download link. No form/account/contract submission, contact, audio download or full-corpus download occurred. Therefore no artifact fitting the delegated <=32MiB direct metadata-only condition was acquired.

Next eligible prerequisite, if an existing authorized official direct subset becomes available: inspect original suitcase transcript/manual TextGrid pairs for multiple speakers, count exact literal um/uh and all ordinary neighbors, and verify complete spoken word tiers and independently corrected boundaries without repaired/removed disfluencies. Freeze those rows/hashes before output. This is qualification, not a model trial. In current access scope, stop here: no additional read-sentence numerical example resolves parent12.

Acoustic median/p95, >=40 acoustically labeled held-out fillers, canonical required-word preservation, technical-name/silence coverage, new join auditions, warm>=300second resource proof and model-training exclusion remain unestablished. Existing12k/12l results and accepted12e joins are unchanged.
