import AppKit
import AVKit

@MainActor final class Delegate: NSObject, NSApplicationDelegate {
    let presenter = PreviewWindow()
    var observation: Timer?
    let movie = CommandLine.arguments[1]
    let reportFile = CommandLine.arguments[2]
    let title = "Native presenter verification"
    func applicationDidFinishLaunching(_ note: Notification) {
        presenter.open(title: title, retry: {}, closed: { NSApplication.shared.terminate(nil) })
        presenter.play(title: title, file: movie, mediaType: "video/mp4", failed: { reason in
            print(reason)
            NSApplication.shared.terminate(nil)
        })
        let timer = Timer(timeInterval: 0.1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.observe() }
        }
        RunLoop.main.add(timer, forMode: .common)
        observation = timer
        Timer.scheduledTimer(withTimeInterval: 90, repeats: false) { _ in MainActor.assumeIsolated { NSApplication.shared.terminate(nil) } }
    }
    func observe() {
        guard let window = NSApplication.shared.windows.first(where: { $0.title == title }),
              let view = window.contentView as? AVPlayerView, let player = view.player,
              let item = player.currentItem, item.status == .readyToPlay,
              CMTimeGetSeconds(player.currentTime()) > 0.5 else { return }
        observation?.invalidate()
        let priorSharing = window.sharingType.rawValue
        player.pause()
        // This standalone test observes unchanged production presentation, overriding
        // only its capture exclusion. The actual product keeps that exclusion.
        window.sharingType = .readOnly
        let report: [String: Any] = ["scope": "Production PreviewWindow compiled unchanged; presenting protocol extracted verbatim from current controller source; standalone presenter proof with capture-only sharing override, not installed app pixels",
            "originalSharing": priorSharing, "observedSharing": window.sharingType.rawValue,
            "itemStatus": item.status.rawValue, "pausedAtSeconds": CMTimeGetSeconds(player.currentTime()),
            "windowTitle": title, "contentWidth": view.bounds.width, "contentHeight": view.bounds.height]
        if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: URL(fileURLWithPath: reportFile))
        }
        print("readyForScreenshot")
        fflush(stdout)
    }
}
@main struct Probe {
    @MainActor static func main() {
        let app = NSApplication.shared
        let delegate = Delegate()
        app.delegate = delegate
        app.setActivationPolicy(.regular)
        app.run()
    }
}
