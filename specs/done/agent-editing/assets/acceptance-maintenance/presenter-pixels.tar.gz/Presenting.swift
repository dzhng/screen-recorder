import Foundation
@MainActor
protocol PreviewPresenting: AnyObject {
    func open(title: String, retry: @escaping @MainActor () -> Void, closed: @escaping @MainActor () -> Void)
    func show(title: String, message: String, canRetry: Bool)
    func play(title: String, file: String, mediaType: String, failed: @escaping @MainActor (String) -> Void)
    func close()
}

