import datetime,json,pathlib,subprocess,time,os
p=pathlib.Path(__file__).parent
argv=['bun','run','build','--filter=@screenrec/macos','--filter=@screenrec/cli']
start=time.monotonic(); log=(p/'build.log').open('w'); proc=subprocess.Popen(argv,cwd='/Users/david/dev/screen-recorder',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
r={'argv':argv,'pid':proc.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':600,'terminal':False}
(p/'build-process.json').write_text(json.dumps(r,indent=2))
try:proc.wait(timeout=600);r['timedOut']=False
except subprocess.TimeoutExpired:
 import signal
 r['timedOut']=True;os.killpg(proc.pid,signal.SIGTERM)
 try:proc.wait(timeout=15)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
r.update(exitCode=proc.returncode,waited=True,terminal=True,elapsedSeconds=time.monotonic()-start,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(p/'build-process.json').write_text(json.dumps(r,indent=2));log.close();print(json.dumps(r));raise SystemExit(proc.returncode)
