import json,os,pathlib,subprocess,time,tempfile,signal,datetime
p=pathlib.Path(__file__).parent;app=p.parent/'ScreenRecorder.app';home=pathlib.Path(tempfile.mkdtemp(prefix='sr-candidate-',dir='/private/tmp'));sock=home/'run/service.sock';node='/Users/david/.nvm/versions/node/v24.14.0/bin/node'
env={**os.environ,'SCREENREC_HOME':str(home),'SCREENREC_DEFAULTS':str(home/'defaults'),'SCREENREC_SERVICE_LAUNCH':'1','PATH':'/usr/bin:/bin:/usr/sbin:/sbin'};start=time.monotonic();stdout=(p/'smoke-app.stdout').open('w');stderr=(p/'smoke-app.stderr').open('w');proc=subprocess.Popen([str(app/'Contents/MacOS/ScreenRecorder')],cwd='/',env=env,stdout=stdout,stderr=stderr,start_new_session=True);report={'pid':proc.pid,'home':str(home),'socket':str(sock),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Isolated staged bundled project service, app-owned startup and graceful exit; not installed acceptance'}
try:
 end=time.monotonic()+15
 while not sock.exists() and proc.poll() is None and time.monotonic()<end:time.sleep(.05)
 assert sock.is_socket(),'Listener not ready'
 def call(op):
  r=subprocess.run([node,str(app/'Contents/Resources/cli/main.mjs'),op,'--socket',str(sock),'--params','{}'],env=env,cwd='/',capture_output=True,text=True,timeout=10);report[op]={'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};assert r.returncode==0,r.stdout+r.stderr;d=json.loads(r.stdout);assert d['ok'];return d['data']
 health=call('service.health');report['servicePid']=health['pid'];assert health['status']=='ready' and health['home']==str(home)
 listing=call('project.list');assert listing == {'projects': [], 'nextCursor': None},listing
 assert not (home/'recordings').exists(),'Startup allocated recording'
 proc.send_signal(signal.SIGTERM);proc.wait(timeout=15);assert proc.returncode==0
 assert not sock.exists(),'Socket remains after quit'
 q=subprocess.run(['ps','-p',str(health['pid']),'-o','pid=,command='],capture_output=True,text=True,timeout=3);assert not q.stdout.strip(),'Owned child survives quit'
 report.update(passed=True,exitCode=proc.returncode,terminal=True,waited=True,servicePidAbsent=True,socketAbsent=True,elapsedSeconds=time.monotonic()-start)
except BaseException as e:
 report.update(passed=False,error=repr(e))
 if proc.poll() is None:
  proc.send_signal(signal.SIGTERM)
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 report.update(exitCode=proc.returncode,terminal=True,waited=True)
finally:
 stdout.close();stderr.close();(p/'smoke.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['service.health','project.list']}))
raise SystemExit(0 if report.get('passed') else 1)
