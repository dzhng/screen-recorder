import AppKit

@MainActor final class Delegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    var window: NSWindow!
    var toggle: NSButton!
    func applicationDidFinishLaunching(_ note: Notification) {
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 560, height: 300),
            styleMask: [.titled, .closable], backing: .buffered, defer: false)
        window.title = "Native window capture control"
        window.delegate = self
        window.sharingType = .none
        let view = NSView(frame: NSRect(x: 0, y: 0, width: 560, height: 300))
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor.systemBlue.cgColor
        let label = NSTextField(labelWithString: "Readable window capture control")
        label.font = .systemFont(ofSize: 23)
        label.textColor = .white
        label.frame = NSRect(x: 30, y: 170, width: 500, height: 50)
        view.addSubview(label)
        toggle = NSButton(title: "Allow this test window to be captured", target: self, action: #selector(changeSharing))
        toggle.frame = NSRect(x: 30, y: 90, width: 390, height: 40)
        view.addSubview(toggle)
        window.contentView = view
        window.center()
        window.orderBack(nil)
        Timer.scheduledTimer(withTimeInterval: 120, repeats: false) { _ in NSApplication.shared.terminate(nil) }
    }
    func windowWillClose(_ note: Notification) { NSApplication.shared.terminate(nil) }
    @objc func changeSharing() {
        window.sharingType = window.sharingType == .none ? .readOnly : .none
        toggle.title = window.sharingType == .none ? "Allow this test window to be captured" : "Block this test window from capture"
        print("sharingType=\(window.sharingType.rawValue)")
        fflush(stdout)
    }
}
@main struct ControlApp {
    @MainActor static func main() {
        let app = NSApplication.shared
        let delegate = Delegate()
        app.delegate = delegate
        app.setActivationPolicy(.regular)
        app.run()
    }
}
