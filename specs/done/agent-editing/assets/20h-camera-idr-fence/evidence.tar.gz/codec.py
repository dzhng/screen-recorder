"""Frozen one-fixture byte inspection; no decoder or maintained codec implementation."""
import base64,hashlib,json,pathlib,sys
from fractions import Fraction
class Bits:
    def __init__(self,nal):
        out=bytearray();zeros=0
        for b in nal[1:]:
            if zeros==2 and b==3:zeros=0;continue
            out.append(b);zeros=zeros+1 if b==0 else 0
        self.bits=''.join(f'{b:08b}' for b in out);self.at=0;self.fields=[]
    def u(self,n,name):
        start=self.at;assert 0<n and self.at+n<=len(self.bits),'truncated '+name
        value=int(self.bits[self.at:self.at+n],2);self.at+=n;self.fields.append([name,start,self.at,value]);return value
    def ue(self,name):
        start=self.at;zeros=0
        while self.at<len(self.bits) and self.bits[self.at]=='0':self.at+=1;zeros+=1;assert zeros<32
        assert self.at<len(self.bits),'truncated '+name
        self.at+=1;assert self.at+zeros<=len(self.bits)
        value=(1<<zeros)-1+(int(self.bits[self.at:self.at+zeros],2) if zeros else 0);self.at+=zeros
        self.fields.append([name,start,self.at,value]);return value
    def se(self,name):
        value=self.ue(name);return (value+1)//2 if value&1 else -value//2

def parameters(sps,pps):
    assert sps[0]&31==7 and pps[0]&31==8
    b=Bits(sps);profile=b.u(8,'profile');constraints=b.u(8,'constraints');level=b.u(8,'level');sid=b.ue('spsID')
    # Deliberately refuse syntax not present in the retained stream; no inferred parser fallback.
    assert profile==100 and constraints==0 and level==11 and sid==0,'unsupported SPS family'
    assert b.ue('chromaFormat')==1
    assert b.ue('bitDepthLumaMinus8')==b.ue('bitDepthChromaMinus8')==0
    assert b.u(1,'qpBypass')==0 and b.u(1,'scalingMatrixPresent')==0
    frame_bits=b.ue('log2MaxFrameNumMinus4')+4
    assert b.ue('picOrderCountType')==0;order_bits=b.ue('log2MaxPicOrderCntLsbMinus4')+4
    refs=b.ue('maxNumRefFrames');b.u(1,'gapsAllowed');width=b.ue('picWidthInMbsMinus1')+1;height=b.ue('picHeightInMapUnitsMinus1')+1
    assert b.u(1,'frameMbsOnly')==1;b.u(1,'direct8x8')
    if b.u(1,'croppingPresent'):
        for k in ['left','right','top','bottom']:b.ue('crop'+k)
    assert b.u(1,'vuiPresent')==0,'explicit VUI requires separately reviewed syntax'
    assert b.bits[b.at:]=='1'+'0'*((8-(b.at+1)%8)%8),'SPS trailing bits'
    sps_fields=b.fields
    c=Bits(pps);assert c.ue('ppsID')==0 and c.ue('spsID')==0
    c.u(1,'entropyCoding');assert c.u(1,'bottomFieldPOC')==0;assert c.ue('numSliceGroupsMinus1')==0
    c.ue('defaultL0Minus1');c.ue('defaultL1Minus1');c.u(1,'weightedPred');c.u(2,'weightedBipred')
    c.se('initQP');c.se('initQS');c.se('chromaQP');c.u(1,'deblockingPresent');c.u(1,'constrainedIntra');assert c.u(1,'redundantPictureCount')==0
    assert c.u(1,'transform8x8Mode')==1 and c.u(1,'ppsScalingMatrixPresent')==0;c.se('secondChromaQP')
    assert c.bits[c.at:]=='1'+'0'*((8-(c.at+1)%8)%8),'PPS trailing bits'
    return {'spsHex':sps.hex(),'ppsHex':pps.hex(),'spsBitFields':sps_fields,'ppsBitFields':c.fields,'frameNumBits':frame_bits,'pocBits':order_bits,'maxReferencePictures':refs,'codedMacroblocks':[width,height],'inferredMaxDpbFrames':min(900//(width*height),16),'vuiPresent':False,'conformanceNotIndependentlyValidated':True}

def boxes(data):
    at=0;items=[]
    while at<len(data):
        assert at+8<=len(data),'partial atom header'
        size=int.from_bytes(data[at:at+4],'big');kind=data[at+4:at+8].decode('ascii');header=8
        if size==1:assert at+16<=len(data);size=int.from_bytes(data[at+8:at+16],'big');header=16
        assert size>=header and at+size<=len(data),'incomplete/open-ended atom'
        items.append({'offset':at,'end':at+size,'header':header,'kind':kind});at+=size
    return items

def rat(t):
    assert t['flags'] in [1,3] and t['epoch']==0 and t['scale']>0,'nonnumeric/unqualified clock'
    return Fraction(t['value'],t['scale'])

def inspect(movie,snapshot,formats):
    data=pathlib.Path(movie).read_bytes();assert len(data)<=2097152
    atoms=boxes(data);media=[(x['offset']+x['header'],x['end']) for x in atoms if x['kind']=='mdat']
    pictures=snapshot['pictures'];facts=snapshot['cursorFacts'];assert len(pictures)==len(facts)<=400
    assert formats['authority'] in ['native-cursors','retained-avcC-byte-record']
    if formats['authority']=='native-cursors':assert formats['allCursorFormatsEqual']
    assert len(formats['parameterSets'])==2 and formats['nalLengthBytes']==4
    sps,pps=[base64.b64decode(x,validate=True) for x in formats['parameterSets']];params=parameters(sps,pps)
    rows=[]
    assert len({rat(x['clocks']['mediaDTS']) for x in facts})==len(facts),'nonunique raw media DTS'
    for segment in snapshot['segmentBounds']:
        for field in ['mediaStart','assetStart','mediaDuration','assetDuration']:rat(segment[field])
        assert rat(segment['mediaDuration'])>0 and rat(segment['assetDuration'])>0,'empty mapping segment'
    for i,(picture,fact) in enumerate(zip(pictures,facts)):
        assert picture['ordinal']==fact['ordinal']==i and fact.get('missingReason') is None
        extent=fact['extents']['sample'];off,length=extent['offset'],extent['length'];end=off+length
        assert length>0 and any(a<=off<end<=b for a,b in media),'sample outside complete mdat'
        sample=data[off:end];at=0;nals=[];vcl=0;idr=None
        while at<len(sample):
            assert at+4<=len(sample);n=int.from_bytes(sample[at:at+4],'big');at+=4
            assert n>0 and at+n<=len(sample),'incomplete NAL';nal=sample[at:at+n];at+=n
            kind=nal[0]&31;assert kind in [1,5,6],'unexpected parameter/auxiliary NAL'
            item={'type':kind,'refIDC':(nal[0]>>5)&3,'bytes':n}
            if kind in [1,5]:
                vcl+=1;b=Bits(nal);assert b.ue('firstMB')==0;stype=b.ue('sliceType');assert b.ue('ppsID')==0
                frame=b.u(params['frameNumBits'],'frameNum')
                if kind==5:
                    assert stype%5==2 and frame==0 and item['refIDC']>0;b.ue('idrPicID');b.u(params['pocBits'],'picOrderCntLSB')
                    prior=b.u(1,'noOutputOfPriorPics');longterm=b.u(1,'longTermReference')
                    idr={'noOutputOfPriorPics':prior,'longTermReference':longterm,'headerFields':b.fields}
                item['sliceType']=stype;item['ppsID']=0
            nals.append(item)
        assert at==len(sample) and vcl==1,'unsupported access-unit multiplicity'
        assert fact['flags']['sampleIsFullSync']==(idr is not None),'sync/IDR disagreement'
        for tick in [picture['pts'],picture['digestPTS'],fact['requestedAssetPTS'],fact['requestedMediaPTS'],*fact['clocks'].values()]:rat(tick)
        assert picture['end'] is not None;rat(picture['end'])
        assert picture['pts']==fact['requestedAssetPTS']
        segment=snapshot['segmentBounds'][fact['selectedSegment']]
        assert rat(segment['assetStart'])<=rat(picture['pts'])<rat(segment['assetStart'])+rat(segment['assetDuration'])
        assert rat(segment['mediaStart'])<=rat(fact['requestedMediaPTS'])<rat(segment['mediaStart'])+rat(segment['mediaDuration'])
        rate=rat(segment['assetDuration'])/rat(segment['mediaDuration'])
        # Physical offset/URL/index are diagnostics. Closure may relocate identical payloads.
        logical={'ordinal':i,'payloadBase64':base64.b64encode(sample).decode(),'format':formats['formatIdentity'],'parameterSets':formats['parameterSets'],'nalLengthBytes':4,'assetPTS':picture['pts'],'mediaPTS':fact['clocks']['mediaPTS'],'mediaDTS':fact['clocks']['mediaDTS'],'decodeDuration':fact['clocks']['decodeDuration'],'requestedMediaPTS':fact['requestedMediaPTS'],'segmentMediaStart':segment['mediaStart'],'segmentAssetStart':segment['assetStart'],'segmentRate':[rate.numerator,rate.denominator]}
        rows.append({'ordinal':i,'physicalExtent':extent,'nals':nals,'idr':idr,'logical':logical})
    fences=[]
    for r in rows:
        if r['idr'] is None or r['idr']['noOutputOfPriorPics']!=0:continue
        i=r['ordinal'];d=rat(r['logical']['mediaDTS']);p=rat(r['logical']['mediaPTS']);asset_fence=rat(r['logical']['assetPTS'])
        prior=[x for x in rows if rat(x['logical']['mediaDTS'])<d];later=[x for x in rows if rat(x['logical']['mediaDTS'])>d]
        if i>0 and len(prior)==i and all(rat(x['logical']['mediaPTS'])<p for x in prior) and all(rat(x['logical']['mediaPTS'])>p for x in later) and all(x['end'] is not None and rat(x['end'])<=asset_fence for x in pictures[:i]):fences.append(i)
    return {'scope':'Encoded byte facts only; no decoder or append safety claim','sourceSHA256':hashlib.sha256(data).hexdigest(),'sourceBytes':len(data),'atoms':atoms,'parameters':params,'rows':rows,'completeIDRFenceOrdinals':fences}

def compare(expected,actual,count,destination):
    before=json.loads(pathlib.Path(expected).read_text());after=json.loads(pathlib.Path(actual).read_text())
    left=[x['logical'] for x in before['rows'][:count]];right=[x['logical'] for x in after['rows'][:count]]
    changes=[]
    for i,item in enumerate(left):
        if i>=len(right):changes.append({'ordinal':i,'fields':['actual.presence']})
        else:
            fields=[k for k in item if item[k]!=right[i].get(k)]
            if fields:changes.append({'ordinal':i,'fields':fields})
    # Full operands precede refusal; physical extents remain in each source artifact.
    pathlib.Path(destination).write_text(json.dumps({'expected':left,'actual':right,'differences':changes,'physicalOffsetsCompared':False},indent=2)+'\n')
    assert len(left)==len(right)==count>0 and not changes,'logical payload/timing/format/mapping identity differs'

if __name__=='__main__':
    if sys.argv[1]=='compare':compare(sys.argv[2],sys.argv[3],int(sys.argv[4]),sys.argv[5]);print('LOGICAL comparison pass')
    else:
        movie,snapshot,formats,destination=sys.argv[1:]
        snapshot=json.loads(pathlib.Path(snapshot).read_text());formats=json.loads(pathlib.Path(formats).read_text())
        result=inspect(movie,snapshot,formats)
        pathlib.Path(destination).write_text(json.dumps(result,indent=2)+'\n')
        print('CODEC samples',len(result['rows']),'complete IDR fences',result['completeIDRFenceOrdinals'])
