"""Frozen supervisor for the reviewed fixed experiment; no product executor."""
import pathlib,json,subprocess,selectors,signal,os,time,datetime,hashlib,sys
root=pathlib.Path(__file__).parent;plan=json.loads((root/'plan.json').read_text());records=[];phase=time.monotonic()
def save():
    (root/'processes.json').write_text(json.dumps({'phaseBoundSeconds':210,'elapsedSeconds':time.monotonic()-phase,'processes':records},indent=2)+'\n')
def receipts(case):
    out=[]
    if case:
        for path in case.rglob('*.process.json'):
            try:out.append({'path':str(path),'receipt':json.loads(path.read_text())})
            except (OSError,json.JSONDecodeError):pass # Atomic writer receipt may not have appeared yet.
    return out
def run(label,argv,bound,case=None,interrupt=False):
    bound=min(bound,210-(time.monotonic()-phase));assert bound>0
    with (root/(label+'.stdout')).open('wb') as stdout,(root/(label+'.stderr')).open('wb') as stderr:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        start=time.monotonic();r={'label':label,'argv':argv,'pid':p.pid,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':bound,'terminal':False};records.append(r);save()
        streams=selectors.DefaultSelector();streams.register(p.stdout,selectors.EVENT_READ,('stdout',stdout));streams.register(p.stderr,selectors.EVENT_READ,('stderr',stderr));sizes={'stdout':0,'stderr':0};intentional=False
        def drain(wait):
            for key,_ in streams.select(wait):
                data=os.read(key.fileobj.fileno(),65536);name,destination=key.data
                if not data:streams.unregister(key.fileobj);key.fileobj.close();continue
                remaining=1048576-sizes[name];destination.write(data[:remaining]);destination.flush();sizes[name]+=min(len(data),remaining)
                if len(data)>remaining:raise RuntimeError('1 MiB '+name+' cap')
        try:
            while streams.get_map() or p.poll() is None:
                if time.monotonic()-start>bound:raise TimeoutError(label+' work deadline')
                if interrupt and not intentional and (case/'ready.json').exists():
                    ready=json.loads((case/'ready.json').read_text());assert ready['status']=='ready-to-interrupt'
                    children=receipts(case);assert all(x['receipt']['terminal'] and x['receipt']['waited'] for x in children),'ready has live byte query'
                    r['intentionalSignal']='SIGKILL after complete active-fence pass and before close';r['ready']=ready;r['byteQueryReceiptsAtKill']=children
                    os.killpg(p.pid,signal.SIGKILL);intentional=True
                drain(.02)
            p.wait();expected=-signal.SIGKILL if interrupt else 0
            assert p.returncode==expected,(label,p.returncode,expected)
            if interrupt:assert intentional
        except BaseException as error:
            r['controllerFailure']=repr(error)
            # Terminate the actual owned query child first; native waitUntilExit reaps it.
            cleanup=[]
            for entry in receipts(case):
                q=entry['receipt']
                if q.get('terminal') or q.get('parentPID')!=p.pid:continue
                try:
                    if p.poll() is None and os.getpgid(q['pid'])==p.pid:
                        os.kill(q['pid'],signal.SIGKILL);cleanup.append({'pid':q['pid'],'signal':'SIGKILL','receipt':entry['path']})
                    else:cleanup.append({'pid':q['pid'],'notInLiveOwnedGroup':True,'receipt':entry['path']})
                except ProcessLookupError:cleanup.append({'pid':q['pid'],'alreadyAbsent':True,'receipt':entry['path']})
            r['queryCleanup']=cleanup;r['cleanupGraceSeconds']=1
            grace=time.monotonic()+1
            while p.poll() is None and time.monotonic()<grace:
                try:drain(.02)
                except RuntimeError:break
            if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);r['writerCleanupSignal']='SIGKILL after query-first grace'
            p.wait(timeout=5)
            raise
        finally:
            fullyDrained=not bool(streams.get_map());streams.close()
            for stream in [p.stdout,p.stderr]:
                if not stream.closed:stream.close()
            r.update(streamsFullyDrained=fullyDrained,terminal=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,stdioBytes=sizes,stdioCapBytes=1048576,byteQueries=receipts(case));save()
def cache():
    folder=pathlib.Path(plan['moduleCache']);return [{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'mtimeNs':p.stat().st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(folder.rglob('*')) if p.is_file()]
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path']);d=p.read_bytes();assert len(d)==pin['bytes'] and hashlib.sha256(d).hexdigest()==pin['sha256'],str(p)
    (root/'cache-before.json').write_text(json.dumps(cache(),indent=2)+'\n')
    run('compile',plan['compile'],150)
    binary=pathlib.Path(plan['ordinary'][0]);(root/'binary.json').write_text(json.dumps({'path':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
    run('ordinary',plan['ordinary'],20,root/'ordinary')
    assert json.loads((root/'ordinary/verdict.json').read_text())['status']=='pass'
    run('interrupt',plan['interrupt'],20,root/'interrupted',True)
    run('fresh-raw-reader',plan['recover'],15,root/'interrupted/recovery')
    assert json.loads((root/'interrupted/recovery/verdict.json').read_text())['status']=='pass'
    (root/'controller-verdict.json').write_text(json.dumps({'status':'pass','scope':'Fixed tiny complete-IDR-fence raw ordinary extension/closure and separate intentional interruption/fresh raw reader only; no canonical proof or adoption'},indent=2)+'\n')
except BaseException as error:
    (root/'controller-verdict.json').write_text(json.dumps({'status':'fail','error':repr(error),'noRetry':True},indent=2)+'\n');print('FAIL',error);sys.exit(1)
finally:
    (root/'cache-after.json').write_text(json.dumps(cache(),indent=2)+'\n');save()
