@preconcurrency import AVFoundation
import Foundation
import CoreFoundation
import Darwin
@testable import ScreenRecorderCapture
import ScreenRecorderMedia

// Frozen external experiment: supported plist values stay typed, including bytes.
indirect enum FormatValue: Codable {
    case string(String), boolean(Bool), number(type:String,value:String), bytes(Data), array([FormatValue]), dictionary([String:FormatValue]), date(Double)
    init(_ value:Any) throws {
        if let v=value as? Data { self = .bytes(v) }
        else if let v=value as? String { self = .string(v) }
        else if let v=value as? NSNumber { if CFGetTypeID(v)==CFBooleanGetTypeID(){self = .boolean(v.boolValue)}else{self = .number(type:String(cString:v.objCType),value:v.stringValue)} }
        else if let v=value as? [String:Any] { self = .dictionary(try v.mapValues(FormatValue.init)) }
        else if let v=value as? [Any] { self = .array(try v.map(FormatValue.init)) }
        else if let v=value as? Date { self = .date(v.timeIntervalSinceReferenceDate) }
        else { throw ProbeFailure(message:"Unsupported actual format extension type \(type(of:value))") }
    }
}
struct EncodedFormat: Encodable {
    let authority="native-cursors";let allCursorFormatsEqual:Bool;let parameterSets:[Data];let nalLengthBytes:Int32
    let formatIdentity:[String:FormatValue]
}
func formatFacts(_ url:URL,_ snapshot:Snapshot,evidence:ObserverEvidence) async throws -> EncodedFormat {
    let asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
    let tracks=try await asset.loadTracks(withMediaType:.video)
    try require(tracks.count==1,"encoded format track count",["count":String(tracks.count)],evidence:evidence)
    let track=tracks[0],descriptions=try await track.load(.formatDescriptions)
    try require(descriptions.count==1,"encoded format count",["count":String(descriptions.count)],evidence:evidence)
    let description=descriptions[0]
    try require(CMFormatDescriptionGetMediaSubType(description)==kCMVideoCodecType_H264,"actual encoding changed",["subtype":String(CMFormatDescriptionGetMediaSubType(description))],evidence:evidence)
    var count=0,nalLength:Int32=0
    let status=CMVideoFormatDescriptionGetH264ParameterSetAtIndex(description,parameterSetIndex:0,parameterSetPointerOut:nil,parameterSetSizeOut:nil,parameterSetCountOut:&count,nalUnitHeaderLengthOut:&nalLength)
    try require(status==noErr && count==2 && nalLength==4,"H264 parameter query",["status":String(status),"count":String(count),"nalLength":String(nalLength)],evidence:evidence)
    var sets=[Data]()
    for i in 0..<count {
        var pointer:UnsafePointer<UInt8>?,length=0
        let status=CMVideoFormatDescriptionGetH264ParameterSetAtIndex(description,parameterSetIndex:i,parameterSetPointerOut:&pointer,parameterSetSizeOut:&length,parameterSetCountOut:nil,nalUnitHeaderLengthOut:nil)
        try require(status==noErr && pointer != nil && length>0 && length<=4096,"H264 parameter bytes unavailable",["status":String(status),"index":String(i),"bytes":String(length)],evidence:evidence)
        sets.append(Data(bytes:pointer!,count:length))
    }
    var equal=true
    for fact in snapshot.cursorFacts {
        guard let t=fact.requestedMediaPTS,let cursor=track.makeSampleCursor(presentationTimeStamp:CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)) else { throw ProbeFailure(message:"No encoded cursor for format ordinal \(fact.ordinal)") }
        equal = equal && CMFormatDescriptionEqual(description,otherFormatDescription:cursor.copyCurrentSampleFormatDescription())
    }
    let dimensions=CMVideoFormatDescriptionGetDimensions(description)
    let transform=try await track.load(.preferredTransform)
    guard let extensions=CMFormatDescriptionGetExtensions(description) else { throw ProbeFailure(message:"H264 format extensions absent") }
    let identity:[String:FormatValue]=["subtype":.number(type:"UInt32",value:String(CMFormatDescriptionGetMediaSubType(description))),"width":.number(type:"Int32",value:String(dimensions.width)),"height":.number(type:"Int32",value:String(dimensions.height)),"extensions":try FormatValue(extensions as NSDictionary),"preferredTransform":.array([transform.a,transform.b,transform.c,transform.d,transform.tx,transform.ty].map{.number(type:"CGFloat",value:String(describing:$0))})]
    return EncodedFormat(allCursorFormatsEqual:equal,parameterSets:sets,nalLengthBytes:nalLength,formatIdentity:identity)
}
struct ByteRead:Encodable { let sourceBytes:Int;let completeBytes:Int;let fragments:Int;let atomRewriting=false;let offsetsNormalized=false;let copiedFromOffset=0 }
func frozenExtension(_ raw:URL,_ root:URL,_ after:Int,evidence:ObserverEvidence) throws -> (URL,Int)? {
    guard FileManager.default.fileExists(atPath:raw.path) else {return nil}
    let input=try FileHandle(forReadingFrom:raw);defer {try? input.close()}
    let data=try input.read(upToCount:2_097_153) ?? Data()
    if data.count>2_097_152 {try data.prefix(2_097_152).write(to:root.appendingPathComponent("failed-unverified-copy.bin"));throw ProbeFailure(message:"2 MiB snapshot cap")}
    let bytes=[UInt8](data);var at=0,count=0,end=0,media=false
    func integer(_ offset:Int,_ n:Int)->UInt64 { bytes[offset..<offset+n].reduce(UInt64(0)){($0<<8)|UInt64($1)} }
    while at+8<=bytes.count {
        var size=integer(at,4);var header=8
        if size==1 {if at+16>bytes.count {break};size=integer(at+8,8);header=16}
        if size==0 {break}
        if size<UInt64(header) {try data.write(to:root.appendingPathComponent("failed-unverified-copy.bin"));throw ProbeFailure(message:"Malformed observed atom size at \(at)")}
        if size>UInt64(bytes.count-at) {break}
        let kind=String(bytes:bytes[at+4..<at+8],encoding:.ascii)
        if kind=="mdat" {media=true}
        else if (kind=="moov" || kind=="moof") && media {count+=1;media=false;end=at+Int(size)}
        at+=Int(size)
    }
    guard count>after else {return nil}
    let copied=data.prefix(end),url=root.appendingPathComponent("fragment-\(count).mov")
    // A second bounded read refuses a torn copy. It is not an immutability promise.
    try input.seek(toOffset:0);let second=try input.read(upToCount:end) ?? Data()
    try copied.write(to:url,options:.withoutOverwriting)
    try save(ByteRead(sourceBytes:data.count,completeBytes:end,fragments:count),root.appendingPathComponent("fragment-\(count)-copy.json"))
    try require(second==copied,"snapshot copy changed during acquisition",["copy":url.path,"firstBytes":String(copied.count),"secondBytes":String(second.count)],evidence:evidence)
    return (url,count)
}
struct CodecResult:Decodable { let completeIDRFenceOrdinals:[Int] }
struct ByteProcessReceipt:Encodable {
    let argv:[String];let pid:Int32;let parentPID:Int32;let groupID:Int32;let started:Date
    let terminal:Bool;let exitCode:Int32?;let terminationReason:String?;let waited:Bool
}
func runByte(_ arguments:[String],record:URL,evidence:ObserverEvidence) throws {
    let process=Process();process.executableURL=URL(fileURLWithPath:"/usr/bin/python3");process.arguments=arguments
    process.standardInput=FileHandle.nullDevice;process.standardOutput=FileHandle.standardOutput;process.standardError=FileHandle.standardError
    let started=Date();try process.run();let group=getpgid(process.processIdentifier)
    // Register kill/wait before the first fallible receipt write.
    defer {
        if process.isRunning {Darwin.kill(process.processIdentifier,SIGKILL)}
        process.waitUntilExit()
        try? save(ByteProcessReceipt(argv:["/usr/bin/python3"]+arguments,pid:process.processIdentifier,parentPID:getpid(),groupID:group,started:started,terminal:true,exitCode:process.terminationStatus,terminationReason:String(describing:process.terminationReason),waited:true),record)
    }
    try save(ByteProcessReceipt(argv:["/usr/bin/python3"]+arguments,pid:process.processIdentifier,parentPID:getpid(),groupID:group,started:started,terminal:false,exitCode:nil,terminationReason:nil,waited:false),record)
    process.waitUntilExit()
    try require(process.terminationReason == .exit && process.terminationStatus==0,"byte query failed",["pid":String(process.processIdentifier),"status":String(process.terminationStatus),"reason":String(describing:process.terminationReason),"processReceipt":record.path],evidence:evidence)
}
func inspectBytes(_ movie:URL,_ snapshotURL:URL,_ formatsURL:URL,_ out:URL,_ script:String,evidence:ObserverEvidence) throws -> CodecResult {
    try runByte([script,movie.path,snapshotURL.path,formatsURL.path,out.path],record:out.appendingPathExtension("process.json"),evidence:evidence)
    return try JSONDecoder().decode(CodecResult.self,from:Data(contentsOf:out))
}
func compareLogical(_ expected:URL,_ actual:URL,_ count:Int,_ script:String,_ destination:URL,evidence:ObserverEvidence) throws {
    try runByte([script,"compare",expected.path,actual.path,String(count),destination.path],record:destination.appendingPathExtension("process.json"),evidence:evidence)
}
@main struct FenceExperiment {
    @MainActor static func main() async {
        var ownership:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments;let mode=args[1],fixture=URL(fileURLWithPath:args[2]),root=URL(fileURLWithPath:args[3]),script=args[4]
            if mode=="recover" {
                let recovery=try OwnedEvidenceDestination(root:root.appendingPathComponent("recovery"));ownership=recovery
                let evidence=try ObserverEvidence(root:recovery.root.appendingPathComponent("evidence"))
                let candidate=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:root.appendingPathComponent("candidate.json")))
                let selection=try JSONDecoder().decode([String:Int].self,from:Data(contentsOf:root.appendingPathComponent("candidate-fence.json")))
                let fence=selection["fenceOrdinal"]!,fragment=selection["fragment"]!
                let raw=root.appendingPathComponent("camera/camera.raw.mov")
                guard let (copy,count)=try frozenExtension(raw,recovery.root,0,evidence:evidence) else {throw ProbeFailure(message:"Interrupted complete fragment absent")}
                let actual=try await read(copy,phase:"interrupted-reopened",fragments:count,evidence:evidence)
                let snapshotURL=recovery.root.appendingPathComponent("recovered.json"),formatsURL=recovery.root.appendingPathComponent("formats.json"),codecURL=recovery.root.appendingPathComponent("codec.json")
                try save(actual,snapshotURL);try save(try await formatFacts(copy,actual,evidence:evidence),formatsURL)
                _ = try inspectBytes(copy,snapshotURL,formatsURL,codecURL,script,evidence:evidence)
                try compare(Array(candidate.pictures.prefix(fence)),actual,evidence:evidence)
                try compareLogical(root.appendingPathComponent("active-\(fragment)-codec.json"),codecURL,fence,script,recovery.root.appendingPathComponent("logical-comparison.json"),evidence:evidence)
                try save(["status":"pass","scope":"Fresh existing physical reader after controller-owned SIGKILL; no canonical recovery/publication","committedPictures":String(fence)],recovery.root.appendingPathComponent("verdict.json"));return
            }
            guard mode=="ordinary" || mode=="interrupt" else {throw ProbeFailure(message:"Unknown fixed case")}
            let owner=try OwnedEvidenceDestination(root:root);ownership=owner
            let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence"))
            let raw=root.appendingPathComponent("camera/camera.raw.mov")
            let source=AVURLAsset(url:fixture);let tracks=try await source.loadTracks(withMediaType:.video)
            try require(tracks.count==1,"fixture track count",["count":String(tracks.count)],evidence:evidence)
            let reader=try AVAssetReader(asset:source);defer {reader.cancelReading()}
            let output=AVAssetReaderTrackOutput(track:tracks[0],outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA]);reader.add(output)
            let startedReader=reader.startReading();try require(startedReader,"fixture read failed",["status":String(reader.status.rawValue)],evidence:evidence)
            var samples=[CMSampleBuffer]();while let sample=output.copyNextSampleBuffer(){samples.append(sample)}
            try require(reader.status == .completed && samples.count==3,"fixture inventory changed",["count":String(samples.count),"status":String(reader.status.rawValue)],evidence:evidence)
            var mappings=[CameraFrameMapping](),observationBytes=Data(),receipts=[IngressObservation]()
            let writer=try CameraWriter(directory:root.appendingPathComponent("camera"),framesPerSecond:30)
            defer {evidence.preserve(mappings:mappings,observations:observationBytes,receipts:receipts,raw:raw);writer.discard()}
            let anchor=CaptureHostTime.nowUs();var clock=CaptureClock();clock.start(at:anchor)
            let state=CaptureWriter.IngressState(clock:clock,accepting:true),started=ContinuousClock.now
            var lastCount=0,candidate:Snapshot?,candidateCodec:URL?,candidateFence:Int?,candidateFragment:Int?,candidateAdmissions:Int?,candidateOffered:Int?,activePassed=false
            func observe() async throws {
                guard let (copy,count)=try frozenExtension(raw,root,lastCount,evidence:evidence) else{return}
                let snapshot=try await read(copy,phase:"active-\(count)",fragments:count,evidence:evidence)
                let snapshotURL=root.appendingPathComponent("active-\(count).json"),formatsURL=root.appendingPathComponent("active-\(count)-formats.json"),codecURL=root.appendingPathComponent("active-\(count)-codec.json")
                try save(snapshot,snapshotURL);try save(try await formatFacts(copy,snapshot,evidence:evidence),formatsURL)
                let result=try inspectBytes(copy,snapshotURL,formatsURL,codecURL,script,evidence:evidence)
                try require(snapshot.canContainFragments==true && (count==1 || snapshot.containsFragments==true),"native fragment qualification",["canContain":String(describing:snapshot.canContainFragments),"contains":String(describing:snapshot.containsFragments),"count":String(count)],evidence:evidence)
                if candidate==nil,let fence=result.completeIDRFenceOrdinals.max() {
                    // read traversed the closing IDR as well as every preceding sample.
                    try require(snapshot.pictures.count>fence,"closing IDR not decoded",["fence":String(fence),"decoded":String(snapshot.pictures.count)],evidence:evidence)
                    try require(mappings.count>=fence,"candidate admissions missing",["fence":String(fence),"admitted":String(mappings.count)],evidence:evidence)
                    for (mapping,picture) in zip(mappings.prefix(fence),snapshot.pictures.prefix(fence)) {
                        let grid=try mapping.acquisitionRange(scale:snapshot.nativeScale)
                        try require(mapping.ordinal==picture.ordinal && grid.start.value==picture.digestPTS.value && grid.start.timescale==picture.digestPTS.scale && grid.start.epoch==picture.digestPTS.epoch,"candidate mapping membership",["mapping":String(mapping.ordinal),"picture":String(picture.ordinal),"grid":String(describing:Tick(grid.start)),"native":String(describing:picture.digestPTS)],evidence:evidence)
                    }
                    candidate=snapshot;candidateFence=fence;candidateCodec=codecURL;candidateFragment=count;candidateAdmissions=mappings.count;candidateOffered=receipts.count
                    try save(snapshot,root.appendingPathComponent("candidate.json"));try save(["fenceOrdinal":fence,"fragment":count,"admittedAtSelection":mappings.count,"offeredAtSelection":receipts.count],root.appendingPathComponent("candidate-fence.json"))
                } else if let candidate,let fence=candidateFence,let original=candidateCodec,let initial=candidateFragment,count>initial {
                    try save(["candidateFragment":initial,"laterFragment":count,"candidateAdmitted":candidateAdmissions!,"laterAdmitted":mappings.count,"candidateOffered":candidateOffered!,"laterOffered":receipts.count,"writerCloseCalled":0],root.appendingPathComponent("active-\(count)-comparison-receipt.json"))
                    try require(mappings.count>candidateAdmissions!,"extension lacks successful append after selection",["candidateAdmitted":String(candidateAdmissions!),"laterAdmitted":String(mappings.count),"candidateOffered":String(candidateOffered!),"laterOffered":String(receipts.count)],evidence:evidence)
                    try compare(Array(candidate.pictures.prefix(fence)),snapshot,evidence:evidence)
                    try compareLogical(original,codecURL,fence,script,root.appendingPathComponent("active-\(count)-logical-comparison.json"),evidence:evidence)
                    activePassed=true
                }
                lastCount=count;print("ACTIVE \(count) decoded \(snapshot.pictures.count) fence \(String(describing:candidateFence))")
            }
            for index in 0..<390 {
                let target=started.advanced(by:.nanoseconds(Int64(index)*1_000_000_000/30));if ContinuousClock.now<target{try await Task.sleep(until:target,clock:.continuous)}
                try require(started.duration(to:.now) < .seconds(20),"20 second writer bound",["index":String(index)],evidence:evidence)
                let hosted=try CaptureClockIngress.retime(samples[index%3],to:CMTimeAdd(time(microseconds:anchor),CMTime(value:Int64(index),timescale:30)),duration:CMTime(value:1,timescale:30))
                let admission=try writer.append(hosted,state:state);let receipt=IngressObservation(offeredOrdinal:index,receipt:admission.receipt,cameraFrame:admission.frame);receipts.append(receipt)
                if let frame=admission.frame{mappings.append(frame);observationBytes.append(try JSONEncoder().encode(Observation(cameraFrame:frame)));observationBytes.append(10)}
                try evidence.ingress(receipt);if index%3==0{try await observe()}
            }
            let end=started.advanced(by:.seconds(13));if ContinuousClock.now<end{try await Task.sleep(until:end,clock:.continuous)}
            while !activePassed && started.duration(to:.now) < .seconds(20){try await Task.sleep(for:.milliseconds(100));try await observe()}
            try require(activePassed && candidateFence != nil,"complete IDR plus further active extension unavailable",["fragments":String(lastCount),"fence":String(describing:candidateFence)],evidence:evidence)
            try observationBytes.write(to:root.appendingPathComponent("timestamps.jsonl"));try save(mappings,root.appendingPathComponent("accepted-mappings.json"))
            if mode=="interrupt" {
                evidence.preserve(mappings:mappings,observations:observationBytes,receipts:receipts,raw:raw)
                try save(["status":"ready-to-interrupt","fenceOrdinal":String(candidateFence!),"candidateCodec":candidateCodec!.path,"offered":"390","accepted":String(mappings.count),"fragments":String(lastCount)],root.appendingPathComponent("ready.json"))
                while true{try await Task.sleep(for:.milliseconds(100))}
            }
            clock.seal(at:anchor+13_000_000);let closed=await writer.close(clock:clock,failure:nil,observations:root.appendingPathComponent("timestamps.jsonl"));defer{closed.releaseJournal()}
            try require(closed.sealed && closed.failure==nil,"ordinary closure failed",["sealed":String(closed.sealed),"failure":String(describing:closed.failure)],evidence:evidence)
            // Closed bytes are read directly: finalization may relocate payloads. No offset normalization.
            let final=try await read(raw,phase:"ordinary-closed",fragments:try fragments(raw,evidence:evidence),evidence:evidence)
            let finalURL=root.appendingPathComponent("closed.json"),formatsURL=root.appendingPathComponent("closed-formats.json"),codecURL=root.appendingPathComponent("closed-codec.json")
            try save(final,finalURL);try save(try await formatFacts(raw,final,evidence:evidence),formatsURL);_ = try inspectBytes(raw,finalURL,formatsURL,codecURL,script,evidence:evidence)
            try compare(Array(candidate!.pictures.prefix(candidateFence!)),final,evidence:evidence);try compareLogical(candidateCodec!,codecURL,candidateFence!,script,root.appendingPathComponent("closed-logical-comparison.json"),evidence:evidence)
            try require(final.pictures.count==mappings.count,"complete closure admission inventory",["decoded":String(final.pictures.count),"admitted":String(mappings.count)],evidence:evidence)
            for (mapping,picture) in zip(mappings,final.pictures) {
                let grid=try mapping.acquisitionRange(scale:final.nativeScale)
                try require(mapping.ordinal==picture.ordinal && grid.start.value==picture.digestPTS.value && grid.start.timescale==picture.digestPTS.scale && grid.start.epoch==picture.digestPTS.epoch,"closed mapping membership",["ordinal":String(mapping.ordinal),"grid":String(describing:Tick(grid.start)),"native":String(describing:picture.digestPTS)],evidence:evidence)
            }
            try save(["status":"pass","fenceOrdinal":String(candidateFence!),"offered":"390","accepted":String(mappings.count),"tail":"Fence IDR and entire later coded sequence remain uncommitted; no duration tail chosen."],root.appendingPathComponent("verdict.json"))
        }catch{if let owner=ownership{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
    }
}
