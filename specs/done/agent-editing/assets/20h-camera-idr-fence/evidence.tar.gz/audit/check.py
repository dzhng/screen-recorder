"""Saved encoded bytes/control qualification only; never launches native code."""
import pathlib,sys,json,copy,importlib.util,hashlib
root=pathlib.Path(__file__).parent;script=root.parent/'codec.py'
spec=importlib.util.spec_from_file_location('frozen_codec',script);codec=importlib.util.module_from_spec(spec);spec.loader.exec_module(codec)
binding=json.loads((root/'bindings.json').read_text())
for x in binding['pins']:
    d=pathlib.Path(x['path']).read_bytes();assert len(d)==x['bytes'] and hashlib.sha256(d).hexdigest()==x['sha256']
movie=binding['pins'][2]['path'];snapshot=json.loads((root/'snapshot-projection.json').read_text());formats=json.loads((root/'byte-format.json').read_text())
refused=[]
for name in ['truncated-NAL','duplicate-DTS','invalid-clock']:
    bad=copy.deepcopy(snapshot)
    if name=='truncated-NAL':bad['cursorFacts'][24]['extents']['sample']['length']-=1
    elif name=='duplicate-DTS':bad['cursorFacts'][1]['clocks']['mediaDTS']=bad['cursorFacts'][0]['clocks']['mediaDTS']
    else:bad['segmentBounds'][0]['assetDuration']['flags']=4
    try:codec.inspect(movie,bad,formats)
    except AssertionError as error:refused.append({'case':name,'error':str(error)})
    else:raise AssertionError('accepted '+name)
result=codec.inspect(movie,snapshot,formats);assert result['completeIDRFenceOrdinals']==[29,58,87,116,145,174]
(root/'byte-facts.json').write_text(json.dumps(result,indent=2)+'\n')
# Comparison controls use authored changed saved facts, not a new native result.
base=root/'byte-facts.json';changed=copy.deepcopy(result);changed['rows'][24]['logical']['payloadBase64']='changed';altered=root/'changed-logical-control.json';altered.write_text(json.dumps(changed)+'\n')
try:codec.compare(base,altered,29,root/'changed-logical-operands.json')
except AssertionError:pass
else:raise AssertionError('accepted changed logical payload')
changes=json.loads((root/'changed-logical-operands.json').read_text());assert changes['differences']==[{'ordinal':24,'fields':['payloadBase64']}]
shifted=copy.deepcopy(result)
for row in shifted['rows']:row['physicalExtent']['offset']+=100
moved=root/'offset-control.json';moved.write_text(json.dumps(shifted)+'\n');codec.compare(base,moved,29,root/'offset-control-operands.json')
print(json.dumps({'status':'pass','completeSamples':197,'completeFences':result['completeIDRFenceOrdinals'],'negativeControls':refused,'changedLogicalPayloadRejectedWithFullOperands':True,'physicalOffsetOnlyControlAccepted':True,'scope':'Original retained bytes + authored saved-data controls only; no native format query/compile/decode/writer or active-prefix stability proof'},indent=2))
