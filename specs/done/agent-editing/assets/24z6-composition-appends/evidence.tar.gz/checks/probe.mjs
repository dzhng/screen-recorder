import { applyBatch } from '/Users/david/dev/screen-recorder/packages/composition/dist/index.js';
import { compositionSchema } from '/Users/david/dev/screen-recorder/packages/composition/dist/schema.js';
import { createHash } from 'node:crypto';
const parse = compositionSchema.safeParse.bind(compositionSchema);
let calls = 0, tracks = 0, clips = 0;
compositionSchema.safeParse = (document, ...args) => {
  calls++; tracks += document.tracks.length; clips += document.clips.length;
  return parse(document, ...args);
};
const input = { canvas: { width: 160, height: 96, fps: { numerator: 30, denominator: 1 }, background: '#000000ff' }, tracks: [], clips: [], groups: [], syncGroups: [], processing: [] };
const context = { namespace: 'probe', assets: [{ id: 'source', streams: [{ id: 'a', kind: 'audio', bounds: { startUs: 0, endUs: 1000 }, available: [{ startUs: 0, endUs: 1000 }] }] }] };
for (const size of [3, 70, 140]) {
  calls = tracks = clips = 0;
  const operations = Array.from({length: size}, (_, i) => [
    { operation: 'track.add', label: `t${i}`, track: { kind: 'audio', order: i } },
    { operation: 'place', label: `c${i}`, clip: { trackId: { label: `t${i}` }, assetId: 'source', streamId: 'a', source: { kind: 'range', range: { startUs: 0, endUs: 1000 } }, placement: { kind: 'project', range: { startUs: 0, endUs: 1000 } } } }
  ]).flat();
  const start = performance.now();
  const result = applyBatch(input, operations, context);
  console.log(JSON.stringify({size, calls, tracks, clips, elapsedMs: performance.now()-start, completeReceiptSHA256: createHash('sha256').update(JSON.stringify(result)).digest('hex'), bounded: calls <= 3 && tracks + clips <= size * 4}));
}
