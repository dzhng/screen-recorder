import hashlib,json,pathlib,tarfile,shutil,subprocess
root=pathlib.Path('/Users/david/.codex/worktrees/external-caller-fixture/screen-recorder')
asset=root/'specs/agent-editing/assets/25a-model-readiness'
old=root/'specs/agent-editing/assets/25-input-preparation'
first=pathlib.Path('/tmp/screenrec-25a-voice-ready-first'); reuse=pathlib.Path('/tmp/screenrec-25a-voice-ready-reuse')
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def verify_archive(p,pins):
 with tarfile.open(p) as t:
  files={m.name:m for m in t.getmembers() if m.isfile()}
  assert set(files)==set(pins)
  for k,v in pins.items():
   b=t.extractfile(files[k]).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'],k
 return {**pin(p),'members':len(files),'allMembersRehashed':True}
base=json.loads((old/'source-runtime-pins.json').read_text())
base_archive=verify_archive(old/'source-runtime.tar.gz',base)
delta={}; matches=[]
for k,v in base.items():
 if pin(root/k)!=v:delta[k]=pin(root/k)
 else:matches.append(k)
assert list(delta)==['specs/agent-editing/slices/25-agent-acceptance.md']
for k in ['packages/test-harness/editing/acceptance-voice-ready.mjs','specs/agent-editing/slices/25a-model-readiness.md','specs/agent-editing/assets/25-input-preparation/README.md']:
 delta[k]=pin(root/k)
with tarfile.open(asset/'source-delta.tar.gz','w:gz') as t:
 for k in delta:t.add(root/k,arcname=k,recursive=False)
source_delta=verify_archive(asset/'source-delta.tar.gz',delta)
resolution=json.loads((old/'module-resolution.json').read_text());ext=resolution['reusedExternal']
for k,v in ext.items():assert pin(k)=={x:v[x] for x in ['bytes','sha256']},k
native=root/'specs/agent-editing/assets/09c-native-audio-file'
nativepins=json.loads((native/'source-reference-pins.json').read_text())|json.loads((native/'source-final-delta-pins.json').read_text())
native_matches=[];archive_only=[]
for k,v in nativepins.items():
 if not (root/k).exists():
  assert k=='helpers/denoise/.build/rnnoise/rnnoise_data.c';archive_only.append(k)
 else:assert pin(root/k)==v,k;native_matches.append(k)
node=pathlib.Path('/Users/david/.nvm/versions/node/v24.14.0/bin/node')
nodepin=json.loads((root/'specs/agent-editing/assets/09c-audio-export/external-tools-pins.json').read_text())[str(node).lstrip('/')]
assert pin(node)==nodepin
r1=json.loads((first/'report.json').read_text());r2=json.loads((reuse/'report.json').read_text())
assert r1['passed'] and r2['passed'] and r2['before']==r2['after'] and r1['before']==r1['after']
assert r2['initial']=={'state':'ready'}
progress=[]
for e in r1['exchanges']:
 response=e['response']; data=response.get('structuredContent',response).get('data',{})
 if data.get('state')=='preparing':progress.append(data)
assert all(v['totalBytes']==3004417962 for v in progress)
received=[v['receivedBytes'] for v in progress]
assert received==sorted(received) and max(received)>0

ready={'scope':'Registered readiness only; fresh external caller generation/edit/delivery remains separate','callerInputs':str(reuse/'prior-caller-inputs.json'),'libraryHome':r2['home'],'projectId':'1463f786-68d9-4303-9f7b-f86bc0cb98c2','revisionId':'73f31656-d0f2-4780-a132-db138697283a','modelId':'qwen3-tts-icl-v1','status':r2['ready'],'preparedVoice':r2['preparedVoice'],'parakeet':{'state':'absent'},'literalOccurrenceCaption':{'kind':'content','requires':'Actual generated parent clip ID and selected source interval; no ASR word rows needed'},'acceptance':False}
save(reuse/'caller-model-readiness.json',ready)
shutil.copyfile(root/'packages/test-harness/editing/acceptance-voice-ready.mjs',reuse/'executed-runner.mjs')
shutil.copyfile(pathlib.Path(__file__),reuse/'packet-producer.py')
home=pathlib.Path(r2['home'])/'library'
assert not (home/'catalog.sqlite-wal').exists(), 'Catalog must be closed before snapshot'
shutil.copyfile(home/'catalog.sqlite',reuse/'closed-catalog.sqlite')
mp=home/'models/qwen3-tts-icl-v1/1eccf1cb2519b5a4e8a95b5f0544f3303568164f'
shutil.copyfile(mp/'receipt.json',reuse/'genuine-managed-receipt.json')
evidence={}
with tarfile.open(asset/'evidence.tar.gz','w:gz') as t:
 for label,d in [('adoption',first),('ready-reuse',reuse)]:
  for p in sorted(d.iterdir()):
   assert p.is_file();k=label+'/'+p.name;evidence[k]=pin(p);t.add(p,arcname=k,recursive=False)
 for label in ['first','reuse']:
  p=pathlib.Path('/tmp/screenrec-25a-voice-ready-'+label+'.log');k=label+'-run.log';evidence[k]=pin(p);t.add(p,arcname=k,recursive=False)
archive=verify_archive(asset/'evidence.tar.gz',evidence)
save(asset/'evidence-pins.json',evidence)
save(asset/'source-runtime-pins.json',{'base':{'manifest':'../25-input-preparation/source-runtime-pins.json','archive':'../25-input-preparation/source-runtime.tar.gz',**base_archive},'currentBaseMatches':len(matches),'changedBaseEntries':list(set(base)&set(delta)),'delta':delta,'deltaArchive':source_delta,'externalRuntime':{'manifest':'../25-input-preparation/module-resolution.json','reusedFiles':len(ext),'allCurrentHashesMatch':True,'archive':'../09c-audio-export/external-runtime.tar.gz'},'native':{'matches':len(native_matches),'archiveOnly':archive_only,'sources':'../09c-native-audio-file/source-reference-pins.json + source-final-delta-pins.json','worker':r2['after']['worker']},'node':{'path':str(node),**nodepin}})
save(asset/'verification.json',{'passed':True,'scope':r2['scope'],'sourceCommitBeforePass':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'libraryHome':r2['home'],'mainProjectId':ready['projectId'],'mainRevisionId':ready['revisionId'],'mainProjectUnedited':True,'adoption':{'report':'evidence.tar.gz:adoption/report.json','exchanges':len(r1['exchanges']),'initial':r1['initial'],'refusal':r1['refusal'],'progressReplies':len(progress),'progress':{'receivedBytesMonotonic':True,'maximumObservedBytes':max(received),'totalBytes':progress[0]['totalBytes']},'terminalServicePids':sorted(set(v['pid'] for v in r1['processes'])),'diagnostic':'First producer repeated the already-terminal second PID in finally; raw producer and report retained unchanged.'},'readyReuse':{'report':'evidence.tar.gz:ready-reuse/report.json','exchanges':len(r2['exchanges']),'initial':r2['initial'],'reopened':r2['reopened'],'terminalProcesses':r2['processes']},'nativeOperations':sorted(set(v['operation'] for v in r2['nativeOperations'])),'models':{'voice':r2['ready'],'parakeet':{'state':'absent'},'preparedVoice':r2['preparedVoice']},'preservation':{'registeredSourceFiles':len(r2['before']['model']),'runtimeEntries':len(r2['before']['runtime']),'runtimeBytes':488274953,'modelBytes':2516143009,'sourceHashesAndModesAndLinksVerifiedBeforeAndAfter':True,'originalDurableHomeFilesAndReceiptIdentityUnchanged':True,'frozenWorkerUnchanged':True},'literalAnchor':r2['literalAnchor'],'callerReadinessFile':str(reuse/'caller-model-readiness.json'),'checks':{'publicAdoptionExitCode':0,'readyReuseExitCode':0,'syntax':0,'format':0,'lint':0},'performance':'unmeasured','remaining':['Actual fresh external caller public generation, edits, delivery and recovery','Relevant integrated visual/media acceptance; no new quality or physical verdict','Historical raw narration transcript is not adopted as a canonical current receipt'],'review':'manual shape/code/docs/choices; no CLI review retry or Claude'})
save(asset/'archive-verification.json',{'passed':True,'baseSource':base_archive,'sourceDelta':source_delta,'evidence':archive,'currentExternalRuntimeMatches':len(ext),'currentNativeSourceMatches':len(native_matches),'generatedNativeArchiveOnly':archive_only})
print(json.dumps({'evidence':archive,'sourceDelta':source_delta,'sourceBase':base_archive,'nativeMatches':len(native_matches),'externalMatches':len(ext)}))
