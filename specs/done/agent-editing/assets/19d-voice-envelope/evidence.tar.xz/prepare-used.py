import json,pathlib,sys,numpy as np
from scipy.io import wavfile
from transformers import AutoTokenizer
root=pathlib.Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder');out=pathlib.Path('/tmp/screenrec-19d-envelope');out.mkdir()
cases=json.loads((root/'packages/test-harness/editing/voice/cases.json').read_text());ref=root/'specs/agent-editing/assets/18-voice/reference.wav'
rate,audio=wavfile.read(ref);assert rate==24000 and audio.shape==(120000,) and audio.dtype==np.float32
tokenizer=AutoTokenizer.from_pretrained('/tmp/screenrec-voice-model',local_files_only=True)
def count(text):return len(tokenizer.encode(f'<|im_start|>assistant\n{text}<|im_end|>\n<|im_start|>assistant\n')[3:-5])
sentence='Okay, so this is the recorder workbench.'
def text_at(target):
 text=''
 # Complete sentences only; backtracking on the final small remainder.
 options=[sentence,'This is the recorder workbench.','Okay.','Yes.','This works.']
 def finish(prefix):
  n=count(prefix)
  if n==target:return prefix
  if n>target:return None
  for option in options:
   value=prefix+' '+option if prefix else option
   if count(value)<=target:
    result=finish(value)
    if result:return result
  return None
 while count((text+' '+sentence).strip())<target-15:text=(text+' '+sentence).strip()
 result=finish(text);assert result and count(result)==target;return result
texts={str(n):text_at(n) for n in (256,1024)}
references={1:str(ref)}
for repeats in (2,4):
 path=out/f'reference-{repeats}x.wav';wavfile.write(path,rate,np.tile(audio,repeats));references[repeats]=str(path)
trials=[('frozen-phrase',cases['replacements'][1]['text'],1,256),('reference-10s',sentence,2,256),('reference-20s',sentence,4,256),('text-256',texts['256'],1,256),('text-1024',texts['1024'],1,256),('output-512',texts['1024'],1,512),('output-1024',texts['1024'],1,1024),('combined',texts['1024'],4,1024)]
plan=[]
for name,text,repeats,budget in trials:
 req={'reference':references[repeats],'referenceText':' '.join([cases['reference']['text']]*repeats),'text':text,'generation':dict(cases['generation'],max_tokens=budget),'seed':cases['seed']}
 (out/(name+'.request.json')).write_text(json.dumps(req,indent=2)+'\n');plan.append({'id':name,'targetTokens':count(text),'referenceRepeats':repeats,'referenceKind':'frozen continuous5s' if repeats==1 else 'synthetic repeated frozen5s PCM and transcript','maxTokens':budget})
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(plan,indent=2))
