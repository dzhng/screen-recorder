import json,sys,inspect,hashlib
from pathlib import Path
import mlx.core as mx
from mlx_audio.tts.models.qwen3_tts.qwen3_tts import Model
source=Path(inspect.getfile(Model));report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Sampler-only synthetic logits and seed binding, no model weights or speech generation','seed':[],'sampling':[]}
for value in [-1,0,2**32-1,2**32,2**64-1,2**64,1.0,True]:
 row={'input':value,'pythonType':type(value).__name__}
 try:mx.random.seed(value);row['accepted']=True;row['key']=mx.random.key(value).tolist()
 except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
 report['seed'].append(row)
for vocabulary in [3072,2048]:
 for parameter,value in [('temperature',0),('temperature',1e-45),('temperature',1e-38),('temperature',1e-6),('temperature',.9),('temperature',1e6),('temperature',1e38),('temperature',1e308),('repetition_penalty',1.5),('repetition_penalty',1e38),('repetition_penalty',1e308),('top_k',0),('top_k',vocabulary-1),('top_k',vocabulary),('top_p',1e-45),('top_p',1.0)]:
  row={'vocabulary':vocabulary,'parameter':parameter,'value':value,'dtype':'bfloat16'}
  def trace(frame,event,arg):
   if frame.f_code is not Model._sample_token.__code__:return None
   if event=='return':
    logits=frame.f_locals['logits'];mx.eval(logits)
    row['logitsNaN']=bool(mx.any(mx.isnan(logits)).item());row['logitsPositiveInfinity']=bool(mx.any(logits==mx.inf).item());row['finiteLogits']=int(mx.sum(mx.isfinite(logits)).item())
   return trace
  try:
   mx.random.seed(18);logits=mx.linspace(-20,20,vocabulary).astype(mx.bfloat16)[None,None,:]
   sys.settrace(trace)
   token=Model._sample_token(None,logits,generated_tokens=[vocabulary-1],**{parameter:value});mx.eval(token)
   row.update(accepted=True,token=token.tolist())
  except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
  finally:sys.settrace(None)
  report['sampling'].append(row)
print(json.dumps(report,indent=2))
