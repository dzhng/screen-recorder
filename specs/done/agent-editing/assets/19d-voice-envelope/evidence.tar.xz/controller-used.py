import pathlib,json,subprocess,os,time,math
root=pathlib.Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder');out=pathlib.Path('/tmp/screenrec-19d-envelope');plan=json.loads((out/'plan.json').read_text());limit=12*1024**3
summary={'passed':False,'residentLimitBytes':limit,'attempts':[]};env=dict(os.environ,HF_HOME=str(out/'cache'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1');previous=None
try:
 for trial in plan:
  name=trial['id'];request=json.loads((out/(name+'.request.json')).read_text())
  # Conservative linear extrapolation of whole observed RSS against total context+output positions.
  projected_positions=11+trial['referenceRepeats']*11+trial['targetTokens']+math.ceil(trial['referenceRepeats']*120000/1920)+trial['maxTokens']
  projection=None if previous is None else previous['peakResidentBytes']*max(1,projected_positions/previous['positions'])
  assert projection is None or projection<limit,('Projected unsafe next case',trial,projection)
  cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/private/tmp/screenrec-19b-relocation/bundle/python/bin/python3.12','-I','-B',str(root/'packages/test-harness/editing/voice/settings.py'),'--bundle','/private/tmp/screenrec-19b-relocation/bundle','--model','/tmp/screenrec-voice-model','--request',str(out/(name+'.request.json')),'--output',str(out/(name+'.wav')),'--report',str(out/(name+'.json')),'--envelope']
  row={'id':name,'command':cmd,'projectedPeakResidentBytes':projection,'samples':[]};summary['attempts'].append(row);start=time.monotonic()
  with (out/(name+'.log')).open('x') as log:
   process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
   try:
    while process.poll() is None:
     sample=subprocess.run(['ps','-o','rss=','-p',str(process.pid)],capture_output=True,text=True)
     if sample.stdout.strip():
      rss=int(sample.stdout.strip())*1024;row['samples'].append({'seconds':time.monotonic()-start,'residentBytes':rss})
      if rss>limit:row['stopped']='resident limit';process.kill();break
     if time.monotonic()-start>600:row['stopped']='600s existing deadline';process.kill();break
     time.sleep(.25)
   finally:
    if process.poll() is None:process.kill()
    row['exitCode']=process.wait();row['wallSeconds']=time.monotonic()-start
  (out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n');assert row['exitCode']==0,row
  result=json.loads((out/(name+'.json')).read_text());assert result['passed'] and result['prefill']['targetTextTokens']==trial['targetTokens'];assert result['peakResidentBytes']<limit and result['output']['mlxPeakBytes']<limit
  if name=='frozen-phrase':assert (out/(name+'.wav')).read_bytes()==(root/'specs/agent-editing/assets/18-voice/same-take-phrase.wav').read_bytes()
  previous={'peakResidentBytes':result['peakResidentBytes'],'positions':result['prefill']['inputTokens']+trial['maxTokens']}
  print(json.dumps({'id':name,'prefill':result['prefill'],'termination':result['termination'],'peakResidentBytes':result['peakResidentBytes'],'wallSeconds':row['wallSeconds']}),flush=True)
 summary['passed']=True
finally:(out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n')
