#import "FrameStageObserver.h"
#import <objc/runtime.h>
#import <string.h>

typedef void (*RenderIMP)(id, SEL, CIImage *, CVPixelBufferRef, CGRect, CGColorSpaceRef);
typedef CGImageRef (*ImageIMP)(id, SEL, CIImage *, CGRect);
static Method renderMethod, imageMethod;
static IMP originalRender, originalImage;
static CIContext *wantedContext;
static CIImage *capturedGraph;
static CGImageRef capturedImage;
static NSUInteger renderCalls, renderDelegations, imageCalls, imageDelegations;
static BOOL restored;
static NSString *renderEncoding, *imageEncoding;
static CGRect renderedBounds, imageBounds;
static NSString *receiverClass;

static void observeRender(id receiver, SEL selector, CIImage *image,
                          CVPixelBufferRef buffer, CGRect bounds, CGColorSpaceRef color) {
    BOOL selected = receiver == wantedContext;
    if (selected) {
        renderCalls++;
        capturedGraph = image;
        renderedBounds = bounds;
    }
    ((RenderIMP)originalRender)(receiver, selector, image, buffer, bounds, color);
    if (selected) renderDelegations++;
}

static CGImageRef observeImage(id receiver, SEL selector, CIImage *image, CGRect bounds) {
    BOOL selected = receiver == wantedContext;
    if (selected) { imageCalls++; imageBounds = bounds; }
    CGImageRef rendered = ((ImageIMP)originalImage)(receiver, selector, image, bounds);
    if (selected) {
        imageDelegations++;
        if (capturedImage) CGImageRelease(capturedImage);
        capturedImage = rendered ? CGImageRetain(rendered) : NULL;
    }
    return rendered;
}

static BOOL typeIs(NSMethodSignature *signature, NSUInteger index, const char *type) {
    return strcmp([signature getArgumentTypeAtIndex:index], type) == 0;
}

BOOL FrameStageBegin(CIContext *context) {
    renderMethod = class_getInstanceMethod(object_getClass(context),
        @selector(render:toCVPixelBuffer:bounds:colorSpace:));
    imageMethod = class_getInstanceMethod(object_getClass(context),
        @selector(createCGImage:fromRect:));
    if (!renderMethod || !imageMethod) return NO;
    renderEncoding = @(method_getTypeEncoding(renderMethod));
    imageEncoding = @(method_getTypeEncoding(imageMethod));
    NSMethodSignature *render = [NSMethodSignature signatureWithObjCTypes:renderEncoding.UTF8String];
    NSMethodSignature *image = [NSMethodSignature signatureWithObjCTypes:imageEncoding.UTF8String];
    if (render.numberOfArguments != 6 || image.numberOfArguments != 4 ||
        strcmp(render.methodReturnType, @encode(void)) != 0 ||
        strcmp(image.methodReturnType, @encode(CGImageRef)) != 0 ||
        [render getArgumentTypeAtIndex:2][0] != '@' ||
        [image getArgumentTypeAtIndex:2][0] != '@' ||
        !typeIs(render, 3, @encode(CVPixelBufferRef)) ||
        !typeIs(render, 4, @encode(CGRect)) ||
        !typeIs(render, 5, @encode(CGColorSpaceRef)) ||
        !typeIs(image, 3, @encode(CGRect))) return NO;
    receiverClass = NSStringFromClass(object_getClass(context));
    renderedBounds = imageBounds = CGRectZero;
    wantedContext = context;
    capturedGraph = nil;
    if (capturedImage) CGImageRelease(capturedImage);
    capturedImage = NULL;
    renderCalls = renderDelegations = imageCalls = imageDelegations = 0;
    restored = NO;
    originalRender = method_setImplementation(renderMethod, (IMP)observeRender);
    originalImage = method_setImplementation(imageMethod, (IMP)observeImage);
    return YES;
}

void FrameStageEnd(void) {
    method_setImplementation(renderMethod, originalRender);
    method_setImplementation(imageMethod, originalImage);
    restored = method_getImplementation(renderMethod) == originalRender &&
               method_getImplementation(imageMethod) == originalImage;
    wantedContext = nil;
}

CIImage *FrameStageGraph(void) { return capturedGraph; }
CGImageRef FrameStagePreencode(void) { return capturedImage; }
NSDictionary *FrameStageObservation(void) {
    return @{
        @"receiverClass": receiverClass ?: @"unavailable",
        @"originalRenderIMP": [NSString stringWithFormat:@"%p", originalRender],
        @"originalImageIMP": [NSString stringWithFormat:@"%p", originalImage],
        @"restoredRenderIMP": [NSString stringWithFormat:@"%p", method_getImplementation(renderMethod)],
        @"restoredImageIMP": [NSString stringWithFormat:@"%p", method_getImplementation(imageMethod)],
        @"imageBounds": @[@(imageBounds.origin.x), @(imageBounds.origin.y),
                            @(imageBounds.size.width), @(imageBounds.size.height)],
        @"renderSelector": @"render:toCVPixelBuffer:bounds:colorSpace:",
        @"imageSelector": @"createCGImage:fromRect:",
        @"renderTypeEncoding": renderEncoding ?: @"unavailable",
        @"imageTypeEncoding": imageEncoding ?: @"unavailable",
        @"renderCalls": @(renderCalls), @"renderDelegations": @(renderDelegations),
        @"imageCalls": @(imageCalls), @"imageDelegations": @(imageDelegations),
        @"restoredOriginalImplementations": @(restored),
        @"renderBounds": @[@(renderedBounds.origin.x), @(renderedBounds.origin.y),
                             @(renderedBounds.size.width), @(renderedBounds.size.height)]
    };
}
