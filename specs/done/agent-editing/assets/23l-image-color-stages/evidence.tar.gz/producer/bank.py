from pathlib import Path
import hashlib,json,tarfile,gzip,io
base=Path('/tmp/screenrec-23l-one-image-stage-successor');wt=Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder');asset=wt/'specs/agent-editing/assets/23l-image-color-stages'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files={}
for p in base.iterdir():
 if p.is_file() and p.name not in ('bank.py','bank.stdout','bank.stderr'):files['producer/'+p.name]=p
for p in (base/'run').iterdir():
 if p.is_file():files['run/'+p.name]=p
sdk=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/System/Library/Frameworks/CoreGraphics.framework/Headers')
for n in ('CGColorSpace.h','CoreGraphics.apinotes'):files['sdk/'+n]=sdk/n
files['producer/bank.py']=Path(__file__)
archive=asset/'evidence.tar.gz';payloads={};seen={}
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,p in sorted(files.items()):
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo(name);info.mode=0o644
    payloads[name]={'bytes':len(data),'sha256':h}
    if h in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[h];t.addfile(info)
    else:info.size=len(data);t.addfile(info,io.BytesIO(data));seen[h]=name
before=json.loads((base/'execution-before.json').read_text());after=json.loads((base/'execution-after.json').read_text());assert before['pins']==after['pins'] and not after['mismatches']
results=json.loads((base/'run/comparison.json').read_text());(asset/'results.json').write_text(json.dumps(results,indent=2)+'\n')
manifest={'base':'fba91e05545243f982af625153a4f6bd9efd8548','kind':'one-image stage diagnostic; no production change','status':'completed with exact terminal-route pixel difference; no tolerance/quality release pass','archive':{'file':'evidence.tar.gz',**pin(archive)},'payloads':payloads,'storage':'Lossless tar hardlinks share exact duplicate file bytes; each logical payload retains its own length/hash. Frozen objects/modules/worker, fixed input/report and historical packet remain referenced by existing authority, not duplicated.','originalCompileFailure':{'file':'compile-failure.tar.gz',**pin(asset/'compile-failure.tar.gz')},'processes':json.loads((base/'execution-processes.json').read_text()),'toolSessions':{'successorRunner':{'sessionId':62655,'actualExitCode':0},'offlineComparison':{'sessionId':9125,'actualExitCode':0,'pidRetained':False}},'executedSources':{n:pin(base/n) for n in ('ColorStages.swift','FrameStageObserver.h','FrameStageObserver.m','execute.py','compare.py')},'executedBinary':{'preservedAt':str(base/'color-stages'),**pin(base/'color-stages')},'immediatePreservation':{'pinsChecked':before['checked'],'before':pin(base/'execution-before.json'),'after':pin(base/'execution-after.json'),'allEqual':True},'restrictions':{'imageDiagnosticAttempts':1,'diagnosticBoundSeconds':30,'existingPixelReaderCommands':4,'movieDecoderInvocations':0,'modelOrServiceOperations':0,'workerOrModuleRebuilds':0,'productionEdits':0,'tolerancePolicy':None,'privateHalfFloatSamplesObserved':False,'historicalDecoderCauseProved':False,'workerBinaryEquivalenceClaimed':False},'meaning':'Input/direct/same compiled graph direct normalized RGBA equal in all bytes. Only the same graph through actual Rec.709 BGRA terminal/publication changes this fixed PNG. Exact route localization is sufficient to investigate shared graph publication; it does not isolate an internal rounding operation or prove historical decoder-buffer equality.'}
(asset/'verification.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(payloads)
 for n,p in payloads.items():
  b=t.extractfile(n).read();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256']
print(json.dumps({'archive':pin(archive),'logicalPayloads':len(payloads),'uniquePayloads':len(seen),'logicalBytes':sum(x['bytes'] for x in payloads.values()),'allPayloadsVerified':True,'executedBinary':manifest['executedBinary']},indent=2))
