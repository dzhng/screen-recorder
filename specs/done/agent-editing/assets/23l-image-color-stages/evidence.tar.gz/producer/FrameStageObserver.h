#import <CoreImage/CoreImage.h>
#import <CoreVideo/CoreVideo.h>
#import <Foundation/Foundation.h>

BOOL FrameStageBegin(CIContext *context);
void FrameStageEnd(void);
CIImage * _Nullable FrameStageGraph(void);
CGImageRef _Nullable FrameStagePreencode(void) CF_RETURNS_NOT_RETAINED;
NSDictionary *FrameStageObservation(void);
