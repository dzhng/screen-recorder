import datetime, hashlib, json, os, subprocess, sys, time
from pathlib import Path
base=Path('/tmp/screenrec-23l-one-image-stage-successor')
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 p=Path(p); h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def collect(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys(): return [v]
  return sum((collect(x) for x in v.values()),[])
 if isinstance(v,list): return sum((collect(x) for x in v),[])
 return []
pins=collect(json.loads((base/'successor-pins.json').read_text()))
pins=list({x['path']:x for x in pins}.values())
def verify(name):
 got=[digest(p['path']) for p in pins]
 mismatches=[{'expected':p,'actual':g} for p,g in zip(pins,got) if any(p[k]!=g[k] for k in ('bytes','sha256'))]
 (base/name).write_text(json.dumps({'at':stamp(),'checked':len(got),'pins':got,'mismatches':mismatches},indent=2)+'\n')
 if mismatches: raise RuntimeError(f'{name}: {len(mismatches)} changed pins')
plan=json.loads((base/'build-plan.json').read_text())
for target in ('observer.o','color-stages','run'):
 if (base/target).exists(): raise RuntimeError(f'prospective output already exists: {target}')
verify('execution-before.json')
records=[]
(base/'execute-source-pin.json').write_text(json.dumps(digest(__file__),indent=2)+'\n')
def run(label,args,timeout=None):
 stdout=base/(label+'.stdout');stderr=base/(label+'.stderr')
 with stdout.open('wb') as out,stderr.open('wb') as err:
  started=stamp(); t=time.monotonic(); child=subprocess.Popen(args,cwd=base,stdout=out,stderr=err)
  record={'label':label,'args':args,'cwd':str(base),'pid':child.pid,'startedAt':started,'timeoutSeconds':timeout}
  records.append(record); print(json.dumps({'event':'spawn',**record}),flush=True)
  (base/'execution-processes.json').write_text(json.dumps(records,indent=2)+'\n')
  try: code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   record['timedOut']=True;child.kill();code=child.wait()
  record.update(endedAt=stamp(),elapsedSeconds=time.monotonic()-t,exitCode=code,stdout=digest(stdout),stderr=digest(stderr))
  (base/'execution-processes.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps({'event':'terminal','label':label,'pid':child.pid,'exitCode':code,'elapsedSeconds':record['elapsedSeconds']}),flush=True)
  if code!=0 or record.get('timedOut'): raise RuntimeError(f'{label} failed: exit {code}, timeout {record.get("timedOut",False)}')
try:
 for i,args in enumerate(plan['compileCommands']): run('compile-'+str(i+1),args)
 (base/'executable-pin.json').write_text(json.dumps(digest(base/'color-stages'),indent=2)+'\n')
 run('diagnostic',plan['diagnosticCommand'],30)
 for i,args in enumerate(plan['pixelReaderCommands']): run('pixels-'+str(i+1),args,30)
except Exception as error:
 (base/'execution-failure.json').write_text(json.dumps({'at':stamp(),'error':str(error)},indent=2)+'\n')
 print(str(error),file=sys.stderr,flush=True)
 sys.exitcode=1
else: sys.exitcode=0
finally: verify('execution-after.json')
sys.exit(sys.exitcode)
