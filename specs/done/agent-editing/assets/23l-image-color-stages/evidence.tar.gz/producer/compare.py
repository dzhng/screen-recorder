from pathlib import Path
import collections, hashlib, json, time
base=Path('/tmp/screenrec-23l-one-image-stage-successor');folder=base/'run'
def pin(p):
 b=p.read_bytes();return {'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
report=json.loads((folder/'report.json').read_text());assert report['completed']
width=3120;height=1970;size=width*height*4
names=['input','direct','graph-direct','graph-terminal'];data={n:(folder/(n+'.rgba')).read_bytes() for n in names}
assert all(len(b)==size for b in data.values())
assert hashlib.sha256(data['input']).hexdigest()=='e965f56f66365d9a3a7ea743d88fcbcd898d74f36a42e83de6a0d784ce6aa4a0'
for i in range(1,5):
 r=json.loads((base/f'pixels-{i}.stdout').read_text());assert r['width']==width and r['height']==height and r['opaque'] and r['sourceProfileSHA256']=='2b3aa1645779a9e634744faf9b01e9102b0c9b88fd6deced7934df86b949af7e'
def compare(a,b):
 if a==b:return {'equal':True,'bytes':len(a),'changedPixels':0,'changedSamples':0,'channelDeltas':{c:{} for c in 'RGBA'}}
 hist={c:collections.Counter() for c in 'RGBA'};changed=0;border=0;first=[]
 for pos in range(0,len(a),4):
  old=a[pos:pos+4];new=b[pos:pos+4]
  if old==new:continue
  changed+=1;pixel=pos//4;x=pixel%width;y=pixel//width
  if x in (0,width-1) or y in (0,height-1):border+=1
  if len(first)<4:first.append({'x':x,'y':y,'before':list(old),'after':list(new)})
  for c,o,n in zip('RGBA',old,new):
   if o!=n:hist[c][n-o]+=1
 return {'equal':False,'bytes':len(a),'changedPixels':changed,'changedSamples':sum(sum(v.values()) for v in hist.values()),'changedOuterBorderPixels':border,'channelDeltas':{c:dict(sorted(v.items())) for c,v in hist.items()},'firstDifferences':first}
pairs={}
for i,a in enumerate(names):
 for b in names[i+1:]:pairs[a+' -> '+b]=compare(data[a],data[b])
providers={}
for n in names:
 meta=report['input']['image'] if n=='input' else report[n]['preencode'];v=(folder/meta['completeProviderData']['file']).read_bytes();activeBytes=meta['bytesPerRow']*meta['height']
 assert len(v)==meta['completeProviderData']['bytes'] and hashlib.sha256(v).hexdigest()==meta['completeProviderData']['sha256']
 assert meta['bitsPerComponent']==8 and meta['bitsPerPixel']==32 and meta['bytesPerRow']==width*4
 providers[n]={'complete':pin(folder/meta['completeProviderData']['file']),'activeRowsBytes':activeBytes,'providerBeyondDeclaredRowsBytes':len(v)-activeBytes,'activeRowsExactlyEqualNormalizedRGBA':v[:activeBytes]==data[n],'tailSha256':hashlib.sha256(v[activeBytes:]).hexdigest()}
raw={n:(folder/(('input.raw') if n=='input' else n+'-preencode.raw')).read_bytes() for n in names}
providerPairs={a+' -> '+b:{'fullProviderEqual':raw[a]==raw[b],'sameLength':len(raw[a])==len(raw[b]),'activeRowsEqual':raw[a][:size]==raw[b][:size]} for i,a in enumerate(names) for b in names[i+1:]}
terminal=(folder/'terminal-bgra.raw').read_bytes();assert len(terminal)==size and report['terminal']['pixelFormat']==1111970369
channels={c:{str(k):v for k,v in sorted(collections.Counter(terminal[i::4]).items())} for i,c in enumerate('BGRA')}
result={'question':'Fixed retained PNG through existing direct publication, same compiled graph direct publication, and same graph Rec.709 BGRA terminal/publication','dimensions':{'width':width,'height':height},'normalizedSamples':{n:pin(folder/(n+'.rgba')) for n in names},'allPairs':pairs,'preencodeProviders':providers,'providerComparisons':providerPairs,'terminal':{'completeRows':pin(folder/'terminal-bgra.raw'),'declaredBGRAChannelHistogram':channels,'comparisonLimit':'Rec.709 terminal values are retained in their actual representation; raw channel differences from sRGB are not treated as color-equivalence failures.'},'tolerance':None,'historicalDecoderCauseProved':False,'privateHalfFloatFramebufferObserved':False}
(folder/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
(base/'compare-source-pin.json').write_text(json.dumps(pin(Path(__file__)),indent=2)+'\n')
print(json.dumps({'allPairs':pairs,'providerComparisons':providerPairs,'allProviderActiveRowsEqualNormalizedRGBA':all(x['activeRowsExactlyEqualNormalizedRGBA'] for x in providers.values())},indent=2))
