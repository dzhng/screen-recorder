import CoreGraphics
import CoreImage
import CoreVideo
import CryptoKit
import Foundation
import ImageIO
@testable import ScreenRecorderFrames
import ScreenRecorderMedia

@main final class ColorStages {
    let folder: URL
    var report: [String: Any] = [:]
    init(folder: URL) { self.folder = folder }
    func hash(_ bytes: Data) -> String {
        SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
    }
    func save(_ name: String, _ bytes: Data) throws -> [String: Any] {
        try bytes.write(to: folder.appendingPathComponent(name), options: .withoutOverwriting)
        return ["file": name, "bytes": bytes.count, "sha256": hash(bytes)]
    }
    func color(_ value: CGColorSpace?, _ name: String) throws -> [String: Any] {
        guard let value else { return ["present": false] }
        var info: [String: Any] = [
            "name": value.name.map { $0 as String } ?? "unnamed",
            "model": value.model.rawValue, "components": value.numberOfComponents,
        ]
        if let icc = value.copyICCData() { info["icc"] = try save(name + ".icc", icc as Data) }
        return info
    }
    func image(_ value: CGImage, _ name: String) throws -> [String: Any] {
        guard let data = value.dataProvider?.data else { throw failure("Missing CGImage provider data") }
        return [
            "width": value.width, "height": value.height,
            "bitsPerComponent": value.bitsPerComponent, "bitsPerPixel": value.bitsPerPixel,
            "bytesPerRow": value.bytesPerRow, "bitmapInfo": value.bitmapInfo.rawValue,
            "alphaInfo": value.alphaInfo.rawValue,
            "colorSpace": try color(value.colorSpace, name),
            "completeProviderData": try save(name + ".raw", data as Data),
        ]
    }
    func context(_ value: CIContext, _ name: String) throws -> [String: Any] {
        ["workingFormat": value.workingFormat.rawValue,
         "workingColorSpace": try color(value.workingColorSpace, name)]
    }
    func jsonValue(_ value: Any, _ name: String) throws -> Any {
        if let string = value as? String { return string }
        if let number = value as? NSNumber { return number }
        if CFGetTypeID(value as CFTypeRef) == CGColorSpace.typeID {
            return try color(unsafeBitCast(value as CFTypeRef, to: CGColorSpace.self), name)
        }
        if let data = value as? Data { return try save(name + ".data", data) }
        if let dictionary = value as? [String: Any] {
            var result: [String: Any] = [:]
            for (key, entry) in dictionary { result[key] = try jsonValue(entry, name + "-" + key) }
            return result
        }
        if let array = value as? [Any] {
            return try array.enumerated().map { try jsonValue($0.element, name + "-\($0.offset)") }
        }
        throw failure("Unsupported attachment type \(CFGetTypeID(value as CFTypeRef)): \(value)")
    }
    func buffer(_ value: CVPixelBuffer) throws -> [String: Any] {
        guard CVPixelBufferLockBaseAddress(value, .readOnly) == kCVReturnSuccess else {
            throw failure("Cannot lock terminal buffer")
        }
        defer { CVPixelBufferUnlockBaseAddress(value, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(value) else { throw failure("Missing terminal samples") }
        let height = CVPixelBufferGetHeight(value), stride = CVPixelBufferGetBytesPerRow(value)
        var attachments: [String: Any] = [:]
        for (name, mode) in [("propagating", CVAttachmentMode.shouldPropagate),
                             ("nonpropagating", CVAttachmentMode.shouldNotPropagate)] {
            let values = CVBufferCopyAttachments(value, mode) as? [String: Any] ?? [:]
            var converted: [String: Any] = [:]
            for (key, attachment) in values {
                converted[key] = try jsonValue(attachment, "terminal-\(name)-\(key)")
            }
            attachments[name] = converted
        }
        return ["width": CVPixelBufferGetWidth(value), "height": height,
                "pixelFormat": CVPixelBufferGetPixelFormatType(value), "bytesPerRow": stride,
                "planeCount": CVPixelBufferGetPlaneCount(value), "attachments": attachments,
                "completeRowsIncludingPadding": try save("terminal-bgra.raw", Data(bytes: base, count: height * stride))]
    }
    func observe<T>(_ context: CIContext, _ body: () throws -> T) throws -> T {
        guard FrameStageBegin(context) else { throw failure("Unsupported Core Image method ABI") }
        defer { FrameStageEnd() }
        return try body()
    }
    func publication(_ name: String, _ image: FrameImage, _ context: CIContext) throws {
        let png = try observe(context) { try image.png(context: context) }
        let observation = FrameStageObservation() as! [String: Any]
        guard observation["imageCalls"] as? Int == 1,
              observation["imageDelegations"] as? Int == 1,
              observation["renderCalls"] as? Int == 0,
              observation["restoredOriginalImplementations"] as? Bool == true,
              let rendered = FrameStagePreencode() else { throw failure("PNG boundary not observed exactly once") }
        report[name] = ["observation": observation, "context": try self.context(context, name + "-context"),
                        "preencode": try self.image(rendered, name + "-preencode"),
                        "png": try save(name + ".png", png)]
    }
    func failure(_ message: String) -> NSError {
        NSError(domain: "ColorStageDiagnostic", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
    static func main() async {
        let probe = ColorStages(folder: URL(fileURLWithPath: CommandLine.arguments[3], isDirectory: true))
        await probe.run()
    }
    func run() async {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: false)
            let input = URL(fileURLWithPath: CommandLine.arguments[1])
            let bytes = try Data(contentsOf: input)
            guard hash(bytes) == "08c139ef8e76f28c214bd3dbb4f00c06f243afdc95431231480bab0c6119c97f",
                  let source = try StillImageSource.open(input), source.orientedWidth == 3120,
                  source.orientedHeight == 1970, source.orientation == 1 else { throw failure("Fixed input changed") }
            report["input"] = ["path": input.path, "sha256": hash(bytes),
                               "image": try image(source.image, "input")]
            let requestData = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[2]))
            guard hash(requestData) == "91335177ce6499ce2d28fa28170fd876c00069f8cac2427a681bc179e3dc3cf1" else { throw failure("Fixed graph request changed") }
            let request = try JSONDecoder().decode(CompositionFrameRenderer.Request.self, from: requestData)
            let executor = try CompositionPictureExecutor(canvas: request.canvas, bindings: request.assets)
            let directContext = CIContext(options: [.cacheIntermediates: false])
            try publication("direct", FrameImage(oriented: source.oriented, maxLongEdge: 3120), directContext)
            guard FrameStageBegin(executor.context) else { throw failure("Unsupported graph render ABI") }
            let terminal: CVPixelBuffer
            do {
                defer { FrameStageEnd() }
                terminal = try await executor.render(request.frame) { _ in
                    var value: CVPixelBuffer?
                    guard CVPixelBufferCreate(nil, 3120, 1970, kCVPixelFormatType_32BGRA,
                        [kCVPixelBufferIOSurfacePropertiesKey as String: [:]] as CFDictionary,
                        &value) == kCVReturnSuccess, let value else { throw failure("Cannot allocate terminal") }
                    return value
                }
            }
            let observation = FrameStageObservation() as! [String: Any]
            guard observation["renderCalls"] as? Int == 1,
                  observation["renderDelegations"] as? Int == 1,
                  observation["imageCalls"] as? Int == 0,
                  observation["restoredOriginalImplementations"] as? Bool == true,
                  executor.decodedImages == 1, executor.decodedSamples == 0,
                  let graph = FrameStageGraph() else { throw failure("Compiled graph boundary not observed exactly once") }
            report["graph"] = ["observation": observation, "extent": NSStringFromRect(graph.extent),
                               "context": try context(executor.context, "graph-context"),
                               "representation": "Lazy CIImage; workingFormat is the context declaration, not captured internal framebuffer samples",
                               "decodedImages": executor.decodedImages, "decodedSamples": executor.decodedSamples,
                               "readerOpens": executor.opens]
            report["terminal"] = try buffer(terminal)
            try publication("graph-direct", FrameImage(oriented: graph, maxLongEdge: 3120), executor.context)
            try publication("graph-terminal", FrameImage(oriented: CIImage(cvPixelBuffer: terminal), maxLongEdge: 3120), executor.context)
            report["completed"] = true
        } catch {
            report["completed"] = false
            report["error"] = String(describing: error)
        }
        do {
            let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: folder.appendingPathComponent("report.json"), options: .withoutOverwriting)
        } catch {
            FileHandle.standardError.write(Data("Cannot save diagnostic report: \(error)\n".utf8))
            exit(1)
        }
        if report["completed"] as? Bool != true { exit(1) }
    }
}
