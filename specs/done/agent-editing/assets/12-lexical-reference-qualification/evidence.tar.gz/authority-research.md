# Bounded speech-reference authority review

2026-10-01. Read-only research: four search queries, four distinct primary
documents. Two initial document URLs failed; their same documents were read
through the publisher's raw README and arXiv paper URLs. No further search loop,
dataset/model download, inference, capture, playback, or human task occurred.
The HF skill was read for metadata-only ML discovery; no HF authentication,
installation or download command was used.

## Current claims

12b selected-baseline adoption is complete and remains unchanged. Parent 12 has
open lexical/filler coverage and held-out characterization. Eight confirmed human
word edges on four words produce baseline median 100 ms / interpolated p95
371.5 ms, still failing the retained 100/250 ms targets. The opening um end has no
baseline proposal; its clip-edge onset is censored. Sentence endpoints are not
word edges. No complete filler inventory or general recall claim is supported.

## Strongest lexical candidate: Earnings-21

Publisher: Rev.com / revdotcom. The authors' paper describes 44 public 2020 calls
sourced from Seeking Alpha. Experienced human transcriptionists produced verbatim
references; a separate senior pool graded/reviewed them, with author spot checks.
These references retain fillers, false starts and other disfluencies. They are
independent of this project's selected Parakeet output.

Official sources actually inspected:
- https://raw.githubusercontent.com/revdotcom/speech-datasets/main/earnings21/README.md
- https://github.com/revdotcom/speech-datasets/blob/main/earnings21/LICENSE.md
- https://arxiv.org/pdf/2104.11348

Access: official public GitHub release; no paywall/account requirement is stated
in the inspected README/paper. Actual individual audio/reference objects were not
fetched or validated. The paper explicitly identifies source file 4346923 (16 kHz,
Industrial Goods), so this is a real named file, not an invented sample ID.

License: the inspected LICENSE explicitly covers transcripts/associated alignment
text under CC BY-SA 4.0. It does not grant that same audio license. The paper's
audio-publication rationale cites earnings-call fair-use precedent. Do not flatten
this into a blanket CC license for audio or redistribute an audio fixture on that
basis alone. This is reported source provenance, not a new legal conclusion.

Authority limit: NLP format offers ts/endTs fields, but its shown example has
empty timestamps. Neither inspected README nor paper establishes independent
manual word-start/end labeling. Aligned timestamps would remain localization
hints, never acoustic timing truth. Lexical human text does not close boundary
median/p95 or safe-cut/join quality.

## Exact prospective small fixture and stopping condition

Named candidate: official Earnings-21 source 4346923, paired only with its official
human nlp_reference. Prospective input: the FIRST complete human-reference
utterance containing literal uh or um, with its original adjacent context, at most
60 seconds total; reference includes every spoken token in that supplied audio,
retaining fillers/repetitions. Select from human reference order BEFORE looking
at any Parakeet hypothesis. One source, one utterance, one unchanged-model run,
no model comparison or recipe alteration. Count lexical S/D/I and uh/um occurrences
by sequence alignment; report missing fillers as lexical omissions and report
sample size. Repeated words are transcript facts, never unwanted/edit targets.

This fixture is NOT executable-ready from this research: no complete short audio
and matching reference interval were inspected. Exact token IDs and source range
must first be bound from publisher metadata; generated alignment cannot manufacture
manual timing authority. The next useful bounded step is a METADATA QUALIFICATION
of this ONE publisher pair: verify object access/license, whether a complete <=60s
reference-aligned utterance is available, and freeze the source/reference hashes,
full token list, range derivation and normalization before any model dispatch.
If that one pair cannot supply a text-complete short excerpt, stop that candidate;
do not run an approximately paired crop or silently infer a complete inventory.
No exact audio interval or um count is claimed today.

Even if later qualified and run, it adds one held-out-from-local-development lexical
and filler-retention diagnostic. It cannot prove independence from undisclosed
Parakeet pretraining, whole-corpus filler precision/recall, timing thresholds,
protected-word cuts/joins, editorial judgment or release acceptance. Published
benchmark status is not proof that the selected pretrained model never saw it.

## Other sources: why not silently adopt

Fourth inspected primary document:
https://github.com/SpeechColab/GigaSpeech/blob/main/README.md

GigaSpeech DEV/TEST are professionally human annotated, with full-file non-speech
coverage, and retain conversational filler tokens in source text. Its standard
scoring procedure removes fillers: that scoring procedure cannot answer this
project's filler-retention question. Access asks for a form/email response or an
HF route. The inspected README supplies no resolved dataset/audio-license terms
and no exact DEV/TEST mini-sample ID; its concrete example is marked XL/L training,
so it must not be presented as held-out. Segment timing is not independently
manual word-edge authority.

Search-only publisher results also surfaced Buckeye (registration, noncommercial)
and PodcastFillers (manual event categories but automatic full transcripts;
noncommercial metadata with explicit deployment restriction). Neither was opened
within the four-document budget or selected. Their search snippets do not establish
complete lexical reference or manual word-edge authority; no further claim follows.

Outcome: named useful lexical-authority candidate, but no fully qualified small
executable fixture or independent boundary corpus found within the bound. This
limits this research claim; it does not block unrelated toolkit implementation.
Original human marks, two actual 12b inference records, selected model files and
accepted 200 ms room-tone loop remain unchanged. No repository changes made.
