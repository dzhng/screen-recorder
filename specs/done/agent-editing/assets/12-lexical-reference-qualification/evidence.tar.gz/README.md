# One-pair qualification result

The named official pair exists, with its repository revision and Git object
identities pinned in [the record](qualification.json). Public audio HEAD succeeds;
audio bytes were not downloaded. The human reference bytes were downloaded once
for this expressly bounded qualification, and their Git blob and SHA-256 agree.

The first literal filler occurs at zero-based reference row 252. Rows 252–259
form a complete punctuation-delimited greeting beginning with Uh, by speaker 2.
Adjacent reference context is available, but the whole 4,709.418-second recording
has no usable reference word times. All ts values are empty; the only nonempty
endTs value is a malformed period. No <=60s audio crop was manufactured from token
position, speech-rate guesses, another model's timing, or inferred waveform edges.

Consequently this is not an executable small lexical fixture yet. Exact source
localization with a text-complete context crop remains missing. Independent human
word timing is separately absent, and any later generated localization must stay
a localization aid rather than boundary truth. Literal uh/um counts are human
reference text facts; they are not measured recognition recall or edit targets.

The transcript license is CC BY-SA 4.0. That file's grant explicitly covers text
and alignment text; it does not establish the same license for audio. The authors'
paper cites a fair-use publication rationale. Additional audio usage authority
and exclusion from Parakeet pretraining were not established. Public availability
is not a blanket audio license or proof of pretrained-model hold-out status.

A minimal lexical normalization is proposed in the record: casefold tokens,
ignore separate punctuation metadata, retain uh/um and repetitions, preserve
false starts and avoid entity/number/synonym equivalence. This policy would be
frozen before looking at hypotheses; no inference or model-setting change occurs.

Qualification stops here. No broad search, audio playback, human task, repository
change, selected recipe change, or claim that parent12 quality passed follows.
