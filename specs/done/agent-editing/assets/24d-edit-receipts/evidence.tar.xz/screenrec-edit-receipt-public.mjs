import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {JourneyService,hash} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const prior=JSON.parse(await readFile('/tmp/screenrec-public-edit-timeout/report.json','utf8'));
const request=JSON.parse(await readFile('/tmp/screenrec-edit-timeout-request.json','utf8'));
const report={passed:false,scope:'public edit continuation only; no PCM preparation',home:prior.failureHome,trace:[],batches:[],projectId:request.projectId};
const service=new JourneyService(prior.failureHome,report);
try {
 await service.start();
 let revision=(await service.call('revision.get',{projectId:request.projectId})).revision;
 assert.equal(revision.document.clips.length,6000);
 report.originalHead=revision.id;report.originalDocumentSha256=hash(Buffer.from(JSON.stringify(revision.document)));
 const span=720000;
 for(let first=6000;first<10000;first+=500) {
  const operations=Array.from({length:500},(_,i)=>({operation:'place',clip:{...request.operations[0].clip,placement:{kind:'project',range:{startUs:(first+i)*span,endUs:(first+i+1)*span}}}}));
  if(first===9500)operations.push({operation:'processing.set',target:{kind:'output'},steps:[{processor:{type:'rnnoise'}}]});
  const input={projectId:request.projectId,expectedRevisionId:revision.id,requestId:`place-${first}`,operations};
  report.pendingRequest=input;
  await writeFile('/tmp/screenrec-edit-receipt-pending.json',JSON.stringify(input,null,2));
  const at=performance.now();
  const raw = await service.mcp.callTool({name:'edit.apply',arguments:input});
  assert.equal(raw.structuredContent.ok,true);
  assert.deepEqual(JSON.parse(raw.content[0].text),raw.structuredContent);
  const result=raw.structuredContent.data;
  assert(!('document' in result.edit));
  const envelopeBytes=Buffer.byteLength(JSON.stringify({jsonrpc:'2.0',id:1,result:raw})+'\n');
  assert(envelopeBytes<10485760);
  report.lastEnvelopeBytes=envelopeBytes;
  report.lastRequest=input;
  if(first===9500){
    report.finalReceipt=result;
    assert.deepEqual(await service.call('edit.apply',input),result);
    await service.stop();await service.start();
    assert.deepEqual(await service.call('edit.apply',input,{transport:'mcp'}),result);
    report.restartReplay=true;
  }
  report.batches.push({first,operations:operations.length,elapsedMs:performance.now()-at,revisionId:result.revision.id,replyBytes:Buffer.byteLength(JSON.stringify(result))});
  assert.deepEqual(result.revision.document.clips.slice(0,revision.document.clips.length),revision.document.clips);
  revision=result.revision;
 }
 assert.equal(revision.document.clips.length,10000);
 delete report.finalReceipt; report.finalHead=revision.id;report.finalDocumentSha256=hash(Buffer.from(JSON.stringify(revision.document)));report.passed=true;
 delete report.pendingRequest;
} catch(error){report.failure={message:error.message,stack:error.stack};throw error;}
finally {await service.stop();await writeFile('/tmp/screenrec-edit-receipt-public.json',JSON.stringify(report,null,2));}
console.log(report.batches);
