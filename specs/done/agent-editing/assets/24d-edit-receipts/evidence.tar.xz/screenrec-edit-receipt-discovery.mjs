import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {JourneyService} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const prior=JSON.parse(await readFile('/tmp/screenrec-edit-receipt-public.json','utf8'));
const report={trace:[],operations:[]};const service=new JourneyService(prior.home,report);
try {await service.start();const list=await service.mcp.listTools();
for(const [name,path] of [['edit.apply','/tmp/screenrec-edit-receipt-help.json'],['text.seed','/tmp/screenrec-text-receipt-help.json']]) {
 const cli=JSON.parse(await readFile(path,'utf8')).operations[0],mcp=list.tools.find(t=>t.name===name);
 assert.equal(cli.description,mcp.description);assert.deepEqual(cli.inputSchema,mcp.inputSchema);assert(cli.description.includes('revision.document as the sole document'));
 report.operations.push({name,description:cli.description,equalSchema:true});
}
report.passed=true;
} finally {await service.stop();await writeFile('/tmp/screenrec-edit-receipt-discovery.json',JSON.stringify(report,null,2));}
