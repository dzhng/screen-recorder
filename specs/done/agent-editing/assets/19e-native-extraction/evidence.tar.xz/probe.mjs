import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createReadStream, readFileSync, writeFileSync, copyFileSync, statSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { createCompiler, validateComposition } from '/Users/david/dev/screen-recorder/packages/composition/dist/index.js';
import { nativeProcessing } from '/Users/david/dev/screen-recorder/apps/service/dist/native-processing.js';
const root='/Users/david/dev/screen-recorder';
const out='/tmp/screenrec-19e-native-probe.i5dNTt';
const worker=join(root,'helpers/mac/.build/arm64-apple-macosx/debug/screenrec-native');
const reference=join(root,'specs/agent-editing/assets/18-voice/reference.wav');
const narration=join(root,'fixtures/narrated-workbench/narration.mov');
const hash=b=>createHash('sha256').update(b).digest('hex');
async function fileHash(path){const h=createHash('sha256');for await(const b of createReadStream(path))h.update(b);return h.digest('hex');}
let sequence=0;
function call(operation,params,expectedError){
  const request={id:String(++sequence),operation,params};
  writeFileSync(join(out,`${sequence}-request.json`),JSON.stringify(request,null,2)+'\n');
  const child=spawnSync(worker,[],{input:JSON.stringify(request)+'\n',encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
  assert.equal(child.status,0,child.stderr||String(child.error));
  const response=JSON.parse(child.stdout);
  writeFileSync(join(out,`${sequence}-response.json`),JSON.stringify(response,null,2)+'\n');
  if(expectedError){assert.equal(response.error?.code,expectedError);return response;}
  assert.equal(response.ok,true,JSON.stringify(response));return response.data;
}
function wave(path){
 const bytes=readFileSync(path); assert.equal(bytes.toString('ascii',0,4),'RIFF');
 let format,pcm;const chunks=[];
 for(let at=12;at+8<=bytes.length;){const tag=bytes.toString('ascii',at,at+4),size=bytes.readUInt32LE(at+4),body=bytes.subarray(at+8,at+8+size);chunks.push({tag,size});
 if(tag==='fmt ')format={tag:body.readUInt16LE(0),channels:body.readUInt16LE(2),sampleRate:body.readUInt32LE(4),bits:body.readUInt16LE(14)};
 if(tag==='data')pcm=body;at+=8+size+(size%2);}
 assert(pcm);return {bytes,pcm,summary:{...format,bytes:bytes.length,frames:pcm.length/(format.channels*format.bits/8),wavSha256:hash(bytes),pcmSha256:hash(pcm),chunks}};
}
const originals={worker:await fileHash(worker),reference:await fileHash(reference),narration:await fileHash(narration)};
const referenceProbe=call('media.probe',{path:reference});
const stream=referenceProbe.streams.find(v=>v.kind==='audio');
const range={startUs:0,endUs:5000000};
const source={source:reference,streamId:stream.id,sourceOffsetUs:0,available:[range]};
const frozen=wave(reference);
copyFileSync(reference,join(out,'copied-reference.wav'));
const sourceResult=call('media.sourceAudio',{source,range,output:join(out,'source-reference.wav')});
const rendered=wave(sourceResult.file);
const unsupported=call('media.sourceAudio',{source,range,output:join(out,'unsupported-profile.wav'),sampleRate:24000,channels:1},'INVALID_REQUEST');
const asset={id:'reference',streams:[{id:stream.id,kind:'audio',bounds:range,available:[range]}]};
const document={canvas:{width:160,height:96,fps:{numerator:10,denominator:1},background:'#000000ff'},tracks:[{id:'audio',kind:'audio',order:0}],groups:[],processing:[],syncGroups:[],clips:[{id:'reference-clip',assetId:asset.id,streamId:stream.id,trackId:'audio',source:{kind:'range',range},placement:{kind:'project',range}}]};
const model=validateComposition(document,[asset]);
const window=createCompiler(model,'reference-probe').window({range,rendition:{sampleRate:48000,channels:2},tap:{target:{kind:'output'},point:{kind:'processed'}}});
const compositionRequest={output:join(out,'composition-reference.wav'),range:window.manifest.sampleRange,clips:[...window.audio()],processing:nativeProcessing(window.processing()),assets:[{assetId:asset.id,streamId:stream.id,path:reference,originUs:referenceProbe.originUs}]};
const compositionResult=call('media.mixCompositionAudio',compositionRequest);
const composition=wave(compositionResult.file);
const unsupportedComposition=call('media.mixCompositionAudio',{...compositionRequest,output:join(out,'unsupported-composition.wav'),sampleRate:24000,channels:1},'INVALID_REQUEST');
const narrationProbe=call('media.probe',{path:narration});
const narrationStream=narrationProbe.streams.find(v=>v.kind==='audio');
const narrationRange={startUs:1000000,endUs:6000000};
const narrationResult=call('media.sourceAudio',{source:{source:narration,streamId:narrationStream.id,sourceOffsetUs:0,available:[narrationRange]},range:narrationRange,output:join(out,'source-narration.wav')});
const nativeNarration=wave(narrationResult.file);
assert.equal(await fileHash(worker),originals.worker);
assert.equal(await fileHash(reference),originals.reference);
assert.equal(await fileHash(narration),originals.narration);
const report={worker,originals,reference:frozen.summary,copied:wave(join(out,'copied-reference.wav')).summary,source:rendered.summary,sourcePcmEqualsFrozen:rendered.pcm.equals(frozen.pcm),sourceWavEqualsFrozen:rendered.bytes.equals(frozen.bytes),sourceReceipt:sourceResult,composition:composition.summary,compositionReceipt:compositionResult,sourceProfileRefusal:unsupported.error,compositionProfileRefusal:unsupportedComposition.error,narrationSource:nativeNarration.summary,narrationReceipt:narrationResult,originalsUnchanged:true};
writeFileSync(join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
const total=readdirSync(out).reduce((n,p)=>n+statSync(join(out,p)).size,0);assert(total<20*1024*1024);console.log(JSON.stringify({out,totalBytes:total,...report},null,2));
