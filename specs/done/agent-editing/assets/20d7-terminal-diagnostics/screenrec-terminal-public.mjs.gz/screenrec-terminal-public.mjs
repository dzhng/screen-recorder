import assert from 'node:assert/strict';
import {mkdtemp,mkdir,cp,readFile,writeFile,rm} from 'node:fs/promises';
import {join} from 'node:path';import {randomUUID,createHash} from 'node:crypto';
import {RevisionStore} from '/Users/david/dev/screen-recorder/packages/core/dist/library.js';
import {JourneyService,poll} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out=await mkdtemp('/tmp/screenrec-terminal-public-'), report={trace:[],passed:false,cases:[]};
const donor='/tmp/capture-real-controller-S56Yox/take';
for(const withVideo of [true,false]) {
 const home=join(out,withVideo?'video':'no-video'); await mkdir(home);let ids=0;
 const text=await readFile(join(donor,'capture.journal.jsonl'),'utf8');
 const lines=text.trimEnd().split('\n').map(JSON.parse);const header=lines[0].data;
 const failure={code:'DEVICE_LOST',message:'The microphone disconnected during the demonstration.'};
 for(const line of lines)if(line.event==='finished'){line.data.state='interrupted';line.data.failure=failure;}
 const store=new RevisionStore(join(home,'library.sqlite'),{now:()=>new Date().toISOString(),newId:()=>++ids===2?header.sessionID:randomUUID()});
 const recording=store.allocate().recording;store.close();
 const source=join(home,'recordings',recording.recordingId,'source');await cp(donor,source,{recursive:true});
 await writeFile(join(source,'capture.journal.jsonl'),lines.map(JSON.stringify).join('\n')+'\n');
 if(!withVideo)await rm(join(source,'video.mov'));
 const bytes=await readFile(join(source,'capture.journal.jsonl'));const hash=createHash('sha256').update(bytes).digest('hex');
 const service=new JourneyService(home,report,join(out,'reads.jsonl'),new URL('file:///tmp/screenrec-terminal-service.mjs'));
 try{
  await service.start();
  const settled=await poll(()=>service.call('recording.get',{recordingId:recording.recordingId}),v=>v.state==='interrupted','recovery');
  assert.equal(settled.interruptionReason,failure.code);assert.equal(settled.interruptionMessage,failure.message);
  assert.equal(settled.currentRevisionId,withVideo?'r0':null);
  await service.stop();await service.start();
  const reopened=await service.call('recording.get',{recordingId:recording.recordingId},{transport:'mcp'});assert.deepEqual(reopened,settled);
  assert.equal(createHash('sha256').update(await readFile(join(source,'capture.journal.jsonl'))).digest('hex'),hash);
  report.cases.push({withVideo,settled,hash});
 }finally{await service.stop();}
}
report.passed=true;await writeFile(join(out,'report.json'),JSON.stringify(report,null,2));console.log(out);
