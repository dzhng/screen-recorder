raise RuntimeError("unprepared ambient module was imported")
