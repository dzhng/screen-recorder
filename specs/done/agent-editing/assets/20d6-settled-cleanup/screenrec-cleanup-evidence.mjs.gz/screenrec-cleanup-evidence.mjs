import assert from 'node:assert/strict';
import {mkdtemp,mkdir,cp,readFile,writeFile,link,chmod,access} from 'node:fs/promises';
import {join} from 'node:path';import {randomUUID,createHash} from 'node:crypto';
import {RevisionStore} from '/Users/david/dev/screen-recorder/packages/core/dist/library.js';
import {JourneyService,poll} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out=await mkdtemp('/tmp/screenrec-cleanup-evidence-'),report={trace:[],passed:false};
const donor='/tmp/capture-real-controller-S56Yox/take';
const header=JSON.parse((await readFile(join(donor,'capture.journal.jsonl'),'utf8')).split('\n')[0]).data;
const home=join(out,'home');await mkdir(home);let ids=0;
const store=new RevisionStore(join(home,'library.sqlite'),{now:()=>new Date().toISOString(),newId:()=>++ids===2?header.sessionID:randomUUID()});
const recording=store.allocate().recording;store.ingestLifecycle(recording.recordingId,{sourceId:recording.sourceId,sequence:1,state:'finalizing'});store.ingestLifecycle(recording.recordingId,{sourceId:recording.sourceId,sequence:2,state:'complete',sourceDurationUs:3194231});const before=store.get(recording.recordingId);store.close();
const source=join(home,'recordings',recording.recordingId,'source');await cp(donor,source,{recursive:true});
const digest=async()=>Object.fromEntries(await Promise.all(['capture.journal.jsonl','narration.mov','narration.publication.json','system.mov','system.publication.json'].map(async n=>[n,createHash('sha256').update(await readFile(join(source,n))).digest('hex')])));
for (const role of ['narration','system']) {
 const attempt=join(source,`.capture-publication-${role}`);await mkdir(attempt,{mode:0o700});
 const receipt=JSON.parse(await readFile(join(source,`${role}.publication.json`),'utf8'));
 await writeFile(join(attempt,'intent.json'),JSON.stringify(receipt.intent));
 await link(join(source,`${role}.mov`),join(attempt,'candidate.mov'));
 await link(join(source,`${role}.publication.json`),join(attempt,'prepared.json'));
}
await chmod(join(source,'.capture-publication-narration'),0o500);
const hashes=await digest();const service=new JourneyService(home,report,join(out,'reads.jsonl'),new URL('file:///tmp/screenrec-20d5-root-service.mjs'));
try{await service.start();const evidenceBefore=await poll(()=>service.call('processing.status',{recordingId:recording.recordingId,artifact:'source'}),v=>v.state==='ready','source evidence');report.evidenceBefore=evidenceBefore;const admitted=await service.call('recording.cleanup',{recordingId:recording.recordingId});assert.equal(admitted.target.revisionId,null);
const failed=await poll(()=>service.call('job.get',{jobId:admitted.jobId}),v=>['ready','failed'].includes(v.state),'first cleanup');
assert.equal(failed.state,'failed',JSON.stringify(failed));assert.equal(failed.retryable,true);report.failed=failed;
await access(join(source,'.capture-publication-narration','candidate.mov'));
await assert.rejects(access(join(source,'.capture-publication-system')));
assert.deepEqual(await digest(),hashes);
await service.stop();await service.start();const resumed=await service.call('job.get',{jobId:admitted.jobId});assert.equal(resumed.state,'failed');assert.equal(resumed.retryable,true);report.resumed=resumed;
await chmod(join(source,'.capture-publication-narration'),0o700);
const retry=await service.call('job.retry',{jobId:admitted.jobId});assert.equal(retry.jobId,admitted.jobId);
const ready=await poll(()=>service.call('job.get',{jobId:admitted.jobId}),v=>['ready','failed'].includes(v.state),'retry cleanup');assert.equal(ready.state,'ready',JSON.stringify(ready));assert.deepEqual(ready.result.roles.map(r=>r.outcome),['removed','alreadyClear']);assert.deepEqual(await digest(),hashes);const after=await service.call('recording.get',{recordingId:recording.recordingId});assert.deepEqual(after,before);report.before=before;report.after=after;assert.equal((await service.call('recording.cleanup',{recordingId:recording.recordingId})).jobId,ready.jobId);report.ready=ready;report.hashes=hashes;const evidenceAfter=await service.call('processing.status',{recordingId:recording.recordingId,artifact:'source'});assert.deepEqual(evidenceAfter,evidenceBefore);report.evidenceAfter=evidenceAfter;report.passed=true;
}finally{await chmod(join(source,'.capture-publication-narration'),0o700).catch(()=>{});await service.stop();await writeFile(join(out,'report.json'),JSON.stringify(report,null,2));console.log(out);}
