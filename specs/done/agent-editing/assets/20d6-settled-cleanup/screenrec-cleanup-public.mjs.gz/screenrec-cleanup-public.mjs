import assert from 'node:assert/strict';
import {mkdtemp,mkdir,cp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';import {randomUUID,createHash} from 'node:crypto';
import {RevisionStore} from '/Users/david/dev/screen-recorder/packages/core/dist/library.js';
import {JourneyService,poll} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out=await mkdtemp('/tmp/screenrec-cleanup-public-'),report={trace:[],passed:false};
const donor='/tmp/capture-real-controller-S56Yox/take';
const header=JSON.parse((await readFile(join(donor,'capture.journal.jsonl'),'utf8')).split('\n')[0]).data;
const home=join(out,'home');await mkdir(home);let ids=0;
const store=new RevisionStore(join(home,'library.sqlite'),{now:()=>new Date().toISOString(),newId:()=>++ids===2?header.sessionID:randomUUID()});
const recording=store.allocate().recording;store.ingestLifecycle(recording.recordingId,{sourceId:recording.sourceId,sequence:1,state:'interrupted',reason:'NO_VIDEO',sourceDurationUs:null});const before=store.get(recording.recordingId);store.close();
const source=join(home,'recordings',recording.recordingId,'source');await cp(donor,source,{recursive:true});
const digest=async()=>Object.fromEntries(await Promise.all(['capture.journal.jsonl','narration.mov','narration.publication.json','system.mov','system.publication.json'].map(async n=>[n,createHash('sha256').update(await readFile(join(source,n))).digest('hex')])));
const hashes=await digest();const service=new JourneyService(home,report,join(out,'reads.jsonl'),new URL('file:///tmp/screenrec-20d5-root-service.mjs'));
try{await service.start();const admitted=await service.call('recording.cleanup',{recordingId:recording.recordingId});assert.equal(admitted.target.revisionId,null);
const ready=await poll(()=>service.call('job.get',{jobId:admitted.jobId}),v=>['ready','failed'].includes(v.state),'cleanup');assert.equal(ready.state,'ready',JSON.stringify(ready));assert.deepEqual(ready.result.roles.map(r=>r.outcome),['alreadyClear','alreadyClear']);assert.deepEqual(await digest(),hashes);const after=await service.call('recording.get',{recordingId:recording.recordingId});assert.deepEqual(after,before);report.before=before;report.after=after;report.ready=ready;report.hashes=hashes;report.passed=true;
}finally{await service.stop();await writeFile(join(out,'report.json'),JSON.stringify(report,null,2));console.log(out);}
