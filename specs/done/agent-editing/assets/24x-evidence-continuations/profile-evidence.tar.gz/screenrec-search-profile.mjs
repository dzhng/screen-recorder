import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { loadavg } from 'node:os';
import { JourneyService, poll, hash } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';

const prior = JSON.parse(await readFile('/tmp/screenrec-transcript-search-diagnostic/report.json', 'utf8'));
const expected = JSON.parse(await readFile('/tmp/screenrec-transcript-search-diagnostic/expected-matches.json', 'utf8'));
const out = '/tmp/screenrec-search-profile';
await mkdir(out, { recursive: true });
const config = JSON.parse(await readFile('/tmp/screenrec-transcript-search-diagnostic/transcript-fixture-1.json', 'utf8'));
config.allowedOperations = ['storage.clearRenderWorkspace'];
config.operationsFile = join(out, 'native-operations.jsonl');
config.observationsFile = join(out, 'unexpected-inference.json');
const configFile = join(out, 'fixture.json');
await writeFile(configFile, JSON.stringify(config, null, 2));
const report = { passed: false, trace: [], queries: [], home: prior.home,
  projectId: prior.projectId, revisionId: prior.revisionId, nativeSha256: hash(await readFile(process.env.SCREENREC_NATIVE)),
  priorReportSha256: hash(await readFile('/tmp/screenrec-transcript-search-diagnostic/report.json')),
  expectedSha256: hash(await readFile('/tmp/screenrec-transcript-search-diagnostic/expected-matches.json')),
  loadAtStart: loadavg(), scope: 'Scratch in-memory timers around unchanged existing owners; real public MCP; no acceptance-budget change' };
assert.equal(report.nativeSha256, prior.nativeSha256);
const service = new JourneyService(prior.home, report, configFile, new URL('file:///tmp/screenrec-search-profile-service.mjs'));
const save = () => writeFile(join(out, 'report.json'), JSON.stringify(report, null, 2));
const ipc = async (type, extra = {}) => {
  const id = `${type}-${report.queries.length}`;
  service.child.send({ type, id, ...extra });
  return poll(() => service.barriers.get(`${id}/${type}.done`) ?? {}, value => value.type === `${type}.done`, type);
};
try {
  await service.start();
  report.pid = service.child.pid;
  const read = async (label, enabled) => {
    await ipc('profile.reset', { enabled });
    const pages = [], entries = [];
    let cursor;
    const at = performance.now();
    do {
      const params = { projectId: prior.projectId, revisionId: prior.revisionId, text: 'so', limit: 250 - entries.length, ...(cursor ? { cursor } : {}) };
      const response = await poll(() => service.call('transcript.search', params, { transport: 'mcp' }), value => value.state === 'ready', 'search');
      assert.equal(response.projectId, prior.projectId);
      assert.equal(response.revisionId, prior.revisionId);
      assert.equal(response.dependencies.length, 1);
      assert.equal(response.dependencies[0].transcript.generation, prior.sourceTranscript.generation);
      assert.deepEqual(response.dependencies[0].transcript.engine, prior.fixture.engine);
      assert.notDeepEqual(response.page.nextCursor, cursor);
      pages.push({ request: { operation: 'transcript.search', params }, response });
      entries.push(...response.page.entries);
      cursor = response.page.nextCursor;
      assert.ok(pages.length <= 100);
    } while (entries.length < 250 && cursor);
    assert.deepEqual(entries, expected);
    assert.ok(cursor);
    const elapsedMs = performance.now() - at;
    const metrics = await ipc('profile.flush');
    const entry = { label, enabled, elapsedMs, pages: pages.length, rowsSha256: hash(Buffer.from(JSON.stringify(entries))),
      totals: metrics.totals, counters: metrics.counters, replacements: metrics.replacements,
      file: `${label}-pages.json` };
    await writeFile(join(out, entry.file), JSON.stringify(pages));
    report.queries.push(entry);
    await save();
  };
  await read('warmup', false);
  await read('control-before-1', false);
  await read('control-before-2', false);
  for (let trial = 1; trial <= 5; trial++) await read(`profile-${trial}`, true);
  await read('control-after-1', false);
  await read('control-after-2', false);
  report.passed = true;
  report.loadAtEnd = loadavg();
} catch (error) {
  report.error = { message: error.message, stack: error.stack };
  throw error;
} finally {
  await service.stop();
  await save();
}
