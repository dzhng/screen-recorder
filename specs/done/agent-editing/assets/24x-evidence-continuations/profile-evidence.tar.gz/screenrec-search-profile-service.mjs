import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const root = '/Users/david/dev/screen-recorder/';
const identities = JSON.parse(await readFile('/tmp/screenrec-transcript-search-diagnostic/runtime-identities.json', 'utf8'));
const slot = '__screenrecSearchProfile';
let enabled = false;
let totals = {};
let counters = {};
const add = (name, elapsed) => {
  const value = totals[name] ??= { calls: 0, totalMs: 0, maxMs: 0 };
  value.calls++;
  value.totalMs += elapsed;
  value.maxMs = Math.max(value.maxMs, elapsed);
};
const profile = {
  sync(name, fn) {
    if (!enabled) return fn();
    const at = performance.now();
    try { return fn(); } finally { add(name, performance.now() - at); }
  },
  count(name, value) {
    if (enabled) counters[name] = (counters[name] ?? 0) + value;
  },
};
globalThis[slot] = profile;
const evidenceUrl = new URL('file://' + root + 'packages/core/dist/project-evidence.js').href;
const transcriptUrl = new URL('file://' + root + 'packages/core/dist/project-transcript.js').href;
const replacements = [];
registerHooks({
  load(url, context, nextLoad) {
    const loaded = nextLoad(url, context);
    if (![evidenceUrl, transcriptUrl].includes(url)) return loaded;
    assert.equal(loaded.format, 'module');
    let source = Buffer.isBuffer(loaded.source) ? loaded.source.toString('utf8') : String(loaded.source);
    const relative = url === evidenceUrl ? 'packages/core/dist/project-evidence.js' : 'packages/core/dist/project-transcript.js';
    assert.equal(createHash('sha256').update(source).digest('hex'), identities[relative]);
    if (url === transcriptUrl) {
      const before = 'export function mergeTranscript(';
      assert.equal(source.split(before).length, 2);
      source = source.replace(before, 'function timedMergeTranscriptBody(') + `\nexport function mergeTranscript(...args) { return globalThis.${slot}.sync('mergeTranscript', () => timedMergeTranscriptBody(...args)); }\n`;
    } else {
      const before = 'projection.window({ range: parsed.data, trackIds })';
      assert.equal(source.split(before).length, 2);
      source = source.replace(before, `globalThis.${slot}.sync('plan.projectionWindow', () => ${before})`);
      const acquire = 'const read = this.options.cache.acquire(id);';
      assert.equal(source.split(acquire).length, 2);
      source = source.replace(acquire, acquire + `\n        globalThis.${slot}.count('acquiredBytes', read?.bytes ?? 0);`);
    }
    replacements.push({ relative, originalSha256: identities[relative], instrumentedSha256: createHash('sha256').update(source).digest('hex') });
    return { ...loaded, source };
  },
});
const { ProjectEvidenceInspection } = await import('file://' + root + 'packages/core/dist/project-evidence.js');
for (const name of ['plan', 'dependencies', 'acquire']) {
  const original = ProjectEvidenceInspection.prototype[name];
  assert.equal(typeof original, 'function');
  ProjectEvidenceInspection.prototype[name] = function (...args) {
    return profile.sync(name, () => {
      const result = original.apply(this, args);
      if (name === 'plan') profile.count('plannedOccurrences', result.occurrences.length);
      if (name === 'dependencies') profile.count('dependencyOccurrenceVisits', args[0].length);
      return result;
    });
  };
}
for (const name of ['read', 'publish']) {
  const original = ProjectEvidenceInspection.prototype[name];
  assert.equal(typeof original, 'function');
  ProjectEvidenceInspection.prototype[name] = async function (...args) {
    if (!enabled) return original.apply(this, args);
    const at = performance.now();
    try { return await original.apply(this, args); } finally { add(name, performance.now() - at); }
  };
}
const { SourceTranscriptRead } = await import('file://' + root + 'packages/core/dist/transcript-read.js');
const sourcePage = SourceTranscriptRead.prototype.page;
SourceTranscriptRead.prototype.page = function (...args) {
  return profile.sync('merge.sourcePage', () => {
    const result = sourcePage.apply(this, args);
    profile.count('sourceRows', result.rows.length);
    return result;
  });
};
process.on('message', message => {
  if (message?.type === 'profile.reset') {
    enabled = message.enabled;
    totals = {};
    counters = {};
    process.send({ type: 'profile.reset.done', id: message.id });
  } else if (message?.type === 'profile.flush') {
    enabled = false;
    process.send({ type: 'profile.flush.done', id: message.id, totals, counters, replacements });
  }
});
await import('file://' + root + 'packages/test-harness/editing/transcript-duration-service.mjs');
