import AVFoundation
import Foundation
Task {
 for (rate,algorithm) in [(16000, "none"),(16000,"mastering"),(44100,"mastering"),(16000,"normal")] {
  let path="/tmp/aac-probe-\(rate)-\(algorithm).m4a"
  try? FileManager.default.removeItem(atPath:path)
  let asset=AVURLAsset(url:URL(fileURLWithPath:"/tmp/screenrec-controls-journey/source.wav"))
  let track=try await asset.loadTracks(withMediaType:.audio)[0]
  let reader=try AVAssetReader(asset:asset)
  let output=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVLinearPCMIsFloatKey:true,AVLinearPCMBitDepthKey:32,AVLinearPCMIsNonInterleaved:false])
  reader.add(output)
  let writer=try AVAssetWriter(outputURL:URL(fileURLWithPath:path),fileType:.m4a)
  var settings:[String:Any]=[AVFormatIDKey:kAudioFormatMPEG4AAC,AVSampleRateKey:rate,AVNumberOfChannelsKey:1,AVEncoderBitRateKey:48000]
  if algorithm != "none" { settings[AVSampleRateConverterAlgorithmKey] = algorithm == "mastering" ? AVSampleRateConverterAlgorithm_Mastering : AVSampleRateConverterAlgorithm_Normal }
  let input=AVAssetWriterInput(mediaType:.audio,outputSettings:settings);writer.add(input)
  writer.startWriting();writer.startSession(atSourceTime:.zero);reader.startReading()
  while let buffer=output.copyNextSampleBuffer() {
   while !input.isReadyForMoreMediaData && writer.status == .writing { try await Task.sleep(for:.milliseconds(1)) }
   if !input.append(buffer) {break}
  }
  input.markAsFinished(); await writer.finishWriting()
  print(rate,algorithm,writer.status.rawValue,writer.error as Any)
 }
 exit(0)
}
dispatchMain()
