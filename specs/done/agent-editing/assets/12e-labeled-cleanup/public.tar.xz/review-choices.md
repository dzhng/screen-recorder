# Focused review and choices

Shape: one existing fixed-corpus public journey owner, one explicit reference-directory input. No production API, dependency, media transform, cleanup classifier, compatibility owner, model, or app change. Both existing frozen WAV SHA pins remain enforced. Default saved verification passes.

Diff: source ranges and sample counts derive from the retained reference mapping. Acquisition admission uses the original journal and per-binding source offsets. Both picture/audio removals and authored narration gain are one atomic batch. Complete original/candidate/undo PCM, document undo, public transports, movie receipt/clocks and existing AAC policy pass. Byte-level corruption fails even when numeric amplitude differences are zero. Formatter, lint, syntax and diff whitespace checks pass.

Docs: frozen evidence documentation remains correct for the default case. Root owns the new packet documentation and pending audition; no shared plan/docs were edited. The new gain-scope rationale belongs with that recipe and choices ledger. No visual or listening acceptance is claimed.

Independent CLI review: root reports the configured Codex model is unsupported. No retry, model/config change, installation or download was performed. This is a focused self-review, not independent Codex acceptance.

## Sound — ranked least confident first

- **Narration-track gain with held sample values (medium confidence).** Clip gain produced the right numeric samples but lost the negative sign on one zero sample when sibling clip silence was added. Applying the ramps after clips combine preserves those bits. Track curve keys are whole microseconds, so the new recipe expands the two 240-frame ramps into 482 held gain keys, placed before their exact 48 kHz sample times. Every public sample now equals the native reference exactly. The 482 keys are bounded data derived from the native envelope, expressed through existing public gain semantics. They describe every ramp level rather than compensating one sample sign. This is a bounded explicit recipe for this fixture; it adds no production mechanism. The default frozen case retains its two existing clip gain stacks.
- **Reference identity follows bytes, not storage location (high confidence).** The saved public report records the packet directory and its SHA256. Reverification requires the same report bytes but permits a different directory, so retaining a scratch packet in the spec assets does not falsely invalidate its saved evidence.
- **Exact difference reports count float bits (high confidence).** A zero sample can be encoded with either sign. Counting only amplitude differences incorrectly reported zero changed samples on an exact-byte failure. The report now counts differing 32-bit float encodings; a one-channel zero-sign mutation reports precisely one changed sample at frame 157535 and still fails verification.

One selector, no new production surfaces. Harness diff: 167 lines added, 77 deleted, net 90; includes formatting of the existing gain branch. Evidence and decisions remain in scratch for root integration.
