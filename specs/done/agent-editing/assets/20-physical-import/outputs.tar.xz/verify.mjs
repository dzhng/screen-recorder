import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, mkdtemp, readFile, stat, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { startProjectService } from '/Users/david/dev/screen-recorder/apps/service/dist/project-service.js';
import { cliReply } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/first-preview-transport.mjs';

// Completed immutable source files only. Never point this verifier at an active capture.
const [outputArgument, cameraArgument, screenArgument, micArgument] = process.argv.slice(2);
assert(outputArgument && cameraArgument && screenArgument && micArgument,
  'Usage: SCREENREC_NATIVE=/frozen/helper node script.mjs OUT CAMERA_MOV SCREEN_MOV MIC_FILE');
assert(process.env.SCREENREC_NATIVE, 'Use the existing frozen SCREENREC_NATIVE helper');
const out = resolve(outputArgument);
await mkdir(out, { recursive: true });
const home = await mkdtemp('/tmp/screenrec-physical-import-library-');
const report = { passed: false, home, native: process.env.SCREENREC_NATIVE, sources: [], failures: [] };
let service;
const cli = '/Users/david/dev/screen-recorder/apps/cli/dist/main.js';
async function digest(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}
async function save() { await writeFile(join(out, 'report.json'), JSON.stringify(report, null, 2) + '\n'); }
async function call(operation, params, output) {
  const envelope = await cliReply([cli, operation, '--socket', service.socketPath,
    '--params', JSON.stringify(params), ...(output ? ['--output', output] : [])]);
  if (!envelope.ok) throw new Error(`${operation}: ${JSON.stringify(envelope.error)}`);
  return envelope.data;
}
async function settle(operation, params) {
  const deadline = Date.now() + 180000;
  for (;;) {
    const value = await call(operation, params);
    if (['ready', 'failed', 'unavailable', 'canceled'].includes(value.state)) return value;
    assert(Date.now() < deadline, `${operation} exceeded bounded three-minute wait`);
    await delay(250);
  }
}
function occupiedAt(segments, fraction) {
  const occupied = segments.filter(s => !s.empty && s.endUs > s.startUs);
  const total = occupied.reduce((sum, s) => sum + s.endUs - s.startUs, 0);
  assert(total > 0, 'Stream must have real occupied support');
  let offset = Math.floor((total - 1) * fraction);
  for (const s of occupied) {
    const length = s.endUs - s.startUs;
    if (offset < length) return s.startUs + offset;
    offset -= length;
  }
  throw new Error('Unreachable occupied timestamp');
}
function wavSummary(bytes) {
  assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
  assert.equal(bytes.toString('ascii', 8, 12), 'WAVE');
  let format, data;
  for (let at = 12; at + 8 <= bytes.length;) {
    const tag = bytes.toString('ascii', at, at + 4), size = bytes.readUInt32LE(at + 4);
    assert(at + 8 + size <= bytes.length, 'WAV chunk exceeds delivered bytes');
    if (tag === 'fmt ') format = bytes.subarray(at + 8, at + 8 + size);
    if (tag === 'data') data = bytes.subarray(at + 8, at + 8 + size);
    at += 8 + size + (size % 2);
  }
  assert(format && data?.length, 'WAV must contain format and nonempty sample data');
  let encoding = format.readUInt16LE(0);
  const channels = format.readUInt16LE(2), sampleRate = format.readUInt32LE(4);
  const blockAlign = format.readUInt16LE(12), bits = format.readUInt16LE(14);
  if (encoding === 65534) encoding = format.readUInt16LE(24);
  assert([1, 3].includes(encoding), `Unsupported verification WAV encoding ${encoding}`);
  assert.equal(data.length % blockAlign, 0);
  const channel = Array.from({ length: channels }, () => ({ peak: 0, square: 0 }));
  const width = bits / 8, frames = data.length / blockAlign;
  for (let frame = 0; frame < frames; frame++) for (let c = 0; c < channels; c++) {
    const offset = frame * blockAlign + c * width;
    let sample;
    if (encoding === 3 && bits === 32) sample = data.readFloatLE(offset);
    else if (encoding === 3 && bits === 64) sample = data.readDoubleLE(offset);
    else if (encoding === 1 && bits === 8) sample = (data[offset] - 128) / 128;
    else if (encoding === 1 && [16, 24, 32].includes(bits)) sample = data.readIntLE(offset, width) / 2 ** (bits - 1);
    else throw new Error(`Unsupported verification PCM width ${bits}`);
    assert(Number.isFinite(sample), 'PCM samples must be finite');
    channel[c].peak = Math.max(channel[c].peak, Math.abs(sample));
    channel[c].square += sample * sample;
  }
  return { encoding, channels, sampleRate, bits, frames, durationSeconds: frames / sampleRate,
    channel: channel.map(c => ({ peak: c.peak, rms: Math.sqrt(c.square / frames) })) };
}
try {
  service = await startProjectService({ home });
  for (const [name, argument] of [['camera', cameraArgument], ['screen', screenArgument], ['microphone', micArgument]]) {
    const path = resolve(argument), initial = await stat(path);
    assert(initial.isFile() && initial.size > 0);
    const source = { name, path, bytes: initial.size, sha256: await digest(path), streams: [] };
    report.sources.push(source);
    console.log(`Importing completed ${name}: ${path}`);
    try {
      source.import = await call('asset.import', { requestId: `physical-${name}-${source.sha256}`, path });
      source.job = await settle('job.get', { jobId: source.import.jobId });
      assert.equal(source.job.state, 'ready', JSON.stringify(source.job));
      source.asset = await call('asset.get', { assetId: source.job.result.assetId });
      assert.equal(source.asset.id, source.sha256);
      assert.equal(source.asset.bytes, initial.size);
      assert(source.asset.streams.some(s => s.kind === (name === 'microphone' ? 'audio' : 'video')));
      for (const stream of source.asset.streams) {
        if (!['video', 'audio'].includes(stream.kind)) continue;
        const selected = { assetId: source.asset.id, streamId: stream.id };
        const item = { streamId: stream.id, kind: stream.kind, segments: [], inspections: [] };
        source.streams.push(item);
        let cursor;
        for (let page = 0; ; page++) {
          assert(page < 1000, 'Segment pagination exceeded bound');
          const result = await call('asset.segments', { ...selected, limit: 1000, ...(cursor ? { cursor } : {}) });
          item.segments.push(...result.segments);
          if (!result.nextCursor) break;
          assert.notDeepEqual(result.nextCursor, cursor, 'Segment cursor must advance');
          cursor = result.nextCursor;
        }
        try {
          if (stream.kind === 'video') {
            for (const [label, fraction] of [['early', .02], ['middle', .5], ['late', .98]]) {
              const params = { ...selected, atUs: occupiedAt(item.segments, fraction), maxLongEdge: 960 };
              const status = await settle('frame.get', params);
              const inspection = { label, params, status };
              item.inspections.push(inspection);
              if (status.state !== 'ready') { report.failures.push({ name, streamId: stream.id, operation: 'frame.get', status }); break; }
              const output = join(out, `${name}-${stream.id.replaceAll(':', '-')}-${label}.png`);
              inspection.delivered = await call('frame.get', params, output);
              const png = await readFile(output);
              assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
              inspection.output = output; inspection.sha256 = await digest(output);
            }
          } else {
            const midpoint = occupiedAt(item.segments, .5);
            const segment = item.segments.find(s => !s.empty && s.startUs <= midpoint && midpoint < s.endUs);
            const startUs = Math.max(segment.startUs, Math.min(midpoint - 5000000, segment.endUs - 10000000));
            const params = { ...selected, range: { startUs, endUs: Math.min(segment.endUs, startUs + 10000000) } };
            const status = await settle('audio.get', params);
            const inspection = { params, status }; item.inspections.push(inspection);
            assert.equal(status.state, 'ready', JSON.stringify(status));
            const output = join(out, `${name}-${stream.id.replaceAll(':', '-')}.wav`);
            inspection.delivered = await call('audio.get', params, output);
            inspection.output = output; inspection.sha256 = await digest(output);
            inspection.pcm = wavSummary(await readFile(output));
            inspection.hasNonzeroAudio = inspection.pcm.channel.some(c => c.peak > 0);
          }
        } catch (error) { item.error = error.message; report.failures.push({ name, streamId: stream.id, error: error.message }); }
      }
      const final = await stat(path);
      assert.equal(final.size, initial.size); assert.equal(final.mtimeMs, initial.mtimeMs);
      assert.equal(await digest(path), source.sha256, 'Completed source changed during verification');
    } catch (error) { source.error = error.message; report.failures.push({ name, error: error.message }); }
    await save();
  }
  report.passed = report.failures.length === 0;
} catch (error) { report.failures.push({ error: error.message, stack: error.stack }); }
finally {
  await service?.close();
  await save();
}
console.log(JSON.stringify({ passed: report.passed, report: join(out, 'report.json'), home, failures: report.failures }, null, 2));
if (!report.passed) process.exitCode = 1;
