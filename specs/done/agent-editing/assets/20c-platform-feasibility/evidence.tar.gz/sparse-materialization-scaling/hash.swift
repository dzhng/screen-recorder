import AVFoundation
import CryptoKit
import Foundation
import Darwin
let start=DispatchTime.now().uptimeNanoseconds
let asset=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1])),track=try await asset.loadTracks(withMediaType:.audio)[0]
let reader=try AVAssetReader(asset:asset)
reader.timeRange=CMTimeRange(start:CMTime(value:100002,timescale:1000000),duration:.positiveInfinity)
let output=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVSampleRateKey:48000,AVNumberOfChannelsKey:1,AVLinearPCMBitDepthKey:32,AVLinearPCMIsFloatKey:true,AVLinearPCMIsNonInterleaved:false]);reader.add(output);precondition(reader.startReading())
var hash=SHA256(),frames:Int64=0,maximum=0
while let count=autoreleasepool(invoking:{()->Int? in
 guard let sample=output.copyNextSampleBuffer() else{return nil}
 let count=CMSampleBufferGetNumSamples(sample);var list=AudioBufferList();var block:CMBlockBuffer?
 precondition(CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)==noErr)
 hash.update(data:Data(bytes:list.mBuffers.mData!,count:count*4));return count
}){frames+=Int64(count);maximum=max(maximum,count)}
precondition(reader.status == .completed)
var usage=rusage();getrusage(RUSAGE_SELF,&usage)
let result:[String:Any]=["frames":frames,"maximumBufferFrames":maximum,"sha256":hash.finalize().map{String(format:"%02x",$0)}.joined(),"seconds":Double(DispatchTime.now().uptimeNanoseconds-start)/1e9,"peakResidentBytes":usage.ru_maxrss]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]))
