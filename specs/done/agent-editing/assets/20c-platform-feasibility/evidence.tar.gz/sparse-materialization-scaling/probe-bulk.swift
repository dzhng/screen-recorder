import AVFoundation
import Foundation
import Darwin
let args=CommandLine.arguments, source=URL(fileURLWithPath:args[1]), count=Int(args[2])!, out=URL(fileURLWithPath:args[3]), mode=args[4]
let began=DispatchTime.now().uptimeNanoseconds
func elapsed()->Double {Double(DispatchTime.now().uptimeNanoseconds-began)/1e9}
func peak()->Int64 {var u=rusage();getrusage(RUSAGE_SELF,&u);return Int64(u.ru_maxrss)}
var phases=[[String:Any]]()
func mark(_ name:String){phases.append(["phase":name,"elapsedSeconds":elapsed(),"peakResidentBytes":peak()])}
mark("start")
let asset=AVURLAsset(url:source), track=try await asset.loadTracks(withMediaType:.audio)[0]
let descriptions=try await track.load(.formatDescriptions), basic=CMAudioFormatDescriptionGetStreamBasicDescription(descriptions[0])!.pointee
precondition(basic.mSampleRate==48000 && basic.mFormatID==kAudioFormatLinearPCM)
let range = try await track.load(.timeRange)
let frames = CMTimeConvertScale(range.duration, timescale:48000, method:.roundTowardZero).value
let scale:Int32=6000000
let composition=AVMutableComposition(), target=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid)!
target.naturalTimeScale=scale
mark("loaded")
var pieces=[AVCompositionTrackSegment]()
var previous=CMTime.zero
for i in 0..<count {
 let start=frames*Int64(i)/Int64(count),end=frames*Int64(i+1)/Int64(count)
 let at=mode=="fragmented" ? CMTime(value:600006+(start+Int64(i)*4800)*125,timescale:scale) : CMTime(value:600006+start*125,timescale:scale)
 let duration=CMTime(value:end-start,timescale:48000)
 if at > previous {pieces.append(AVCompositionTrackSegment(timeRange:CMTimeRange(start:previous,duration:CMTimeSubtract(at,previous))))}
 pieces.append(AVCompositionTrackSegment(url:source,trackID:track.trackID,sourceTimeRange:CMTimeRange(start:CMTime(value:start,timescale:48000),duration:duration),targetTimeRange:CMTimeRange(start:at,duration:duration)))
 previous=CMTimeAdd(at,duration)
}
try target.validateSegments(pieces)
target.segments=pieces
pieces.removeAll()
mark("inserted")
let before=target.segments.count
mark("segmentsQueried")
if args.count > 5 && args[5] == "metadata-only" {
 let report:[String:Any] = ["mode":mode,"insertions":count,"compositionSegments":before,"sourceFrames":frames,"phases":phases,"scope":"metadata-only control; no export or outputPCM claim"]
 FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]))
 exit(0)
}
let exporter=AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetPassthrough)!
try await exporter.export(to:out,as:.mov)
mark("exported")
let published=AVURLAsset(url:out), result=try await published.loadTracks(withMediaType:.audio)[0],segments=try await result.load(.segments)
var occupied=0,empty=0,sourceFrames:Int64=0
for segment in segments {
 if segment.isEmpty {empty+=1;continue}
 occupied+=1
 let duration=CMTimeConvertScale(segment.timeMapping.source.duration,timescale:48000,method:.roundHalfAwayFromZero)
 precondition(CMTimeCompare(duration,segment.timeMapping.source.duration)==0)
 sourceFrames+=duration.value
}
precondition(sourceFrames==frames)
if mode=="fragmented" {precondition(occupied==count)}
mark("inspected")
let report:[String:Any]=["mode":mode,"insertions":count,"compositionSegments":before,"occupiedSegments":occupied,"emptySegments":empty,"sourceFrames":sourceFrames,"outputBytes":try out.resourceValues(forKeys:[.fileSizeKey]).fileSize!,"phases":phases,"rssScope":"worker process highwater only; framework service memory not included"]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]))
