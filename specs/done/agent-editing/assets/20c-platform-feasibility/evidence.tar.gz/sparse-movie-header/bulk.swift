import AVFoundation
import Foundation
import Darwin
let args=CommandLine.arguments,source=URL(fileURLWithPath:args[1]),count=Int(args[2])!,out=URL(fileURLWithPath:args[3])
let began=DispatchTime.now().uptimeNanoseconds
func peak()->Int64{var u=rusage();getrusage(RUSAGE_SELF,&u);return Int64(u.ru_maxrss)}
var phases=[[String:Any]]()
func mark(_ phase:String){phases.append(["phase":phase,"seconds":Double(DispatchTime.now().uptimeNanoseconds-began)/1e9,"peakResidentBytes":peak()])}
mark("start")
let asset=AVURLAsset(url:source),track=try await asset.loadTracks(withMediaType:.audio)[0],range=try await track.load(.timeRange)
let frames=CMTimeConvertScale(range.duration,timescale:48000,method:.roundTowardZero).value
let movie=try AVMutableMovie(settingsFrom:nil,options:nil)
movie.timescale=6000000
movie.defaultMediaDataStorage=AVMediaDataStorage(url:out,options:nil)
mark("loaded")
let composition=AVMutableComposition(), target=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid)!
target.naturalTimeScale=48000
var pieces=[AVCompositionTrackSegment](),previous=CMTime.zero
for i in 0..<count {
 let first=frames*Int64(i)/Int64(count),end=frames*Int64(i+1)/Int64(count)
 let at=CMTime(value:600006+(first+Int64(i)*4800)*125,timescale:6000000),duration=CMTime(value:end-first,timescale:48000)
 if at>previous{pieces.append(AVCompositionTrackSegment(timeRange:CMTimeRange(start:previous,duration:CMTimeSubtract(at,previous))))}
 pieces.append(AVCompositionTrackSegment(url:source,trackID:track.trackID,sourceTimeRange:CMTimeRange(start:CMTime(value:first,timescale:48000),duration:duration),targetTimeRange:CMTimeRange(start:at,duration:duration)))
 previous=CMTimeAdd(at,duration)
}
try target.validateSegments(pieces);target.segments=pieces;pieces.removeAll()
mark("composed")
try movie.insertTimeRange(CMTimeRange(start:.zero,duration:previous),of:composition,at:.zero,copySampleData:true)
mark("copied")
mark("gaps")
try movie.writeHeader(to:out,fileType:.mov,options:.addMovieHeaderToDestination)
mark("header")
let published=AVURLAsset(url:out),result=try await published.loadTracks(withMediaType:.audio)[0],segments=try await result.load(.segments)
var occupied=0,empty=0,sourceFrames:Int64=0
for s in segments {
 if s.isEmpty{empty+=1;continue}
 let first=frames*Int64(occupied)/Int64(count),end=frames*Int64(occupied+1)/Int64(count)
 let expected=CMTime(value:600006+(first+Int64(occupied)*4800)*125,timescale:6000000)
 precondition(s.timeMapping.target.start==expected,"phase changed")
 precondition(s.timeMapping.target.duration==CMTime(value:end-first,timescale:48000),"duration changed")
 sourceFrames+=end-first;occupied+=1
}
precondition(occupied==count && sourceFrames==frames)
mark("verifiedSegments")
let report:[String:Any]=["runs":count,"sourceFrames":frames,"occupied":occupied,"empty":empty,"naturalTimeScale":try await result.load(.naturalTimeScale),"outputBytes":try out.resourceValues(forKeys:[.fileSizeKey]).fileSize!,"phases":phases]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]))
