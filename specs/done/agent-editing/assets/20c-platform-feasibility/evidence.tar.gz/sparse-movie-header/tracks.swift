import AVFoundation
import Foundation
let asset=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1]))
var rows=[[String:Any]]()
for track in try await asset.loadTracks(withMediaType:.audio) {
 let segs=try await track.load(.segments)
 rows.append(["track":track.trackID,"segments":segs.map { ["empty":$0.isEmpty,"source":String(describing:$0.timeMapping.source),"target":String(describing:$0.timeMapping.target)] }])
}
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:rows,options:[.prettyPrinted,.sortedKeys]))
