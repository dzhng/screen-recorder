import AVFoundation
import Foundation
let a=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1])),t=try await a.loadTracks(withMediaType:.audio)[0],segments=try await t.load(.segments)
let count=Int(CommandLine.arguments[2])!,frames:Int64=96000
var index=0,issues=[[String:Any]]()
for s in segments where !s.isEmpty {
 let first=frames*Int64(index)/Int64(count),end=frames*Int64(index+1)/Int64(count),expected=CMTime(value:600006+(first+Int64(index)*4800)*125,timescale:6000000)
 if (s.timeMapping.target.start != expected || s.timeMapping.target.duration != CMTime(value:end-first,timescale:48000)) && issues.count<8 {
  issues.append(["index":index,"startValue":s.timeMapping.target.start.value,"startScale":s.timeMapping.target.start.timescale,"expectedValue":expected.value,"expectedScale":expected.timescale,"durationValue":s.timeMapping.target.duration.value,"durationScale":s.timeMapping.target.duration.timescale,"expectedFrames":end-first])
 }
 index+=1
}
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:["occupied":index,"issues":issues],options:[.prettyPrinted,.sortedKeys]))
