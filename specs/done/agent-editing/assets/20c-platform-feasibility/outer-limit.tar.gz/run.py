import pathlib,subprocess,time,json,hashlib
base=pathlib.Path('/tmp/sparse-outer-limit')
for name,count,mode in [('retained-10000',10000,'full'),('acquisition-100000',100000,'full'),('cancel-100000',100000,'cancel')]:
 out=base/(name+'.mov'); stdout=open(base/(name+'.json'),'wb'); stderr=open(base/(name+'.log'),'wb'); started=time.monotonic();maximum=0;guard=None
 p=subprocess.Popen([str(base/'probe'),str(base/'payload.mov'),str(count),str(out),'fragmented',mode],stdout=stdout,stderr=stderr)
 while p.poll() is None:
  r=subprocess.run(['ps','-o','rss=','-p',str(p.pid)],capture_output=True,text=True)
  if r.stdout.strip(): maximum=max(maximum,int(r.stdout)*1024)
  if maximum>3*1024**3 or time.monotonic()-started>60:
   guard='rss3GiB' if maximum>3*1024**3 else 'time60s';p.terminate();break
  time.sleep(.1)
 try:code=p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();code=p.wait()
 stdout.close();stderr.close()
 receipt={'returncode':code,'seconds':time.monotonic()-started,'observedRSSBytes':maximum,'guard':guard,'guardScope':'experiment only; not product limits','sourceSHA256':hashlib.sha256((base/'payload.mov').read_bytes()).hexdigest()}
 (base/(name+'.execution.json')).write_text(json.dumps(receipt,indent=2));print(name,receipt,flush=True)
 if code or guard:break
