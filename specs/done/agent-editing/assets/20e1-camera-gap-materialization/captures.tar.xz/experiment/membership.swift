@preconcurrency import AVFoundation
import CryptoKit
import Foundation
import ScreenRecorderFrames

func pixelHash(_ pixel: CVPixelBuffer) -> String {
    CVPixelBufferLockBaseAddress(pixel,.readOnly)
    defer { CVPixelBufferUnlockBaseAddress(pixel,.readOnly) }
    var hash=SHA256()
    for y in 0..<CVPixelBufferGetHeight(pixel) {
        hash.update(data:Data(bytes:CVPixelBufferGetBaseAddress(pixel)!.advanced(by:y*CVPixelBufferGetBytesPerRow(pixel)),count:CVPixelBufferGetWidth(pixel)*4))
    }
    return hash.finalize().map { String(format:"%02x",$0) }.joined()
}
@main struct Membership {
    static func main() async throws {
        let root=URL(fileURLWithPath:CommandLine.arguments[1])
        let url=root.appendingPathComponent("candidate.mov")
        let candidateHash=SHA256.hash(data:try Data(contentsOf:url)).map { String(format:"%02x",$0) }.joined()
        let report=try JSONSerialization.jsonObject(with:Data(contentsOf:root.appendingPathComponent("report.json"))) as! [String:Any]
        precondition(candidateHash==report["candidateSha256"] as! String)
        let asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
        let track=try await asset.loadTracks(withMediaType:.video).first!
        let segments=try await track.load(.segments)
        let raw=try JSONSerialization.jsonObject(with:Data(contentsOf:root.appendingPathComponent("raw-pictures.json"))) as! [[String:Any]]
        var grid=Set<Int64>()
        for segment in segments {
            let range=segment.timeMapping.target
            let first=CMTimeConvertScale(range.start,timescale:1000000,method:.roundHalfAwayFromZero).value
            let last=CMTimeConvertScale(range.end,timescale:1000000,method:.roundHalfAwayFromZero).value
            grid.formUnion([first,first+(last-first)/2,last-1])
        }
        let source=try await PresentationSource(source:url,streamId:"track:\(track.trackID)",startUs:0)
        var rows:[[String:Any]]=[]
        for us in grid.sorted() {
            let at=CMTime(value:us,timescale:1000000)
            let segment=segments.first { $0.timeMapping.target.containsTime(at) }!
            let selection=try source.selection(at:at,end:.positiveInfinity)
            var row:[String:Any]=["atUs":us,"expectedEmpty":segment.isEmpty,"endValue":selection.end.value,"endScale":selection.end.timescale]
            if segment.isEmpty {
                precondition(selection.buffer==nil && selection.sampleTime==nil)
                row["status"]="unavailable"
            } else {
                let stamp=selection.sampleTime!;let pixel=selection.buffer!
                let match=raw.first { CMTime(value:($0["ptsValue"] as! NSNumber).int64Value,timescale:($0["ptsScale"] as! NSNumber).int32Value)==stamp }!
                let hash=pixelHash(pixel)
                precondition(hash==match["sha256"] as! String && CVPixelBufferGetWidth(pixel)==match["width"] as! Int && CVPixelBufferGetHeight(pixel)==match["height"] as! Int)
                precondition(stamp==segment.timeMapping.target.start)
                row["status"]="available";row["actualValue"]=stamp.value;row["actualScale"]=stamp.timescale;row["BGRAsha256"]=hash
            }
            rows.append(row)
        }
        let after=SHA256.hash(data:try Data(contentsOf:url)).map { String(format:"%02x",$0) }.joined()
        precondition(after==candidateHash)
        try JSONSerialization.data(withJSONObject:["scope":"Actual PresentationSource membership only; public color admission remains NOT_READY","candidateSha256":candidateHash,"unchanged":after==candidateHash,"rows":rows,"decodedSamples":source.decodedCount],options:[.prettyPrinted,.sortedKeys]).write(to:root.appendingPathComponent("membership-report.json"))
        print("PASS actual PresentationSource excludes empty edits and preserves exact occupiedPTS/fullBGRA for all\(rows.count) boundaries/interiors")
    }
}
