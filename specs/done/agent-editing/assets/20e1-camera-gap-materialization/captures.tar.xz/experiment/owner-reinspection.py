from pathlib import Path
import json,subprocess,hashlib
from fractions import Fraction
p=Path('/tmp/screenrec-20e1-gap'); out=p/'owner'; out.mkdir()
worker=Path('/Users/david/dev/screen-recorder/helpers/mac/.build/arm64-apple-macosx/debug/screenrec-native'); sha=lambda b:hashlib.sha256(b).hexdigest();wh=sha(worker.read_bytes());assert wh=='8a0c7732f3c1f99e074048f2ac3b8b29beb613462fb5ce769a134b1cbfdea186'
calls=[]
def call(name,operation,params):
 req={'id':name,'operation':operation,'params':params}; (out/f'{name}.request.json').write_text(json.dumps(req,indent=2)+'\n'); r=subprocess.run([str(worker)],input=json.dumps(req)+'\n',text=True,capture_output=True,timeout=30); (out/f'{name}.stdout.json').write_text(r.stdout);(out/f'{name}.stderr.txt').write_text(r.stderr); calls.append({'name':name,'exitCode':r.returncode});assert r.returncode==0;r=json.loads(r.stdout);return r
metadata={}
for name,file in [('raw','video.mov'),('candidate','candidate.mov')]:
 response=call(name+'-probe','media.probe',{'path':str(p/file)});assert response['ok'];metadata[name]=response['data']
 def selected(meta):
  stream=next(s for s in meta['streams']if s['kind']=='video');origin=meta['originUs'];available=[{'startUs':s['startUs'],'endUs':s['endUs']}for s in stream['segments']if not s['empty']];return stream,origin,available
 stream,origin,available=selected(metadata[name]);metadata[name]['selectedAvailable']=available
metadata['candidate']['selectedAvailable']
stream,origin,available=selected(metadata['candidate']); times=sorted(set([s['startUs'] for s in available]+[s['endUs']for s in available[:-1]]+[sum([available[i]['endUs'],available[i+1]['startUs']])//2 for i in range(len(available)-1)]+[s['endUs']-1 for s in available]+[available[-1]['endUs']]))
asset=lambda name:{'assetId':name,'streamId':next(s['id']for s in metadata[name]['streams']if s['kind']=='video'),'originUs':metadata[name]['originUs'],'path':str(p/('candidate.mov'if name=='candidate'else'video.mov'))}
visual=call('candidate-visual','media.sourceVisualSamples',{'asset':asset('candidate'),'available':available,'atSourceUs':times});assert visual['ok']
for row in visual['data']['samples']:
 occupied=any(s['startUs']<=row['requestedSourceUs']<s['endUs']for s in available)
 assert (row['status']=='available')==occupied,row
positive=[s['startUs'] for s in available]; frameRows=[]
for at in times:
 file=out/f'candidate-{at}.png'; r=call('candidate-frame-'+str(at),'media.sourceFrame',{'asset':asset('candidate'),'available':available,'atUs':at,'output':str(file),'maxLongEdge':160})
 occupied=any(s['startUs']<=at<s['endUs']for s in available);assert r['ok']==occupied
 if not occupied:assert not file.exists() and r['error']['code'] in ['UNAVAILABLE','SOURCE_PICTURE_UNAVAILABLE']
 if at in positive:
  original=out/f'raw-{at}.png'; raw=call('raw-frame-'+str(at),'media.sourceFrame',{'asset':asset('raw'),'available':metadata['raw']['selectedAvailable'],'atUs':at,'output':str(original),'maxLongEdge':160});assert raw['ok']; assert raw['data']['actualSourceUs']==r['data']['actualSourceUs']==at
  assert file.read_bytes()==original.read_bytes();frameRows.append({'atUs':at,'pngSha256':sha(file.read_bytes()),'pngByteEqual':True})
raw=json.loads((p/'raw-pictures.json').read_text());decoded=json.loads((p/'candidate-pictures.json').read_text());rawSelected=[r for r in raw if Fraction(r['ptsValue'],r['ptsScale'])*1000000-metadata['raw']['originUs'] in positive];occupiedDecoded=[];emptyDecoded=[]
for d in decoded:
 at=Fraction(d['ptsValue'],d['ptsScale'])*1000000-origin
 (occupiedDecoded if any(s['startUs']<=at<s['endUs']for s in available)else emptyDecoded).append(d)
assert len(occupiedDecoded)==len(rawSelected)==3
for a,b in zip(occupiedDecoded,rawSelected):assert Fraction(a['ptsValue'],a['ptsScale'])==Fraction(b['ptsValue'],b['ptsScale']) and (a['sha256'],a['width'],a['height'])==(b['sha256'],b['width'],b['height'])
report={'workerSha256':wh,'probeOriginUs':origin,'availableDerivedFromActualProbe':available,'grid':times,'occupiedDecodedExact':True,'occupiedDecodedCount':len(occupiedDecoded),'emptyEditDecoderEmissions':emptyDecoded,'positiveFrames':frameRows,'allGapFramesRefusedWithoutPNG':True,'originalUnfilteredCountRedRetained':True,'calls':calls}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
