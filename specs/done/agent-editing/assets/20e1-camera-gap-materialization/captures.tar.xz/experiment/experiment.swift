@preconcurrency import AVFoundation
import CryptoKit
import Foundation

struct Picture: Codable {
    let ptsValue: Int64
    let ptsScale: Int32
    let durationValue: Int64
    let durationScale: Int32
    let width: Int
    let height: Int
    let sha256: String
    var pts: CMTime { CMTime(value: ptsValue, timescale: ptsScale) }
}
func pictures(_ asset: AVAsset, _ track: AVAssetTrack) throws -> [Picture] {
    let reader = try AVAssetReader(asset: asset)
    let output = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
    reader.add(output)
    guard reader.startReading() else { throw reader.error! }
    var rows: [Picture] = []
    while let sample = output.copyNextSampleBuffer() {
        let pixel = sample.imageBuffer!
        CVPixelBufferLockBaseAddress(pixel, .readOnly)
        let width = CVPixelBufferGetWidth(pixel), height = CVPixelBufferGetHeight(pixel)
        let stride = CVPixelBufferGetBytesPerRow(pixel)
        var hash = SHA256()
        for y in 0..<height { hash.update(data: Data(bytes: CVPixelBufferGetBaseAddress(pixel)!.advanced(by: y*stride), count: width*4)) }
        CVPixelBufferUnlockBaseAddress(pixel, .readOnly)
        rows.append(Picture(ptsValue: sample.presentationTimeStamp.value, ptsScale: sample.presentationTimeStamp.timescale,
            durationValue: sample.duration.value, durationScale: sample.duration.timescale,
            width: width, height: height, sha256: hash.finalize().map { String(format:"%02x",$0) }.joined()))
    }
    guard reader.status == .completed else { throw reader.error! }
    return rows
}
func stamp(_ t: CMTime) -> [String: Any] { ["value":t.value,"timescale":t.timescale] }
@main struct Experiment {
    static func main() async throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1])
        let request = try JSONSerialization.jsonObject(with: Data(contentsOf: root.appendingPathComponent("request.json"))) as! [String: Any]
        let input = URL(fileURLWithPath: request["raw"] as! String)
        let before = SHA256.hash(data: try Data(contentsOf: input)).map { String(format:"%02x",$0) }.joined()
        let asset = AVURLAsset(url: input, options: [AVURLAssetPreferPreciseDurationAndTimingKey:true])
        let source = try await asset.loadTracks(withMediaType: .video).first!
        let scale = try await source.load(.naturalTimeScale)
        let raw = try pictures(asset, source)
        try JSONEncoder().encode(raw).write(to: root.appendingPathComponent("raw-pictures.json"))
        let starts = (request["acceptedStartsUs"] as! [Int64]).map { CMTime(value:$0,timescale:1000000) }
        let frame = CMTime(value:1,timescale:Int32(request["declaredFramesPerSecond"] as! Int))
        let ranges = starts.map { start in CMTimeRange(start:start, end:CMTimeConvertScale(CMTimeAdd(start,frame),timescale:scale,method:.roundHalfAwayFromZero)) }
        guard ranges.allSatisfy({ r in raw.contains { $0.pts == r.start } }) else { fatalError("No exact raw source picture for accepted mapping") }
        let composition = AVMutableComposition()
        let target = composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid)!
        target.naturalTimeScale = scale
        var pieces:[AVCompositionTrackSegment]=[]
        var previous = CMTime.zero
        for range in ranges {
            if range.start > previous { pieces.append(AVCompositionTrackSegment(timeRange:CMTimeRange(start:previous,end:range.start))) }
            pieces.append(AVCompositionTrackSegment(url:input,trackID:source.trackID,sourceTimeRange:range,targetTimeRange:range))
            previous = range.end
        }
        try target.validateSegments(pieces); target.segments = pieces
        let exporter = AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetPassthrough)!
        let candidate = URL(fileURLWithPath:request["candidate"] as! String)
        try await exporter.export(to:candidate,as:.mov)
        let result = AVURLAsset(url:candidate,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
        let track = try await result.loadTracks(withMediaType:.video).first!
        let segments = try await track.load(.segments)
        let decoded = try pictures(result,track)
        try JSONEncoder().encode(decoded).write(to:root.appendingPathComponent("candidate-pictures.json"))
        let occupied = segments.filter { !$0.isEmpty }.map { $0.timeMapping.target }
        let selected = ranges.map { range in raw.first { $0.pts == range.start }! }
        let supportExact = occupied == ranges
        let picturesExact = decoded.count == selected.count && zip(decoded,selected).allSatisfy {
            $0.pts == $1.pts && $0.sha256 == $1.sha256 && $0.width == $1.width && $0.height == $1.height
        }
        let after = SHA256.hash(data:try Data(contentsOf:input)).map { String(format:"%02x",$0) }.joined()
        let report:[String:Any] = ["sourceSha256":before,"sourceUnchanged":before==after,"rawNaturalTimescale":scale,
            "rounding":"absolute end = roundHalfAwayFromZero(start + 1/30, raw natural timescale); starts exact; no nearest lookup",
            "expected":ranges.map { ["start":stamp($0.start),"duration":stamp($0.duration)] },
            "segments":segments.map { ["empty":$0.isEmpty,"targetStart":stamp($0.timeMapping.target.start),"targetDuration":stamp($0.timeMapping.target.duration),"sourceStart":stamp($0.timeMapping.source.start),"sourceDuration":stamp($0.timeMapping.source.duration)] },
            "occupiedSupportExact":supportExact,"decodedPicturesExact":picturesExact,
            "rawDecodedCount":raw.count,"candidateDecodedCount":decoded.count,
            "candidateSha256":SHA256.hash(data:try Data(contentsOf:candidate)).map { String(format:"%02x",$0) }.joined()]
        try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]).write(to:root.appendingPathComponent("report.json"))
        print("supportExact=\(supportExact) picturesExact=\(picturesExact) raw=\(raw.count) candidate=\(decoded.count)")
        if !supportExact || !picturesExact || before != after { exit(1) }
    }
}
