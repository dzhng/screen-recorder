await import('file:///Users/david/.codex/worktrees/external-caller-fixture/screen-recorder/apps/service/dist/project-service.js');
await import('file:///Users/david/.codex/worktrees/external-caller-fixture/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs');
await import('file:///Users/david/.codex/worktrees/external-caller-fixture/screen-recorder/packages/test-harness/editing/acceptance-inputs.mjs');
process.argv=[process.execPath,'/Users/david/.codex/worktrees/external-caller-fixture/screen-recorder/apps/cli/dist/main.js','--help'];
await import('file:///Users/david/.codex/worktrees/external-caller-fixture/screen-recorder/apps/cli/dist/main.js');
