import pathlib,json,tarfile,hashlib,subprocess,urllib.parse,shutil
root=pathlib.Path('/Users/david/.codex/worktrees/external-caller-fixture/screen-recorder');dst=root/'specs/agent-editing/assets/25-input-preparation';out=pathlib.Path('/tmp/screenrec-25-preparation-current')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def archive(name,files):
 pins={}
 with tarfile.open(dst/(name+'.tar.gz'),'w:gz',compresslevel=6) as t:
  for member,p in sorted(files.items()):t.add(p,arcname=member,recursive=False);pins[member]=pin(p)
 (dst/(name+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
 return pins
report=json.loads((out/'report.json').read_text());assert report['passed'];
graph=[json.loads(x) for x in pathlib.Path('/tmp/screenrec-25-resolution-graph.jsonl').read_text().splitlines()]
js=sorted({pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(v['url']).path)) for v in graph if v['url'].startswith('file:')})
external={str(p):pin(p) for p in js if not p.is_relative_to(root)}
old=json.loads((root/'specs/agent-editing/assets/09c-audio-export/external-runtime-pins.json').read_text());oldmap={p['path']:p for p in old};reuse={};other={}
for path,p in external.items():
 if path in oldmap:
  assert p=={'bytes':oldmap[path]['bytes'],'sha256':oldmap[path]['sha256']},path
  reuse[path]={**p,'member':oldmap[path]['member']}
 else:other['external/'+path.lstrip('/')]=pathlib.Path(path)
(dst/'module-resolution.json').write_text(json.dumps({'graph':graph,'files':len(js),'reusedExternal':reuse,'additionalExternal':{k:pin(p) for k,p in other.items()}},indent=2)+'\n')
paths=set(json.loads((root/'specs/agent-editing/assets/09c-audio-export/source-runtime-pins.json').read_text()))
paths.update(str(p.relative_to(root)) for p in js if p.is_relative_to(root))
paths.update(['packages/test-harness/editing/acceptance.mjs','packages/test-harness/editing/acceptance-inputs.mjs','packages/test-harness/editing/acceptance-inputs.test.mjs','specs/agent-editing/slices/25-agent-acceptance.md','specs/agent-editing/assets/25-fixture-brief/README.md','specs/recording-for-ai/assets/speech/boundaries/transcript.json','specs/agent-editing/assets/12-speech/manifest.json'])
paths.update(report['authorities'])
missing=[p for p in paths if not(root/p).is_file()];assert not missing,missing
src=archive('source-runtime',{p:root/p for p in paths})
files={}
for directory,stem in [(out,'current'),(pathlib.Path('/tmp/screenrec-25-preparation-first'),'first-diagnostic')]:
 for p in directory.rglob('*'):
  rel=p.relative_to(directory)
  if p.is_file() and not any(v.startswith('library-') for v in rel.parts):files[stem+'/'+str(rel)]=p
for p in pathlib.Path('/tmp').glob('screenrec-25*.log'):files['logs/'+p.name]=p
for p in ['/tmp/screenrec-25-bank.py','/tmp/screenrec-25-verify.py','/tmp/screenrec-25-bank-shadowed.py','/tmp/screenrec-25-resolution-loader.mjs','/tmp/screenrec-25-resolution-probe.mjs','/tmp/screenrec-25-resolution-graph.jsonl']:files['provenance/'+pathlib.Path(p).name]=pathlib.Path(p)
files.update(other);files['tools/usr-bin-tar']=pathlib.Path('/usr/bin/tar').resolve()
ev=archive('evidence',files)
nativepins=json.loads((root/'specs/agent-editing/assets/09c-native-audio-file/source-final-pins.json').read_text());nativebad=[];archived=[]
for name,p in nativepins.items():
 f=root/name
 if not f.is_file():archived.append(name)
 elif pin(f)!=p:nativebad.append(name)
assert not nativebad,nativebad;assert archived==['helpers/denoise/.build/rnnoise/rnnoise_data.c'],archived
hist=root/'specs/recording-for-ai/assets/speech/boundaries/transcript.json';assert pin(hist)['sha256']=='f17e3bb721c24637a6c0e650511d2853f0c42497d903c6ca953d0bb3a80aaa00'
ver={'passed':True,'baseCommit':'baa92372','scope':report['scope'],'commands':[{'command':'SCREENREC_NATIVE=/tmp/screenrec-09c-native-presented-worker node packages/test-harness/editing/acceptance.mjs --case tutorial --prepare --resume --transport both --media-root /Users/david/dev/screen-recorder --out /tmp/screenrec-25-preparation-current','exitCode':0,'log':'screenrec-25-preparation-axis-final.log'},{'command':'node --test packages/test-harness/editing/acceptance-inputs.test.mjs','exitCode':0,'tests':3,'log':'screenrec-25-inputs-axis-final.log'}],'publicExchanges':len(report['exchanges']),'inputs':len(report['inputs']),'provenanceFiles':len(report['provenance']),'worker':report['worker'],'nativeCurrentSourcesMatched':len(nativepins)-len(archived),'nativeArchivedOnly':archived,'project':report['project'],'libraryHome':report['home'],'modelStatus':report['modelStatus'],'historicalTranscript':{**pin(hist),'sourceSha256':'2bf4af51122816d6e4c4a6731ddd1a73375be3ed61d82d8cd66bec824638962c','sourceAuthority':'assets/12-speech/manifest.json','scope':'historical raw/word evidence only; no current canonical receipt or supported adoption established'},'gaps':report['gaps'],'performance':'unmeasured','sourceRuntimeMembers':len(src),'evidenceMembers':len(ev),'externalResolvedReused':len(reuse),'additionalExternal':len(other),'diagnostics':['Initial test RED: binding helper missing','First CLI build missing local client dist; client and CLI rebuilt successfully','First public preparation admitted all inputs but failed wrong project.get revision assumption','Second public preparation admitted all inputs but failed wrong revision.get response nesting','Corrected resume preserves old reports and original requests, leaves12 ready import jobs/assets and one unedited project'],'systemTools':{'node':subprocess.check_output(['node','--version'],text=True).strip(),'tar':pin(pathlib.Path('/usr/bin/tar')),'tarLinks':subprocess.check_output(['otool','-L','/usr/bin/tar'],text=True),'remaining':'macOS system libraries/dyld shared cache; linked executable identities retained by original native/external packets'},'review':'manual shape/code/docs/choices; no CLI review retry or Claude call'}
(dst/'verification.json').write_text(json.dumps(ver,indent=2)+'\n');print(json.dumps({'source':len(src),'evidence':len(ev),'externalReused':len(reuse),'additionalExternal':len(other)},indent=2))
