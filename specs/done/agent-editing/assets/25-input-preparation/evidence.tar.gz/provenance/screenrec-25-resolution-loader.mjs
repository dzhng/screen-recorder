import {appendFileSync} from 'node:fs';
export async function resolve(specifier,context,nextResolve){const r=await nextResolve(specifier,context);appendFileSync('/tmp/screenrec-25-resolution-graph.jsonl',JSON.stringify({specifier,parentURL:context.parentURL??null,url:r.url})+'\n');return r;}
