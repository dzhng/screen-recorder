import json,pathlib,tarfile,hashlib
root=pathlib.Path('/Users/david/.codex/worktrees/external-caller-fixture/screen-recorder');base=root/'specs/agent-editing/assets/25-input-preparation';result={'passed':True,'archives':{},'currentSourceMatches':0}
for name in ['source-runtime','evidence']:
 pins=json.loads((base/(name+'-pins.json')).read_text());actual={}
 with tarfile.open(base/(name+'.tar.gz'),'r:gz') as t:
  for m in t:
   if m.isfile() or m.islnk():
    data=t.extractfile(m).read();actual[m.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert actual==pins,(name,len(actual),len(pins))
 if name=='source-runtime':
  for path,p in pins.items():
   b=(root/path).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==p,path
  result['currentSourceMatches']=len(pins)
 arc=base/(name+'.tar.gz');result['archives'][arc.name]={'members':len(actual),'bytes':arc.stat().st_size,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest()}
(base/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
