from pathlib import Path
import json,subprocess,hashlib
p=Path('/tmp/screenrec-20e2-real-recovery/take');out=Path('/tmp/screenrec-20e2-real-consumer');out.mkdir(exist_ok=True)
w=Path('/Users/david/dev/screen-recorder/helpers/mac/.build/arm64-apple-macosx/debug/screenrec-native')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(w)=='8a0c7732f3c1f99e074048f2ac3b8b29beb613462fb5ce769a134b1cbfdea186'
calls=[]
def call(name,op,params):
 q={'id':name,'operation':op,'params':params}
 if (out/(name+'.stdout.json')).exists():
  assert json.loads((out/(name+'.request.json')).read_text())==q
  r=json.loads((out/(name+'.stdout.json')).read_text());calls.append({'name':name,'ok':r['ok'],'retainedResponse':True});return r
 (out/(name+'.request.json')).write_text(json.dumps(q,indent=2)+'\n')
 r=subprocess.run([str(w)],input=json.dumps(q)+'\n',text=True,capture_output=True,timeout=30)
 (out/(name+'.stdout.json')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr)
 assert r.returncode==0;r=json.loads(r.stdout);calls.append({'name':name,'ok':r['ok']});return r

files={'raw':p/'camera/camera.raw.mov','canonical':p/'camera/video.mov'}
metadata={};available={};assets={}
for name,path in files.items():
 r=call(name+'-probe','media.probe',{'path':str(path)});assert r['ok'];meta=r['data'];metadata[name]=meta
 stream=next(s for s in meta['streams']if s['kind']=='video')
 available[name]=[{'startUs':s['startUs'],'endUs':s['endUs']}for s in stream['segments']if not s['empty']]
 assets[name]={'assetId':name,'streamId':stream['id'],'originUs':meta['originUs'],'path':str(path)}
for field in ['transform','colorPrimaries','transferFunction','ycbcrMatrix','width','height']:
 assert metadata['canonical']['streams'][0][field]==metadata['raw']['streams'][0][field],field
origin=metadata['canonical']['originUs'];assert origin==4147523
assert available['canonical']==[{'startUs':0,'endUs':250114773-origin}],available
pts=[round(r['cameraFrame']['start']['value']*1000000/r['cameraFrame']['start']['timescale'])for r in map(json.loads,(p/'timestamps.jsonl').read_text().splitlines())if r.get('role')=='camera' and r.get('disposition')=='accepted'][:4428]
import bisect
times=[4147522,4147523,16424883,16441500,181210793,181230000,250114772,250114773]
checks=[]
for absolute in times:
 at=absolute-origin
 target=out/f'canonical-{at}.png';r=call(f'canonical-frame-{at}','media.sourceFrame',{'asset':assets['canonical'],'available':available['canonical'],'atUs':at,'output':str(target),'maxLongEdge':320})
 yes=0<=at<250114773-origin;assert r['ok']==yes,r
 if not yes:
  assert not target.exists() and r['error']['code'] in ['UNAVAILABLE','SOURCE_PICTURE_UNAVAILABLE','INVALID_REQUEST'],r
  checks.append({'atUs':at,'outsideRefused':True});continue
 raw=out/f'raw-{at}.png';q=call(f'raw-frame-{at}','media.sourceFrame',{'asset':assets['raw'],'available':available['raw'],'atUs':at,'output':str(raw),'maxLongEdge':320});assert q['ok']
 expected=pts[bisect.bisect_right(pts,absolute)-1]-origin
 assert r['data']['actualSourceUs']==q['data']['actualSourceUs']==expected,(at,r,q,expected)
 assert target.read_bytes()==raw.read_bytes()
 checks.append({'atUs':at,'actualSourceUs':expected,'pngSha256':sha(target),'rawCanonicalExact':True})
report={'workerSha256':sha(w),'files':{n:{'path':str(f),'sha256':sha(f)}for n,f in files.items()},'availableDerivedFromActualProbe':available['canonical'],'metadata':metadata,'checks':checks,'calls':calls}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(checks))
