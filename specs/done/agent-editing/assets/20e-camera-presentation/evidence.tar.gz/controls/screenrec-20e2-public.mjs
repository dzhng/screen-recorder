import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {startProjectService} from '/Users/david/dev/screen-recorder/apps/service/dist/project-service.js';
import {cliReply} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/first-preview-transport.mjs';
const out='/tmp/screenrec-20e2-public';await mkdir(out);
const report={passed:false,calls:[]};let service;
const save=()=>writeFile(out+'/report.json',JSON.stringify(report,null,2));
async function call(operation,params,output){const r=await cliReply(['/Users/david/dev/screen-recorder/apps/cli/dist/main.js',operation,'--socket',service.socketPath,'--params',JSON.stringify(params),...(output?['--output',output]:[])]);report.calls.push({operation,params,output,response:r});await save();assert(r.ok,JSON.stringify(r));return r.data;}
async function ready(op,p){const deadline=Date.now()+180000;for(;;){const r=await call(op,p);if(r.state==='ready')return r;assert(!['failed','unavailable','canceled'].includes(r.state),JSON.stringify(r));assert(Date.now()<deadline);await delay(250);}}
try{
 service=await startProjectService({home:out+'/home'});
 const path='/tmp/screenrec-20e2-real-recovery/take/camera/video.mov';
 const imported=await call('asset.import',{requestId:'camera-presentation',path});
 const job=await ready('job.get',{jobId:imported.jobId});const asset=await call('asset.get',{assetId:job.result.assetId});report.asset=asset;
 const stream=asset.streams.find(s=>s.kind==='video');assert(stream);
 const segments=await call('asset.segments',{assetId:asset.id,streamId:stream.id,limit:1000});report.segments=segments;
 const created=await call('project.create',{requestId:'camera-presentation',title:'Retained camera presentation',canvas:{width:320,height:180,fps:{numerator:30,denominator:1},background:'#000000ff'}});
 const edited=await call('edit.apply',{projectId:created.project.projectId,requestId:'place',expectedRevisionId:created.revision.id,operations:[{operation:'track.add',label:'camera',track:{kind:'video',order:0}},{operation:'place',clip:{trackId:{label:'camera'},assetId:asset.id,streamId:stream.id,source:{kind:'range',range:{startUs:0,endUs:245967250}},placement:{kind:'project',range:{startUs:0,endUs:245967250}}}}]});
 const selected={projectId:created.project.projectId,revisionId:edited.revision.id};
 for(const [name,startUs,endUs,atUs]of[['first',12200000,12366667,12293977],['second',177000000,177166667,177082477]]){
  const frame={...selected,atUs,maxLongEdge:320};await ready('frame.get',frame);await call('frame.get',frame,out+'/'+name+'.png');
  const params={...selected,range:{startUs,endUs}};await ready('preview.get',params);await call('preview.get',params,out+'/'+name+'.mp4');
 }
 report.passed=true;
}catch(e){report.error={message:e.message,stack:e.stack};process.exitCode=1;}
finally{await service?.close();report.serviceClosed=true;await save();}
console.log(JSON.stringify({passed:report.passed,error:report.error,out}));
