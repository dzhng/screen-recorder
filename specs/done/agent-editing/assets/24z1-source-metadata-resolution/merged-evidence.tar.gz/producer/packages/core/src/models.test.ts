import { afterEach, expect, test, vi } from "vitest";
import { createHash, randomUUID } from "node:crypto";
import { once } from "node:events";
import { execFileSync } from "node:child_process";
import {
  mkdir,
  chmod,
  mkdtemp,
  readdir,
  readFile,
  realpath,
  readlink,
  rename,
  rm,
  stat,
  symlink,
  writeFile,
} from "node:fs/promises";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import { join } from "node:path";
import { CatalogError } from "./catalog.js";
import { parakeetModel, Models, type ModelManifest } from "./models.js";

const cleanups: (() => Promise<unknown> | void)[] = [];
afterEach(async () => {
  for (const cleanup of cleanups.splice(0).reverse()) await cleanup();
});

const contents: Record<string, Buffer> = {
  "Model.mlmodelc/weights/weight.bin": Buffer.alloc(256 * 1024, "weights"),
  "vocab.json": Buffer.from('{"0":"um"}'),
};
const pin = (path: string, body: Buffer) => ({
  path,
  bytes: body.length,
  sha256: createHash("sha256").update(body).digest("hex"),
});
const manifest: ModelManifest = {
  name: "tiny",
  purpose: "transcription",
  platform: { system: process.platform, architecture: process.arch },
  repo: "test/tiny-coreml",
  revision: "r1",
  folderName: "tiny-model",
  engine: {
    runtime: "TinyRuntime",
    runtimeVersion: "1.0.0",
    runtimeRevision: "c".repeat(40),
    decoder: "tiny-decoder",
  },
  files: Object.entries(contents).map(([path, body]) => pin(path, body)),
};
type Handler = (path: string, response: ServerResponse, request: IncomingMessage) => void;
const serveFile: Handler = (path, response) => {
  const body = contents[path];
  if (!body) return void response.writeHead(404).end();
  response.writeHead(200, { "content-length": body.length }).end(body);
};

async function fixture(handler: Handler = serveFile) {
  const home = await mkdtemp("/tmp/screenrec-speech-models-");
  cleanups.push(() => rm(home, { recursive: true, force: true }));
  const requests: string[] = [];
  const server = createServer((request, response) => {
    const prefix = `/${manifest.repo}/resolve/${manifest.revision}/`;
    const path = decodeURIComponent(request.url!.slice(prefix.length));
    handler(path, response, request);
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  cleanups.push(() => {
    server.closeAllConnections();
    server.close();
  });
  const origin = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const local: typeof fetch = (input, init) => {
    requests.push(String(input));
    return fetch(String(input).replace("https://huggingface.co", origin), init);
  };
  const open = (network: typeof fetch = local) => new Models(home, network, [manifest]);
  const models = join(await realpath(home), "models");
  return {
    home,
    requests,
    open,
    models,
    revision: join(models, "tiny", "r1"),
    staged: () => readdir(join(models, ".staging")),
  };
}
const offline: typeof fetch = () => {
  throw new Error("status and native requests must not use the network");
};
const failure = (code: string, retryable = false) =>
  expect.objectContaining({ code, retryable }) as unknown as CatalogError;
/** Sends the first bytes of a large file, then holds the response open until released. */
function stalling(path: string) {
  const held: ServerResponse[] = [];
  const handler: Handler = (requested, response) => {
    if (requested !== path) return serveFile(requested, response, undefined as never);
    const body = contents[path]!;
    response.writeHead(200, { "content-length": body.length });
    response.write(body.subarray(0, 1024));
    held.push(response);
  };
  return { handler, held };
}

test("prepare installs pinned files whole and reports them for the native request", async () => {
  const { open, requests, models, revision, staged } = await fixture();
  const speech = open();
  expect(await speech.status("tiny")).toEqual({ state: "absent" });

  await speech.prepare("tiny", new AbortController().signal);

  expect(await speech.status("tiny")).toEqual({ state: "ready" });
  expect(await speech.transcription("tiny").nativeRequest()).toEqual({
    directory: join(revision, "tiny-model"),
    files: manifest.files,
  });
  for (const [path, body] of Object.entries(contents))
    expect(await readFile(join(revision, "tiny-model", path))).toEqual(body);
  expect(JSON.parse(await readFile(join(revision, "receipt.json"), "utf8"))).toMatchObject({
    modelDigest: speech.transcription("tiny").modelDigest,
  });
  expect(requests.sort()).toEqual([
    "https://huggingface.co/test/tiny-coreml/resolve/r1/Model.mlmodelc/weights/weight.bin",
    "https://huggingface.co/test/tiny-coreml/resolve/r1/vocab.json",
  ]);
  expect(await staged()).toEqual([]);
  expect((await stat(models)).mode & 0o777).toBe(0o700);
});

test("the runtime pinned beside the model is the one the native worker resolves", async () => {
  const resolved = JSON.parse(
    await readFile(new URL("../../../helpers/mac/Package.resolved", import.meta.url), "utf8"),
  ) as { pins: { identity: string; state: { version?: string; revision: string } }[] };
  const fluidAudio = resolved.pins.find((pin) => pin.identity === "fluidaudio");
  expect(fluidAudio?.state).toEqual({
    version: parakeetModel.engine.runtimeVersion,
    revision: parakeetModel.engine.runtimeRevision,
  });
});

test("the model digest names the pinned file list, not the order it is declared in", async () => {
  const { home } = await fixture();
  const digest = new Models(home, offline, [manifest]).transcription("tiny").modelDigest;
  const reordered = { ...manifest, files: [...manifest.files].reverse() };
  expect(new Models(home, offline, [reordered]).transcription("tiny").modelDigest).toBe(digest);
  const repinned = {
    ...manifest,
    files: manifest.files.map((file, index) =>
      index ? file : { ...file, sha256: "0".repeat(64) },
    ),
  };
  expect(new Models(home, offline, [repinned]).transcription("tiny").modelDigest).not.toBe(digest);
});

test("status, native requests and an already prepared model never use the network", async () => {
  const { open } = await fixture();
  expect(await open(offline).status("tiny")).toEqual({ state: "absent" });
  await expect(open(offline).transcription("tiny").nativeRequest()).rejects.toEqual(
    failure("MODEL_NOT_PREPARED", true),
  );
  await open().prepare("tiny", new AbortController().signal);

  const restarted = open(offline);
  expect(await restarted.status("tiny")).toEqual({ state: "ready" });
  await restarted.prepare("tiny", new AbortController().signal);
  expect((await restarted.transcription("tiny").nativeRequest()).files).toEqual(manifest.files);
});

test("an interrupted download is retryable and leaves no model", async () => {
  const { open, revision, staged } = await fixture((path, response) => {
    const body = contents[path]!;
    response.writeHead(200, { "content-length": body.length });
    response.write(body.subarray(0, body.length / 2), () => response.destroy());
  });
  const speech = open();

  await expect(speech.prepare("tiny", new AbortController().signal)).rejects.toEqual(
    failure("MODEL_DOWNLOAD_FAILED", true),
  );

  expect(await speech.status("tiny")).toMatchObject({
    state: "failed",
    code: "MODEL_DOWNLOAD_FAILED",
    retryable: true,
  });
  await expect(stat(revision)).rejects.toMatchObject({ code: "ENOENT" });
  expect(await staged()).toEqual([]);
});

test("staging left by a process that stopped mid-download is removed on the next start", async () => {
  const { handler, held } = stalling("Model.mlmodelc/weights/weight.bin");
  const { open, revision, staged } = await fixture(handler);
  const controller = new AbortController();
  const preparing = open().prepare("tiny", controller.signal);
  cleanups.push(async () => {
    controller.abort();
    await preparing.catch(() => {});
  });
  await vi.waitFor(() => expect(held).toHaveLength(1));
  expect(await staged()).toHaveLength(1);

  const restarted = open(offline);

  expect(await staged()).toEqual([]);
  expect(await restarted.status("tiny")).toEqual({ state: "absent" });
  await expect(stat(revision)).rejects.toMatchObject({ code: "ENOENT" });
});

test("a file whose bytes differ from its pin is refused", async () => {
  const { open, revision, staged } = await fixture((path, response) => {
    const body = Buffer.from(contents[path]!);
    body[0] = body[0]! ^ 0xff;
    response.writeHead(200).end(body);
  });
  const speech = open();

  await expect(speech.prepare("tiny", new AbortController().signal)).rejects.toEqual(
    failure("MODEL_HASH_MISMATCH"),
  );

  expect(await speech.status("tiny")).toMatchObject({
    state: "failed",
    code: "MODEL_HASH_MISMATCH",
  });
  await expect(stat(revision)).rejects.toMatchObject({ code: "ENOENT" });
  expect(await staged()).toEqual([]);
});

test("a file longer or shorter than its pin is refused without reading past the pin", async () => {
  const responses: Handler[] = [
    // Never ends: only the size bound can stop this download.
    (path, response) =>
      void response.writeHead(200).write(Buffer.concat([contents[path]!, Buffer.from("x")])),
    (path, response) => void response.writeHead(200).end(contents[path]!.subarray(1)),
  ];
  for (const handler of responses) {
    const { open, revision } = await fixture(handler);
    const speech = open();

    await expect(speech.prepare("tiny", new AbortController().signal)).rejects.toEqual(
      failure("MODEL_HASH_MISMATCH"),
    );
    await expect(stat(revision)).rejects.toMatchObject({ code: "ENOENT" });
  }
});

test("a prepared file changed on disk reads as invalid until prepare replaces the install", async () => {
  const { open, requests, revision } = await fixture();
  const speech = open();
  await speech.prepare("tiny", new AbortController().signal);
  const vocabulary = join(revision, "tiny-model", "vocab.json");
  await writeFile(vocabulary, '{"0":"uh"}');

  expect(await speech.status("tiny")).toEqual({ state: "invalid" });
  await expect(speech.transcription("tiny").nativeRequest()).rejects.toEqual(
    failure("MODEL_NOT_PREPARED", true),
  );

  await speech.prepare("tiny", new AbortController().signal);
  expect(await speech.status("tiny")).toEqual({ state: "ready" });
  expect(await readFile(vocabulary)).toEqual(contents["vocab.json"]);
  expect(requests).toHaveLength(4);
});

test("an extra file inside the model folder makes the install invalid", async () => {
  const { open, revision } = await fixture();
  const speech = open();
  await speech.prepare("tiny", new AbortController().signal);
  await mkdir(join(revision, "tiny-model", "Extra.mlmodelc"));
  await writeFile(join(revision, "tiny-model", "Extra.mlmodelc", "model.mil"), "");

  expect(await speech.status("tiny")).toEqual({ state: "invalid" });
});

test("concurrent prepares join one download", async () => {
  const { handler, held } = stalling("Model.mlmodelc/weights/weight.bin");
  const { open, requests } = await fixture(handler);
  const speech = open();

  const first = speech.prepare("tiny", new AbortController().signal);
  await vi.waitFor(() => expect(held).toHaveLength(1));
  expect(await speech.status("tiny")).toMatchObject({
    state: "preparing",
    totalBytes: manifest.files.reduce((total, file) => total + file.bytes, 0),
  });
  const second = speech.prepare("tiny", new AbortController().signal);
  held[0]!.end(contents["Model.mlmodelc/weights/weight.bin"]!.subarray(1024));

  await Promise.all([first, second]);
  expect(await speech.status("tiny")).toEqual({ state: "ready" });
  expect(requests.filter((url) => url.endsWith("weight.bin"))).toHaveLength(1);
});

test("a caller that aborts leaves a joined prepare running", async () => {
  const { handler, held } = stalling("Model.mlmodelc/weights/weight.bin");
  const { open } = await fixture(handler);
  const speech = open();
  const leaving = new AbortController();
  const left = speech.prepare("tiny", leaving.signal);
  const stayed = speech.prepare("tiny", new AbortController().signal);
  await vi.waitFor(() => expect(held).toHaveLength(1));

  leaving.abort(new Error("left"));
  await expect(left).rejects.toThrow("left");
  held[0]!.end(contents["Model.mlmodelc/weights/weight.bin"]!.subarray(1024));

  await stayed;
  expect(await speech.status("tiny")).toEqual({ state: "ready" });
});

test("abort by every caller stops the download and leaves no model", async () => {
  const { handler, held } = stalling("Model.mlmodelc/weights/weight.bin");
  const { open, revision, staged } = await fixture(handler);
  const speech = open();
  const controller = new AbortController();
  const preparing = speech.prepare("tiny", controller.signal);
  await vi.waitFor(() => expect(held).toHaveLength(1));

  controller.abort(new Error("stopped"));

  await expect(preparing).rejects.toThrow("stopped");
  expect(await speech.status("tiny")).toEqual({ state: "absent" });
  await expect(stat(revision)).rejects.toMatchObject({ code: "ENOENT" });
  expect(await staged()).toEqual([]);
});

test("a models directory that is a link is refused", async () => {
  const { home } = await fixture();
  const elsewhere = join(home, randomUUID());
  await mkdir(elsewhere);
  await symlink(elsewhere, join(home, "models"));

  expect(() => new Models(home, offline, [manifest])).toThrow(failure("MODEL_STORAGE_FAILED"));
});

async function voiceFixture() {
  const home = await mkdtemp("/tmp/screenrec-model-runtime-");
  cleanups.push(() => rm(home, { recursive: true, force: true }));
  const f = {
    home,
    models: join(await realpath(home), "models"),
    staged: () => readdir(join(home, "models/.staging")),
  };
  const runtime = join(f.home, "runtime-source"),
    source = join(f.home, "model-source");
  await mkdir(runtime);
  await mkdir(source);
  for (const [path, body] of Object.entries(contents)) {
    await mkdir(join(source, path, ".."), { recursive: true });
    await writeFile(join(source, path), body);
  }
  const executable = Buffer.from("a pinned executable");
  await writeFile(join(runtime, "worker"), executable, { mode: 0o700 });
  await symlink("worker", join(runtime, "python"));
  const entries = [
    { kind: "file" as const, mode: 0o700, ...pin("worker", executable) },
    { kind: "symlink" as const, mode: 0o755, path: "python", target: "worker" },
  ];
  const voice: ModelManifest = {
    ...manifest,
    name: "voice",
    purpose: "voice",
    runtimeArtifact: {
      digest: createHash("sha256").update(JSON.stringify(entries)).digest("hex"),
      entries,
      python: "worker",
      entry: "worker",
    },
  };
  const owner = () => new Models(f.home, offline, [manifest, voice]);
  return {
    ...f,
    owner,
    runtime,
    source,
    voice,
    sources: { runtimeSource: runtime, modelSource: source },
  };
}

test("local runtime and model adoption survives restart and detects changed executable bytes", async () => {
  const f = await voiceFixture(),
    models = f.owner();
  const descriptor = models.list().find((entry) => entry.modelId === "voice")!;
  expect(descriptor.preparation.runtimeSourceRequired).toBe(true);
  expect(await models.status("voice")).toEqual({ state: "absent" });
  await models.prepare("voice", new AbortController().signal, f.sources);
  const ready = await models.voice("voice");
  expect(await readFile(ready.python)).toEqual(Buffer.from("a pinned executable"));
  expect((await stat(ready.python)).ino).not.toBe((await stat(join(f.runtime, "worker"))).ino);
  expect((await stat(ready.python)).mode & 0o777).toBe(0o700);
  expect(await f.owner().status("voice")).toEqual({ state: "ready" });
  await models.prepare("voice", new AbortController().signal);
  expect((await models.voice("voice")).descriptorDigest).toBe(descriptor.descriptorDigest);
  const changed = Buffer.from(await readFile(ready.python));
  changed[0] = changed[0]! ^ 0xff;
  await writeFile(ready.python, changed);
  expect(await models.status("voice")).toEqual({ state: "invalid" });
  await expect(models.voice("voice")).rejects.toMatchObject({ code: "MODEL_NOT_PREPARED" });
  expect(await readFile(join(f.runtime, "worker"))).toEqual(Buffer.from("a pinned executable"));
});

test("a changed source or escaping runtime link never publishes a prepared model", async () => {
  const f = await voiceFixture(),
    models = f.owner();
  await rm(join(f.runtime, "python"));
  await symlink("../outside", join(f.runtime, "python"));
  await expect(
    models.prepare("voice", new AbortController().signal, f.sources),
  ).rejects.toMatchObject({ code: "MODEL_HASH_MISMATCH" });
  expect(await f.staged()).toEqual([]);
  expect(await models.status("tiny")).toEqual({ state: "absent" });
  await rm(join(f.runtime, "python"));
  await symlink("worker", join(f.runtime, "python"));
  await writeFile(join(f.runtime, "worker"), "changed");
  await expect(
    models.prepare("voice", new AbortController().signal, f.sources),
  ).rejects.toMatchObject({ code: "MODEL_HASH_MISMATCH" });
  expect(await f.staged()).toEqual([]);
  await expect(stat(join(f.models, "voice", "r1"))).rejects.toMatchObject({ code: "ENOENT" });
});

test("runtime source and registered identity are explicit, and discovery needs no installed bytes", async () => {
  const f = await voiceFixture(),
    models = f.owner();
  expect(models.list().map((entry) => entry.modelId)).toEqual(["tiny", "voice"]);
  await expect(models.status("unknown")).rejects.toMatchObject({ code: "UNKNOWN_MODEL" });
  await expect(models.prepare("voice", new AbortController().signal)).rejects.toMatchObject({
    code: "MODEL_SOURCE_REQUIRED",
  });
  expect(() =>
    models.prepare("voice", new AbortController().signal, { runtimeSource: "relative" }),
  ).toThrow();
  expect(await f.staged()).toEqual([]);
});

test("concurrent verification waits for current bytes while other model requests advance", async () => {
  const f = await voiceFixture(),
    models = f.owner();
  await models.prepare("voice", new AbortController().signal, f.sources);
  let complete = false;
  const first = models.status("voice").then((value) => {
    complete = true;
    return value;
  });
  const second = models.status("voice");
  expect(await models.status("tiny")).toEqual({ state: "absent" });
  expect(complete).toBe(false);
  expect(models.list().find((entry) => entry.modelId === "voice")?.purpose).toBe("voice");
  expect(await first).toEqual({ state: "ready" });
  expect(await second).toEqual({ state: "ready" });
  const receipt = await models.voice("voice");
  expect(await readlink(join(receipt.python, "..", "python"))).toBe("worker");
  await rename(receipt.python, receipt.python + ".missing");
  expect(await models.status("voice")).toEqual({ state: "invalid" });
});

test("canceling a local runtime admission drains its private stage without affecting another model", async () => {
  const f = await voiceFixture(),
    models = f.owner(),
    controller = new AbortController();
  const pending = models.prepare("voice", controller.signal, f.sources);
  controller.abort(new Error("cancel local admission"));
  await expect(pending).rejects.toThrow("cancel local admission");
  expect(await f.staged()).toEqual([]);
  expect(await models.status("tiny")).toEqual({ state: "absent" });
  expect(await models.status("voice")).toEqual({ state: "absent" });
});

test("registered platform requirements cannot become false ready execution inputs", async () => {
  const f = await voiceFixture();
  const models = new Models(f.home, offline, [
    { ...f.voice, platform: { system: "unsupported", architecture: "unsupported" } },
  ]);
  expect(await models.status("voice")).toMatchObject({
    state: "failed",
    code: "MODEL_PLATFORM_UNSUPPORTED",
    retryable: false,
  });
  expect(() => models.prepare("voice", new AbortController().signal, f.sources)).toThrow(
    expect.objectContaining({ code: "MODEL_PLATFORM_UNSUPPORTED" }),
  );
  await expect(models.voice("voice")).rejects.toMatchObject({ code: "MODEL_PLATFORM_UNSUPPORTED" });
  expect(models.list()[0]?.platform.system).toBe("unsupported");
});

test("runtime admission preserves pinned directory modes under a restrictive service umask", async () => {
  const f = await voiceFixture();
  await mkdir(join(f.runtime, "data"));
  await chmod(join(f.runtime, "data"), 0o755);
  const entries = [
    ...f.voice.runtimeArtifact!.entries,
    { kind: "directory" as const, path: "data", mode: 0o755 },
  ];
  const voice = {
    ...f.voice,
    runtimeArtifact: {
      ...f.voice.runtimeArtifact!,
      entries,
      digest: createHash("sha256").update(JSON.stringify(entries)).digest("hex"),
    },
  };
  const models = new Models(f.home, offline, [voice]);
  const original = process.umask(0o077);
  try {
    await models.prepare("voice", new AbortController().signal, f.sources);
    const prepared = await models.voice("voice");
    expect((await stat(join(prepared.python, "..", "data"))).mode & 0o777).toBe(0o755);
  } finally {
    process.umask(original);
  }
});

test("voice joiners and another model prepare independently without cross-canceling", async () => {
  const f = await voiceFixture(),
    models = f.owner(),
    left = new AbortController(),
    right = new AbortController();
  const departing = models.prepare("voice", left.signal, f.sources);
  const joined = models.prepare("voice", right.signal, f.sources);
  const transcription = models.prepare("tiny", new AbortController().signal, {
    modelSource: f.source,
  });
  left.abort(new Error("caller departed"));
  await expect(departing).rejects.toThrow("caller departed");
  await Promise.all([joined, transcription]);
  expect(await models.status("voice")).toEqual({ state: "ready" });
  expect(await models.status("tiny")).toEqual({ state: "ready" });
  expect(await f.staged()).toEqual([]);
});

test("a FIFO model source is refused instead of waiting for a writer", async () => {
  const f = await voiceFixture(),
    models = f.owner();
  const path = join(f.source, manifest.files[0]!.path);
  await rm(path);
  execFileSync("mkfifo", [path]);
  await expect(
    models.prepare("tiny", new AbortController().signal, { modelSource: f.source }),
  ).rejects.toMatchObject({ code: "MODEL_HASH_MISMATCH" });
  expect(await f.staged()).toEqual([]);
});
