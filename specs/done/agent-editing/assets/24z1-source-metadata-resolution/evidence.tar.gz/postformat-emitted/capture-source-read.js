import { createHash } from "node:crypto";
import { z } from "zod";
import { intervalIndex, fromTime, toTime, toSignedTime, subtract, add, compare, ceil, sourceAvailability, } from "@screenrec/composition";
import { compositionAsset } from "./assets.js";
import { CatalogError } from "./catalog.js";
import { selectSource, selectSourceSupport, sourceSelectionSchema, } from "./source-selection.js";
// Leave headroom for transport envelopes beneath the public eight-MiB frame bound.
export function boundSourceEvidenceResponse(value) {
    if (Buffer.byteLength(JSON.stringify(value)) > 4 * 1024 * 1024)
        throw new CatalogError("LIMIT_EXCEEDED", "Source evidence response exceeds 4MiB; narrow the range, tracks or page limit");
}
export const initialCapture = () => ({
    cursor: { after: null, done: false, row: null },
    pause: { after: null, done: false, row: null },
    geometry: { after: null, done: false, row: null },
    interruption: { after: null, done: false, row: null },
});
const index = { cursor: "cursor", pause: "pauses", geometry: "geometry" };
const sourcePositionSchema = z.strictObject({
    after: z.tuple([z.number().int().nonnegative(), z.number().int().nonnegative()]).nullable(),
    done: z.boolean(),
});
export const capturePositionSchema = z.strictObject({
    cursor: sourcePositionSchema,
    pause: sourcePositionSchema,
    geometry: sourcePositionSchema,
    interruption: sourcePositionSchema,
});
const digest = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
/** Explicit capture authority and clock conversion, shared by source and project inspection. */
export class CaptureSourceRead {
    assets;
    acquisitions;
    records;
    constructor(assets, acquisitions, records) {
        this.assets = assets;
        this.acquisitions = acquisitions;
        this.records = records;
    }
    resolve(selection, domain) {
        return this.resolveMany([selection], domain)[0];
    }
    /** A synchronous validation phase shares immutable rows; the next phase starts fresh. */
    resolveMany(selections, domain) {
        const assets = new Map();
        const acquisitions = new Map();
        return selections.map((input) => {
            const selection = sourceSelectionSchema.parse(input);
            let asset = assets.get(selection.assetId);
            if (!asset) {
                asset = compositionAsset(this.assets.get(selection.assetId));
                assets.set(selection.assetId, asset);
            }
            let acquisition = selection.acquisitionId === undefined
                ? undefined
                : acquisitions.get(selection.acquisitionId);
            if (!acquisition && selection.acquisitionId !== undefined) {
                acquisition = this.acquisitions.get(selection.acquisitionId);
                acquisitions.set(selection.acquisitionId, acquisition);
            }
            return this.context(selectSourceSupport(asset, acquisition, selection), acquisition, domain);
        });
    }
    context(selected, acquisition, domain) {
        const binding = selected.binding;
        const visual = selected.stream.kind === "video" && binding?.sourceRoles.includes("video");
        const capability = (kind, applicable = true) => ({
            kind,
            state: acquisition && applicable ? "ready" : "unavailable",
            reason: !acquisition
                ? "capture_context_missing"
                : applicable
                    ? null
                    : "requires_captured_video",
        });
        const receipt = acquisition?.evidence.receipt;
        const completion = receipt?.completion;
        const terminal = receipt?.lastLifecycle?.state;
        const interruptionReason = !acquisition
            ? "capture_context_missing"
            : receipt?.incompleteTail || receipt?.invalidAtSequence != null
                ? "capture_completion_untrusted"
                : !completion
                    ? "capture_completion_unknown"
                    : terminal &&
                        ["complete", "interrupted", "canceled"].includes(terminal) &&
                        terminal !== completion.state
                        ? "capture_completion_conflict"
                        : null;
        const coverage = domain === "cursor"
            ? [capability("cursor", !!visual)]
            : [
                capability("pause"),
                capability("geometry", !!visual),
                { kind: "unplaced_geometry", state: "unavailable", reason: "no_source_time" },
                {
                    kind: "interruption",
                    state: interruptionReason ? "unavailable" : "ready",
                    reason: interruptionReason,
                },
                ...["scene", "cut"].map((kind) => ({
                    kind,
                    state: "unavailable",
                    reason: "unsupported",
                })),
            ];
        return {
            selection: selected.selection,
            domain,
            durationUs: selected.durationUs,
            sourceToAssetOffsetUs: binding?.sourceToAssetOffsetUs ?? 0,
            supportDigest: selected.supportDigest,
            evidence: acquisition?.evidence ?? null,
            coverage,
        };
    }
    /** Pointer history keeps the acquisition clock, independently of an edited clip range.
     * assetUs = captureUs + sourceToAssetOffsetUs; containerUs = assetUs + originUs. */
    presentation(selection) {
        const context = this.resolve(selection, "cursor");
        if (!context.evidence || context.coverage.some((item) => item.state !== "ready"))
            throw new CatalogError("UNAVAILABLE", "Pointer history requires captured-video authority", {
                coverage: context.coverage,
            });
        const selected = selectSource(this.assets, this.acquisitions, selection);
        const clockOffsetUs = toSignedTime(subtract(fromTime(context.sourceToAssetOffsetUs), fromTime(selected.track.sourceOffsetUs)));
        const span = {
            startUs: ceil(subtract(fromTime(selected.stream.bounds.startUs), fromTime(context.sourceToAssetOffsetUs))),
            endUs: ceil(subtract(fromTime(selected.stream.bounds.endUs), fromTime(context.sourceToAssetOffsetUs))),
        };
        if (typeof clockOffsetUs !== "number" ||
            !Number.isSafeInteger(clockOffsetUs) ||
            !Number.isSafeInteger(span.startUs) ||
            !Number.isSafeInteger(span.endUs) ||
            span.startUs < 0 ||
            span.endUs <= span.startUs)
            throw new CatalogError("INVALID_EVIDENCE", "Capture presentation clock exceeds its valid source history");
        return {
            source: selected.track.source,
            streamId: selection.streamId,
            clockOffsetUs,
            spans: [span],
            evidence: context.evidence,
        };
    }
    /** undefined means bounded work exhausted; null means this source window is complete. */
    next(context, range, state, budget) {
        if (!context.evidence)
            return null;
        const kinds = context.coverage
            .filter((c) => c.state === "ready")
            .map((c) => c.kind);
        const captureRange = {
            startUs: Math.max(0, ceil(subtract(fromTime(range.startUs), fromTime(context.sourceToAssetOffsetUs)))),
            endUs: Math.max(0, ceil(subtract(fromTime(range.endUs), fromTime(context.sourceToAssetOffsetUs)))),
        };
        for (const kind of kinds) {
            const position = state[kind];
            if (position.row || position.done)
                continue;
            if (budget.remaining-- <= 0)
                return undefined;
            if (kind === "interruption") {
                position.done = true;
                const completion = context.evidence.receipt.completion;
                if (completion?.state === "interrupted") {
                    const source = add(fromTime(completion.durationUs), fromTime(context.sourceToAssetOffsetUs));
                    if (compare(source, fromTime(range.startUs)) > 0 &&
                        compare(source, fromTime(range.endUs)) <= 0) {
                        position.done = false;
                        position.row = {
                            kind,
                            sourceAtUs: toTime(source),
                            captureAtUs: completion.durationUs,
                            sourceSequence: completion.sequence,
                            observation: {
                                state: completion.state,
                                durationUs: completion.durationUs,
                                ...(completion.failureCode == null ? {} : { failureCode: completion.failureCode }),
                                ...(completion.failureMessage == null
                                    ? {}
                                    : { failureMessage: completion.failureMessage }),
                            },
                        };
                    }
                }
                continue;
            }
            if (captureRange.startUs >= captureRange.endUs) {
                position.done = true;
                continue;
            }
            const row = this.records.pointRecords(context.evidence, index[kind], captureRange, position.after, 1)[0];
            if (!row) {
                position.done = true;
                continue;
            }
            const captureAtUs = row.sourceUs;
            position.row = {
                kind,
                sourceAtUs: toTime(add(fromTime(captureAtUs), fromTime(context.sourceToAssetOffsetUs))),
                captureAtUs,
                sourceSequence: row.sequence,
                observation: JSON.parse(row.content),
            };
        }
        const head = kinds
            .map((kind) => state[kind].row)
            .filter((row) => !!row)
            .sort((a, b) => compare(fromTime(a.sourceAtUs), fromTime(b.sourceAtUs)) ||
            a.sourceSequence - b.sourceSequence ||
            a.kind.localeCompare(b.kind))[0];
        if (!head)
            return null;
        state[head.kind].row = null;
        if (head.kind === "interruption")
            state[head.kind].done = true;
        state[head.kind].after = [head.captureAtUs, head.sourceSequence];
        return head;
    }
    events(input) {
        return this.get(input, "events");
    }
    cursor(input) {
        return this.get(input, "cursor");
    }
    get(input, domain) {
        const selection = {
            assetId: input.assetId,
            streamId: input.streamId,
            ...(input.acquisitionId === undefined ? {} : { acquisitionId: input.acquisitionId }),
        };
        const context = this.resolve(selection, domain);
        const range = input.sourceRange ?? { startUs: 0, endUs: ceil(fromTime(context.durationUs)) };
        const limit = input.limit ?? (domain === "events" ? 100 : 1000), maximum = domain === "events" ? 500 : 5000;
        if (!Number.isSafeInteger(range.startUs) ||
            !Number.isSafeInteger(range.endUs) ||
            range.startUs < 0 ||
            range.endUs <= range.startUs ||
            range.endUs > ceil(fromTime(context.durationUs)))
            throw new CatalogError("INVALID_RANGE", "Capture evidence range must be within the selected stream");
        if (!Number.isSafeInteger(limit) || limit < 1 || limit > maximum)
            throw new CatalogError("INVALID_PARAMS", `Limit must be 1 to ${maximum}`);
        const reference = digest({ context, range });
        let position = initialCapture();
        if (input.cursor !== undefined) {
            const cursor = z
                .strictObject({ reference: z.string(), position: capturePositionSchema })
                .safeParse(input.cursor);
            if (!cursor.success)
                throw new CatalogError("INVALID_PARAMS", "Invalid capture evidence cursor");
            if (cursor.data.reference !== reference)
                throw new CatalogError("ARTIFACT_CHANGED", "Capture evidence or filters changed");
            for (const kind of Object.keys(position))
                position[kind] = { ...cursor.data.position[kind], row: null };
        }
        const selected = selectSource(this.assets, this.acquisitions, selection);
        const available = intervalIndex(selected.track.available, (r) => ({
            start: fromTime(r.startUs),
            end: fromTime(r.endUs),
        }));
        const rows = [];
        const budget = { remaining: 128 };
        let more = true;
        while (rows.length < limit) {
            const row = this.next(context, range, position, budget);
            if (row === undefined)
                break;
            if (row === null) {
                more = false;
                break;
            }
            const at = fromTime(row.sourceAtUs);
            if ((row.kind === "interruption" ? available.before(at) : available(at)).length)
                rows.push(row);
        }
        const ready = context.coverage.some((c) => c.state === "ready");
        const result = {
            ...selection,
            ...(input.cursor === undefined
                ? {
                    available: sourceAvailability(selected.track.available, [range]),
                }
                : {}),
            state: ready ? "ready" : "unavailable",
            context,
            sourceRange: range,
            page: ready
                ? {
                    rows,
                    nextCursor: more
                        ? {
                            reference,
                            position: Object.fromEntries(Object.entries(position).map(([kind, { after, done }]) => [
                                kind,
                                { after, done },
                            ])),
                        }
                        : null,
                }
                : null,
        };
        boundSourceEvidenceResponse(result);
        return result;
    }
}
