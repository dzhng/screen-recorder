import { createHash } from "node:crypto";
import { mediaClipSchema, sourceAvailability, toSignedTime, subtract, fromTime, } from "@screenrec/composition";
import { compositionAsset } from "./assets.js";
import { CatalogError } from "./catalog.js";
export const sourceSelectionSchema = mediaClipSchema.pick({
    assetId: true,
    streamId: true,
    acquisitionId: true,
});
/** Resolve immutable source inputs without inventing a recording or a project timeline. */
export function selectSource(assets, acquisitions, input) {
    const selection = sourceSelectionSchema.parse(input);
    const asset = assets.get(selection.assetId);
    const acquisition = selection.acquisitionId === undefined ? undefined : acquisitions.get(selection.acquisitionId);
    return selectSourceMetadata(asset, assets.path(asset.id), acquisition, selection);
}
/** Identical selection rules apply to immutable admitted metadata before catalog publication. */
export function selectSourceMetadata(asset, path, acquisition, input) {
    const selected = selectSourceSupport(compositionAsset(asset), acquisition, input);
    return {
        selection: selected.selection,
        stream: selected.stream,
        durationUs: selected.durationUs,
        supportDigest: selected.supportDigest,
        track: {
            source: path,
            streamId: selected.stream.id,
            sourceOffsetUs: toSignedTime(subtract(fromTime(0), fromTime(asset.originUs))),
            available: selected.available,
        },
    };
}
/** Evidence needs the same source authority and support without a renderable file address. */
export function selectSourceSupport(asset, acquisition, input) {
    const selection = sourceSelectionSchema.parse(input);
    if (asset.id !== selection.assetId || acquisition?.id !== selection.acquisitionId)
        throw new CatalogError("INVALID_PARAMS", "Source metadata differs from selection");
    const stream = asset.streams.find((value) => value.id === selection.streamId);
    if (!stream || stream.kind === "image")
        throw new CatalogError("UNSUPPORTED_MEDIA", "Source inspection requires a decodable timed stream", selection);
    const binding = acquisition?.bindings.find((value) => value.assetId === asset.id && value.streamId === stream.id);
    if (acquisition && !binding)
        throw new CatalogError("INVALID_PARAMS", "Acquisition does not bind the selected asset and stream", selection);
    const available = sourceAvailability(stream.available, binding?.available);
    const supportDigest = createHash("sha256").update(JSON.stringify(available)).digest("hex");
    return {
        selection,
        stream,
        durationUs: stream.bounds.endUs,
        supportDigest,
        binding,
        available,
    };
}
export const sourceSelectionKey = (value) => JSON.stringify([value.assetId, value.streamId, value.acquisitionId ?? null]);
