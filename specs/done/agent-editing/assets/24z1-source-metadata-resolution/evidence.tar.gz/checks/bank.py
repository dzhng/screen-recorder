import json, hashlib, shutil, tarfile, subprocess
from pathlib import Path
root=Path('/Users/david/.codex/worktrees/source-metadata-resolution/screen-recorder')
scratch=Path('/tmp/screenrec-24z1-resolution')
stage=scratch/'bank'
packet=root/'specs/agent-editing/assets/24z1-source-metadata-resolution'
stage.mkdir(exist_ok=False)
def digest(b): return hashlib.sha256(b).hexdigest()
def copy(src,dest):
 p=stage/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
for file in scratch.iterdir():
 if file.is_file() and file.suffix in ['.log','.json','.ts','.mjs','.py']:copy(file,'checks/'+file.name)
for name in ['public','public-resumed','public-correct-route']:
 for file in (scratch/name).iterdir():
  if file.is_file():copy(file,'attempts/'+name+'/'+file.name)
r=json.loads((scratch/'public-correct-route/report.json').read_text())
for read in r['reads']:
 for id in read['checkpoints']:copy(Path(r['home'])/'library/cache/derived'/f'{id}.cache','checkpoints/'+f'{id}.cache')
for a in r['fixture']['acquisitions']:
 for src in [Path(a['evidence']['receipt']['file']),Path(r['home'])/'library/acquisitions'/a['id']/a['journal']['fileName']]:
  copy(src,'admitted/'+a['id']+'/'+src.name)
copy(root/'specs/agent-editing/assets/10d-public-scenes/authored-source.mov','inputs/authored-source.mov')
copy(Path(r['home'])/'donor/capture.journal.jsonl','inputs/authored-journal.jsonl')
inputs=json.loads((scratch/'runtime-metafile.json').read_text())['inputs']
runtime=[]
replacements={'packages/test-harness/editing/source-metadata.mjs':scratch/'executed-source-metadata.mjs','packages/test-harness/editing/evidence-service.mjs':scratch/'executed-evidence-service.mjs'}
for name in sorted(inputs):
 path=(root/name).resolve()
 if path.is_relative_to(root):dest='runtime/'+str(path.relative_to(root))
 else:dest='runtime/external/'+str(path.relative_to(Path('/Users/david/dev/screen-recorder/node_modules')))
 producer=replacements.get(name,path)
 copy(producer,dest)
 runtime.append({'input':name,'resolvedPath':str(path),'archivePath':dest,'bytes':producer.stat().st_size,'sha256':digest(producer.read_bytes()),'executedSnapshot':name in replacements})
for base in ['apps/service','apps/cli','packages/core','packages/client','packages/protocol','packages/composition']:
 for src in (root/base/'src').rglob('*'):
  if src.is_file():copy(src,'source/'+str(src.relative_to(root)))
 copy(root/base/'package.json','source/'+base+'/package.json')
for src in [root/'package.json',root/'bun.lock',root/'AGENTS.md',root/'README.md']:
 copy(src,'source/'+src.name)
for rel in ['packages/test-harness/editing/source-metadata.mjs','packages/test-harness/editing/evidence-service.mjs']:
 copy(root/rel,'source/'+rel)
worker=Path('/tmp/screenrec-09c-native-presented-worker')
workerPin={'path':str(worker),'sha256':digest(worker.read_bytes()),'bytes':worker.stat().st_size}
assert workerPin['sha256']=='0a9cd72a62af990a2bccef585184df0a2bbc36220a2fc258e0198ee43d726928'
(stage/'runtime-pins.json').write_text(json.dumps({'metafilePurpose':'Read-only bundle analysis identifies local imported graph; service/harness ran unbundled Node. Executed pre-format MJS snapshots and loaded emitted JS retained. Source tree snapshots are final formatted reference, not a claim of producer byte equivalence.','baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'inputs':runtime,'node':subprocess.check_output(['node','--version'],text=True).strip(),'nativeWorker':workerPin},indent=2)+'\n')
files={str(p.relative_to(stage)):{'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(stage.rglob('*')) if p.is_file()}
archive=packet/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in files:tar.add(stage/name,arcname=name,recursive=False)
manifest={'scope':'Fresh source metadata functional/work proof; no latency claim','archive':{'file':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes())},'runtimeGraphInputs':len(runtime),'files':files}
(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={'passed':r['passed'],'cardinalityArms':[{'cardinality':a['cardinality'],'rowCount':len(a['rows']),'pageRows':a['pageRows'],'metadataReads':a['counts'],'checkpointCount':len(a['checkpoints']),'nativeCallsDuringRead':a['nativeCallsDuringRead']} for a in r['reads']],'regression':{'before':{'headers':8,'segments':20,'acquisitions':8},'after':{'headers':2,'segments':10,'acquisitions':4}},'postAwaitFalsification':'Expected ARTIFACT_CHANGED becomes stale successful rows with second validation removed; exact source restored and green','checks':{'projectEvidenceFull':'34/34 pass','settledNewRegressions':'2/2 pass','broaderOwners':'104/107 pass; three unchanged 5s deadlines failed under contention, retained','coreTypes':0,'lint':0,'format':0},'remaining':'Original p95 RED9983/17688ms and full-scale 250ms SLA remain open; no original warm cohort repeated','originals':r['originals'],'archive':manifest['archive'],'runtimeGraphInputs':len(runtime),'archivedFiles':len(files),'nativeWorker':workerPin}
(packet/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for m in members:
  b=tar.extractfile(m).read();assert len(b)==files[m.name]['bytes'];assert digest(b)==files[m.name]['sha256']
print(json.dumps({'archive':manifest['archive'],'files':len(files),'runtimeGraphInputs':len(runtime),'verified':True}))
