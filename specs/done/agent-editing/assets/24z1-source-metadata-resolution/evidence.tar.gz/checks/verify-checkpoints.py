import json, hashlib
from pathlib import Path
base = Path('/tmp/screenrec-24z1-resolution/public-correct-route')
r = json.loads((base/'report.json').read_text())
results = []
for arm, read in zip(r['fixture']['arms'], r['reads']):
    cursors = {}
    for exchange in r['exchanges']:
        if exchange['request']['operation'] != 'cursor.raw': continue
        if exchange['request']['params']['projectId'] != arm['projectId']: continue
        reply = exchange['response'].get('structuredContent', exchange['response'])
        if not reply.get('ok'): continue
        page = reply['data'].get('page')
        if page and page['nextCursor']:
            cursor = page['nextCursor']
            cursors[cursor['checkpointId']] = cursor
    checkpoints = []
    for id in read['checkpoints']:
        path = Path(r['home'])/'library/cache/derived'/f'{id}.cache'
        b = path.read_bytes()
        state = json.loads(b)
        cursor = cursors[id]
        assert state['manifestId'] == cursor['manifestId']
        assert state['queryDigest'] == cursor['queryDigest']
        assert state['kind'] == 'events'
        checkpoints.append({'id': id, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'expectedCursor': cursor, 'state': state})
    assert len({x['sha256'] for x in checkpoints}) == 7
    results.append({'cardinality': arm['cardinality'], 'checkpoints': checkpoints})
(base/'checkpoint-verification.json').write_text(json.dumps(results,indent=2)+'\n')
print('14 advancing checkpoint byte hashes match actual public cursor manifest/query digests')
