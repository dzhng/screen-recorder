import struct,json
from pathlib import Path
p=Path('/tmp/screenrec-rational-phase')
def wav(path):
 b=Path(path).read_bytes();i=12;fmt=data=None
 while i+8<=len(b):
  name=b[i:i+4];n=struct.unpack_from('<I',b,i+4)[0];v=b[i+8:i+8+n];i+=8+n+(n%2)
  if name==b'fmt ':fmt=v
  if name==b'data':data=v
 kind,ch,rate=struct.unpack_from('<HHI',fmt);bits=struct.unpack_from('<H',fmt,14)[0]
 if kind==65534:kind=struct.unpack_from('<H',fmt,24)[0]
 if kind==1 and bits==16:return ch,rate,[v/32768 for v in struct.unpack('<'+'h'*(len(data)//2),data)]
 assert kind==3 and bits==32,(path,kind,bits)
 return ch,rate,list(struct.unpack('<'+'f'*(len(data)//4),data))
c,r,original=wav('/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/specs/agent-editing/assets/00-corpus/a-audio.wav');assert(c,r)==(1,48000)
expected=original[:32768]+[0.0]*(40960-32768)+original[40960:96000]
checks={}
for name in ['source','project','prepared','late']:
 c,r,samples=wav(p/('verify-'+name+'.wav'));base=original[52800:62400] if name=='late' else expected;want=[v for v in base for _ in range(c)]
 assert r==48000 and samples==want,name
 checks[name]={'channels':c,'rate':r,'frames':len(samples)//c,'exactOriginalPCM':True}
seed=wav(p/'seed-late.wav')[2];assert seed==original[52801:62401] and seed!=original[52800:62400]
checks['oldLate']={'matchedShiftedOriginal52801':True}
(p/'public-pcm-check.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
