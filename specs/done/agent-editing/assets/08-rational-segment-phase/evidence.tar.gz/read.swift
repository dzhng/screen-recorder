import Foundation
import ScreenRecorderAudio
import ScreenRecorderMedia
let source = CommandLine.arguments[1], out = CommandLine.arguments[2]
try FileManager.default.createDirectory(atPath: out, withIntermediateDirectories: true)
for (name,range) in [("full", TimeSpan(startUs:0,endUs:2100000)),("late",TimeSpan(startUs:1200000,endUs:1400000))] {
 let result = try await SourceAudio.write(source:.init(source:source,sourceOffsetUs:0,available:[.init(startUs:0,endUs:2100000)]),range:range,output:URL(fileURLWithPath:out+"/"+name+".wav"))
 try JSONEncoder().encode(result).write(to:URL(fileURLWithPath:out+"/"+name+".json"))
}
