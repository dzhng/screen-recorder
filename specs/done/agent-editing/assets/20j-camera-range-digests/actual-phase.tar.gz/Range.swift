@preconcurrency import AVFoundation
import Foundation
import CoreVideo
import CryptoKit
import Darwin
import ScreenRecorderMedia
@testable import ScreenRecorderCapture

func invalid(_ message:String)->CaptureFailure {CameraMedia.invalid(message)}
func nativeTime(_ t:Tick)->CMTime {CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)}
func checkpoint(_ hash:SHA256)->String {var copy=hash;return copy.finalize().map{String(format:"%02x",$0)}.joined()}
struct RangeSpec:Decodable {let label:String;let family:String;let url:String;let start:Tick;let end:Tick;let first:Int;let last:Int;let baseline:String}
struct FixedPlan:Decodable {let cases:[RangeSpec];let goldenPath:String}
struct Golden:Decodable {struct Value:Decodable {let pictures:Int;let sha256:String};let checkpoints:[String:[Value]]}
@MainActor final class OutputBudget {var decoded=0}
struct PixelFact:Encodable {let width:Int;let height:Int;let stride:Int;let pixelFormat:UInt32;let lockStatus:Int32;let basePresent:Bool;let bytes:Data}
func capturePixel(_ image:CVPixelBuffer)->PixelFact {
    let width=CVPixelBufferGetWidth(image),height=CVPixelBufferGetHeight(image),stride=CVPixelBufferGetBytesPerRow(image),format=CVPixelBufferGetPixelFormatType(image),status=CVPixelBufferLockBaseAddress(image,.readOnly)
    defer{if status==kCVReturnSuccess{CVPixelBufferUnlockBaseAddress(image,.readOnly)}}
    let base=status==kCVReturnSuccess ? CVPixelBufferGetBaseAddress(image) : nil
    var bytes=Data()
    if let base,width==32 && height==16 && stride>=width*4 && format==kCVPixelFormatType_32BGRA {for row in 0..<height{bytes.append(Data(bytes:base.advanced(by:row*stride),count:width*4))}}
    return PixelFact(width:width,height:height,stride:stride,pixelFormat:format,lockStatus:status,basePresent:base != nil,bytes:bytes)
}
@MainActor func readRange(_ spec:RangeSpec,root:URL,evidence:ObserverEvidence,budget:OutputBudget,hash:inout SHA256) async throws -> Snapshot {
    let url=URL(fileURLWithPath:spec.url),asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true]),tracks=try await asset.loadTracks(withMediaType:.video)
    let audio=try await asset.loadTracks(withMediaType:.audio)
    try require(tracks.count==1 && audio.isEmpty,"range source tracks",["label":spec.label,"videos":String(tracks.count),"audio":String(audio.count)],evidence:evidence)
    let track=tracks[0],scale=try await track.load(.naturalTimeScale),duration=try await asset.load(.duration),segments=SourceSegment.occupied(of:try await track.load(.segments)),descriptions=try await track.load(.formatDescriptions)
    try require(scale==1_000_000 && descriptions.count==1,"range source scale/format",["label":spec.label,"scale":String(scale)],evidence:evidence)
    let range=CMTimeRange(start:nativeTime(spec.start),end:nativeTime(spec.end))
    try save(["start":spec.start,"end":spec.end,"assetDuration":Tick(duration)],root.appendingPathComponent(spec.label+"-range.json"))
    var rows=[Picture](),facts=[CursorFact](),eof=false
    let reader=try AVAssetReader(asset:asset)
    defer {
        try? save(["eof":String(eof),"status":String(reader.status.rawValue),"error":String(describing:reader.error),"outputs":String(rows.count),"totalDecodedOutputs":String(budget.decoded)],root.appendingPathComponent(spec.label+"-decoded-eof.json"))
        try? save(Snapshot(phase:spec.label,completedFragments:1,nativeScale:scale,duration:Tick(duration),readerStatus:reader.status.rawValue,containsFragments:nil,canContainFragments:nil,pictures:rows,segmentBounds:segments.map(SegmentBounds.init),cursorFacts:facts),root.appendingPathComponent(spec.label+"-partial.json"))
        reader.cancelReading()
    }
    let output=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA]);output.alwaysCopiesSampleData=false;reader.add(output);reader.timeRange=range
    let started=reader.startReading();try save(["started":String(started),"status":String(reader.status.rawValue),"error":String(describing:reader.error)],root.appendingPathComponent(spec.label+"-decoded-start.json"));try require(started,"ranged decoded reader start",["label":spec.label],evidence:evidence)
    while budget.decoded<400 {
        guard let sample=output.copyNextSampleBuffer() else{eof=true;break}
        let local=rows.count,fact=observe(sample,ordinal:local,remainingPayload:2_097_152,source:descriptions[0]);budget.decoded+=1
        try save(fact,root.appendingPathComponent(spec.label+"-decoded-buffer-\(local).json"))
        try require(sample.imageBuffer != nil,"range decoded buffer lacks image",["label":spec.label,"buffer":String(local)],evidence:evidence)
        let pixel=capturePixel(sample.imageBuffer!);try save(pixel,root.appendingPathComponent(spec.label+"-pixel-\(local).json"))
        try require(pixel.lockStatus==kCVReturnSuccess && pixel.basePresent && pixel.width==32 && pixel.height==16 && pixel.bytes.count==2048,"range visible pixel observation",["label":spec.label,"buffer":String(local),"lock":String(pixel.lockStatus),"bytes":String(pixel.bytes.count)],evidence:evidence)
        let pts=sample.presentationTimeStamp,end=assetEnd(ofSamplePresentedAt:pts,in:segments,of:track),ordinal=spec.first+local
        rows.append(Picture(ordinal:ordinal,pts:Tick(pts),digestPTS:Tick(CMTimeConvertScale(pts,timescale:scale,method:.roundHalfAwayFromZero)),width:pixel.width,height:pixel.height,end:end.map(Tick.init),bgra:pixel.bytes));facts.append(cursorFact(pts,ordinal:ordinal,segments:segments,track:track))
        try save(rows.last!,root.appendingPathComponent(spec.label+"-picture-\(local).json"))
        try frozenCameraDigest(sample,into:&hash,scale:scale)
    }
    try save(["eof":String(eof),"status":String(reader.status.rawValue),"error":String(describing:reader.error),"outputs":String(rows.count),"totalDecodedOutputs":String(budget.decoded)],root.appendingPathComponent(spec.label+"-decoded-eof.json"))
    let snapshot=Snapshot(phase:spec.label,completedFragments:1,nativeScale:scale,duration:Tick(duration),readerStatus:reader.status.rawValue,containsFragments:nil,canContainFragments:nil,pictures:rows,segmentBounds:segments.map(SegmentBounds.init),cursorFacts:facts)
    try save(snapshot,root.appendingPathComponent(spec.label+"-decoded.json"))
    try require(eof && reader.status == .completed,"ranged decoded EOF/cap",["label":spec.label,"eof":String(eof),"status":String(reader.status.rawValue),"outputs":String(rows.count)],evidence:evidence)
    return snapshot
}
@MainActor func compressedRange(_ spec:RangeSpec,root:URL,evidence:ObserverEvidence) async throws {
    let asset=AVURLAsset(url:URL(fileURLWithPath:spec.url),options:[AVURLAssetPreferPreciseDurationAndTimingKey:true]),tracks=try await asset.loadTracks(withMediaType:.video)
    try require(tracks.count==1,"compressed range tracks",["label":spec.label,"videos":String(tracks.count)],evidence:evidence)
    let descriptions=try await tracks[0].load(.formatDescriptions);try require(descriptions.count==1,"compressed range format",["label":spec.label],evidence:evidence)
    let reader=try AVAssetReader(asset:asset);var eof=false,buffers=0,media=0,payload=0
    defer{try? save(["eof":String(eof),"status":String(reader.status.rawValue),"error":String(describing:reader.error),"buffers":String(buffers),"media":String(media),"payloadBytes":String(payload)],root.appendingPathComponent(spec.label+"-compressed-eof.json"));reader.cancelReading()}
    let output=AVAssetReaderTrackOutput(track:tracks[0],outputSettings:nil);output.alwaysCopiesSampleData=false;reader.add(output);reader.timeRange=CMTimeRange(start:nativeTime(spec.start),end:nativeTime(spec.end))
    let started=reader.startReading();try save(["started":String(started),"status":String(reader.status.rawValue),"error":String(describing:reader.error)],root.appendingPathComponent(spec.label+"-compressed-start.json"));try require(started,"ranged compressed reader start",["label":spec.label],evidence:evidence)
    for ordinal in 0..<512 {
        guard let sample=output.copyNextSampleBuffer() else{eof=true;break}
        let fact=observe(sample,ordinal:ordinal,remainingPayload:2_097_152-payload,source:descriptions[0]);try save(fact,root.appendingPathComponent(spec.label+"-compressed-buffer-\(ordinal).json"));buffers+=1;media+=max(0,fact.numSamples);payload+=fact.copiedBytes
        try require(media<=400 && fact.numSamples>=0 && fact.blockCopyComplete != false && !fact.indexedOmittedForBound && !fact.rawTiming.boundedOmission && !fact.outputTiming.boundedOmission && !fact.sizes.boundedOmission,"ranged compressed observation cap",["label":spec.label,"buffers":String(buffers),"media":String(media)],evidence:evidence)
    }
    try save(["eof":String(eof),"status":String(reader.status.rawValue),"error":String(describing:reader.error),"buffers":String(buffers),"media":String(media),"payloadBytes":String(payload)],root.appendingPathComponent(spec.label+"-compressed-eof.json"))
    try require(eof && reader.status == .completed,"ranged compressed EOF/cap",["label":spec.label,"eof":String(eof),"status":String(reader.status.rawValue)],evidence:evidence)
}
@main struct RangeDigests {
    @MainActor static func main() async {
        var owner:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments,root=URL(fileURLWithPath:args[1]),plan=try JSONDecoder().decode(FixedPlan.self,from:Data(contentsOf:URL(fileURLWithPath:args[2]))),golden=try JSONDecoder().decode(Golden.self,from:Data(contentsOf:URL(fileURLWithPath:plan.goldenPath)))
            let admitted=try OwnedEvidenceDestination(root:root);owner=admitted;let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence")),budget=OutputBudget()
            var rawHash=SHA256(),canonicalHash=SHA256(),rawRows=[Picture](),canonicalRows=[Picture]()
            for spec in plan.cases {
                let snapshot:Snapshot
                if spec.family=="raw" {snapshot=try await readRange(spec,root:root,evidence:evidence,budget:budget,hash:&rawHash);rawRows+=snapshot.pictures}
                else {snapshot=try await readRange(spec,root:root,evidence:evidence,budget:budget,hash:&canonicalHash);canonicalRows+=snapshot.pictures}
                let actualHash=checkpoint(spec.family=="raw" ? rawHash : canonicalHash),expectedHash=golden.checkpoints[spec.family]!.first{$0.pictures==spec.last}!.sha256
                try save(["actual":actualHash,"expected":expectedHash,"rangePictures":String(snapshot.pictures.count),"cumulativePictures":String(spec.family=="raw" ? rawRows.count : canonicalRows.count)],root.appendingPathComponent(spec.label+"-digest.json"))
                // Compressed boundary facts remain observations, never a forwarding/filtering rule.
                try await compressedRange(spec,root:root,evidence:evidence)
                let baseline=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:URL(fileURLWithPath:spec.baseline)))
                try compare(Array(baseline.pictures[spec.first..<spec.last]),snapshot,evidence:evidence)
                try require(snapshot.pictures.count==spec.last-spec.first && actualHash==expectedHash,"exact ranged membership/digest checkpoint",["label":spec.label,"count":String(snapshot.pictures.count),"actualHash":actualHash,"expectedHash":expectedHash],evidence:evidence)
                if spec.last==197 {
                    let all=spec.family=="raw" ? rawRows : canonicalRows
                    try save(all,root.appendingPathComponent(spec.family+"-concatenated-pictures.json"));try save(baseline.pictures,root.appendingPathComponent(spec.family+"-expected-pictures.json"))
                    try require(all==baseline.pictures && (snapshot.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}) == (baseline.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}),"complete series tuples/native support",["family":spec.family,"pictures":String(all.count)],evidence:evidence)
                }
            }
            try save(["status":"pass","scope":"Two independent continuing exact CameraMedia digest projections over six retained-file ranges; no live/backlog/recovery/transfer adoption","decodedOutputs":String(budget.decoded),"rawFinal":checkpoint(rawHash),"canonicalFinal":checkpoint(canonicalHash)],root.appendingPathComponent("verdict.json"))
        } catch {if let owner{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
    }
}
