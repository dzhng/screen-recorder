@preconcurrency import AVFoundation
import CoreVideo
import CryptoKit
@testable import ScreenRecorderCapture

func frozenCameraDigest(_ sample: CMSampleBuffer, into hash: inout SHA256, scale: Int32) throws {
        guard let pixel = sample.imageBuffer else { throw invalid("Camera picture has no decoded pixels.") }
        CVPixelBufferLockBaseAddress(pixel, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixel, .readOnly) }
        for number in [CMTimeConvertScale(sample.presentationTimeStamp, timescale: scale, method: .roundHalfAwayFromZero).value,
            Int64(CVPixelBufferGetWidth(pixel)), Int64(CVPixelBufferGetHeight(pixel))] {
            var little = number.littleEndian
            withUnsafeBytes(of: &little) { hash.update(bufferPointer: $0) }
        }
        let base = CVPixelBufferGetBaseAddress(pixel)!
        let visibleRowBytes = CVPixelBufferGetWidth(pixel) * 4
        let stride = CVPixelBufferGetBytesPerRow(pixel)
        let height = CVPixelBufferGetHeight(pixel)
        // Padding is not picture data; tightly packed rows can share one hash update.
        if stride == visibleRowBytes {
            hash.update(bufferPointer: UnsafeRawBufferPointer(start: base, count: visibleRowBytes * height))
        } else {
            for row in 0..<height {
                hash.update(bufferPointer: UnsafeRawBufferPointer(start: base.advanced(by: row * stride), count: visibleRowBytes))
            }
        }
    }
