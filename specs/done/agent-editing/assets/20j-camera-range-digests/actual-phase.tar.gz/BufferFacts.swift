@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import CoreVideo
import Darwin

struct TimingFact: Encodable {
    let duration: Tick; let pts: Tick; let dts: Tick
    init(_ t: CMSampleTimingInfo) { duration=Tick(t.duration); pts=Tick(t.presentationTimeStamp); dts=Tick(t.decodeTimeStamp) }
}
struct TypedFact: Encodable {
    let present: Bool; let value: FormatValue?; let error: String?; let unsupportedType: String?; let unsupportedDescription: String?
    init(_ raw: Any?) {
        present=raw != nil
        guard let raw else { value=nil;error=nil;unsupportedType=nil;unsupportedDescription=nil;return }
        do { value=try FormatValue(raw);error=nil;unsupportedType=nil;unsupportedDescription=nil }
        catch { value=nil;self.error=String(describing:error);unsupportedType=String(describing:type(of:raw));unsupportedDescription=String(describing:raw) }
    }
}
struct TimingArrayFact: Encodable { let queryStatus: Int32; let entriesNeeded: Int; let readStatus: Int32?; let entriesReturned: Int?; let values: [TimingFact]?; let boundedOmission: Bool }
struct SizeArrayFact: Encodable { let queryStatus: Int32; let entriesNeeded: Int; let readStatus: Int32?; let entriesReturned: Int?; let values: [Int]?; let boundedOmission: Bool }
struct IndexedFact: Encodable { let sampleIndex: Int; let timingStatus: Int32; let timing: TimingFact?; let sizeBytes: Int }
struct BufferFormat: Encodable { let mediaType: UInt32; let subtype: UInt32; let sourceEqual: Bool; let dimensions: [Int]?; let extensions: TypedFact }
struct BufferFact: Encodable {
    let bufferOrdinal: Int; let numSamples: Int; let valid: Bool; let dataReady: Bool
    let blockPresent: Bool; let blockBytes: Int?; let copiedBytes: Int; let copyStatus: Int32?; let payload: Data?; let blockCopyComplete: Bool?
    let imagePresent: Bool; let formatPresent: Bool; let format: BufferFormat?
    let clocks: [String:Tick]; let rawTiming: TimingArrayFact; let outputTiming: TimingArrayFact; let sizes: SizeArrayFact; let indexed: [IndexedFact]; let indexedOmittedForBound: Bool
    let bufferShouldPropagate: TypedFact; let bufferShouldNotPropagate: TypedFact; let sampleAttachmentsCreateFalse: TypedFact
}
struct NativeRows: Decodable { struct Row: Decodable { let ordinal: Int; let cursor: CursorFact }; let rows: [Row] }
struct Correspondence: Encodable { let bufferOrdinal: Int; let sampleIndex: Int; let returnedMediaSamplePosition: Int; let nativeDecodePosition: Int?; let nativePresentationOrdinal: Int?; let fieldsDiffering: [String] }

func timingArray(_ sample: CMSampleBuffer, output: Bool) -> TimingArrayFact {
    var needed=0
    let q=output ? CMSampleBufferGetOutputSampleTimingInfoArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed) : CMSampleBufferGetSampleTimingInfoArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed)
    guard needed>0 && needed<=400 else {return TimingArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:nil,entriesReturned:nil,values:nil,boundedOmission:needed>400)}
    var array=[CMSampleTimingInfo](repeating:CMSampleTimingInfo(),count:needed),returned=needed
    let status=output ? CMSampleBufferGetOutputSampleTimingInfoArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned) : CMSampleBufferGetSampleTimingInfoArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned)
    return TimingArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:status,entriesReturned:returned,values:status==noErr ? array.prefix(min(max(0,returned),array.count)).map(TimingFact.init) : nil,boundedOmission:returned>array.count)
}
func sizeArray(_ sample: CMSampleBuffer) -> SizeArrayFact {
    var needed=0;let q=CMSampleBufferGetSampleSizeArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed)
    guard needed>0 && needed<=400 else {return SizeArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:nil,entriesReturned:nil,values:nil,boundedOmission:needed>400)}
    var array=[Int](repeating:0,count:needed),returned=needed
    let status=CMSampleBufferGetSampleSizeArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned)
    return SizeArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:status,entriesReturned:returned,values:status==noErr ? Array(array.prefix(min(max(0,returned),array.count))) : nil,boundedOmission:returned>array.count)
}
func format(_ description: CMFormatDescription, source: CMFormatDescription) -> BufferFormat {
    let type=CMFormatDescriptionGetMediaType(description),subtype=CMFormatDescriptionGetMediaSubType(description)
    let dimensions=type==kCMMediaType_Video ? CMVideoFormatDescriptionGetDimensions(description) : nil
    return BufferFormat(mediaType:type,subtype:subtype,sourceEqual:CMFormatDescriptionEqual(description,otherFormatDescription:source),dimensions:dimensions.map{[Int($0.width),Int($0.height)]},extensions:TypedFact(CMFormatDescriptionGetExtensions(description).map{$0 as NSDictionary}))
}
func observe(_ sample: CMSampleBuffer, ordinal: Int, remainingPayload: Int, source: CMFormatDescription) -> BufferFact {
    let n=CMSampleBufferGetNumSamples(sample),block=CMSampleBufferGetDataBuffer(sample),image=CMSampleBufferGetImageBuffer(sample),description=CMSampleBufferGetFormatDescription(sample)
    var data:Data?,status:Int32?,length:Int?,copied=0
    if let block {
        let count=CMBlockBufferGetDataLength(block);length=count;let wanted=min(count,max(0,remainingPayload));var bytes=Data(count:wanted)
        let result=wanted==0 ? noErr : bytes.withUnsafeMutableBytes{CMBlockBufferCopyDataBytes(block,atOffset:0,dataLength:wanted,destination:$0.baseAddress!)}
        status=result;if result==noErr{data=bytes;copied=wanted}
    }
    var indexed=[IndexedFact]()
    if n>=0 && n<=400 {
        for index in 0..<n {
            var t=CMSampleTimingInfo();let result=CMSampleBufferGetSampleTimingInfo(sample,at:index,timingInfoOut:&t)
            indexed.append(IndexedFact(sampleIndex:index,timingStatus:result,timing:result==noErr ? TimingFact(t) : nil,sizeBytes:CMSampleBufferGetSampleSize(sample,at:index)))
        }
    }
    return BufferFact(bufferOrdinal:ordinal,numSamples:n,valid:CMSampleBufferIsValid(sample),dataReady:CMSampleBufferDataIsReady(sample),blockPresent:block != nil,blockBytes:length,copiedBytes:copied,copyStatus:status,payload:data,blockCopyComplete:block == nil ? nil : (status==noErr && copied==length),imagePresent:image != nil,formatPresent:description != nil,format:description.map{format($0,source:source)},clocks:["rawPTS":Tick(CMSampleBufferGetPresentationTimeStamp(sample)),"rawDTS":Tick(CMSampleBufferGetDecodeTimeStamp(sample)),"rawDuration":Tick(CMSampleBufferGetDuration(sample)),"outputPTS":Tick(CMSampleBufferGetOutputPresentationTimeStamp(sample)),"outputDTS":Tick(CMSampleBufferGetOutputDecodeTimeStamp(sample)),"outputDuration":Tick(CMSampleBufferGetOutputDuration(sample))],rawTiming:timingArray(sample,output:false),outputTiming:timingArray(sample,output:true),sizes:sizeArray(sample),indexed:indexed,indexedOmittedForBound:n<0 || n>400,bufferShouldPropagate:TypedFact(CMCopyDictionaryOfAttachments(allocator:nil,target:sample,attachmentMode:kCMAttachmentMode_ShouldPropagate).map{$0 as NSDictionary}),bufferShouldNotPropagate:TypedFact(CMCopyDictionaryOfAttachments(allocator:nil,target:sample,attachmentMode:kCMAttachmentMode_ShouldNotPropagate).map{$0 as NSDictionary}),sampleAttachmentsCreateFalse:TypedFact(CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false).map{$0 as NSArray}))
}

