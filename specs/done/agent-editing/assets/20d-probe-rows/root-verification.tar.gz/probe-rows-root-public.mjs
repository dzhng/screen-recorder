import assert from 'node:assert/strict';
import {mkdir,cp,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,root} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/probe-rows-root-public'; await mkdir(out);
await cp('/tmp/probe-consumer-red/source',out+'/source',{recursive:true});
const report={trace:[],passed:false};
const service=new JourneyService(out+'/home',report,out+'/reads.jsonl',new URL(`file://${root}/packages/test-harness/editing/capture-evidence-service.mjs`));
const request={requestId:'root-bulk-admission',path:out+'/source'};
try {
 await service.start(); report.submitted=await service.call('acquisition.import',request);
 const started=performance.now();
 while(performance.now()-started<180000){
  const job=await service.call('job.get',{jobId:report.submitted.jobId},{transport:'mcp'});
  if(['ready','failed','canceled'].includes(job.state)){report.terminal=job;break;}
  await delay(500);
 }
 report.seconds=(performance.now()-started)/1000;
 assert.equal(report.terminal.state,'ready');
 report.replay=await service.call('acquisition.import',request);
 assert.equal(report.replay.jobId,report.submitted.jobId);
 report.passed=true;
} finally {await service.stop(); await writeFile(out+'/report.json',JSON.stringify(report,null,2));}
