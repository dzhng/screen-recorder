import {mediaWorker} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/apps/service/dist/worker.js';
import {writeFile} from 'node:fs/promises';
const budget=Number(process.argv[2]);
const request={directory:'/tmp/source-admission-scale/source',output:`/tmp/source-admission-scale/evidence-${budget}.jsonl`};
const start=performance.now();
const result=await mediaWorker({SCREENREC_NATIVE:'/tmp/screenrec-canonical-admission-native'})('media.sourceEvidence',request,{timeoutMs:budget});
await writeFile(`/tmp/source-admission-scale/result-${budget}.json`,JSON.stringify({request,budget,seconds:(performance.now()-start)/1000,result},null,2));
console.log(JSON.stringify({budget,seconds:(performance.now()-start)/1000,result}));
