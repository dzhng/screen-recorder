from caller import *
import hashlib,struct,math
waitmedia('audio.get',{**inputs['workbenchNarration']['selected'],'range':facts['bindings']['markedSpeech']['contextAssetRange']},'marked-original-context','wav')
def wav(p):
 b=pathlib.Path(p).read_bytes();i=12;fmt=None;pcm=None
 while i+8<=len(b):
  kind=b[i:i+4];n=struct.unpack_from('<I',b,i+4)[0];chunk=b[i+8:i+8+n]
  if kind==b'fmt ':fmt=struct.unpack_from('<HHIIHH',chunk)
  if kind==b'data':pcm=chunk
  i+=8+n+(n%2)
 return {'channels':fmt[1],'sampleRate':fmt[2],'frames':len(pcm)//(fmt[1]*fmt[5]//8),'bits':fmt[5],'format':fmt[0]},pcm
def floats(p):m,b=wav(p);return m,struct.unpack('<'+'f'*(len(b)//4),b)
def comparison(a,b):
 ma,xa=floats(a);mb,xb=floats(b);channels=ma['channels'];aa=xa[::channels];bb=xb[::mb['channels']];n=min(len(aa),len(bb));diff=[a-b for a,b in zip(aa,bb)];return {'a':str(a),'b':str(b),'metadataA':ma,'metadataB':mb,'sameFirstChannel':aa==bb,'maxAbsoluteError':max(map(abs,diff),default=0),'rmsError':math.sqrt(sum(x*x for x in diff)/max(n,1))}
report={}
report['rawGenerationHash']=hashlib.sha256((HOME/'fresh-paid-raw.wav').read_bytes()).hexdigest();report['rawGenerationExpected']=facts['references'][1]['sha256'];report['retimeComparison']=comparison(HOME/'retimed-delivered.wav',facts['references'][0]['path'])
for key in ['marked-a','narration','audio-nested','audio-root','output']:report[key+'Order']=comparison(HOME/(key+'-ordered-audio.wav'),HOME/(key+'-reversed-audio.wav'))
# Music changes must leave outside the declared interlude identical on the full sample clock.
mb,xb=floats(HOME/'music-base-full.wav');mm,xm=floats(HOME/'music-muted-full.wav');ml,xl=floats(HOME/'music-level-half-full.wav');t=json.load(open(HOME/'timeline.json'));from fractions import Fraction
T=lambda x:Fraction(x['numerator'],x['denominator']) if isinstance(x,dict) else Fraction(x)
lo=math.floor(T(t['interludeStart'])*48000/1000000)*2;hi=math.ceil(T(t['interludeEnd'])*48000/1000000)*2;report['musicProtectedOutside']={'muted':xb[:lo]==xm[:lo] and xb[hi:]==xm[hi:],'halfLevel':xb[:lo]==xl[:lo] and xb[hi:]==xl[hi:],'mutedChangesInside':xb[lo:hi]!=xm[lo:hi],'halfChangesInside':xb[lo:hi]!=xl[lo:hi]}
# Exact source marks and supplied sample-stepped gain recipe.
m,x=floats(HOME/'marked-original-context.wav');ref=list(x[15024:172560])+list(x[191520:342720]);join=157536
for i in range(240):ref[join-240+i]=struct.unpack('<f',struct.pack('<f',ref[join-240+i]*((239-i)/240)))[0];ref[join+i]=struct.unpack('<f',struct.pack('<f',ref[join+i]*(i/240)))[0]
m,y=floats(HOME/'marked-exact.wav');actual=y[::2];diff=[a-b for a,b in zip(ref,actual)];report['markedSampleRecipe']={'expectedFrames':len(ref),'actualFrames':len(actual),'equal':ref==list(actual),'differentSamples':sum(a!=b for a,b in zip(ref,actual)),'maxAbsoluteError':max(map(abs,diff)),'protectedBeforeJoin':ref[:join-240]==list(actual[:join-240]),'protectedAfterJoin':ref[join+240:]==list(actual[join+240:])}
(HOME/'numeric-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
