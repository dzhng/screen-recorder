import json,subprocess,pathlib,time,uuid
HOME=pathlib.Path('/tmp/screenrec-25-fresh-caller');CLI='/Users/david/dev/screen-recorder/apps/cli/dist/main.js';SOCKET='/tmp/screenrec-25-preparation-current/library-ACs9sl/run/service.sock'
facts=json.load(open('/tmp/screenrec-25a-voice-ready-reuse/caller-ready-inputs.json'));project=facts['projectId'];inputs={x['key']:x for x in facts['inputs']}
def call(op,p,name=None,out=None):
 name=name or op+'-'+str(uuid.uuid4());file=HOME/(name+'.request.json');file.write_text(json.dumps(p,indent=2));argv=['node',CLI,op,'--socket',SOCKET,'--params','-'];argv+=['--output',str(out)] if out else []
 r=subprocess.run(argv,input=json.dumps(p),text=True,capture_output=True);(HOME/(name+'.reply.json')).write_text(r.stdout);(HOME/(name+'.stderr')).write_text(r.stderr)
 try: j=json.loads(r.stdout)
 except: raise RuntimeError(r.stdout+r.stderr)
 print(name, j.get('ok'),json.dumps(j.get('error',{}))[:700],flush=True);return j

def data(j):
 if not j.get('ok'):raise RuntimeError(j)
 return j.get('result',j.get('data'))
def edit(ops,name,rev=None):
 rev=rev or data(call('project.get',{'projectId':project},name+'-before'))['currentRevisionId'];return data(call('edit.apply',{'projectId':project,'expectedRevisionId':rev,'requestId':name,'operations':ops},name))
def checkpoint(name,r):
 p=HOME/'checkpoints.json';x=json.load(open(p)) if p.exists() else {};x[name]=r;p.write_text(json.dumps(x,indent=2))
def place(key,track,start,end,ss,se,label,pitch=None):
 op={'operation':'place','label':label,'clip':{'trackId':track,'placement':{'kind':'project','range':{'startUs':start,'endUs':end}},**inputs[key]['selected'],'source':{'kind':'range','range':{'startUs':ss,'endUs':se}}}};
 if pitch:op['clip']['pitch']=pitch
 return op
if __name__=='__main__':
 for op,p in [('project.get',{'projectId':project}),('revision.get',{'projectId':project}),('processing.capabilities',{}),('output.capabilities',{}),('model.list',{})]:print(json.dumps(call(op,p,op+'-initial'))[:15000])
def current(name='current'):return data(call('revision.get',{'projectId':project},name))['revision']
def remember(name,r):
 checkpoint(name,r)
 p=HOME/'ids.json';x=json.load(open(p));x.update(r.get('edit',{}).get('labels',{}));p.write_text(json.dumps(x,indent=2));return r

def waitmedia(op,p,name,ext):
 for n in range(120):
  j=call(op,p,name+'-poll-'+str(n));d=data(j)
  if d.get('state') in ['failed','canceled'] or d.get('reason') and d.get('state') not in ['processing','not_ready']:print(json.dumps(d));return d
  if d.get('state')=='ready':
   return data(call(op,p,name+'-deliver',HOME/(name+'.'+ext)))
  time.sleep(1)
 raise RuntimeError('poll limit '+name)
def undo(name):
 rev=current(name+'-before')['id'];r=data(call('edit.undo',{'projectId':project,'requestId':name,'expectedRevisionId':rev},name));return remember(name,{'revision':r} if 'document' in r else r)
def restore(name,target):
 rev=current(name+'-before')['id'];r=data(call('edit.restore',{'projectId':project,'requestId':name,'expectedRevisionId':rev,'targetRevisionId':target},name));return remember(name,{'revision':r} if 'document' in r else r)
def stack(target,steps):return {'operation':'processing.set','target':target,'steps':steps}
def audio(rev,name,rg=None,tap=None):
 p={'projectId':project,'revisionId':rev}
 if rg:p['range']=rg
 if tap:p['tap']=tap
 return waitmedia('audio.get',p,name,'wav')
