from caller import *
ids=json.load(open(HOME/'ids.json'));r=current('cuts-inspected');a=[c for c in r['document']['clips'] if c['trackId']==ids['narration']];ops=[]
for c in a:
 rg=c['placement']['range'];start,end=rg['startUs'],rg['endUs'];keys=[]
 if start==0:keys=[{'at':{'numerator':0,'denominator':1},'value':1,'interpolation':'linear'},{'at':{'numerator':end-5000,'denominator':end},'value':1,'interpolation':'linear'},{'at':{'numerator':1,'denominator':1},'value':0,'interpolation':'linear'}]
 else:keys=[{'at':{'numerator':0,'denominator':1},'value':0,'interpolation':'linear'},{'at':{'numerator':5000,'denominator':end-start},'value':1,'interpolation':'linear'},{'at':{'numerator':1,'denominator':1},'value':1,'interpolation':'linear'}]
 ops.append(stack({'kind':'clip','id':c['id']},[{'processor':{'type':'gain','gain':{'keys':keys}}}]))
from fractions import Fraction
for op in ops:
 for k in op['steps'][0]['processor']['gain']['keys']:
  f=Fraction(k['at']['numerator'],k['at']['denominator']);k['at']={'numerator':f.numerator,'denominator':f.denominator}
r=remember('marked-speech',edit(ops,'03b-marked-join'));audio(r['revision']['id'],'marked-delivered');
end=6432000;r=remember('retime-original',edit([place('retimeOriginal',ids['narration'],end,end+4820000,0,4820000,'retime-a'),{'operation':'place','label':'retime-picture','clip':{'trackId':ids['picture'],'placement':{'kind':'project','range':{'startUs':end,'endUs':end+4820000}},**inputs['still']['selected'],'source':{'kind':'hold','atUs':0}}}],'04-retime-original'));ids=json.load(open(HOME/'ids.json'))
r=remember('retime-split',edit([{'operation':'split','clipIds':[ids['retime-a']],'atUs':end+650125,'rightLabels':[{'clipId':ids['retime-a'],'label':'retime-mid'}]},{'operation':'split','clipIds':[{'label':'retime-mid'}],'atUs':end+1910000,'rightLabels':[{'clipId':{'label':'retime-mid'},'label':'retime-tail'}]}],'05-retime-partition'));ids=json.load(open(HOME/'ids.json'))
r=remember('retimed-block',edit([{'operation':'retime','clipIds':[ids['retime-mid']],'durationUs':1574844,'pitch':'preserve','ripple':{'trackIds':[ids['narration'],ids['picture']]},'scope':'selected'}],'06-retime-middle'));print(json.dumps(r['revision']['document']['clips'][-4:]));audio(r['revision']['id'],'retimed-delivered',{'startUs':end,'endUs':11566969})
print(json.dumps(call('voice.generate',facts['bindings']['voice']['request'],'fresh-paid-completion'))[:5000])
