from caller import *
from fractions import Fraction
T=lambda x:Fraction(x['numerator'],x['denominator']) if isinstance(x,dict) else Fraction(x)
ids=json.load(open(HOME/'ids.json'));r=current('caption-contrast-before');clips={x['id']:x for x in r['document']['clips']};ops=[]
for k in ['fixture-caption','paid-caption']:
 src=dict(clips[ids[k]]['source']);src['color']='#d92d43ff';ops.append({'operation':'text.set','clipId':ids[k],'source':src})
r=remember('final-contrast',edit(ops,'32-caption-contrast'));rev=r['revision'];(HOME/'final-revision.json').write_text(json.dumps(rev,indent=2));t=json.load(open(HOME/'timeline.json'));is_=T(t['interludeStart']);ie=T(t['interludeEnd']);gs=T(t['generatedStart']);ge=T(t['generatedEnd'])
for name,at in [('interlude-start',is_+34000),('interlude-middle',is_+1000000),('interlude-end',ie-34000),('paid-start',gs+34000),('paid-middle',(gs+ge)/2),('paid-end',ge-34000)]:waitmedia('frame.get',{'projectId':project,'revisionId':rev['id'],'atUs':int(at)},'final-contrast-'+name,'png')
settings={'preset':'balanced','video':{'rateControl':{'mode':'average','bitrate':3000000}}}
waitmedia('preview.get',{'projectId':project,'revisionId':rev['id'],'settings':settings},'primitive-fixture-preview','mp4')
for kind,leaf in [('video','primitive-fixture.mp4'),('processed-package','primitive-fixture.zip')]:
 exportid=str(uuid.uuid4());p={'projectId':project,'revisionId':rev['id'],'kind':kind,'exportId':exportid,'directory':str(HOME),'leaf':leaf}
 if kind=='video':p['settings']=settings
 j=data(call('export.create',p,'final-export-'+kind));print(json.dumps(j)[:2000])
 for n in range(300):
  d=data(call('export.status',{'exportId':exportid},'final-export-'+kind+'-status-'+str(n)))
  if d.get('output') or d.get('job',{}).get('state') in ['failed','canceled'] or d.get('state') in ['failed','committed','ready']:print(json.dumps(d)[:6000]);(HOME/('final-export-'+kind+'-terminal.json')).write_text(json.dumps(d,indent=2));break
  time.sleep(1)
