import caller
from caller import *
caller.SOCKET='/tmp/screenrec-25-relocation-recipient/run/service.sock'
r=data(call('asset.import',{'requestId':'recipient-inspect-delivered-movie','path':str((HOME/'primitive-fixture.mp4').resolve())},'delivered-movie-import'));job=r['jobId']
for n in range(120):
 r=data(call('job.get',{'jobId':job},'delivered-movie-job-'+str(n)))
 if r['state']=='ready':break
 if r['state'] in ['failed','canceled']:raise RuntimeError(r)
 time.sleep(1)
a=data(call('asset.get',{'assetId':r['result']['assetId']},'delivered-movie-asset'));print(json.dumps(a,indent=2))
for stream in a['streams']:call('asset.segments',{'assetId':a['id'],'streamId':stream['id']},'delivered-movie-segments-'+stream['id'].replace(':','-'))
