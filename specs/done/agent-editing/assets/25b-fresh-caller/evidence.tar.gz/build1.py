from caller import *
L=lambda s:{'label':s}
ops=[{'operation':'group.add','group':{'kind':'audio','order':0},'label':'audio-root'},{'operation':'group.add','group':{'kind':'audio','order':0,'parentId':L('audio-root')},'label':'audio-nested'}]
for i,(name,kind) in enumerate([('narration','audio'),('music','audio'),('ambience','audio'),('picture','video'),('camera','video'),('still','video'),('captions','video')]):
 t={'kind':kind,'order':i}
 if kind=='audio':t['parentId']=L('audio-nested')
 ops.append({'operation':'track.add','track':t,'label':name})
ops += [place('workbenchNarration',L('narration'),0,7140000,50470000,57610000,'marked-a'),place('workbenchScreen',L('picture'),0,7140000,50518675,57658675,'marked-v')]
r=json.load(open(HOME/'01-marked-original.reply.json'))['data'];checkpoint('marked-original',r);print(json.dumps(r)[:2000])
ids={k:v for k,v in r['edit']['labels'].items()};print(ids);(HOME/'ids.json').write_text(json.dumps(ids,indent=2))
ops=[{'operation':'remove','clipIds':[ids['marked-a'],ids['marked-v']],'ranges':[{'startUs':0,'endUs':313000},{'startUs':3595000,'endUs':3990000}],'scope':'selected','ripple':{'trackIds':[ids['narration'],ids['picture']]}}]
r=edit(ops,'02-marked-cuts');checkpoint('marked-cuts',r);print(json.dumps(r)[:6000])
