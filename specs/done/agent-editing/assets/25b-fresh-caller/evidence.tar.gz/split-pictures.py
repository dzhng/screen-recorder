import caller
from caller import *
caller.SOCKET='/tmp/screenrec-25-relocation-recipient/run/service.sock';st=json.load(open(HOME/'recipient-adoption.json'));caller.project=st['result']['projectId'];project=caller.project;hist=json.load(open(HOME/'recipient-history-all.json'));old=json.load(open(HOME/'checkpoints.json'))
for suffix,ordinal in [('pre-split',old['pre-pure-split']['revision']['ordinal']),('post-split',old['pure-split']['revision']['ordinal'])]:
 hr=next(x for x in hist['revisions'] if x['ordinal']==ordinal)
 for name,at in [('left-piece',1000000),('split-neighbor',2034000),('right-piece',2500000),('right-tail',3200000)]:waitmedia('frame.get',{'projectId':project,'revisionId':hr['id'],'atUs':at},'recipient-'+suffix+'-'+name,'png')
