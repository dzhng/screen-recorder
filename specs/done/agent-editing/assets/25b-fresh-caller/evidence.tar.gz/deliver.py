from caller import *
ids=json.load(open(HOME/'ids.json'));before=current('lost-before');p={'projectId':project,'requestId':'28-lost-response','expectedRevisionId':before['id'],'operations':[stack({'kind':'track','id':ids['music']},[{'processor':{'type':'gain','gain':0.25}}])]};(HOME/'28-lost-response.request.json').write_text(json.dumps(p,indent=2))
# Intentional receiving-side loss: public CLI completes, consumer discards reply. Identical request replays saved mutation.
r=subprocess.run(['node',CLI,'edit.apply','--socket',SOCKET,'--params','-'],input=json.dumps(p),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True);(HOME/'28-lost-response.transport.json').write_text(json.dumps({'exitCode':r.returncode,'stdout':'intentionally discarded; receipt not observed','stderr':r.stderr}));r=data(call('edit.apply',p,'29-recover-identical-lost-response'));remember('lost-response-recovered',r);head=current('lost-recovered-head');second=data(call('edit.apply',p,'30-identical-replay-again'));(HOME/'lost-response-proof.json').write_text(json.dumps({'headId':head['id'],'replayedId':second['revision']['id'],'same':head['id']==second['revision']['id']},indent=2));r=undo('31-undo-lost-response');rev=r['revision'];(HOME/'final-revision.json').write_text(json.dumps(rev,indent=2));audio(rev['id'],'final-recovery-audio')
# History discovery and complete bounded traversal.
subprocess.run(['node',CLI,'revision.history','--help'],stdout=open(HOME/'revision.history-help.json','w'))
p={'projectId':project};page=0
while True:
 j=data(call('revision.history',p,'history-page-'+str(page)));print(json.dumps(j)[:800]);cursor=j.get('nextCursor')
 if not cursor:break
 p={'projectId':project,'cursor':cursor};page+=1
settings={'preset':'balanced','video':{'rateControl':{'mode':'average','bitrate':3000000}}}
waitmedia('preview.get',{'projectId':project,'revisionId':rev['id'],'settings':settings},'fixture-preview','mp4')
for kind,leaf,exportid in [('video','primitive-fixture.mp4','fresh-fixture-video'),('processed-package','primitive-fixture.zip','fresh-fixture-package')]:
 p={'projectId':project,'revisionId':rev['id'],'kind':kind,'exportId':exportid,'directory':str(HOME),'leaf':leaf}
 if kind=='video':p['settings']=settings
 j=data(call('export.create',p,'export-'+kind));print(json.dumps(j)[:2000])
 for n in range(300):
  d=data(call('export.status',{'exportId':exportid},'export-'+kind+'-status-'+str(n)))
  if d.get('output') or d.get('job',{}).get('state') in ['failed','canceled'] or d.get('state') in ['failed','committed','ready']:print(json.dumps(d)[:6000]);break
  time.sleep(1)
