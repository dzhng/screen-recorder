from caller import *
import struct,hashlib,math
for k in ['voiceContext','voiceReference']:waitmedia('audio.get',inputs[k]['selected'],'source-'+k,'wav')
bg=json.load(open('/tmp/screenrec-25-frozen-recipe-facts.json'))['voice']['background'];sel={'assetId':bg['sha256'],'streamId':'track:1'};call('asset.get',{'assetId':bg['sha256']},'word-background-asset');call('asset.segments',sel,'word-background-segments');waitmedia('audio.get',sel,'source-wordBackground','wav')
def pcm(p):
 b=pathlib.Path(p).read_bytes();i=12
 while i+8<=len(b):
  kind=b[i:i+4];n=struct.unpack_from('<I',b,i+4)[0]
  if kind==b'data':return struct.unpack('<'+'f'*(n//4),b[i+8:i+8+n])
  i+=8+n+(n%2)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
ctx=pcm(HOME/'source-voiceContext.wav');word=pcm(HOME/'fresh-paid-raw.wav');background=pcm(HOME/'source-wordBackground.wav');expected=pcm(facts['references'][2]['path']);historical=pcm(facts['references'][1]['path']);crop=word[5760:20160];gain=10**(-4.519810154304541/20);new=[f32(v*gain+b*bg['linearGain']) for v,b in zip(crop,background)];result=list(ctx[:63928]);
for i in range(120):result.append(f32(ctx[63928+i]*(1-i/119)+new[i]*(i/119)))
result.extend(new[120:14280]);
for i in range(120):result.append(f32(new[14280+i]*(1-i/119)+ctx[76528+i]*(i/119)))
result.extend(ctx[76648:]);diff=[a-b for a,b in zip(result,expected)]
report={'rawPCMEqual':word==historical,'rawContainerHeadersMayDiffer':True,'rawFrames':len(word),'contextRecipeFrames':len(result),'expectedContextFrames':len(expected),'contextRecipeComparedToAccepted24k':{'differentSamples':sum(a!=b for a,b in zip(result,expected)),'maxAbsoluteError':max(map(abs,diff)),'rmsError':math.sqrt(sum(x*x for x in diff)/len(diff))},'integrated48kOutput':'Native project mixer runs 48k stereo; contextual 24k recipe comparison is distinct from rendered integrated quality acceptance.'};(HOME/'context-comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
