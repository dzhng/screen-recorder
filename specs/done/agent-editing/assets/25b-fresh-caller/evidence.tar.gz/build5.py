from caller import *
from fractions import Fraction
F=lambda n,d=1:{'numerator':Fraction(n,d).numerator,'denominator':Fraction(n,d).denominator}
T=lambda x:Fraction(x['numerator'],x['denominator']) if isinstance(x,dict) else Fraction(x)
L=lambda x:{'label':x}
ids=json.load(open(HOME/'ids.json'));t=json.load(open(HOME/'timeline.json'));is_=T(t['interludeStart']);ie=T(t['interludeEnd']);vs=ie;ve=vs+5070000
recipe=json.load(open('/tmp/screenrec-25-frozen-recipe-facts.json'));j=data(call('job.get',{'jobId':data(json.load(open(HOME/'word-background-import.reply.json')))['jobId']},'word-background-ready'));print(json.dumps(j)[:1200]);bg=recipe['voice']['background'];inputs['wordBackground']={'selected':{'assetId':bg['sha256'],'streamId':'track:1'}}
raw=data(json.load(open(HOME/'fresh-paid-completion.reply.json')))['published']['audio'];inputs['generatedPaid']={'selected':{'assetId':raw['assetId'],'streamId':raw['streamId']}}
# Existing word context appends to a gain-1 processed track, with empty own stack.
r=remember('voice-original-context',edit([place('voiceContext',ids['narration'],F(vs),F(vs+5000000),0,5000000,'voice-original')],'19-voice-original-context'));audio(r['revision']['id'],'voice-before',{'startUs':int(vs)+1,'endUs':int(vs+5000000)})
ids=json.load(open(HOME/'ids.json'))
ops=[{'operation':'remove','clipIds':[ids['voice-original']],'scope':'selected','ripple':'none'},{'operation':'track.add','label':'voice-new-track','track':{'kind':'audio','order':3,'parentId':ids['audio-nested']}}]
# Context left, generated overlay, context right use separate tracks for explicit 120-sample overlaps.
leftEnd=vs+Fraction(64048*1000000,24000);gs=vs+Fraction(63928*1000000,24000);ge=gs+600000;rs=ge-5000
ops += [place('voiceContext',ids['narration'],F(vs),F(leftEnd),0,F(Fraction(64048*1000000,24000)),'voice-left'),place('generatedPaid',L('voice-new-track'),F(gs),F(ge),240000,840000,'paid-generated'),place('voiceContext',ids['narration'],F(rs),F(ve),F(Fraction(76528*1000000,24000)),5000000,'voice-right'),place('wordBackground',ids['ambience'],F(gs),F(ge),0,600000,'word-background')]
def gainkeys(n,points,mult=1):return [{'at':F(at,n),'value':value*mult,'interpolation':'linear'} for at,value in points]
for label,n,points,mult in [('voice-left',64048,[(0,1),(63928,1),(64047,0),(64048,0)],1),('voice-right',43472,[(0,0),(119,1),(43472,1)],1),('paid-generated',14400,[(0,0),(119,1),(14280,1),(14399,0),(14400,0)],10**(-4.519810154304541/20)),('word-background',14400,[(0,0),(119,1),(14280,1),(14399,0),(14400,0)],bg['linearGain'])]:
 ops.append(stack({'kind':'clip','id':L(label)},[{'processor':{'type':'gain','gain':{'keys':gainkeys(n,points,mult)}}}]))
# Keep a declared workbench image behind the voice context and explicit pause.
ops.append({'operation':'place','label':'voice-picture','clip':{'trackId':ids['picture'],'placement':{'kind':'project','range':{'startUs':F(vs),'endUs':F(ve+600000)}},**inputs['workbenchScreen']['selected'],'source':{'kind':'hold','atUs':75000000}}})
r=remember('local-voice-context',edit(ops,'20-local-paid-context'));audio(r['revision']['id'],'voice-contextual-output',{'startUs':int(vs)+1,'endUs':int(ve)})
# Pause: 600ms of the admitted normal-level looping source, gain 1 and no overlap or extra ramps.
ops=[place('pauseLoop',ids['ambience'],F(ve),F(ve+600000),0,600000,'explicit-pause'),place('music',ids['music'],F(is_),F(ie),0,2000000,'interlude-music')]
ops.append(stack({'kind':'clip','id':L('interlude-music')},[{'processor':{'type':'gain','gain':{'keys':gainkeys(2000000,[(0,0),(500000,.125),(1500000,.125),(2000000,0)])}}}]))
r=remember('music-and-pause',edit(ops,'21-music-pause'));audio(r['revision']['id'],'music-base-full')
ids=json.load(open(HOME/'ids.json'))
r=remember('music-muted',edit([stack({'kind':'track','id':ids['music']},[{'processor':{'type':'gain','gain':0}}])],'22-music-mute'));audio(r['revision']['id'],'music-muted-full');undo('23-undo-music-mute')
r=remember('music-level-half',edit([stack({'kind':'track','id':ids['music']},[{'processor':{'type':'gain','gain':0.5}}])],'24-music-level'));audio(r['revision']['id'],'music-level-half-full');undo('25-undo-music-level')
font={'assetId':inputs['font']['assetId'],'postScriptName':'ArialMT'}
def text(literal):return {'kind':'text','text':literal,'font':font,'width':600,'height':80,'size':48,'color':'#ffffffff','alignment':'center','wrap':False}
ops=[{'operation':'place','label':'fixture-caption','clip':{'trackId':ids['captions'],'placement':{'kind':'project','range':{'startUs':F(is_),'endUs':F(ie)}},'source':text('Primitive fixture')}},{'operation':'place','label':'paid-caption','clip':{'trackId':ids['captions'],'placement':{'kind':'content','clipId':ids['paid-generated'],'sourceRange':{'startUs':240000,'endUs':840000}},'source':text('paid')}}]
for label in ['fixture-caption','paid-caption']:ops.append(stack({'kind':'clip','id':L(label)},[{'processor':{'type':'geometry','rect':{'x':340,'y':625,'width':600,'height':80},'fit':'contain'}}]))
ops.append({'operation':'zoom','target':{'kind':'clip','id':ids['interlude-screen']},'window':{'kind':'clip','clipId':ids['interlude-screen'],'start':F(1,4),'end':F(3,4)},'from':1,'to':1.05,'geometry':{'pivot':{'x':.65,'y':.67}}})
# Deliberately force a stale request; inspect actual head and recompute the intended caption batch.
p={'projectId':project,'requestId':'26-stale-caption-attempt','expectedRevisionId':facts['revisionId'],'operations':ops};call('edit.apply',p,'26-stale-caption-attempt')
r=remember('captions-and-zoom',edit(ops,'27-caption-zoom-recomputed'));audio(r['revision']['id'],'final-full-audio')
t.update({'voiceStart':F(vs),'voiceEnd':F(ve),'generatedStart':F(gs),'generatedEnd':F(ge),'projectEnd':F(ve+600000)});(HOME/'timeline.json').write_text(json.dumps(t,indent=2));(HOME/'final-revision.json').write_text(json.dumps(r['revision'],indent=2))
for name,at in [('interlude-start',is_+34000),('interlude-middle',is_+1000000),('interlude-end',ie-34000),('paid-start',gs+34000),('paid-middle',(gs+ge)/2),('paid-end',ge-34000)]:waitmedia('frame.get',{'projectId':project,'revisionId':r['revision']['id'],'atUs':int(at)},'final-'+name,'png')
