from caller import *
ids=json.load(open(HOME/'ids.json'));base=current('stacks-base');checkpoint('stacks-base',{'revision':base});rg={'startUs':0,'endUs':3282000}
# Each level get/set/reorder/bypass; all mutations are retained as distinct checkpoints.
for kind,key in [('clip','marked-a'),('track','narration'),('group','audio-nested'),('group','audio-root'),('output',None)]:
 target={'kind':kind};
 if key:target['id']=ids[key]
 suffix=key or kind
 print(json.dumps(call('processing.get',{'projectId':project,'revisionId':current('get-'+suffix)['id'],'target':target},'processing-get-'+suffix))[:300])
 steps=[{'processor':{'type':'gain','gain':0.5 if kind=='clip' else 0.8}},{'processor':{'type':'rnnoise'} if kind=='clip' else {'type':'gain','gain':1.25}}]
 r=remember(suffix+'-ordered',edit([stack(target,steps)],'stack-'+suffix+'-set'));audio(r['revision']['id'],suffix+'-ordered-audio',rg)
 got=data(call('processing.get',{'projectId':project,'revisionId':r['revision']['id'],'target':target},'processing-read-'+suffix));print(suffix,got.keys());steps=got['steps']
 r=remember(suffix+'-reordered',edit([stack(target,list(reversed(steps)))],'stack-'+suffix+'-reorder'));audio(r['revision']['id'],suffix+'-reversed-audio',rg)
 for st in steps:st['enabled']=False
 r=remember(suffix+'-bypassed',edit([stack(target,steps)],'stack-'+suffix+'-bypass'));audio(r['revision']['id'],suffix+'-bypassed-audio',rg)
 restore('stack-'+suffix+'-restore',base['id'])
# Insertions below inherit only the explicitly authored compatible narration stack.
r=remember('processed-track-ready',edit([stack({'kind':'track','id':ids['narration']},[{'processor':{'type':'gain','gain':1}}])],'processed-narration-track'))
