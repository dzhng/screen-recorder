from caller import *
recipe=json.load(open('/tmp/screenrec-25-frozen-recipe-facts.json'))
r=call('asset.import',{'requestId':'fresh-caller-word-background','path':recipe['voice']['background']['path']},'word-background-import');print(json.dumps(r))
raw=data(json.load(open(HOME/'fresh-paid-completion.reply.json')))['published']['audio'];inputs['generatedPaid']={'selected':{'assetId':raw['assetId'],'streamId':raw['streamId']}}
waitmedia('audio.get',inputs['generatedPaid']['selected'],'fresh-paid-raw','wav');call('asset.get',{'assetId':raw['assetId']},'fresh-paid-asset')
