from caller import *
cat=json.load(open(HOME/'catalog.json'))
for op in ['voice.generate','edit.undo','edit.restore','audio.get','frame.get','preview.get','export.create','package.open','package.adopt','processing.get']:
 help=subprocess.run(['node',CLI,op,'--help'],capture_output=True,text=True);(HOME/(op+'-help.json')).write_text(help.stdout)
 print(op,json.dumps(json.loads(help.stdout)['operations'][0]['inputSchema'])[:3000])
for k,a in inputs.items():
 j=data(call('asset.get',{'assetId':a['assetId']},'asset-'+k));print(k,json.dumps(j)[:1800])
 if a['selected']:
  z=call('asset.segments',a['selected'],'segments-'+k);print(json.dumps(z)[:1300])
print(json.dumps(call('model.status',{'modelId':'qwen3-tts-icl-v1'},'voice-ready')))
print(json.dumps(call('voice.generate',facts['bindings']['voice']['request'],'fresh-paid-generate'))[:2200])
