from caller import *
from fractions import Fraction
F=lambda n,d=1:{'numerator':Fraction(n,d).numerator,'denominator':Fraction(n,d).denominator}
T=lambda x:Fraction(x['numerator'],x['denominator']) if isinstance(x,dict) else Fraction(x)
ids=json.load(open(HOME/'ids.json'));r=current('undo-split-inspected');audio(r['id'],'undo-split-audio')
t=json.load(open(HOME/'timeline.json'));start=T(t['interludeStart']);end=start+2000000
ops=[place('screen',ids['picture'],F(start),F(end),10000000,12000000,'interlude-screen'),place('camera',ids['camera'],F(start),F(end),10000000,12000000,'interlude-camera'),place('microphone',ids['narration'],F(start),F(end),10000000,12000000,'interlude-mic'),{'operation':'place','label':'interlude-still','clip':{'trackId':ids['still'],'placement':{'kind':'project','range':{'startUs':F(start),'endUs':F(start+1000000)}},**inputs['still']['selected'],'source':{'kind':'hold','atUs':0}}}]
ops.extend([stack({'kind':'clip','id':{'label':'interlude-camera'}},[{'processor':{'type':'geometry','rect':{'x':900,'y':30,'width':350,'height':197},'fit':'contain'}}]),stack({'kind':'clip','id':{'label':'interlude-still'}},[{'processor':{'type':'geometry','rect':{'x':40,'y':40,'width':141,'height':93},'fit':'contain'}}]),stack({'kind':'clip','id':{'label':'interlude-mic'}},[{'processor':{'type':'gain','gain':1}}])])
r=remember('camera-interlude',edit(ops,'12-camera-interlude'));audio(r['revision']['id'],'interlude-original-audio',{'startUs':int(start)+1,'endUs':int(end)});waitmedia('frame.get',{'projectId':project,'revisionId':r['revision']['id'],'atUs':int(start)+500000},'interlude-original-frame','png')
ids=json.load(open(HOME/'ids.json'));save=r['revision']['id']
media={**inputs['workbenchScreen']['selected'],'source':{'kind':'range','range':{'startUs':10000000,'endUs':12000000}}}
r=remember('picture-replacement',edit([{'operation':'replace','clipId':ids['interlude-camera'],'kind':'video','media':media,'fit':'exact','processing':'keep'}],'13-replace-picture'));audio(r['revision']['id'],'picture-replaced-audio',{'startUs':int(start)+1,'endUs':int(end)});waitmedia('frame.get',{'projectId':project,'revisionId':r['revision']['id'],'atUs':int(start)+500000},'picture-replaced-frame','png');undo('14-undo-picture')
media={**inputs['music']['selected'],'source':{'kind':'range','range':{'startUs':0,'endUs':2000000}}}
r=remember('audio-replacement-keep',edit([{'operation':'replace','clipId':ids['interlude-mic'],'kind':'audio','media':media,'fit':'exact','processing':'keep'}],'15-replace-audio-keep'));audio(r['revision']['id'],'audio-replaced-audio',{'startUs':int(start)+1,'endUs':int(end)});waitmedia('frame.get',{'projectId':project,'revisionId':r['revision']['id'],'atUs':int(start)+500000},'audio-replaced-frame','png');undo('16-undo-audio')
r=remember('audio-replacement-reset',edit([{'operation':'replace','clipId':ids['interlude-mic'],'kind':'audio','media':media,'fit':'exact','processing':'reset'}],'17-replace-audio-reset'));undo('18-undo-reset')
t['interludeEnd']=F(end);t['voiceStart']=F(end);(HOME/'timeline.json').write_text(json.dumps(t))
