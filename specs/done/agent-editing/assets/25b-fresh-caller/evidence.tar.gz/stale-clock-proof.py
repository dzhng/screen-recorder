import caller
from caller import *
from fractions import Fraction
caller.SOCKET='/tmp/screenrec-25-relocation-recipient/run/service.sock';caller.project=json.load(open(HOME/'recipient-adoption.json'))['result']['projectId'];project=caller.project
F=lambda n:{'numerator':Fraction(n).numerator,'denominator':Fraction(n).denominator}
T=lambda x:Fraction(x['numerator'],x['denominator']) if isinstance(x,dict) else Fraction(x)
def end(r):return max(T(c['placement']['range']['endUs']) for c in r['document']['clips'] if c['placement']['kind']=='project')
r=current('recipient-stale-original-head');baseline=r['id'];origend=end(r);ids=json.load(open(HOME/'ids.json'))
def silence(at):return {'operation':'place','label':'stale-clock-silence','clip':{'trackId':ids['narration'],'placement':{'kind':'project','range':{'startUs':F(at),'endUs':F(at+100000)}},'source':{'kind':'silence'}}}
saved={'projectId':project,'requestId':'recipient-stale-clock-original','expectedRevisionId':r['id'],'operations':[silence(origend)]}
# Separate accepted mutation changes timeline before pending request, forcing a genuine stale clock.
edit([{'operation':'insert','atUs':0,'durationUs':100000,'ripple':{'trackIds':[t['id'] for t in r['document']['tracks']]}}],'recipient-shift-before-stale')
call('edit.apply',saved,'recipient-stale-clock-rejection');actual=current('recipient-stale-clock-actual');newend=end(actual);result=remember('recipient-stale-clock-recomputed',edit([silence(newend)],'recipient-stale-clock-recomputed',actual['id']));(HOME/'stale-clock-proof.json').write_text(json.dumps({'oldEnd':F(origend),'actualEnd':F(newend),'recomputedEnd':F(newend),'changedByUs':100000,'rejection':json.load(open(HOME/'recipient-stale-clock-rejection.reply.json'))},indent=2));undo('recipient-undo-stale-insertion');undo('recipient-undo-stale-shift');r=current('recipient-final-restored-after-stale');audio(r['id'],'recipient-final-after-stale-audio')
