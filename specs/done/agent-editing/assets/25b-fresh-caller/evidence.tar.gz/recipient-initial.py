import caller
from caller import *
caller.SOCKET='/tmp/screenrec-25-relocation-recipient/run/service.sock'
for op,p in [('service.health',{}),('project.list',{}),('asset.list',{}),('model.status',{'modelId':'qwen3-tts-icl-v1'}),('model.status',{'modelId':'parakeet'})]:print(json.dumps(call(op,p,'recipient-initial-'+op+('-'+p['modelId'] if 'modelId' in p else ''))))
