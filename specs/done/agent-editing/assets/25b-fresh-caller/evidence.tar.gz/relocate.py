import caller
from caller import *
caller.SOCKET='/tmp/screenrec-25-relocation-recipient/run/service.sock'
op=data(json.load(open(HOME/'recipient-package-open-canonical.reply.json')));admission=op['id']
for n in range(300):
 st=data(call('package.status',{'admissionId':admission},'recipient-package-status-'+str(n)))
 if st.get('state')=='ready' or st.get('packageHandle'):break
 if st.get('state') in ['failed','canceled']:raise RuntimeError(st)
 time.sleep(1)
print(json.dumps(st)[:3500]);handle=st['packageHandle'];p={'packageHandle':handle,'requestId':'recipient-adopt-fixture'}
st=data(json.load(open(HOME/'recipient-adopt-3.reply.json')))
(HOME/'recipient-adoption.json').write_text(json.dumps(st,indent=2));caller.project=st['result']['projectId'];project=caller.project
call('project.get',{'projectId':project},'recipient-project-get');r=current('recipient-revision-get');(HOME/'recipient-final-revision.json').write_text(json.dumps(r,indent=2));hist=data(call('revision.history',{'projectId':project},'recipient-history'));(HOME/'recipient-history-all.json').write_text(json.dumps(hist,indent=2))
settings={'preset':'balanced','video':{'rateControl':{'mode':'average','bitrate':3000000}}};waitmedia('preview.get',{'projectId':project,'revisionId':r['id'],'settings':settings},'recipient-fixture-preview','mp4');audio(r['id'],'recipient-fixture-audio')
for suffix,at in [('interlude-middle',12566968),('paid-middle',16530635)]:waitmedia('frame.get',{'projectId':project,'revisionId':r['id'],'atUs':at},'recipient-'+suffix,'png')
# The same durable word source remains ordinary usable media. A changed model-dependent request must refuse absent preparation.
call('model.status',{'modelId':'qwen3-tts-icl-v1'},'recipient-model-still-absent');req=json.loads(json.dumps(facts['bindings']['voice']['request']));req['seed']='19';call('voice.generate',req,'recipient-changed-voice-settings')
# Retained denoise branch restores and undoes using packaged history, with mono channel identity verified separately.
branch=next(x for x in hist['revisions'] if x['ordinal']==json.load(open(HOME/'stack-marked-a-set.reply.json'))['data']['revision']['ordinal']);restore('recipient-restore-denoise',branch['id']);rr=current('recipient-denoise-head');audio(rr['id'],'recipient-denoise-audio',{'startUs':0,'endUs':3282000});undo('recipient-undo-denoise');rr=current('recipient-undo-denoise-head');audio(rr['id'],'recipient-undo-denoise-audio')
# Compare delivered whole movie across pure split through packaged historical revisions.
old=json.load(open(HOME/'checkpoints.json'));preord=old['pre-pure-split']['revision']['ordinal'];postord=old['pure-split']['revision']['ordinal']
for suffix,ordinal in [('pre-split',preord),('post-split',postord)]:
 hr=next(x for x in hist['revisions'] if x['ordinal']==ordinal);waitmedia('preview.get',{'projectId':project,'revisionId':hr['id'],'settings':settings},'recipient-'+suffix+'-preview','mp4')
call('package.close',{'admissionId':admission},'recipient-package-close')
