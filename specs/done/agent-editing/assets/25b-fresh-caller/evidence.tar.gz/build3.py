from caller import *
from fractions import Fraction
F=lambda n,d=1: {'numerator':Fraction(n,d).numerator,'denominator':Fraction(n,d).denominator}
ids=json.load(open(HOME/'ids.json'));r=current('before-exact-retime');c={x['id']:x for x in r['document']['clips']};start=6432000;midstart=start+650125;midend=Fraction(start+650125)+Fraction(1259875)*Fraction(5,4);end=midend+2910000
ops=[{'operation':'remove','clipIds':[ids['retime-mid'],ids['retime-tail'],ids['retime-picture']],'scope':'selected','ripple':'none'},place('retimeOriginal',ids['narration'],midstart,F(midend),650125,1910000,'retime-mid-exact','preserve'),place('retimeOriginal',ids['narration'],F(midend),F(end),1910000,4820000,'retime-tail-exact','preserve'),{'operation':'place','label':'retime-picture-exact','clip':{'trackId':ids['picture'],'placement':{'kind':'project','range':{'startUs':start,'endUs':F(end)}},**inputs['still']['selected'],'source':{'kind':'hold','atUs':0}}}]
r=json.load(open(HOME/'06d-exact-retime-placement.reply.json'))['data']
# Sample-exact join gain authoring using normalized piece clocks.
clips=r['revision']['document']['clips'];aa=[x for x in clips if x.get('assetId')==inputs['workbenchNarration']['assetId']]
ops=[]
for i,c in enumerate(aa):
 dur=Fraction(c['placement']['range']['endUs'])-Fraction(c['placement']['range']['startUs']);keys=[{'at':F(0),'value':1 if i==0 else 0,'interpolation':'hold'}]
 if i==0:
  for j in range(240):keys.append({'at':F((dur-5000)+Fraction(j*1000000,48000),dur),'value':(239-j)/240,'interpolation':'hold'})
 else:
  keys=[]
  for j in range(241):keys.append({'at':F(Fraction(j*1000000,48000),dur),'value':j/240,'interpolation':'hold'})
 keys.append({'at':F(1),'value':0 if i==0 else 1,'interpolation':'hold'})
 old=next(x for x in r['revision']['document']['processing'] if x['target']['id']==c['id'])['steps'][0];ops.append(stack({'kind':'clip','id':c['id']},[{'id':old['id'],'processor':{'type':'gain','gain':{'keys':keys}}}]))
r=remember('marked-speech-exact-join',edit(ops,'07-exact-marked-join'));audio(r['revision']['id'],'marked-exact',{'startUs':0,'endUs':6432000})
print(json.dumps(call('voice.generate',facts['bindings']['voice']['request'],'fresh-paid-completion'))[:7000])
(HOME/'timeline.json').write_text(json.dumps({'interludeStart':F(end),'retimeEnd':F(end)}))
