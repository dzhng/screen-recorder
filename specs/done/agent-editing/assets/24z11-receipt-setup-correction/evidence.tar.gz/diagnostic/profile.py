from pathlib import Path
import subprocess,hashlib,json
root=Path('/Users/david/.codex/worktrees/mcp-result-delivery/screen-recorder')
p=root/'apps/cli/src/result-delivery.test.ts'
original=p.read_bytes();s=original.decode();(Path('/tmp/screenrec-24z11-correction')/'original-result-delivery.test.ts').write_bytes(original)
start='test("production project service replays the retained receipt through default MCP without new clip authoring", async () => {\n'
s=s.replace(start,start+'  const profileStart = performance.now();\n  let previousPhase = profileStart;\n  const profilePhase = (phase: string) => { const now = performance.now(); console.info(JSON.stringify({ profile: "24z11-receipt", phase, ms: now - previousPhase, totalMs: now - profileStart })); previousPhase = now; };\n')
replacements=[
 ('  expect(createHash("sha256").update(raw)', '  profilePhase("retained-tar-extraction");\n  expect(createHash("sha256").update(raw)'),
 ('  const data: unknown = JSON.parse(raw.toString());','  profilePhase("retained-authority-hash");\n  const data: unknown = JSON.parse(raw.toString());'),
 ('  const operations = saved.edit.normalized.flatMap','  profilePhase("receipt-json-and-schema");\n  const operations = saved.edit.normalized.flatMap'),
 ('  const home = await mkdtemp("/tmp/mcp-production-result-");','  profilePhase("fixture-arguments-authoring");\n  const home = await mkdtemp("/tmp/mcp-production-result-");'),
 ('  cleanup.push(() => service.close());','  profilePhase("service-startup");\n  cleanup.push(() => service.close());'),
 ('  const client = new Client({ name: "production-result", version: "1" });','  profilePhase("fixture-storage-seeding");\n  const client = new Client({ name: "production-result", version: "1" });'),
 ('  const delivered = await client.callTool({ name: "edit.apply", arguments: params });','  profilePhase("sdk-bootstrap");\n  const delivered = await client.callTool({ name: "edit.apply", arguments: params });\n  profilePhase("operation-to-descriptor");'),
 ('  const bytes = Buffer.concat(chunks);','  profilePhase("complete-artifact-reads");\n  const bytes = Buffer.concat(chunks);'),
 ('  const cli = promisify(execFile)(', '  profilePhase("complete-byte-and-storage-oracles");\n  const cli = promisify(execFile)('),
 ('  await client.callTool({\n    name: "artifact.close",\n    arguments: { token: descriptor.resultDelivery.token },\n  });','  profilePhase("ordinary-cli-and-full-byte-oracle");\n  await client.callTool({\n    name: "artifact.close",\n    arguments: { token: descriptor.resultDelivery.token },\n  });\n  profilePhase("artifact-close");'),
]
# Limit instrumentation to the retained receipt test only.
a,b=s.split('test("deferred media metadata',1)
for old,new in replacements:
 assert old in a,old
 a=a.replace(old,new,1)
s=a+'test("deferred media metadata'+b
p.write_text(s)
(Path('/tmp/screenrec-24z11-correction')/'profiled-result-delivery.test.ts').write_text(s)
cmd=['node','node_modules/vitest/vitest.mjs','run','apps/cli/src/result-delivery.test.ts','-t','production project service','--reporter=verbose','--disableConsoleIntercept']
try:
 with Path('/tmp/screenrec-24z11-correction/profile.log').open('w') as out:r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=60)
 print(json.dumps({'exit':r.returncode,'command':cmd,'originalSha256':hashlib.sha256(original).hexdigest()}))
finally:
 p.write_bytes(original)
 assert p.read_bytes()==original
