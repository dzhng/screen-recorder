import AppKit
import ScreenRecorderControls
@MainActor final class Target: NSObject { @objc func choose(_ sender: NSMenuItem) {} }
@main struct Shot {
@MainActor static func main() throws {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    NSApp.appearance = NSAppearance(named: .aqua)
    var state = ControlsState(); state.service = .ready
    state.library.recent = [.init(recordingId: "fixture-recording", createdAt: "2026-10-02T12:00:00Z", state: "complete", sourceDurationUs: 9_000_000, interruptionReason: nil, sourceId: "fixture-source", sourceAdmissions: [])]
    state.library.projects = [try JSONDecoder().decode(LibraryState.Project.self, from: Data(#"{"projectId":"fixture-project","title":"Caller project","createdAt":"2026-10-02T12:00:00Z","currentRevisionId":"fixture-revision"}"#.utf8))]
    let target = Target(), menu = NSMenu()
    StatusMenu.apply(RecordingMenu.entries(for: state), to: menu, target: target, action: #selector(Target.choose(_:)))
    let sections = ["Recent Recordings", "Projects"].map { title -> (String, [NSMenuItem]) in
        let group = menu.items.first { $0.title == title }!.submenu!
        return (title, group.items.first!.submenu!.items)
    }
    let selected = CommandLine.arguments[2]
    let rowHeight: CGFloat = 26, column: CGFloat = 380, margin: CGFloat = 18
    let height: CGFloat = 360
    let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: column + margin * 2, height: height), styleMask: [.borderless], backing: .buffered, defer: false)
    let view = window.contentView!
    for section in sections where section.0 == selected {
        let heading = NSMenuItem(title: section.0, action: nil, keyEquivalent: "")
        let items = [heading] + section.1
        let matrix = NSMatrix(frame: NSRect(x: margin, y: height - margin - CGFloat(items.count) * rowHeight, width: column, height: CGFloat(items.count) * rowHeight), mode: NSMatrix.Mode(rawValue: 2)!, cellClass: NSMenuItemCell.self, numberOfRows: items.count, numberOfColumns: 1)
        matrix.cellSize = NSSize(width: column, height: rowHeight)
        matrix.intercellSpacing = .zero
        matrix.drawsBackground = true
        matrix.backgroundColor = .windowBackgroundColor
        for (ordinal, item) in items.enumerated() {
            let cell = matrix.cell(atRow: ordinal, column: 0) as! NSMenuItemCell
            cell.menuItem = item; cell.title = item.title; cell.font = .menuFont(ofSize: 13)
            cell.isEnabled = item.isEnabled; cell.calcSize()
        }
        view.addSubview(matrix)
    }
    view.layoutSubtreeIfNeeded()
    let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds)!
    view.cacheDisplay(in: view.bounds, to: bitmap)
    try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
    window.close()
}
}
