import { readFileSync, writeFileSync } from 'node:fs';
const out = '/Users/david/.cache/screen-recorder/verification/composition-contract';
const preview = readFileSync('apps/macos/Tests/preview-service.test.mjs','utf8').match(/writeFile\(\s*swift,\s*(`[^`]+`)/)[1];
writeFileSync(out+'/PreviewServiceFixture.swift', Function('return '+preview)());
const exports = [...readFileSync('apps/macos/Tests/export-controls.test.mjs','utf8').matchAll(/String\.raw`([^`]+)`/g)].at(-1)[1];
writeFileSync(out+'/ExportServiceFixture.swift', exports);
