# Choices

Sound, high confidence: project-only composition selectors and native actions follow the spec/user boundary; recordings retain source lifetime and deletion. Detection remains evidence, never edit authority.

Sound, high confidence: remove dead router now, retain mixed core export/package owners only until their separately owned deletion. No compatibility route, field filter or legacy shadow type added. Root explicitly keeps the unused recording revision column and current cursor metadata until their real writer/schema owner purge.

Sound, high confidence: rehome useful consumer fixtures to actual canonical CaptureStore and explicit project APIs. CPU-only silence fixture preserves10s→8s removal→exact original-document undo, replay/stale/head/history across actual CLI and MCP. Generated video fixtures keep1fps source2s/8s durations and their original source-byte/pinned revision/lease/deletion/rediscovery assertions; expensive executions deferred to final suite.

Sound, medium confidence: visual proof uses offscreen production NSMenu items rendered in native AppKit cells. This proves labels/order/clipping and leaves live popup/installed behavior outside scope. Four valid section images receive unprimed critique and background Preview handoff; failed detached-cell and two-column captures remain rejected diagnostics.

Routine internal naming and formatting compressed; no user-only decision or new editorial policy introduced.
