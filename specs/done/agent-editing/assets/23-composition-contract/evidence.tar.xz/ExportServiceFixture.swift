
import AppKit
import ScreenRecorderControls

@MainActor final class Service {
    var state: ServiceHost.State = .starting
    var host: ServiceHost!
    static func start(_ resolved: ServiceBundle) async -> Service {
        let service = Service()
        service.host = ServiceHost(bundle: resolved, onNativeCall: { _, _, answer in
            answer(.failure(ServiceFailure(code: "UNKNOWN_OPERATION", message: "This check owns no capture session")))
        }) { state in Task { @MainActor in service.state = state } }
        service.host.start()
        for _ in 0..<150 {
            if case .ready = service.state { return service }
            if case .unavailable(let code, let message) = service.state { fatalError("\(code): \(message)") }
            try? await Task.sleep(for: .milliseconds(100))
        }
        fatalError("Bundled service did not become ready")
    }
    func call(_ operation: String, _ params: [String: Any]) async throws(ServiceFailure) -> Data {
        try await host.call(operation, params)
    }
}

@main struct Check {
    @MainActor static func main() {
        let app = NSApplication.shared
        Task { @MainActor in
            await run()
            app.terminate(nil)
        }
        app.run()
    }
    @MainActor static func until(_ seconds: Int, _ poll: () -> Void, _ condition: () -> Bool) async {
        for _ in 0..<(seconds * 10) where !condition() {
            poll()
            try? await Task.sleep(for: .milliseconds(100))
        }
        precondition(condition(), "Timed out waiting for the bundled service")
    }
    @MainActor static func run() async {
        NSApp.setActivationPolicy(.accessory)
        let arguments = CommandLine.arguments
        let (bundlePath, projectId, directory, pinnedRevision, clipId) = (arguments[1], arguments[2], arguments[3], arguments[4], arguments[5])
        let resolved: ServiceBundle = try! await withCheckedThrowingContinuation { continuation in
            ServiceBundle.resolve(in: Bundle(path: bundlePath)!) { continuation.resume(with: $0) }
        }
        var service = await Service.start(resolved)
        var failures: [String] = []
        var revealed: [URL] = []
        let first = ExportController(
            call: { operation, params throws(ServiceFailure) in try await service.call(operation, params) },
            choose: { kind, _ in
                precondition(kind == .video)
                // An edit made while the panel is open does not change the pinned export.
                _ = try? await service.call("edit.apply", ["projectId": projectId, "requestId": UUID().uuidString,
                    "expectedRevisionId": pinnedRevision, "operations": [["operation": "trim", "clipId": clipId, "range": ["startUs": 0, "endUs": 1_000_000], "ripple": "none"]]])
                return URL(fileURLWithPath: directory).appendingPathComponent("demo.mp4")
            },
            reveal: { revealed.append($0) }, changed: {}, failure: { failures.append($0) })

        first.export(projectId, kind: .video)
        await until(60, first.tick) { first.state.records.first?.committed == true || !failures.isEmpty }
        precondition(failures.isEmpty, "Export failed: \(failures)")
        let committed = first.state.records[0]
        precondition(committed.revisionId == pinnedRevision && committed.leaf == "demo.mp4" && committed.directory == directory,
            "The committed export is the revision pinned before the edit: \(committed)")
        first.reveal(committed.exportId)
        precondition(revealed == [URL(fileURLWithPath: directory).appendingPathComponent("demo.mp4")])
        let current = try! JSONSerialization.jsonObject(with: await service.call("project.get", ["projectId": projectId])) as! [String: Any]
        precondition(current["currentRevisionId"] as? String != pinnedRevision, "The library edit did advance")

        // The same destination is occupied now, so the service refuses to replace it.
        let occupied = ExportController(
            call: { operation, params throws(ServiceFailure) in try await service.call(operation, params) },
            choose: { _, _ in URL(fileURLWithPath: directory).appendingPathComponent("demo.mp4") },
            reveal: { _ in }, changed: {}, failure: { failures.append($0) })
        occupied.export(projectId, kind: .video)
        await until(60, occupied.tick) { occupied.state.records.first?.state == "failed" || !failures.isEmpty }
        precondition(failures.isEmpty, "Occupied export was refused before admission: \(failures)")
        let failed = occupied.state.records[0].exportId
        print("EXPORTS committed=\(committed.exportId) failed=\(failed)")

        service.host.shutdown()
        service = await Service.start(resolved)
        let restarted = ExportController(
            call: { operation, params throws(ServiceFailure) in try await service.call(operation, params) },
            choose: { _, _ in nil }, reveal: { _ in }, changed: {}, failure: { failures.append($0) })
        restarted.discover()
        await until(20, {}) { !restarted.state.records.isEmpty || restarted.state.discoveryFailure != nil }
        precondition(restarted.state.discoveryFailure == nil, "\(restarted.state.discoveryFailure!)")
        precondition(restarted.state.records.map(\.exportId) == [failed],
            "Only the unfinished export is rediscovered: \(restarted.state.records.map(\.exportId))")
        let found = restarted.state.records[0]
        precondition(found.state == "failed" && found.directory == directory && found.leaf == "demo.mp4",
            "The rediscovered export states its admitted destination without app storage")
        restarted.abandon(failed)
        await until(30, {}) { restarted.state.records.isEmpty || !restarted.state.failures.isEmpty }
        precondition(restarted.state.failures.isEmpty, "\(restarted.state.failures)")
        do throws(ServiceFailure) {
            _ = try await service.call("export.status", ["exportId": failed])
            preconditionFailure("An abandoned export has no status")
        } catch {
            precondition(error.code == "NOT_FOUND", error.localizedDescription)
        }
        service.host.shutdown()
        print("PASS native exports commit, rediscover an unfinished export after restart and abandon it")
    }
}
