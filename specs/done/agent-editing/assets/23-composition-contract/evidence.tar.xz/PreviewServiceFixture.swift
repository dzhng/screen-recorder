
import AppKit
import AVKit
import Foundation
import CryptoKit

@MainActor final class Bridge {
    var state: ServiceHost.State = .starting
}
@main struct Integration {
    @MainActor static func main() {
        let app = NSApplication.shared
        Task { @MainActor in
            do { try await runIntegration(); app.terminate(nil) }
            catch {
                FileHandle.standardError.write(Data("Integration failed: \(error)\n".utf8))
                exit(1)
            }
        }
        app.run()
    }
    @MainActor static func pause() async { try? await Task.sleep(for: .milliseconds(100)) }
    @MainActor static func visible() -> NSWindow? { NSApp.windows.first { $0.isVisible && $0.title.hasPrefix("Preview —") } }
    @MainActor static func runIntegration() async throws {
        _ = NSApplication.shared
        NSApp.setActivationPolicy(.accessory)
        let bundle = Bundle(path: CommandLine.arguments[1])!
        let resolved: ServiceBundle = try await withCheckedThrowingContinuation { continuation in
            ServiceBundle.resolve(in: bundle) { continuation.resume(with: $0) }
        }
        let bridge = Bridge()
        let host = ServiceHost(
            bundle: resolved,
            onNativeCall: { _, _, answer in
                answer(.failure(ServiceFailure(code: "UNKNOWN_OPERATION", message: "This check owns no capture session")))
            }
        ) { state in Task { @MainActor in bridge.state = state } }
        host.start()
        defer { host.shutdown() }
        var ready = false
        for _ in 0..<100 {
            if case .ready = bridge.state { ready = true; break }
            if case .unavailable(let code, let message) = bridge.state { fatalError("\(code): \(message)") }
            await pause()
        }
        precondition(ready, "Bundled service did not become ready")
        if case .ready(let pid, _) = bridge.state {
            FileHandle.standardOutput.write(Data("SERVICE_PID=\(pid)\n".utf8))
        }
        var failures: [String] = []
        let owner = PreviewController(call: { try await host.call($0, $1) }, failure: { failures.append($0) })
        defer { owner.close() }
        let id = CommandLine.arguments[2]
        owner.open(id)
        var item: AVPlayerItem?
        for _ in 0..<150 {
            owner.tick(); await pause()
            precondition(failures.isEmpty, "Preview failed: \(failures)")
            if let candidate = (visible()?.contentView as? AVPlayerView)?.player?.currentItem,
                candidate.status == .readyToPlay { item = candidate; break }
        }
        guard let item, let window = visible(), let view = window.contentView as? AVPlayerView else {
            fatalError("Actual service preview never became playable")
        }
        precondition(window.title.hasSuffix(CommandLine.arguments[5]))
        precondition(abs(CMTimeGetSeconds(item.duration)-8) < 0.001)
        precondition(!view.allowsVideoFrameAnalysis)
        view.player!.pause()
        _ = try await host.call("edit.apply", ["projectId": id, "requestId": UUID().uuidString, "expectedRevisionId": CommandLine.arguments[5], "operations": [["operation": "remove", "clipIds": [CommandLine.arguments[6]], "ranges": [["startUs": 2000000, "endUs": 4000000]], "ripple": ["trackIds": [CommandLine.arguments[7]]]]]])
        // The real service lease initially lasts 30s. Paused playback must retain its
        // original item past that deadline while the current library edit advances.
        let until = Date().addingTimeInterval(31)
        while Date() < until {
            owner.tick(); await pause()
            precondition(failures.isEmpty && visible() === window && view.player?.currentItem === item,
                "Pinned player changed or lost its renewed lease")
        }
        precondition(window.title.hasSuffix(CommandLine.arguments[5]) && abs(CMTimeGetSeconds(item.duration)-8) < 0.001)
        let current = try JSONSerialization.jsonObject(with: await host.call("revision.get", ["projectId":id])) as! [String:Any]
        let document = (current["revision"] as! [String: Any])["document"] as! [String: Any]
        let clips = document["clips"] as! [[String: Any]]
        let duration = clips.reduce(0) { total, clip in let placement = clip["placement"] as! [String: Any]; let range = placement["range"] as! [String: Int]; return total + range["endUs"]! - range["startUs"]! }
        precondition(duration == 6000000)
        let asset = item.asset as! AVURLAsset
        precondition(FileManager.default.fileExists(atPath: asset.url.path))
        let hash = SHA256.hash(data: try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[3])))
            .map { String(format: "%02x", $0) }.joined()
        precondition(hash == CommandLine.arguments[4], "Source changed during native playback")
        print("PASS pinned native player past original lease deadline; current edit is 6s")
        _ = try await host.call("project.delete", ["projectId":id])
        for _ in 0..<30 { owner.tick(); await pause(); if visible() == nil { break } }
        precondition(visible() == nil && view.player == nil)
        precondition(!FileManager.default.fileExists(atPath: asset.url.path))
        precondition(failures.last?.contains("NOT_FOUND") == true)
        print("PASS real deletion stops player and removes cached media")
    }
}
