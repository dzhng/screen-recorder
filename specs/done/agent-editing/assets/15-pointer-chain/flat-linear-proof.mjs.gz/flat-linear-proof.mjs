import {readFile,writeFile} from 'node:fs/promises';
import {sourceSurface,stackSurface,expectedRgba} from '/tmp/screenrec-editing-speech/packages/test-harness/editing/layers-oracle.mjs';
const rgba=await readFile('/tmp/screenrec-pointer-chain-final/whole-chain/source-800000.png.rgba');
const reference=expectedRgba(stackSurface({...sourceSurface({width:256,height:160,rgba}),canvasDomain:true},[{processor:{type:'geometry',crop:{x:32,y:24,width:192,height:112},rect:{x:24,y:16,width:192,height:128},fit:'cover'}}],{width:256,height:160}));
for(const [name,file] of [['flat','/tmp/screenrec-pointer-flat-control3/flat-cover.png.rgba'],['original','/tmp/screenrec-pointer-chain-stages2/clip-0.png.rgba']]){const b=await readFile(file);console.log(name,b.reduce((m,v,i)=>Math.max(m,Math.abs(v-reference[i])),0),b.reduce((n,v,i)=>n+(Math.abs(v-reference[i])>2),0))}
await writeFile('/tmp/pointer-flat-linear-expected.rgba',reference);
