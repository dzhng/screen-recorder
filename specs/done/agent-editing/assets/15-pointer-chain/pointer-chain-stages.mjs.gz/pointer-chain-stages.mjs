import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {JourneyService,poll,run} from '/tmp/screenrec-editing-speech/packages/test-harness/editing/source-evidence-fixture.mjs';
import {sourceSurface,stackSurface,expectedRgba,over,background} from '/tmp/screenrec-editing-speech/packages/test-harness/editing/layers-oracle.mjs';
function cachedCenters(surface) {
  const values = new Float64Array(surface.width * surface.height * 4);
  const ready = new Uint8Array(surface.width * surface.height);
  return {
    ...surface,
    sample(x, y) {
      const ix = x - 0.5,
        iy = y - 0.5;
      if (
        !Number.isInteger(ix) ||
        !Number.isInteger(iy) ||
        ix < 0 ||
        iy < 0 ||
        ix >= surface.width ||
        iy >= surface.height
      )
        return surface.sample(x, y);
      const index = iy * surface.width + ix;
      if (!ready[index]) {
        values.set(surface.sample(x, y), index * 4);
        ready[index] = 1;
      }
      return values.subarray(index * 4, index * 4 + 4);
    },
  };
}


const report=JSON.parse(await readFile('/tmp/screenrec-pointer-chain-final/report.json','utf8'));const chain=report.checks.wholeChain,row=chain.rows.find(r=>r.name==='256x160-cover');const home=report.checks.frame.receipt.file.split('/library/')[0].replace(/^\/private/,'');const out='/tmp/screenrec-pointer-chain-stages2';await mkdir(out);const result={trace:[],stages:[]};const service=new JourneyService(home,result,out+'/native');
try{await service.start();const call=service.call.bind(service);const revision=(await call('revision.get',row.selection)).revision;const doc=revision.document;const clip=doc.clips[0];const byTarget=id=>doc.processing.find(p=>p.target.id===id);const clipStack=byTarget(clip.id);let surface=sourceSurface({width:256,height:160,rgba:await readFile(chain.references[0].file+'.rgba'),encodedProfile:'srgb'});
const stages=[{name:'pointer',target:{kind:'clip',id:clip.id},stepId:clipStack.steps[0].id},...row.steps.clip.map((step,i)=>({name:'clip-'+i,target:{kind:'clip',id:clip.id},stepId:clipStack.steps[i+1].id,steps:[step]})),{name:'track',target:{kind:'track',id:clip.trackId},steps:row.steps.track},{name:'inner',target:{kind:'group',id:doc.tracks[0].parentId},steps:row.steps.inner},{name:'outer',target:{kind:'group',id:doc.groups.find(g=>!g.parentId).id},steps:row.steps.outer},{name:'output',target:{kind:'output'},steps:row.steps.output}];
for(const [i,stage] of stages.entries()){
 if(stage.name==='output')surface=over(background(row.canvas),surface);
 if(stage.steps)surface=cachedCenters(stackSurface(surface,stage.steps,row.canvas,i===1));
 const expected=expectedRgba(surface),file=out+'/'+stage.name+'.png';await call('frame.retry',{...row.selection,atUs:0,maxLongEdge:256,tap:{target:stage.target,point:stage.stepId?{kind:'after-step',stepId:stage.stepId}:{kind:'processed'}}});const receipt=await poll(()=>call('frame.get',{...row.selection,atUs:0,maxLongEdge:256,tap:{target:stage.target,point:stage.stepId?{kind:'after-step',stepId:stage.stepId}:{kind:'processed'}}},{output:file}),v=>v.state==='ready',stage.name);await run('/tmp/screenrec-pointer-chain-final/whole-chain/frame-pixels',[file,file+'.rgba']);const actual=await readFile(file+'.rgba');await writeFile(file+'.expected.rgba',expected);result.stages.push({name:stage.name,receipt,maximumError:actual.reduce((m,v,k)=>Math.max(m,Math.abs(v-expected[k])),0),aboveTwo:actual.reduce((n,v,k)=>n+(Math.abs(v-expected[k])>2),0)});
}
}finally{await service.stop();await writeFile(out+'/report.json',JSON.stringify(result,null,2));}console.log(result.stages.map(s=>({name:s.name,max:s.maximumError,aboveTwo:s.aboveTwo})));
