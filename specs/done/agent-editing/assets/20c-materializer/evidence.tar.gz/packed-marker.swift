import AVFoundation
import Foundation
let a=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1])),t=try await a.loadTracks(withMediaType:.audio)[0],r=try AVAssetReader(asset:a),o=AVAssetReaderTrackOutput(track:t,outputSettings:nil)
r.add(o);precondition(r.startReading())
while let s=o.copyNextSampleBuffer(){print("packet",s.numSamples,s.presentationTimeStamp,s.duration,"valid",s.isValid,"ready",CMSampleBufferDataIsReady(s),"bytes",s.dataBuffer.map{CMBlockBufferGetDataLength($0)} as Any);if s.numSamples==0{print(CMCopyDictionaryOfAttachments(allocator:nil,target:s,attachmentMode:kCMAttachmentMode_ShouldPropagate) as Any);print(CMCopyDictionaryOfAttachments(allocator:nil,target:s,attachmentMode:kCMAttachmentMode_ShouldNotPropagate) as Any)}}
print("status",r.status.rawValue)
if let c=t.makeSampleCursorAtLastSampleInDecodeOrder(){print("last",c.presentationTimeStamp,c.decodeTimeStamp,c.currentSampleDuration)}
