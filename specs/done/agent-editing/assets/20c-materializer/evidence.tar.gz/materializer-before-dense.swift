@preconcurrency import AVFoundation
import CryptoKit
import Foundation
import ScreenRecorderMedia

package struct CaptureMediaIdentity: Codable, Sendable, Equatable {
  package let bytes: Int64
  package let sha256: String
}

/// Candidate facts only. Publication and removal of working media belong to the caller.
package struct CaptureAudioMaterialization: Sendable {
  package let role: String
  package let payload: CaptureMediaIdentity
  package let journal: JournalPrefix
  package let acceptedFrames: Int64
  package let committedFrames: Int64
  package let representedFrames: Int64
  package let cleanPhysicalEOF: Bool
  package let diagnostic: String?
  package let candidate: URL?
  package let canonical: CaptureMediaIdentity?
  package let pcmSHA256: String
  package let supportSHA256: String
}

package enum CaptureAudioMaterializer {
  private struct Run {
    let physical: Int64
    let declared: Int64
    var count: Int64
  }

  /// Inputs must remain immutable under the publication owner's take lease. Roles are invoked
  /// sequentially so platform export metadata is not multiplied by concurrent finalizations.
  package static func materialize(lease: CaptureJournalLease, through prefix: JournalPrefix,
    role: String, candidate: URL) async throws
    -> CaptureAudioMaterialization
  {
    try Task.checkCancellation()
    try lease.check()
    let directory = lease.directory
    let existing = FileManager.default.fileExists(atPath: candidate.path)
    guard ["narration", "system"].contains(role) else { throw invalid("Invalid audio role.") }
    var format: JournalPCMTrack?
    var runs: [Run] = []
    var accepted: Int64 = 0
    let journal = try CaptureJournal.streamAcceptedPCM(lease: lease, through: prefix, track: {
      if $0.role == role { format = $0 }
    }) { append in
      try Task.checkCancellation()
      guard append.role == role else { return }
      accepted = append.physicalFirstFrame + append.frameCount
      if let last = runs.last, last.physical + last.count == append.physicalFirstFrame,
        last.declared + last.count == append.declaredFirstFrame
      {
        runs[runs.count - 1].count += append.frameCount
      } else {
        // Provisional measured materializer capacity, not a new recording/admission domain.
        guard runs.count < 100_000 else {
          throw invalid("Sparse materializer exceeds its measured 100000-run capacity; retain working media.")
        }
        runs.append(Run(physical: append.physicalFirstFrame, declared: append.declaredFirstFrame,
          count: append.frameCount))
      }
    }
    guard let format, journal.validatedPrefix == prefix else {
      throw invalid("No validated accepted PCM track is available.")
    }
    let scale = try timescale(format)
    let payloadURL = URL(fileURLWithPath: directory).appendingPathComponent(format.file)
    let payload = try identity(payloadURL)
    let input = try MediaInput(url: payloadURL)
    let tracks = try await input.asset.loadTracks(withMediaType: .audio)
    guard tracks.count == 1 else { throw invalid("Packed media must contain exactly one audio track.") }
    let track = tracks[0]
    try await validate(track, format: format)
    let physical = try await scan(input: input, track: track, format: format, accepted: accepted)
    let represented = min(accepted, physical.frames)
    runs = runs.compactMap { run in
      guard run.physical < represented else { return nil }
      return Run(physical: run.physical, declared: run.declared,
        count: min(run.count, represented - run.physical))
    }
    var support = digest("screenrec.capture-support.v1", format: format)
    integer(format.phaseUs, into: &support)
    for run in runs {
      integer(run.physical, into: &support)
      integer(run.declared, into: &support)
      integer(run.count, into: &support)
    }
    let supportHash = hex(support.finalize())
    var canonical: CaptureMediaIdentity?
    if represented > 0 {
      if !existing {
      let composition = AVMutableComposition()
      guard let target = composition.addMutableTrack(withMediaType: .audio,
        preferredTrackID: kCMPersistentTrackID_Invalid)
      else { throw invalid("Cannot create canonical audio track.") }
      target.naturalTimeScale = scale
      var pieces: [AVCompositionTrackSegment] = []
      var previous = CMTime.zero
      for run in runs {
        try Task.checkCancellation()
        let at = try placement(run.declared, format: format, scale: scale)
        let duration = CMTime(value: run.count, timescale: format.rate)
        if at > previous {
          pieces.append(AVCompositionTrackSegment(timeRange:
            CMTimeRange(start: previous, duration: CMTimeSubtract(at, previous))))
        }
        pieces.append(AVCompositionTrackSegment(url: input.url, trackID: track.trackID,
          sourceTimeRange: CMTimeRange(start: CMTime(value: run.physical, timescale: format.rate), duration: duration),
          targetTimeRange: CMTimeRange(start: at, duration: duration)))
        previous = try placement(run.declared + run.count, format: format, scale: scale)
      }
      try target.validateSegments(pieces)
      target.segments = pieces
      pieces.removeAll()
      guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough)
      else { throw invalid("Cannot export canonical audio.") }
      try Task.checkCancellation()
      try await exporter.export(to: candidate, as: .mov)
      try Task.checkCancellation()
      }
      try await verify(candidate, format: format, runs: runs, scale: scale,
        expectedPCM: physical.pcm)
      canonical = try identity(candidate)
    } else if existing {
      throw invalid("Existing candidate has no represented physical prefix.")
    }
    // This is a mutation check, not a substitute for the caller's immutable-input lease.
    guard try identity(payloadURL) == payload else { throw invalid("Packed media changed during materialization.") }
    _ = try CaptureJournal.streamAcceptedPCM(lease: lease, through: prefix) { _ in }
    let diagnostic = physical.diagnostic ?? (physical.frames > accepted ? "unmappedPhysicalTail"
      : physical.frames < accepted ? "acceptedBeyondPhysicalEOF"
      : nil)
    return CaptureAudioMaterialization(role: role, payload: payload, journal: prefix,
      acceptedFrames: accepted, committedFrames: physical.frames, representedFrames: represented,
      cleanPhysicalEOF: physical.cleanEOF, diagnostic: diagnostic,
      candidate: canonical == nil ? nil : candidate, canonical: canonical,
      pcmSHA256: physical.pcm, supportSHA256: supportHash)
  }

  private static func validate(_ track: AVAssetTrack, format: JournalPCMTrack) async throws {
    guard format.rate > 0, format.rate <= 192_000, (1...8).contains(format.channels) else {
      throw invalid("Accepted PCM format is outside the native execution domain.")
    }
    let descriptions = try await track.load(.formatDescriptions)
    guard !descriptions.isEmpty else { throw invalid("Packed PCM format is absent.") }
    for description in descriptions {
      guard let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(description)?.pointee,
        asbd.mFormatID == kAudioFormatLinearPCM, asbd.mSampleRate == Double(format.rate),
        asbd.mChannelsPerFrame == format.channels, asbd.mFramesPerPacket == 1,
        asbd.mBitsPerChannel == 32, asbd.mBytesPerFrame == format.channels * 4,
        asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0,
        asbd.mFormatFlags & (kAudioFormatFlagIsBigEndian | kAudioFormatFlagIsNonInterleaved) == 0
      else { throw invalid("Packed PCM does not match the accepted fixed Float32 format.") }
    }
  }

  private struct Physical {
    let frames: Int64
    let cleanEOF: Bool
    let pcm: String
    let diagnostic: String?
  }

  /// Packed sample addresses must be proven before sample counts can stand for a prefix.
  /// Empty edits, shifted media or a packet jump terminate proof before later payload is read.
  private static func scan(input: MediaInput, track: AVAssetTrack, format: JournalPCMTrack,
    accepted: Int64) async throws -> Physical
  {
    let segments = try await track.load(.segments)
    var occupiedEnd = CMTime.zero
    var intact = true
    for segment in segments {
      let map = segment.timeMapping
      guard !segment.isEmpty, map.target.start == occupiedEnd, map.source.start == occupiedEnd,
        map.source.duration == map.target.duration, map.target.duration > .zero
      else { intact = false; break }
      occupiedEnd = CMTimeRangeGetEnd(map.target)
    }
    let exactEnd = try ExactTime(occupiedEnd)
    let maximum = try exactEnd.sample(Int(format.rate))
    guard try ExactTime(CMTime(value: maximum, timescale: format.rate)).equals(exactEnd) else {
      throw invalid("Packed PCM boundary is not an exact native sample.")
    }
    let reader = try AVAssetReader(asset: input.asset)
    let output = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
    output.alwaysCopiesSampleData = false
    guard reader.canAdd(output) else { throw invalid("Cannot inspect packed PCM.") }
    reader.add(output)
    guard reader.startReading() else { throw reader.error ?? invalid("Cannot read packed PCM.") }
    defer { reader.cancelReading() }
    var frames: Int64 = 0
    var hash = digest("screenrec.capture-pcm.v1", format: format)
    var problem: String? = intact ? nil : "interiorPhysicalMappingLoss"
    while frames < maximum {
      try Task.checkCancellation()
      let advanced = try autoreleasepool { () throws -> Bool in
        guard let sample = output.copyNextSampleBuffer() else { return false }
        let count = sample.numSamples
        let stamp = sample.presentationTimeStamp
        guard sample.isValid, CMSampleBufferDataIsReady(sample), count > 0,
          stamp.isNumeric, stamp == CMTime(value: frames, timescale: format.rate),
          let bytes = Int(exactly: Int128(count) * Int128(format.channels) * 4),
          let block = sample.dataBuffer, CMBlockBufferGetDataLength(block) == bytes
        else { problem = "interiorPhysicalPacketLoss"; return false }
        let owned = Int(min(Int64(count), maximum - frames))
        let hashed = Int(max(0, min(Int64(owned), accepted - frames)))
        var nextHash = hash
        let hashBytes = hashed * Int(format.channels) * 4
        var offset = 0
        while offset < hashBytes {
          try Task.checkCancellation()
          var data = Data(count: min(65_536, hashBytes - offset))
          let status = data.withUnsafeMutableBytes {
            CMBlockBufferCopyDataBytes(block, atOffset: offset, dataLength: $0.count, destination: $0.baseAddress!)
          }
          guard status == noErr else { problem = "unreadablePhysicalPacket"; return false }
          nextHash.update(data: data)
          offset += data.count
        }
        hash = nextHash
        frames += Int64(owned)
        return true
      }
      if !advanced { break }
    }
    // Passthrough PCM can end with documented drain/empty-media markers. They carry no
    // samples, and neither proves that the underlying media tables end at the selected edit.
    var terminal = Set<String>()
    var ended = false
    if intact && frames == maximum {
      while true {
        try Task.checkCancellation()
        guard let sample = output.copyNextSampleBuffer() else { ended = true; break }
        let drain = CMGetAttachment(sample, key: kCMSampleBufferAttachmentKey_DrainAfterDecoding,
          attachmentModeOut: nil) as? Bool == true
        let empty = CMGetAttachment(sample, key: kCMSampleBufferAttachmentKey_EmptyMedia,
          attachmentModeOut: nil) as? Bool == true
        let kind = drain ? "drain" : "empty"
        guard sample.isValid, sample.numSamples == 0, sample.dataBuffer == nil,
          sample.duration == .zero, drain != empty, terminal.insert(kind).inserted,
          drain || sample.presentationTimeStamp == occupiedEnd else { break }
      }
    }
    let last = track.makeSampleCursorAtLastSampleInDecodeOrder()
    let mediaEnd = last.map { CMTimeAdd($0.presentationTimeStamp, $0.currentSampleDuration) }
    let completeMediaExtent = mediaEnd?.isNumeric == true && mediaEnd == occupiedEnd
    let clean = intact && frames == maximum && ended && reader.status == .completed && completeMediaExtent
    if !clean, problem == nil {
      problem = completeMediaExtent ? "incompletePhysicalDecode" : "unprovenPhysicalEOF"
    }
    return Physical(frames: frames, cleanEOF: clean, pcm: hex(hash.finalize()), diagnostic: problem)
  }

  private static func verify(_ url: URL, format: JournalPCMTrack, runs: [Run], scale: Int32,
    expectedPCM: String) async throws
  {
    let input = try MediaInput(url: url)
    let tracks = try await input.asset.loadTracks(withMediaType: .audio)
    guard tracks.count == 1 else { throw invalid("Canonical output has unexpected audio tracks.") }
    let track = tracks[0]
    try await validate(track, format: format)
    let segments = SourceSegment.occupied(of: try await track.load(.segments))
    guard segments.count == runs.count else { throw invalid("Canonical occupied run count changed.") }
    let decoder = AudioSourceReader(input: input, track: track, sampleRate: Int(format.rate),
      packetFrames: 1, channels: Int(format.channels))
    var hash = digest("screenrec.capture-pcm.v1", format: format)
    for (run, segment) in zip(runs, segments) {
      try Task.checkCancellation()
      let start = try placement(run.declared, format: format, scale: scale)
      guard segment.asset.start == start,
        segment.asset.duration == CMTime(value: run.count, timescale: format.rate)
      else { throw invalid("Canonical support changed.") }
      try decoder.begin(origin: ExactTime(start), at: 0, end: run.count)
      var read: Int64 = 0
      while read < run.count {
        try Task.checkCancellation()
        guard let buffer = try autoreleasepool(invoking: { try decoder.next() }) else {
          throw invalid("Canonical PCM ended before its mapped native frame boundary.")
        }
        let bytes = Int(buffer.frameLength) * Int(format.channels) * 4
        hash.update(data: Data(bytes: buffer.floatChannelData![0], count: bytes))
        read += Int64(buffer.frameLength)
        guard read <= run.count else { throw invalid("Canonical decoder crossed an occupied run boundary.") }
      }
      guard read == run.count else { throw invalid("Canonical native run length changed.") }
    }
    guard hex(hash.finalize()) == expectedPCM else { throw invalid("Canonical PCM differs from its physical prefix.") }
  }

  private static func timescale(_ format: JournalPCMTrack) throws -> Int32 {
    func gcd(_ first: Int64, _ second: Int64) -> Int64 {
      var a = first, b = second
      while b != 0 { (a, b) = (b, a % b) }
      return a
    }
    let phaseScale = 1_000_000 / gcd(format.phaseUs, 1_000_000)
    let divisor = gcd(Int64(format.rate), phaseScale)
    guard let scale = Int32(exactly: Int64(format.rate) / divisor * phaseScale) else {
      throw invalid("Accepted sample phase cannot be represented exactly by this container timescale.")
    }
    return scale
  }
  private static func placement(_ frame: Int64, format: JournalPCMTrack, scale: Int32) throws -> CMTime {
    let value = Int128(format.phaseUs) * Int128(scale) / 1_000_000
      + Int128(frame) * Int128(scale / format.rate)
    guard let value = Int64(exactly: value) else { throw invalid("Canonical timing exceeds container capacity.") }
    return CMTime(value: value, timescale: scale)
  }
  private static func digest(_ domain: String, format: JournalPCMTrack) -> SHA256 {
    var hash = SHA256()
    hash.update(data: Data((domain + "\0").utf8))
    integer(Int64(format.rate), into: &hash)
    integer(Int64(format.channels), into: &hash)
    return hash
  }
  private static func integer(_ value: Int64, into hash: inout SHA256) {
    var little = value.littleEndian
    withUnsafeBytes(of: &little) { hash.update(bufferPointer: $0) }
  }
  private static func hex(_ digest: SHA256.Digest) -> String {
    digest.map { String(format: "%02x", $0) }.joined()
  }
  private static func identity(_ url: URL, prefix: Int64? = nil) throws -> CaptureMediaIdentity {
    let file = try FileHandle(forReadingFrom: url)
    defer { try? file.close() }
    var hash = SHA256(), bytes: Int64 = 0
    while prefix == nil || bytes < prefix! {
      try Task.checkCancellation()
      let count = Int(min(65_536, prefix.map { $0 - bytes } ?? 65_536))
      guard let data = try file.read(upToCount: count), !data.isEmpty else { break }
      bytes += Int64(data.count)
      hash.update(data: data)
    }
    guard prefix == nil || bytes == prefix else { throw invalid("Pinned input prefix is missing.") }
    return CaptureMediaIdentity(bytes: bytes, sha256: hex(hash.finalize()))
  }
  private static func invalid(_ message: String) -> CaptureFailure {
    CaptureFailure("MATERIALIZATION_FAILED", message)
  }
}
