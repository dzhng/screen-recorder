import {Catalog} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/core/dist/catalog.js';
import {AssetStore} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/core/dist/assets.js';
import {writeFile} from 'node:fs/promises';
const directory='/tmp/asset-index-public-home/library';
const catalog=new Catalog(directory+'/catalog.sqlite');const store=new AssetStore(catalog,directory);
try{const id='e83523233b5b60dbfc70334f80a4dec3f38aab52ea8451afbdb459123c06ca04';
const times=[];let cursor,count=0;const started=performance.now();
do{const t=performance.now();const page=store.segments(id,'track:1',{limit:250,...(cursor?{cursor}:{})});times.push(performance.now()-t);count+=page.segments.length;cursor=page.nextCursor;}while(cursor);
const sorted=[...times].sort((a,b)=>a-b);
const report={count,pages:times.length,totalSeconds:(performance.now()-started)/1000,p95Milliseconds:sorted[Math.ceil(.95*times.length)-1],maximumMilliseconds:sorted.at(-1),maxRSSKiB:process.resourceUsage().maxRSS,times,queryPlan:catalog.catalog.prepare('EXPLAIN QUERY PLAN SELECT ordinal,value FROM asset_segments WHERE assetId=? AND streamId=? AND ordinal>? ORDER BY ordinal LIMIT ?').all(id,'track:1',-1,251),headerBytes:catalog.catalog.prepare('SELECT length(metadata) AS bytes FROM assets WHERE id=?').get(id),scope:'Actual AssetStore250-row complete traversal, real public-admitted asset, no complete metadata reconstruction or native work'};
await writeFile('/tmp/asset-index-large-work.json',JSON.stringify(report,null,2));console.log({...report,times:undefined});}finally{catalog.close();}
