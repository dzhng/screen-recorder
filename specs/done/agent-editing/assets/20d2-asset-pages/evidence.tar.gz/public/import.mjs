import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,root} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const report={trace:[],passed:false};
const service=new JourneyService('/tmp/asset-index-public-home',report,'/tmp/asset-index-public-import.reads.jsonl',new URL(`file://${root}/packages/test-harness/editing/capture-evidence-service.mjs`));
try{
 await service.start();
 report.submitted=await service.call('acquisition.import',{requestId:'probe-rows-fresh-attempt',path:'/tmp/probe-consumer-red/source'});
 const started=performance.now();
 while(performance.now()-started<180000){
 const job=await service.call('job.get',{jobId:report.submitted.jobId},{transport:'mcp'});
 if(['ready','failed','canceled'].includes(job.state)){report.terminal=job;break;}
 await delay(500);
 }
 report.seconds=(performance.now()-started)/1000;
 assert.equal(report.terminal.state,'ready');

 report.passed=true;
}finally{await service.stop();await writeFile('/tmp/asset-index-public-import.json',JSON.stringify(report,null,2));}
