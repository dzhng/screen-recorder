import { createRequire, registerHooks } from 'node:module';
import { readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const test = process.argv[2];
const paths = new Set();
registerHooks({ load(url, context, next) {
  if (url.startsWith('file:')) paths.add(realpathSync(fileURLToPath(url)));
  return next(url, context);
}});
const authority = createRequire(test).resolve('@screenrec/core/library');
await import(authority);
const modules = [...paths].sort().map(path => {
  const bytes = readFileSync(path);
  return { path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
});
writeFileSync(process.argv[3], JSON.stringify({ consumer: test, resolvedLibrary: authority, realpathLibrary: realpathSync(authority), nodeVersion: process.version, modules }, null, 2) + '\n');
console.log(`Pinned ${modules.length} actual read-only import modules at ${realpathSync(authority)}`);
