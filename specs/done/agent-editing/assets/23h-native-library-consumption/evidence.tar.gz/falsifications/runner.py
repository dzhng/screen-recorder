"""Bounded reproduction recipe; requires an explicitly selected owned worktree.

Historical runs and their exact restored source hashes are in the adjacent manifests.
This recipe uses the selected worktree's settled test/source. It runs no app, media or model.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

work = Path(sys.argv[1]).resolve()
source = work / "apps/macos/Sources/ScreenRecorder/LibraryController.swift"
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=False)
mutations = [
    ("revision-action", "$0.recordingId == id && $0.currentRevisionId != nil", "$0.recordingId == id"),
    ("deletion-identity", "guard receipt.target == target && receipt.deleted else {", "guard receipt.deleted else {"),
    ("service-read-fence", "guard service == serviceGeneration && generation == recordingGeneration else { return }", "// Negative control: obsolete catalog answer admitted."),
    ("processing-owner", "        if state.processing?.recordingId != take.recordingId { state.processing = nil }", "        // Negative control: retain the previous owner's processing."),
    ("read-owner", "        recordingGeneration = UUID()\n", "        // Negative control: old job read keeps its authority.\n"),
]
results = []
for name, old, new in mutations:
    original = source.read_bytes()
    before = hashlib.sha256(original).hexdigest()
    assert old in original.decode()
    try:
        source.write_text(original.decode().replace(old, new, 1))
        with (output / (name + ".log")).open("wb") as log:
            result = subprocess.run(
                ["node", "--test", "apps/macos/tests/library-controls.test.mjs"],
                cwd=work, stdout=log, stderr=subprocess.STDOUT, timeout=90,
            )
        results.append({"mutation": name, "exitCode": result.returncode, "originalSha256": before})
    finally:
        source.write_bytes(original)
        assert hashlib.sha256(source.read_bytes()).hexdigest() == before
        if results and results[-1]["mutation"] == name:
            results[-1]["restoredSha256"] = before
    assert results[-1]["exitCode"] != 0, name + " did not falsify its assertion"
(output / "manifest.json").write_text(json.dumps(results, indent=2) + "\n")
