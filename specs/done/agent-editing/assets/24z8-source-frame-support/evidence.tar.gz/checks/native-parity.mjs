import { jsonWorker } from '/Users/david/dev/screen-recorder/apps/service/dist/worker.js';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const home='/tmp/screenrec-24z8-frame-support';
const executable='/tmp/screenrec-09c-native-presented-worker';
const path='/Users/david/dev/screen-recorder/specs/agent-editing/assets/10d-public-scenes/authored-source.mov';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const workerSHA=hash(await readFile(executable));
if(workerSHA!=='0a9cd72a62af990a2bccef585184df0a2bbc36220a2fc258e0198ee43d726928')throw Error('worker mismatch');
const render=jsonWorker({executable});
const available=[{startUs:0,endUs:100000},{startUs:200000,endUs:450000}];
const results=[];
for(const [name,support] of [['full',available],['demanded',[available[1]]]]){
 const request={asset:{assetId:'authored',streamId:'track:1',path,originUs:0},available:support,atUs:350000,maxLongEdge:64,output:`${home}/${name}.png`};
 const result=await render('media.sourceFrame',request);
 await writeFile(`${home}/${name}-request.json`,JSON.stringify(request,null,2)+'\n');
 await writeFile(`${home}/${name}-response.json`,JSON.stringify(result,null,2)+'\n');
 if(!result.ok)throw Error(JSON.stringify(result));
 const {file,...receipt}=result.data;
 results.push({name,receipt,sha256:hash(await readFile(file))});
}
if(JSON.stringify(results[0].receipt)!==JSON.stringify(results[1].receipt)||results[0].sha256!==results[1].sha256)throw Error('mismatch');
await writeFile(`${home}/native-parity.json`,JSON.stringify({workerSHA,inputSHA256:hash(await readFile(path)),calls:2,allReceiptsEqualApartFromOutputPath:true,allPNGBytesEqual:true,results},null,2)+'\n');
console.log(JSON.stringify({calls:2,workerSHA,sha256:results[0].sha256,receipt:results[0].receipt}));
