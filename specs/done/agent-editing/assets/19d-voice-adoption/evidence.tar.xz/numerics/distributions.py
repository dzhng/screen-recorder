import hashlib,inspect,itertools,json,sys
from pathlib import Path
import mlx.core as mx
from mlx_audio.tts.models.qwen3_tts.qwen3_tts import Model
model=Path('/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519');config=json.loads((model/'config.json').read_text())['talker_config'];eos=config['codec_eos_token_id'];ceiling=3.3895313892515355e38;rows=[]
for vocabulary,history_name,history in [(3072,'low64',list(range(64))),(3072,'high64',list(range(1984,2048))),(2048,'residual-none',None)]:
 for temperature,top_k,top_p in itertools.product([0,1e-6,1e6],[0,1,3072],[5e-324,1]):
  row={'vocabulary':vocabulary,'history':history_name,'historyCount':len(history or []),'temperature':temperature,'top_k':top_k,'top_p':top_p,'repetition_penalty':ceiling if history else 1.05}
  def trace(frame,event,arg):
   if frame.f_code is not Model._sample_token.__code__:return None
   if event=='return':
    logits=frame.f_locals['logits'];p=mx.softmax(logits.astype(mx.float32),axis=-1);mx.eval(logits,p)
    row.update(nan=bool(mx.any(mx.isnan(logits)).item()),positiveInfinity=bool(mx.any(logits==mx.inf).item()),finiteCandidates=int(mx.sum(mx.isfinite(logits)).item()),maskedCandidates=int(mx.sum(logits==-mx.inf).item()),probabilitiesFinite=bool(mx.all(mx.isfinite(p)).item()),probabilitySum=float(mx.sum(p).item()),positiveProbabilities=int(mx.sum(p>0).item()))
   return trace
  mx.random.seed(18);sys.settrace(trace)
  try:
   token=Model._sample_token(None,mx.linspace(-20,20,vocabulary).astype(mx.bfloat16)[None,None,:],temperature=temperature,top_k=top_k,top_p=top_p,repetition_penalty=row['repetition_penalty'],generated_tokens=history,suppress_tokens=([i for i in range(vocabulary-1024,vocabulary) if i!=eos] if history else None));mx.eval(token);row['token']=token.tolist()
  finally:sys.settrace(None)
  assert not row['nan'] and not row['positiveInfinity'] and row['finiteCandidates']>0 and row['probabilitiesFinite'] and row['positiveProbabilities']>0 and abs(row['probabilitySum']-1)<1e-5,row
  rows.append(row)
print(json.dumps({'scope':'Synthetic bfloat16 logits across declared numerical/filter extremes; diagnostic softmax uses float32 over actual post-transform logits; no quality guarantee','sourceSha256':hashlib.sha256(Path(inspect.getfile(Model)).read_bytes()).hexdigest(),'cases':len(rows),'rows':rows},indent=2))
