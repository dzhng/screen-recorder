import importlib.util, unittest
path='/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/helpers/voice/test_worker.py'
spec=importlib.util.spec_from_file_location('adapter_tests',path); tests=importlib.util.module_from_spec(spec); spec.loader.exec_module(tests)
original=tests.worker.require
def missing_budget_guard(condition,code,message):
    if code=='LIMIT_EXCEEDED':return
    return original(condition,code,message)
tests.worker.require=missing_budget_guard
suite=unittest.TestSuite([tests.AdapterTests('test_refusal_prevents_consumer_work_and_always_restores_encode')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
