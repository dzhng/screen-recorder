import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdir, readFile, writeFile, readdir, stat, rename, rm } from "node:fs/promises";
import { resolve, join } from "node:path";
import { parseArgs } from "node:util";
import { setTimeout as delay } from "node:timers/promises";
import { Models } from "/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/models.js";
import { voiceRenderer } from "/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/voice.js";
import { mediaWorker } from "/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/worker.js";
const { values } = parseArgs({
  options: Object.fromEntries(
    ["out", "model-home", "native", "case"].map((x) => [x, { type: "string" }]),
  ),
});
for (const key of ["out", "model-home", "native"]) assert(values[key], `Missing --${key}`);
assert(!values.case || values.case === "reference-lifetime", "Unknown focused case");
const out = resolve(values.out);
await mkdir(out, { mode: 0o700 });
const workspace = join(out, "workspace");
const root = "/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/";
const frozen = join(root, "specs/agent-editing/assets/18-voice");
const cases = JSON.parse(
  await readFile(join(root, "packages/test-harness/editing/voice/cases.json")),
);
const models = new Models(resolve(values["model-home"]));
const preparation = await models.voice("qwen3-tts-icl-v1");
const native = mediaWorker({ SCREENREC_NATIVE: resolve(values.native) });
const run = voiceRenderer(native, models, "qwen3-tts-icl-v1", workspace);
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const request = (name) => ({
  reference: join(frozen, "reference.wav"),
  referenceText: cases.reference.text,
  text: cases.replacements[0].text,
  generation: cases.generation,
  seed: String(cases.seed),
  output: join(out, `${name}.wav`),
});
const report = {
  passed: false,
  checks: [],
  scope: "Registered entry parity; no public job, managed-origin or listening acceptance",
  case: values.case ?? "all",
  preparation,
};
async function empty() {
  assert.deepEqual(await readdir(workspace), []);
}
async function refusal(label, execute, code) {
  let error;
  try {
    await execute();
  } catch (e) {
    error = e;
  }
  assert.equal(error?.code, code, `${label}: ${error}`);
  await empty();
  report.checks.push({ label, code });
}
const previousPythonPath = process.env.PYTHONPATH;
const shadow = join(out, "shadow");
await mkdir(shadow);
await writeFile(
  join(shadow, "mlx_audio.py"),
  'raise RuntimeError("unprepared ambient module was imported")\n',
);
process.env.PYTHONPATH = shadow;
try {
  if (values.case !== "reference-lifetime") {
    for (const replacement of cases.replacements) {
      const q = { ...request(replacement.id), text: replacement.text };
      const result = await run(q, new AbortController().signal);
      const actual = await readFile(q.output),
        expected = await readFile(join(frozen, `same-take-${replacement.id}.wav`));
      assert.deepEqual(actual, expected);
      await empty();
      report.checks.push({
        label: replacement.id,
        exactWAVAndPCM: true,
        ignoresAmbientPythonPath: true,
        sha256: digest(actual),
        receipt: result,
      });
    }
    // Identical intelligible audio at budgets11/12 has different completion truth.
    for (const budget of [1, 11]) {
      const q = {
        ...request(`cap-${budget}`),
        generation: { ...cases.generation, max_tokens: budget },
      };
      await refusal(
        `token budget ${budget}`,
        () => run(q, new AbortController().signal),
        "VOICE_INCOMPLETE",
      );
      await assert.rejects(stat(q.output), { code: "ENOENT" });
    }
    const boundary = {
      ...request("eos-boundary"),
      generation: { ...cases.generation, max_tokens: 12 },
    };
    const boundaryReceipt = await run(boundary, new AbortController().signal);
    assert.equal(boundaryReceipt.stopReason, "eos");
    assert.equal(boundaryReceipt.generatedTokens, 11);
    assert.deepEqual(
      await readFile(boundary.output),
      await readFile(join(frozen, "same-take-word.wav")),
    );
    report.checks.push({
      label: "EOS at final permitted iteration",
      receipt: boundaryReceipt,
      exactWAVAndPCM: true,
    });
    for (const generation of [{ top_p: 2 ** -9 }, { repetition_penalty: 1e308 }, { speed: 1 }])
      await refusal(
        "unsupported numeric or ignored control",
        () => run({ ...request("invalid-control"), generation }, new AbortController().signal),
        "INVALID_REQUEST",
      );
    const overText = {
      ...request("over-text"),
      text: "This sentence exceeds the measured input budget. ".repeat(200),
    };
    await refusal(
      "actual target token budget",
      () => run(overText, new AbortController().signal),
      "LIMIT_EXCEEDED",
    );
    await assert.rejects(stat(overText.output), { code: "ENOENT" });
    const replay = [];
    for (const id of ["changed-seed", "changed-seed-replay"]) {
      const q = {
        ...request(id),
        text: "Okay, so this is the recorder workbench.",
        seed: "19",
        generation: { repetition_penalty: 1.5 },
      };
      const receipt = await run(q, new AbortController().signal);
      replay.push(await readFile(q.output));
      report.checks.push({ label: id, receipt, sha256: digest(replay.at(-1)) });
    }
    assert.deepEqual(replay[0], replay[1]);
    await refusal(
      "preexisting destination",
      () => run(request("word"), new AbortController().signal),
      "INVALID_REQUEST",
    );
    const same = { ...request("collision"), output: join(frozen, "reference.wav") };
    const before = digest(await readFile(same.output));
    await refusal(
      "input/output collision",
      () => run(same, new AbortController().signal),
      "INVALID_REQUEST",
    );
    assert.equal(digest(await readFile(same.output)), before);
    for (const [label, path, bytes] of [
      ["missing runtime", preparation.python, null],
      ["wrong runtime", preparation.python, Buffer.from("wrong executable")],
      ["missing model", join(preparation.model, ".gitattributes"), null],
      [
        "mismatched model bytes",
        join(preparation.model, ".gitattributes"),
        Buffer.from("changed bytes"),
      ],
    ]) {
      const backup = join(out, `${label.replaceAll(" ", "-")}-backup`);
      await rename(path, backup);
      try {
        if (bytes) await writeFile(path, bytes);
        await refusal(
          label,
          () => run(request(label.replaceAll(" ", "-")), new AbortController().signal),
          "MODEL_NOT_PREPARED",
        );
      } finally {
        await rm(path, { force: true });
        await rename(backup, path);
      }
    }
  }
  await mkdir(workspace, { recursive: true, mode: 0o700 });
  const originalVoice = models.voice.bind(models);
  report.phases=[];
  models.voice = async (...args) => { const at=performance.now(); report.phases.push({phase:"verification-start",at}); try{return await originalVoice(...args);} finally {report.phases.push({phase:"verification-end",at:performance.now(),elapsedMs:performance.now()-at});} };
  for (const mode of ["cancel"]) {
    const controller = new AbortController();
    const pending = run(
      request(mode),
      controller.signal,
      mode === "deadline" ? 10000 : 600000,
    ).then(
      () => ({ unexpected: true }),
      (error) => ({ error }),
    );
    try {
      let pid;
      const end = Date.now() + 8000;
      while (Date.now() < end) {
        const dirs = await readdir(workspace);
        if (
          dirs.length &&
          (await stat(join(workspace, dirs[0], "audio.wav")).then(
            () => true,
            () => false,
          ))
        ) {
          const rows = execFileSync("ps", ["-axo", "pid=,ppid=,command="], {
            encoding: "utf8",
          }).split("\n");
          const row = rows.find(
            (s) =>
              s.includes(preparation.entry) && Number(s.trim().split(/\s+/)[1]) === process.pid,
          );
          if (row) {
            pid = Number(row.trim().split(/\s+/)[0]);
            break;
          }
        }
        await delay(10);
      }
      const observed = [];
      for(const directory of await readdir(workspace)) {
        const entries = [];
        for(const file of await readdir(join(workspace,directory))) entries.push({file,bytes:(await stat(join(workspace,directory,file))).size});
        observed.push({directory,entries});
      }
      const processRows = execFileSync("ps", ["-axo","pid=,ppid=,etime=,command="], {encoding:"utf8"}).split("\n").filter(row=>row.includes(preparation.entry));
      report.phases.push({phase:"observation-deadline",at:performance.now(),pid:pid??null,observed,processRows});
      assert(pid, `${mode}: worker did not reach partial output`);
      process.kill(pid, "SIGSTOP");
      if (mode === "cancel") controller.abort();
      const result = await pending;
      assert.equal(result.error?.code, mode === "cancel" ? "CANCELED" : "MEDIA_WORKER_TIMEOUT");
      assert.throws(() => process.kill(pid, 0), { code: "ESRCH" });
      await empty();
      report.checks.push({
        label: mode,
        pid,
        partialOutput: true,
        closedBeforeReturn: true,
        code: result.error.code,
      });
    } finally {
      const abortAt=performance.now(); report.phases.push({phase:"abort-requested",at:abortAt});
      controller.abort();
      const ended=await pending;
      report.phases.push({phase:"returned-after-abort",at:performance.now(),drainMs:performance.now()-abortAt,error:ended.error?.code, message:ended.error?.message, details:ended.error?.details, remainingWorkspace:await readdir(workspace)});
    }
  }
  report.passed = true;
} catch (error) {
  report.failure = { message: error.message, stack: error.stack };
  throw error;
} finally {
  if (previousPythonPath === undefined) delete process.env.PYTHONPATH;
  else process.env.PYTHONPATH = previousPythonPath;
  await writeFile(join(out, "report.json"), JSON.stringify(report, null, 2) + "\n");
}
