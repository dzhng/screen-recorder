import { Models } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/src/models.ts';
console.log(JSON.stringify(new Models('/tmp/screenrec-19d-bundle-discovery-library').list()));
