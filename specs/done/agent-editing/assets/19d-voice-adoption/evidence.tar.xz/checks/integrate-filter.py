from pathlib import Path
import ctypes,os,json,hashlib,difflib,shutil,re
root=Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder');old=Path('/private/tmp/screenrec-19d-profile-bundle');new=Path('/private/tmp/screenrec-19d-repaired-bundle');new.mkdir(mode=0o700)
entries=json.loads((root/'packages/core/src/model-data/voice-runtime.json').read_text()); clone=ctypes.CDLL(None,use_errno=True).clonefile;clone.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];clone.restype=ctypes.c_int
assert shutil.disk_usage(new).free>512*1024**2
for e in entries:
 p=new/e['path']; source=old/e['path']
 if e['kind']=='directory':p.mkdir(mode=e['mode'])
 elif e['kind']=='symlink':p.symlink_to(e['target'])
 else:
  if clone(os.fsencode(source),os.fsencode(p),0):raise OSError(ctypes.get_errno(),'clonefile failed')
  assert p.stat().st_ino!=source.stat().st_ino
relative='mlx_audio/tts/models/qwen3_tts/qwen3_tts.py'; target=new/'python/lib/python3.12/site-packages'/relative
original=target.read_text();assert hashlib.sha256(original.encode()).hexdigest()=='0d9437e4f08680d7bf8cb7bf3b44c8e3de37ad9edf025f50dba37dface2e6902'
candidate=(root/'specs/agent-editing/assets/19d1-probability-filter/candidate.py').read_text();body=candidate[candidate.index('    if not'):].rstrip()+'\n'
start=original.index('    if not',original.index('def _apply_probability_filters('));end=original.index('\n\ndef mel_spectrogram',start);patched=original[:start]+body+original[end:];target.write_text(patched)
patch=''.join(difflib.unified_diff(original.splitlines(True),patched.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
(root/'helpers/voice/probability-filter.patch').write_text(patch)
pinsPath=root/'helpers/voice/pins.json';pins=json.loads(pinsPath.read_text());pins['runtimeFiles'][relative]=hashlib.sha256(patched.encode()).hexdigest();pinsPath.write_text(json.dumps(pins,indent=2)+'\n')
profilePath=root/'packages/core/src/model-data/voice-profile-v1.json';profile=json.loads(profilePath.read_text());profile['topPMinimum']=5e-324;profile['filterSemantics']['topP']='One disables nucleus sampling. If filtering would erase all valid candidates, the registered runtime preserves the first maximum-logit candidate; already-valid filtered results are unchanged.';profilePath.write_text(json.dumps(profile,indent=2)+'\n')
for source,relative in [('helpers/voice/worker.py','voice/worker.py'),('helpers/voice/pins.json','voice/pins.json'),('packages/core/src/model-data/voice-profile-v1.json','voice/profile.json')]:shutil.copyfile(root/source,new/relative)
for entry in entries:
 if entry['kind']=='file':
  if entry['path'] in ['voice/worker.py','voice/pins.json','voice/profile.json','python/lib/python3.12/site-packages/mlx_audio/tts/models/qwen3_tts/qwen3_tts.py']:
   b=(new/entry['path']).read_bytes();entry.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
raw=json.dumps(entries,separators=(',',':'));(root/'packages/core/src/model-data/voice-runtime.json').write_text(raw+'\n');digest=hashlib.sha256(raw.encode()).hexdigest();p=root/'packages/core/src/model-registry.ts';p.write_text(re.sub(r'(runtimeArtifact: \{\s*digest: ")[a-f0-9]+',r'\g<1>'+digest,p.read_text()))
print(json.dumps({'runtimeDigest':digest,'patchedSourceSha256':hashlib.sha256(patched.encode()).hexdigest(),'patchSha256':hashlib.sha256(patch.encode()).hexdigest(),'profileSha256':hashlib.sha256(profilePath.read_bytes()).hexdigest()},indent=2))
