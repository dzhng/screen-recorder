from pathlib import Path
import json,hashlib,shutil,re
root=Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder');bundle=Path('/private/tmp/screenrec-19d-repaired-bundle'); inv=root/'packages/core/src/model-data/voice-runtime.json'; rows=json.loads(inv.read_text())
for source,rel in [('helpers/voice/worker.py','voice/worker.py'),('helpers/voice/pins.json','voice/pins.json'),('packages/core/src/model-data/voice-profile-v1.json','voice/profile.json')]:
 shutil.copyfile(root/source,bundle/rel); b=(bundle/rel).read_bytes(); e=next(e for e in rows if e['path']==rel);e.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
raw=json.dumps(rows,separators=(',',':'));inv.write_text(raw+'\n');digest=hashlib.sha256(raw.encode()).hexdigest();p=root/'packages/core/src/model-registry.ts';p.write_text(re.sub(r'(runtimeArtifact: \{\s*digest: ")[a-f0-9]+',r'\g<1>'+digest,p.read_text()));print(digest)
