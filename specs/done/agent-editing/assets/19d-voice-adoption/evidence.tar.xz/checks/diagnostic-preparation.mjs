import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { JourneyService } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/screenrec-19d-diagnostic-preparation';
await mkdir(out,{mode:0o700});
const report={passed:false,scope:'Diagnostic preparation completion with600s horizon and aggregate filesystem observer; original180s deadline remains red',progress:[],checks:[],trace:[]};
process.env.SCREENREC_NATIVE='/Users/david/dev/screen-recorder/helpers/mac/.build/debug/screenrec-native';
const service=new JourneyService(`${out}/home`,report);const start=performance.now();
try {
 await service.start();
 const params={modelId:'qwen3-tts-icl-v1',runtimeSource:'/private/tmp/screenrec-19d-profile-bundle',modelSource:'/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519'};
 report.discovery=await service.call('model.list',{});
 await service.call('model.prepare',params);
 for(;;){
  const state=await service.call('model.status',{modelId:params.modelId});
  report.progress.push({elapsedMs:performance.now()-start,...state});
  if(state.state==='ready')break;
  assert.equal(state.state,'preparing'); assert.ok(performance.now()-start<600000,'600s diagnostic horizon exceeded');
  await delay(1000);
 }
 report.passed=true;
} finally {report.elapsedMs=performance.now()-start;await service.stop();await writeFile(`${out}/report.json`,JSON.stringify(report,null,2)+'\n');}
