import assert from "node:assert/strict";
import { constants } from "node:fs";
import { copyFile, mkdir, open, readFile, rm, writeFile } from "node:fs/promises";
import { mediaWorker } from "/private/tmp/screenrec-camera-proof-admission/apps/service/dist/worker.js";
const original = "/private/tmp/screenrec-20e2-final-recovery/take";
const output = "/private/tmp/screenrec-21d-retained-boundary";
const directory = `${output}/source`;
await mkdir(directory, {recursive:true});
for (const name of ["capture.journal.jsonl", "camera.publication.json"])
  await copyFile(`${original}/camera/${name}`, `${directory}/${name}`);
await copyFile(`${original}/timestamps.jsonl`, `${directory}/camera.mapping.jsonl`);
// macOS cp -c prepared the private APFS clone; Node forced-clone is unsupported here.
const fd = await open(`${original}/camera/video.mov`, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
const worker = mediaWorker();
const request = {directory, output:`${output}/evidence.jsonl`, canonical:{video:"/dev/fd/3"}};
await writeFile(`${output}/request.json`, JSON.stringify(request,null,2));
try {
  const result = await worker("media.sourceEvidence", request, {descriptors:[fd.fd],timeoutMs:180000});
  await writeFile(`${output}/response.json`, JSON.stringify(result,null,2));
  assert.equal(result.ok,true,JSON.stringify(result));
  assert.equal(result.data.header.source.kind,"probe-camera");
  assert.equal(result.data.header.sessionID,"BBED6493-8AA8-41C1-94CD-34B39C6B94F2");
  assert.equal(result.data.header.cameraBinding,undefined);
  assert.equal(result.data.publications.video.representedFrames,4428);
  assert.equal(result.data.publications.video.canonical.sha256,"974663bf829190327e83ebef37318c0f45a36e97448d7093506379f305e3fd12");
  await rm(`${directory}/camera.raw.mov`);
  const refused = await worker("media.sourceEvidence", {...request,output:`${output}/unsupported.jsonl`}, {descriptors:[fd.fd],timeoutMs:180000});
  await writeFile(`${output}/raw-less-refusal.json`, JSON.stringify(refused,null,2));
  assert.equal(refused.ok,false);
  assert.equal(refused.error.code,"INVALID_CAMERA_MAPPING");
  assert.match(refused.error.message,/original raw timescale authority/);
  console.log("PASS retained original canonical/picture/PTS verification; unbound historical identity preserved; raw-less proof scope refused");
} finally { await fd.close(); }
