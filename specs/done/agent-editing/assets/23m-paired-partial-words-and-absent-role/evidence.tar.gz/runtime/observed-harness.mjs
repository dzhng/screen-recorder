import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { once } from "node:events";
import { constants, appendFileSync, readFileSync } from "node:fs";
import { chmod, copyFile, cp, mkdir, readFile, readdir, realpath, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { DatabaseSync } from "node:sqlite";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const script = fileURLToPath(import.meta.url);
const root = resolve(dirname(script), "../../..");
const duration = 134025574;
const origin = 48675;
const cut = { startUs: 1800000, endUs: 1850000 };
const recordingId = "862bfdeb-4074-4fa0-b003-57e5a9e2f975";
const narration = "2bf4af51122816d6e4c4a6731ddd1a73375be3ed61d82d8cd66bec824638962c";
const video = "ade26eacf8dce118e4fe16dcf261e7d3445d115e2b92721f0a01b8a4511de17a";
const nativeAllowed = new Set([
  "storage.clearRenderWorkspace",
  "packageWorkspace.recover",
  "media.audioCapabilities",
  "media.probe",
  "media.sourceEvidence",
]);

if (process.argv[2] === "--native-gate") {
  const request = JSON.parse(readFileSync(0));
  const log = (value) => appendFileSync(process.env.SCREENREC_WORD_NATIVE_LOG, JSON.stringify(value) + "\n");
  log({ event: "request", request });
  if (request.operation === "speech.transcribe") {
    const fixture = JSON.parse(readFileSync(process.env.SCREENREC_WORD_REPLAY));
    const { track, models, output } = request.params;
    assert.equal(hash(readFileSync(track.source)), narration);
    assert.deepEqual({ ...track, source: null }, fixture.track);
    assert.deepEqual(models.files, fixture.model.files);
    assert.equal(await realpath(models.directory), await realpath(fixture.model.directory));
    const raw = readFileSync(fixture.rawFile);
    assert.equal(hash(raw), fixture.rawSha256);
    assert(output.startsWith(fixture.outputRoot + "/"), "Frozen output escaped owned transcript storage");
    await writeFile(output, raw);
    const response = {
      id: request.id,
      ok: true,
      data: { ...fixture.receipt, output: { file: output, bytes: raw.length, sha256: hash(raw) } },
    };
    log({ event: "frozen-reply", response, forwarded: false, authority: "Reconstructed fixture receipt; immutable raw/segment bytes and retained public engine metadata" });
    process.stdout.write(JSON.stringify(response) + "\n");
  } else if (!nativeAllowed.has(request.operation)) {
    log({ event: "refused", operation: request.operation });
    process.stdout.write(JSON.stringify({ id: request.id, ok: false, error: {
      code: "UNREQUESTED_NATIVE_OPERATION", message: request.operation, retryable: false, details: {},
    } }) + "\n");
  } else {
    const count = Number(process.env.SCREENREC_WORD_DESCRIPTOR_COUNT);
    assert(Number.isInteger(count) && count >= 0 && count <= 32);
    const child = spawn(process.env.SCREENREC_WORD_WORKER, [], {
      cwd: "/", stdio: ["pipe", "pipe", "pipe", ...Array.from({ length: count }, (_, i) => i + 3)],
    });
    let stdout = "", stderr = "";
    child.stdout.on("data", (bytes) => { stdout += bytes; });
    child.stderr.on("data", (bytes) => { stderr += bytes; });
    child.stdin.end(JSON.stringify(request) + "\n");
    const [code, signal] = await once(child, "close");
    log({ event: "forwarded-close", pid: child.pid, operation: request.operation, descriptors: count, code, signal, stdout, stderr });
    assert.equal(code, 0, stderr);
    process.stdout.write(stdout);
  }
  process.exit(0);
}

const { values } = parseArgs({ options: {
  out: { type: "string" }, "old-home": { type: "string" }, "old-catalog": { type: "string" },
  "project-home": { type: "string" }, "source-bundle": { type: "string" },
  "legacy-app": { type: "string" }, "saved-report": { type: "string" },
  "raw-file": { type: "string" }, "readiness-report": { type: "string" },
  "legacy-worker": { type: "string" }, mutant: { type: "boolean", default: false },
} });
for (const name of ["out", "old-home", "old-catalog", "project-home", "source-bundle", "legacy-app", "saved-report", "raw-file", "readiness-report", "legacy-worker"])
  assert(values[name], `Name --${name} explicitly`);
assert(process.env.SCREENREC_NATIVE, "Name the unchanged current worker");
const out = resolve(values.out);
await mkdir(out, { mode: 0o700 });
const save = (name, value) => writeFile(join(out, name), JSON.stringify(value, null, 2) + "\n");
const pin = async (path) => {
  const bytes = await readFile(path);
  return { path: await realpath(path), bytes: bytes.length, sha256: hash(bytes) };
};
const report = {
  passed: false, scope: "Paired public partial words and not_requested role; frozen ASR, no inference/quality/media verdict",
  fixtureReceipt: "Reconstructed from immutable 23a raw segment values and retained public engine metadata; not original native RPC bytes",
  inputs: {}, exchanges: [], processes: [], checks: [], model: {}, pages: {}, comparisons: {},
};
const saved = JSON.parse(await readFile(values["saved-report"], "utf8"));
const readiness = JSON.parse(await readFile(values["readiness-report"], "utf8"));
report.inputs.readiness = await pin(values["readiness-report"]);
assert.equal(report.inputs.readiness.sha256, "6e1684fb5d4bb076bbc6d417b28d533d9a91ded7d443c6f3617d3a19b6a4de47");
assert.equal(readiness.passed, true);
report.inputs.saved = await pin(values["saved-report"]);
assert.equal(report.inputs.saved.sha256, "caf571d7f4d2ad8048fcb1084e5adb330c68f94b1d240faefadf0034a4335122");
report.inputs.raw = await pin(values["raw-file"]);
assert.equal(report.inputs.raw.sha256, "45a5ceb1c79225e3e35651dfb38de498df7843cdea222913fd113c2c82a6b885");
const raw = (await readFile(values["raw-file"], "utf8")).trim().split("\n").map(JSON.parse);
const rawWords = raw.flatMap((line) => line.words);
assert.equal(rawWords.length, 306);
assert.equal(raw.flatMap((line) => line.result.tokenTimings).length, 629);
assert.equal(raw.reduce((n, line) => n + line.samples, 0), 2143573);
const oldHome = join(out, "recording-home"), newHome = join(out, "project-home");
await mkdir(oldHome, { mode: 0o700 });
await mkdir(join(newHome, "library/assets"), { recursive: true, mode: 0o700 });
report.inputs.oldCatalog = await pin(values["old-catalog"]);
assert.equal(report.inputs.oldCatalog.sha256, "7f882c348f248e79ad4efaa609f3e36092a037876ef566ac7b36927dd18715eb");
await copyFile(values["old-catalog"], join(oldHome, "library.sqlite"));
await mkdir(join(oldHome, "recordings"));
await cp(join(values["old-home"], "recordings", recordingId), join(oldHome, "recordings", recordingId), { recursive: true, force: false });
report.inputs.projectCatalog = await pin(join(values["project-home"], "library/catalog.sqlite"));
assert.equal(report.inputs.projectCatalog.sha256, "ba8be18f32048ab4ed94917a1df719716f51547d17c4d133e4e9fd7df16f9a9f");
await copyFile(report.inputs.projectCatalog.path, join(newHome, "library/catalog.sqlite"));
for (const name of await readdir(join(values["project-home"], "library/assets")))
  await copyFile(join(values["project-home"], "library/assets", name), join(newHome, "library/assets", name), constants.COPYFILE_FICLONE);
for (const [path, format] of [[join(oldHome, "library.sqlite"), 1], [join(newHome, "library/catalog.sqlite"), 22]]) {
  const db = new DatabaseSync(path, { readOnly: true });
  assert.equal(db.prepare("PRAGMA user_version").get().user_version, format);
  assert.deepEqual(db.prepare("PRAGMA foreign_key_check").all(), []);
  db.close();
}
report.inputs.sources = [];
for (const [name, digest] of [["video.mov", video], ["narration.mov", narration], ["capture.journal.jsonl", "d44ff9028b14c533b78db6bf944b63cfc46e84b5f8d8e92299a36d4e1d986698"]]) {
  const source = join(root, "fixtures/narrated-workbench", name);
  const original = await pin(source), copied = await pin(join(oldHome, "recordings", recordingId, "source", name));
  assert.equal(original.sha256, digest); assert.equal(copied.sha256, digest);
  report.inputs.sources.push({ original, copied });
}
const sourceBundle = await realpath(values["source-bundle"]);
const legacyApp = await realpath(values["legacy-app"]);
const currentWorker = await realpath(process.env.SCREENREC_NATIVE);
const legacyWorker = await realpath(values["legacy-worker"]);
report.inputs.currentWorker = await pin(currentWorker);
report.inputs.legacyWorker = await pin(legacyWorker);
assert.equal(report.inputs.currentWorker.sha256, "0a9cd72a62af990a2bccef585184df0a2bbc36220a2fc258e0198ee43d726928");
assert.equal(report.inputs.legacyWorker.sha256, "c3402dd667a46da62da7603102ce6f9bbdbebe04442bcaf6e7fe45157e18ff4b");
report.inputs.node = { ...await pin(process.execPath), version: process.version };
const observer = join(out, "process-observer.mjs");
await writeFile(observer, `import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {appendFileSync} from 'node:fs';
const log=v=>appendFileSync(process.env.SCREENREC_WORD_PROCESS_LOG,JSON.stringify(v)+'\\n');
const spawn=childProcess.spawn;
childProcess.spawn=function(command,args,options={}) {
  const count=Array.isArray(options.stdio)?Math.max(0,options.stdio.length-3):0;
  if(command===process.env.SCREENREC_NATIVE) options={...options,env:{...(options.env??process.env),SCREENREC_WORD_DESCRIPTOR_COUNT:String(count)}};
  const child=spawn.call(this,command,args,options);
  log({event:'spawn',parentPid:process.pid,pid:child.pid,command,args,descriptors:count});
  child.on('close',(code,signal)=>log({event:'close',parentPid:process.pid,pid:child.pid,code,signal}));
  return child;
};
syncBuiltinESMExports();
process.on('exit',code=>log({event:'node-exit',pid:process.pid,code}));
`);
const gate = join(out, "native-gate.mjs");
await writeFile(gate, `#!${process.execPath}\nprocess.argv[2]='--native-gate';await import(${JSON.stringify(script)});\n`);
await chmod(gate, 0o700);
const profile = join(out, "read-only-authorities.sb");
await writeFile(profile, `(version 1)\n(allow default)\n(deny network-outbound)\n(deny file-write* ${[
  values["old-home"], values["project-home"], values["old-catalog"], legacyApp,
  join(root, "fixtures"), currentWorker, legacyWorker, dirname(values["readiness-report"]), readiness.source, readiness.home,
].map((p) => `(subpath ${JSON.stringify(resolve(p))})`).join(" ")})\n`);
const processLog = join(out, "processes.jsonl"), nativeLog = join(out, "native.jsonl");
process.env.SCREENREC_WORD_PROCESS_LOG = processLog;
await import(observer);
const replay = join(out, "replay.json");
const live = new Set(), exited = new Map();
async function run(args, env) {
  const child = spawn(process.execPath, args, { env, cwd: "/", stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "", stderr = "";
  child.stdout.on("data", (bytes) => { stdout += bytes; });
  child.stderr.on("data", (bytes) => { stderr += bytes; });
  const timer = setTimeout(() => child.kill("SIGKILL"), 30000);
  try {
    const [code, signal] = await once(child, "close");
    return { pid: child.pid, code, signal, stdout, stderr };
  } finally { clearTimeout(timer); }
}
async function start(side, entryOverride) {
  const old = side === "recording";
  const entry = entryOverride ?? (old ? join(legacyApp, "Contents/Resources/service/main.mjs") : join(sourceBundle, "service.mjs"));
  const cli = old ? join(legacyApp, "Contents/Resources/cli/main.mjs") : join(sourceBundle, "cli.mjs");
  const env = { ...process.env, SCREENREC_HOME: old ? oldHome : newHome, SCREENREC_NATIVE: gate,
    SCREENREC_WORD_WORKER: old ? legacyWorker : currentWorker, SCREENREC_WORD_REPLAY: replay,
    SCREENREC_WORD_NATIVE_LOG: nativeLog, SCREENREC_WORD_PROCESS_LOG: processLog,
    NODE_OPTIONS: `--import=${observer}` };
  const child = spawn("/usr/bin/sandbox-exec", ["-f", profile, process.execPath, entry], { env, cwd: "/", stdio: ["pipe", "pipe", "pipe"] });
  const record = { side, pid: child.pid, entry: await pin(entry), cli: await pin(cli), stdout: "", stderr: "", exit: null };
  report.processes.push(record); live.add(child);
  child.stdout.on("data", (bytes) => { record.stdout += bytes; });
  child.stderr.on("data", (bytes) => { record.stderr += bytes; });
  const close = once(child, "close").then(([code, signal]) => {
    record.exit = { code, signal }; live.delete(child); return record.exit;
  });
  exited.set(child, close);
  let socket;
  for (let i = 0; i < 150; i++) {
    const lines = record.stdout.split("\n").filter(Boolean).map(JSON.parse);
    assert(!lines.some((line) => line.event === "failed"), record.stdout);
    socket = lines.find((line) => line.event === "started")?.socketPath;
    if (socket) break;
    assert.equal(record.exit, null, record.stderr);
    await new Promise((done) => setTimeout(done, 100));
  }
  assert(socket, record.stdout + record.stderr);
  const mcp = new Client({ name: "paired-partial-words", version: "1" });
  const transport = new StdioClientTransport({ command: process.execPath, args: [cli, "mcp", "--socket", socket], env, stderr: "pipe" });
  await mcp.connect(transport);
  return {
    side,
    async call(operation, params, { via = "cli", error } = {}) {
      const request = { operation, params };
      const response = via === "cli" ? await run([cli, operation, "--socket", socket, "--params", JSON.stringify(params)], env) : await mcp.callTool({ name: operation, arguments: params });
      report.exchanges.push({ side, via, request, response });
      const result = via === "cli" ? JSON.parse(response.stdout) : response.structuredContent ?? JSON.parse(response.content[0].text);
      if (via === "cli") {
        assert.equal(response.signal, null); assert.equal(response.code, result.ok ? 0 : 1);
      } else {
        const text = JSON.parse(response.content.find((item) => item.type === "text").text);
        if (response.structuredContent) assert.deepEqual(text, response.structuredContent);
      }
      assert.equal(result.ok, !error, JSON.stringify(result));
      if (error) { assert.equal(result.error.code, error); return result.error; }
      return result.data;
    },
    async stop() {
      await mcp.close();
      child.stdin.end();
      const timer = setTimeout(() => child.kill("SIGKILL"), 15000);
      try { assert.deepEqual(await close, { code: 0, signal: null }, record.stderr); }
      finally { clearTimeout(timer); }
    },
  };
}
async function poll(read, done, label) {
  const deadline = performance.now() + 180000;
  for (;;) {
    const value = await read();
    if (done(value)) return value;
    assert(!["failed", "canceled", "unavailable"].includes(value.state), `${label}: ${JSON.stringify(value)}`);
    assert(performance.now() < deadline, label);
    await new Promise((finish) => setTimeout(finish, 100));
  }
}
async function drain(service, operation, params, name, via = "cli") {
  const pages = [];
  let cursor;
  do {
    const value = await poll(() => service.call(operation, { ...params, ...(cursor ? { cursor } : {}), limit: cursor ? 250 : 2 }, { via }),
      (reply) => reply.state === "ready", operation);
    pages.push(value);
    cursor = value.page.nextCursor;
  } while (cursor);
  report.pages[name] = pages;
  return pages.flatMap((value) => value.page.rows ?? value.page.entries);
}
const baselineOld = saved.receipts.legacySelectedTranscript.page.rows;
const baselineProject = saved.projectTranscriptPages.flatMap((page) => page.page.rows);
function projectedOld(before, edited) {
  return before.flatMap((row) => {
    const range = row.sourceRange;
    const retained = edited ? [{ startUs: 0, endUs: cut.startUs }, { startUs: cut.endUs, endUs: duration }] : [{ startUs: 0, endUs: duration }];
    const fragments = retained.flatMap((span) => {
      const left = Math.max(range.startUs, span.startUs), right = Math.min(range.endUs, span.endUs);
      const shift = span.startUs === cut.endUs ? 50000 : 0;
      return left < right ? [{ source: { startUs: left, endUs: right }, playback: { startUs: left - shift, endUs: right - shift } }] : [];
    });
    return fragments.length ? [{ ...row, partial: fragments.reduce((n, f) => n + f.source.endUs - f.source.startUs, 0) !== range.endUs - range.startUs, fragments }] : [];
  });
}
function expectedProject(document, generation, acquisitionId) {
  const trackRank = document.tracks.findIndex((track) => track.kind === "audio");
  return document.clips.filter((clip) => clip.assetId === narration).flatMap((clip) =>
    baselineProject.flatMap((row) => {
      const left = Math.max(row.sourceRange.startUs, clip.source.range.startUs), right = Math.min(row.sourceRange.endUs, clip.source.range.endUs);
      if (left >= right) return [];
      const shift = clip.placement.range.startUs - clip.source.range.startUs;
      return [{ ...row, clipId: clip.id, trackId: clip.trackId, trackRank, acquisitionId, generation,
        partial: left !== row.sourceRange.startUs || right !== row.sourceRange.endUs,
        fragments: [{ source: { startUs: left, endUs: right }, project: { startUs: left + shift, endUs: right + shift } }] }];
    }),
  ).sort((a, b) => a.fragments[0].project.startUs - b.fragments[0].project.startUs || a.ordinal - b.ordinal);
}
function expectedOldSearch(pairs) {
  return pairs.map((ordinals) => {
    const words = ordinals.map((ordinal) => baselineOld.find((row) => row.ordinal === ordinal));
    const sourceRange = { startUs: words[0].sourceRange.startUs, endUs: words.at(-1).sourceRange.endUs };
    const [{ partial, fragments }] = projectedOld([{ sourceRange }], true);
    return { wordIds: ordinals.map((ordinal) => `w${ordinal}`), sourceRange, partial, fragments };
  });
}
function expectedProjectSearch(rows, pairs) {
  return pairs.map((ordinals) => {
    const words = ordinals.map((ordinal) => rows.findLast((row) => row.ordinal === ordinal));
    return { trackId: words[0].trackId, trackRank: words[0].trackRank, words,
      projectRange: { startUs: words[0].fragments[0].project.startUs, endUs: words.at(-1).fragments.at(-1).project.endUs } };
  });
}
let old, modern;
let failure;
try {
  old = await start("recording");
  modern = await start("project");
  report.model.list = await modern.call("model.list", {});
  const registered = report.model.list.find((model) => model.modelId === "parakeet");
  assert.equal(registered.modelDigest, "4fe3f59cc82bab4ee7d06349b9a37c92d4b5758553b2cbb87a54ecc2dee6824a");
  report.model.preparation = await modern.call("model.prepare", { modelId: "parakeet", modelSource: readiness.source });
  report.model.ready = await poll(() => modern.call("model.status", { modelId: "parakeet" }), (reply) => reply.state === "ready", "model preparation");
  assert.deepEqual(await modern.call("model.status", { modelId: "parakeet" }, { via: "mcp" }), report.model.ready);
  const modelDirectory = join(newHome, "library/models/parakeet", registered.pins.modelRevision, "parakeet-tdt-0.6b-v2");
  report.model.receipt = await pin(join(dirname(modelDirectory), "receipt.json"));
  const source = join(root, "fixtures/narrated-workbench");
  const importing = await modern.call("acquisition.import", { requestId: "23m-source", path: source });
  const imported = await poll(() => modern.call("job.get", { jobId: importing.jobId }), (reply) => reply.state === "ready", "source admission");
  const acquisition = await modern.call("acquisition.get", { acquisitionId: imported.target.acquisitionId });
  report.acquisition = acquisition;
  assert.deepEqual(await modern.call("acquisition.get", { acquisitionId: acquisition.id }, { via: "mcp" }), acquisition);
  assert.equal(acquisition.evidence.receipt.header.systemAudio, false);
  assert.equal(acquisition.evidence.receipt.header.microphone, true);
  assert(!acquisition.bindings.some((binding) => binding.sourceRoles.includes("system")));
  const voice = acquisition.bindings.find((binding) => binding.sourceRoles.includes("narration"));
  assert.equal(voice.assetId, narration); assert.equal(voice.sourceToAssetOffsetUs, -origin);
  const sourceSelector = { assetId: narration, streamId: voice.streamId, acquisitionId: acquisition.id };
  const engine = saved.receipts.projectTranscript.dependencies.find((dep) => dep.selection.assetId === narration).transcript.engine;
  const fixture = {
    track: { source: null, streamId: voice.streamId, sourceOffsetUs: -origin, available: raw.map((line) => line.source) },
    model: { directory: modelDirectory, files: readiness.nativeRequest.files },
    rawFile: report.inputs.raw.path, rawSha256: report.inputs.raw.sha256,
    outputRoot: join(newHome, "library/transcripts/assets"),
    receipt: { engine: { runtime: engine.runtime, runtimeVersion: engine.runtimeVersion, decoder: engine.decoder, encoderPrecision: engine.encoderPrecision, computeUnits: engine.computeUnits },
      segments: raw.map(({ ordinal, source, state, reason, words }) => ({ ordinal, source, state, ...(reason ? { reason } : {}), wordCount: words.length })), wordCount: 306 },
  };
  await save("replay.json", fixture);
  const sourceRows = await drain(modern, "transcript.get", sourceSelector, "source-cli");
  assert.deepEqual(await drain(modern, "transcript.get", sourceSelector, "source-mcp", "mcp"), sourceRows);
  const metadata = report.pages["source-cli"][0].page.transcript;
  assert.equal(metadata.raw.sha256, report.inputs.raw.sha256);
  assert.deepEqual(metadata.engine, engine);
  const sourceWords = sourceRows.filter((row) => row.type === "word");
  const expectedSource = baselineProject.filter((row) => row.type === "word").map(({ clipId, assetId, streamId, acquisitionId, trackId, trackRank, generation, fragments, ...row }) => row);
  assert.deepEqual(sourceWords, expectedSource);
  report.receivedRaw = await pin(join(newHome, "library/transcripts/assets", narration, metadata.generation, "raw.jsonl"));
  assert.equal(report.receivedRaw.sha256, report.inputs.raw.sha256);
  const take = await old.call("recording.get", { recordingId });
  const restored = await old.call("edit.restore", { recordingId, requestId: "23m-identity", expectedRevisionId: take.currentRevisionId, targetRevisionId: "r0" });
  const oldBeforeRevision = restored.revision;
  const made = await modern.call("project.create", { requestId: "23m-identity", title: "Partial-word protocol fixture", canvas: { width: 3120, height: 1970, fps: { numerator: 30, denominator: 1 }, background: "#000000ff" } });
  const projectId = made.project.projectId;
  const operations = [];
  for (const [label, binding] of [["video", acquisition.bindings.find((b) => b.sourceRoles.includes("video"))], ["audio", voice]]) {
    const asset = await modern.call("asset.get", { assetId: binding.assetId });
    const startUs = Math.max(0, -binding.sourceToAssetOffsetUs);
    const endUs = Math.min(duration, asset.streams.find((stream) => stream.id === binding.streamId).endUs - binding.sourceToAssetOffsetUs);
    operations.push({ operation: "track.add", label, track: { kind: label, order: 0 } }, { operation: "place", clip: {
      trackId: { label }, assetId: binding.assetId, streamId: binding.streamId, acquisitionId: acquisition.id,
      source: { kind: "range", range: { startUs: startUs + binding.sourceToAssetOffsetUs, endUs: endUs + binding.sourceToAssetOffsetUs } },
      placement: { kind: "project", range: { startUs, endUs } },
    } });
  }
  const placed = await modern.call("edit.apply", { projectId, requestId: "23m-place", expectedRevisionId: made.revision.id, operations });
  const before = { recordingId, revisionId: oldBeforeRevision.id };
  const projectBefore = { projectId, revisionId: placed.revision.id };
  const oldBefore = await drain(old, "transcript.get", before, "old-before-cli");
  assert.deepEqual(oldBefore, projectedOld(baselineOld, false));
  const newBefore = await drain(modern, "transcript.get", projectBefore, "new-before-cli");
  assert.deepEqual(newBefore, expectedProject(placed.revision.document, metadata.generation, acquisition.id));
  assert.deepEqual(await drain(old, "transcript.get", before, "old-before-mcp", "mcp"), oldBefore);
  assert.deepEqual(await drain(modern, "transcript.get", projectBefore, "new-before-mcp", "mcp"), newBefore);
  const oldCut = await old.call("edit.cut", { recordingId, requestId: "23m-cut", expectedRevisionId: before.revisionId, ranges: [cut] });
  const doc = placed.revision.document;
  const newCut = await modern.call("edit.apply", { projectId, requestId: "23m-cut", expectedRevisionId: projectBefore.revisionId, operations: [{ operation: "remove", clipIds: doc.clips.map((clip) => clip.id), ranges: [cut], scope: "selected", ripple: { trackIds: doc.tracks.map((track) => track.id) } }] });
  report.revisions = { oldBefore: oldBeforeRevision, newBefore: placed.revision, oldAfter: oldCut.revision, newAfter: newCut.revision };
  const after = { recordingId, revisionId: oldCut.revision.id }, projectAfter = { projectId, revisionId: newCut.revision.id };
  const oldAfter = await drain(old, "transcript.get", after, "old-after-cli");
  const newAfter = await drain(modern, "transcript.get", projectAfter, "new-after-cli");
  assert.deepEqual(oldAfter, projectedOld(baselineOld, true));
  assert.deepEqual(newAfter, expectedProject(newCut.revision.document, metadata.generation, acquisition.id));
  assert.deepEqual(await drain(old, "transcript.get", after, "old-after-mcp", "mcp"), oldAfter);
  assert.deepEqual(await drain(modern, "transcript.get", projectAfter, "new-after-mcp", "mcp"), newAfter);
  for (const [name, rows, count] of [["old", oldAfter, 306], ["project", newAfter, 307]]) {
    const words = rows.filter((row) => row.type === "word");
    assert.equal(words.length, count); assert.deepEqual([...new Set(words.map((row) => row.ordinal))].sort((a,b) => a-b), Array.from({ length: 306 }, (_,i) => i));
    report.comparisons[name] = { wordRows: words.length, distinctOrdinals: 306, partial: words.filter((row) => row.partial) };
  }
  const common = (rows, side) => rows.filter((row) => row.type === "word" && row.ordinal === 1).flatMap((row) => row.fragments.map((fragment) => fragment[side]));
  const retained = [{ startUs: 1648675, endUs: 1800000 }, { startUs: 1800000, endUs: 1918675 }];
  assert.deepEqual(common(oldAfter, "playback"), retained); assert.deepEqual(common(newAfter, "project"), retained);
  assert.deepEqual(await drain(old, "transcript.get", before, "old-history-cli"), oldBefore);
  assert.deepEqual(await drain(modern, "transcript.get", projectBefore, "new-history-cli"), newBefore);
  const absent = await old.call("audio.get", { ...after, range: { startUs: 0, endUs: 1000000 }, track: "system" }, { error: "UNAVAILABLE" });
  assert.deepEqual(absent, { code: "UNAVAILABLE", message: "Selected audio was not acquired", retryable: false, details: { missingRoles: [{ role: "system", reason: "not_requested" }] } });
  assert.deepEqual(await old.call("audio.get", { ...after, range: { startUs: 0, endUs: 1000000 }, track: "system" }, { via: "mcp", error: "UNAVAILABLE" }), absent);
  const search = async (service, target, text, name) => {
    const entries = await drain(service, "transcript.search", { ...target, text }, name);
    assert.deepEqual(await drain(service, "transcript.search", { ...target, text }, name + "-mcp", "mcp"), entries);
    return entries;
  };
  report.search = {
    oldPartial: await search(old, after, "so this", "old-partial"),
    projectPartial: await search(modern, projectAfter, "so this", "new-partial"),
    oldWhole: await search(old, after, "this is", "old-whole"),
    projectWhole: await search(modern, projectAfter, "this is", "new-whole"),
  };
  assert.deepEqual(report.search.oldPartial, expectedOldSearch([[1,2]]));
  assert.deepEqual(report.search.oldWhole, expectedOldSearch([[2,3],[164,165]]));
  assert.deepEqual(report.search.projectWhole, expectedProjectSearch(expectedProject(newCut.revision.document, metadata.generation, acquisition.id), [[2,3],[164,165]]));
  assert.deepEqual(report.search.projectPartial, []);
  report.checks.push("Complete raw/source and all before/after CLI/MCP projection values, ordinal/occurrence shape, historical reads, intentional phrase difference, whole phrase and genuine absent role");
  if (values.mutant) {
    await modern.stop(); modern = null;
    const original = await readFile(join(sourceBundle, "service.mjs"), "utf8");
    const needle = 'if (head.row.type !== "word" || head.row.partial) {';
    assert.equal(original.split(needle).length, 2, "Partial barrier mutation owner not unique");
    const mutant = original.replace(needle, 'if (head.row.type !== "word") {');
    const entry = join(out, "partial-barrier-mutant.mjs");
    await writeFile(entry, mutant);
    report.mutant = { original: await pin(join(sourceBundle, "service.mjs")), changed: await pin(entry), needle };
    modern = await start("project-mutant", entry);
    const unexpected = await drain(modern, "transcript.search", { ...projectAfter, text: "so this" }, "mutant-partial");
    report.mutant.entries = unexpected;
    assert(unexpected.length > 0, "Negative producer did not falsify the partial-phrase contract");
    assert.deepEqual(unexpected, expectedProjectSearch(expectedProject(newCut.revision.document, metadata.generation, acquisition.id), [[1,2]]));
    try { assert.deepEqual(unexpected, []); } catch (error) { report.mutant.originalRed = { name: error.name, message: error.message, actual: unexpected, expected: [] }; }
    assert(report.mutant.originalRed);
    assert.deepEqual(await drain(modern, "transcript.search", { ...projectAfter, text: "this is" }, "mutant-whole"), report.search.projectWhole);
  }
  report.passed = true;
} catch (error) {
  failure = error;
  report.failure = { name: error.name, message: error.message, stack: error.stack };
} finally {
  for (const service of [modern, old]) if (service) {
    try { await service.stop(); } catch (error) { report.cleanupFailure ??= []; report.cleanupFailure.push(String(error)); failure ??= error; }
  }
  for (const child of live) child.kill("SIGKILL");
  await Promise.allSettled(exited.values());
  report.native = await readFile(nativeLog, "utf8").then((text) => text.trim().split("\n").filter(Boolean).map(JSON.parse), () => []);
  report.childEvents = await readFile(processLog, "utf8").then((text) => text.trim().split("\n").filter(Boolean).map(JSON.parse), () => []);
  await save("report.json", report);
}
if (failure) throw failure;
assert(report.native.filter((event) => event.event === "frozen-reply").length === 1);
assert(!report.native.some((event) => event.event === "refused"));
for (const child of report.childEvents.filter((event) => event.event === "spawn"))
  assert(report.childEvents.some((event) => event.event === "close" && event.pid === child.pid), `Unclosed child ${child.pid}`);
await save("report.json", report);
console.log(JSON.stringify({ passed: report.passed, exchanges: report.exchanges.length, pages: Object.keys(report.pages).length, partialRows: report.comparisons, negative: !!report.mutant?.originalRed }));
