import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {appendFileSync} from 'node:fs';
const log=v=>appendFileSync(process.env.SCREENREC_WORD_PROCESS_LOG,JSON.stringify(v)+'\n');
const spawn=childProcess.spawn;
childProcess.spawn=function(command,args,options={}) {
  const count=Array.isArray(options.stdio)?Math.max(0,options.stdio.length-3):0;
  if(command===process.env.SCREENREC_NATIVE) options={...options,env:{...(options.env??process.env),SCREENREC_WORD_DESCRIPTOR_COUNT:String(count)}};
  const child=spawn.call(this,command,args,options);
  log({event:'spawn',parentPid:process.pid,pid:child.pid,command,args,descriptors:count});
  child.on('close',(code,signal)=>log({event:'close',parentPid:process.pid,pid:child.pid,code,signal}));
  return child;
};
syncBuiltinESMExports();
process.on('exit',code=>log({event:'node-exit',pid:process.pid,code}));
