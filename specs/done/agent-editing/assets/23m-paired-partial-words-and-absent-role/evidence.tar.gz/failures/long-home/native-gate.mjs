#!/Users/david/.nvm/versions/node/v24.14.0/bin/node
process.argv[2]='--native-gate';await import("/Users/david/.codex/worktrees/speech-evaluator-policy/screen-recorder/packages/test-harness/editing/cutover-words.mjs");
