import collections,hashlib,json,pathlib,tarfile,datetime
root=pathlib.Path('/Users/david/dev/screen-recorder');b=pathlib.Path(__file__).parent;assets=root/'specs/agent-editing/assets/24z-current-preparation'
def read(p):return json.loads(p.read_text())
def pin(p):
 x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()}
a=read(b/'runtime-authority.json')
for v in a['pins']:
 actual=pin(pathlib.Path(v['path']));assert actual==v,(v,actual)
m=read(b/'measure/measure-report.json');p=read(b/'profile/case/profile-report.json')
for report,n in [(m,42),(p,2)]:
 assert len(report['collections'])==n and report['passed']==False and report['error']['message'].startswith('Complete cached 250-row collection exceeded unchanged 250ms')
 assert not report['shutdownErrors'] and not report.get('processObservationError')
 for c in report['collections']:
  assert c['pageCount']==7 and sum(v['rows'] for v in c['pages'])==250 and c['nextCursor'] and c['nativeCallBoundary']['before']==c['nativeCallBoundary']['after']
 for pid in {v['pid'] for v in report['processEvents'] if v['event']=='spawn'}:
  assert any(v['event']=='node-exit' and v['pid']==pid and v['code']==0 for v in report['processEvents'])
  assert any(v['event']=='close' and v['pid']==pid and v['code']==0 and v['signal'] is None for v in report['processEvents'])
assert all(v['reason']=='complete' for v in p['profiles'])
summary=[]
for arm in [512,1024]:
 f=b/f'profile/case/service-{arm}.cpuprofile';v=read(f);nodes={n['id']:n for n in v['nodes']};parent={c:n['id'] for n in v['nodes'] for c in n.get('children',[])};ex=collections.Counter();inc=collections.Counter()
 def label(i):
  c=nodes[i]['callFrame'];return c['functionName'] or '(anonymous)',c['url'],c['lineNumber']+1
 for sample,t in zip(v['samples'],v['timeDeltas']):
  ex[label(sample)]+=t;chain=set()
  while sample in nodes:
   chain.add(label(sample))
   if sample not in parent:break
   sample=parent[sample]
  for key in chain:inc[key]+=t
 def top(c):return [{'function':k[0],'url':k[1],'line':k[2],'sampledMs':n/1000} for k,n in c.most_common(20)]
 summary.append({'arm':arm,'source':pin(f),'exclusive':top(ex),'inclusive':top(inc)})
(assets/'metadata-batch-profile-summary.json').write_text(json.dumps({'scope':'Two successor query profiles, not SLA samples or causal attribution. Inclusive frames overlap; idle, inspector and GC remain included.','arms':summary},indent=2)+'\n')
files={}
def add(p,name):assert p.is_file();files[name]=p
for name in ['bank.py','runtime-authority.json','preflight.json','measure.py','measure-process.json','measure.stdout','measure.stderr']:add(b/name,name)
add(root/'packages/test-harness/editing/source-cardinality.mjs','executed/source-cardinality.mjs')
add(pathlib.Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002/metadata-merged-tests.log'),'merged-tests.log')
for prefix,directory,report in [('measure',b/'measure',m),('profile',b/'profile/case',p)]:
 for f in directory.iterdir():
  if f.is_file() and (f.name.startswith(prefix+'-') or f.name.startswith('measure-process') or f.name.startswith('service-') or f.name=='fixture.json') and not f.name.endswith('processes.txt'):add(f,prefix+'/'+f.name)
 for c in report['collections']:
  for cf in c.get('cacheFiles',[]):add(directory/(cf['id']+'.cache.json'),prefix+'/'+cf['id']+'.cache.json')
for f in (b/'profile').iterdir():
 if f.is_file():add(f,'profile-producer/'+f.name)
child=pathlib.Path('/tmp/screenrec-source-metadata-batch');cr=read(child/'report.json')
for v in cr['sourcePins']:
 relative=str(pathlib.Path(v['path']).relative_to('/Users/david/.codex/worktrees/source-cardinality-current/screen-recorder'));assert pin(root/relative)['sha256']==v['sha256']
for f in child.iterdir():
 if f.is_file():add(f,'child/'+f.name)
archive=assets/'metadata-batch.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name,recursive=False)
manifest=[{'member':name,**pin(f)} for name,f in sorted(files.items())]
with tarfile.open(archive) as t:
 for v in manifest:
  data=t.extractfile(v['member']).read();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
result={'scope':'Synchronous SQL batching integrated and narrow contracts green; source-cardinality 1024 p95 remains red','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':'55738523','childCommit':cr['commit'],'productionSize':{'added':44,'deleted':15,'net':29},'rootReview':'Existing acquisition/asset/selection owners only; complete metadata and first failure unchanged, fresh phases retained, sequential scene preparation unchanged. Root reviewed all source/test/doc changes.','mergedTests':{'files':3,'tests':78,'exitCode':0,'log':pin(pathlib.Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002/metadata-merged-tests.log'))},'independentReview':cr['checks']['codex'],'independentReviewLimit':'CLI rejected configured model before reviewing; no review verdict, no override or unchanged retry','runtimeAfter':{'authority':pin(b/'runtime-authority.json'),'count':len(a['pins']),'differences':[],'intendedChanges':len(a['changes'])},'preflight':read(b/'preflight.json'),'measure':{'process':read(b/'measure-process.json'),'report':pin(b/'measure/measure-report.json'),'collections':42,'arms':m['arms'],'error':m['error']['message'],'completeOutputChecks':True,'queryNativeCalls':0,'allChildrenNodeExitAndOsClose':True},'profile':{'process':read(b/'profile/profile-process.json'),'report':pin(b/'profile/case/profile-report.json'),'profiles':p['profiles'],'meaning':'Both profiles complete; original producer applies unchanged latency assertion afterward and remains exit1. Attribution only.'},'next':'Inspect remaining current owner/transport work before any further measurement. No unchanged retry or budget relaxation.','archive':pin(archive),'members':manifest}
(assets/'metadata-batch.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'pinsVerified':len(a['pins']),'membersVerified':len(manifest),'archiveBytes':archive.stat().st_size,'p95':[v['p95Ms'] for v in m['arms']]}))
