# Focused review

Shape: AcquisitionStore owns both singular and batched decode/error meaning. SourceSelectionRead remains the only decoded per-phase metadata cache. Existing full AssetStore.get owns segment reconstruction; its per-stream SQL loop is replaced, not shadowed. No public operation, cache table, epoch, schema, service composition, budget or deadline change.

Diff: source-key order and lazy failure selection are preserved. SQL rows are keyed by acquisition ID; missing and null metadata retain their old CatalogError codes and payloads. Segment rows retain ordinal order within each stream and decode in header stream order. Unknown/undeclared segments are not decoded. No SourceSelectionRead spans checkpoint publication. Existing prepare=true scene admission remains sequential.

Verification: red-ready existing work test: headers2/segments10/acquisitions4; corrected exact page/cursor test: headers2/segments2/acquisitions2. Three owning files passed78 tests; the final no-segment fast path then passed the22-test asset file. Expanded existing first-error controls cover later missing/pending/malformed acquisition rows and their standalone actual errors. Post-publication mutation checks reject changed metadata and delete the attempted checkpoint. Targeted core types, lint, formatting and git diff check pass. No native/model/service/benchmark or full-suite run.

Docs: existing service README links the shared source-selection owner and explains synchronous freshness/error-order/admission principles. No shared spec or maintenance hub edited.

Independent CLI review: PID20720 actual exit1/3.837s, HTTP400 unsupported configured gpt-6.1-sol for the CLI ChatGPT account, before source review. Complete prompt/stdout/stderr/process receipt retained. No retry or model/config override; no clean-review claim from it. Implementer's source review is clean; parent independent review remains required for integration.
