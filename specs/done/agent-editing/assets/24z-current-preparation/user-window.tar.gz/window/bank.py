import collections,datetime,hashlib,json,pathlib,tarfile
root=pathlib.Path('/Users/david/dev/screen-recorder')
b=pathlib.Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2'); w=b/'user-window-20261002-191516'; out=root/'specs/agent-editing/assets/24z-current-preparation'
def read(p): return json.loads(p.read_text())
def pin(p):
 data=p.read_bytes(); return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def save(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
a=read(b/'successor-ed94019f/runtime-authority.json')
pins=a['unchanged']+[v['after'] for v in a['changes']]+a['scenarioConsumers']+a['sdk']['esmFiles']+[v[k] for v in a['resources'] for k in ['source','emitted']]+[a[k] for k in ['node','native','fixture']]
differences=[]
for v in pins:
 p=pathlib.Path(v['path']); p=p if p.is_absolute() else root/p; actual=pin(p)
 if actual['bytes']!=v['bytes'] or actual['sha256']!=v['sha256']: differences.append({'expected':v,'actual':actual})
assert len(pins)==774 and not differences
save(w/'runtime-after.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority':pin(b/'successor-ed94019f/runtime-authority.json'),'count':len(pins),'differences':differences})
m=read(b/'current/measure-report.json'); p=read(w/'profile-qualified/case/profile-report.json')
for d,n in [(m,42),(p,2)]:
 assert len(d['collections'])==n and not d['passed'] and d['error']['message'].startswith('Complete cached 250-row collection exceeded unchanged 250ms')
 assert not d['shutdownErrors'] and not d.get('processObservationError')
 for c in d['collections']:
  assert c['pageCount']==7 and sum(v['rows'] for v in c['pages'])==250 and c['nextCursor']
  assert c['nativeCallBoundary']['invocationsDuringRead']==0 and c['nativeCallBoundary']['before']==c['nativeCallBoundary']['after']
 spawned={v['pid'] for v in d['processEvents'] if v['event']=='spawn'}
 for pid in spawned:
  assert any(v['event']=='node-exit' and v['pid']==pid and v['code']==0 for v in d['processEvents'])
  assert any(v['event']=='close' and v['pid']==pid and v['code']==0 and v['signal'] is None for v in d['processEvents'])
assert len(p['profiles'])==2 and all(v['reason']=='complete' for v in p['profiles'])
summary=[]
for arm in [512,1024]:
 f=w/f'profile-qualified/case/service-{arm}.cpuprofile'; d=read(f); nodes={v['id']:v for v in d['nodes']}; parent={child:v['id'] for v in d['nodes'] for child in v.get('children',[])}; exclusive=collections.Counter(); inclusive=collections.Counter()
 def label(i):
  c=nodes[i]['callFrame'];return (c['functionName'] or '(anonymous)',c['url'],c['lineNumber']+1,c['columnNumber']+1)
 for sample,delta in zip(d['samples'],d['timeDeltas']):
  exclusive[label(sample)]+=delta; chain=set()
  while sample in nodes:
   chain.add(label(sample))
   if sample not in parent:break
   sample=parent[sample]
  for key in chain: inclusive[key]+=delta
 def top(counter): return [{'function':k[0],'url':k[1],'line':k[2],'column':k[3],'sampledMs':v/1000} for k,v in counter.most_common(25)]
 summary.append({'arm':arm,'profile':pin(f),'exclusive':top(exclusive),'inclusive':top(inclusive)})
save(out/'user-window-profile-summary.json',{'scope':'Sample attribution of two current queries; inclusive frames overlap. Includes idle, GC and inspector overhead; no elapsed-time causality or SLA claim.','arms':summary})
files={}
def add(p,name):
 assert p.is_file();files[name]=p
for name in ['preflight.json','runtime-before.json','runtime-after.json','runtime-differences.json','measure.py','measure-process.json','measure.stdout','measure.stderr','bank.py']:
 add(w/name,'window/'+name)
add(b/'successor-ed94019f/runtime-authority.json','runtime-authority.json')
add(b/'current/fixture.json','fixture.json')
for name in ['source-cardinality.mjs','source-cardinality-fixture.mjs','source-evidence-fixture.mjs','evidence-service.mjs','first-preview-transport.mjs','service-cpu-profile.mjs']:
 add(root/'packages/test-harness/editing'/name,'executed-harness/'+name)
for prefix,directory,report in [('measure',b/'current',m),('profile',w/'profile-qualified/case',p)]:
 for f in directory.iterdir():
  if f.is_file() and (f.name.startswith(prefix+'-') or f.name.startswith('measure-process') or f.name.startswith('service-')) and not f.name.endswith('processes.txt'):
   add(f,prefix+'/'+f.name)
 for c in report['collections']:
  for cf in c.get('cacheFiles', []): add(directory/(cf['id']+'.cache.json'),prefix+'/'+cf['id']+'.cache.json')
for name in ['profile','profile-current','profile-qualified']:
 for f in (w/name).iterdir():
  if f.is_file():add(f,name+'-producer/'+f.name)
archive=out/'user-window.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name,recursive=False)
manifest=[{'member':name,**pin(f)} for name,f in sorted(files.items())]
save(out/'user-window.json',{'scope':'One current measure and two-query CPU attribution in user-offered relatively free window; red p95 retained, target unchanged.','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootHead':'9e1d27fa0fc383399f0058a08067b2a8b2797d06','preflight':read(w/'preflight.json'),'runtimeAfter':read(w/'runtime-after.json'),'measure':{'process':read(w/'measure-process.json'),'report':pin(b/'current/measure-report.json'),'collections':42,'warmCollectionsPerArm':20,'arms':m['arms'],'error':m['error']['message'],'completeOutputChecks':True,'queryNativeCalls':0,'allSourceAndMcpNodeExitAndOsClose':True},'profile':{'process':read(w/'profile-qualified/profile-process.json'),'report':pin(w/'profile-qualified/case/profile-report.json'),'attempt':read(w/'profile-qualified/case/profile-attempt.json'),'profiles':p['profiles'],'terminalFailure':p['error']['message'],'meaning':'Both complete query profiles are usable attribution. Overall producer remains exit1 because unchanged harness latency assertion runs after profiling; no profile/SLA pass claimed.','setupFailures':[{'process':read(w/name/'profile-process.json'),'stderr':pin(w/name/'profile.stderr'),'meaning':reason} for name,reason in [('profile','Historical native binding refused before service startup'),('profile-current','Scratch SDK dynamic import resolution failed before service startup')]]},'archive':pin(archive),'members':manifest})
with tarfile.open(archive,'r:gz') as t:
 for v in manifest:
  data=t.extractfile(v['member']).read();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
print(json.dumps({'pinsVerified':len(pins),'archive':pin(archive),'members':len(manifest),'completeCollections':44}))
