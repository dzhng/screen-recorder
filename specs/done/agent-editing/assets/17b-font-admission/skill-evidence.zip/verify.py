import json,subprocess,pathlib
D=pathlib.Path('/tmp/screenrec-font-fresh-skill')
def read(n): return json.loads((D/(n+'.stdout.json')).read_text())['data']
def call(n,op,p):
 subprocess.run(['python3',str(D/'call.py'),n,op,json.dumps(p)],check=True)
 return read(n)
checks={}
for src,get,prefix in [('02-arial-import','06-arial-get','15-arial'),('03-albayan-import','07-albayan-get','16-albayan')]:
 a=read(get)
 after=call(prefix+'-get-restarted','asset.get',{'assetId':a['id']})
 checks[prefix+'-asset-metadata-identical']=after==a
 p=json.loads((D/(src+'.request.json')).read_text())
 job=call(prefix+'-replay-restarted','asset.import',p)
 checks[prefix+'-job-identity-preserved']=job['jobId']==read(src)['jobId']
 checks[prefix+'-replay-ready-and-same-asset']=job['state']=='ready' and job['result']['assetId']==a['id']
checks['library-identical-after-restart']=read('12-list-after-repeat')==read('14-list-restarted')
for initial,replay,newjob in [('04-arial-job','10-arial-replay','10-arial-new-job'),('05-albayan-job','11-albayan-replay','11-albayan-new-job')]:
 checks[initial+'-same-request-same-job']=read(initial)['jobId']==read(replay)['jobId']
 checks[initial+'-new-request-same-asset']=read(initial)['result']==read(newjob)['result']
 checks[initial+'-new-request-distinct-job']=read(initial)['jobId']!=read(newjob)['jobId']
(D/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
assert all(checks.values()),checks
print(json.dumps(checks,indent=2))
