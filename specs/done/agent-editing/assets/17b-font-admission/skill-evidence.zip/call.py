import json,sys,subprocess,pathlib
D=pathlib.Path('/tmp/screenrec-font-fresh-skill')
label,op,raw=sys.argv[1:]
params=json.loads(raw)
(D/(label+'.request.json')).write_text(raw+'\n')
args=['node','/Users/david/dev/screen-recorder/apps/cli/dist/main.js',op,'--socket',(D/'socket.txt').read_text(),'--params','-']
(D/(label+'.command.json')).write_text(json.dumps(args))
r=subprocess.run(args,input=raw+'\n',text=True,capture_output=True,timeout=60)
(D/(label+'.stdout.json')).write_text(r.stdout)
(D/(label+'.stderr')).write_text(r.stderr)
(D/(label+'.exit.txt')).write_text(str(r.returncode)+'\n')
print(r.stdout); print('exit:',r.returncode,'stderr:',r.stderr)
