import json,subprocess,pathlib
D=pathlib.Path('/tmp/screenrec-font-fresh-skill')
def read(n): return json.loads((D/(n+'.stdout.json')).read_text())['data']
def call(n,op,p):
 subprocess.run(['python3',str(D/'call.py'),n,op,json.dumps(p)],check=True)
 return read(n)
call('09-list-page2','asset.list',{'limit':1,'cursor':read('08-list')['nextCursor']})
chosen=[]
for name,label,face in [('arial','06-arial-get','ArialMT'),('albayan','07-albayan-get','AlBayan')]:
 a=read(label)
 selected=next(f for f in a['fontFaces'] if f['postScriptName']==face)
 chosen.append({'assetId':a['id'],'postScriptName':selected['postScriptName'],'intent':'Explicit regular/plain face for later text work; not rendered or coverage-verified'})
(D/'chosen-faces.json').write_text(json.dumps(chosen,indent=2)+'\n')
for src,prefix in [('02-arial-import','10-arial'),('03-albayan-import','11-albayan')]:
 p=json.loads((D/(src+'.request.json')).read_text())
 call(prefix+'-replay','asset.import',p)
 p['requestId']=p['requestId'].replace('-1','-2')
 j=call(prefix+'-new-import','asset.import',p)
 call(prefix+'-new-job','job.get',{'jobId':j['jobId']})
call('12-list-after-repeat','asset.list',{})
