import {JourneyService} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
import {mkdtemp,writeFile,access,unlink} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
const dir='/tmp/screenrec-font-fresh-skill';
const home=await mkdtemp('/tmp/srf-');
const report={trace:[]};
const svc=new JourneyService(home,report);
await writeFile(`${dir}/home.txt`,home);
try {
 await svc.start();
 await writeFile(`${dir}/socket.txt`,svc.socketPath);
 await writeFile(`${dir}/lifecycle.jsonl`,JSON.stringify({event:'started',home,socket:svc.socketPath})+'\n');
 for (;;) {
  if(await access(`${dir}/stop`).then(()=>true,()=>false)) break;
  if(await access(`${dir}/restart`).then(()=>true,()=>false)) {
   await unlink(`${dir}/restart`); await svc.stop(); await svc.start();
   await writeFile(`${dir}/socket.txt`,svc.socketPath);
   await writeFile(`${dir}/restarted.json`,JSON.stringify({home,socket:svc.socketPath}));
  }
  await delay(200);
 }
} finally {
 await svc.stop();
 await writeFile(`${dir}/service-logs.txt`,svc.logs.join(''));
 await writeFile(`${dir}/service-report.json`,JSON.stringify(report,null,2));
 await writeFile(`${dir}/stopped.json`,JSON.stringify({stopped:true,home}));
}
