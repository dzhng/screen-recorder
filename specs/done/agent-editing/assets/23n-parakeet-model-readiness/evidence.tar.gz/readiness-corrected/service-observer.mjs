import childProcess from 'node:child_process';import {syncBuiltinESMExports} from 'node:module';import {appendFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
const spawn=childProcess.spawn;childProcess.spawn=(...args)=>{const child=spawn(...args);child.once('close',(code,signal)=>appendFileSync(process.env.SCREENREC_READINESS_CHILD_LOG,JSON.stringify({event:'close',pid:child.pid,executable:args[0],args:args[1],code,signal})+'\n'));return child;};syncBuiltinESMExports();
await import(pathToFileURL(process.env.SCREENREC_READINESS_SERVICE).href);
