#!/Users/david/.nvm/versions/node/v24.14.0/bin/node
import {spawn} from 'node:child_process';import {appendFileSync} from 'node:fs';
const log=value=>appendFileSync(process.env.SCREENREC_READINESS_NATIVE_LOG,JSON.stringify(value)+'\n');let input='';
process.stdin.setEncoding('utf8').on('data',value=>input+=value);process.stdin.on('end',()=>{
const request=JSON.parse(input);log({event:'request',request});
if(request.operation!=='media.audioCapabilities'||Object.keys(request.params).length){log({event:'refused',request});process.stdout.write(JSON.stringify({id:request.id,ok:false,error:{code:'UNEXPECTED_NATIVE_CALL',message:request.operation,retryable:false,details:{}}})+'\n');return;}
const child=spawn(process.env.SCREENREC_READINESS_NATIVE,[],{stdio:['pipe','pipe','pipe']});log({event:'forwarded',pid:child.pid});
let stdout='',stderr='';child.stdout.on('data',value=>stdout+=value);child.stderr.on('data',value=>stderr+=value);
child.on('close',(code,signal)=>{log({event:'close',pid:child.pid,code,signal,stdout,stderr});process.stdout.write(stdout);process.stderr.write(stderr);process.exitCode=code??1;});child.stdin.end(input);
});
