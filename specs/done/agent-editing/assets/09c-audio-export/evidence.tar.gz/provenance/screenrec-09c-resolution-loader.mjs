import {appendFileSync} from 'node:fs';
export async function resolve(specifier,context,nextResolve){const resolved=await nextResolve(specifier,context);appendFileSync('/tmp/screenrec-09c-resolution-graph.jsonl',JSON.stringify({specifier,parentURL:context.parentURL??null,url:resolved.url})+'\n');return resolved;}
