import pathlib,json,hashlib,tarfile,sqlite3,subprocess,platform,sys
root=pathlib.Path('/Users/david/.codex/worktrees/audio-export/screen-recorder');dst=root/'specs/agent-editing/assets/09c-audio-export'
def digest(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def archive(name,files):
 pins={}
 with tarfile.open(dst/(name+'.tar.gz'),'w:gz',compresslevel=6) as t:
  for member,p in sorted(files.items()):
   assert p.is_file(),str(p)
   t.add(p,arcname=member,recursive=False);pins[member]=digest(p)
 (dst/(name+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
 return pins
paths=set(json.loads((dst/'source-runtime-pins.json').read_text()))
paths.update(['apps/service/README.md','specs/agent-editing/slices/09c-audio-only-export.md','specs/agent-editing/contracts.md'])
source=archive('source-runtime',{p:root/p for p in paths})
evidence={}
for stem in ['public-riff-final','public-complete','public-all-gates','public-reviewed-corrected','public-mutant','wav-fifth']:
 base=pathlib.Path('/tmp/screenrec-09c-'+stem)
 for p in base.rglob('*'):
  if p.is_file(): evidence[stem+'/'+str(p.relative_to(base))]=p
for stem in ['public-first','public-final','public-presented','public-scope-final','wav-first','wav-second','wav-third','wav-fourth','public-reviewed']:
 base=pathlib.Path('/tmp/screenrec-09c-'+stem)
 for leaf in ['report.json','service.log','native/operations.jsonl']:
  p=base/leaf
  if p.is_file(): evidence['diagnostics/'+stem+'/'+leaf]=p
for p in pathlib.Path('/tmp').glob('screenrec-09c*.log'):
 if '-native-' not in p.name: evidence['logs/'+p.name]=p
for p in pathlib.Path('/tmp/screenrec-09c-controls-complete').rglob('*'):
 if p.is_file(): evidence['controls/'+str(p.relative_to('/tmp/screenrec-09c-controls-complete'))]=p
for name in ['screenrec-09c-bank.py','screenrec-09c-preserve-decoded.py','screenrec-09c-riff-minimal-header-mutant.ts','screenrec-09c-export-admission-mutant.ts','screenrec-09c-native-integration-check.json','screenrec-09c-resolution-loader.mjs','screenrec-09c-resolution-probe.mjs','screenrec-09c-resolution-graph.jsonl']:
 p=pathlib.Path('/tmp')/name
 if p.is_file(): evidence['provenance/'+name]=p
bank=archive('evidence',evidence)
if '--core-only' in sys.argv:
 print(json.dumps({'sourceRuntime':len(source),'evidence':len(bank)}));sys.exit()
# Archive all non-system dependencies that the external tools name, once by resolved path.
queue=[pathlib.Path('/Users/david/.nvm/versions/node/v24.14.0/bin/node'),pathlib.Path('/opt/homebrew/bin/ffmpeg').resolve(),pathlib.Path('/opt/homebrew/bin/ffprobe').resolve()];seen=set();links={};tools={}
while queue:
 p=queue.pop()
 if str(p) in seen:continue
 seen.add(str(p));tools[str(p).lstrip('/')]=p
 reply=subprocess.check_output(['otool','-L',str(p)],text=True)
 links[str(p)]=reply
 for line in reply.splitlines()[1:]:
  q=line.strip().split(' (')[0]
  if q.startswith('/opt/homebrew/') and pathlib.Path(q).is_file():queue.append(pathlib.Path(q).resolve())
toolpins=archive('external-tools',tools)
versions={k:subprocess.check_output(v,text=True).strip() for k,v in {'node':['node','--version'],'ffmpeg':['ffmpeg','-version'],'ffprobe':['ffprobe','-version'],'os':['sw_vers'],'swift':['swift','--version']}.items()}
(dst/'external-tools-links.json').write_text(json.dumps({'links':links,'versions':versions,'system':'macOS system frameworks and dyld shared cache remain host dependencies; named by the exact tool link outputs.'},indent=2)+'\n')
print(json.dumps({'sourceRuntime':len(source),'evidence':len(bank),'externalTools':len(toolpins),'sizes':{p.name:p.stat().st_size for p in dst.glob('*.tar.gz')}},indent=2))
