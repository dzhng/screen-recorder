
import Foundation
import ScreenRecorderControls
@main struct Check {
 static func main() throws {
  for leaf in ["mix.wav","mix.m4a"] {
   let fields:[String:Any] = ["exportId":"audio-"+leaf,"projectId":"p","kind":"audio","snapshot":["revisionId":"r","settings":["container":leaf.hasSuffix("wav") ? "wav":"m4a"]],"state":"failed","destination":["directory":"/tmp","leaf":leaf],"retryable":true,"abandoning":false,"cleanupPending":false,"output":NSNull(),"reason":"fixture failure"]
   let data=try JSONSerialization.data(withJSONObject:fields)
   let record=try JSONDecoder().decode(ExportsState.Record.self,from:data)
   precondition(record.kind == .audio && record.leaf == leaf && record.target == .project("p"))
   var exports=ExportsState();exports.admit(record)
   var state=ControlsState();state.service = .ready
   let menu=RecordingMenu.entries(for:state,exports:exports).first(where:{$0.title.hasPrefix("Exports")})!.submenu
   precondition(menu.first?.title == "Audio — "+leaf+" — failed")
   precondition(menu.first?.submenu.contains(where:{$0.action?.id == "export.retry.audio-"+leaf && $0.enabled}) == true)
  }
  if CommandLine.arguments.count > 1 {
   let data=try Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))
   let records=try JSONDecoder().decode([ExportsState.Record].self,from:data)
   precondition(!records.isEmpty && records.allSatisfy{$0.kind == .audio})
   for record in records {
    var exports=ExportsState();exports.admit(record)
    var state=ControlsState();state.service = .ready
    let rows=RecordingMenu.entries(for:state,exports:exports).first(where:{$0.title.hasPrefix("Exports")})!.submenu
    precondition(rows.first?.title.hasPrefix("Audio — "+record.leaf) == true)
   }
  }
  print("audio destinations and status controls passed")
 }
}