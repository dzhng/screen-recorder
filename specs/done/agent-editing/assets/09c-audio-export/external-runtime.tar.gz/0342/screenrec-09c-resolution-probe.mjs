await import('file:///Users/david/.codex/worktrees/audio-export/screen-recorder/apps/service/dist/project-service.js');
await import('file:///Users/david/.codex/worktrees/audio-export/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs');
process.argv=[process.execPath,'/Users/david/.codex/worktrees/audio-export/screen-recorder/apps/cli/dist/main.js','--help'];
await import('file:///Users/david/.codex/worktrees/audio-export/screen-recorder/apps/cli/dist/main.js');
