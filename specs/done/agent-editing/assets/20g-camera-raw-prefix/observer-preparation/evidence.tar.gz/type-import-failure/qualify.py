import json,pathlib,subprocess,time,datetime,os,signal,hashlib,sys,selectors
root=pathlib.Path('/tmp/screenrec-20g-raw-prefix/observer-preparation')
plan=json.loads((root/'plan.json').read_text())
records=[]; live=None; phase=time.monotonic()
def write():
    (root/'processes.json').write_text(json.dumps({'phaseBoundSeconds':160,'elapsedSeconds':time.monotonic()-phase,'processes':records},indent=2)+'\n')
def run(label,argv,bound):
    global live
    bound=min(bound,160-(time.monotonic()-phase))
    if bound<=0: raise RuntimeError('phase deadline')
    with (root/(label+'.stdout')).open('wb') as out,(root/(label+'.stderr')).open('wb') as err:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        live=p; start=time.monotonic()
        record={'label':label,'argv':argv,'pid':p.pid,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':bound,'terminal':False}
        records.append(record); write()
        streams=selectors.DefaultSelector()
        streams.register(p.stdout,selectors.EVENT_READ,('stdout',out))
        streams.register(p.stderr,selectors.EVENT_READ,('stderr',err))
        sizes={'stdout':0,'stderr':0}
        try:
            while streams.get_map() or p.poll() is None:
                if time.monotonic()-start>bound: raise RuntimeError('process deadline')
                for key,_ in streams.select(.02):
                    chunk=os.read(key.fileobj.fileno(),65536)
                    name,destination=key.data
                    if not chunk: streams.unregister(key.fileobj); key.fileobj.close(); continue
                    remaining=1_048_576-sizes[name]
                    destination.write(chunk[:remaining]); destination.flush(); sizes[name]+=min(remaining,len(chunk))
                    if len(chunk)>remaining: raise RuntimeError(name+' fixed 1 MiB log cap')
            p.wait()
        except BaseException as error:
            record['controllerFailure']=str(error)
            if p.poll() is None: os.killpg(p.pid,signal.SIGKILL)
            p.wait(timeout=5)
            raise
        finally:
            streams.close()
            for pipe in [p.stdout,p.stderr]:
                if not pipe.closed: pipe.close()
            record.update(terminal=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,stdioBytes=sizes,stdioCapBytes=1_048_576)
            live=None; write()
        expected=0
        if p.returncode!=expected: raise RuntimeError(f'{label} exit {p.returncode}, expected {expected}')
def inventory():
    cache=pathlib.Path(plan['warmCache'])
    return [{'path':str(p.relative_to(cache)),'bytes':p.stat().st_size,'mtimeNs':p.stat().st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(cache.rglob('*')) if p.is_file()]
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path'])
        assert p.stat().st_size==pin['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256'],str(p)
    assert (root/'ObserverTypes.swift').read_text()==(root/'Observer.swift').read_text().replace('@main struct PrefixObserver','struct PrefixObserver')
    (root/'cache-before.json').write_text(json.dumps(inventory(),indent=2)+'\n')
    run('compile',plan['compile'],150)
    exe=root/'filesystem-checks'
    (root/'executable.json').write_text(json.dumps({'path':str(exe),'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n')
    run('filesystem-only',plan['filesystem'],10)
    (root/'qualification-verdict.json').write_text(json.dumps({'status':'pass','scope':'actual observer Foundation/filesystem ownership, failure persistence and tuple diagnostics only; no media'},indent=2)+'\n')
except BaseException as error:
    (root/'qualification-verdict.json').write_text(json.dumps({'status':'fail','error':repr(error),'mediaDispatched':False},indent=2)+'\n')
    print('FAIL',error);sys.exit(1)
finally:
    (root/'cache-after.json').write_text(json.dumps(inventory(),indent=2)+'\n');write()
