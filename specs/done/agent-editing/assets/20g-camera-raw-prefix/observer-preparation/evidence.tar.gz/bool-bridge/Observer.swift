@preconcurrency import AVFoundation
import Foundation
import Darwin
import CryptoKit
@testable import ScreenRecorderCapture
import ScreenRecorderMedia

struct ProbeFailure: Error { let message: String }

struct Tick: Codable, Equatable {
    let value: Int64; let scale: Int32; let epoch: Int64; let flags: UInt32
    init(_ t: CMTime) { value=t.value; scale=t.timescale; epoch=t.epoch; flags=t.flags.rawValue }
}
struct Picture: Codable, Equatable {
    let ordinal: Int; let pts: Tick; let digestPTS: Tick; let width: Int; let height: Int
    let end: Tick?; let bgra: Data
}
struct Snapshot: Codable {
    let phase: String; let completedFragments: Int; let nativeScale: Int32
    let duration: Tick; let readerStatus: Int; let containsFragments: Bool?; let canContainFragments: Bool?
    let pictures: [Picture]
    let segmentBounds: [SegmentBounds]; let cursorFacts: [CursorFact]
}

struct SegmentBounds: Codable {
    let mediaStart: Tick; let mediaDuration: Tick; let assetStart: Tick; let assetDuration: Tick
    init(_ segment: SourceSegment) {
        mediaStart=Tick(segment.media.start); mediaDuration=Tick(segment.media.duration)
        assetStart=Tick(segment.asset.start); assetDuration=Tick(segment.asset.duration)
    }
}
struct StorageExtent: Codable { let offset: Int64; let length: Int64 }
struct CursorFact: Codable {
    let ordinal: Int; let requestedAssetPTS: Tick; let selectedSegment: Int?
    let requestedMediaPTS: Tick?; let matchedByOwnerMicroseconds: Bool?
    let clocks: [String:Tick]; let flags: [String:Bool]; let extents: [String:StorageExtent]
    let storageURL: String?; let sampleIndexInChunk: Int64?; let samplesRequiredForDecoderRefresh: Int?; let missingReason: String?
}
func cursorFact(_ pts: CMTime, ordinal: Int, segments: [SourceSegment], track: AVAssetTrack) -> CursorFact {
    guard let index=segments.firstIndex(where:{$0.asset.containsTime(pts)}) else {
        return CursorFact(ordinal:ordinal,requestedAssetPTS:Tick(pts),selectedSegment:nil,requestedMediaPTS:nil,matchedByOwnerMicroseconds:nil,clocks:[:],flags:[:],extents:[:],storageURL:nil,sampleIndexInChunk:nil,samplesRequiredForDecoderRefresh:nil,missingReason:"No occupied owner segment contains requested asset PTS")
    }
    let media=segments[index].mediaTime(ofAsset:pts)
    guard let cursor=track.makeSampleCursor(presentationTimeStamp:media) else {
        return CursorFact(ordinal:ordinal,requestedAssetPTS:Tick(pts),selectedSegment:index,requestedMediaPTS:Tick(media),matchedByOwnerMicroseconds:nil,clocks:[:],flags:[:],extents:[:],storageURL:nil,sampleIndexInChunk:nil,samplesRequiredForDecoderRefresh:nil,missingReason:"Native sample cursor unavailable")
    }
    let sync=cursor.currentSampleSyncInfo, dependency=cursor.currentSampleDependencyInfo
    let sample=cursor.currentSampleStorageRange, chunk=cursor.currentChunkStorageRange
    // currentSampleDuration is SDK decode duration, not an independent display-duration guarantee.
    return CursorFact(ordinal:ordinal,requestedAssetPTS:Tick(pts),selectedSegment:index,requestedMediaPTS:Tick(media),matchedByOwnerMicroseconds:microseconds(cursor.presentationTimeStamp)==microseconds(media),clocks:["mediaPTS":Tick(cursor.presentationTimeStamp),"mediaDTS":Tick(cursor.decodeTimeStamp),"decodeDuration":Tick(cursor.currentSampleDuration)],flags:["sampleIsFullSync":sync.sampleIsFullSync.boolValue,"sampleIsPartialSync":sync.sampleIsPartialSync.boolValue,"sampleIsDroppable":sync.sampleIsDroppable.boolValue,"sampleIndicatesWhetherItHasDependentSamples":dependency.sampleIndicatesWhetherItHasDependentSamples.boolValue,"sampleHasDependentSamples":dependency.sampleHasDependentSamples.boolValue,"sampleIndicatesWhetherItDependsOnOthers":dependency.sampleIndicatesWhetherItDependsOnOthers.boolValue,"sampleDependsOnOthers":dependency.sampleDependsOnOthers.boolValue,"sampleIndicatesWhetherItHasRedundantCoding":dependency.sampleIndicatesWhetherItHasRedundantCoding.boolValue,"sampleHasRedundantCoding":dependency.sampleHasRedundantCoding.boolValue],extents:["sample":StorageExtent(offset:sample.offset,length:sample.length),"chunk":StorageExtent(offset:chunk.offset,length:chunk.length)],storageURL:cursor.currentChunkStorageURL?.absoluteString,sampleIndexInChunk:cursor.currentSampleIndexInChunk,samplesRequiredForDecoderRefresh:cursor.samplesRequiredForDecoderRefresh,missingReason:nil)
}
struct OwnedEvidenceDestination {
    let root:URL; let failure:URL
    init(root:URL) throws {
        guard Darwin.mkdir(root.path,0o700)==0 else { throw ProbeFailure(message:"Exclusive evidence destination refused: errno \(errno)") }
        self.root=root; self.failure=root.appendingPathComponent("failure.json")
    }
}
final class ObserverEvidence: Sendable {
    let root: URL
    init(root: URL) throws {
        guard Darwin.mkdir(root.path,0o700)==0 else { throw ProbeFailure(message:"Exclusive observer directory refused: errno \(errno)") }
        self.root=root
    }
    func ingress(_ value:IngressObservation) throws {
        let url=root.appendingPathComponent("returned-ingress.jsonl")
        if !FileManager.default.fileExists(atPath:url.path) { try Data().write(to:url) }
        let output=try FileHandle(forWritingTo:url); defer { try? output.close() }
        try output.seekToEnd(); try output.write(contentsOf:JSONEncoder().encode(value)+Data([10]))
    }
    func preserve(mappings:[CameraFrameMapping], observations:Data, receipts:[IngressObservation], raw:URL) {
        var result=[String:String]()
        func attempt(_ label:String,_ body:() throws -> Void) { do { try body(); result[label]="saved" } catch { result[label]="failed: \(error)" } }
        attempt("accepted-mappings") { try save(mappings,root.appendingPathComponent("accepted-mappings.json")) }
        attempt("accepted-observations") { try observations.write(to:root.appendingPathComponent("timestamps.jsonl"),options:.atomic) }
        attempt("offered-receipts") { try save(receipts,root.appendingPathComponent("offered-receipts.json")) }
        if FileManager.default.fileExists(atPath:raw.path) {
            attempt("unverified-raw-prefix") {
                let before=try FileManager.default.attributesOfItem(atPath:raw.path)
                let input=try FileHandle(forReadingFrom:raw); defer { try? input.close() }
                let copy=try input.read(upToCount:2_097_152) ?? Data()
                try copy.write(to:root.appendingPathComponent("unverified-raw-prefix.bin"),options:.atomic)
                let after=try FileManager.default.attributesOfItem(atPath:raw.path)
                let metadata=["label":"Unverified live-writer byte prefix; not a verified complete MOV or physical sample proof","sourceBytesBefore":String(describing:before[.size]),"sourceBytesAfter":String(describing:after[.size]),"copiedBytes":String(copy.count),"capBytes":"2097152","sourceFileNumberBefore":String(describing:before[.systemFileNumber]),"sourceFileNumberAfter":String(describing:after[.systemFileNumber]),"sha256":SHA256.hash(data:copy).map{String(format:"%02x",$0)}.joined()]
                try save(metadata,root.appendingPathComponent("raw-prefix-label.json"))
            }
        } else { result["unverified-raw-prefix"]="absent before cleanup" }
        do { try save(result,root.appendingPathComponent("preservation.json")) }
        catch { try? FileHandle.standardError.write(contentsOf:Data("Failure evidence preservation failed: \(error)\n".utf8)) }
    }
}
func require(_ okay: Bool, _ message: String, _ operands:[String:String], evidence:ObserverEvidence) throws {
    if !okay {
        let record=try JSONSerialization.data(withJSONObject:["message":message,"operands":operands],options:.sortedKeys)
        try record.write(to:evidence.root.appendingPathComponent("failed-assertion.json"),options:.atomic)
        throw ProbeFailure(message:message)
    }
}
struct IngressObservation: Encodable { let offeredOrdinal:Int; let receipt:CaptureWriter.IngressReceipt; let cameraFrame:CameraFrameMapping? }
struct TupleDifference: Encodable { let ordinal:Int; let fields:[String]; let expected:Picture?; let actual:Picture? }
func differingFields(_ a:Picture,_ b:Picture)->[String] {
    var fields=[String]()
    func tick(_ name:String,_ x:Tick,_ y:Tick) {
        if x.value != y.value { fields.append(name+".value") }; if x.scale != y.scale { fields.append(name+".scale") }
        if x.epoch != y.epoch { fields.append(name+".epoch") }; if x.flags != y.flags { fields.append(name+".flags") }
    }
    if a.ordinal != b.ordinal { fields.append("ordinal") }; tick("pts",a.pts,b.pts); tick("digestPTS",a.digestPTS,b.digestPTS)
    if a.width != b.width { fields.append("width") }; if a.height != b.height { fields.append("height") }
    if let x=a.end,let y=b.end { tick("ownerComputedEnd",x,y) } else if a.end != b.end { fields.append("ownerComputedEnd.presence") }
    if a.bgra != b.bgra { fields.append("bgra") }
    return fields
}

func save<T: Encodable>(_ value: T, _ url: URL) throws {
    let e=JSONEncoder(); e.outputFormatting=[.prettyPrinted,.sortedKeys]
    try e.encode(value).write(to:url,options:.atomic)
}
// This observes complete atom extents only. Native owners interpret every sample clock.
func fragments(_ url: URL, evidence:ObserverEvidence) throws -> Int {
    guard FileManager.default.fileExists(atPath:url.path) else { return 0 }
    let sizeAttribute=try FileManager.default.attributesOfItem(atPath:url.path)[.size] as? NSNumber
    try require(sizeAttribute != nil,"raw size unavailable",["sizeAttribute":String(describing:sizeAttribute),"url":url.path],evidence:evidence)
    let size=sizeAttribute!.intValue
    try require(size <= 2_097_152,"raw output exceeds fixed 2 MiB cap",["observedBytes":String(size),"capBytes":"2097152"],evidence:evidence)
    let bytes=[UInt8](try Data(contentsOf:url)); var at=0; var media=false; var count=0
    func integer(_ offset:Int,_ n:Int)->UInt64 { bytes[offset..<offset+n].reduce(UInt64(0)){($0<<8)|UInt64($1)} }
    while at+8<=bytes.count {
        var size=integer(at,4); let kind=String(bytes:bytes[at+4..<at+8],encoding:.ascii) ?? "?"; var header=8
        if size==1 { if at+16>bytes.count { break }; size=integer(at+8,8); header=16 }
        if size==0 { break } // An open-ended box is never committed by this observer.
        try require(size>=UInt64(header),"invalid atom size",["offset":String(at),"declaredSize":String(size),"headerSize":String(header)],evidence:evidence)
        if size>UInt64(bytes.count-at) { break }
        if kind=="mdat" { media=true }
        else if (kind=="moov" || kind=="moof") && media { count+=1; media=false }
        at+=Int(size)
    }
    return count
}
func read(_ url: URL, phase: String, fragments: Int, evidence:ObserverEvidence) async throws -> Snapshot {
    let asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
    let tracks=try await asset.loadTracks(withMediaType:.video)
    try require(tracks.count==1,"physical reader requires one video track",["trackCount":String(tracks.count),"url":url.path,"phase":phase],evidence:evidence)
    let audio=try await asset.loadTracks(withMediaType:.audio)
    try require(audio.isEmpty,"unexpected audio",["audioCount":String(audio.count),"phase":phase],evidence:evidence)
    let track=tracks[0]; let scale=try await track.load(.naturalTimeScale)
    try require(scale==1_000_000,"native camera scale changed",["nativeScale":String(scale),"phase":phase],evidence:evidence)
    let duration=try await asset.load(.duration)
    try require(duration.isNumeric && duration > .zero,"fragment lacks positive native duration",["duration":String(describing:Tick(duration)),"phase":phase],evidence:evidence)
    let segments=SourceSegment.occupied(of:try await track.load(.segments))
    let reader=try AVAssetReader(asset:asset)
    let output=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
    output.alwaysCopiesSampleData=false; reader.add(output)
    reader.timeRange=CMTimeRange(start:.zero,duration:duration)
    defer { reader.cancelReading() }
    let assertionValue=reader.startReading(); try require(assertionValue,"reader failed to start: \(String(describing:reader.error))",["readerStatus":String(reader.status.rawValue),"readerError":String(describing:reader.error),"phase":phase],evidence:evidence)
    var rows=[Picture](); var facts=[CursorFact]()
    defer {
        try? save(Snapshot(phase:phase,completedFragments:fragments,nativeScale:scale,duration:Tick(duration),readerStatus:reader.status.rawValue,containsFragments:nil,canContainFragments:nil,pictures:rows,segmentBounds:segments.map(SegmentBounds.init),cursorFacts:facts),evidence.root.appendingPathComponent("partial-"+phase+"-"+String(fragments)+".json"))
    }
    while let sample=output.copyNextSampleBuffer() {
        try require(rows.count<240,"decoded ordinal exceeds fixed cap",["decodedCount":String(rows.count),"phase":phase],evidence:evidence)
        try require(sample.imageBuffer != nil,"decoded picture lacks pixels",["decodedPTS":String(describing:Tick(sample.presentationTimeStamp)),"ordinal":String(rows.count),"imageBufferPresent":String(sample.imageBuffer != nil)],evidence:evidence)
        let image=sample.imageBuffer!
        let width=CVPixelBufferGetWidth(image),height=CVPixelBufferGetHeight(image)
        try require(width==32 && height==16,"fixture dimensions changed",["width":String(width),"height":String(height),"ordinal":String(rows.count)],evidence:evidence)
        let lockResult=CVPixelBufferLockBaseAddress(image,.readOnly)
        defer { if lockResult==kCVReturnSuccess { CVPixelBufferUnlockBaseAddress(image,.readOnly) } }
        try require(lockResult==kCVReturnSuccess,"pixel lock failed",["lockResult":String(lockResult),"width":String(width),"height":String(height),"ordinal":String(rows.count)],evidence:evidence)
        var bytes=Data()
        if let base=CVPixelBufferGetBaseAddress(image) {
            let stride=CVPixelBufferGetBytesPerRow(image)
            for y in 0..<height { bytes.append(Data(bytes:base.advanced(by:y*stride),count:width*4)) }
        }
        try require(bytes.count==width*height*4,"incomplete visible BGRA",["byteCount":String(bytes.count),"width":String(width),"height":String(height),"actualBGRA":bytes.base64EncodedString(),"ordinal":String(rows.count)],evidence:evidence)
        let pts=sample.presentationTimeStamp
        let end=assetEnd(ofSamplePresentedAt:pts,in:segments,of:track)
        facts.append(cursorFact(pts,ordinal:rows.count,segments:segments,track:track))
        rows.append(Picture(ordinal:rows.count,pts:Tick(pts),digestPTS:Tick(CMTimeConvertScale(pts,timescale:scale,method:.roundHalfAwayFromZero)),width:width,height:height,end:end.map(Tick.init),bgra:bytes))
    }
    try require(reader.status == .completed,"reader terminal failure: \(reader.status.rawValue) \(String(describing:reader.error))",["readerStatus":String(reader.status.rawValue),"readerError":String(describing:reader.error),"phase":phase],evidence:evidence)
    return Snapshot(phase:phase,completedFragments:fragments,nativeScale:scale,duration:Tick(duration),readerStatus:reader.status.rawValue,containsFragments:try await asset.load(.containsFragments),canContainFragments:try await asset.load(.canContainFragments),pictures:rows,segmentBounds:segments.map(SegmentBounds.init),cursorFacts:facts)
}
func compare(_ prefix:[Picture],_ later:Snapshot, evidence:ObserverEvidence) throws {
    // These are the operands. Save them before even the count/endpoint preconditions.
    let name="comparison-"+later.phase+"-"+String(later.completedFragments)
    try save(prefix,evidence.root.appendingPathComponent(name+"-expected.json"))
    try save(later,evidence.root.appendingPathComponent(name+"-actual.json"))
    var changes=[TupleDifference]()
    for (index,picture) in prefix.enumerated() {
        if index>=later.pictures.count { changes.append(TupleDifference(ordinal:index,fields:["actual.presence"],expected:picture,actual:nil)); continue }
        let fields=differingFields(picture,later.pictures[index])
        if !fields.isEmpty { changes.append(TupleDifference(ordinal:index,fields:fields,expected:picture,actual:later.pictures[index])) }
    }
    try save(changes,evidence.root.appendingPathComponent(name+"-differences.json"))
    try require(!prefix.isEmpty && later.pictures.count>=prefix.count,"missing candidate prefix",["expectedCount":String(prefix.count),"actualCount":String(later.pictures.count)],evidence:evidence)
    for picture in prefix {
        try require(picture.end != nil,"candidate picture lacks owner-computed endpoint",["ordinal":String(picture.ordinal),"expectedOperand":name+"-expected.json"],evidence:evidence)
    }
    try require(changes.isEmpty,"candidate tuple differs: \(changes.map{String($0.ordinal)+":"+$0.fields.joined(separator:",")})",["differencesOperand":name+"-differences.json","actualOperand":name+"-actual.json","expectedOperand":name+"-expected.json"],evidence:evidence)
}
struct Verdict: Codable { let status:String; let committedPictures:Int; let offered:Int; let accepted:Int; let extensions:Int; let tail:String }
struct Observation: Encodable { let role="camera"; let disposition="accepted"; let cameraFrame:CameraFrameMapping }

@main struct PrefixObserver {
    @MainActor static func main() async {
        var ownership:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments
            let mode=args[1], fixture=URL(fileURLWithPath:args[2]), root=URL(fileURLWithPath:args[3])
            let owner=try OwnedEvidenceDestination(root:mode=="recover" ? root.appendingPathComponent("recovery-observer") : root)
            ownership=owner
            let evidence=try ObserverEvidence(root:owner.root.appendingPathComponent("observer-evidence"))
            if mode=="recover" {
                let first=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:root.appendingPathComponent("first.json")))
                let prefix=Array(first.pictures.dropLast())
                let result=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"interrupted-physical",fragments:try fragments(root.appendingPathComponent("camera/camera.raw.mov"),evidence:evidence),evidence:evidence)
                try save(result,owner.root.appendingPathComponent("recovered.json")); try compare(prefix,result,evidence:evidence)
                try save(Verdict(status:"pass",committedPictures:prefix.count,offered:210,accepted:result.pictures.count,extensions:result.completedFragments,tail:"First-snapshot final picture and every later picture are uncommitted; interrupted tail unverified."),owner.root.appendingPathComponent("recovery-verdict.json"))
                print("PASS interrupted committed-prefix equality"); return
            }
            let source=AVURLAsset(url:fixture)
            let inputTracks=try await source.loadTracks(withMediaType:.video)
            try require(inputTracks.count==1,"input requires one video track",["inputTracks":String(inputTracks.count),"fixture":fixture.path],evidence:evidence)
            let track=inputTracks[0]
            let inputReader=try AVAssetReader(asset:source)
            defer { inputReader.cancelReading() }
            let decoded=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
            inputReader.add(decoded); let assertionValue=inputReader.startReading(); try require(assertionValue,"input reader failed",["inputReaderStatus":String(inputReader.status.rawValue),"error":String(describing:inputReader.error)],evidence:evidence)
            var samples=[CMSampleBuffer]()
            while let sample=decoded.copyNextSampleBuffer() { samples.append(sample) }
            try require(inputReader.status == .completed && samples.count==3,"original input reader differs",["inputReaderStatus":String(inputReader.status.rawValue),"sampleCount":String(samples.count)],evidence:evidence)
            var mappings=[CameraFrameMapping](), observationBytes=Data(), receipts=[IngressObservation]()
            let writer=try CameraWriter(directory:root.appendingPathComponent("camera"),framesPerSecond:30)
            defer {
                evidence.preserve(mappings:mappings,observations:observationBytes,receipts:receipts,raw:root.appendingPathComponent("camera/camera.raw.mov"))
                writer.discard()
            }
            let anchor=CaptureHostTime.nowUs(); var clock=CaptureClock(); clock.start(at:anchor)
            let state=CaptureWriter.IngressState(clock:clock,accepting:true)
            var first:Snapshot?, second:Snapshot?; var lastCount=0
            let started=ContinuousClock.now
            for index in 0..<210 {
                let target=started.advanced(by:.nanoseconds(Int64(index)*1_000_000_000/30))
                if ContinuousClock.now<target { try await Task.sleep(until:target,clock:.continuous) }
                try require(started.duration(to:.now) < .seconds(15),"writer observation exceeded 15 seconds",["elapsedObservation":String(describing:started.duration(to:.now)),"offeredOrdinal":String(index)],evidence:evidence)
                let hosted=try CaptureClockIngress.retime(samples[index%3],to:CMTimeAdd(time(microseconds:anchor),CMTime(value:Int64(index),timescale:30)),duration:CMTime(value:1,timescale:30))
                let admission=try writer.append(hosted,state:state)
                let observedReceipt=IngressObservation(offeredOrdinal:index,receipt:admission.receipt,cameraFrame:admission.frame)
                receipts.append(observedReceipt)
                if let frame=admission.frame { mappings.append(frame); observationBytes.append(try JSONEncoder().encode(Observation(cameraFrame:frame))); observationBytes.append(10) }
                try evidence.ingress(observedReceipt)
                if index%3==0 {
                    let count=try fragments(root.appendingPathComponent("camera/camera.raw.mov"),evidence:evidence)
                    if count>lastCount {
                        let snapshot=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:first==nil ? "first-extension" : "later-extension",fragments:count,evidence:evidence)
                        try save(snapshot,evidence.root.appendingPathComponent("snapshot-"+snapshot.phase+"-"+String(count)+".json"))
                        try require(snapshot.canContainFragments == true && (first==nil || snapshot.containsFragments == true),"MOV extent not native fragment-capable/extended media",["canContainFragments":String(describing:snapshot.canContainFragments),"containsFragments":String(describing:snapshot.containsFragments),"fragmentCount":String(count)],evidence:evidence)
                        if first==nil {
                            try require(snapshot.pictures.count>1,"first fragment lacks a non-tail prefix",["decodedPictures":String(snapshot.pictures.count),"fragmentCount":String(count)],evidence:evidence)
                            first=snapshot; try save(snapshot,root.appendingPathComponent("first.json"))
                        } else {
                            try compare(Array(first!.pictures.dropLast()),snapshot,evidence:evidence)
                            second=snapshot; try save(snapshot,root.appendingPathComponent("extension-\(count).json"))
                        }
                        lastCount=count; print("EXTENSION \(count) decoded \(snapshot.pictures.count)")
                    }
                }
            }
            let feedEnd=started.advanced(by:.seconds(7))
            if ContinuousClock.now<feedEnd { try await Task.sleep(until:feedEnd,clock:.continuous) }
            // Observe only; never add frames or tune the fixed seven-second feed.
            while second==nil && started.duration(to:.now) < .seconds(15) {
                try await Task.sleep(for:.milliseconds(100))
                let count=try fragments(root.appendingPathComponent("camera/camera.raw.mov"),evidence:evidence)
                if count>lastCount {
                    let snapshot=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"later-extension",fragments:count,evidence:evidence)
                    try save(snapshot,evidence.root.appendingPathComponent("snapshot-"+snapshot.phase+"-"+String(count)+".json"))
                    try require(snapshot.canContainFragments == true && (first==nil || snapshot.containsFragments == true),"MOV extent not native fragment-capable/extended media",["canContainFragments":String(describing:snapshot.canContainFragments),"containsFragments":String(describing:snapshot.containsFragments),"fragmentCount":String(count)],evidence:evidence)
                    if first==nil { try require(snapshot.pictures.count>1,"first fragment lacks a non-tail prefix",["decodedPictures":String(snapshot.pictures.count),"fragmentCount":String(count)],evidence:evidence) }
                    if let first { try compare(Array(first.pictures.dropLast()),snapshot,evidence:evidence); second=snapshot }
                    else { first=snapshot; try save(snapshot,root.appendingPathComponent("first.json")) }
                    try save(snapshot,root.appendingPathComponent("extension-\(count).json")); lastCount=count
                }
            }
            try require(first != nil && second != nil && lastCount>=2,"fewer than two actual extensions within fixed bounds",["firstSaved":String(first != nil),"secondSaved":String(second != nil),"fragmentCount":String(lastCount)],evidence:evidence)
            let prefix=Array(first!.pictures.dropLast())
            try observationBytes.write(to:root.appendingPathComponent("timestamps.jsonl"))
            try save(mappings,root.appendingPathComponent("accepted-mappings.json"))
            if mode=="interrupt" {
                evidence.preserve(mappings:mappings,observations:observationBytes,receipts:receipts,raw:root.appendingPathComponent("camera/camera.raw.mov"))
                try save(Verdict(status:"ready-to-interrupt",committedPictures:prefix.count,offered:210,accepted:mappings.count,extensions:lastCount,tail:"First-snapshot final picture and all later pictures remain uncommitted."),root.appendingPathComponent("ready.json"))
                print("READY writer-active unclosed")
                while true { try await Task.sleep(for:.milliseconds(100)) }
            }
            clock.seal(at:anchor+7_000_000)
            let closed=await writer.close(clock:clock,failure:nil,observations:root.appendingPathComponent("timestamps.jsonl"))
            defer { closed.releaseJournal() }
            try require(closed.sealed && closed.failure==nil,"ordinary writer closure failed",["sealed":String(closed.sealed),"failure":String(describing:closed.failure)],evidence:evidence)
            let final=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"ordinary-closed",fragments:try fragments(root.appendingPathComponent("camera/camera.raw.mov"),evidence:evidence),evidence:evidence)
            try save(final,root.appendingPathComponent("closed.json")); try compare(prefix,final,evidence:evidence)
            try require(final.pictures.count==mappings.count,"closed physical/admission ordinal mismatch",["decodedPictures":String(final.pictures.count),"acceptedMappings":String(mappings.count)],evidence:evidence)
            for (mapping,picture) in zip(mappings,final.pictures) {
                let expected=try mapping.acquisitionRange(scale:final.nativeScale)
                try require(expected.start.value==picture.digestPTS.value && expected.start.timescale==picture.digestPTS.scale && expected.start.epoch==picture.digestPTS.epoch,"closed PTS/admission mismatch",["ordinal":String(mapping.ordinal),"expectedPTS":String(describing:Tick(expected.start)),"actualPTS":String(describing:picture.digestPTS)],evidence:evidence)
            }
            try save(Verdict(status:"pass",committedPictures:prefix.count,offered:210,accepted:mappings.count,extensions:lastCount,tail:"First-snapshot final picture and every later picture remain uncommitted by the prefix experiment."),root.appendingPathComponent("verdict.json"))
            print("PASS ordinary prefix extension and closure equality")
        } catch {
            if let owner=ownership {
                try? save(["status":"fail","error":String(describing:error)],owner.failure)
            }
            print("FAIL \(error)"); Darwin.exit(1)
        }
    }
}
