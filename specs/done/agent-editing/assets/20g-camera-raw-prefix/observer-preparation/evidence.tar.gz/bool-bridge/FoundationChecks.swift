import Foundation
import CoreMedia
import CryptoKit
@testable import ScreenRecorderCapture

@main struct FoundationChecks {
    static func main() throws {
        let root=try OwnedEvidenceDestination(root:URL(fileURLWithPath:CommandLine.arguments[1]))
        let conflict=root.root.appendingPathComponent("predecessor")
        try FileManager.default.createDirectory(at:conflict,withIntermediateDirectories:false)
        let sentinel=Data("PREDECESSOR MUST STAY INTACT".utf8)
        try sentinel.write(to:conflict.appendingPathComponent("failure.json"))
        var conflictingOwner:OwnedEvidenceDestination?
        do { conflictingOwner=try OwnedEvidenceDestination(root:conflict) }
        catch { if let owner=conflictingOwner { try save(["unexpected":"owned"],owner.failure) } }
        guard conflictingOwner==nil, try Data(contentsOf:conflict.appendingPathComponent("failure.json"))==sentinel,
            !FileManager.default.fileExists(atPath:conflict.appendingPathComponent("observer-evidence").path)
        else { throw ProbeFailure(message:"exclusive destination modified predecessor") }

        let owner=try OwnedEvidenceDestination(root:root.root.appendingPathComponent("tuple-fault"))
        let evidence=try ObserverEvidence(root:owner.root.appendingPathComponent("observer-evidence"))
        let raw=owner.root.appendingPathComponent("AUTHORED-NONMEDIA-BYTES.bin")
        try Data(repeating:0x5a,count:2_097_169).write(to:raw)
        let sourceAttributes=try FileManager.default.attributesOfItem(atPath:raw.path)
        let zero=CMTime(value:0,timescale:1_000_000), end=CMTime(value:33_333,timescale:1_000_000)
        let mapping=CameraFrameMapping(ordinal:0,start:CaptureRationalTime(zero),nominalEnd:CaptureRationalTime(end))
        let observations=try JSONEncoder().encode(Observation(cameraFrame:mapping))+Data([10])
        let receipts=[IngressObservation(offeredOrdinal:0,receipt:CaptureWriter.IngressReceipt(disposition:"accepted",sourceUs:0),cameraFrame:mapping)]
        let original=Picture(ordinal:0,pts:Tick(zero),digestPTS:Tick(zero),width:32,height:16,end:Tick(end),bgra:Data(repeating:0x11,count:2048))
        var pixels=original.bgra; pixels[17]=0x22
        let changed=Picture(ordinal:0,pts:original.pts,digestPTS:original.digestPTS,width:32,height:16,end:Tick(CMTime(value:33_334,timescale:1_000_000)),bgra:pixels)
        let actual=Snapshot(phase:"AUTHORED-FILESYSTEM-FAULT",completedFragments:2,nativeScale:1_000_000,duration:Tick(end),readerStatus:2,containsFragments:nil,canContainFragments:nil,pictures:[changed],segmentBounds:[],cursorFacts:[])
        var caught=false
        do {
            defer {
                evidence.preserve(mappings:[mapping],observations:observations,receipts:receipts,raw:raw)
                try? FileManager.default.removeItem(at:raw) // fake cleanup, never CameraWriter
            }
            try compare([original],actual,evidence:evidence)
        } catch {
            guard let failure=error as? ProbeFailure,
                failure.message=="candidate tuple differs: [\"0:ownerComputedEnd.value,bgra\"]"
            else { throw error }
            caught=true
            try save(["injectedError":String(describing:error)],owner.failure)
        }
        guard caught else { throw ProbeFailure(message:"observer accepted injected mismatch") }
        let name="comparison-AUTHORED-FILESYSTEM-FAULT-2"
        let decoded=try JSONSerialization.jsonObject(with:Data(contentsOf:evidence.root.appendingPathComponent(name+"-differences.json"))) as! [[String:Any]]
        guard decoded.first?["fields"] as? [String]==["ownerComputedEnd.value","bgra"],
            try Data(contentsOf:evidence.root.appendingPathComponent("unverified-raw-prefix.bin")).count==2_097_152,
            !FileManager.default.fileExists(atPath:raw.path),
            try Data(contentsOf:evidence.root.appendingPathComponent("timestamps.jsonl"))==observations
        else { throw ProbeFailure(message:"actual observer lost injected failure operands/inventory/capped bytes") }
        let expected=try JSONDecoder().decode([Picture].self,from:Data(contentsOf:evidence.root.appendingPathComponent(name+"-expected.json")))
        let retained=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:evidence.root.appendingPathComponent(name+"-actual.json")))
        let mappings=try JSONDecoder().decode([CameraFrameMapping].self,from:Data(contentsOf:evidence.root.appendingPathComponent("accepted-mappings.json")))
        guard expected==[original], retained.pictures==[changed], mappings.count==1,
            mappings[0].ordinal==0,mappings[0].start.value==0,mappings[0].nominalEnd.value==33_333
        else { throw ProbeFailure(message:"saved operands/admission values differ") }
        let offered=try JSONSerialization.jsonObject(with:Data(contentsOf:evidence.root.appendingPathComponent("offered-receipts.json"))) as! NSArray
        let expectedOffered=try JSONSerialization.jsonObject(with:JSONEncoder().encode(receipts)) as! NSArray
        let copied=try Data(contentsOf:evidence.root.appendingPathComponent("unverified-raw-prefix.bin"))
        let label=try JSONDecoder().decode([String:String].self,from:Data(contentsOf:evidence.root.appendingPathComponent("raw-prefix-label.json")))
        guard offered==expectedOffered, copied==Data(repeating:0x5a,count:2_097_152),
            label["label"]=="Unverified live-writer byte prefix; not a verified complete MOV or physical sample proof",
            label["capBytes"]=="2097152",label["copiedBytes"]=="2097152",
            label["sourceBytesBefore"]==String(describing:sourceAttributes[.size]),label["sourceBytesAfter"]==String(describing:sourceAttributes[.size]),
            label["sourceFileNumberBefore"]==String(describing:sourceAttributes[.systemFileNumber]),label["sourceFileNumberAfter"]==String(describing:sourceAttributes[.systemFileNumber]),
            label["sha256"]==SHA256.hash(data:copied).map{String(format:"%02x",$0)}.joined()
        else { throw ProbeFailure(message:"offered values/capped bytes/unverified label differ") }
        let positive=Snapshot(phase:"SAME-OPERANDS-CONTROL",completedFragments:2,nativeScale:1_000_000,duration:Tick(end),readerStatus:2,containsFragments:nil,canContainFragments:nil,pictures:[original],segmentBounds:[],cursorFacts:[])
        try compare([original],positive,evidence:evidence)
        print("PASS actual observer Foundation/filesystem fault and predecessor refusal; no native writer/reader called")
    }
}
