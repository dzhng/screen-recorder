import json,pathlib,sys
root=pathlib.Path(sys.argv[1])
def load(p):return json.loads((root/p).read_text())
def check():
    processes=load('processes.json')['processes']
    assert processes and all(p['terminal'] for p in processes)
    ordinary=load('ordinary/verdict.json'); assert ordinary['status']=='pass'
    first=load('ordinary/first.json'); prefix=first['pictures'][:-1]; assert prefix
    assert all(p['end'] is not None for p in prefix)
    later=[json.loads(p.read_text()) for p in (root/'ordinary').glob('extension-*.json')]
    assert later and all(p['completedFragments']>first['completedFragments'] for p in later)
    for snap in later+[load('ordinary/closed.json')]:
        assert snap['readerStatus']==2 and snap['nativeScale']==1_000_000
        assert snap['pictures'][:len(prefix)]==prefix
    closed=load('ordinary/closed.json'); mapping=load('ordinary/accepted-mappings.json')
    assert len(closed['pictures'])==len(mapping)==ordinary['accepted']
    assert ordinary['offered']==210 and ordinary['extensions']>=2
    for index,(m,p) in enumerate(zip(mapping,closed['pictures'])):
        assert m['ordinal']==p['ordinal']==index
        numerator=m['start']['value']*1_000_000; denominator=m['start']['timescale']
        expected=(2*numerator+denominator)//(2*denominator)
        assert p['digestPTS']['value']==expected
        assert p['width']==32 and p['height']==16
    assert load('controller-verdict.json')['status']=='pass'
    ready=load('interrupted/ready.json'); assert ready['status']=='ready-to-interrupt'
    killed=[p for p in processes if p['label']=='interrupt']; assert len(killed)==1 and killed[0]['exitCode']==-9
    interrupted=load('interrupted/first.json')['pictures'][:-1]; assert interrupted
    extensions=[json.loads(p.read_text()) for p in (root/'interrupted').glob('extension-*.json')]
    assert extensions
    for snap in extensions+[load('interrupted/recovered.json')]:assert snap['pictures'][:len(interrupted)]==interrupted
    assert load('interrupted/recovery-verdict.json')['status']=='pass'
    assert [p['label'] for p in processes]==['compile','ordinary','interrupt','recover']
    assert all(p['exitCode']==0 for p in processes if p['label']!='interrupt')
    print('PASS saved complete raw tuples, actual extensions/closure, interruption and all process terminals')
try: check()
except BaseException as e: print('FAIL saved acceptance:',repr(e));sys.exit(1)
