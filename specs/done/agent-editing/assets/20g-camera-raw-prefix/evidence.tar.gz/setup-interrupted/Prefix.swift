@preconcurrency import AVFoundation
import Foundation
import Darwin
@testable import ScreenRecorderCapture
import ScreenRecorderMedia

struct ProbeFailure: Error { let message: String }
func require(_ okay: Bool, _ message: String) throws { if !okay { throw ProbeFailure(message: message) } }
struct Tick: Codable, Equatable {
    let value: Int64; let scale: Int32; let epoch: Int64; let flags: UInt32
    init(_ t: CMTime) { value=t.value; scale=t.timescale; epoch=t.epoch; flags=t.flags.rawValue }
}
struct Picture: Codable, Equatable {
    let ordinal: Int; let pts: Tick; let digestPTS: Tick; let width: Int; let height: Int
    let end: Tick?; let bgra: Data
}
struct Snapshot: Codable {
    let phase: String; let completedFragments: Int; let nativeScale: Int32
    let duration: Tick; let readerStatus: Int; let containsFragments: Bool; let canContainFragments: Bool
    let pictures: [Picture]
}
func save<T: Encodable>(_ value: T, _ url: URL) throws {
    let e=JSONEncoder(); e.outputFormatting=[.prettyPrinted,.sortedKeys]
    try e.encode(value).write(to:url,options:.atomic)
}
// This observes complete atom extents only. Native owners interpret every sample clock.
func fragments(_ url: URL) throws -> Int {
    guard FileManager.default.fileExists(atPath:url.path) else { return 0 }
    let size=(try FileManager.default.attributesOfItem(atPath:url.path)[.size] as! NSNumber).intValue
    try require(size <= 2_097_152,"raw output exceeds fixed 2 MiB cap")
    let bytes=[UInt8](try Data(contentsOf:url)); var at=0; var media=false; var count=0
    func integer(_ offset:Int,_ n:Int)->UInt64 { bytes[offset..<offset+n].reduce(UInt64(0)){($0<<8)|UInt64($1)} }
    while at+8<=bytes.count {
        var size=integer(at,4); let kind=String(bytes:bytes[at+4..<at+8],encoding:.ascii) ?? "?"; var header=8
        if size==1 { if at+16>bytes.count { break }; size=integer(at+8,8); header=16 }
        if size==0 { break } // An open-ended box is never committed by this observer.
        try require(size>=UInt64(header),"invalid atom size")
        if size>UInt64(bytes.count-at) { break }
        if kind=="mdat" { media=true }
        else if (kind=="moov" || kind=="moof") && media { count+=1; media=false }
        at+=Int(size)
    }
    return count
}
func read(_ url: URL, phase: String, fragments: Int) async throws -> Snapshot {
    let asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
    let tracks=try await asset.loadTracks(withMediaType:.video)
    try require(tracks.count==1,"physical reader requires one video track")
    try require(try await asset.loadTracks(withMediaType:.audio).isEmpty,"unexpected audio")
    let track=tracks[0]; let scale=try await track.load(.naturalTimeScale)
    try require(scale==1_000_000,"native camera scale changed")
    let duration=try await asset.load(.duration)
    try require(duration.isNumeric && duration > .zero,"fragment lacks positive native duration")
    let segments=SourceSegment.occupied(of:try await track.load(.segments))
    let reader=try AVAssetReader(asset:asset)
    let output=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
    output.alwaysCopiesSampleData=false; reader.add(output)
    reader.timeRange=CMTimeRange(start:.zero,duration:duration)
    defer { reader.cancelReading() }
    try require(reader.startReading(),"reader failed to start: \(String(describing:reader.error))")
    var rows=[Picture]()
    while let sample=output.copyNextSampleBuffer() {
        try require(rows.count<240,"decoded ordinal exceeds fixed cap")
        guard let image=sample.imageBuffer else { throw ProbeFailure(message:"decoded picture lacks pixels") }
        let width=CVPixelBufferGetWidth(image),height=CVPixelBufferGetHeight(image)
        try require(width==32 && height==16,"fixture dimensions changed")
        try require(CVPixelBufferLockBaseAddress(image,.readOnly)==kCVReturnSuccess,"pixel lock failed")
        var bytes=Data()
        if let base=CVPixelBufferGetBaseAddress(image) {
            let stride=CVPixelBufferGetBytesPerRow(image)
            for y in 0..<height { bytes.append(Data(bytes:base.advanced(by:y*stride),count:width*4)) }
        }
        CVPixelBufferUnlockBaseAddress(image,.readOnly)
        try require(bytes.count==width*height*4,"incomplete visible BGRA")
        let pts=sample.presentationTimeStamp
        let end=assetEnd(ofSamplePresentedAt:pts,in:segments,of:track)
        rows.append(Picture(ordinal:rows.count,pts:Tick(pts),digestPTS:Tick(CMTimeConvertScale(pts,timescale:scale,method:.roundHalfAwayFromZero)),width:width,height:height,end:end.map(Tick.init),bgra:bytes))
    }
    try require(reader.status == .completed,"reader terminal failure: \(reader.status.rawValue) \(String(describing:reader.error))")
    return Snapshot(phase:phase,completedFragments:fragments,nativeScale:scale,duration:Tick(duration),readerStatus:reader.status.rawValue,containsFragments:try await asset.load(.containsFragments),canContainFragments:try await asset.load(.canContainFragments),pictures:rows)
}
func compare(_ prefix:[Picture],_ later:Snapshot) throws {
    try require(!prefix.isEmpty && later.pictures.count>=prefix.count,"missing committed prefix")
    for (index,picture) in prefix.enumerated() {
        try require(picture.end != nil,"committed picture lacks native endpoint")
        try require(picture == later.pictures[index],"committed tuple differs at ordinal \(index)")
    }
}
struct Verdict: Codable { let status:String; let committedPictures:Int; let offered:Int; let accepted:Int; let extensions:Int; let tail:String }
struct Observation: Encodable { let role="camera"; let disposition="accepted"; let cameraFrame:CameraFrameMapping }

@main struct PrefixProbe {
    @MainActor static func main() async {
        do {
            let args=CommandLine.arguments
            let mode=args[1], fixture=URL(fileURLWithPath:args[2]), root=URL(fileURLWithPath:args[3])
            if mode=="recover" {
                let first=try JSONDecoder().decode(Snapshot.self,from:Data(contentsOf:root.appendingPathComponent("first.json")))
                let prefix=Array(first.pictures.dropLast())
                let result=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"interrupted-physical",fragments:try fragments(root.appendingPathComponent("camera/camera.raw.mov")))
                try save(result,root.appendingPathComponent("recovered.json")); try compare(prefix,result)
                try save(Verdict(status:"pass",committedPictures:prefix.count,offered:210,accepted:result.pictures.count,extensions:result.completedFragments,tail:"First-snapshot final picture and every later picture are uncommitted; interrupted tail unverified."),root.appendingPathComponent("recovery-verdict.json"))
                print("PASS interrupted committed-prefix equality"); return
            }
            try FileManager.default.createDirectory(at:root,withIntermediateDirectories:false)
            let source=AVURLAsset(url:fixture), track=try await source.loadTracks(withMediaType:.video).first!
            let inputReader=try AVAssetReader(asset:source)
            let decoded=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
            inputReader.add(decoded); try require(inputReader.startReading(),"input reader failed")
            var samples=[CMSampleBuffer]()
            while let sample=decoded.copyNextSampleBuffer() { samples.append(sample) }
            try require(inputReader.status == .completed && samples.count==3,"original input reader differs")
            inputReader.cancelReading()
            let writer=try CameraWriter(directory:root.appendingPathComponent("camera"),framesPerSecond:30)
            defer { writer.discard() }
            let anchor=CaptureHostTime.nowUs(); var clock=CaptureClock(); clock.start(at:anchor)
            let state=CaptureWriter.IngressState(clock:clock,accepting:true)
            var mappings=[CameraFrameMapping](), observationBytes=Data()
            var first:Snapshot?, second:Snapshot?; var lastCount=0
            let started=ContinuousClock.now
            for index in 0..<210 {
                let target=started.advanced(by:.nanoseconds(Int64(index)*1_000_000_000/30))
                if ContinuousClock.now<target { try await Task.sleep(until:target,clock:.continuous) }
                try require(started.duration(to:.now) < .seconds(15),"writer observation exceeded 15 seconds")
                let hosted=try CaptureClockIngress.retime(samples[index%3],to:CMTimeAdd(time(microseconds:anchor),CMTime(value:Int64(index),timescale:30)),duration:CMTime(value:1,timescale:30))
                let admission=try writer.append(hosted,state:state)
                if let frame=admission.frame { mappings.append(frame); observationBytes.append(try JSONEncoder().encode(Observation(cameraFrame:frame))); observationBytes.append(10) }
                if index%3==0 {
                    let count=try fragments(root.appendingPathComponent("camera/camera.raw.mov"))
                    if count>lastCount {
                        let snapshot=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:first==nil ? "first-extension" : "later-extension",fragments:count)
                        try require(snapshot.canContainFragments && (first==nil || snapshot.containsFragments),"MOV extent not native fragment-capable/extended media")
                        if first==nil {
                            try require(snapshot.pictures.count>1,"first fragment lacks a non-tail prefix")
                            first=snapshot; try save(snapshot,root.appendingPathComponent("first.json"))
                        } else {
                            try compare(Array(first!.pictures.dropLast()),snapshot)
                            second=snapshot; try save(snapshot,root.appendingPathComponent("extension-\(count).json"))
                        }
                        lastCount=count; print("EXTENSION \(count) decoded \(snapshot.pictures.count)")
                    }
                }
            }
            let feedEnd=started.advanced(by:.seconds(7))
            if ContinuousClock.now<feedEnd { try await Task.sleep(until:feedEnd,clock:.continuous) }
            // Observe only; never add frames or tune the fixed seven-second feed.
            while second==nil && started.duration(to:.now) < .seconds(15) {
                try await Task.sleep(for:.milliseconds(100))
                let count=try fragments(root.appendingPathComponent("camera/camera.raw.mov"))
                if count>lastCount {
                    let snapshot=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"later-extension",fragments:count)
                    if let first { try compare(Array(first.pictures.dropLast()),snapshot); second=snapshot }
                    else { first=snapshot; try save(snapshot,root.appendingPathComponent("first.json")) }
                    try save(snapshot,root.appendingPathComponent("extension-\(count).json")); lastCount=count
                }
            }
            try require(first != nil && second != nil && lastCount>=2,"fewer than two actual extensions within fixed bounds")
            let prefix=Array(first!.pictures.dropLast())
            try observationBytes.write(to:root.appendingPathComponent("timestamps.jsonl"))
            try save(mappings,root.appendingPathComponent("accepted-mappings.json"))
            if mode=="interrupt" {
                try save(Verdict(status:"ready-to-interrupt",committedPictures:prefix.count,offered:210,accepted:mappings.count,extensions:lastCount,tail:"First-snapshot final picture and all later pictures remain uncommitted."),root.appendingPathComponent("ready.json"))
                print("READY writer-active unclosed")
                while true { try await Task.sleep(for:.milliseconds(100)) }
            }
            clock.seal(at:anchor+7_000_000)
            let closed=await writer.close(clock:clock,failure:nil,observations:root.appendingPathComponent("timestamps.jsonl"))
            defer { closed.releaseJournal() }
            try require(closed.sealed && closed.failure==nil,"ordinary writer closure failed")
            let final=try await read(root.appendingPathComponent("camera/camera.raw.mov"),phase:"ordinary-closed",fragments:try fragments(root.appendingPathComponent("camera/camera.raw.mov")))
            try save(final,root.appendingPathComponent("closed.json")); try compare(prefix,final)
            try require(final.pictures.count==mappings.count,"closed physical/admission ordinal mismatch")
            for (mapping,picture) in zip(mappings,final.pictures) {
                let expected=try mapping.acquisitionRange(scale:final.nativeScale)
                try require(expected.start.value==picture.digestPTS.value && expected.start.timescale==picture.digestPTS.scale && expected.start.epoch==picture.digestPTS.epoch,"closed PTS/admission mismatch")
            }
            try save(Verdict(status:"pass",committedPictures:prefix.count,offered:210,accepted:mappings.count,extensions:lastCount,tail:"First-snapshot final picture and every later picture remain uncommitted by the prefix experiment."),root.appendingPathComponent("verdict.json"))
            print("PASS ordinary prefix extension and closure equality")
        } catch {
            let args=CommandLine.arguments
            if args.count>3 {
                try? save(["status":"fail","error":String(describing:error)],URL(fileURLWithPath:args[3]).appendingPathComponent("failure.json"))
            }
            print("FAIL \(error)"); Darwin.exit(1)
        }
    }
}
