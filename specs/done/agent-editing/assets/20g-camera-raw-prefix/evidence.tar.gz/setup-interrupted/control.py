import json, pathlib, subprocess, time, datetime, os, signal, hashlib, sys
root=pathlib.Path('/tmp/screenrec-20g-raw-prefix')
plan=json.loads((root/'plan.json').read_text())
records=[]; live=None; phase=time.monotonic()
def write():
    (root/'processes.json').write_text(json.dumps({'phaseBoundSeconds':180,'elapsedSeconds':time.monotonic()-phase,'processes':records},indent=2)+'\n')
def run(label,argv,bound,interrupt=False):
    global live
    bound=min(bound,180-(time.monotonic()-phase))
    if bound<=0: raise RuntimeError('phase deadline')
    with (root/(label+'.stdout')).open('wb') as out,(root/(label+'.stderr')).open('wb') as err:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        live=p; start=time.monotonic()
        record={'label':label,'argv':argv,'pid':p.pid,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':bound,'terminal':False}
        records.append(record); write()
        try:
            if interrupt:
                ready=root/'interrupted/ready.json'
                while p.poll() is None and not ready.exists() and time.monotonic()-start<bound: time.sleep(.02)
                if not ready.exists(): raise RuntimeError('interrupt prerequisite not reached')
                if json.loads(ready.read_text())['status']!='ready-to-interrupt': raise RuntimeError('bad ready verdict')
                record['signal']='SIGKILL before CameraWriter.close'; record['ready']=json.loads(ready.read_text())
                os.killpg(p.pid,signal.SIGKILL)
                p.wait(timeout=min(5,max(.01,bound-(time.monotonic()-start))))
            else: p.wait(timeout=bound)
        except BaseException as error:
            record['controllerFailure']=str(error)
            if p.poll() is None: os.killpg(p.pid,signal.SIGKILL)
            p.wait(timeout=5)
            raise
        finally:
            record.update(terminal=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start)
            live=None; write()
        expected=-signal.SIGKILL if interrupt else 0
        if p.returncode!=expected: raise RuntimeError(f'{label} exit {p.returncode}, expected {expected}')
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path'])
        if p.stat().st_size!=pin['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=pin['sha256']: raise RuntimeError('changed preflight pin '+str(p))
    run('compile',plan['compile'],150)
    exe=root/'prefix-probe'
    (root/'executable.json').write_text(json.dumps({'path':str(exe),'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n')
    run('ordinary',plan['ordinary'],15)
    if json.loads((root/'ordinary/verdict.json').read_text())['status']!='pass': raise RuntimeError('ordinary prerequisite fails')
    run('interrupt',plan['interrupt'],15,True)
    run('recover',plan['recover'],15)
    (root/'controller-verdict.json').write_text(json.dumps({'status':'pass','scope':'tiny raw committed-prefix ordinary extension/closure and distinct interruption physical-reader only'},indent=2)+'\n')
except BaseException as error:
    (root/'controller-verdict.json').write_text(json.dumps({'status':'fail','error':str(error),'interruptedCaseAuthorizedOnlyAfterOrdinaryPass':True},indent=2)+'\n')
    print('FAIL',error); sys.exit(1)
finally: write()
