import datetime, hashlib, json, os, pathlib, selectors, signal, subprocess, sys, time
root=pathlib.Path('/tmp/screenrec-20g-raw-prefix/compile-diagnostic')
plan=json.loads((root/'plan.json').read_text()); record={}; live=None; phaseStarted=time.monotonic()

def cache_inventory():
    cache=pathlib.Path(plan['moduleCache'])
    rows=[]
    for path in sorted(cache.rglob('*')):
        if path.is_file():
            data=path.read_bytes(); st=path.stat()
            rows.append({'path':str(path.relative_to(cache)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mtimeNs':st.st_mtime_ns,'inode':st.st_ino,'mode':oct(st.st_mode & 0o777),'uid':st.st_uid})
    return {'root':str(cache),'files':rows,'totalBytes':sum(p['bytes'] for p in rows)}

def persist(): (root/'process.json').write_text(json.dumps(record,indent=2)+'\n')
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path'])
        assert p.stat().st_size==pin['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256'],str(p)
    before=cache_inventory(); (root/'cache-before.json').write_text(json.dumps(before,indent=2)+'\n')
    with (root/'compile.stdout').open('wb') as out,(root/'compile.stderr').open('wb') as err:
        p=subprocess.Popen(plan['compile'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        live=p; started=time.monotonic()
        record={'label':'compile-only-diagnostic','argv':plan['compile'],'pid':p.pid,'controllerPid':os.getpid(),'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':150,'stdioCapBytes':1048576,'terminal':False}
        persist()
        streams=selectors.DefaultSelector();streams.register(p.stdout,selectors.EVENT_READ,('stdout',out));streams.register(p.stderr,selectors.EVENT_READ,('stderr',err)); sizes={'stdout':0,'stderr':0}
        try:
            while streams.get_map() or p.poll() is None:
                if time.monotonic()-phaseStarted>150: raise RuntimeError('compile-only fixed deadline')
                for key,_ in streams.select(.02):
                    chunk=os.read(key.fileobj.fileno(),65536); name,destination=key.data
                    if not chunk: streams.unregister(key.fileobj);key.fileobj.close();continue
                    left=1048576-sizes[name];destination.write(chunk[:left]);destination.flush();sizes[name]+=min(left,len(chunk))
                    if len(chunk)>left: raise RuntimeError(name+' fixed log cap')
            p.wait()
        except BaseException as error:
            record['failure']=repr(error)
            if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
            p.wait(timeout=5); raise
        finally:
            streams.close()
            for pipe in [p.stdout,p.stderr]:
                if not pipe.closed:pipe.close()
            record.update(terminal=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-started,totalPhaseElapsedSeconds=time.monotonic()-phaseStarted,stdioBytes=sizes)
            live=None;persist()
        if p.returncode!=0: raise RuntimeError('compiler exited '+str(p.returncode))
    exe=pathlib.Path(plan['output'])
    record['binary']={'path':str(exe),'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
    persist();print('PASS compile-only; binary retained and never invoked')
except BaseException as error:
    (root/'failure.json').write_text(json.dumps({'error':repr(error),'mediaDispatched':False},indent=2)+'\n');print('FAIL',error);sys.exit(1)
finally:
    (root/'cache-after.json').write_text(json.dumps(cache_inventory(),indent=2)+'\n')
