from pathlib import Path
import json,hashlib,shutil
base=Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002/retained-camera-picture-correspondence');old=base/'current-binding-execution';r=base/'current-binding-ffclock-successor';r.mkdir(mode=0o700)
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
plan={'status':'FIXED BEFORE EXECUTION','correction':'Use observed FF preceding AU packet PTS for locator; packet-count end avoids native-asset clock and endpoint inclusion mistakes. Original failed interval frozen, not widened or repeated.','firstFailure':pin(old/'report.json'),'originalPlan':pin(base/'current-binding-preparation/plan.json'),'interval':'83.652853%+#64','nativeFacts':str(old/'native'),'nativeRegeneration':False,'packetCap':64,'packetPayloadBytesCap':16777216,'stdioBytesCap':2097152,'ffprobeDecodedPicturesCap':64,'ffmpegDecodedPicturesCap':64,'combinedDecodedPicturesCap':128,'sharedDataDeadlineSeconds':30,'uniqueFrameGate':'All3complete byte joins then one actual decoded frame pts,pkt_pos,pkt_size matching target packet. No best_effort,pkt_dts,filterPTS,ordinal fallback.','fullPNG':'ONEfull1920x1080RGB24target only, same current owner; completeRGBAzero tolerance against preservedconfirm01.','historicalProducerIdentity':'Unavailable; not reconstructed','stopping':'First failure; no retry,widening,native rerun or second picture'}
(r/'plan.json').write_text(json.dumps(plan,indent=2));shutil.copyfile(old/'tool-authority.json',r/'tool-authority.json')
original=json.loads((old/'before-pins.json').read_text()); extra=[old/'report.json',old/'manifest.json',old/'closure.json',old/'native/access-units.json',old/'native/generated-buffer.json',old/'native/segments.json',old/'native/target-clock.json',old/'native/target.au',old/'native/preceding.au',old/'native/following.au',r/'plan.json']
(r/'before-pins.json').write_text(json.dumps(original+[pin(p) for p in extra],indent=2))
s=(old/'data.py').read_text();s=s.replace("source=Path(plan['target']['input']);ffprobe=plan['toolPaths']['ffprobe'];ffmpeg=plan['toolPaths']['ffmpeg'];deadline=None", "source=Path(plan['target']['input']);ffprobe=plan['toolPaths']['ffprobe'];ffmpeg=plan['toolPaths']['ffmpeg'];deadline=None\nold=base/'current-binding-execution'\nfixed=json.loads((r/'plan.json').read_text())")
s=s.replace("'scope':'ONE current encoded-AU to packet to decoded-picture clock/content binding; original nativeRGB RED unchanged; missing historical producer identity not reconstructed'", "'scope':'CORRECTED FF-clock/count locator; real decoded frame position+size+PTS gate before one PNG; original failed interval and nativeRGB RED unchanged' ")
s=s.replace("report['nativeBinary']=json.loads((r/'executed-binary.json').read_text());assert pin(report['nativeBinary']['path'])==report['nativeBinary']", "report['nativeEvidenceReused']=str(old/'native');report['fixedPlan']=fixed")
s=s.replace("run([str(r/'target-probe'),str(r/'native'),str(source)],'native')\n units=json.loads((r/'native/access-units.json').read_text())", "units=json.loads((old/'native/access-units.json').read_text())")
s=s.replace("packets=[];stream=None;packetBytes=0", "packets=[];frames=[];stream=None;packetBytes=0")
s=s.replace("assert len(packets)<=256 and packetBytes<=16_777_216", "assert len(packets)<=64 and packetBytes<=16_777_216")
s=s.replace("elif kind=='stream':stream=x", "elif kind=='frame':\n   frames.append(x);assert len(frames)<=64,'FFprobe decoded picture cap'\n  elif kind=='stream':stream=x")
s=s.replace("f'{float(start):.6f}%{float(end):.6f}','-show_packets','-show_streams'", "fixed['interval'],'-show_packets','-show_frames','-show_streams'")
s=s.replace("packet=pts,dts,duration,size,pos,flags,data_hash:stream=", "packet=pts,dts,duration,size,pos,flags,data_hash:frame=media_type,pts,pkt_dts,pkt_pos,pkt_size,width,height,pix_fmt,key_frame,best_effort_timestamp:stream=")
s=s.replace("{'stream':stream,'packets':packets,'payloadBytes':packetBytes}", "{'stream':stream,'packets':packets,'frames':frames,'payloadBytes':packetBytes}")
s=s.replace("report['packetPayloadBytes']=packetBytes;save()", "report['packetPayloadBytes']=packetBytes;report['ffprobeDecodedFrameCount']=len(frames);report['ffprobeFrames']=frames;save()")
needle="tb=Fraction(stream['time_base']);beforePTS=int(joined['preceding']['pts']);afterPTS=int(joined['following']['pts']);assert beforePTS<targetPTS<afterPTS"
replace=needle+"\n matchedFrames=[f for f in frames if f.get('pts')==str(targetPTS) and f.get('pkt_pos')==joined['target']['pos'] and f.get('pkt_size')==joined['target']['size']]\n report['directFrameMatches']=matchedFrames;save()\n assert len(matchedFrames)==1 and sum(f.get('pts')==str(targetPTS) for f in frames)==1,'Usable unique real decoded frame pts+pkt_pos+pkt_size correspondence required BEFORE PNG'\n assert matchedFrames[0].get('media_type')=='video' and (matchedFrames[0].get('width'),matchedFrames[0].get('height'))==('1920','1080'),'Full direct frame geometry required'"
assert needle in s;s=s.replace(needle,replace)
s=s.replace("'frameClockOwner':'showinfo AVFrame/filter PTS under copyts; exact equality to the unique byte-bound current packet PTS; no best_effort field or ordinal selection','packetPositionOnFrame':'not exposed by current AVFrame header; no claim of frame packet-position metadata'", "'frameIdentityOwner':'ActualFFprobe decoded frame pts+pkt_pos+pkt_size matches unique byte-bound packet BEFORE PNG; best_effort/pkt_dts/ordinal not used','directFrame':matchedFrames[0]")
s=s.replace("len(decoded)<=128", "len(decoded)<=64 and len(frames)+len(decoded)<=128").replace("len(decoded)<128", "len(decoded)<64")
s=s.replace("report['decodedFrames']=decoded;", "report['combinedDecodedFrameCount']=len(frames)+len(decoded);report['decodedFrames']=decoded;")
(r/'data.py').write_text(s)
print(r)
