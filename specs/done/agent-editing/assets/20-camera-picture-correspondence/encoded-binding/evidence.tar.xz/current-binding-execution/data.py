from pathlib import Path
import json,subprocess,os,time,datetime,hashlib,selectors,re,signal
from fractions import Fraction
r=Path(__file__).parent;base=r.parent
plan=json.loads((base/'current-binding-preparation/plan.json').read_text());source=Path(plan['target']['input']);ffprobe=plan['toolPaths']['ffprobe'];ffmpeg=plan['toolPaths']['ffmpeg'];deadline=None
report={'scope':'ONE current encoded-AU to packet to decoded-picture clock/content binding; original nativeRGB RED unchanged; missing historical producer identity not reconstructed','passed':False,'producerPID':os.getpid(),'processes':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bounds':plan['boundedPhases'],'sharedDataDeadlineSeconds':30}
def save(): (r/'report.json').write_text(json.dumps(report,indent=2))
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def run(argv,label,onLine=None):
 remaining=deadline-time.monotonic();assert remaining>0,'Shared data deadline expired before '+label
 row={'label':label,'argv':argv,'boundSeconds':remaining,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False};report['processes'].append(row);save();start=time.monotonic()
 buffers={};counts={};failure=None
 with (r/(label+'.stdout')).open('wb') as o,(r/(label+'.stderr')).open('wb') as e:
  child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);row['pid']=child.pid;row['processGroupID']=os.getpgid(child.pid);save();print(json.dumps({'label':label,'pid':child.pid,'status':'live'}),flush=True)
  selector=selectors.DefaultSelector()
  for key,stream,dst in [('stdout',child.stdout,o),('stderr',child.stderr,e)]:
   os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,(key,dst));buffers[key]=b'';counts[key]=0
  try:
   while selector.get_map():
    assert time.monotonic()<deadline,'Shared data deadline expired during '+label
    for event,_ in selector.select(timeout=min(.1,max(0,deadline-time.monotonic()))):
     key,dst=event.data;chunk=os.read(event.fileobj.fileno(),65536)
     if not chunk:selector.unregister(event.fileobj);continue
     dst.write(chunk);dst.flush();counts[key]+=len(chunk);assert counts[key]<=2_097_152,label+' stdio cap exceeded'
     buffers[key]+=chunk
     while b'\n' in buffers[key]:
      line,buffers[key]=buffers[key].split(b'\n',1)
      if onLine:onLine(key,line.decode('utf8',errors='strict'))
   for key,data in buffers.items():
    if data and onLine:onLine(key,data.decode('utf8',errors='strict'))
   child.wait(timeout=max(.001,deadline-time.monotonic()))
  except BaseException as error:
   failure=error
   if child.poll() is None:os.killpg(child.pid,signal.SIGKILL)
   child.wait()
  finally:
   selector.close();child.stdout.close();child.stderr.close();row.update(exitCode=child.returncode,terminal=True,waited=True,elapsedSeconds=time.monotonic()-start,stdioBytes=counts,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),supervisorFailure=None if failure is None else str(failure));save()
  if failure:raise failure
  assert child.returncode==0,label+' actual terminal '+str(child.returncode)
 return (r/(label+'.stdout')).read_text()
try:
 before=json.loads((r/'before-pins.json').read_text());report['beforePins']=[pin(p['path']) for p in before];assert report['beforePins']==before,'Protected input/runtime changed since preparation'
 tools=json.loads((r/'tool-authority.json').read_text());toolPins=[t['executable'] for t in tools.values()]+[p for t in tools.values() for p in t['libraries']];assert all(pin(p['path'])==p for p in toolPins),'Current tools/libraries changed'
 report['toolPins']=toolPins;report['producer']=pin(__file__);report['nativeBinary']=json.loads((r/'executed-binary.json').read_text());assert pin(report['nativeBinary']['path'])==report['nativeBinary']
 save();dataStart=time.monotonic();deadline=dataStart+30
 run([str(r/'target-probe'),str(r/'native'),str(source)],'native')
 units=json.loads((r/'native/access-units.json').read_text());byRole={u['role']:u for u in units};report['nativeUnits']=units;save()
 assert len(units)==3 and sum(u['bytes'] for u in units)<=6_291_456
 def seconds(t):return Fraction(t['value'],t['scale'])
 start=seconds(byRole['preceding']['assetPTS']);end=seconds(byRole['following']['assetPTS']);assert 0<end-start<=10
 packets=[];stream=None;packetBytes=0
 def packetLine(key,line):
  global stream,packetBytes
  if key!='stdout' or not line:return
  fields=line.split('|');kind=fields[0];x=dict(f.split('=',1) for f in fields[1:] if '=' in f)
  if kind=='packet':
   packets.append(x);packetBytes+=int(x['size']);assert len(packets)<=256 and packetBytes<=16_777_216,'Packet count/payload cap'
  elif kind=='stream':stream=x
 run([ffprobe,'-v','error','-select_streams','v:0','-read_intervals',f'{float(start):.6f}%{float(end):.6f}','-show_packets','-show_streams','-show_data_hash','sha256','-show_entries','packet=pts,dts,duration,size,pos,flags,data_hash:stream=index,codec_name,time_base,start_pts,start_time,width,height,color_space,color_transfer,color_primaries','-of','compact=p=1:nk=0',str(source)],'packets',packetLine)
 (r/'packets.json').write_text(json.dumps({'stream':stream,'packets':packets,'payloadBytes':packetBytes},indent=2));report['packetCount']=len(packets);report['packetPayloadBytes']=packetBytes;save()
 assert stream and stream['codec_name']=='h264' and (stream['width'],stream['height'])==('1920','1080')
 joined={}
 for role,u in byRole.items():
  extent=u['cursor']['extents']['sample'];matches=[p for p in packets if int(p.get('pos',-1))==extent['offset'] and int(p['size'])==extent['length'] and p.get('data_hash','').lower()=='sha256:'+u['sha256']]
  assert len(matches)==1,'Unique packet AU join absent/ambiguous for '+role
  joined[role]=matches[0]
 report['joinedPackets']=joined;report['packetTimeBase']=stream['time_base'];save()
 targetPTS=int(joined['target']['pts']);assert joined['target']['pts']!='N/A' and sum(p.get('pts')==str(targetPTS) for p in packets)==1,'Unique actual target packet PTS required'
 tb=Fraction(stream['time_base']);beforePTS=int(joined['preceding']['pts']);afterPTS=int(joined['following']['pts']);assert beforePTS<targetPTS<afterPTS
 # These clocks are from exact current packet byte joins, never native/gray/ordinal aliases.
 report['decodeQualification']={'actualPacketPTS':targetPTS,'timeBase':str(tb),'targetPacketPTSUnique':True,'frameClockOwner':'showinfo AVFrame/filter PTS under copyts; exact equality to the unique byte-bound current packet PTS; no best_effort field or ordinal selection','packetPositionOnFrame':'not exposed by current AVFrame header; no claim of frame packet-position metadata','precedingPacketPTS':beforePTS,'followingPacketPTS':afterPTS};save()
 decoded=[];selected=[];showTB=[]
 def frameLine(key,line):
  if key!='stderr':return
  match=re.search(r'\[Parsed_showinfo_0[^]]*\].*n:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:',line)
  if match:
   decoded.append({'n':int(match[1]),'pts':int(match[2]),'line':line});assert len(decoded)<=128,'Decoded picture cap';assert len(decoded)<128 or any(f['pts']==targetPTS for f in decoded),'Target absent at decoded-picture cap'
  m=re.search(r'\[Parsed_showinfo_0[^]]*\].*config in time_base:\s*([0-9]+/[0-9]+)',line)
  if m:showTB.append(m[1])
  m=re.search(r'\[Parsed_showinfo_3[^]]*\].*n:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:',line)
  if m:selected.append({'n':int(m[1]),'pts':int(m[2]),'line':line})
 png=r/'current-ffmpeg.png';ss=float(beforePTS*tb);duration=float((afterPTS-beforePTS)*tb)
 filter=f"showinfo,select='eq(pts,{targetPTS})',format=rgb24,showinfo"
 run([ffmpeg,'-hide_banner','-nostdin','-copyts','-seek_timestamp','1','-ss',f'{ss:.6f}','-i',str(source),'-an','-t',f'{duration:.6f}','-vf',filter,'-fps_mode','passthrough','-frames:v','1','-update','1','-c:v','png','-pix_fmt','rgb24',str(png)],'decode',frameLine)
 report['decodedFrames']=decoded;report['selectedFrames']=selected;report['showinfoTimeBases']=showTB;save()
 assert showTB and all(Fraction(t)==tb for t in showTB),'Decoded frame timebase changed'
 assert sum(f['pts']==targetPTS for f in decoded)==1 and len(selected)==1 and selected[0]['pts']==targetPTS,'Unique selected decoded frame PTS join required'
 assert png.is_file(),'Exactly one output image required';report['currentPNG']=pin(png);save()
 for label,image in [('reference',base/'confirm-01.png'),('current',png)]:
  raw=r/(label+'.rgba');run([plan['boundedPhases']['pixelCompare']['reader'],str(image),str(raw)],label+'-pixels');report[label+'RGBA']=pin(raw);save()
 a=(r/'reference.rgba').read_bytes();b=(r/'current.rgba').read_bytes();assert len(a)==len(b)==8_294_400,'Full RGBA size mismatch'
 comparison={'bytes':len(a),'equal':a==b,'differentSamples':sum(x!=y for x,y in zip(a,b)),'differentPixels':sum(a[i:i+4]!=b[i:i+4] for i in range(0,len(a),4))};report['comparison']=comparison;save();assert a==b,'Complete current FFmpeg vs saved confirm01 pixels differ; stop with RED'
 assert time.monotonic()<=deadline,'Shared data deadline expired during full comparison'
 report['passed']=True
except BaseException as error:
 report['error']={'type':type(error).__name__,'message':str(error)}
finally:
 report['dataElapsedSeconds']=None if deadline is None else time.monotonic()-(deadline-30)
 before=json.loads((r/'before-pins.json').read_text());report['afterPins']=[pin(p['path']) for p in before];report['inputsUnchanged']=report['afterPins']==before
 report['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({'passed':report['passed'],'error':report.get('error'),'report':str(r/'report.json'),'dataElapsedSeconds':report['dataElapsedSeconds']}),flush=True)
raise SystemExit(0 if report['passed'] and report['inputsUnchanged'] else 1)
