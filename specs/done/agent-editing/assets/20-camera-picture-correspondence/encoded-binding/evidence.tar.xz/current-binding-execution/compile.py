from pathlib import Path
import subprocess,json,datetime,time,hashlib,os
r=Path(__file__).parent;argv=json.loads((r/'compile-argv.json').read_text());p={'argv':argv,'boundSeconds':30,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producerPID':os.getpid()};t=time.monotonic()
def save(): (r/'compile-process.json').write_text(json.dumps(p,indent=2))
files=[Path(x) for x in argv if Path(x).is_file()];(r/'compile-inputs.json').write_text(json.dumps([{'path':str(x),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files],indent=2))
with (r/'compile.stdout').open('wb') as o,(r/'compile.stderr').open('wb') as e:
 c=subprocess.Popen(argv,stdout=o,stderr=e);p['pid']=c.pid;save();print(json.dumps({'phase':'compile','pid':c.pid}),flush=True)
 try:c.wait(timeout=30);p['timedOut']=False
 except subprocess.TimeoutExpired:c.kill();c.wait();p['timedOut']=True
 p.update(exitCode=c.returncode,terminal=True,waited=True,elapsedSeconds=time.monotonic()-t,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if c.returncode==0:
  b=r/'target-probe';(r/'executed-binary.json').write_text(json.dumps({'path':str(b),'bytes':b.stat().st_size,'sha256':hashlib.sha256(b.read_bytes()).hexdigest()},indent=2))
print(json.dumps(p),flush=True)
raise SystemExit(c.returncode)
