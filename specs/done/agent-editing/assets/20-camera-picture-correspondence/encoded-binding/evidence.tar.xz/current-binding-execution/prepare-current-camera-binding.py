from pathlib import Path
import json,shutil,hashlib,subprocess,re
base=Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002/retained-camera-picture-correspondence')
r=base/'current-binding-execution';r.mkdir(mode=0o700)
for name,src in [('Observation.swift','/tmp/screenrec-20h-idr-fence/Observation.swift'),('References.swift','/tmp/screenrec-20k-cursor-buffers/References.swift'),('BufferFacts.swift','/tmp/screenrec-20k-cursor-buffers/BufferFacts.swift')]:shutil.copyfile(src,r/name)
plan=json.loads((base/'current-binding-preparation/plan.json').read_text())
old=json.loads(Path('/tmp/screenrec-20k-cursor-buffers/plan.json').read_text())['compile']
argv=old[:old.index('/tmp/screenrec-20h-idr-fence/Observation.swift')]+[str(r/n) for n in ['Observation.swift','References.swift','BufferFacts.swift']]+[x for x in old if x.endswith('.swift.o')]+[str(r/'Target.swift'),'-o',str(r/'target-probe')]
(r/'compile-argv.json').write_text(json.dumps(argv,indent=2))
def pin(p):
 p=Path(p);h=hashlib.sha256();
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
files=[base/'current-binding-preparation/plan.json',base/'confirm-01.png',Path(plan['target']['input']),Path(plan['boundedPhases']['pixelCompare']['reader'])]
files+= [Path(x) for x in argv if x.endswith('.swift.o')]
files+=list(Path('/tmp/screenrec-20f-camera-overlap/final/Modules').glob('ScreenRecorder*.swiftmodule'))
tools={}
for name in ['ffmpeg','ffprobe']:
 tool=Path(plan['toolPaths'][name]);linked=subprocess.check_output(['/usr/bin/otool','-L',str(tool)],text=True);(r/(name+'-libraries.txt')).write_text(linked)
 libs=[Path(line.strip().split(' (')[0]) for line in linked.splitlines()[1:] if line.strip().startswith('/opt/homebrew/')]
 tools[name]={'executable':pin(tool),'libraries':[pin(p) for p in libs]}
 versions=subprocess.run([str(tool),'-version'],capture_output=True);(r/(name+'-version.stdout')).write_bytes(versions.stdout);(r/(name+'-version.stderr')).write_bytes(versions.stderr);assert versions.returncode==0
 tools[name]['versionExitCode']=versions.returncode
(r/'tool-authority.json').write_text(json.dumps(tools,indent=2))
header=Path('/opt/homebrew/opt/ffmpeg/include/libavutil/frame.h');shutil.copyfile(header,r/'ffmpeg-frame.h')
(r/'before-pins.json').write_text(json.dumps([pin(p) for p in files],indent=2))
assert pin(files[2])['sha256']==plan['target']['inputSHA256'];assert pin(files[1])['sha256']==plan['target']['referenceSHA256']
print(r)
