@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import CryptoKit
import Darwin
import ScreenRecorderMedia
struct AccessUnit: Encodable {
 let role:String;let cursor:CursorFact;let assetPTS:Tick;let sha256:String;let bytes:Int;let file:String
}
@main struct Target {
 @MainActor static func main() async {
  let args=CommandLine.arguments,root=URL(fileURLWithPath:args[1]),url=URL(fileURLWithPath:args[2])
  do {
   let owner=try OwnedEvidenceDestination(root:root),evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence"))
   let asset=AVURLAsset(url:url,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
   let tracks=try await asset.loadTracks(withMediaType:.video)
   try require(tracks.count==1,"one video track",["count":String(tracks.count)],evidence:evidence)
   let track=tracks[0],segments=SourceSegment.occupied(of:try await track.load(.segments)),formats=try await track.load(.formatDescriptions)
   try save(segments.map(SegmentBounds.init),root.appendingPathComponent("segments.json"))
   let target=CMTime(value:83_596_893,timescale:1_000_000)
   guard let segment=segments.first(where:{$0.asset.containsTime(target)}),formats.count==1,
    let selected=track.makeSampleCursor(presentationTimeStamp:segment.mediaTime(ofAsset:target)) else {throw ProbeFailure(message:"Target segment/cursor/format unavailable")}
   let targetFact=cursorFact(target,ordinal:0,segments:segments,track:track)
   try save(targetFact,root.appendingPathComponent("target-cursor.json"))
   let end=assetEnd(ofSamplePresentedAt:target,in:segments,of:track)
   try save(["selectedAssetPTS":Tick(segment.assetTime(ofMedia:selected.presentationTimeStamp)),"expectedAssetPTS":Tick(target),"ownerEnd":Tick(end ?? .invalid)],root.appendingPathComponent("target-clock.json"))
   try require(CMTimeCompare(segment.assetTime(ofMedia:selected.presentationTimeStamp),target)==0 && end.map{microseconds($0)==83_663_563}==true,"exact selected asset clock/support",[:],evidence:evidence)
   var visited=[targetFact],fences=[(String,AVSampleCursor)]()
   for direction in [-1,1] {
    guard let cursor=track.makeSampleCursor(presentationTimeStamp:selected.presentationTimeStamp) else {throw ProbeFailure(message:"Fence cursor unavailable")}
    var found=false
    for distance in 1...64 {
     guard cursor.stepInPresentationOrder(byCount:Int64(direction))==Int64(direction) else {break}
     let at=segment.assetTime(ofMedia:cursor.presentationTimeStamp)
     if abs(CMTimeGetSeconds(CMTimeSubtract(at,target)))>5 {break}
     let fact=cursorFact(at,ordinal:direction*distance,segments:segments,track:track);visited.append(fact)
     try save(visited,root.appendingPathComponent("visited-cursors.json"))
     if cursor.currentSampleSyncInfo.sampleIsFullSync.boolValue {fences.append((direction<0 ? "preceding":"following",cursor));found=true;break}
    }
    try require(found,"fullSync fence within fixed bound",["direction":String(direction),"visited":String(visited.count)],evidence:evidence)
   }
   let input=try FileHandle(forReadingFrom:url);defer{try? input.close()}
   var before=stat();guard fstat(input.fileDescriptor,&before)==0 && (before.st_mode&S_IFMT)==S_IFREG else {throw ProbeFailure(message:"Regular source descriptor required")}
   var units=[AccessUnit]()
   for (role,cursor) in [("target",selected)]+fences {
    let extent=cursor.currentSampleStorageRange
    try require(extent.offset>=0 && extent.length>0 && extent.length<=2_097_152 && extent.offset+extent.length<=before.st_size,"bounded complete stored AU",["role":role,"offset":String(extent.offset),"length":String(extent.length)],evidence:evidence)
    try require(cursor.currentChunkStorageURL?.standardizedFileURL==url.standardizedFileURL,"same physical sample storage",["role":role,"storage":cursor.currentChunkStorageURL?.path ?? "missing"],evidence:evidence)
    try input.seek(toOffset:UInt64(extent.offset));let bytes=try input.read(upToCount:Int(extent.length)) ?? Data()
    let file=root.appendingPathComponent(role+".au");try bytes.write(to:file,options:.withoutOverwriting)
    let at=segment.assetTime(ofMedia:cursor.presentationTimeStamp),fact=cursorFact(at,ordinal:0,segments:segments,track:track)
    units.append(AccessUnit(role:role,cursor:fact,assetPTS:Tick(at),sha256:SHA256.hash(data:bytes).map{String(format:"%02x",$0)}.joined(),bytes:bytes.count,file:file.path))
    try save(units,root.appendingPathComponent("access-units.json"));try require(bytes.count==Int(extent.length),"complete descriptor AU read",["role":role],evidence:evidence)
   }
   let generator=AVSampleBufferGenerator(asset:asset,timebase:nil),request=AVSampleBufferRequest(start:selected);request.direction = .none;request.mode = .immediate
   let sample=try generator.makeSampleBuffer(for:request),fact=observe(sample,ordinal:0,remainingPayload:2_097_152,source:formats[0])
   try save(fact,root.appendingPathComponent("generated-buffer.json"))
   let stored=try Data(contentsOf:root.appendingPathComponent("target.au"))
   try require(fact.numSamples==1 && fact.valid && fact.dataReady && fact.blockCopyComplete==true && fact.payload==stored && fact.format?.sourceEqual==true && fact.clocks["rawPTS"]==Tick(selected.presentationTimeStamp) && fact.clocks["rawDTS"]==Tick(selected.decodeTimeStamp),"generated sample actual identity",[:],evidence:evidence)
   var after=stat();guard fstat(input.fileDescriptor,&after)==0 else {throw ProbeFailure(message:"Source final stat failed")}
   try require(before.st_dev==after.st_dev && before.st_ino==after.st_ino && before.st_size==after.st_size && before.st_mtimespec.tv_sec==after.st_mtimespec.tv_sec && before.st_mtimespec.tv_nsec==after.st_mtimespec.tv_nsec,"source descriptor unchanged",[:],evidence:evidence)
   try save(["status":"pass","visitedPositions":String(visited.count),"storedBytes":String(units.reduce(0){$0+$1.bytes}),"generatedBuffers":"1","nativePixelDecodes":"0","ownerRoot":owner.root.path],root.appendingPathComponent("verdict.json"))
  } catch {
   try? save(["status":"fail","error":String(describing:error)],root.appendingPathComponent("terminal-failure.json"))
   print("FAIL \(error)");Darwin.exit(1)
  }
 }
}
