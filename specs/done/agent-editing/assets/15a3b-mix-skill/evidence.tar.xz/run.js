const fs = require('fs');
const cp = require('child_process');
const path = require('path');
const cli = '/Users/david/dev/screen-recorder/apps/cli/dist/main.js';
const socket = '/private/tmp/screenrec-denoise-skill-home-DMbStG/library/run/service.sock';
const out = '/tmp/screenrec-denoise-mix-skill-results';
function call(op, params, output) {
  const args = [cli, op, '--socket', socket];
  if (params !== undefined) args.push('--params', JSON.stringify(params));
  if (output) args.push('--output', output);
  const r = cp.spawnSync('node', args, {encoding:'utf8', maxBuffer: 50*1024*1024});
  const rec = {operation:op, params, output, command:['node', ...args], status:r.status, stdout:r.stdout, stderr:r.stderr};
  fs.appendFileSync(path.join(out,'commands.jsonl'), JSON.stringify(rec)+'\n');
  if (r.status !== 0) throw new Error(`${op} failed (${r.status}): ${r.stderr || r.stdout}`);
  const data=JSON.parse(r.stdout);
  fs.writeFileSync(path.join(out,`result-${op.replaceAll('.','-')}-${Date.now()}.json`), JSON.stringify(data,null,2)+'\n');
  return data;
}
const project = call('project.create',{requestId:'denoise-mix-skill-project-20260929',title:'RNNoise Mix Skill Journey',canvas:{width:1920,height:1080,fps:{numerator:30,denominator:1},background:'#000000ff'}});
const imported = call('asset.import',{requestId:'denoise-mix-skill-source-20260929',path:'/tmp/screenrec-active-mixer-native-final/source.wav'});
console.log(JSON.stringify({project,imported},null,2));
