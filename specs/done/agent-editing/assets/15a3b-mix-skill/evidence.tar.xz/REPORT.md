# RNNoise mix skill journey

## Result

Created managed project `fea61dd1-2f64-4377-804d-e9a0f1ac7950` from the whole 5.000-second imported source `source.wav` (asset `14d1b9c98f6575f7631748d93599d8518a84fbbc87c1b015ed34b7615a7f8b93`, stream `track:1`, 48 kHz mono). The project is currently at revision `07a9d809-12d3-41da-88d5-ce17a5a2c3b7`, ordinal 4, after undoing the split. It contains the original full-length clip and its RNNoise processing curve.

The curve is the clip-local linear `mix`:

- 0/1 → 0 (dry)
- 1/4 → 1 (fully denoised)
- 3/4 → 1 (fully denoised)
- 1/1 → 0 (dry)

No gain processor was authored. The processor capability reports execution ready. The authored step is `processingStep:57c416a6dfb75719d61b9bb57fe9c8a3c7345be11b8096504a44c80bdc943639:0` on revision `b8af8719-3cb7-48d9-814a-524aebad8008`, ordinal 2.

## Delivered audio

Full processed 48 kHz stereo float WAV: [processed-full.wav](/tmp/screenrec-denoise-mix-skill-results/processed-full.wav)

Bounded dry/processed comparisons, in project time:

- Entrance, 0–1.25 s: [dry](/tmp/screenrec-denoise-mix-skill-results/entrance-dry.wav), [processed](/tmp/screenrec-denoise-mix-skill-results/entrance-processed.wav)
- Fully denoised middle, 1.25–3.75 s: [dry](/tmp/screenrec-denoise-mix-skill-results/steady-dry.wav), [processed](/tmp/screenrec-denoise-mix-skill-results/steady-processed.wav)
- Return, 3.75–5.00 s: [dry](/tmp/screenrec-denoise-mix-skill-results/return-dry.wav), [processed](/tmp/screenrec-denoise-mix-skill-results/return-processed.wav)

These files are sample-aligned within each bounded range. Dry audio matches the input source sample-for-sample after mono-to-stereo duplication. The processed samples differ from dry in 119,998/120,000 entrance samples, 240,000/240,000 middle samples, and 120,000/120,000 return samples. Measured dry→processed RMS values were 0.008996→0.007187 (entrance), 0.012143→0.007942 (middle), and 0.009813→0.007319 (return). These measurements show signal changes; they do not establish perceived loudness or denoising quality. There is no separate gain stage.

## Split and recovery evidence

Split the clip at 625,000 µs (one eighth of the full clip, inside the entrance), creating revision `73a6ce3b-9b85-4e77-abd7-30e02989ec63`, ordinal 3. The returned settings preserved the original key values and assigned the two segments evaluation ranges 0–1/8 and 1/8–1, with the shared RNNoise state key retained across the split.

The post-split full render is [processed-after-split.wav](/tmp/screenrec-denoise-mix-skill-results/processed-after-split.wav). Numeric comparison with `processed-full.wav` found identical frame/channel counts (240,000 stereo frames), zero differing samples (480,000 interleaved samples), zero maximum absolute difference, and zero RMS difference.

`edit.undo` created revision `07a9d809-12d3-41da-88d5-ce17a5a2c3b7`, ordinal 4. `revision.get` and `processing.get` confirm the unsplit 5-second clip and the same four-point curve. `revision.history` returned ordinals 0–4, retaining both the denoise edit and split history.

## Limits and records

The supplied WAV is synthetic diagnostic audio and is not a listening-quality sample. No listening or perceptual-quality claim is made. Verification here covers the returned settings, job readiness/support receipts, sample counts, dry-source identity, segment-level numeric comparisons, and exact pre/post-split sample equality.

`commands.jsonl` records CLI operations, params, and responses. `help-*.json` contains advertised operation schemas used for discovery; `capabilities.json`, revision/asset/job result JSON, and `numeric-analysis.json` preserve evidence. The helper scripts (`run.js`, `continue.js`, `place.js`, `denoise.js`, `render.js`, `poll.js`, `split.js`, `analyze-wav.js`, `undo.js`) are limited to calling the public CLI and analyzing delivered WAVs with Node standard libraries. The first placement attempt is recorded; the CLI rejected it because track order must be an integer, and the corrected call succeeded.
