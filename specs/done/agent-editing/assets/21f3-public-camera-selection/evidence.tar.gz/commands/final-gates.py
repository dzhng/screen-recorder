import os,subprocess,json
from pathlib import Path
root=Path.cwd();native='/tmp/screenrec-21f3-final-native-build/debug/screenrec-native';controller='/tmp/screenrec-21f3-allocated-controller-build/controller-journey';video='/tmp/screenrec-21f3-inputs/crash-input.mov'
env={**os.environ,'SCREENREC_NATIVE':native}
cases=[('crash','public-camera-recovery.mjs',[]),('empty','public-camera-empty-recovery.mjs',[]),('completion','public-recovery-retained-completion.mjs',['--source-home','/tmp/screenrec-21f3-frozen-crash/primary/before-recovery']),('import-controls','public-camera-recovery-controls.mjs',['--source-home','/tmp/screenrec-21f3-frozen-crash/primary/before-recovery']),('selection','public-camera-selection.mjs',['--audio','/tmp/screenrec-21f3-inputs/narration.packed.mov']),('destinations','public-camera-destination-controls.mjs',[])]
results=[]
for name,script,args in cases:
 command=['node','packages/test-harness/editing/'+script,'--out','/tmp/screenrec-21f3-frozen-'+name,'--executable',controller,'--native',native,'--video','/tmp/screenrec-21f3-inputs/input.mov' if name=='selection' else video,*args]
 with open('/tmp/screenrec-21f3-frozen-'+name+'.log','w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 results.append({'name':name,'command':command,'exitCode':r.returncode});Path('/tmp/screenrec-21f3-frozen-gates.json').write_text(json.dumps(results,indent=2))
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
