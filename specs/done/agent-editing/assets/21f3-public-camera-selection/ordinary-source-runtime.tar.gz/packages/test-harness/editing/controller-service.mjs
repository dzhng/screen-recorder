import { startProjectService } from "../../../apps/service/dist/project-service.js";

// The actual private channel and project service share the production app host's pipes.
await startProjectService({
  home: process.env.SCREENREC_CONTROLLER_HOME,
  control: { input: process.stdin, output: process.stdout },
});
