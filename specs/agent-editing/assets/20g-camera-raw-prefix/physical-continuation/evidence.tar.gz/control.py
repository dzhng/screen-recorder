import json, pathlib, subprocess, time, datetime, os, signal, hashlib, sys, selectors
root=pathlib.Path('/tmp/screenrec-20g-raw-prefix/physical-continuation')
plan=json.loads((root/'plan.json').read_text())
records=[]; live=None; phase=time.monotonic()
def write():
    (root/'processes.json').write_text(json.dumps({'phaseBoundSeconds':180,'elapsedSeconds':time.monotonic()-phase,'processes':records},indent=2)+'\n')
def run(label,argv,bound,interrupt=False):
    global live
    bound=min(bound,180-(time.monotonic()-phase))
    if bound<=0: raise RuntimeError('phase deadline')
    with (root/(label+'.stdout')).open('wb') as out,(root/(label+'.stderr')).open('wb') as err:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        live=p; start=time.monotonic()
        record={'label':label,'argv':argv,'pid':p.pid,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':bound,'terminal':False}
        records.append(record); write()
        streams=selectors.DefaultSelector()
        streams.register(p.stdout,selectors.EVENT_READ,('stdout',out))
        streams.register(p.stderr,selectors.EVENT_READ,('stderr',err))
        sizes={'stdout':0,'stderr':0}; killed=False
        try:
            while streams.get_map() or p.poll() is None:
                if time.monotonic()-start>bound: raise RuntimeError('process deadline')
                if interrupt and not killed and (root/'interrupted/ready.json').exists():
                    ready=json.loads((root/'interrupted/ready.json').read_text())
                    if ready['status']!='ready-to-interrupt': raise RuntimeError('bad ready verdict')
                    record['signal']='SIGKILL before CameraWriter.close'; record['ready']=ready
                    os.killpg(p.pid,signal.SIGKILL); killed=True
                for key,_ in streams.select(.02):
                    chunk=os.read(key.fileobj.fileno(),65536)
                    name,destination=key.data
                    if not chunk: streams.unregister(key.fileobj); key.fileobj.close(); continue
                    remaining=1_048_576-sizes[name]
                    destination.write(chunk[:remaining]); destination.flush(); sizes[name]+=min(remaining,len(chunk))
                    if len(chunk)>remaining: raise RuntimeError(name+' fixed 1 MiB log cap')
            p.wait()
            if interrupt and not killed: raise RuntimeError('interrupt prerequisite not reached')
        except BaseException as error:
            record['controllerFailure']=str(error)
            if p.poll() is None: os.killpg(p.pid,signal.SIGKILL)
            p.wait(timeout=5)
            raise
        finally:
            streams.close()
            for pipe in [p.stdout,p.stderr]:
                if not pipe.closed: pipe.close()
            record.update(terminal=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,stdioBytes=sizes,stdioCapBytes=1_048_576)
            live=None; write()
        expected=-signal.SIGKILL if interrupt else 0
        if p.returncode!=expected: raise RuntimeError(f'{label} exit {p.returncode}, expected {expected}')
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path'])
        if p.stat().st_size!=pin['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=pin['sha256']: raise RuntimeError('changed preflight pin '+str(p))
    run('ordinary',plan['ordinary'],15)
    if json.loads((root/'ordinary/verdict.json').read_text())['status']!='pass': raise RuntimeError('ordinary prerequisite fails')
    run('interrupt',plan['interrupt'],15,True)
    run('recover',plan['recover'],15)
    (root/'controller-verdict.json').write_text(json.dumps({'status':'pass','scope':'tiny raw committed-prefix ordinary extension/closure and distinct interruption physical-reader only'},indent=2)+'\n')
except BaseException as error:
    (root/'controller-verdict.json').write_text(json.dumps({'status':'fail','error':str(error),'interruptedCaseAuthorizedOnlyAfterOrdinaryPass':True},indent=2)+'\n')
    print('FAIL',error); sys.exit(1)
finally: write()
