@preconcurrency import AVFoundation
import Foundation
import Darwin
@testable import ScreenRecorderCapture
import ScreenRecorderMedia

struct SavedPictureTiming: Decodable { let ordinal:Int; let pts:Tick; let digestPTS:Tick; let end:Tick? }
struct SavedTimings: Decodable { let nativeScale:Int32; let pictures:[SavedPictureTiming] }
struct NativeInterval: Codable { let ordinal:Int; let start:Tick; let duration:Tick; let end:Tick }
struct OrderingAnswer: Codable {
    let receiverOrdinal:Int; let referenceOrdinal:Int
    let earlierDecodeMayHaveLaterPresentation:Bool; let laterDecodeMayHaveEarlierPresentation:Bool
    let decodePositionComparison:Int
}
struct MetadataRow: Codable {
    let ordinal:Int; let nativeInterval:NativeInterval; let savedPicturePTS:Tick; let savedDigestPTS:Tick
    let mappingExactStart:Tick; let mappingOwnerGridStart:Tick
    let nativeMatchesPictureRational:Bool; let nativeMatchesMappingOwnerGridRational:Bool
    let nativeMatchesExactMappingRational:Bool; let ownerComputedEnd:Tick?; let savedOwnerComputedEnd:Tick?
    let ownerEndMatchesSavedRational:Bool?; let cursor:CursorFact; let ordering:[OrderingAnswer]
    let cursorIdentity:String; let cursorPTSBefore:Tick; let cursorDTSBefore:Tick
    let cursorPTSAfter:Tick; let cursorDTSAfter:Tick
}
func nativeTime(_ t:Tick)->CMTime { CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch) }
func sameRational(_ a:CMTime,_ b:CMTime)->Bool { a.isNumeric && b.isNumeric && a.epoch==b.epoch && CMTimeCompare(a,b)==0 }
struct MetadataResult: Codable {
    let scope:String; let trackIdentity:String; let nativeScale:Int32; let nativeDuration:Tick
    let segmentBounds:[SegmentBounds]; let rows:[MetadataRow]
}
@main struct MetadataEntry {
    @MainActor static func main() async {
        var ownership:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments
            let movie=URL(fileURLWithPath:args[1]), savedURL=URL(fileURLWithPath:args[2]), mappingURL=URL(fileURLWithPath:args[3])
            let owner=try OwnedEvidenceDestination(root:URL(fileURLWithPath:args[4]));ownership=owner
            let evidence=try ObserverEvidence(root:owner.root.appendingPathComponent("evidence"))
            let saved=try JSONDecoder().decode(SavedTimings.self,from:Data(contentsOf:savedURL))
            let mappings=try JSONDecoder().decode([CameraFrameMapping].self,from:Data(contentsOf:mappingURL))
            let asset=AVURLAsset(url:movie,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
            let tracks=try await asset.loadTracks(withMediaType:.video), audio=try await asset.loadTracks(withMediaType:.audio)
            try require(tracks.count==1 && audio.isEmpty,"expected one video/no audio",["videoCount":String(tracks.count),"audioCount":String(audio.count)],evidence:evidence)
            let track=tracks[0], identity=String(describing:ObjectIdentifier(tracks[0]))
            let scale=try await track.load(.naturalTimeScale), duration=try await asset.load(.duration)
            let segments=SourceSegment.occupied(of:try await track.load(.segments))
            let inventoryURL=evidence.root.appendingPathComponent("native-inventory.jsonl")
            try Data().write(to:inventoryURL);let inventoryStream=try FileHandle(forWritingTo:inventoryURL);defer { try? inventoryStream.close() }
            var inventory=[CMTimeRange](), intervals=[NativeInterval](), rows=[MetadataRow]()
            defer { try? save(intervals,evidence.root.appendingPathComponent("native-inventory.json"));try? save(rows,evidence.root.appendingPathComponent("rows.json")) }
            try visitPresentedSamples(track:track,segments:segments) { range in
                let ordinal=inventory.count
                let row=NativeInterval(ordinal:ordinal,start:Tick(range.start),duration:Tick(range.duration),end:Tick(CMTimeRangeGetEnd(range)))
                try inventoryStream.write(contentsOf:JSONEncoder().encode(row)+Data([10]))
                try require(ordinal<240,"fixed native inventory cap",["ordinal":String(ordinal),"nativeStart":String(describing:row.start)],evidence:evidence)
                inventory.append(range);intervals.append(row)
            }
            try inventoryStream.synchronize();try save(intervals,evidence.root.appendingPathComponent("native-inventory.json"))
            try require(inventory.count==saved.pictures.count && inventory.count==mappings.count && inventory.count==197,"complete native/saved inventory correspondence",["native":String(inventory.count),"savedPictures":String(saved.pictures.count),"savedMappings":String(mappings.count)],evidence:evidence)
            try require(scale==saved.nativeScale,"native scale correspondence",["native":String(scale),"saved":String(saved.nativeScale)],evidence:evidence)
            var cursors=[AVSampleCursor]()
            for (ordinal,range) in inventory.enumerated() {
                guard let segment=segments.first(where:{$0.asset.containsTime(range.start)}),
                    let cursor=track.makeSampleCursor(presentationTimeStamp:segment.mediaTime(ofAsset:range.start))
                else { throw ProbeFailure(message:"native cursor unavailable at ordinal \(ordinal)") }
                cursors.append(cursor)
            }
            let rowsURL=evidence.root.appendingPathComponent("rows.jsonl");try Data().write(to:rowsURL)
            let rowStream=try FileHandle(forWritingTo:rowsURL);defer { try? rowStream.close() }
            for (ordinal,range) in inventory.enumerated() {
                let picture=saved.pictures[ordinal],mapping=mappings[ordinal]
                let grid=try mapping.acquisitionRange(scale:scale)
                let fact=cursorFact(range.start,ordinal:ordinal,segments:segments,track:track)
                let cursor=cursors[ordinal]
                let ptsBefore=Tick(cursor.presentationTimeStamp), dtsBefore=Tick(cursor.decodeTimeStamp)
                var answers=[OrderingAnswer]()
                for reference in [ordinal-1,ordinal,ordinal+1] where reference>=0 && reference<cursors.count {
                    let other=cursors[reference] // All were made by the same exact track instance.
                    answers.append(OrderingAnswer(receiverOrdinal:ordinal,referenceOrdinal:reference,
                        earlierDecodeMayHaveLaterPresentation:cursor.maySamplesWithEarlierDecodeTimeStampsHavePresentationTimeStamps(laterThan:other),
                        laterDecodeMayHaveEarlierPresentation:cursor.maySamplesWithLaterDecodeTimeStampsHavePresentationTimeStamps(earlierThan:other),
                        decodePositionComparison:cursor.comparePositionInDecodeOrder(withPositionOf:other).rawValue))
                }
                let end=assetEnd(ofSamplePresentedAt:range.start,in:segments,of:track)
                let endMatch:Bool?=end.flatMap { actual in picture.end.map { sameRational(actual,nativeTime($0)) } }
                let row=MetadataRow(ordinal:ordinal,nativeInterval:intervals[ordinal],savedPicturePTS:picture.pts,savedDigestPTS:picture.digestPTS,
                    mappingExactStart:Tick(mapping.start.time),mappingOwnerGridStart:Tick(grid.start),
                    nativeMatchesPictureRational:sameRational(range.start,nativeTime(picture.pts)),nativeMatchesMappingOwnerGridRational:sameRational(range.start,grid.start),
                    nativeMatchesExactMappingRational:sameRational(range.start,mapping.start.time),ownerComputedEnd:end.map(Tick.init),savedOwnerComputedEnd:picture.end,
                    ownerEndMatchesSavedRational:endMatch,cursor:fact,ordering:answers,
                    cursorIdentity:String(describing:ObjectIdentifier(cursor)),cursorPTSBefore:ptsBefore,cursorDTSBefore:dtsBefore,
                    cursorPTSAfter:Tick(cursor.presentationTimeStamp),cursorDTSAfter:Tick(cursor.decodeTimeStamp))
                rows.append(row);try rowStream.write(contentsOf:JSONEncoder().encode(row)+Data([10]))
                try require(picture.ordinal==ordinal && mapping.ordinal==ordinal && row.nativeMatchesPictureRational && row.nativeMatchesMappingOwnerGridRational,
                    "ordinal/rational asset-PTS correspondence",["ordinal":String(ordinal),"savedOrdinal":String(picture.ordinal),"mappingOrdinal":String(mapping.ordinal),"nativeStart":String(describing:row.nativeInterval.start),"savedStart":String(describing:picture.pts),"mappingGrid":String(describing:row.mappingOwnerGridStart)],evidence:evidence)
                try require(row.cursorPTSBefore==row.cursorPTSAfter && row.cursorDTSBefore==row.cursorDTSAfter,"reordering query preserved cursor position",["ordinal":String(ordinal),"beforePTS":String(describing:row.cursorPTSBefore),"afterPTS":String(describing:row.cursorPTSAfter),"beforeDTS":String(describing:row.cursorDTSBefore),"afterDTS":String(describing:row.cursorDTSAfter)],evidence:evidence)
                try require(fact.missingReason==nil && fact.matchedByOwnerMicroseconds==true,"native cursor fact availability",["ordinal":String(ordinal),"missing":String(describing:fact.missingReason),"matched":String(describing:fact.matchedByOwnerMicroseconds)],evidence:evidence)
            }
            try rowStream.synchronize()
            try save(MetadataResult(scope:"Complete retained closed-source metadata only; no decoder/writer/pixels or stable-prefix claim",trackIdentity:identity,nativeScale:scale,nativeDuration:Tick(duration),segmentBounds:segments.map(SegmentBounds.init),rows:rows),owner.root.appendingPathComponent("result.json"))
            try save(["status":"pass","nativeRows":String(rows.count),"sameTrackIdentity":identity,"endpointQualification":"Existing owner maps/clips SDK decode duration; not an independent display-duration guarantee","stablePrefixQualified":"false"],owner.root.appendingPathComponent("verdict.json"))
            print("PASS complete197 native metadata rows; same-track cursor predicates only")
        } catch {
            if let owner=ownership { try? save(["status":"fail","error":String(describing:error)],owner.failure) }
            print("FAIL \(error)");Darwin.exit(1)
        }
    }
}
