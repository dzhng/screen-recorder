# Frozen saved-data checker, not a native replay or maintained product harness.
import json,pathlib,hashlib,copy,collections
from fractions import Fraction
from pathlib import Path
root=pathlib.Path(__file__).parent
load=lambda p:json.loads((root/p).read_text())
def rational(t):
    assert t['flags']&1 and t['epoch']==0 and t['scale']>0
    return Fraction(t['value'],t['scale'])
def check(v):
    rows=v['rows'];saved=load('saved-timings.json')['pictures'];mappings=load('saved-mappings.json')
    assert len(rows)==len(saved)==len(mappings)==197
    assert len({r['cursorIdentity'] for r in rows})==197
    assert rows==load('case/evidence/rows.json')
    assert rows==[json.loads(s) for s in (root/'case/evidence/rows.jsonl').read_text().splitlines()]
    intervals=load('case/evidence/native-inventory.json')
    assert intervals==[json.loads(s) for s in (root/'case/evidence/native-inventory.jsonl').read_text().splitlines()]
    assert len(intervals)==197
    for i,(r,s,m) in enumerate(zip(rows,saved,mappings)):
        assert r['ordinal']==s['ordinal']==m['ordinal']==i
        assert r['nativeInterval']==intervals[i]
        assert r['savedPicturePTS']==s['pts'] and r['savedDigestPTS']==s['digestPTS']
        assert r['mappingExactStart']=={'value':m['start']['value'],'scale':m['start']['timescale'],'epoch':m['start']['epoch'],'flags':1}
        assert r['savedOwnerComputedEnd']==s.get('end')
        assert r['cursorPTSBefore']==r['cursorPTSAfter']==r['cursor']['clocks']['mediaPTS']
        assert r['cursorDTSBefore']==r['cursorDTSAfter']==r['cursor']['clocks']['mediaDTS']
        assert r['cursor']['ordinal']==i and r['cursor']['requestedAssetPTS']==intervals[i]['start']
        assert r['cursor'].get('missingReason') is None and r['cursor']['matchedByOwnerMicroseconds'] is True
        assert rational(intervals[i]['start'])==rational(s['pts'])==rational(r['mappingOwnerGridStart'])
        assert r['nativeMatchesPictureRational'] and r['nativeMatchesMappingOwnerGridRational']
        assert r['nativeMatchesExactMappingRational']==(rational(intervals[i]['start'])==rational(r['mappingExactStart']))
        assert rational(r['ownerComputedEnd'])==rational(s['end']) and r['ownerEndMatchesSavedRational']
        refs=[j for j in [i-1,i,i+1] if 0<=j<197]
        assert [a['referenceOrdinal'] for a in r['ordering']]==refs
        for a in r['ordering']:
            j=a['referenceOrdinal'];assert a['receiverOrdinal']==i
            actual=rational(r['cursorDTSBefore']);other=rational(rows[j]['cursorDTSBefore'])
            assert a['decodePositionComparison']==((actual>other)-(actual<other))
            assert isinstance(a['earlierDecodeMayHaveLaterPresentation'],bool)
            assert isinstance(a['laterDecodeMayHaveEarlierPresentation'],bool)
        for extent in r['cursor']['extents'].values():
            assert 0<=extent['offset'] and 0<extent['length'] and extent['offset']+extent['length']<=26557
    return rows
if __name__=='__main__':
    authority=load('authority.json')
    for pin in authority['pins']:
        q=pathlib.Path(pin['path']);d=q.read_bytes();assert len(d)==pin['bytes'] and hashlib.sha256(d).hexdigest()==pin['sha256'],pin['path']
    original=json.loads(Path('/tmp/screenrec-20g-raw-prefix/physical-continuation/ordinary/closed.json').read_text())
    expected={'nativeScale':original['nativeScale'],'pictures':[{k:x[k] for k in ['ordinal','pts','digestPTS','end'] if k in x} for x in original['pictures']]}
    assert load('saved-timings.json')==expected
    assert (root/'saved-mappings.json').read_bytes()==Path('/tmp/screenrec-20g-raw-prefix/physical-continuation/ordinary/accepted-mappings.json').read_bytes()
    v=load('case/result.json');r=check(v)
    # Prove this saved-data checker refuses changed native membership/cursor position.
    refused=[]
    for label,field in [('native-PTS','nativeInterval'),('cursor-position','cursorPTSAfter')]:
        altered=copy.deepcopy(v)
        if label=='native-PTS': altered['rows'][24][field]['start']['value']+=1
        else: altered['rows'][24][field]['value']+=1
        try:check(altered)
        except AssertionError:refused.append(label)
        else:raise AssertionError('checker accepted changed '+label)
    processes=load('processes.json')['processes']
    assert len(processes)==2 and all(p['terminal'] and p['exitCode']==0 for p in processes)
    assert processes[0]['elapsedSeconds']<150 and processes[1]['elapsedSeconds']<15
    assert all(n<=1048576 for p in processes for n in p['stdioBytes'].values())
    assert load('cache-before.json')==load('cache-after.json')
    assert load('terminal.json')['targetedAbsence']['stdout']==''
    print(json.dumps({'status':'pass','completeRows':len(r),'sameTrackDistinctUnmovedCursors':197,'orderingQueries':sum(len(x['ordering']) for x in r),'negativeControlsRejected':refused,'protectedPins':len(authority['pins']),'cacheFilesUnchanged':len(load('cache-before.json')),'scope':'Saved evidence values only; no native replay'},indent=2))
