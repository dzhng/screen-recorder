# Marking-page marker follow-up

One persistent compact legend beside the canvas identifies blue selection, gray confirmation and orange playback in initial, selected and completed states. aria-describedby associates it with the waveform. The prior repeated per-state color strings and their now-unused local mark lookup are removed.

Only successful save clears the transient selected point, immediately redraws the waveform and continues the existing completion flow. Confirmed marks remain in the marks array. Save failure leaves selected untouched for retry. No preview, cancellation, exported notes, targets or audio behavior changed.

Shape/diff/docs review: two existing page-owner files only, no registry, helper, production API or state abstraction. No repository docs changed; root owns actual-state captures and fresh critique. Formatter, lint, module syntax and diff whitespace pass. No browser use, screenshots or playback performed in this follow-up. No new test duplicates this simple UI implementation; root will verify the actual states.

Choices: no unresolved or user-only choices. Persistent legend was explicitly approved by root and avoids condition-dependent explanations. UI acceptance remains pending root's fresh captures and critique.

Five lines added, four deleted; net one. No production surfaces added.
