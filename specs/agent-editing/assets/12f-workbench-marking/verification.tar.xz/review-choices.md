# Focused packet-selector review

Shape: the existing page/server, packet binding and export owner remain authoritative. One --packet selector chooses the existing packet format, and the selected annotations.targets owns prompts and exported word entries. No parallel target registry, production API, annotation authority or engine was added. The complete default five-target context passes an exact comparison; its target order and save notes are preserved.

Diff: packet WAV/source SHA, channel count, frame count and original source clock remain checked by the existing loader. Non-default w6 export contains only its requested protected-word entry; sentence, filler inventory and repetition intent stay absent. Saved exports retain the submitted source binding and relative-to-source conversion without adding the recording origin twice. Default byte-range audio serving remains exact. The actual fourteen-and-a-half-second packet also passes an unconfirmed synthetic draft export; it is not human boundary evidence.

Verification: final-tests.txt contains seven passing focused tests. export-owner-mutation-red.txt restores the old export owner and fails specifically on invented paragraph/this entries versus requested workbench; restoring the fix passes. Format, lint, syntax and diff whitespace checks pass. The temporary actual-packet server was stopped. Hidden browser creation is unavailable in both IAB and the installed Chrome extension; no tab was created, no playback ran, and root owns actual muted browser QA/fresh critique after integration.

Docs: no repository plan/evidence documentation was edited; root owns the retained packet and handoff. Conditional opening-um wording prevents false claims for the new packet while preserving the existing default wording. Loading copy stays neutral before prompts arrive.

Independent review: root read the settled five-file diff and reported no blocking finding. The configured Codex CLI is known unsupported; no retry or override occurred.

## Choices

No unresolved or user-only choices. These routine implementation choices are sound:

- **Neutral loading prompt (high confidence).** Before metadata loads, the page now says boundary prompts are loading. It previously named an opening filler even for a packet requesting only workbench. Actual prompts still come from the supplied targets.
- **Conditional opening-filler note and transcript preface (high confidence).** The original target list includes an opening-um target from the listener's report, so its exact note/preface remain. The workbench-only target list does not, so its saved notes and transcript preface omit that unrelated report. Targets are the sole data owner; no extra configuration was added.

No production surfaces were added. Five existing harness files changed: 113 lines added, 11 deleted, net 102. Most additions are the real-server regression and exact default-target preservation assertion.
