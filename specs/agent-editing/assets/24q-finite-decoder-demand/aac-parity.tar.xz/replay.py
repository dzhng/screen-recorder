import pathlib,subprocess,json,os,hashlib
root=pathlib.Path('/tmp/screenrec-24q-tail');source='/tmp/screenrec-24o-checkpoint/retained-marker.m4a'
for label,worker in [('baseline','/tmp/screenrec-24q-baseline-native'),('candidate',str(pathlib.Path('helpers/mac/.build/release/screenrec-native').resolve()))]:
 for start,end,name in [(2998000000,3000000000,'tail'),(2999980000,3000000000,'last20ms')]:
  out=root/(label+'-'+name+'.wav');fd=os.open(source,os.O_RDONLY)
  params={'source':{'source':f'/dev/fd/{fd}','sourceOffsetUs':0,'available':[{'startUs':0,'endUs':3000000000}]},'range':{'startUs':start,'endUs':end},'output':str(out)}
  r=subprocess.run([worker],input=json.dumps({'id':label,'operation':'media.sourceAudio','params':params})+'\n',text=True,capture_output=True,pass_fds=(fd,),timeout=30);os.close(fd)
  (root/(label+'-'+name+'.json')).write_text(r.stdout);(root/(label+'-'+name+'.log')).write_text(r.stderr)
  print(label,name,r.stdout,r.stderr)
