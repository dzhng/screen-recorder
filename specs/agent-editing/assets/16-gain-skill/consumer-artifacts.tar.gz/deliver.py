from run import *
import time,sys
for name in sys.argv[1:]:
 params=json.load(open(P/(name+'-poll.request.json')))
 for i in range(1,21):
  r=call(name+'-poll-'+str(i),'audio.get',params)
  if not r['ok'] or r['data']['state'] not in ['processing','pending']: break
  time.sleep(.25)
 if r['ok'] and r['data']['state']=='ready':call(name+'-delivery','audio.get',params,name+'.wav')
