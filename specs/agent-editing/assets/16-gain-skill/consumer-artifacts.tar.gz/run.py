import json,subprocess,pathlib
P=pathlib.Path('/tmp/screenrec-gain-fresh-skill')
CLI=['node','/Users/david/dev/screen-recorder/apps/cli/dist/main.js']
SOCKET=json.load(open('/tmp/gain-skill-service.json'))['socketPath']
def call(name,op,params,output=None):
 (P/(name+'.request.json')).write_text(json.dumps(params,indent=2))
 cmd=CLI+[op,'--socket',SOCKET,'--params','-']
 if output: cmd+=['--output',str(P/output)]
 r=subprocess.run(cmd,input=json.dumps(params),text=True,capture_output=True)
 (P/(name+'.receipt.json')).write_text(r.stdout)
 (P/(name+'.stderr.txt')).write_text(r.stderr)
 (P/(name+'.exit.txt')).write_text(str(r.returncode))
 result=json.loads(r.stdout); print(name,json.dumps(result)); return result
if __name__=='__main__':
 call('create','project.create',{'requestId':'fresh-gain-create','title':'Fresh gain black-box','canvas':{'width':320,'height':240,'fps':{'numerator':30,'denominator':1},'background':'#000000ff'}})
 call('import','asset.import',{'requestId':'fresh-gain-import','path':json.load(open('/tmp/gain-skill-service.json'))['source']})
 call('capabilities','processing.capabilities',{})
