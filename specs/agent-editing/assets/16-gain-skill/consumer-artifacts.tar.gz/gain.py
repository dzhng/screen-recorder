from run import *
r=json.load(open(P/'place.receipt.json'))['data']['revision']; clip=r['document']['clips'][0]['id']
f=lambda n,d:{'numerator':n,'denominator':d}
params={'projectId':r['projectId'],'expectedRevisionId':r['id'],'requestId':'fresh-gain-curve','operations':[{'operation':'processing.set','target':{'kind':'clip','id':clip},'steps':[{'enabled':True,'window':{'kind':'clip','clipId':clip,'start':f(1,4),'end':f(3,4)},'processor':{'type':'gain','gain':{'keys':[{'at':f(0,1),'value':0.2,'interpolation':'linear'},{'at':f(1,1),'value':0.8,'interpolation':'linear'}]}}}]}]}
call('gain','edit.apply',params)
call('gain-replay','edit.apply',params)
