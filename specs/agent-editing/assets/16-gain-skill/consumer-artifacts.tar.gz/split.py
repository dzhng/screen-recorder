from run import *
r=json.load(open(P/'gain.receipt.json'))['data']['revision'];clip=r['document']['clips'][0]['id']
call('before-split','project.get',{'projectId':r['projectId']})
q={'projectId':r['projectId'],'expectedRevisionId':r['id'],'requestId':'fresh-gain-split','operations':[{'operation':'split','clipIds':[clip],'atUs':500000,'scope':'selected','rightLabels':[{'clipId':clip,'label':'right'}]}]}
s=call('split','edit.apply',q)
call('split-replay','edit.apply',q)
call('gain-replay-after-split','edit.apply',json.load(open(P/'gain.request.json')))
call('after-replays','project.get',{'projectId':r['projectId']})
s=s['data']['revision']
call('split-output-poll','audio.get',{'projectId':s['projectId'],'revisionId':s['id'],'range':{'startUs':0,'endUs':1000000}})
# Wrong clock domain: integer project-microsecond keys on a normalized clip step.
import copy
bad=copy.deepcopy(json.load(open(P/'gain.request.json')))
bad['expectedRevisionId']=s['id'];bad['requestId']='fresh-gain-invalid-domain'
stack=s['document']['processing'][0]
bad['operations'][0]['target']=stack['target']
bad['operations'][0]['steps']=copy.deepcopy(stack['steps'])
bad['operations'][0]['steps'][0]['processor']['gain']['keys']=[{'at':0,'value':0.2,'interpolation':'linear'},{'at':1000000,'value':0.8,'interpolation':'linear'}]
call('before-invalid','project.get',{'projectId':r['projectId']})
call('invalid-domain','edit.apply',bad)
call('after-invalid','project.get',{'projectId':r['projectId']})
