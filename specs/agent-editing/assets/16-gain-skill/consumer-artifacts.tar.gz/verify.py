import json,struct,math,pathlib
P=pathlib.Path('/tmp/screenrec-gain-fresh-skill')
# Fixed before measurement: 1e-7 full-scale absolute error, every sample,
# plus exact dry outside window and exact split PCM preservation.
TOL=1e-7
def wav(name):
 b=(P/(name+'.wav')).read_bytes(); assert b[:4]==b'RIFF' and b[8:12]==b'WAVE'
 pos=12; chunks={}
 while pos+8<=len(b):
  tag=b[pos:pos+4];size=struct.unpack_from('<I',b,pos+4)[0];chunks[tag]=b[pos+8:pos+8+size];pos+=8+size+(size%2)
 fmt,ch,sr,br,align,bits=struct.unpack_from('<HHIIHH',chunks[b'fmt '])
 if fmt==65534: fmt=struct.unpack_from('<H',chunks[b'fmt '],24)[0]
 assert (fmt,ch,sr,bits)==(3,2,48000,32),(fmt,ch,sr,bits)
 data=chunks[b'data']; vals=struct.unpack('<'+'f'*(len(data)//4),data)
 assert len(vals)==96000
 return vals,{'format':'float32','channels':ch,'sampleRate':sr,'frames':len(vals)//ch},data
dry,meta,_=wav('dry')
result={'toleranceAbsolute':TOL,'envelope':'g(n)=0.2+0.6*n/48000 for 12000<=n<36000; otherwise 1','metadata':meta,'dryPeakByChannel':[max(abs(x) for x in dry[c::2]) for c in range(2)],'checks':{}}
for name in ['after','processed','output','split-output']:
 if not (P/(name+'.wav')).exists():continue
 a,_,_=wav(name); errors=[abs(v-dry[i]*(0.2+0.6*(i//2)/48000 if 12000<=i//2<36000 else 1)) for i,v in enumerate(a)]
 outside=[i for i,v in enumerate(a) if not 12000<=i//2<36000 and v!=dry[i]]
 result['checks'][name]={'samplesChecked':len(a),'maxAbsoluteError':max(errors),'maxErrorByChannel':[max(errors[c::2]) for c in range(2)],'samplesOverTolerance':sum(e>TOL for e in errors),'outsideWindowUnequalSamples':len(outside),'pass':all(math.isfinite(v) for v in a) and max(errors)<=TOL and not outside,'boundaryFrames':{str(n):{'dry':dry[2*n:2*n+2],'actual':a[2*n:2*n+2]} for n in [11999,12000,23999,24000,35999,36000]}}
if (P/'split-output.wav').exists():
 a,_,ab=wav('output');b,_,bb=wav('split-output')
 result['splitPreservation']={'pcmBytesIdentical':ab==bb,'unequalSamples':sum(x!=y for x,y in zip(a,b)),'maxAbsoluteDifference':max(abs(x-y) for x,y in zip(a,b))}
(P/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
