from run import *
r=json.load(open(P/'gain.receipt.json'))['data']['revision']
base={'projectId':r['projectId'],'revisionId':r['id'],'range':{'startUs':0,'endUs':1000000}}
target=r['document']['processing'][0]['target']; step=r['document']['processing'][0]['steps'][0]['id']
for name,point in [('dry',{'kind':'dry'}),('after',{'kind':'after-step','stepId':step}),('processed',{'kind':'processed'})]:
 call(name+'-poll','audio.get',dict(base,tap={'target':target,'point':point}))
call('output-poll','audio.get',base)
