from run import P
import json,hashlib
def read(n):return json.load(open(P/(n+'.receipt.json')))
g=read('gain');s=read('split')
checks={'gainReplaySameData':g['data']==read('gain-replay')['data'],'splitReplaySameData':s['data']==read('split-replay')['data'],'historicalGainReplaySameData':g['data']==read('gain-replay-after-split')['data'],'replaysDidNotMoveHead':read('after-replays')['data']['currentRevisionId']==s['data']['revision']['id'],'negativeRejected':read('invalid-domain')['ok'] is False,'negativeExitCode':int((P/'invalid-domain.exit.txt').read_text()),'negativeRevisionUnchanged':read('before-invalid')['data']['currentRevisionId']==read('after-invalid')['data']['currentRevisionId']==s['data']['revision']['id'],'splitClipCount':len(s['data']['revision']['document']['clips']),'splitOrdinal':s['data']['revision']['ordinal'],'audioSupportComplete':all(not u['ranges'] for n in ['dry','after','processed','output','split-output'] for u in read(n+'-delivery')['data']['published']['audio']['unavailable'])}
(P/'state-verification.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
(P/'media-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in P.glob('*.wav')},indent=2))
