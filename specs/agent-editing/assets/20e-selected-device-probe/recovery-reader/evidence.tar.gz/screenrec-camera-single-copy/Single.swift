@preconcurrency import AVFoundation
import Foundation
@main struct Direct {
 static func main() async throws {
  let source=URL(fileURLWithPath:CommandLine.arguments[1])
  let destination=URL(fileURLWithPath:CommandLine.arguments[2])
  let asset=AVURLAsset(url:source,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
  let original=try await asset.loadTracks(withMediaType:.video).first!
  let scale=try await original.load(.naturalTimeScale)
  let movie=AVMutableMovie();movie.timescale=scale
  movie.defaultMediaDataStorage=AVMediaDataStorage(url:destination,options:nil)
  let track=movie.addMutableTrack(withMediaType:.video,copySettingsFrom:original,options:nil)!
  track.timescale=scale
  let ranges=[(Int64(181144273),Int64(181210933)),(Int64(181244263),Int64(181277593))].map{
   CMTimeRange(start:CMTime(value:$0.0,timescale:1000000),end:CMTime(value:$0.1,timescale:1000000))
  }
  // Exact source and target domains, as in the existing composition segments.
  let span=CMTimeRange(start:ranges.first!.start,end:ranges.last!.end)
  try track.insertTimeRange(span,of:original,at:span.start,copySampleData:true)
  for i in (1..<ranges.count).reversed() {
   let gap=CMTimeRange(start:ranges[i-1].end,end:ranges[i].start)
   track.removeTimeRange(gap)
   track.insertEmptyTimeRange(gap)
  }
  try movie.writeHeader(to:destination,fileType:.mov,options:.addMovieHeaderToDestination)
  print("direct source-track insertion complete")
 }
}
