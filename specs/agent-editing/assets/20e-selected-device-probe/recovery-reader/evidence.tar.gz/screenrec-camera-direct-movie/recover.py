from pathlib import Path
import shutil,json,hashlib,subprocess,time,os,signal
out=Path('/tmp/screenrec-camera-direct-recovery');out.mkdir()
source=Path('/tmp/screenrec-20-physical-take-1');clone=out/'take'
shutil.copytree(source,clone,ignore=lambda p,n:[x for x in n if x.startswith('.screenrec-output-')])
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
files=[p for p in clone.rglob('*') if p.is_file()]
identities=[{'path':str(p.relative_to(clone)),'bytes':p.stat().st_size,'sha256':hashfile(p)} for p in files]
assert all(hashfile(source/r['path'])==r['sha256'] for r in identities)
request=json.loads((source/'request.json').read_text());request['outputDirectory']=str(clone)
(out/'recover-request.json').write_text(json.dumps(request))
r={'inputs':identities,'operationalDeadlineSeconds':180,'operationalRssGuardBytes':4*1024**3,'instrumented':True}
start=time.monotonic();peak=0
with (out/'receipt.json').open('wb') as stdout,(out/'trace.log').open('wb') as stderr:
 p=subprocess.Popen(['/tmp/screenrec-camera-direct-movie/probe-instrumented','--probe','selected-devices','recover',str(out/'recover-request.json')],stdout=stdout,stderr=stderr,start_new_session=True);r['pid']=p.pid
 while p.poll() is None:
  try:peak=max(peak,int(subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip())*1024)
  except (ValueError,subprocess.CalledProcessError):pass
  if time.monotonic()-start>=180 or peak>4*1024**3:
   r['stoppedBy']='deadline' if time.monotonic()-start>=180 else 'rssGuard';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.25)
 r.update(exitCode=p.wait(),elapsedSeconds=time.monotonic()-start,peakSampledRssBytes=peak)
r['inputsUnchanged']=all(hashfile(clone/v['path'])==v['sha256'] and hashfile(source/v['path'])==v['sha256'] for v in identities)
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
