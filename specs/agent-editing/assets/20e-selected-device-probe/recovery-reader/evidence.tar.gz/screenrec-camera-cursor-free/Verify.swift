@preconcurrency import AVFoundation
import CryptoKit
import Foundation
struct Point:Decodable {let value:Int64;let timescale:Int32;let epoch:Int64;var time:CMTime{CMTime(value:value,timescale:timescale)}}
struct Frame:Decodable {let ordinal:Int;let start:Point;let end:Point}
struct Row:Decodable {let role:String;let disposition:String;let cameraFrame:Frame?}
@main struct Verify {
 static func emit(_ x:[String:Any]){FileHandle.standardOutput.write(try! JSONSerialization.data(withJSONObject:x,options:[.sortedKeys])+Data([10]))}
 static func ranges(_ frames:ArraySlice<Frame>,scale:Int32)->[CMTimeRange] {
  var out:[CMTimeRange]=[]
  for f in frames {
   let a=CMTimeConvertScale(f.start.time,timescale:scale,method:.roundHalfAwayFromZero)
   let b=CMTimeConvertScale(f.end.time,timescale:scale,method:.roundHalfAwayFromZero)
   if let last=out.last,last.end==a {out[out.count-1]=CMTimeRange(start:last.start,end:b)}
   else {out.append(CMTimeRange(start:a,end:b))}
  };return out
 }
 static func analyze(_ path:String,_ frames:[Frame],_ phase:String,_ expectedCount:Int?) async throws -> (Int,String,[String:Any]) {
  let asset=AVURLAsset(url:URL(fileURLWithPath:path),options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
  let track=try await asset.loadTracks(withMediaType:.video).first!
  let occupied=SourceSegment.occupied(of:try await track.load(.segments));let scale=try await track.load(.naturalTimeScale)
  if let expectedCount {precondition(occupied.map(\.asset)==ranges(frames.prefix(expectedCount),scale:scale))}
  let transform=try await track.load(.preferredTransform)
  let descriptions=try await track.load(.formatDescriptions)
  let colorKeys=[kCMFormatDescriptionExtension_ColorPrimaries,kCMFormatDescriptionExtension_TransferFunction,kCMFormatDescriptionExtension_YCbCrMatrix]
  let colors=descriptions.map{ d -> [String:String] in
   var x:[String:String]=[:];for k in colorKeys {if let v=CMFormatDescriptionGetExtension(d,extensionKey:k){x[k as String]=String(describing:v)}};return x
  }
  let metadata:[String:Any]=["transform":[transform.a,transform.b,transform.c,transform.d,transform.tx,transform.ty],"colors":colors,"scale":scale]
  let reader=try AVAssetReader(asset:asset)
  let output=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA])
  reader.add(output);precondition(reader.startReading());defer{reader.cancelReading()}
  var count=0;var hash=SHA256()
  while true {
   emit(["phase":phase,"before":count,"status":reader.status.rawValue])
   guard let sample=output.copyNextSampleBuffer() else{break}
   let pts=sample.presentationTimeStamp
   guard (phase == "candidate" ? occupied.contains { $0.asset.containsTime(pts) } : assetEnd(ofSamplePresentedAt:pts,in:occupied,of:track) != nil) else {continue}
   precondition(count<frames.count)
   let expected=CMTimeConvertScale(frames[count].start.time,timescale:scale,method:.roundHalfAwayFromZero)
   precondition(pts==expected,"picture timestamp mismatch at \(count)")
   let pixel=sample.imageBuffer!;CVPixelBufferLockBaseAddress(pixel,.readOnly)
   for value in [CMTimeConvertScale(pts,timescale:scale,method:.roundHalfAwayFromZero).value,Int64(CVPixelBufferGetWidth(pixel)),Int64(CVPixelBufferGetHeight(pixel))] {
    var le=value.littleEndian;hash.update(data:withUnsafeBytes(of:&le){Data($0)})
   }
   for y in 0..<CVPixelBufferGetHeight(pixel){hash.update(data:Data(bytes:CVPixelBufferGetBaseAddress(pixel)!.advanced(by:y*CVPixelBufferGetBytesPerRow(pixel)),count:CVPixelBufferGetWidth(pixel)*4))}
   CVPixelBufferUnlockBaseAddress(pixel,.readOnly);count+=1
  }
  precondition(reader.status == .completed)
  if let expectedCount{precondition(count==expectedCount)}
  let digest=hash.finalize().map{String(format:"%02x",$0)}.joined()
  emit(["phase":phase,"complete":count,"sha256":digest,"metadata":metadata])
  return(count,digest,metadata)
 }
 static func main() async throws {
  let data=try Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]));var frames:[Frame]=[]
  for line in data.split(separator:10) {let r=try JSONDecoder().decode(Row.self,from:Data(line));if r.role=="camera" && r.disposition=="accepted" {let f=r.cameraFrame!;precondition(f.ordinal==frames.count && f.start.epoch==0 && f.end.epoch==0 && f.start.timescale>0 && f.end.timescale>0 && f.end.time>f.start.time);if let last=frames.last{precondition(last.end.time<=f.start.time)};frames.append(f)}}
  precondition(frames.count==4502)
  let raw=try await analyze(CommandLine.arguments[2],frames,"raw",nil)
  precondition(raw.0==4428)
  // The raw function has returned and its reader is canceled/released before candidate creation.
  let candidate=try await analyze(CommandLine.arguments[3],frames,"candidate",raw.0)
  precondition(raw.1==candidate.1)
  precondition(NSDictionary(dictionary:raw.2).isEqual(to:candidate.2))
  emit(["passed":true,"mapped":frames.count,"represented":raw.0,"unrepresented":frames.count-raw.0,"pictureSHA256":raw.1])
 }
}
