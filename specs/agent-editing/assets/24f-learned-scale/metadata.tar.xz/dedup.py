from pathlib import Path
from array import array
import hashlib,json,time
root=Path('/tmp/screenrec-denoise-two-hour-complete');parts=Path('/tmp/screenrec-denoise-two-hour-parts');parts.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(8*1024*1024):h.update(b)
 return h.hexdigest()
# Capture complete independent files' hashes before deriving reconstructed evidence.
original={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(root.iterdir()) if p.is_file()}
Path('/tmp/screenrec-denoise-two-hour-original-hashes.json').write_text(json.dumps(original,indent=2)+'\n')
for c in range(2):
 with (root/f'reference-{c}-input.f32').open('rb') as f:(parts/f'input-{c}-period.f32').write_bytes(f.read(34560*4))
 with (root/f'reference-{c}-raw.f32').open('rb') as f:(parts/f'output-{c}-prefix.f32').write_bytes(f.read(960*4))
result={}
for c in range(2):
 h=hashlib.sha256();period=(parts/f'input-{c}-period.f32').read_bytes()
 for i in range(10000):h.update(period)
 name=f'reference-{c}-input.f32';assert h.hexdigest()==original[name]['sha256'];result[name]={'sha256':h.hexdigest(),'bytes':len(period)*10000,'method':'period-repeat','part':f'input-{c}-period.f32','repetitions':10000}
hashes=[hashlib.sha256((parts/f'output-{c}-prefix.f32').read_bytes()) for c in range(2)]
with (root/'prepared.wav').open('rb') as f:
 header=f.read(4096);assert header[:4]==b'RIFF';assert header[-8:-4]==b'data';assert int.from_bytes(header[-4:],'little')==345600000*8
 while b:=f.read(8*1024*1024):
  a=array('I');a.frombytes(b);assert a.itemsize==4
  for c in range(2):hashes[c].update(a[c::2].tobytes())
for c in range(2):
 name=f'reference-{c}-raw.f32';assert hashes[c].hexdigest()==original[name]['sha256'];result[name]={'sha256':hashes[c].hexdigest(),'bytes':(345600000+960)*4,'method':'prefix-plus-wav-channel','part':f'output-{c}-prefix.f32','wav':'prepared.wav','pcmOffset':4096,'channels':2,'channel':c}
Path('/tmp/screenrec-denoise-two-hour-reconstructed.json').write_text(json.dumps({'scope':'Lossless evidence compression after original independent full comparison, not a new oracle comparison','original':original,'reconstructed':result},indent=2)+'\n')
print(json.dumps(result,indent=2))
