import { PreparedAudioStore } from '/Users/david/dev/screen-recorder/packages/core/dist/prepared-audio.js';
import { appendFileSync } from 'node:fs';
const request=PreparedAudioStore.prototype.request;
PreparedAudioStore.prototype.request=function(...args) { try { return request.apply(this,args); } catch(e) { appendFileSync('/tmp/screenrec-asset-stage-error.txt', String(e.stack)+'\n'); throw e; } };
