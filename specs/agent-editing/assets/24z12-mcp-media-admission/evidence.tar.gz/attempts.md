# Retained attempt distinctions

- Original single PNG adapter red: first unexpected automatic read, stopped before
  completing an oversized reply. Its source/test and raw runner log are retained.
- Single correction initially completed full-byte reads but Vitest's element-wise
  Buffer deep comparison exceeded the unchanged 5000 ms test deadline. The log is
  retained. Buffer.equals retained the full-byte oracle and passed without a bound
  change or smaller fixture.
- Initial added batch fixtures used `timestampsUs`, which is not the existing
  public request field (`atUs`); three INVALID_PARAMS assertion failures are banked
  in media-progress.txt. Correct request fixtures, not production, were changed.
- The first listener-loss oracle guessed CONNECTION_CLOSED. Actual FIN caused the
  existing FrameError/TRUNCATED_FRAME projection: INVALID_RESPONSE, retryable
  false, complete static message. That failed oracle is retained in progress2;
  production was not adjusted. Later missing-path failure is CONNECTION_ERROR.
- Raw-cap tests initially serialized schema-parsed failure objects whose key order
  differs from the original structured value. Progress3 retains both failed text
  equality assertions. The final oracle compares actual text against its actual
  full structured JSON and separately checks every semantic error field.
- Baseline aggregate setup first attempted TypeScript7 transpileModule, unavailable
  in this installed compiler API (`ScriptTarget` undefined). No baseline emitted
  bytes were replaced by that attempt, so its passing aggregate run was not red
  evidence. A scratch baseline tsconfig then used an extra `../` in extends,
  causing TS5083/type errors despite emitting runnable baseline JS. That intermediate
  assertion was not used as a clean baseline build. Corrected extends builds cleanly;
  red-aggregate.txt is the subsequent actual committed-base-source first-read red.
  These two setup diagnostics are recorded here from tool outputs, not claimed as
  retained raw compiler logs. The final baseline build/source/emitted bytes are banked.
- Initial final narrowed gate: 125/126. New direct cancellation fixture only
  accepted LocalTransportError, but the actual main callback also handles
  ArtifactDeliveryError used by budget estimation. Only its callback guard changed.
  Isolated corrected cancellation passes; final narrowed gate passes 126/126.

Both complete synthetic oversized wire values separately trigger the installed
SDK's unconfigured ReadBuffer overflow. This establishes real default parser
rejection plus exact size, not an observed completed overflowing child reply.
No accepted recording/media cohort, deadline or SDK buffer was repeated/changed.
