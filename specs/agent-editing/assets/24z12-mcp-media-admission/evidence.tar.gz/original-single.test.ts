import { createHash } from "node:crypto";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, expect, test } from "vitest";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { listenLocal, DerivativeDelivery } from "@screenrec/service";
import { operationSchema, responseSchema, type OperationResult } from "@screenrec/protocol";

const cleanup: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close();
});
async function fixture(make: (open: (bytes: Buffer) => { token: string; bytes: number; expiresAt: number }) => OperationResult) {
  await mkdir(".build", { recursive: true });
  const home = await mkdtemp(join(process.cwd(), ".build/m-"));
  cleanup.push(() => rm(home, { recursive: true, force: true }));
  const delivery = new DerivativeDelivery();
  cleanup.push(async () => delivery.dispose());
  const calls = { reads: 0, renewals: 0, closes: 0 };
  let consumed!: () => void;
  const firstRead = new Promise<"unexpected automatic read">((resolve) => {
    consumed = () => resolve("unexpected automatic read");
  });
  const result = make((bytes) => delivery.open({ kind: "asset", id: "fixture" }, () => ({
    bytes: bytes.length,
    read: (buffer, position) => bytes.copy(buffer, 0, position, position + buffer.length),
    release() {},
  })));
  const server = await listenLocal({
    runtimeDirectory: home,
    delivery,
    handler: (request) => {
      const op = operationSchema.parse({ operation: request.operation, params: request.params });
      if (op.operation === "artifact.read") {
        calls.reads++;
        consumed();
        return { ok: true, data: delivery.read(op.params.token, op.params.offset, op.params.maxBytes) };
      }
      if (op.operation === "artifact.renew") {
        calls.renewals++;
        return { ok: true, data: delivery.renew(op.params.token) };
      }
      if (op.operation === "artifact.close") {
        calls.closes++;
        delivery.close(op.params.token);
        return { ok: true, data: { closed: true } };
      }
      return result;
    },
  });
  cleanup.push(() => server.close());
  const client = new Client({ name: "media-admission", version: "1" });
  cleanup.push(() => client.close());
  await client.connect(new StdioClientTransport({
    command: process.execPath,
    args: [new URL("../dist/main.js", import.meta.url).pathname, "mcp", "--socket", server.socketPath],
    stderr: "pipe",
  }));
  return { client, calls, firstRead, result };
}
const ready = (delivery: { token: string; bytes: number; expiresAt: number }) => ({
  state: "ready", published: { frame: { mediaType: "image/png", recipe: { width: 640, height: 360 } } },
  delivery, support: { startUs: 7, endUs: 10 }, sourceClock: "fixture", evidence: { quote: '"\\é' },
});
test("default SDK defers a complete eight MiB PNG before any consumption and leaves all bytes readable", async () => {
  const bytes = Buffer.alloc(8 * 1024 ** 2, 137);
  const f = await fixture((open) => ({ ok: true, data: ready(open(bytes)) }));
  const pending = f.client.callTool({ name: "frame.get", arguments: { assetId: "fixture", streamId: "video", atUs: 7 } });
  pending.catch(() => undefined);
  const reply = await Promise.race([pending, f.firstRead]);
  expect(reply).not.toBe("unexpected automatic read");
  if (typeof reply === "string") throw Error(reply);
  const response = responseSchema.parse(reply.structuredContent);
  expect(response).toEqual({ id: response.id, ...f.result });
  expect(reply.content).toEqual([{ type: "text", text: JSON.stringify(response) }]);
  expect(reply.isError).toBe(false);
  expect(f.calls).toEqual({ reads: 0, renewals: 0, closes: 0 });
  if (!response.ok) throw Error(response.error.message);
  const token = (response.data as ReturnType<typeof ready>).delivery.token;
  const chunks: Buffer[] = [];
  for (let offset = 0; offset < bytes.length;) {
    const read = responseSchema.parse((await f.client.callTool({ name: "artifact.read", arguments: { token, offset } })).structuredContent);
    if (!read.ok) throw Error(read.error.message);
    const chunk = read.data as { data: string; nextOffset: number };
    chunks.push(Buffer.from(chunk.data, "base64"));
    expect(chunk.nextOffset).toBeGreaterThan(offset);
    offset = chunk.nextOffset;
  }
  expect(Buffer.concat(chunks)).toEqual(bytes);
  const intended = { ...reply, content: [...reply.content, { type: "image", data: bytes.toString("base64"), mimeType: "image/png" }] };
  console.info(JSON.stringify({ fixture: "single PNG", rawBytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex"), base64Bytes: 4 * Math.ceil(bytes.length / 3), intendedWireBytes: Buffer.byteLength(JSON.stringify({ result: intended, jsonrpc: "2.0", id: 1 }) + "\n"), deferredWireBytes: Buffer.byteLength(JSON.stringify({ result: reply, jsonrpc: "2.0", id: 1 }) + "\n"), calls: f.calls, exactBytes: true }));
});
