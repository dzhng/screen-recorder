# Owned late-error cost closure

Scope: the current Node v24.14.0 default SDK/owned service media path, after a
validated operation has resolved one socket and received its response. No foreign
producer error bodies or general RPC input/security claim.

`apps/cli/src/mcp-result.ts` uses the existing main error projection: delivery and
transport failures carry code/message/retryability with empty details. Metadata
cost includes its structured JSON and the quoted JSON inside the text block. The
same content constructor is used for measured placeholder blocks and real blocks.
The real SDK wraps `{result,jsonrpc:"2.0",id:extra.requestId}` and appends a newline.
`mcpInlineBytes` subtracts the measured empty-envelope cost from the existing
response/control derivation; it never increases the existing result threshold.

For each admitted batch item, compare complete successful metadata plus its
content block against complete failed-item metadata; sum each larger outcome with
the exact shell and metadata/content commas. `contentIndex:8` has the same numeric
width as every supported index 1..8. Single replies compare complete successful
and failed envelopes. Saturating addition returns response-bound+1 on excess;
base64 uses 4*ceil(B/3), JSON quoting at most 2*B. No B-sized placeholder is made.
An oversize raw PNG/JSON uses the existing refusal outcome, not an attachment;
audio above the existing raw cap uses unchanged metadata. Actual consumption
revalidates readiness and retains existing close/error order.

Owned message writers:
- Artifact consumer readiness/chunk/renewal/expiry/JSON errors are static. Renewal's
  longest diagnostic has 64 ASCII bytes. Buffered cap errors are also static.
- DerivativeDelivery read/renew failures are CatalogError with static messages and
  empty details. The retained file handle reads synchronously; released/position/
  closed failures are static. Unexpected filesystem errors become the listener's
  static INTERNAL_ERROR `Service handler failed`, through operation-errors.ts.
- The listener can refuse an artifact operation at its in-flight bound. Its
  `Local service request capacity is full; retry after existing work finishes`
  message is 74 ASCII bytes, the longest fixed diagnostic in this closure.
- Client abort/timeout/parse/correlation/connection-close messages and FrameError
  messages are fixed. UNCORRELATED_RESPONSE is the longest current owned failure
  code (21 bytes). False retryability serializes one byte longer than true.
- The client's socket error callback retains Node's error.message. Node's pinned
  internal/errors ExceptionWithHostPort formats syscall + finite libuv error name
  + selected path; internalConnect may add ` - Local (undefined:undefined)` for a
  Pipe's empty getsockname object. The longest native name from this exact runtime
  is EPROTONOSUPPORT (14 bytes). Read/write/shutdown errno diagnostics are shorter.
  The current estimate constructs this longest connect/path/suffix message and
  lets JSON serialization measure its actual path escaping and UTF-8 bytes.

A once-resolved explicit socket prevents discovery timeout/app-launch diagnostics
from joining automatic consumption's closure. This is path selection, not service
identity: listener loss yields FIN/TRUNCATED_FRAME first and then ENOENT at the
same path. The public fixture preserves both complete failures and continues
across items. It observes one initial health probe, no late probes or launches.

Pins: runtime-authority.json retains Node executable, built-in errors/net source,
finite native error names, SDK request-handler/stdio sources, every scoped emitted
file/source pair, and resolved workspace package entries. These are compiled-scope
identities, not a claim that every emitted file ran. Unchanged owner bytes are
identified by the committed base and the source authority manifest; they are not
repacked as a second complete source tree.
