# Local review closure

Refactor-clean: one framing owner constructs actual metadata and media blocks and
uses those same constructors to measure their empty forms. Main only validates,
resolves selection, dispatches and composes the owner. Its catch also uses that
constructor. Artifact descriptions reuse the existing readiness/batch schemas and
buffer policy; consumption revalidates rather than trusting an admission snapshot.
Shared operation registries serve both CLI files and MCP. Deleted redundant batch
nullable guards and repeated test byte reconstruction. Production +279/-126 =
net +153 lines, including 186 new framing lines and moved constructor/registry work;
no public endpoint, dependency, store, cache, config or worker surface added.

Code-review: complete whole-batch deferral occurs before any read/renew/close and
returns the original response. Admitted metadata/item ordering and indices use the
existing consumer. Raw-cap errors still close without reading; large audio remains
metadata-only without close. Observed FIN error precedence, cancellation's ordinary
un-signaled cleanup, fresh descriptor validation, renewal and selected-path
connection errors are retained. The budget reflects owned fixed and dynamic costs,
actual RPC identity and JSON quoting, with saturating arithmetic. No alternate
schema/error registry, truncation or fallback after consumption remains.

Tests: real CLI/default SDK and actual socket/delivery fixtures compare complete
metadata, item errors, exact media bytes, caller token reads and side effects.
Near-wire numeric/escaped identities prove wrapper accounting; small accepted PNG,
audio, JSON and batches prevent an always-defer implementation from passing. Both
committed-baseline first-read regressions are red. Synthetic complete envelopes
are rejected by the exact installed default ReadBuffer. Existing consumer/service
controls remain green. No enlarged SDK or deadline.

Docs: external caller instructions explain metadata-only media and independent
leases. The spec points to the framing owner and compact packet, and preserves
integration/final-release limits. Root hubs/global choices untouched; all local
markdown links resolve. Choices ledger records discretion and source-bound cost
assumptions; no unsound/user-only decision remains.
