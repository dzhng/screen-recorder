import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/asset-pages-root'; await mkdir(out);
const report={trace:[],passed:false}; const service=new JourneyService(out+'/home',report);
try {await service.start();const submitted=await service.call('asset.import',{requestId:'bulk-root',path:'/tmp/source-budget-root-fixture/scale/source/narration.mov'});
 const start=performance.now();let job;
 do {job=await service.call('job.get',{jobId:submitted.jobId});if(job.state==='ready')break;assert(!['failed','canceled','unavailable'].includes(job.state),JSON.stringify(job));assert(performance.now()-start<30000);await delay(100);} while(true);
 report.assetId=job.result.assetId;report.readyJob=job;report.passed=true;
}finally{await service.stop();await writeFile(out+'/admission.json',JSON.stringify(report,null,2));}
