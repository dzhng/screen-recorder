import assert from 'node:assert/strict';
import { mkdir,mkdtemp,readFile,writeFile,copyFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire('/Users/david/dev/screen-recorder/packages/test-harness/package.json');
const {Client}=await import(require.resolve('@modelcontextprotocol/sdk/client/index.js'));
const {StdioClientTransport}=await import(require.resolve('@modelcontextprotocol/sdk/client/stdio.js'));
import { JourneyService,hash,poll,root,run } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/screenrec-24z7-root-public';
const previous=JSON.parse(await readFile(join(out,'unknown-operation-report.json'),'utf8'));
const home=previous.home;
const report={...previous,passed:false,scope:'Current scene-enabled event read public delivery/work proof only; no timing cohort',trace:previous.trace??[]};
const configuration=join(out,'service.json'),nativeFile=join(out,'native.jsonl'),readsFile=join(out,'reads.jsonl');

await writeFile(configuration,JSON.stringify({sources:[],allowedOperations:['media.audioCapabilities','media.probe','media.sourceEvidence','media.sourceVisualSamples','storage.clearRenderWorkspace'],operationsFile:nativeFile,metadataReadsFile:readsFile}));
const service=new JourneyService(home,report,configuration,new URL('file:///Users/david/dev/screen-recorder/packages/test-harness/editing/evidence-service.mjs'));
const lines=async file=>(await readFile(file,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
const call=(operation,params,options)=>service.call(operation,params,options);
let client;
try {
 const executable=await readFile(process.env.SCREENREC_NATIVE);assert.equal(hash(executable),'0a9cd72a62af990a2bccef585184df0a2bbc36220a2fc258e0198ee43d726928');
 const retained=join(root,'specs/agent-editing/assets/24z-source-cardinality');
 const journal=Buffer.from((await run('tar',['-xOf',join(retained,'evidence.tar.gz'),'cohort/authored-journal.jsonl'])).stdout);
 const movie=join(root,'specs/agent-editing/assets/10d-public-scenes/authored-source.mov');
 const movieBytes=await readFile(movie),assetId=hash(movieBytes);assert.equal(assetId,'491d34c0c2bff15f01d8be032bafa4ca1a96f6244ddc4ba2738bf7673678b49e');
 const donor=join(home,'donor');assert.deepEqual(await readFile(join(donor,'video.mov')),movieBytes);assert.deepEqual(await readFile(join(donor,'capture.journal.jsonl')),journal);
 await service.start();
 client=new Client({name:'scene-event-metadata-proof',version:'1'});
 await client.connect(new StdioClientTransport({command:process.execPath,args:[join(root,'apps/cli/dist/main.js'),'mcp','--socket',service.socketPath],stderr:'pipe'}));
 const acquisitions=[];
 for(let i=0;i<2;i++){
  const submitted=await call('acquisition.import',{requestId:`event-source-${i}`,path:donor});
  const ready=await poll(()=>call('job.get',{jobId:submitted.jobId}),x=>x.state==='ready','acquisition');
  const a=await call('acquisition.get',{acquisitionId:ready.target.acquisitionId});assert.equal(a.journal.sha256,hash(journal));acquisitions.push(a);
 }
 const created=await call('project.create',{requestId:'event-project',canvas:{width:64,height:48,fps:{numerator:30,denominator:1},background:'#000000ff'}});
 const operations=[{operation:'track.add',label:'video',track:{kind:'video',order:0}},...acquisitions.map((a,i)=>({operation:'place',label:`c${i}`,clip:{trackId:{label:'video'},assetId,streamId:'track:1',acquisitionId:a.id,source:{kind:'range',range:{startUs:0,endUs:2500000}},placement:{kind:'project',range:{startUs:i*3000000,endUs:i*3000000+2500000}}}}))];
 const edited=await call('edit.apply',{requestId:'event-place',projectId:created.project.projectId,expectedRevisionId:created.revision.id,operations});
 const params={projectId:created.project.projectId,revisionId:edited.revision.id,range:{startUs:0,endUs:5500000},limit:1};
 const query=async p=>{const reply=await client.callTool({name:'timeline.events',arguments:p});report.exchanges.push({request:{transport:'default MCP',operation:'timeline.events',params:p},response:reply});assert.equal(reply.structuredContent.ok,true,JSON.stringify(reply));assert.deepEqual(JSON.parse(reply.content[0].text),reply.structuredContent);return reply.structuredContent.data;};
 await poll(()=>query(params),x=>x.page!==null,'events ready');
 const beforeNative=(await lines(nativeFile)).length,beforeReads=(await lines(readsFile)).length;
 let cursor,rows=[],dependencies,coverage; const checkpointIDs=[];
 for(let page=0;page<40;page++){
  const reply=await query({...params,...(cursor?{cursor}:{})});assert.equal(reply.state,'ready');assert(reply.page);
  if(!dependencies){dependencies=reply.dependencies;coverage=reply.coverage;}else assert.deepEqual(reply.dependencies,dependencies);
  rows.push(...reply.page.rows);cursor=reply.page.nextCursor;
  if(!cursor)break;assert(!checkpointIDs.includes(cursor.checkpointId));checkpointIDs.push(cursor.checkpointId);assert(page<39,'bounded completion');
 }
 assert(rows.some(x=>x.kind==='scene'));assert(rows.some(x=>x.kind==='geometry'));assert(rows.some(x=>x.kind==='cut'));
 const geometry=rows.filter(x=>x.kind==='geometry');assert.deepEqual(geometry.map(x=>[x.projectAtUs,x.sourceAtUs,x.captureAtUs]),[[0,0,250000],[3000000,0,250000]]);
 for(const row of rows.filter(x=>x.kind==='scene')){const clip=edited.revision.document.clips.find(c=>c.id===row.clipId);assert(clip);const source=typeof row.sourceAtUs==='number'?row.sourceAtUs:row.sourceAtUs.numerator/row.sourceAtUs.denominator;const projected=typeof row.projectAtUs==='number'?row.projectAtUs:row.projectAtUs.numerator/row.projectAtUs.denominator;assert.equal(projected,clip.placement.range.startUs+source);}
 assert.equal((await lines(nativeFile)).length,beforeNative,'reads trigger no native work');
 const cli=await call('timeline.events',{...params,limit:100});const mcp=await query({...params,limit:100});assert.deepEqual(cli.page.rows,mcp.page.rows);assert.deepEqual(cli.dependencies,mcp.dependencies);assert.deepEqual(cli.coverage,mcp.coverage);assert.deepEqual(cli.page.rows,rows);
 const work=(await lines(readsFile)).slice(beforeReads);report.work=work;report.rows=rows;report.dependencies=dependencies;report.coverage=coverage;report.checkpointIDs=checkpointIDs;report.nativeCallsDuringCollection=0;report.fixture={acquisitions,project:edited.revision};report.originals={movieSHA256:assetId,journalSHA256:hash(journal),workerSHA256:hash(executable)};assert.deepEqual(await readFile(movie),movieBytes);report.passed=true;
}finally{
 await client?.close();await service.stop();report.serviceLogs=service.logs;await writeFile(join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
}
console.log(JSON.stringify({passed:report.passed,home,exchanges:report.exchanges.length,rows:report.rows.length,pages:report.checkpointIDs.length+1,nativeCallsDuringCollection:0}));
