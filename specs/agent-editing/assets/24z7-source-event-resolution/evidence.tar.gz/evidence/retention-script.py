from pathlib import Path
import subprocess, hashlib, json, shutil
root=Path.cwd();proof=Path('/tmp/24z7-evidence');test=Path('packages/core/src/project-evidence.test.ts');original=test.read_bytes()
def snapshot(destination):
 pins=[]
 for folder in ['packages/core/src','packages/composition/src','packages/composition/dist']:
  for path in sorted(Path(folder).rglob('*')):
   if path.is_file():
    target=destination/'runtime'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    pins.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for name in ['package.json','packages/core/package.json','packages/core/tsconfig.json','packages/core/tsconfig.check.json','packages/composition/package.json','packages/composition/tsconfig.json','tsconfig.base.json','bun.lock']:
  path=Path(name);target=destination/'runtime'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target);pins.append({'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 return pins
arm=proof/'green';shutil.rmtree(arm);arm.mkdir()
try:
 instrument=original.decode().replace('import { createHash, randomUUID }','import { cpSync, mkdirSync, writeFileSync } from "node:fs";\nimport { createHash, randomUUID }',1)
 at=instrument.index('    expect(next.page!.rows).toEqual(',instrument.index('test("scene-enabled continuation validation'))
 injection='''    const proofRoot = %s;
    f.catalog.catalog.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    mkdirSync(proofRoot, { recursive: true });
    cpSync(f.home, proofRoot + "/catalog", { recursive: true });
    writeFileSync(proofRoot + "/consumer.json", JSON.stringify({ query, captures, first, next, work }, null, 2));
'''%json.dumps(str(arm))
 test.write_text(instrument[:at]+injection+instrument[at:]);pins=snapshot(arm)
 command=['node','node_modules/vitest/vitest.mjs','run','packages/core/src/project-evidence.test.ts','-t','scene-enabled continuation validation','--maxWorkers=1']
 with (arm/'test.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 (arm/'source-pins.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exitCode':result.returncode,'node':subprocess.check_output(['node','--version'],text=True).strip(),'command':command,'pins':pins},indent=2)+'\n')
 print('green retention exit',result.returncode)
finally:test.write_bytes(original)
for name,path,needle,replacement,pattern in [
 ('fresh-validation','packages/core/src/project-evidence.ts','created = await this.publish(input.projectId, state);\n        validate();','created = await this.publish(input.projectId, state);','events metadata is resolved again'),
 ('error-precedence','packages/core/src/source-events.ts','    if (domain === "events" && this.options.scenes) {','    if (domain === "events" && this.options.scenes) {\n      if (!prepare) this.options.capture.resolveMany(selections, domain);','read-only source-event batches keep'),
 ('preparation-order','packages/core/src/source-events.ts','    if (domain === "events" && this.options.scenes) {','    if (domain === "events" && this.options.scenes) {\n      this.options.capture.resolveMany(selections, domain);','scene preparation admits')]:
 destination=proof/'controls'/name;destination.mkdir(parents=True,exist_ok=True);path=Path(path);source=path.read_bytes();assert needle in source.decode()
 try:
  path.write_text(source.decode().replace(needle,replacement,1));pins=snapshot(destination)
  command=['node','node_modules/vitest/vitest.mjs','run','packages/core/src/project-evidence.test.ts','-t',pattern,'--maxWorkers=1']
  with (destination/'red.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  (destination/'source-pins.json').write_text(json.dumps({'exitCode':result.returncode,'command':command,'mutation':{'path':str(path),'needle':needle,'replacement':replacement},'pins':pins},indent=2)+'\n')
  print(name,'falsification exit',result.returncode)
 finally:path.write_bytes(source)
 command=['node','node_modules/vitest/vitest.mjs','run','packages/core/src/project-evidence.test.ts','-t',pattern,'--maxWorkers=1']
 with (destination/'restored.txt').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,'restored exit',result.returncode)
final=proof/'final-source';final.mkdir(exist_ok=True);pins=snapshot(final)
(final/'source-pins.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'pins':pins},indent=2)+'\n')
shutil.copy2('/tmp/24z7-retain.py',proof/'retention-script.py')
