# One retained image through the existing compiled picture stages

Prospective preparation only. No compiler, linker, GPU, image decoder, movie
reader, worker or pixel-reader executable has run in this pass. Root reviews
this source/plan and coordinates one serial diagnostic after12i model activity
is actually terminal. Repository production sources and all frozen artifacts
remain unchanged.

## Fixed input and permitted retargeting

`input-selection.json` binds the retained current direct-source PNG and its
actual public receipt, source sample952322µs, full3120×1970 dimensions and saved
sRGB profile/opaque verdict. The input is selected as the actual physical picture
of the first project-before receipt, before any prospective output. Its PNG
container metadata was read without inflation/decoding. No crop, LUT, identity
bypass, alternate color oracle or acceptance tolerance is introduced.

`stage-request.json` retains every node, operation, target and ordering value from the actual saved compiled visual graph:
clamp, both identity affines, full coverage, track composition and black output.
Only the source layer/binding is retargeted to that already delivered PNG as an
image:0 source with its own content identity and no video clock. This is a new
image-input mechanism test, not a reproduction of the historical video decoder.
It reads one image through the existing StillImageSource owner. Original
requests, delivered pictures, worker and public23l cohort remain immutable.

## Existing compiled owners and observation

All41 frame/media object files equal the saved09c worker linker-input hashes;
all41 current source files equal their frozen source pins. The retained debug
modules/build description declare test access and Swift6.3.3/macOS26.0. Modules,
SDK metadata/headers, compiler drivers, current OS metadata, worker and unchanged
pixel reader are pinned in `authority.json`. Module hashes are pinned now; they
are not a separate historical module-hash receipt. The prospective executable
links only the probe/observer and these retained objects. It does not rebuild or
replace a native worker, speech target or production source.

The compiled CompositionPictureExecutor owns the complete graph, context and
Rec709 terminal render. Its graph is local to render(), so the public worker API
cannot expose graph-direct PNG. A probe-local Objective-C observer captures that
same CIImage at CIContext's render-to-CVPixelBuffer call and delegates unchanged
arguments to the original implementation. A second observer retains the actual
CGImage returned by FrameImage.png's createCGImage call before shared encoding.
Both selectors/types are declared in the pinned local SDK header. Runtime ABI,
receiver class, selectors, original/restored implementation addresses, call and
delegation counts must be recorded. Unsupported ABI or a boundary not observed
exactly once fails the diagnostic; no approximation or fallback is allowed.
The original methods are restored in cleanup after every observation scope.
Observation affects only this standalone process.

## Three routes and measurable boundaries

1. Direct FrameImage PNG uses the existing default source context and the fixed
   PNG's oriented StillImageSource image.
2. The exact CIImage captured from the compiled executor goes directly through
   FrameImage.png using that executor's actual context.
3. The same executor invocation's existing Rec709 BGRA terminal buffer becomes
   a CIImage and goes through FrameImage.png with that same context.

Retain the input CGImage's complete provider bytes/format/profile, actual context
working format/space, graph extent and observed boundary counts, complete
terminal buffer rows including stride plus both attachment modes, and each
actual pre-encode CGImage's complete provider bytes/format/profile and encoded
PNG. Save full ICC bytes and hashes. Unsupported attachment metadata fails
rather than silently dropping values. Exact stage methods/contexts come from
existing compiled code; no filter or coverage implementation is copied.

A CIImage graph is lazy: it has no public discrete pixel plane. The probe can
capture the exact graph identity/context and its actual pre-encode materialized
samples, but cannot capture private Core Image half-float intermediate surfaces.
A context's workingFormat declaration is not proof of those hidden buffers.
Those internal samples remain unobserved; do not claim full internal stage
localization or infer a particular rounding operation from terminal outputs.

Use the unchanged accepted FrameImagePixels executable on input and all three
outputs, retaining each complete sRGB RGBA plane and receipt. Compare every
byte and record channel/error counts without adopting a tolerance. Native
provider/BGRA bytes remain available separately; do not reinterpret them as
already normalized sRGB RGBA. A direct-control difference stays explicit.

## Outcome bounds and execution fence

If graph-direct already differs from direct publication, changing only the
terminal buffer would be insufficient for this valid PNG input. If only the
terminal route differs, the terminal/still-publication seam is implicated for
this input. Neither outcome proves why the original video-input cohort differed:
its decoded BGRA bytes/attachments, internal graph values, historical terminal
buffer and pre-encode CGImage were never saved. An all-equal result cannot
exonerate those missing video-input stages.

`build-plan.json` contains exact prospective commands. Reverify all input,
request, source, object, module, SDK/tool and probe pins before authorized work.
Compile only the standalone observer/probe, then run one fixed-image diagnostic
within the existing30-second media bound. Capture raw commands/output and actual
child terminal status, preserve failure reports, and do not retry or change
limits. Existing pixel-reader commands follow serially; no public service,
movie/source decoder, model, GUI, playback or capture operation belongs here.
Root owns any later production reslice and shared handoff. Preparation supplies
no image-quality, performance, release or historical causal verdict.
