import copy, hashlib, json, pathlib, struct
root=pathlib.Path.cwd(); owner=pathlib.Path(__file__).parent
packet=pathlib.Path('/tmp/screenrec-23l-packet'); report_path=packet/'runs/third/report.json'
build=pathlib.Path('/tmp/screenrec-09c-native-build/arm64-apple-macosx/debug')
def pin(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
r=json.loads(report_path.read_text())
selected=next(p for p in r['pictures'] if p['file'].endswith('/31-project-raw.png'))
input_path=packet/'runs/third/31-project-raw.png'; input_pin=pin(input_path)
assert input_pin['sha256']==selected['sha256'] and input_pin['bytes']==selected['data']['delivery']['bytes']
# Container metadata only: no inflation, ImageIO decode, color conversion or pixel execution.
b=input_path.read_bytes(); chunks=[]; offset=8
assert b[:8]==b'\x89PNG\r\n\x1a\n'
while offset<len(b):
    size=struct.unpack('>I',b[offset:offset+4])[0]; kind=b[offset+4:offset+8].decode('ascii')
    if kind!='IDAT':chunks.append({'kind':kind,'bytes':size,'payloadHex':b[offset+8:offset+8+size].hex()})
    offset+=size+12
    if kind=='IEND':break
assert offset==len(b)
rows=[json.loads(line) for line in (packet/'runs/third/native.jsonl').read_text().splitlines()]
original=next(row for row in rows if row.get('request',{}).get('operation')=='media.renderCompositionFrame')
original_params=original['request']['params']; frame=original_params['frame']
assert len(frame['layers'])==1 and frame['layers'][0]['width']==3120 and frame['layers'][0]['height']==1970
request=copy.deepcopy(original_params)
layer=request['frame']['layers'][0]
layer.update(kind='image',assetId=input_pin['sha256'],streamId='image:0'); del layer['sourceUs']
request['assets']=[{'assetId':input_pin['sha256'],'streamId':'image:0','path':str(input_path),'originUs':0}]
request['output']=str(owner/'run/unused-publication-address.png')
assert request['frame']['visual']==original_params['frame']['visual'] and request['canvas']==original_params['canvas']
(owner/'stage-request.json').write_text(json.dumps(request,indent=2)+'\n')
selection={'selectionRule':'The first project-before picture actual sample, matched to retained current direct-source PNG; selected before any new output', 'report':pin(report_path),'nativeLog':pin(packet/'runs/third/native.jsonl'),'input':input_pin,'receipt':selected,'originalCompiledRequest':original,'diagnosticRequest':pin(owner/'stage-request.json'),'permittedDifferences':['One already-rendered PNG instead of movie video: image kind, image:0 stream, no source clock, PNG content identity/path','Scratch output address'], 'unchanged':['Complete visual graph operation values/order/target identities','Canvas dimensions, fps, black background, graph profile','No processing/pointers/fonts or delivery resize'],'pngContainerMetadata':chunks,'decodedSamplesInspected':False}
selection['visualCanonicalSha256']=hashlib.sha256(json.dumps(original_params['frame']['visual'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
selection['savedNormalizedRgba']=next(row for row in json.loads((packet/'pixels/outputs.json').read_text()) if row['original'].endswith('/31-project-raw.png.rgba'))
(owner/'input-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
linked_path=root/'specs/agent-editing/assets/09c-native-audio-file/linked-code-pins.json'; linked=json.loads(linked_path.read_text())
source_path=root/'specs/agent-editing/assets/09c-native-audio-file/source-final-pins.json'; source=json.loads(source_path.read_text())
objects=[]; sources=[]
for scope in ['ScreenRecorderFrames','ScreenRecorderMedia']:
    for path in sorted(build.glob(scope+'.build/*.swift.o')):
        item=pin(path); assert {k:item[k] for k in ['bytes','sha256']}==linked[str(path)]
        objects.append(item)
    for path in sorted((root/'helpers/mac/Sources'/scope).glob('*.swift')):
        item=pin(path); relative=str(path.relative_to(root)); assert {k:item[k] for k in ['bytes','sha256']}==source[relative]
        sources.append(item)
modules=[pin(build/'Modules'/name) for name in ['ScreenRecorderFrames.swiftmodule','ScreenRecorderMedia.swiftmodule']]
description=pin(build/'description.json'); sdk=pathlib.Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk')
headers=[sdk/'System/Library/Frameworks/CoreImage.framework/Headers/CIContext.h',sdk/'System/Library/Frameworks/CoreGraphics.framework/Headers/CGImage.h',sdk/'System/Library/Frameworks/CoreVideo.framework/Headers/CVBuffer.h']
authority={'base':'fba91e05545243f982af625153a4f6bd9efd8548','historicalLinkedPins':pin(linked_path),'historicalSourcePins':pin(source_path),'objects':objects,'allObjectsEqualHistoricalLinkedPins':True,'currentSources':sources,'allSourcesEqualFrozenSourcePins':True,'modulesPinnedNowNotHistoricalHashProof':modules,'buildDescription':description,'swiftVersionRecord':pin(build/'swift-version--1AB21518FC5DEDBE.txt'),'recordedSwiftVersion':(build/'swift-version--1AB21518FC5DEDBE.txt').read_text(),'sdkResolvedPath':str(sdk.resolve()),'sdkMetadata':[pin(p) for p in [sdk/'SDKSettings.json',sdk/'SDKSettings.plist'] if p.exists()],'sdkHeaders':[pin(p) for p in headers],'compilerDrivers':[pin(pathlib.Path('/Library/Developer/CommandLineTools/usr/bin')/name) for name in ['swiftc','clang']],'systemVersion':pin(pathlib.Path('/System/Library/CoreServices/SystemVersion.plist')),'unchangedFrozenWorker':pin(pathlib.Path('/tmp/screenrec-09c-native-presented-worker')),'unchangedPixelReader':pin(pathlib.Path('/tmp/screenrec-21e-image-pixels')),'compiledOrExecutedThisPass':False,'limits':['Historical object identities are supported by saved linker-input pins; newly pinned module metadata is not a separate historical module hash','No claim that a relinked standalone probe is the original0a process/binary','No historical decoder buffer or graph/internal framebuffer values supplied']}
(owner/'authority.json').write_text(json.dumps(authority,indent=2)+'\n')
frameworks=['Foundation','CoreGraphics','CoreImage','CoreVideo','CoreMedia','AVFoundation','AudioToolbox','CoreText','ImageIO','UniformTypeIdentifiers','VideoToolbox','CryptoKit']
commands=[['/Library/Developer/CommandLineTools/usr/bin/clang','-fobjc-arc','-isysroot',str(sdk),'-mmacosx-version-min=26.0','-c',str(owner/'FrameStageObserver.m'),'-o',str(owner/'observer.o')],['/Library/Developer/CommandLineTools/usr/bin/swiftc','-swift-version','6','-parse-as-library','-target','arm64-apple-macosx26.0','-sdk',str(sdk),'-module-cache-path',str(owner/'module-cache'),'-I',str(build/'Modules'),'-import-objc-header',str(owner/'FrameStageObserver.h'),str(owner/'ColorStages.swift'),str(owner/'observer.o'),*[item['path'] for item in objects],*[argument for name in frameworks for argument in ['-framework',name]],'-o',str(owner/'color-stages')]]
plan={'status':'prospective only; neither compiler nor probe invoked','compileCommands':commands,'diagnosticCommand':[str(owner/'color-stages'),str(input_path),str(owner/'stage-request.json'),str(owner/'run')],'pixelReaderCommands':[[str(pathlib.Path('/tmp/screenrec-21e-image-pixels')), str(input_path if stage=='input' else owner/'run'/(stage+'.png')),str(owner/'run'/(stage+'.rgba'))] for stage in ['input','direct','graph-direct','graph-terminal']],'executionOrder':'Root review;12i actual model terminal; reverify pins; compile only probe plus observer using retained objects; one serial diagnostic; existing pixel reader; complete-byte comparisons','inferenceOrMovieDecode':False,'deadline':'Existing30-second media-worker bound for diagnostic child; no retry or relaxation'}
(owner/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'input':input_pin,'objects':len(objects),'sources':len(sources),'retainedObjectsBytes':sum(i['bytes'] for i in objects),'modules':modules,'request':pin(owner/'stage-request.json'),'compiledOrExecuted':False},indent=2))
