Completed and retained the project:

- Project: `1ee2706f-ffcc-411c-8487-5b6b8ffbc7a8`
- Revision: `2c16db40-809b-4d1e-a1b7-200cba97ccc9`

Authored output geometry with x **20 → 220** over **0–2,000,000 µs**, linear interpolation. Public revision and processing reads confirmed the exact stored values. No rendering or native execution occurred.

[Report and evidence](/tmp/screenrec-ref-fresh-consumer/report.md) include exact requests/responses, limitations, and preserved initial failures.