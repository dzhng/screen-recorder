Blocked: the supplied socket returned `connect EPERM` for capabilities and project creation. No project/revision was created, and no geometry edit could be submitted or verified.

Public help revealed animated geometry nesting but no rectangle placement option.

Saved exact requests, responses, help output, and limitations in [report.md](/tmp/screenrec-ref-fresh-consumer/report.md).