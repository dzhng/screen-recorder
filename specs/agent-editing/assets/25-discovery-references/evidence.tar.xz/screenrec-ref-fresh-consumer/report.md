# Fresh public CLI consumer trial

Completed the corrected output-target authoring/inspection scope. The project remains available for independent confirmation.

- Project: `1ee2706f-ffcc-411c-8487-5b6b8ffbc7a8`
- Initial revision: `c5a3388d-1fad-45b6-a023-a4329e40e5db`
- Authored/current revision: `2c16db40-809b-4d1e-a1b7-200cba97ccc9` (ordinal 1)
- Processing step: `processingStep:f34eb44145ff0a667893d99fa9148938705113f8ea153bebbae51df32703258b:0`
- Canvas: 320 × 180, 30/1 fps, background `#101820ff`; no tracks or clips.

## Exact submitted nested values

`edit.apply` used request ID `fresh-consumer-geometry-20260928`, the initial revision pin above, and this operation:

```json
{
  "operation": "processing.set",
  "target": {
    "kind": "output"
  },
  "steps": [
    {
      "processor": {
        "type": "geometry",
        "rect": {
          "x": {
            "keys": [
              {
                "at": 0,
                "value": 20,
                "interpolation": "linear"
              },
              {
                "at": 2000000,
                "value": 220,
                "interpolation": "linear"
              }
            ]
          },
          "y": 40,
          "width": 60,
          "height": 40
        }
      },
      "window": {
        "kind": "project",
        "range": {
          "startUs": 0,
          "endUs": 2000000
        }
      }
    }
  ]
}
```

The path to animated x is `operations[0].steps[0].processor.rect.x.keys`. Values are x=20 at 0 µs and x=220 at 2,000,000 µs, both with `linear` interpolation. Rect y=40, width=60, height=40 remain constant. The explicit project window is [0, 2,000,000) µs. Rect coordinates are canvas pixels according to public `processing.capabilities`.

## Observed results

`processing.capabilities` advertised geometry for clip, track, group, and output targets. `project.create` and `edit.apply` succeeded with exit 0 and `ok:true`; the edit reported `changed:true`. The service preserved both keyframes, interpolation strings, rect fields, and window, assigning a processing step ID and defaulting `enabled` to true.

Separate public `revision.get` and `processing.get` calls pinned to the authored revision returned identical stored steps with exactly the submitted processor/window. `project.get` confirmed that revision is current. All three reads exited 0 with `ok:true`. Local comparisons of these public responses passed; see `11-verification.json`.

## Evidence and friction

Exact argv arrays, JSON stdin requests, raw stdout, stderr, and exit statuses are preserved for public service calls in files `03-*` through `10-*`. The successful continuation is `05-*` through `10-*`; `07-edit.request.json` is the complete actual edit request. `01-help.response.json` and `02-edit-help.response.json` preserve global and operation-specific public help, with corresponding argv/stderr files.

Initial `03-capabilities` and `04-create` failures remain unchanged: exit 1, `CONNECTION_ERROR`, `connect EPERM /tmp/sr-ref-consumer-CiQLh9/library/run/service.sock`. After the environment changed, creation was retried with the identical request ID and arguments. The initial report is preserved as `report-initial-blocked.md`. The original `discovered-geometry-NOT-SUBMITTED.json` remains a historical artifact from that blocked phase; its step was subsequently submitted in `07-edit.request.json`.

Global help was large enough to truncate the initial display (10,670 lines, approximately 85,000 tokens), so it was saved in full. Operation-specific help narrowed discovery, but nested shapes required following generated `$ref` entries. Capability output marks nested key arrays `readOnly:true`, which could confuse authoring discovery; operation help allowed them, and the actual edit accepted them. No continuation command returned an error.

## Limits

This verifies authoring and readback, not evaluated positions or visible motion. Public help exposed media, text, and silence placement; authored text requires a font asset. The corrected task allowed output-only authoring, so no visual source was added. The empty project has no authored two-second clip; two seconds describes the processor window and keyframe interval. The endpoint is excluded by the half-open window. Although capabilities advertise execution support, execution was not exercised.

Every public CLI invocation used the explicit scratch socket. No implementation, tests, internal schema files, skills, or other reports were read. No capture, devices, native/model execution, rendering, build, repository edits, or service lifecycle actions were performed. The bounded trial is stopped, with the project retained.
