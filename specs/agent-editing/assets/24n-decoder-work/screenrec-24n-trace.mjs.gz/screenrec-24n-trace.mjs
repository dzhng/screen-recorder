import {readFileSync,writeFileSync,openSync,closeSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const cases=JSON.parse(readFileSync('/tmp/screenrec-24n-verified/report.json')).cases;
for (const label of ['late-descriptor','aac-late']) {
 const request=structuredClone(cases.find(c=>c.label===label).request);
 request.output='/tmp/screenrec-24n-trace-'+label+'.wav';
 const source=label==='aac-late'?'/tmp/screenrec-24n-verified/retained-marker.m4a':'/tmp/screenrec-24n-verified/source.wav';
 const fd=openSync(source,'r');
 const result=spawnSync(process.argv[2],[],{input:JSON.stringify({id:label,operation:'media.mixCompositionAudio',params:request})+'\n',encoding:'utf8',timeout:30000,stdio:['pipe','pipe','pipe',fd]});
 closeSync(fd);
 writeFileSync('/tmp/screenrec-24n-trace-'+label+'.log',result.stderr);
 writeFileSync('/tmp/screenrec-24n-trace-'+label+'.json',result.stdout);
 if(result.status!==0)throw new Error(String(result.status));
}
