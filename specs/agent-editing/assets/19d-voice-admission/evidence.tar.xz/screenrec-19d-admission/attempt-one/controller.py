import json,os,pathlib,subprocess,time,shutil
root=pathlib.Path('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder');out=pathlib.Path('/tmp/screenrec-19d-admission');model='/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519';limit=12*1024**3
summary={'passed':False,'diskAtStart':dict(zip(('total','used','free'),shutil.disk_usage(out))),'attempts':[]}
assert summary['diskAtStart']['free']>512*1024**2
try:
 for name in ['tiny-reference','short-reference','temperature-low','temperature-high']:
  cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/private/tmp/screenrec-19b-relocation/bundle/python/bin/python3.12','-I','-B',str(root/'packages/test-harness/editing/voice/settings.py'),'--bundle','/private/tmp/screenrec-19b-relocation/bundle','--model',model,'--request',str(out/(name+'.request.json')),'--output',str(out/(name+'.wav')),'--report',str(out/(name+'.json'))]
  row={'id':name,'command':cmd,'samples':[]};summary['attempts'].append(row);start=time.monotonic()
  with (out/(name+'.log')).open('x') as log:
   process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,HF_HOME=str(out/'cache'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1'))
   try:
    while process.poll() is None:
     sample=subprocess.run(['ps','-o','rss=','-p',str(process.pid)],capture_output=True,text=True)
     if sample.stdout.strip():
      rss=int(sample.stdout.strip())*1024;row['samples'].append({'seconds':time.monotonic()-start,'residentBytes':rss})
      if rss>limit:row['stopped']='resident target';process.kill();break
     if time.monotonic()-start>600:row['stopped']='deadline';process.kill();break
     time.sleep(.25)
   finally:
    if process.poll() is None:process.kill()
    row['exitCode']=process.wait();row['wallSeconds']=time.monotonic()-start
  result=json.loads((out/(name+'.json')).read_text());row['result']=result
  if name=='tiny-reference':
   assert row['exitCode']!=0 and not result['passed'] and not (out/(name+'.wav')).exists();row['expectedRefusal']=True
  else:
   assert row['exitCode']==0 and result['passed'];assert result['peakResidentBytes']<=limit and result['output']['mlxPeakBytes']<=limit
   if name=='short-reference':assert result['termination']['reason']=='eos'
  (out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'id':name,'exitCode':row['exitCode'],'termination':result.get('termination'),'error':result.get('error'),'wallSeconds':row['wallSeconds']}),flush=True)
 summary['passed']=True
finally:(out/'attempts.json').write_text(json.dumps(summary,indent=2)+'\n')
