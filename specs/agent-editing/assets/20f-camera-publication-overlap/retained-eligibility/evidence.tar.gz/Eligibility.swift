@preconcurrency import AVFoundation
import Foundation
import ScreenRecorderMedia
@testable import ScreenRecorderCapture

@main enum Eligibility {
    struct Report: Encodable {
        let scope: String
        let singleVideoNoAudio: Bool
        let occupiedSegments: Int
        let scale: Int32
        let nativeAndMappingCount: Int
        let mappingTorn: Bool
        let support: ExactRange
        let segmentContainsSupport: Bool
        let raw: CaptureMediaIdentity
        let closed: CaptureMediaIdentity
        let observations: CaptureMediaIdentity
    }
    static func main() async throws {
        let take = URL(fileURLWithPath: CommandLine.arguments[1])
        let rawURL = take.appendingPathComponent("camera/camera.raw.mov")
        let mappingURL = take.appendingPathComponent("timestamps.jsonl")
        let marker = take.appendingPathComponent("camera/camera.closed.json")
        let rawIdentity = try CaptureMediaIdentity.read(rawURL)
        let closed = try CaptureMediaIdentity.read(marker)
        let declared = try JSONDecoder().decode(CaptureMediaIdentity.self, from: Data(contentsOf: marker))
        precondition(rawIdentity == declared)
        let observations = try CaptureMediaIdentity.read(mappingURL, maximumBytes: 268_435_456)
        let input = try MediaInput(url: rawURL, purpose: .streaming)
        let videos = try await input.asset.loadTracks(withMediaType: .video)
        let audios = try await input.asset.loadTracks(withMediaType: .audio)
        precondition(videos.count == 1 && audios.isEmpty)
        let track = videos[0]
        let scale = try await track.load(.naturalTimeScale)
        let segments = SourceSegment.occupied(of: try await track.load(.segments))
        precondition(scale > 0 && segments.count == 1)
        let mapping = try CameraMedia.Mapping(mappingURL)
        var first: CMTime?, previous: CMTime?, support: CMTimeRange?
        try visitPresentedSamples(track: track, segments: segments) { native in
            guard let frame = try mapping.next() else { preconditionFailure("Native inventory exceeds mapping") }
            let range = try frame.acquisitionRange(scale: scale)
            precondition(previous.map { $0 < frame.start.time } ?? true)
            precondition(range.start == native.start)
            previous = frame.start.time
            first = first ?? range.start
            support = CMTimeRange(start: first!, end: CMTimeMinimum(range.end, native.end))
        }
        let trailing = try mapping.next(); precondition(trailing == nil)
        let exact = support!
        precondition(!mapping.torn && exact.end > exact.start)
        let contains = segments[0].asset.start <= exact.start && segments[0].asset.end >= exact.end
        precondition(contains)
        let currentRaw = try CaptureMediaIdentity.read(rawURL); precondition(currentRaw == rawIdentity)
        let currentClosed = try CaptureMediaIdentity.read(marker); precondition(currentClosed == closed)
        let currentMapping = try CaptureMediaIdentity.read(mappingURL, maximumBytes: 268_435_456); precondition(currentMapping == observations)
        let report = Report(scope: "Retained closed-source metadata/mapping correspondence only; no decoder/export/publication/performance acceptance", singleVideoNoAudio: true, occupiedSegments: segments.count, scale: scale, nativeAndMappingCount: mapping.frames, mappingTorn: mapping.torn, support: try ExactRange(startUs: ExactTime(exact.start), endUs: ExactTime(exact.end)), segmentContainsSupport: contains, raw: rawIdentity, closed: closed, observations: observations)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(report).write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
        print("Retained metadata/mapping correspondence: \(mapping.frames) frames, one occupied segment, exact support; zero decoder dispatch")
    }
}
