import subprocess,json,time,datetime,os,signal
from pathlib import Path
r=Path('/tmp/screenrec-20f-retained-eligibility');records=[]
for label,args,bound in [('compile',json.loads((r/'compile-plan.json').read_text()),30),('metadata',[str(r/'eligibility'),'/tmp/screenrec-20e-stop-scale-verified/result/take',str(r/'report.json')],30)]:
 with (r/(label+'.stdout')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
  t=time.monotonic();p=subprocess.Popen(args,stdout=out,stderr=err,start_new_session=True);entry=dict(label=label,pid=p.pid,args=args,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),boundSeconds=bound);records.append(entry);print(json.dumps(dict(event='spawn',label=label,pid=p.pid)),flush=True)
  try:code=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait();entry['timedOut']=True
  entry.update(exitCode=code,elapsedSeconds=time.monotonic()-t);(r/'processes.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(dict(event='terminal',label=label,pid=p.pid,exitCode=code)),flush=True)
  if code or entry.get('timedOut'): raise SystemExit(code or 1)
