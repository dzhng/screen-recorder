import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,rm} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {JourneyService,hash} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const phase=process.argv[2],out='/tmp/source-arbitrary-phase',home=out+'/cache-home';
assert(['seed','verify'].includes(phase));if(phase==='seed')await mkdir(home);
const report={phase,trace:[],checks:{},nativeSha256:hash(await readFile(process.env.SCREENREC_NATIVE))};const service=new JourneyService(home,report),call=service.call.bind(service);
async function terminal(operation,params){const until=performance.now()+120000;for(;;){const r=await call(operation,params,{transport:'mcp'});if(['ready','failed','canceled'].includes(r.state))return r;assert(performance.now()<until);await delay(100);}}
try{
 await service.start();let state;
 if(phase==='seed'){
  const imported=await call('asset.import',{requestId:'source',path:'/tmp/capture-admission-windows/48000-canonical/canonical.mov'});
  const job=await terminal('job.get',{jobId:imported.jobId});assert.equal(job.state,'ready');const asset=await call('asset.get',{assetId:job.result.assetId});
  const made=await call('project.create',{requestId:'seed',canvas:{width:16,height:16,fps:{numerator:30,denominator:1},background:'#000000ff'}});const projectId=made.project.projectId;
  const edited=await call('edit.apply',{projectId,expectedRevisionId:made.revision.id,requestId:'place',operations:[{operation:'track.add',label:'a',track:{kind:'audio',order:0}},{operation:'place',clip:{trackId:{label:'a'},assetId:asset.id,streamId:asset.streams[0].id,source:{kind:'range',range:{startUs:0,endUs:2000000}},placement:{kind:'project',range:{startUs:0,endUs:2000000}}}}]});
  state={projectId,revisionId:edited.revision.id,asset,requests:{}};
 }else state=JSON.parse(await readFile(out+'/cache-seed.json','utf8'));
 const selection={projectId:state.projectId,revisionId:state.revisionId};const source={assetId:state.asset.id,streamId:state.asset.streams[0].id};
 for(const [name,operation,params]of [['source','audio.get',source],['project','audio.get',selection],['late','audio.get',{...source,range:{startUs:1100000,endUs:1300000}}],['preview','preview.get',{...selection,range:{startUs:800000,endUs:1200000}}],['prepared','audio.prepare',selection],['waveform','waveform.get',{...source,bucketFrames:6000}]]){
  const ready=await terminal(operation,params);assert.equal(ready.state,'ready',JSON.stringify(ready));assert(ready.published);report.checks[name]={operation,params,ready};
  if(phase==='seed')state.requests[name]={params,ready};else assert.notEqual(ready.jobId,state.requests[name].ready.jobId,name+' replayed old identity');
  if(operation==='audio.get'||operation==='preview.get')await call(operation,params,{output:out+'/'+phase+'-'+name+(operation==='audio.get'?'.wav':'.mp4')});
  if(operation==='audio.prepare'){
   const asset=await call('asset.get',{assetId:ready.published.audio.assetId});const input={assetId:asset.id,streamId:asset.streams[0].id};
   assert.equal((await terminal('audio.get',input)).state,'ready');await call('audio.get',input,{output:out+'/'+phase+'-prepared.wav'});
  }
 }
 if(phase==='seed')await writeFile(out+'/cache-seed.json',JSON.stringify(state,null,2));report.passed=true;
}finally{try{await writeFile(out+'/cache-'+phase+'-report.json',JSON.stringify(report,null,2));}finally{await service.stop();}}
if(phase==='verify')await rm(home,{recursive:true,force:true});
