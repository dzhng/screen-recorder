import AVFoundation
import Foundation
let asset=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1]))
let track=try await asset.loadTracks(withMediaType:.audio)[0]
let rate=Int32(CommandLine.arguments[2])!
let phase=CMTime(value:100001,timescale:1000000)
let n=Int64(rate)*11/10
for (name,start) in [("global-full",CMTime(value:Int64(rate)/10-2,timescale:rate)),("phase-full",CMTimeSubtract(phase,CMTime(value:2,timescale:rate))),("global-late",CMTime(value:Int64(rate)*12/10-2,timescale:rate)),("phase-late",CMTimeAdd(phase,CMTime(value:n-2,timescale:rate)))] {
 let reader=try AVAssetReader(asset:asset)
 reader.timeRange=CMTimeRange(start:start,duration:.positiveInfinity)
 let output=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVSampleRateKey:rate,AVNumberOfChannelsKey:1,AVLinearPCMBitDepthKey:32,AVLinearPCMIsFloatKey:true,AVLinearPCMIsNonInterleaved:false])
 reader.add(output);precondition(reader.startReading())
 let packet=output.copyNextSampleBuffer()!,stamp=CMSampleBufferGetPresentationTimeStamp(packet)
 var list=AudioBufferList();var block:CMBlockBuffer?
 precondition(CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(packet,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)==noErr)
 let values=list.mBuffers.mData!.assumingMemoryBound(to:Float.self)
 print(name,"seek",start.value,start.timescale,"stamp",stamp.value,stamp.timescale,"first",Array(UnsafeBufferPointer(start:values,count:6)))
 reader.cancelReading()
}
