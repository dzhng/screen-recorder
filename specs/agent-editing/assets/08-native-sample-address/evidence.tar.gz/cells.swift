import AVFoundation
import Foundation
let asset=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1]))
let track=try await asset.loadTracks(withMediaType:.audio)[0]
let rate=Int32(CommandLine.arguments[2])!, anchor=Int64(CommandLine.arguments[3])!
let phase=CMTime(value:anchor,timescale:1000000), n=Int64(rate)*11/10-2
var rows=[[String:Any]]()
for fraction:Int64 in [-1,0,1,2,3,4] {
 let start=CMTimeAdd(phase,CMTime(value:n*4+fraction,timescale:rate*4))
 let reader=try AVAssetReader(asset:asset);reader.timeRange=CMTimeRange(start:start,duration:.positiveInfinity)
 let output=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVSampleRateKey:rate,AVNumberOfChannelsKey:1,AVLinearPCMBitDepthKey:32,AVLinearPCMIsFloatKey:true,AVLinearPCMIsNonInterleaved:false])
 reader.add(output);precondition(reader.startReading())
 let packet=output.copyNextSampleBuffer()!,stamp=CMSampleBufferGetPresentationTimeStamp(packet)
 var list=AudioBufferList();var block:CMBlockBuffer?
 precondition(CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(packet,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)==noErr)
 let values=list.mBuffers.mData!.assumingMemoryBound(to:Float.self)
 let matches=(n-10...n+10).filter { j in (0..<6).allSatisfy { i in values[i] == Float(((j+Int64(i))*97%1009)-504)/1024 } }
 rows.append(["fractionQuarter":fraction,"seekValue":start.value,"seekScale":start.timescale,"stampValue":stamp.value,"stampScale":stamp.timescale,"expectedCell":n,"matchedPayloadFrames":matches,"first":Array(UnsafeBufferPointer(start:values,count:6))])
 reader.cancelReading()
}
let data=try JSONSerialization.data(withJSONObject:rows,options:[.prettyPrinted,.sortedKeys]);FileHandle.standardOutput.write(data)
