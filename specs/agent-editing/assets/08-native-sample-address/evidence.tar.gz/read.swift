import Foundation
import ScreenRecorderAudio
import ScreenRecorderMedia
let input=CommandLine.arguments[1], output=CommandLine.arguments[2]
try FileManager.default.createDirectory(atPath:output,withIntermediateDirectories:true)
for (name,range) in [("full",TimeSpan(startUs:0,endUs:2100001)),("late",TimeSpan(startUs:1200011,endUs:1299567))] {
 FileHandle.standardError.write(Data("CASE \(name)\n".utf8))
 _ = try await SourceAudio.write(source:.init(source:input,sourceOffsetUs:0,available:[.init(startUs:0,endUs:2100001)]),range:range,output:URL(fileURLWithPath:output+"/"+name+".wav"))
}
