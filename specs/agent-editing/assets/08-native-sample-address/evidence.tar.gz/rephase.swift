import AVFoundation
let source=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1]))
let track=try await source.loadTracks(withMediaType:.audio)[0]
let composition=AVMutableComposition()
let target=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid)!
target.naturalTimeScale=1000000
try target.insertTimeRange(CMTimeRange(start:CMTime(value:100001,timescale:1000000),duration:CMTime(value:2,timescale:1)),of:track,at:CMTime(value:100013,timescale:1000000))
try await AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetPassthrough)!.export(to:URL(fileURLWithPath:CommandLine.arguments[2]),as:.mov)
