import AVFoundation
import Foundation
let args=CommandLine.arguments, path=args[1], anchorText=args[2], first=Int64(args[3])!, count=Int(args[4])!, destination=args[5]
let asset=AVURLAsset(url:URL(fileURLWithPath:path)),track=try await asset.loadTracks(withMediaType:.audio)[0]
let formats=try await track.load(.formatDescriptions)
let asbd=CMAudioFormatDescriptionGetStreamBasicDescription(formats[0])!.pointee
let rate=Int64(asbd.mSampleRate),channels=Int(asbd.mChannelsPerFrame),packet=Int64(asbd.mFramesPerPacket)
let cell=max(0,first-2*packet), discard=Int(first-cell)
// Integer microsecond strictly inside the already chosen native sample cell.
let parts=anchorText.split(separator:"/").map { Int128($0)! }
let anchorValue=parts[0], anchorScale=parts.count==2 ? parts[1] : 1000000
let top=anchorValue*1000000*Int128(rate)+Int128(cell)*1000000*anchorScale
let divisor=anchorScale*Int128(rate)
let ceilUs=top/divisor+(top%divisor>0 ? 1:0)
let seek=CMTime(value:Int64(ceilUs)+1,timescale:1000000)
let reader=try AVAssetReader(asset:asset)
reader.timeRange=CMTimeRange(start:seek,duration:.positiveInfinity)
let output=AVAssetReaderTrackOutput(track:track,outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVSampleRateKey:rate,AVNumberOfChannelsKey:channels,AVLinearPCMBitDepthKey:32,AVLinearPCMIsFloatKey:true,AVLinearPCMIsNonInterleaved:false])
reader.add(output);precondition(reader.startReading())
var bytes=Data(),stamps=[[String:Int64]]()
while bytes.count/4/channels < count+discard,let sample=output.copyNextSampleBuffer() {
 let stamp=CMSampleBufferGetPresentationTimeStamp(sample),frames=CMSampleBufferGetNumSamples(sample)
 var list=AudioBufferList();var block:CMBlockBuffer?
 precondition(CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)==noErr)
 bytes.append(list.mBuffers.mData!.assumingMemoryBound(to:UInt8.self),count:frames*channels*4)
 stamps.append(["value":stamp.value,"scale":Int64(stamp.timescale),"frames":Int64(frames)])
}
let available=bytes.count/4/channels
let end=min(available,count+discard)
try bytes.subdata(in:discard*channels*4..<end*channels*4).write(to:URL(fileURLWithPath:destination))
let result:[String:Any] = ["rate":rate,"channels":channels,"packetFrames":packet,"first":first,"count":count,"seekCell":cell,"discard":discard,"seekUs":seek.value,"available":available,"stamps":stamps,"status":reader.status.rawValue]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]))
reader.cancelReading()
