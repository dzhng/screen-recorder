# Arbitrary physical phase: localized reader defect

Frozen source evidence: /tmp/capture-admission-windows, anchor100001us, native44.1/48k, exact2s continuouspayload. Full SourceAudio output is exactly floor(anchor*rate) zeros then original payload; late output is one earlier payload sample than its full slice.

Instrumentation: requested start/seek and packet timestamps in {44100,48000}.log. Packet-only AVFoundation probe bypasses both product selection and AVAudioConverter. At48k, requested reader seek57598/48000 returns payload52797; preserving phase100001us+52798/48000 returnspayload52798. Both reportPTS57598/48000. Index2 selection therefore gives52799 vs52800.44.1k repeats the mechanism. This establishes phase loss before converter rather than inferring from output disagreement.

Proposal: preserve exact run-origin time and end to decoder seek, adding native-frame counts relative to that run, while keeping output's declared floor grid. Raw-window skip and resampled composition period skip are integer counts relative to the same run. Keep current selected/acquisition support and converter lookahead. Use common exact-time representation; do not snap the source anchor or add a fitted sample correction. Keep bounded seek/context.

Verify lossless arbitraryphase full/range against authored original first, then44.1->48 resampling context phase and existing mixedrate controls. Include both sides of native halfsample, original aligned45760/48000 regression, sourceoffset, available gaps, late boundedread, integer rates/fractional refusal, cached identity invalidation. Resampling equivalence remains unproven until run.

Exact phase+native offset can exceed CMTimeScale for some rational inputs. Preserve representable cases exactly; do not add new format policy or silently round unsupported rational combinations as part of a local fix. Any such reachable case needs explicit disposition.

No production correction made yet; temporary logging patch saved, production source restored.
