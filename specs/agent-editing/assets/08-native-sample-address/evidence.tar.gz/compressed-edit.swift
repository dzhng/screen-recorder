import AVFoundation
import Foundation
let source=AVURLAsset(url:URL(fileURLWithPath:CommandLine.arguments[1]))
let track=try await source.loadTracks(withMediaType:.audio)[0]
let composition=AVMutableComposition(), target=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid)!
target.naturalTimeScale=441000000
try target.insertTimeRange(CMTimeRange(start:.zero,duration:CMTime(value:2,timescale:1)),of:track,at:CMTime(value:100013,timescale:1000000))
let url=URL(fileURLWithPath:CommandLine.arguments[2]);try await AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetPassthrough)!.export(to:url,as:.mov)
let t=try await AVURLAsset(url:url).loadTracks(withMediaType:.audio)[0]
for s in try await t.load(.segments) where !s.isEmpty { print(s.timeMapping) }
