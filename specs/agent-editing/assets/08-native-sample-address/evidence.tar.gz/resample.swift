import AVFoundation
import Foundation
let a=CommandLine.arguments,data=try Data(contentsOf:URL(fileURLWithPath:a[1])),wanted=Int(a[3])!
let sourceFormat=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:44100,channels:1,interleaved:true)!,targetFormat=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:48000,channels:1,interleaved:true)!
let converter=AVAudioConverter(from:sourceFormat,to:targetFormat)!, output=AVAudioPCMBuffer(pcmFormat:targetFormat,frameCapacity:8192)!
var position=0, result=Data(), supplied:AVAudioPCMBuffer?
while result.count/4<wanted {
 var failure:NSError?
 let status=converter.convert(to:output,error:&failure) { _,status in
  let count=min(8192,data.count/4-position)
  if count==0 {status.pointee = .endOfStream;return nil}
  let b=AVAudioPCMBuffer(pcmFormat:sourceFormat,frameCapacity:AVAudioFrameCount(count))!;b.frameLength=AVAudioFrameCount(count)
  data.withUnsafeBytes { src in for i in 0..<count { b.floatChannelData![0][i]=Float(bitPattern:src.loadUnaligned(fromByteOffset:(position+i)*4,as:UInt32.self)) } }
  position+=count;supplied=b;status.pointee = .haveData;return b
 }
 precondition(status != .error && output.frameLength>0,"short conversion")
 let n=min(Int(output.frameLength),wanted-result.count/4)
 result.append(UnsafeRawPointer(output.floatChannelData![0]).assumingMemoryBound(to:UInt8.self),count:n*4)
}
try result.write(to:URL(fileURLWithPath:a[2]))
