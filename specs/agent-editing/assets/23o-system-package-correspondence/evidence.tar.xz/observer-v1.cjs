const cp = require('node:child_process');
const fs = require('node:fs');
const path = process.env.SCREENREC_23O_EVENTS;
const emit = value => fs.appendFileSync(path, JSON.stringify({at:new Date().toISOString(), parentPid:process.pid, ...value})+'\n');
const watch = (child, command, args) => {
 emit({event:'spawn',pid:child.pid,command,args});
 child.on('exit',(code,signal)=>emit({event:'exit',pid:child.pid,code,signal}));
 child.on('close',(code,signal)=>emit({event:'close',pid:child.pid,code,signal}));
 return child;
};
for (const method of ['spawn','execFile']) {
 const original=cp[method];
 cp[method]=function(command,args,...rest){return watch(original.call(this,command,args,...rest),command,args)};
}
require('node:module').syncBuiltinESMExports();
process.on('exit',code=>emit({event:'node-exit',pid:process.pid,code}));
