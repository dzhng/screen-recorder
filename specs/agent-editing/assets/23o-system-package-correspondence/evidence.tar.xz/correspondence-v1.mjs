import assert from 'node:assert/strict';
import {spawn,execFile} from 'node:child_process';
import {once} from 'node:events';
import {promisify} from 'node:util';
import {readFile,writeFile,mkdir,copyFile,realpath} from 'node:fs/promises';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {createHash} from 'node:crypto';
const root='/Users/david/dev/screen-recorder',out=await realpath('/tmp/screenrec-23o-system-package');
const app='/Users/david/Applications/Screen Recorder.app';
const run=promisify(execFile),sha=b=>createHash('sha256').update(b).digest('hex');
const report={passed:false,scope:'One authored legacy inspection package and actual current public system-only project; no recording-row admission, capture, speech inference, playback or installed cutover',calls:[],runtime:{node:process.execPath,native:process.env.SCREENREC_NATIVE},range:{startUs:700001,endUs:1000001},splitAtUs:800001};
const persist=()=>writeFile(join(out,'correspondence-report.json'),JSON.stringify(report,null,2));
async function poll(read,done,label){const end=performance.now()+30000;for(;;){const v=await read();if(done(v))return v;assert(!['failed','canceled','cleanup_failed'].includes(v.state),label+': '+JSON.stringify(v));assert(performance.now()<end,label+' deadline');await delay(50)}}
const processes=[];
async function start(side,entry,native,ipc=false){const home=join(out,side+'-home');await mkdir(home,{mode:0o700});const log=[];const child=spawn(process.execPath,[entry,...(ipc?[home,join(out,'current-native')]:[])],{cwd:'/',env:{...process.env,SCREENREC_HOME:home,SCREENREC_NATIVE:native},stdio:['pipe','pipe','pipe',...(ipc?['ipc']:[])]});child.stdout.on('data',b=>log.push(b.toString()));child.stderr.on('data',b=>log.push(b.toString()));const closed=once(child,'close');const p={side,home,child,closed,log,cli:side==='legacy'?join(app,'Contents/Resources/cli/main.mjs'):join(root,'apps/cli/dist/main.js')};processes.push(p);const started=ipc?await Promise.race([once(child,'message').then(([v])=>v),closed.then(v=>{throw Error(JSON.stringify(v)+log.join(''))})]):await poll(()=>{assert.equal(child.exitCode,null,log.join(''));return log.join('').split('\n').flatMap(s=>{try{return[JSON.parse(s)]}catch{return[]}}).find(v=>v.event==='started')??{}},v=>!!v.socketPath,'startup');assert(!started.error,JSON.stringify(started));p.socket=started.socketPath;report[side+'Process']={pid:child.pid,home,socket:p.socket};await persist();return p}
async function call(p,operation,params,output){const args=[p.cli,operation,'--socket',p.socket,'--params',JSON.stringify(params),...(output?['--output',output]:[])];const start=performance.now();let result;try{const r=await run(process.execPath,args,{timeout:30000,maxBuffer:8*1024**2});result={code:0,stdout:r.stdout,stderr:r.stderr}}catch(e){result={code:e.code,signal:e.signal,killed:e.killed,stdout:e.stdout,stderr:e.stderr}}const value=JSON.parse(result.stdout);report.calls.push({side:p.side,operation,params,...(output?{output}:{}),result,value,elapsedMs:performance.now()-start});await persist();assert.equal(result.code,value.ok?0:1,JSON.stringify(result));assert.equal(value.ok,true,JSON.stringify(value));return value.data}
async function delivered(p,selection,leaf){await poll(()=>call(p,'audio.get',selection),v=>v.state==='ready',leaf);const file=join(out,leaf);const receipt=await call(p,'audio.get',selection,file);return{file,receipt}}
function pcm(bytes){assert.equal(bytes.toString('ascii',0,4),'RIFF');let fmt;for(let p=12;p+8<=bytes.length;){const size=bytes.readUInt32LE(p+4),id=bytes.toString('ascii',p,p+4);if(id==='fmt ')fmt={tag:bytes.readUInt16LE(p+8),channels:bytes.readUInt16LE(p+10),sampleRate:bytes.readUInt32LE(p+12),bits:bytes.readUInt16LE(p+22)};if(id==='data'){assert.equal(fmt.tag,3);assert.equal(fmt.bits,32);assert.equal(fmt.sampleRate,48000);return{...fmt,bytes:bytes.subarray(p+8,p+8+size)}}p+=8+size+(size%2)}assert.fail('No WAV data')}
try{
 const legacy=await start('legacy',join(app,'Contents/Resources/service/main.mjs'),join(app,'Contents/MacOS/screenrec-native'));
 const opening=await call(legacy,'package.open',{path:join(out,'authored-system-inspection.zip')});
 const ready=await poll(()=>call(legacy,'package.status',{admissionId:opening.id}),v=>v.state==='ready','authored legacy package');
 report.legacyPackage=ready;
 report.legacy=await delivered(legacy,{packageHandle:ready.packageHandle,revisionId:'r0',track:'system',range:report.range},'legacy-system.wav');
 await call(legacy,'package.close',{admissionId:opening.id});
 const donor=join(root,'specs/agent-editing/assets/20d-activation/native-parity/unreadable-packed'),source=join(out,'authentic-source');
 for(const role of ['video','system']){await copyFile(join(donor,role+'.mov'),join(source,role+'.mov'));assert.equal(sha(await readFile(join(source,role+'.mov'))),sha(await readFile(join(donor,role+'.mov'))))}
 const current=await start('current',join(root,'packages/test-harness/editing/source-acquisition-service.mjs'),process.env.SCREENREC_NATIVE,true);
 const importing=await call(current,'acquisition.import',{requestId:'23o-authentic-system-source',path:source});
 const adopted=await poll(()=>call(current,'job.get',{jobId:importing.jobId}),v=>v.state==='ready','source import');
 const acquired=await call(current,'acquisition.get',{acquisitionId:adopted.target.acquisitionId});report.acquisition=acquired;
 const system=acquired.bindings.find(x=>x.sourceRoles.includes('system'));assert(system);assert(!acquired.bindings.some(x=>x.sourceRoles.includes('narration')));
 const asset=await call(current,'asset.get',{assetId:system.assetId});report.asset=asset;
 const startUs=Math.max(0,-system.sourceToAssetOffsetUs),endUs=Math.min(3163631,asset.streams.find(x=>x.id===system.streamId).endUs-system.sourceToAssetOffsetUs);
 const made=await call(current,'project.create',{requestId:'23o-system-project',title:'Explicit system-only correspondence fixture',canvas:{width:160,height:120,fps:{numerator:30,denominator:1},background:'#000000ff'}});
 const placed=await call(current,'edit.apply',{projectId:made.project.projectId,requestId:'23o-system-placement',expectedRevisionId:made.revision.id,operations:[{operation:'track.add',label:'system-track',track:{kind:'audio',order:0}},{operation:'place',label:'system-clip',clip:{trackId:{label:'system-track'},assetId:system.assetId,streamId:system.streamId,acquisitionId:acquired.id,source:{kind:'range',range:{startUs:startUs+system.sourceToAssetOffsetUs,endUs:endUs+system.sourceToAssetOffsetUs}},placement:{kind:'project',range:{startUs,endUs}}}}]});report.placed=placed;
 const selection={projectId:made.project.projectId,revisionId:placed.revision.id,range:report.range};
 report.project=await delivered(current,selection,'project-system.wav');
 const split=await call(current,'edit.apply',{projectId:selection.projectId,requestId:'23o-split-inside-actual-hole',expectedRevisionId:selection.revisionId,operations:[{operation:'split',clipIds:[placed.labels['system-clip']],atUs:report.splitAtUs,scope:'selected'}]});report.split=split;
 report.afterSplit=await delivered(current,{...selection,revisionId:split.revision.id},'project-system-split.wav');
 const old=pcm(await readFile(report.legacy.file)),modern=pcm(await readFile(report.project.file)),splitPCM=pcm(await readFile(report.afterSplit.file));
 assert.equal(old.channels,1);assert.equal(modern.channels,2);assert.equal(splitPCM.channels,2);assert.equal(old.bytes.length,14400*4);assert.equal(modern.bytes.length,14400*8);assert.deepEqual(modern.bytes,splitPCM.bytes);
 const dup=Buffer.alloc(old.bytes.length*2);for(let i=0;i<old.bytes.length;i+=4){old.bytes.copy(dup,i*2,i,i+4);old.bytes.copy(dup,i*2+4,i,i+4)}
 const different=[];for(let f=0;f<14400;f++)if(dup.readFloatLE(f*8)!==modern.bytes.readFloatLE(f*8))different.push(f);
 const original=await run('ffmpeg',['-v','error','-nostdin','-i',join(root,'specs/agent-editing/assets/00-corpus/a-audio.wav'),'-map','0:a:0','-f','f32le','-c:a','pcm_f32le','-'],{encoding:'buffer',maxBuffer:4*1024**2,timeout:30000});await writeFile(join(out,'independent-offered.f32'),original.stdout);
 report.pcm={legacy:{frames:14400,sha256:sha(old.bytes)},project:{frames:14400,sha256:sha(modern.bytes)},split:{frames:14400,sha256:sha(splitPCM.bytes)},monoDuplicationCompared:true,differentFrames:different.length,firstDifferent:different[0]??null,lastDifferent:different.at(-1)??null};
 report.executionComplete=true;await persist();
}finally{
 report.terminal=[];
 for(const p of processes.reverse()){if(p.child.exitCode===null&&p.child.signalCode===null){if(p.child.connected)p.child.send('close');else p.child.stdin.end();const timeout=setTimeout(()=>p.child.kill('SIGKILL'),15000);try{const[code,signal]=await p.closed;report.terminal.push({side:p.side,pid:p.child.pid,code,signal});assert.equal(code,0,p.log.join(''))}finally{clearTimeout(timeout)}}else{const[code,signal]=await p.closed;report.terminal.push({side:p.side,pid:p.child.pid,code,signal})}await writeFile(join(out,p.side+'-service.log'),p.log.join(''))}
 await persist();
}
console.log(JSON.stringify({executionComplete:report.executionComplete,pcm:report.pcm,terminal:report.terminal}));
