import assert from 'node:assert/strict';
import {openSync} from 'node:fs';
import {readFile,writeFile,mkdir,readdir,copyFile,open,stat} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as old from './legacy-owners.mjs';
const root='/Users/david/dev/screen-recorder', out='/tmp/screenrec-23o-system-package';
const {mediaWorker,nativeResult}=await import(root+'/apps/service/dist/worker.js');
const {writeArchive}=await import(root+'/apps/service/dist/archive-write.js');
const worker=mediaWorker();
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={scope:'Authored legacy inspection fixture from immutable actual offline NativeCapture output; not automatic recording package export',native:[],owners:JSON.parse(await readFile(out+'/legacy-source-authority.json','utf8'))};
const call=async(operation,params,options)=>{const response=await worker(operation,params,options);report.native.push({operation,params,response});await writeFile(out+'/fixture-progress.json',JSON.stringify(report,null,2));return nativeResult(response)};
const donor=join(root,'specs/agent-editing/assets/20d-activation/native-parity/unreadable-packed');
const source=join(out,'authentic-source');await mkdir(source,{recursive:true});
// Immutable retained media is borrowed; only journal decompression and small receipts are materialized.
const journal=gunzipSync(await readFile(join(donor,'capture.journal.jsonl.gz')));await writeFile(join(source,'capture.journal.jsonl'),journal);
await copyFile(join(donor,'system.publication.json'),join(source,'system.publication.json'));
const canonical={video:join(donor,'video.mov'),system:join(donor,'system.mov')};
const prior=JSON.parse(await readFile(out+'/fixture-progress.json','utf8'));report.native.push(...prior.native);const normalization=prior.native.find(x=>x.operation==='media.sourceEvidence').response.data;
assert.equal(normalization.header.sessionID,'unreadable-packed');assert.equal(normalization.header.microphone,true);assert.equal(normalization.header.systemAudio,true);
assert.equal(normalization.geometryRecords,0);assert.equal(normalization.finished,true);
const lines=(await readFile(join(out,'normalized.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
assert.deepEqual(lines.map(x=>x.event),['audioAcquired','audioAcquired']);assert.deepEqual(lines.map(x=>x.data.role),['system','system']);
const rows=lines.map((x,i)=>({sequence:i+1,event:x.event,sourceUs:x.data.startUs,content:JSON.stringify(x.data)}));
const input=join(out,'package-input');await mkdir(input,{recursive:true});await mkdir(join(input,'evidence'),{recursive:true});const directory=kind=>join(input,'evidence',kind);
const recovery=JSON.parse(await readFile(join(donor,'recovery.json'),'utf8')),durationUs=recovery.durationUs;
const revision=old.createOriginalRevision(durationUs,'authored-23o');
const identity={recordingId:'authored-system-inspection-23o',sourceId:'unreadable-packed',generation:'verified-system-23o'};
await old.writeSourceEvidencePages({*exportRecords(_,index){if(index==='system')yield rows}},identity,directory('source'));
await copyFile(join(out,'normalized.jsonl'),join(directory('source'),'normalized.jsonl'));
await writeFile(join(directory('source'),'metadata.json'),JSON.stringify({...identity,receipt:{...normalization,file:'evidence/source/normalized.jsonl'}}));
const sourceReader=new old.FileSourceEvidence(directory('source'),identity);
const sample=(params,signal)=>call('media.visualSamples',params,{signal});
const analysis=new old.SourceSceneAnalysis(identity.recordingId,canonical.video,durationUs,sample);
const chunk=await analysis.analyze({startUs:0,endUs:durationUs},new AbortController().signal);
const sceneIdentity={...identity,generation:'actual-scene-23o',policy:old.scenePolicy.id};
const sceneMetadata={...sceneIdentity,durationUs,sourceWidth:chunk.sourceWidth,sourceHeight:chunk.sourceHeight,chunkCount:1,comparisonCount:chunk.comparisons.length,boundaryCount:chunk.comparisons.filter(x=>x.boundary).length};
await old.writeSceneEvidencePages({page:()=>({metadata:sceneMetadata,chunks:[chunk],nextStartUs:null})},sceneIdentity,directory('scenes'));
const scenes=new old.FileSceneEvidence(directory('scenes'),sceneIdentity);
const indexIdentity={...identity,generation:'authored-clean-index-23o',revisionId:revision.id,sourceIdentity:identity,sceneIdentity,selectionPolicy:old.selectionPolicy.id,framePolicy:old.framePolicy,trailPolicy:old.trailPolicy.id};
const selection={revision,sourceIdentity:identity,sceneIdentity,sourceWidth:chunk.sourceWidth,sourceHeight:chunk.sourceHeight};
const candidates=[],coverage=[],entries=[];
for await (const row of old.selectIndex(selection,old.selectionEvidence(selection,{source:sourceReader,scenes},new AbortController().signal))) {
 if(row.kind==='coverage')coverage.push({...row,sequence:coverage.length});else candidates.push(row);
}
await mkdir(join(out,'clean-images'));
for(const candidate of candidates){
 const frame=await old.materializeFrame({recordingId:identity.recordingId,sourceId:identity.sourceId,revision,source:canonical.video,output:join(out,'clean-images',candidate.ordinal+'.png'),atUs:candidate.requestedPlaybackUs,maxLongEdge:160,crop:null,clean:true,trailUs:0,sourceEvidence:null},{decode:(p,s)=>call('media.frame',p,{signal:s}),evidence:sourceReader,sample},new AbortController().signal);
 entries.push({candidate,frame,coverageCount:coverage.filter(x=>x.ordinal===candidate.ordinal).length});
}
const indexMetadata={...indexIdentity,durationUs,candidateCount:entries.length,coverageCount:coverage.length,bytes:entries.reduce((n,e)=>n+e.frame.bytes,0)};
await old.writeScreenshotIndexPages({page:()=>({metadata:indexMetadata,entries,nextOrdinal:null}),coveragePage:({candidateOrdinal})=>({coverage:coverage.filter(x=>candidateOrdinal===undefined||x.ordinal===candidateOrdinal),nextSequence:null}),openRead:(_,ordinal)=>old.retainedFileRead(old.openedFile(openSync(entries[ordinal].frame.file,'r')),entries[ordinal].frame.bytes)},indexIdentity,revision,directory('index'));

await old.writeTimelineEventPages({sourceIdentity:identity,sceneIdentity,revision,interrupted:true,source:sourceReader,scenes},directory('events'));
// File readers validate every emitted evidence payload, including images and canonical coverage.
const portableIndex=new old.FileScreenshotIndex(directory('index'),indexIdentity,revision);
for(const entry of portableIndex.page({identity:indexIdentity}).entries)portableIndex.openRead(indexIdentity,entry.candidate.ordinal).release();
const eventReader=new old.FileTimelineEvents(directory('events'),{sourceIdentity:identity,sceneIdentity,revision,interrupted:true});
await old.validateTimelineEventPages(eventReader,{sourceIdentity:identity,sceneIdentity,revision,interrupted:true,source:sourceReader,scenes});
await mkdir(join(input,'source'));await mkdir(join(input,'revisions'));
for(const role of ['video','system'])await copyFile(canonical[role],join(input,'source',role+'.mov'));
await writeFile(join(input,'source','capture.journal.jsonl'),journal);
await writeFile(join(input,'revisions','r0.json'),JSON.stringify(revision));
await writeFile(join(input,'README.md'),report.scope+'\n');
const inventory=[];
async function walk(dir,base=''){for(const name of await readdir(dir)){const path=join(base,name),full=join(dir,name),info=await stat(full);if(info.isDirectory())await walk(full,path);else{const bytes=await readFile(full);let role=path==='README.md'?'document':path.startsWith('source/')?(name==='capture.journal.jsonl'?'journal':name.split('.')[0]):path.startsWith('revisions/')?'revision':path.startsWith('evidence/index/images/')?'image':path.startsWith('evidence/index/')?(name.startsWith('coverage')||name.startsWith('candidateCoverage')?'coverage':'index'):path.split('/')[1];inventory.push({path,role,bytes:bytes.length,sha256:sha(bytes),...(['video','system'].includes(role)?{durationUs}: {})})}}}
await walk(input);
// Generic index inventory names coverage pages by writer output; metadata/pages remain index role.
const evidence=['source','scenes','index','events'].map(kind=>({artifact:{reference:{kind,recordingId:identity.recordingId,sourceId:identity.sourceId,revisionId:'r0'},generation:kind==='source'?identity.generation:kind==='scenes'?sceneIdentity.generation:kind==='index'?indexIdentity.generation:'authored-events-23o',policy:kind==='scenes'?old.scenePolicy.id:kind==='index'?old.selectionPolicy.id:kind==='source'?'source-normalization-v2':'timeline-events-v1',options:kind==='index'?{clean:true}:{},timeDomain:['source','scenes'].includes(kind)?'source':'playback'},files:inventory.filter(x=>x.path.startsWith('evidence/'+kind+'/')).map(x=>x.path)}));
const manifest={schemaVersion:1,snapshot:{recordingId:identity.recordingId,sourceId:identity.sourceId,revisionId:'r0',sourceDurationUs:durationUs,historyThroughOrdinal:0,capture:{state:'interrupted',createdAt:'authored-23o',interruptionReason:'PACKED_MEDIA_INVALID'}},acquisition:{recordingId:identity.recordingId,sourceId:identity.sourceId,sourceGeneration:identity.generation,narration:'not_acquired',system:'acquired'},inventory,history:[{id:'r0',path:'revisions/r0.json'}],evidence,transcript:'unavailable:no_narration'};
const revisions=new Map([['revisions/r0.json',JSON.stringify(revision)]]);
old.validateManifest(JSON.stringify(manifest),revisions,old.archiveLimits);
await writeFile(join(input,'manifest.json'),JSON.stringify(manifest));
const members=[];
for(const path of [...inventory.map(x=>x.path),'manifest.json']){const full=join(input,path),handle=await open(full),info=await handle.stat({bigint:true}),bytes=await readFile(full);members.push({path,bytes:bytes.length,sha256:sha(bytes),identity:old.fileIdentity(info)});await handle.close()}
await writeFile(join(out,'archive-plan.json'),JSON.stringify(members));await mkdir(join(out,'archive-workspace'));
const inputHandle=await open(input),plan=await open(join(out,'archive-plan.json')),workspace=await open(join(out,'archive-workspace'));
try{const archive=await writeArchive({handle:inputHandle,plan,bytes:members.reduce((n,x)=>n+x.bytes,0)},{directory:join(out,'archive-workspace'),handle:workspace},worker);await copyFile(join(out,'archive-workspace',archive.receipt.path),join(out,'authored-system-inspection.zip'));report.archive=archive.receipt;await archive.close()}finally{await inputHandle.close();await plan.close();await workspace.close()}
report.source={journal:{bytes:journal.length,sha256:sha(journal)},normalization,canonical};report.manifest=manifest;report.scene={metadata:sceneMetadata,chunk};report.index={metadata:indexMetadata,candidates,coverage};report.passed=true;
await writeFile(join(out,'fixture-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:true,archive:report.archive,candidates:entries.length}));
