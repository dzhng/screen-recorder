import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,cp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';import {randomUUID,createHash} from 'node:crypto';
import {RevisionStore} from '/Users/david/dev/screen-recorder/packages/core/dist/library.js';
import {JourneyService,poll} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out=await mkdtemp('/tmp/screenrec-cleanup-cancel-'),report={trace:[],passed:false};
const donor='/var/folders/3p/k21gnpt573b8yy45xvy27nd00000gn/T/screenrec-cleanup-long-source-ugo70nh8';
const header=JSON.parse((await readFile(join(donor,'capture.journal.jsonl'),'utf8')).split('\n')[0]).data;
const home=join(out,'home');await mkdir(home);let ids=0;
const store=new RevisionStore(join(home,'library.sqlite'),{now:()=>new Date().toISOString(),newId:()=>++ids===2?header.sessionID:randomUUID()});
const recording=store.allocate().recording;store.ingestLifecycle(recording.recordingId,{sourceId:recording.sourceId,sequence:1,state:'interrupted',reason:'NO_VIDEO',sourceDurationUs:null});const before=store.get(recording.recordingId);store.close();
const source=join(home,'recordings',recording.recordingId,'source');await cp(donor,source,{recursive:true});
const digest=async()=>Object.fromEntries(await Promise.all(['capture.journal.jsonl','narration.mov','narration.publication.json',].map(async n=>[n,createHash('sha256').update(await readFile(join(source,n))).digest('hex')])));
const hashes=await digest();const service=new JourneyService(home,report,join(out,'reads.jsonl'),new URL('file:///tmp/screenrec-20d5-root-service.mjs'));
try{await service.start();const admitted=await service.call('recording.cleanup',{recordingId:recording.recordingId});assert.equal(admitted.target.revisionId,null);
let held=false;
for(let i=0;i<400;i++){
 const probe=spawnSync('python3',['-c',"import fcntl,sys; f=open(sys.argv[1]);\ntry: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)\nexcept BlockingIOError: sys.exit(75)",join(source,'capture.journal.jsonl')]);
 if(probe.status===75){held=true;break;}await new Promise(r=>setTimeout(r,10));
}
assert(held,'actual native journal lease not observed');
const ready=await service.call('job.cancel',{jobId:admitted.jobId});assert.equal(ready.state,'canceled',JSON.stringify(ready));assert.deepEqual(await digest(),hashes);report.nativeLeaseObserved=true;
const after=await service.call('recording.get',{recordingId:recording.recordingId});assert.deepEqual(after,before);report.before=before;report.after=after;report.ready=ready;report.hashes=hashes;report.passed=true;
}finally{await service.stop();await writeFile(join(out,'report.json'),JSON.stringify(report,null,2));console.log(out);}
