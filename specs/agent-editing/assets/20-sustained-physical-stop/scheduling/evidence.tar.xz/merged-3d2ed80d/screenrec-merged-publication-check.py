from pathlib import Path
import subprocess,os,time,json,hashlib
P=Path('/Users/david/.cache/screen-recorder/verification/independent-publication-scheduling/merged-3d2ed80d');P.mkdir(exist_ok=False)
B=Path('/Users/david/dev/screen-recorder/helpers/mac/.build/debug/ScreenRecorderCaptureTests');rows=[]
for name,key in [('overlap','SCREENREC_SOURCE_PUBLICATION_OVERLAP_OUTPUT'),('independent','SCREENREC_INDEPENDENT_PUBLICATION_OUTPUT')]:
 env=os.environ.copy();env[key]=str(P/name);start=time.monotonic();proc=subprocess.Popen([str(B)],env=env,cwd='/Users/david/dev/screen-recorder',stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:out,err=proc.communicate(timeout=30)
 except subprocess.TimeoutExpired:
  proc.kill();out,err=proc.communicate();raise
 (P/(name+'.stdout')).write_text(out);(P/(name+'.stderr')).write_text(err);rows.append({'case':name,'argv':[str(B)],'pid':proc.pid,'exitCode':proc.returncode,'elapsedSeconds':time.monotonic()-start,'environmentOverride':{key:env[key]},'reaped':True});(P/'report.json').write_text(json.dumps({'rootHead':'3d2ed80d','binary':{'path':str(B),'bytes':B.stat().st_size,'sha256':hashlib.sha256(B.read_bytes()).hexdigest()},'cases':rows},indent=2)+'\n');assert proc.returncode==0,err
print(json.dumps(rows,indent=2))
