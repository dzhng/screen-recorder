import subprocess, os, json, time, sys
from pathlib import Path
root=Path(__file__).parent
wt=Path("/Users/david/.codex/worktrees/sustained-stop/screen-recorder")
name, envname = sys.argv[1:3]
out=root/name
env=dict(os.environ);env[envname]=str(out)
cmd=[str(wt/"helpers/mac/.build/debug/ScreenRecorderCaptureTests")]
began=time.monotonic()
with (root/(name+".stdout")).open("wb") as stdout,(root/(name+".stderr")).open("wb") as stderr:
 try:
  proc=subprocess.run(cmd,cwd=wt,env=env,stdout=stdout,stderr=stderr,timeout=40)
  exitcode=proc.returncode; timedout=False
 except subprocess.TimeoutExpired:
  exitcode=None;timedout=True
report={"command":cmd,"cwd":str(wt),"environmentOverride":{envname:str(out)},"elapsedSeconds":time.monotonic()-began,"exitCode":exitcode,"timedOut":timedout}
(root/(name+".process.json")).write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
sys.exit(124 if timedout else exitcode)
