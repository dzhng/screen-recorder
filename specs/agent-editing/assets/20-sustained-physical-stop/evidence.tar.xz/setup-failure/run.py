import datetime,hashlib,json,os,pathlib,signal,subprocess,time,uuid
out=pathlib.Path(__file__).parent
app=out.parent/'manifest-reference/ScreenRecorder.app'
home=out/'home';home.mkdir(mode=0o700);sock=home/'run/service.sock'
node='/Users/david/.nvm/versions/node/v24.14.0/bin/node';cli=app/'Contents/Resources/cli/main.mjs';worker=app/'Contents/MacOS/screenrec-native'
env={**os.environ,'SCREENREC_HOME':str(home),'SCREENREC_DEFAULTS':str(home/'preferences'),'SCREENREC_SERVICE_LAUNCH':'1','PATH':'/usr/bin:/bin:/usr/sbin:/sbin'}
began=time.monotonic();deadline=began+285;stopAt=None;active=None;p=None;logs=[]
report={'scope':'One actual staged bundled public CLI capture of explicitly selected built-in camera, built-in microphone and display; sustained stop/publication/AppKit/service quit only. No iPhone substitute, physical event sync, drift, installed acceptance or general performance verdict.','home':str(home),'activeTargetSeconds':205,'pauseTargetSeconds':2,'hardDeadlineSeconds':285,'stopPublicationAndQuitDeadlineSeconds':10,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'calls':[],'passed':False}
def save(phase):
 report.update(phase=phase,elapsedSeconds=time.monotonic()-began)
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 (out/'progress.json').write_text(json.dumps({k:report.get(k) for k in ['phase','elapsedSeconds','appPid','servicePid','passed','error','stopToTerminalSeconds','stopToAppExitSeconds']})+'\n')
 print(json.dumps({'phase':phase,'elapsedSeconds':round(report['elapsedSeconds'],3)}),flush=True)
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk);size+=len(chunk)
 return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}
def call(op,params=None,limit=10):
 params={} if params is None else params;at=time.monotonic();allowed=min(limit,deadline-at)
 if stopAt is not None:allowed=min(allowed,stopAt+10-at)
 assert allowed>0,'Original10s completed-stop deadline exhausted'
 q=subprocess.Popen([node,str(cli),op,'--socket',str(sock),'--params',json.dumps(params)],cwd='/',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:stdout,stderr=q.communicate(timeout=allowed)
 except BaseException:q.kill();stdout,stderr=q.communicate();report['calls'].append({'operation':op,'params':params,'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'timedOut':True,'elapsedSeconds':time.monotonic()-at});raise
 report['calls'].append({'operation':op,'params':params,'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'elapsedSeconds':time.monotonic()-at})
 assert q.returncode==0,'CLI operation failed: '+op
 v=json.loads(stdout);assert v['ok'],'Operation refused: '+op
 return v['data']
def bounded_wait(seconds,phase):
 until=time.monotonic()+seconds;nextProgress=time.monotonic()+25
 while time.monotonic()<until:
  assert p.poll() is None,'App exited while capture active'
  assert time.monotonic()<deadline,'Whole-run hard deadline exhausted'
  time.sleep(min(.25,until-time.monotonic()))
  if time.monotonic()>=nextProgress:save(phase);nextProgress=time.monotonic()+25
try:
 report['candidatePins']=[pin(app/x) for x in ['Contents/MacOS/ScreenRecorder','Contents/MacOS/screenrec-native','Contents/Resources/service/main.mjs','Contents/Resources/cli/main.mjs','Contents/Resources/service/runtime.json']]
 subprocess.run(['/usr/bin/defaults','write',str(home/'preferences'),'showSettingsAtLaunch','-bool','NO'],check=True,timeout=3)
 logs=[(out/'app.stdout').open('w'),(out/'app.stderr').open('w')]
 p=subprocess.Popen([str(app/'Contents/MacOS/ScreenRecorder')],cwd='/',env=env,stdout=logs[0],stderr=logs[1],start_new_session=True);report['appPid']=p.pid;save('starting')
 readyDeadline=time.monotonic()+12
 while not sock.exists() and p.poll() is None and time.monotonic()<readyDeadline:time.sleep(.05)
 assert sock.is_socket(),'Listener unavailable'
 health=call('service.health');report['servicePid']=health['pid'];assert health['home']==str(home),'Unexpected service home'
 report['before']=call('capture.status');assert report['before']['device']['state']=='idle','Capture not initially idle'
 sources=call('capture.sources');report['sources']=sources
 camera='6C707041-05AC-0011-0009-000000000001';mic='BuiltInMicrophoneDevice'
 assert any(x['id']==camera for x in sources['cameras']),'Explicit built-in camera absent; no fallback'
 assert any(x['id']==mic for x in sources['microphones']),'Explicit built-in microphone absent; no fallback'
 assert any(x['id']==1 for x in sources['displays']),'Explicit display1 absent; no fallback'
 selection={'source':{'kind':'display','displayId':1},'microphone':True,'systemAudio':False,'microphoneDeviceId':mic,'cameraDeviceId':camera,'requestId':'sustained-builtin-'+str(uuid.uuid4())}
 (out/'request.json').write_text(json.dumps(selection,indent=2)+'\n');report['selection']=selection
 start=call('capture.start',selection,limit=15);report['start']=start;active=start['recordingId'];assert start['state']=='recording'
 recordingAt=time.monotonic();save('recording-before-pause');bounded_wait(100,'recording-before-pause')
 report['pause']=call('capture.pause',{'recordingId':active});assert report['pause']['state']=='paused';pauseAt=time.monotonic();save('paused');bounded_wait(2,'paused')
 report['resume']=call('capture.resume',{'recordingId':active});assert report['resume']['state']=='recording';resumeAt=time.monotonic();report['pauseWallSeconds']=resumeAt-pauseAt
 save('recording-after-resume');bounded_wait(105,'recording-after-resume')
 report['beforeStop']=call('capture.status');assert report['beforeStop']['device']['state']=='recording'
 report['observedRecordingWallExcludingPauseSeconds']=time.monotonic()-recordingAt-report['pauseWallSeconds'];assert report['observedRecordingWallExcludingPauseSeconds']>=205
 stopAt=time.monotonic();report['stopRequestedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('stopping')
 report['stopAck']=call('capture.stop',{'recordingId':active},limit=10)
 while True:
  take=call('recording.get',{'recordingId':active},limit=2);report['latestRecording']=take
  if take['state'] in ['complete','interrupted','canceled']:break
  assert time.monotonic()<stopAt+10,'Stop did not publish terminal take within original10s'
  time.sleep(.1)
 report['stopToTerminalSeconds']=time.monotonic()-stopAt;assert take['state']=='complete','Terminal recording incomplete'
 publication=take['publication'];assert publication['inputsClosed'],'Inputs not physically closed'
 assert publication['primary']['state']==publication['camera']['state']=='published','Source outcome not published'
 assert publication['primary']['source']['sourceDurationUs']>=200_000_000,'Primary source below200s'
 assert publication['camera']['source']['sourceDurationUs']>=200_000_000,'Camera source below200s'
 report['terminalRecording']=take;active=None;save('durable-published-quitting')
 report['quitSignalAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.send_signal(signal.SIGTERM);p.wait(timeout=max(.001,stopAt+10-time.monotonic()))
 report['stopToAppExitSeconds']=time.monotonic()-stopAt;assert report['stopToAppExitSeconds']<=10,'Stop-to-AppKit exit exceeded original10s'
 assert p.returncode==0,'App exit failure'
 report['appExitCode']=p.returncode;report['appReaped']=True
 serviceStatus=subprocess.run(['ps','-p',str(report['servicePid']),'-o','pid=,ppid=,stat=,command='],capture_output=True,text=True,timeout=2)
 report['serviceAfterQuit']=serviceStatus.stdout;report['servicePidAbsent']=not serviceStatus.stdout.strip();assert report['servicePidAbsent'],'Service survives actual app quit'
 report['socketAbsent']=not sock.exists();assert report['socketAbsent'],'Service socket survives quit'
 report['passed']=True;save('capture-passed-inspecting-private-results')
except BaseException as e:
 report['error']=repr(e);save('failed-no-retry')
finally:
 if p is not None and p.poll() is None:
  report['cleanupSignalAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.send_signal(signal.SIGTERM)
  try:p.wait(timeout=min(12,max(.1,deadline-time.monotonic())))
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();report['forcedGroupKill']=True
 if p is not None:report.update(appExitCode=p.returncode,appReaped=True)
 for log in logs:log.close()
 report['socketAbsent']=not sock.exists()
 if report.get('servicePid'):
  q=subprocess.run(['ps','-p',str(report['servicePid']),'-o','pid=,ppid=,stat=,command='],capture_output=True,text=True,timeout=2);report['servicePidAbsent']=not q.stdout.strip();report['serviceAfterCleanup']=q.stdout
 try:
  recording=home/'library/recordings'/report.get('start',{}).get('recordingId','missing')
  report['recordingFiles']=[pin(f) for f in recording.rglob('*') if f.is_file()]
  results={}
  for sub in ['source','camera']:
   journal=recording/sub/'capture.journal.jsonl'
   if journal.is_file():
    rows=(json.loads(v) for v in journal.read_text().splitlines());finished=[v['data'] for v in rows if v['event']=='finished'];results[sub]=finished[-1] if finished else None
  report['durableCaptureResults']=results
  if report['passed']:
   assert set(results)=={'source','camera'} and all(results.values()),'Missing durable finished source outcomes'
   assert all(r['state']=='complete' and r['durationUs']>=200_000_000 for r in results.values()),'Durable source result incomplete'
   assert all(len(r['pauses'])==1 for r in results.values()),'Expected single durable pause per source'
   report['drops']={k:[{'role':t['role'],'droppedSamples':t['droppedSamples'],'omittedSamples':t['omittedSamples'],'samples':t['samples']} for t in v['tracks']] for k,v in results.items()}
   assert all(t['droppedSamples']==0 for r in results.values() for t in r['tracks']),'Actual dropped samples nonzero'
  report['nativeMetadata']=[]
  for f in recording.rglob('*.mov'):
   request={'id':str(uuid.uuid4()),'operation':'media.probe','params':{'path':str(f)}};at=time.monotonic()
   q=subprocess.Popen([str(worker)],cwd='/',env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   try:stdout,stderr=q.communicate(json.dumps(request)+'\n',timeout=min(15,max(.1,deadline-time.monotonic())))
   except subprocess.TimeoutExpired:q.kill();stdout,stderr=q.communicate();report['nativeMetadata'].append({'path':str(f),'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'timedOut':True});raise
   row={'path':str(f),'request':request,'pid':q.pid,'exitCode':q.returncode,'stdout':stdout,'stderr':stderr,'elapsedSeconds':time.monotonic()-at};report['nativeMetadata'].append(row)
   assert q.returncode==0 and json.loads(stdout)['ok'],'Native metadata probe failed'
  report['afterCandidatePins']=[pin(pathlib.Path(v['path'])) for v in report['candidatePins']];assert report['afterCandidatePins']==report['candidatePins'],'Candidate changed during check'
 except BaseException as e:report['evidenceError']=repr(e);report['passed']=False
 report['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('complete' if report['passed'] else 'failed-retained')
 print(json.dumps({k:report.get(k) for k in ['passed','error','evidenceError','appPid','servicePid','appExitCode','servicePidAbsent','socketAbsent','stopToTerminalSeconds','stopToAppExitSeconds','elapsedSeconds']}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
