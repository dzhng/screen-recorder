import pathlib,subprocess,time,os,json,hashlib,shutil,ctypes
root=pathlib.Path(__file__).parent
wt=pathlib.Path('/Users/david/.codex/worktrees/sustained-stop/screen-recorder')
donor=pathlib.Path('/private/tmp/sr-sustain-dxstjza3/library/recordings/03aaae8b-0a68-418b-9238-080504b5f5ca/camera')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}
receipt=json.loads((donor/'camera.publication.json').read_text())
assert receipt['representedFrames']==6145 and receipt['pictureTimeScale']==1000000
assert receipt['pictureSHA256']=='4e923cdd76e318daf9f131c7a1b79ee8d2b1afadc48d98bdec274c2754c517d0'
assert receipt['support']=={'startUs':712680,'endUs':205714400}
assert not (root/'output').exists(), 'One fixed attempt; no overwrite/retry'
source=[]
for folder in ['helpers/mac/Sources/ScreenRecorderCapture','helpers/mac/Sources/ScreenRecorderMedia','helpers/mac/Tests/ScreenRecorderCaptureTests']:
 for p in (wt/folder).glob('*.swift'):
  rel=p.relative_to(wt);dest=root/'executed-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);source.append({'path':str(rel),**digest(p)})
for rel in ['helpers/mac/Package.swift','helpers/mac/Package.resolved']:
 p=wt/rel;dest=root/'executed-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);source.append({'path':rel,**digest(p)})
binary=wt/'helpers/mac/.build/debug/ScreenRecorderCaptureTests'; frozen=root/'executed-binary'
assert ctypes.CDLL(None,use_errno=True).clonefile(os.fsencode(binary),os.fsencode(frozen),0)==0
before={str(p.relative_to(donor)):digest(p) for p in donor.iterdir() if p.is_file()}
(root/'donor-before.json').write_text(json.dumps(before,indent=2))
(root/'executed-source.json').write_text(json.dumps(source,indent=2))
(root/'diff.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=wt))
env=dict(os.environ);env['SCREENREC_RETAINED_CAMERA_PUBLICATION_OUTPUT']=str(root/'output');env['SCREENREC_RETAINED_CAMERA_PUBLICATION_SOURCE']=str(donor)
began=time.monotonic();last_phase=None;timeout=False
with (root/'stdout.log').open('wb') as out,(root/'stderr.log').open('wb') as err:
 process=subprocess.Popen([str(frozen)],env=env,stdout=out,stderr=err)
 (root/'live-process.json').write_text(json.dumps({'pid':process.pid,'binary':str(frozen),'startedMonotonic':began,'wholeProcessDeadlineSeconds':90},indent=2))
 while process.poll() is None:
  if time.monotonic()-began>=90:
   timeout=True;process.terminate()
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:process.kill();process.wait()
   break
  progress=root/'output/progress.json'
  if progress.exists():
   try:current=json.loads(progress.read_text());phase=current['phase']
   except (json.JSONDecodeError,KeyError):phase=None
   if phase and phase!=last_phase:print(json.dumps({'pid':process.pid,'progress':current}),flush=True);last_phase=phase
  time.sleep(.25)
 code=process.wait()
after={str(p.relative_to(donor)):digest(p) for p in donor.iterdir() if p.is_file()}
(root/'donor-after.json').write_text(json.dumps(after,indent=2))
stderr=(root/'stderr.log').read_text();fallback='camera verification: outcome=full-scan-fallback' in stderr
report={'pid':process.pid,'exitCode':code,'wholeProcessSeconds':time.monotonic()-began,'timedOut':timeout,'wholeProcessDeadlineSeconds':90,'binary':str(frozen),'binaryIdentity':digest(frozen),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip(),'donor':str(donor),'donorAllExistingRegularFileBytesUnchanged':before==after,'fallbackReported':fallback,'qualified':code==0 and not timeout and not fallback and before==after,'scope':'Fresh cloned closed-camera final proof after new priming; neither physical Stop nor SDK drain nor installed release.'}
(root/'process.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True);print((root/'stdout.log').read_text(),flush=True);print(stderr[-3000:],flush=True)
