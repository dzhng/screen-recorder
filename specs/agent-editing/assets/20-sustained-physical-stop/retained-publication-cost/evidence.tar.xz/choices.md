# Choices

Use one fresh APFSclone of the retained physical camera source, with no existing
canonical or camera/source publication receipt. High confidence: a cached success
would not measure the final proof owner, and copying only required raw/mapping/
marker/journal operands preserves source authority without replaying acquisition.

Prime new Verification state through one complete checkpoint, then separately time
one camera publication. High confidence on this controlled mechanism: actual SDK
reader records and final exact picture identity prove both ordered prefix states
and bounded final tails. It does not reconstruct the original capture's before-
Stop verification progress, SDK drain or shared primary work.

Allow different canonical-container bytes while requiring the original ordered
picture hash, exact support, scale, binding, origin, pauses and diagnostics. High
confidence: independently rebuilt container metadata is outside picture identity;
this is an explicit measurement scope, not a pixel tolerance. The changed journal
receipt prefix may include an original terminal suffix while preserving clock
authority, so receipt JSON byte identity is also outside the claim.

Use the debug test executable for cheap feedback. High confidence on the exact
proof result; no causal or timing inference to the release app or either physical
Stop run. Both timings are native consumer monotonic intervals. The producer's
wholeProcessSeconds field includes post-exit donor hashing and is a conservative
upper bound on child lifetime, not an exact child wall-clock duration.

Stop after one qualified attempt. No repeat or profiler is warranted by this
result; physical shutdown still requires its own changed-candidate confirmation.
