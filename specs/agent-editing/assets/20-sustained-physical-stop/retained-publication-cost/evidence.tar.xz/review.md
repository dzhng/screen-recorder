# Review verdict

Clean: refactor-clean, code-review and write-docs. The existing stop-scale consumer
owns the diagnostic extension; no production module, hook, owner, endpoint or
ordinary-suite runtime was added. The original camera and all donor files stay
read-only, and every output belongs to a new scratch directory.

Independent prelaunch review required a literal frozen picture/count/support/scale
reference and a prime-both-reader gate before final publication. Both were fixed
before the sole measured attempt. Original receipt and whole source identities,
original validated journal prefix and current shared-clock facts are persisted
before guards. Raw and private canonical prime views are APFScloned and explicitly
unverified; both real priming SDK readers must start before publication begins.
Final proof saves complete new receipt and actual reader ranges before accepting
exact pixels/support/binding/origin/pauses and requiring both final readers to
resume strictly beyond source origin. Source receipt JSON identity is not inferred
from retained picture identity; the original journal has a later terminal suffix.

One externally bounded process performed the measurement. No fallback was
reported, no input was acquired, no app was opened, and no additional decoder,
profiler, physical test, inference or full-suite run followed. Reader restoration
happens only after Verification.close joins its work; original/new journal leases
are released by their owners after joined work. Failed owned candidates remain
diagnostic inputs instead of being deleted by this consumer.

The helper README links this existing consumer and states its closed-source scope;
the root README reaches the helper README. The consumer is opt-in and absent from
the normal suite, because this externally supplied large fixture is measurement
work rather than an everyday regression. Its assertions preserve exact proof, not
a host-specific timing threshold.
