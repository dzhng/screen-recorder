import datetime,hashlib,json,pathlib,sqlite3
out=pathlib.Path(__file__).parent;r=json.loads((out/'report.json').read_text());setup=json.loads((out/'setup.json').read_text());home=pathlib.Path(r['home']);recording=home/'library/recordings'/r.get('start',{}).get('recordingId','missing');stopMono=r.get('stopMonotonicSeconds');stopWall=datetime.datetime.fromisoformat(r['stopRequestedAt']).timestamp() if r.get('stopRequestedAt') else None;transitions=[];prior=None
for call in r['calls']:
 if call['operation']!='recording.get' or not call.get('stdout'):continue
 reply=json.loads(call['stdout'])
 if not reply.get('ok'):continue
 d=reply['data'];p=d['publication'];value={'state':d['state'],'inputsClosed':p['inputsClosed'],'primaryState':(p['primary'] or {}).get('state'),'cameraState':(p['camera'] or {}).get('state'),'admissions':[{'kind':a['kind'],'jobId':(a['job'] or {}).get('jobId'),'jobState':(a['job'] or {}).get('state')} for a in d['sourceAdmissions']]}
 if value!=prior:transitions.append({'callBeginAfterStopSeconds':call['beganMonotonicSeconds']-stopMono,'callEndAfterStopSeconds':call['endedMonotonicSeconds']-stopMono,'lifecycleSequence':d['lifecycleSequence'],'observation':value});prior=value
facts={};fileTimes=[]
for f in recording.rglob('*'):
 if not f.is_file():continue
 stat=f.stat();fileTimes.append({'path':str(f.relative_to(recording)),'bytes':stat.st_size,'mtimeNs':stat.st_mtime_ns,'ctimeNs':stat.st_ctime_ns,'birthtime':getattr(stat,'st_birthtime',None),'mtimeAfterStopSeconds':stat.st_mtime-stopWall if stopWall else None})
for sub in ['source','camera']:
 path=recording/sub/'capture.journal.jsonl';events={};finished=[];sequences=[]
 if path.is_file():
  for line in path.read_text().splitlines():
   row=json.loads(line);events[row['event']]=events.get(row['event'],0)+1
   if row['event']=='finished':finished.append(row)
   if row['event']=='lifecycle':sequences.append(row)
  facts[sub]={'events':events,'finished':finished,'terminalLifecycles':sequences[-3:]}
  for filename in ['source.publication.json','camera.publication.json','narration.publication.json']:
   member=recording/sub/filename
   if member.is_file():facts[sub][filename]=json.loads(member.read_text())
(out/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n');(out/'publication-transitions.json').write_text(json.dumps(transitions,indent=2)+'\n');(out/'post-cleanup-file-times.json').write_text(json.dumps(fileTimes,indent=2)+'\n')
row=None;jobs=[];acqs=[]
catalog=home/'library/catalog.sqlite'
if catalog.is_file():
 conn=sqlite3.connect('file:'+str(catalog)+'?mode=ro',uri=True);conn.row_factory=sqlite3.Row
 raw=conn.execute('select * from recordings').fetchone();row=dict(raw) if raw else None;jobs=[dict(j) for j in conn.execute('select * from jobs')];acqs=[dict(a) for a in conn.execute('select * from acquisitions')];conn.close()
(out/'post-cleanup-recording-row.json').write_text(json.dumps(row,indent=2)+'\n');(out/'post-cleanup-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');(out/'post-cleanup-acquisitions.json').write_text(json.dumps(acqs,indent=2)+'\n')
kindById={a['id']:json.loads(a['admission'])['source']['kind'] for a in acqs};pub=json.loads(row['publication'])['observation'] if row else{};results=r.get('durableCaptureResults',{});stopCall=next((c for c in r['calls'] if c['operation']=='capture.stop'),{});lastPoll=next((c for c in reversed(r['calls']) if c['operation']=='recording.get' and c.get('stdout')),None)
summary={'scope':r['scope'],'expectedImplementationHead':setup['expectedImplementationHead'],'passed':r['passed'],'verdict':'PASS: both durablepublished sources and actual app/servicequit within original10s deadline.' if r['passed'] else 'RED: original deadline or physical lifecycle check failed; later cleanup remains separate.','error':r.get('error'),'evidenceError':r.get('evidenceError'),'physicalAttempts':1 if r.get('start') else 0,'scopeDelta':setup['scopeDelta'],'activeObservedSeconds':r.get('observedRecordingWallExcludingPauseSeconds'),'durableSourceDurationUs':{k:v['durationUs'] for k,v in results.items() if v},'pauses':{k:v['pauses'] for k,v in results.items() if v},'tracks':{k:v['tracks'] for k,v in results.items() if v},'cursor':{k:v['cursor'] for k,v in results.items() if v},'stopAckSeconds':stopCall.get('elapsedSeconds'),'stopAckState':r.get('stopAck',{}).get('state'),'stopToTerminalSeconds':r.get('stopToTerminalSeconds'),'stopToAppExitSeconds':r.get('stopToAppExitSeconds'),'stopBeginElapsedSeconds':r.get('stopBeginElapsedSeconds'),'observedTransitions':transitions,'lastCallEndAfterStopSeconds':lastPoll['endedMonotonicSeconds']-stopMono if lastPoll and stopMono else None,'cleanupAfterStopSeconds':datetime.datetime.fromisoformat(r['cleanupSignalAt']).timestamp()-stopWall if r.get('cleanupSignalAt') and stopWall else None,'afterActualExit':{'state':row['state'] if row else None,'lifecycleSequence':row['lifecycleSequence'] if row else None,'finalizationError':row['finalizationError'] if row else None,'inputsClosed':pub.get('inputsClosed'),'primaryState':(pub.get('primary') or {}).get('state'),'cameraState':(pub.get('camera') or {}).get('state'),'appPid':r.get('appPid'),'appExitCode':r.get('appExitCode'),'appReaped':r.get('appReaped'),'servicePid':r.get('servicePid'),'servicePidAbsent':r.get('servicePidAbsent'),'socketAbsent':r.get('socketAbsent')},'postExitJobs':[{'kind':kindById.get(j['targetId']),'jobId':j['jobId'],'targetId':j['targetId'],'artifact':j['artifact'],'state':j['state'],'reason':j['reason'],'errorCode':j['errorCode']} for j in jobs],'candidatePinsUnchanged':r.get('afterCandidatePins')==r.get('candidatePins'),'privateMediaLogicalBytes':sum(f['bytes'] for f in r.get('recordingFiles',[]) if f['path'].endswith('.mov')),'metadataProbeCount':len(r.get('nativeMetadata',[])),'hostObservations':{'beforeCapture':str(out/'host-before-capture.json'),'beforeStop':str(out/'host-before-stop.json'),'meaning':'Saved basic uptime/vm_stat/ps observations only; no causal load comparison or latency attribution'},'fileTimes':fileTimes,'limits':['No physical event synchronization/drift/image or audible quality/iPhone/installed-app acceptance','Beforestop internalverification range/picture count unknown; no snapshot collected','Sourceflags and receiptmtimes establish observations/ordering, not internalSDK/normalization/decoder phase durations','Postexit jobs lack start/end timestamps; kinds bound through actualacquisition admission.source.kind','No crosscase causal performance attribution','No retry, recapture, recoveryrestart, source/library change or additional nativepixeldecode']}
(out/'compact-report.json').write_text(json.dumps(summary,indent=2)+'\n');pins=[]
for f in out.iterdir():
 if f.is_file() and f.name!='evidence-pins.json':pins.append({'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(out/'evidence-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['passed','verdict','error','physicalAttempts','activeObservedSeconds','durableSourceDurationUs','stopToTerminalSeconds','stopToAppExitSeconds','lastCallEndAfterStopSeconds','candidatePinsUnchanged']}))
