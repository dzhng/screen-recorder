@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import CoreVideo
import Darwin

struct TimingFact: Encodable {
    let duration: Tick; let pts: Tick; let dts: Tick
    init(_ t: CMSampleTimingInfo) { duration=Tick(t.duration); pts=Tick(t.presentationTimeStamp); dts=Tick(t.decodeTimeStamp) }
}
struct TypedFact: Encodable {
    let present: Bool; let value: FormatValue?; let error: String?; let unsupportedType: String?; let unsupportedDescription: String?
    init(_ raw: Any?) {
        present=raw != nil
        guard let raw else { value=nil;error=nil;unsupportedType=nil;unsupportedDescription=nil;return }
        do { value=try FormatValue(raw);error=nil;unsupportedType=nil;unsupportedDescription=nil }
        catch { value=nil;self.error=String(describing:error);unsupportedType=String(describing:type(of:raw));unsupportedDescription=String(describing:raw) }
    }
}
struct TimingArrayFact: Encodable { let queryStatus: Int32; let entriesNeeded: Int; let readStatus: Int32?; let entriesReturned: Int?; let values: [TimingFact]?; let boundedOmission: Bool }
struct SizeArrayFact: Encodable { let queryStatus: Int32; let entriesNeeded: Int; let readStatus: Int32?; let entriesReturned: Int?; let values: [Int]?; let boundedOmission: Bool }
struct IndexedFact: Encodable { let sampleIndex: Int; let timingStatus: Int32; let timing: TimingFact?; let sizeBytes: Int }
struct BufferFormat: Encodable { let mediaType: UInt32; let subtype: UInt32; let sourceEqual: Bool; let dimensions: [Int]?; let extensions: TypedFact }
struct BufferFact: Encodable {
    let bufferOrdinal: Int; let numSamples: Int; let valid: Bool; let dataReady: Bool
    let blockPresent: Bool; let blockBytes: Int?; let copiedBytes: Int; let copyStatus: Int32?; let payload: Data?; let blockCopyComplete: Bool?
    let imagePresent: Bool; let formatPresent: Bool; let format: BufferFormat?
    let clocks: [String:Tick]; let rawTiming: TimingArrayFact; let outputTiming: TimingArrayFact; let sizes: SizeArrayFact; let indexed: [IndexedFact]; let indexedOmittedForBound: Bool
    let bufferShouldPropagate: TypedFact; let bufferShouldNotPropagate: TypedFact; let sampleAttachmentsCreateFalse: TypedFact
}
struct NativeRows: Decodable { struct Row: Decodable { let ordinal: Int; let cursor: CursorFact }; let rows: [Row] }
struct Correspondence: Encodable { let bufferOrdinal: Int; let sampleIndex: Int; let returnedMediaSamplePosition: Int; let nativeDecodePosition: Int?; let nativePresentationOrdinal: Int?; let fieldsDiffering: [String] }

func timingArray(_ sample: CMSampleBuffer, output: Bool) -> TimingArrayFact {
    var needed=0
    let q=output ? CMSampleBufferGetOutputSampleTimingInfoArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed) : CMSampleBufferGetSampleTimingInfoArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed)
    guard needed>0 && needed<=400 else {return TimingArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:nil,entriesReturned:nil,values:nil,boundedOmission:needed>400)}
    var array=[CMSampleTimingInfo](repeating:CMSampleTimingInfo(),count:needed),returned=needed
    let status=output ? CMSampleBufferGetOutputSampleTimingInfoArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned) : CMSampleBufferGetSampleTimingInfoArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned)
    return TimingArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:status,entriesReturned:returned,values:status==noErr ? array.prefix(min(max(0,returned),array.count)).map(TimingFact.init) : nil,boundedOmission:returned>array.count)
}
func sizeArray(_ sample: CMSampleBuffer) -> SizeArrayFact {
    var needed=0;let q=CMSampleBufferGetSampleSizeArray(sample,entryCount:0,arrayToFill:nil,entriesNeededOut:&needed)
    guard needed>0 && needed<=400 else {return SizeArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:nil,entriesReturned:nil,values:nil,boundedOmission:needed>400)}
    var array=[Int](repeating:0,count:needed),returned=needed
    let status=CMSampleBufferGetSampleSizeArray(sample,entryCount:needed,arrayToFill:&array,entriesNeededOut:&returned)
    return SizeArrayFact(queryStatus:q,entriesNeeded:needed,readStatus:status,entriesReturned:returned,values:status==noErr ? Array(array.prefix(min(max(0,returned),array.count))) : nil,boundedOmission:returned>array.count)
}
func format(_ description: CMFormatDescription, source: CMFormatDescription) -> BufferFormat {
    let type=CMFormatDescriptionGetMediaType(description),subtype=CMFormatDescriptionGetMediaSubType(description)
    let dimensions=type==kCMMediaType_Video ? CMVideoFormatDescriptionGetDimensions(description) : nil
    return BufferFormat(mediaType:type,subtype:subtype,sourceEqual:CMFormatDescriptionEqual(description,otherFormatDescription:source),dimensions:dimensions.map{[Int($0.width),Int($0.height)]},extensions:TypedFact(CMFormatDescriptionGetExtensions(description).map{$0 as NSDictionary}))
}
func observe(_ sample: CMSampleBuffer, ordinal: Int, remainingPayload: Int, source: CMFormatDescription) -> BufferFact {
    let n=CMSampleBufferGetNumSamples(sample),block=CMSampleBufferGetDataBuffer(sample),image=CMSampleBufferGetImageBuffer(sample),description=CMSampleBufferGetFormatDescription(sample)
    var data:Data?,status:Int32?,length:Int?,copied=0
    if let block {
        let count=CMBlockBufferGetDataLength(block);length=count;let wanted=min(count,max(0,remainingPayload));var bytes=Data(count:wanted)
        let result=wanted==0 ? noErr : bytes.withUnsafeMutableBytes{CMBlockBufferCopyDataBytes(block,atOffset:0,dataLength:wanted,destination:$0.baseAddress!)}
        status=result;if result==noErr{data=bytes;copied=wanted}
    }
    var indexed=[IndexedFact]()
    if n>=0 && n<=400 {
        for index in 0..<n {
            var t=CMSampleTimingInfo();let result=CMSampleBufferGetSampleTimingInfo(sample,at:index,timingInfoOut:&t)
            indexed.append(IndexedFact(sampleIndex:index,timingStatus:result,timing:result==noErr ? TimingFact(t) : nil,sizeBytes:CMSampleBufferGetSampleSize(sample,at:index)))
        }
    }
    return BufferFact(bufferOrdinal:ordinal,numSamples:n,valid:CMSampleBufferIsValid(sample),dataReady:CMSampleBufferDataIsReady(sample),blockPresent:block != nil,blockBytes:length,copiedBytes:copied,copyStatus:status,payload:data,blockCopyComplete:block == nil ? nil : (status==noErr && copied==length),imagePresent:image != nil,formatPresent:description != nil,format:description.map{format($0,source:source)},clocks:["rawPTS":Tick(CMSampleBufferGetPresentationTimeStamp(sample)),"rawDTS":Tick(CMSampleBufferGetDecodeTimeStamp(sample)),"rawDuration":Tick(CMSampleBufferGetDuration(sample)),"outputPTS":Tick(CMSampleBufferGetOutputPresentationTimeStamp(sample)),"outputDTS":Tick(CMSampleBufferGetOutputDecodeTimeStamp(sample)),"outputDuration":Tick(CMSampleBufferGetOutputDuration(sample))],rawTiming:timingArray(sample,output:false),outputTiming:timingArray(sample,output:true),sizes:sizeArray(sample),indexed:indexed,indexedOmittedForBound:n<0 || n>400,bufferShouldPropagate:TypedFact(CMCopyDictionaryOfAttachments(allocator:nil,target:sample,attachmentMode:kCMAttachmentMode_ShouldPropagate).map{$0 as NSDictionary}),bufferShouldNotPropagate:TypedFact(CMCopyDictionaryOfAttachments(allocator:nil,target:sample,attachmentMode:kCMAttachmentMode_ShouldNotPropagate).map{$0 as NSDictionary}),sampleAttachmentsCreateFalse:TypedFact(CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false).map{$0 as NSArray}))
}

@main struct CompressedAdmission {
    @MainActor static func main() async {
        var owner:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments,root=URL(fileURLWithPath:args[1]),sourceURL=URL(fileURLWithPath:args[2])
            let admitted=try OwnedEvidenceDestination(root:root);owner=admitted
            let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence"))
            let asset=AVURLAsset(url:sourceURL,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true])
            let tracks=try await asset.loadTracks(withMediaType:.video),audio=try await asset.loadTracks(withMediaType:.audio)
            try save(["source":sourceURL.path,"videos":String(tracks.count),"audio":String(audio.count)],root.appendingPathComponent("source-tracks.json"))
            try require(tracks.count==1 && audio.isEmpty,"source track admission",["videos":String(tracks.count),"audio":String(audio.count)],evidence:evidence)
            let track=tracks[0],descriptions=try await track.load(.formatDescriptions),scale=try await track.load(.naturalTimeScale),transform=try await track.load(.preferredTransform)
            try save(descriptions.map{format($0,source:$0)},root.appendingPathComponent("source-format-descriptions.json"))
            try save(["scale":FormatValue.number(type:"Int32",value:String(scale)),"preferredTransform":FormatValue.array([transform.a,transform.b,transform.c,transform.d,transform.tx,transform.ty].map{.number(type:"CGFloat",value:String(describing:$0))})],root.appendingPathComponent("source-track-metadata.json"))
            try require(descriptions.count==1,"source format admission",["formats":String(descriptions.count)],evidence:evidence)
            let sourceDescription=descriptions[0],reader=try AVAssetReader(asset:asset);defer{reader.cancelReading()}
            let output=AVAssetReaderTrackOutput(track:track,outputSettings:nil);output.alwaysCopiesSampleData=false;reader.add(output)
            let started=reader.startReading()
            try save(["started":String(started),"status":String(reader.status.rawValue),"error":String(describing:reader.error)],root.appendingPathComponent("reader-start.json"))
            try require(started,"compressed reader start",["status":String(reader.status.rawValue)],evidence:evidence)
            var all=[BufferFact](),payload=0,media=0,eof=false
            for ordinal in 0..<512 {
                guard let sample=output.copyNextSampleBuffer() else {eof=true;break}
                let fact=observe(sample,ordinal:ordinal,remainingPayload:2_097_152-payload,source:sourceDescription)
                // Save the complete available fact before even the resource-cap refusal.
                try save(fact,root.appendingPathComponent("buffer-\(ordinal).json"));all.append(fact);payload+=fact.copiedBytes;media+=max(0,fact.numSamples)
                try save(["buffers":String(all.count),"mediaSamples":String(media),"payloadBytes":String(payload),"eof":"false","status":String(reader.status.rawValue)],root.appendingPathComponent("inventory.json"))
                try require(media<=400 && fact.numSamples>=0 && (fact.blockCopyComplete != false) && !fact.indexedOmittedForBound && !fact.rawTiming.boundedOmission && !fact.outputTiming.boundedOmission && !fact.sizes.boundedOmission,"fixed observer resource/complete-copy bounds",["buffer":String(ordinal),"samples":String(media),"blockCopyComplete":String(describing:fact.blockCopyComplete)],evidence:evidence)
            }
            try save(["buffers":String(all.count),"mediaSamples":String(media),"payloadBytes":String(payload),"eof":String(eof),"status":String(reader.status.rawValue),"error":String(describing:reader.error)],root.appendingPathComponent("inventory.json"))
            try require(eof && reader.status == .completed,"compressed EOF completion",["eof":String(eof),"status":String(reader.status.rawValue)],evidence:evidence)
            let native=try JSONDecoder().decode(NativeRows.self,from:Data(contentsOf:URL(fileURLWithPath:args[3])))
            func nativeTime(_ t:Tick)->CMTime{CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)}
            let ordered=native.rows.sorted{CMTimeCompare(nativeTime($0.cursor.clocks["mediaDTS"]!),nativeTime($1.cursor.clocks["mediaDTS"]!))<0}
            var correspondence=[Correspondence](),position=0
            for buffer in all {
                for indexed in buffer.indexed {
                    let matching=ordered.enumerated().filter{$0.element.cursor.clocks["mediaDTS"]==indexed.timing?.dts}
                    let match=matching.count==1 ? matching[0] : nil;var differences=[String]()
                    if indexed.timingStatus != noErr{differences.append("timingStatus")}
                    if match==nil{differences.append("uniqueNativeDTSMembership")}
                    if let match,let t=indexed.timing {
                        if match.offset != position{differences.append("decodePosition")}
                        if t.pts != match.element.cursor.clocks["mediaPTS"]{differences.append("rawPTS")}
                        if t.duration != match.element.cursor.clocks["decodeDuration"]{differences.append("rawDecodeDuration")}
                        if Int64(indexed.sizeBytes) != match.element.cursor.extents["sample"]?.length{differences.append("sampleSize")}
                    }
                    correspondence.append(Correspondence(bufferOrdinal:buffer.bufferOrdinal,sampleIndex:indexed.sampleIndex,returnedMediaSamplePosition:position,nativeDecodePosition:match?.offset,nativePresentationOrdinal:match?.element.ordinal,fieldsDiffering:differences));position+=1
                }
            }
            try save(correspondence,root.appendingPathComponent("native-correspondence.json"))
            let typedErrors=all.flatMap{[$0.bufferShouldPropagate.error,$0.bufferShouldNotPropagate.error,$0.sampleAttachmentsCreateFalse.error,$0.format?.extensions.error]}.compactMap{$0}
            try save(typedErrors,root.appendingPathComponent("typed-value-errors.json"))
            try require(media==197 && ordered.count==197 && correspondence.count==197 && correspondence.allSatisfy{$0.fieldsDiffering.isEmpty} && typedErrors.isEmpty,"complete native source correspondence/typed observation",["media":String(media),"native":String(ordered.count),"correspondence":String(correspondence.count),"typedErrors":String(typedErrors.count)],evidence:evidence)
            try save(["status":"pass","scope":"Complete intact compressed-reader buffer metadata, including markers/groups; no writer or pixel decode","buffers":String(all.count),"mediaSamples":String(media)],root.appendingPathComponent("verdict.json"))
        } catch {if let owner{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
    }
}
