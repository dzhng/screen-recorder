import {validateComposition,createCompiler} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/index.ts';
import {deriveStatePlan} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/processing-state.ts';
for(const windowed of [false,true]) for(const n of [1000,4000,8000]) {
 const doc={canvas:{width:64,height:64,fps:{numerator:30,denominator:1},background:'#000000ff'},tracks:[{id:'a',kind:'audio',order:0}],groups:[],syncGroups:[],clips:Array.from({length:n},(_,i)=>({id:`c${i}`,trackId:'a',source:{kind:'silence'},placement:{kind:'project',range:{startUs:i*1000000,endUs:(i+1)*1000000}}})),processing:Array.from({length:n},(_,i)=>({target:{kind:'clip',id:`c${i}`},steps:[{id:`s${i}`,enabled:true,processor:{type:'rnnoise'},...(windowed?{window:{kind:'project',range:{startUs:i*1000000+100000,endUs:(i+1)*1000000-100000}}}:{})}]}))};
 const start=performance.now(),model=validateComposition(doc,[]),validated=performance.now();const plan=deriveStatePlan(model),derived=performance.now();
 const compiler=createCompiler(model,'r'), request={range:{startUs:200000,endUs:300000},rendition:{sampleRate:48000,channels:2},tap:{target:{kind:'output'},point:{kind:'processed'}}};
 compiler.audioWindow(request); const a=performance.now();for(let j=0;j<10;j++)compiler.audioWindow(request);const b=performance.now();
 const plain=createCompiler(validateComposition({...doc,processing:[]},[]),'r');plain.audioWindow(request);const c=performance.now();for(let j=0;j<10;j++)plain.audioWindow(request);
 console.log(JSON.stringify({windowed,n,domains:plan.domains.length,validateMs:validated-start,deriveMs:derived-validated,smallStateWindowMs:(b-a)/10,smallStatelessWindowMs:(performance.now()-c)/10}));
}
