**Clean for this correction.** Unioning all enabled steps from requested processing and selected state nodes includes the omitted stateless prefixes. Deduplication by globally unique step ID is sound and preserves existing enabled-prefix admission semantics.

The regression checks the out-of-range sibling’s gain requirement directly. My previous review missed this omission.

Read-only inspection; no builds, tests, native execution, or inference run.