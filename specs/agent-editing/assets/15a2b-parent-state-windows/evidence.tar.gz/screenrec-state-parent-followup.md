One remaining actionable issue:

- **[P2] Returned manifests expose mutable cached state** — [processing-state.ts:275](/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/composition/src/processing-state.ts:275). `selectStatePlan` shallow-copies domains, sharing `members`, ranges, and other nested objects with the newly cached `fullState`. A metadata-only probe confirmed that clearing the first window’s `domains[0].members` makes an identical subsequent request omit state entirely. Deep-freeze the cached plan or detach returned mutable data.

The quadratic lookup finding is resolved. WeakMap lifetime follows the immutable model; the activation fast path preserves the existing clock semantics. Recorded scaling is approximately linear. Stateful window selection still performs whole-plan work per request, but I found no additional introduced quadratic issue.

**Verdict: not clean** because of cache aliasing. No edits, broad suites, native execution, or inference; no runtime/listening acceptance implied.