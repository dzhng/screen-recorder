**Clean for this focused review; no remaining actionable issue found.**

- Parsing state at the manifest owner detaches nested data from the compiler cache.
- Selected state members—including dependencies—add readiness requirements, deduplicated by globally unique step ID.
- RNNoise remains unbound, so internal-gap requests refuse before renderer admission.
- Both regressions exercise the reported failures appropriately.

Read-only inspection only; I did not rerun the reported 242-pass/1-skip checks or infer runtime/listening acceptance.