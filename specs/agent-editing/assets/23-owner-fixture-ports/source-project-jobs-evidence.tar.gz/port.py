from pathlib import Path
import re
p=Path('/Users/david/dev/screen-recorder/packages/core/src/jobs.test.ts');s=p.read_text();names=['an edit during processing does not move the revision the work was admitted for','the same parameters on an edited revision never reuse the old running job','out-of-order results retain their own revision and input identities','regenerating an evicted artifact preserves its revision and cannot invalidate a newer publication'];blocks={}
for name in names:
 a=s.index('test("'+name+'"');b=s.find('\ntest(',a+1);b=len(s) if b<0 else b;blocks[name]=s[a:b]
s=s.replace('import { RevisionStore } from "./library.js";','import { CaptureStore, isSettled } from "./capture-store.js";\nimport { AssetStore } from "./assets.js";\nimport { projectStoreFixture } from "./project-store.fixture.js";').replace('  recordingJobTargets,\n','').replace('new RevisionStore','new CaptureStore').replace('store: RevisionStore','store: CaptureStore')
a=s.index('  const recordingTargets = recordingJobTargets(store);');b=s.index('  const queue = new JobQueue',a)
s=s[:a]+'''  const projects = projectStoreFixture(store, new AssetStore(store, dirname(path)), dirname(path));
  const targets: JobTargets = {
    pin(target) {
      if (target.kind === "recording") {
        if (target.revisionId !== null)
          throw new CatalogError("NOT_READY", "Unsupported recording job target");
        const recording = store.get(target.recordingId);
        if (!isSettled(recording.state) || recording.state === "canceled" || store.isDeleting(target.recordingId))
          throw new CatalogError("INVALID_STATE", "Source-owned work requires a settled available recording");
        return { ...target, revisionId: null };
      }
      if (target.kind === "project") projects.requireRevision(target.projectId, target.revisionId);
      // Other managed domain fixtures vouch for their inputs; real owners validate their rows.
      return target;
    },
    isAvailable: (target) => target.kind === "recording" ? store.isAvailable(target.recordingId) : target.kind === "project" ? projects.hasRevision(target.projectId, target.revisionId) : true,
    isDeleting: (owner) => owner.kind === "recording" ? store.isDeleting(owner.recordingId) : owner.kind === "project" && projects.isDeleting(owner.projectId),
    isCapturing: () => store.isCapturing(),
  };
'''+s[b:]
s=s.replace('return { store, queue, attempts, started, targets };','return { store, projects, queue, attempts, started, targets };').replace('A finished take: it has a revision to pin, and no capture of it is still outstanding.','A settled source: no capture of it is still outstanding.')
s=s.replace('revisionId: "r0"','revisionId: null')
# Actual explicit project revisions replace four old recording-edit test blocks.
for name,old in blocks.items():
 block=old.replace('{ store, queue, started }','{ projects, queue, started }').replace('const recordingId = finished(store);','const { projectId, revisionId } = project(projects);').replace('recordingId','projectId').replace('kind: "recording"','kind: "project"').replace('"r0"','revisionId')
 block=re.sub(r'store\.edit\(projectId, \{\s*operation: "cut",\s*requestId: "([^"]+)",\s*expectedRevisionId: revisionId,\s*ranges: \[\{ startUs: \d+, endUs: \d+ \}\],\s*\}\)',r'projects.apply(projectId, { requestId: "\1", expectedRevisionId: revisionId, operations: [{ operation: "canvas.set", canvas: { width: 320 } }] }).revision',block)
 block=block.replace('store.revision(','projects.revision(')
 # Every initial project target names the exact caller-selected revision.
 block=block.replace('projectId: projectId }','projectId, revisionId }')
 if name==names[0]:block=block.replace('expect(queue.submit(request).target)','expect(queue.submit({ ...request, target: { ...request.target, revisionId: edited.id } }).target)')
 if name==names[1]:block=block.replace('const second = queue.submit(request);','const second = queue.submit({ ...request, target: { ...request.target, revisionId: revision.id } });')
 if name==names[2]:
  block=block.replace('const current = queue.submit(request);','const current = queue.submit({ ...request, target: { ...request.target, revisionId: edited.id } });').replace('const alternate = queue.submit({ ...request, input: "at=4" });','const alternate = queue.submit({ ...request, target: current.target, input: "at=4" });')
 a=s.index('test("'+name+'"');b=s.find('\ntest(',a+1);b=len(s) if b<0 else b;s=s[:a]+block+s[b:]
# Reuse actual project fixture; no media or clip needed for a real authored revision.
a=s.index('\nafterEach(');s=s[:a]+'''
function project(projects: ReturnType<typeof projectStoreFixture>) {
  const created = projects.create({ requestId: "create", canvas: { width: 160, height: 96, fps: { numerator: 30, denominator: 1 }, background: "#000000ff" } });
  return { projectId: created.project.projectId, revisionId: created.revision.id };
}
'''+s[a:]
s=s.replace('const { store, queue: initial } = fixture();','const { store, queue: initial, targets } = fixture();').replace('targets: recordingJobTargets(store),','targets,')
s=s.replace('expect(() => store.revision(recording.recordingId)).toThrow();','expect(store.get(recording.recordingId).currentRevisionId).toBeNull();\n  expect(store.catalog.prepare("SELECT * FROM project_revisions").all()).toEqual([]);\n  expect(store.catalog.prepare("SELECT * FROM projects").all()).toEqual([]);')
# Generic namespace cases intentionally exercise controlled managed identities, not actual project documents.
s=s.replace('test("managed targets retain distinct kind and revision identities after restart", async () => {\n  const first = fixture();','test("managed targets retain distinct kind and revision identities after restart", async () => {\n  const first = fixture();\n  first.targets.pin = (target) => target.kind === "recording" ? first.targets.pin(target) : target;\n  first.targets.isAvailable = () => true;')
# Avoid self-call; this case never targets recording.
s=s.replace('first.targets.pin = (target) => target.kind === "recording" ? first.targets.pin(target) : target;','first.targets.pin = (target) => { if (target.kind === "recording") throw Error("Managed target required"); return target; };')
name='managed targets retain distinct kind and revision identities after restart';a=s.index('test("'+name);b=s.find('\ntest(',a+1);block=s[a:b].replace('const reopened = open(first.path, "restarted");','const reopened = open(first.path, "restarted");\n  reopened.targets.pin = first.targets.pin;\n  reopened.targets.isAvailable = first.targets.isAvailable;');s=s[:a]+block+s[b:]
s=s.replace('test("deleting a project drains every pinned revision without touching a same-named asset", async () => {\n  const f = fixture();','test("deleting a project drains every pinned revision without touching a same-named asset", async () => {\n  const f = fixture();\n  f.targets.pin = (target) => { if (target.kind === "recording") throw Error("Managed target required"); return target; };\n  f.targets.isAvailable = () => true;')
# Current source and project identities are distinct; obsolete recording implicit edit admission is refused.
a=s.index('test("source targets stay distinct from omitted and explicit revisions"');b=s.find('\ntest(',a+1)
s=s[:a]+'''test("source targets stay distinct from explicit project revisions and refuse recording edit selectors", async () => {
  const { store, projects, queue, started } = fixture();
  const recordingId = finished(store);
  const target = { kind: "project" as const, ...project(projects) };
  const base = { artifact: "target-proof", lane: "heavy" as const, input: "same input" };
  const source = queue.submit({ ...base, target: { kind: "recording", recordingId, revisionId: null } });
  const revision = queue.submit({ ...base, target });
  expect(source.target).toEqual({ kind: "recording", recordingId, revisionId: null });
  expect(revision.target).toEqual(target);
  expect(source.jobId).not.toBe(revision.jobId);
  expect(queue.submit({ ...base, target }).jobId).toBe(revision.jobId);
  expect(() => queue.submit({ ...base, target: { kind: "recording", recordingId } })).toThrow(expect.objectContaining({ code: "NOT_READY" }));
  expect(() => queue.submit({ ...base, target: { kind: "recording", recordingId, revisionId: "r0" } })).toThrow(expect.objectContaining({ code: "NOT_READY" }));
  (await started(source.attemptId)).finish("{}");
  (await started(revision.attemptId)).finish("{}");
  await queue.idle();
});
'''+s[b:]
# Preserve canceled-source lifetime oracle under an explicit controlled domain admission.
a=s.index('test("work that outlives a discarded take');b=s.find('\ntest(',a+1);block=s[a:b].replace('work that outlives a discarded take','domain-admitted work that outlives a discarded capture').replace('{ store, queue, attempts, started }','{ store, queue, attempts, started, targets }').replace('  const recording = store.allocate().recording;','  // This queue-domain control admits live work; current source service admission still refuses it.\n  targets.pin = (target) => {\n    if (target.kind !== "recording" || target.revisionId !== null) throw Error("Source target required");\n    store.get(target.recordingId);\n    return { ...target, revisionId: null };\n  };\n  const recording = store.allocate().recording;');s=s[:a]+block+s[b:]
p.write_text(s)
