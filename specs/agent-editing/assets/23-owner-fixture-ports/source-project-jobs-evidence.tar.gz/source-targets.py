from pathlib import Path
import re,json
p=Path('/Users/david/dev/screen-recorder/packages/core/src/jobs.test.ts');s=p.read_text();a=s.index('test("source targets stay distinct from explicit project revisions');b=s.index('\ntest(',a+1);excluded=s[a:b];segments=[s[:a],s[b:]];count=0
for i,segment in enumerate(segments):
 def repl(m):
  global count
  if 'revisionId:' in m[0]:return m[0]
  count+=1;return m[0][:-1]+', revisionId: null }'
 segment=re.sub(r'(?:target:|const target =)\s*\{\s*kind: "recording"(?: as const)?,\s*recordingId(?:[^{}]*?)\}',repl,segment);segments[i]=segment
p.write_text(segments[0]+excluded+segments[1]);print(json.dumps({'insertedSourceSelectors':count}))
