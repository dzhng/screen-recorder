const fs=require('node:fs');const ts=require('/Users/david/dev/screen-recorder/node_modules/typescript');
const file='/Users/david/dev/screen-recorder/packages/core/src/jobs.test.ts';let text=fs.readFileSync(file,'utf8');const ast=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);const edits=[];const excludedStart=text.indexOf('test("source targets stay distinct from explicit project revisions');const excludedEnd=text.indexOf('\ntest(',excludedStart+1);
function visit(node){if(ts.isObjectLiteralExpression(node)&&!(node.pos>=excludedStart&&node.end<=excludedEnd)){
const props=new Map(node.properties.filter(ts.isPropertyAssignment).map(p=>[p.name.getText(ast),p]));const kind=props.get('kind');
const target=(ts.isPropertyAssignment(node.parent)&&node.parent.name.getText(ast)==='target')||(ts.isVariableDeclaration(node.parent)&&node.parent.name.getText(ast)==='target');
if(target&&kind&&kind.initializer.getText(ast).replace(/ as const$/,'')==='"recording"'&&!props.has('revisionId')){const close=node.end-1;edits.push({at:close,insert:node.properties.hasTrailingComma?' revisionId: null,':' , revisionId: null '});}}
ts.forEachChild(node,visit)}visit(ast);for(const e of edits.sort((a,b)=>b.at-a.at))text=text.slice(0,e.at)+e.insert+text.slice(e.at);fs.writeFileSync(file,text);process.stdout.write(JSON.stringify({insertedSourceSelectors:edits.length})+'\n');
