from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np, json, hashlib
b=Path(__file__).parent
sides=[b/'final-baseline/outputs/images/pointer-readability',b/'coverage-green/outputs/images/pointer-readability']
out=b/'visual';out.mkdir(exist_ok=True)
metrics=[]
for mode in ['delivery','authored','ancestor','full','crop','coverage']:
    images=[[Image.open(side/f'{kind}-{mode}.png').convert('RGB') for side in sides] for kind in ['clean','pointer','trail']]
    w,h=images[0][0].size
    board=Image.new('RGB',(max(220,w)*2,3*(h+30)), '#ddd');d=ImageDraw.Draw(board)
    if mode in ['delivery','authored']: bounds=(24,91,150,120)
    elif mode=='ancestor': bounds=(24,211,150,240)
    elif mode=='full': bounds=(48,182,300,240)
    elif mode=='crop': bounds=(0,0,32,32)
    else: bounds=(0,128,40,160)
    cw,ch=(bounds[2]-bounds[0])*3,(bounds[3]-bounds[1])*3
    crop=Image.new('RGB',(max(220,cw)*2,3*(ch+30)),'#ddd');cd=ImageDraw.Draw(crop)
    for row,kind in enumerate(['clean','pointer','trail']):
        a,z=[np.asarray(im).astype(float) for im in images[row]]
        delta=np.abs(a-z);mask=np.max(delta,axis=2)>0
        metrics.append(dict(name=f'{kind}-{mode}',size=[w,h],changedPixels=int(mask.sum()),mae=float(delta.mean()),before=hashlib.sha256((sides[0]/f'{kind}-{mode}.png').read_bytes()).hexdigest(),after=hashlib.sha256((sides[1]/f'{kind}-{mode}.png').read_bytes()).hexdigest()))
        for col,im in enumerate(images[row]):
            label=f'{mode} / {kind} / {"A" if col==0 else "B"}'
            d.text((col*max(220,w)+4,row*(h+30)+4),label,fill='black');board.paste(im,(col*max(220,w),row*(h+30)+25))
            cd.text((col*max(220,cw)+4,row*(ch+30)+4),label+' / 3x detail',fill='black');crop.paste(im.crop(bounds).resize((cw,ch),Image.Resampling.NEAREST),(col*max(220,cw),row*(ch+30)+25))
    board.save(out/f'{mode}-full.png');crop.save(out/f'{mode}-detail.png')
(out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
(out/'criteria.txt').write_text('Inspect all six modes at native size and in the supplemental 3x details. The surface is a recorded frame with explicit cursor or trail annotations. A pointer should retain a recognizable asymmetric arrow silhouette and anchored tip; trails should have a distinct colored core and dark support, continuous strokes and visible age fade. Annotations should remain proportionate to visible content in a thumbnail. Check contrast, blur, clipping, unexpected shifts, and whether content changes when annotations are absent. Full-size source annotations provide the established visual style. No approved redesign image is supplied. Each full board shows original pixel dimensions, with A at left and B at right; details are nearest-neighbor enlargements only.\n')
print(json.dumps(metrics,indent=2))
