# Pointer delivery comparison

Target: preserve the established CursorOverlay shape, source hotspot, explicit trail history/fade, delivered-pixel readability floors, and cap against visible source content. The historical half-size baseline is a failing implementation, not a redesign reference. Full-size source output and the direct FrameImage crop establish the existing visual policy.

Comparability: every scene uses the same deterministic 320×240 source picture at exact physical sample 25/10 seconds, same pointer coordinates and supplied trail. Each A/B pair has equal output dimensions and compiled geometry. A is unchanged production at 7cd42c3c; B is the candidate. All 18 final candidate PNGs match the reviewed coverage-green PNGs byte for byte (final/visual-identity.json).

| Landmark | Established requirement/reference | Candidate | Result |
| --- | --- | --- | --- |
| Half-size pointer | Existing changed-pixel oracle at least 12 rows / 8 columns, asymmetric anchored tip | 15 / 11 across delivery, authored and ancestor reductions | Numerical gate passes; fresh reviewer finds recognizable arrow, no displaced tip, clipping or text obstruction |
| Half-size trail | At least 2 high-contrast colored core rows and 2 dark halo rows at the established cross-section | 2 / 2 in all three reductions | Numerical gate passes; fresh reviewer finds clearer continuous core/support, existing age bands retained |
| Full-size output | Historical established source-scale picture | Clean, pointer and trail PNGs byte-identical | No visual change |
| Unannotated content | Corresponding clean picture | All six PNG pairs byte-identical | No visual change |
| Thumbnail cap | Existing 16 delivered-pixel floor capped by 20% of visible source long edge; 64 source pixels × 20% = 12.8 source pixels, delivered at half scale | 6 rows / 5 columns; arrow remains present | Existing policy preserved; no constants changed |
| Tiny crop softness | Fresh reviewer medium-confidence concern: softer/muddier native-size silhouette | Direct old FrameSource→FrameImage reference at SAME saved source/sample/pointer/crop and 32×32 output | All three 17-pixel annotation masks identical, bbox x6..10/y21..26; annotation deltas ≤1/255 after subtracting each clean image. Fresh reference follow-up pending root |

The pointer takes a larger share of a thumbnail than of the full source because the existing policy gives readability a floor, then caps that floor against visible content. This is preserved default behavior, not an approved redesign or a new aesthetic choice.

All full images and complete endpoint/fade detail crops are supplied, including clean controls and the intentionally empty cropped-out trail. Crop/coverage source domains exclude the trail coordinates; missing trail there is the explicit geometry, not dropped history. Native captures remain unscaled; supplementary details are labeled 3× nearest-neighbor enlargements.

Direct-reference image differences outside the pointer are reported in crop-reference-metrics.json rather than hidden. Different established source color/crop pipelines produce those clean-image differences. Subtracting each path's clean image isolates annotation shape: zero >0.1 ink-mask disagreements, maximum annotation delta 1/255 (crop-reference-ink-metrics.json). The reference uses top-left crop (80,166,64,64); rotated coverage aligns the same domain at output (0,128,32,32).

Root independently checked all 18 before/after hashes, dimensions and changed-pixel counts (10 unchanged, 8 changed), inspected all 12 full/detail boards, and found the production shape/code review clean. Fresh reviewer accepted reduced/full/clean behavior; qualitative acceptance of the tiny crop awaits root's follow-up with the direct-reference board.
