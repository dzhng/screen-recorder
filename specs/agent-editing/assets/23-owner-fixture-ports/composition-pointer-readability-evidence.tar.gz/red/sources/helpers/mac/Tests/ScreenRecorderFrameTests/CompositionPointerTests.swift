@preconcurrency import AVFoundation
import CryptoKit
import Foundation
@testable import ScreenRecorderFrames
import ScreenRecorderMedia

func verifyCompositionPointerReadability(in parent: URL) async throws {
    let directory = parent.appendingPathComponent("pointer-readability")
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
    let source = directory.appendingPathComponent("source.mp4")
    try await FixtureWriter.write(to: source,
        times: (0..<26).map { CMTime(value: Int64($0), timescale: 10) })
    let track = try await AVURLAsset(url: source).loadTracks(withMediaType: .video)[0]
    let streamId = "track:\(track.trackID)"
    let atUs: Int64 = 2_500_000
    func render(_ name: String, overlay: FrameOverlay?, edge: Int = 160) async throws -> FixtureImage {
        let clip: [String: Any] = ["kind": "clip", "id": "c"]
        let operations: [[String: Any]] = overlay.map {
            [["kind": "pointer", "stepId": "pointer", "trailUs": $0.trailUs, "geometryPrefix": []]]
        } ?? []
        let output = directory.appendingPathComponent(name + ".png")
        var body: [String: Any] = [
            "output": output.path, "profile": "h264-rec709", "processing": [], "maxLongEdge": edge,
            "canvas": ["width": 320, "height": 240, "fps": ["numerator": 10, "denominator": 1],
                       "background": "#000000ff"],
            "frame": ["index": 25, "sampleAtUs": atUs,
                      "visibleRange": ["startUs": atUs, "endUs": 2_600_000],
                      "layers": [["kind": "video", "clipId": "c", "trackId": "t", "assetId": "a",
                                  "streamId": streamId, "sourceUs": atUs, "availability": "available",
                                  "width": 320, "height": 240]],
                      "visual": [["target": clip, "inputs": [], "operations": operations],
                                 ["target": ["kind": "output"], "inputs": [clip], "operations": []]]],
            "assets": [["assetId": "a", "streamId": streamId, "path": source.path, "originUs": 0]],
        ]
        if let overlay {
            let row: [String: Any] = [
                "frameIndex": 25, "sampleAtUs": atUs, "clipId": "c", "stepId": "pointer",
                "trailUs": overlay.trailUs, "status": "picture", "assetId": "a", "streamId": streamId,
                "requestedSourceUs": atUs, "captureUs": atUs, "clockOffsetUs": 0,
                "sourceToAssetOffsetUs": 0, "width": 320, "height": 240,
                "start": ["value": "25", "timescale": 10], "end": ["value": "26", "timescale": 10],
                "sampleTime": ["value": "25", "timescale": 10],
                "overlay": try JSONSerialization.jsonObject(with: JSONEncoder().encode(overlay)),
            ]
            var data = try JSONSerialization.data(withJSONObject: row, options: .sortedKeys)
            data.append(10)
            let file = directory.appendingPathComponent(name + ".pointers.jsonl")
            try data.write(to: file)
            body["pointers"] = ["file": file.path, "bytes": data.count, "records": 1,
                "sha256": SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()]
        }
        let data = try JSONSerialization.data(withJSONObject: body, options: .sortedKeys)
        try data.write(to: directory.appendingPathComponent(name + ".request.json"))
        let request = try JSONDecoder().decode(CompositionFrameRenderer.Request.self, from: data)
        let result = try await CompositionFrameRenderer.write(request)
        try JSONEncoder().encode(result).write(to: directory.appendingPathComponent(name + ".result.json"))
        return try FixtureImage(contentsOf: output)
    }
    let angle = Double(47) / 48 * 2 * Double.pi
    let pointer = CursorPoint(atSourceUs: atUs, x: 70 + 24 * cos(angle), y: 212 + 24 * sin(angle))
    let trail: [CursorPoint] = (0..<13).map { index in
        let timestamp = atUs - Int64(12 - index) * 100_000
        let x = Double(150 + index * 10)
        return CursorPoint(atSourceUs: timestamp, x: x, y: 210)
    }
    let clean = try await render("clean-half", overlay: nil)
    let pointed = try await render("pointer-half", overlay: FrameOverlay(pointer: pointer))
    let trailed = try await render("trail-half", overlay: FrameOverlay(trail: [trail], trailUs: 2_000_000))
    func changed(_ x: Int, _ y: Int) -> Bool {
        let drawn = pointed.color(x: x, y: y, width: 1, height: 1)
        let original = clean.color(x: x, y: y, width: 1, height: 1)
        return max(abs(drawn.red - original.red), abs(drawn.green - original.green),
                   abs(drawn.blue - original.blue)) > 0.1
    }
    let x = Int(pointer.x / 2), y = Int(pointer.y / 2)
    let columns = x..<min(x + 24, pointed.width)
    let rows = y..<min(y + 24, pointed.height)
    let pointerRows = rows.filter { row in columns.contains { changed($0, row) } }.count
    let pointerColumns = columns.filter { column in rows.contains { changed(column, $0) } }.count
    var core = 0, halo = 0
    for row in 96..<116 {
        let sample = trailed.color(x: 120, y: row, width: 1, height: 1)
        if sample.red - sample.green > 0.5 { core += 1 }
        let luma = (sample.red + sample.green + sample.blue) / 3.0
        if luma < 0.12 { halo += 1 }
    }
    let metrics = ["pointerRows": pointerRows, "pointerColumns": pointerColumns,
                   "trailCoreRows": core, "trailHaloRows": halo]
    try JSONSerialization.data(withJSONObject: metrics, options: [.prettyPrinted, .sortedKeys])
        .write(to: directory.appendingPathComponent("metrics.json"))
    precondition(pointerRows >= 12 && pointerColumns >= 8 && core >= 2 && halo >= 2,
        "Halved compiled pictures must retain readable pointer/core/halo delivered-pixel floors: \(metrics)")
    print("PASS compiled pointer delivery floors: \(metrics)")
}
