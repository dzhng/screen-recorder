# Source scene fixture ownership review

Clean shape/code/docs review. Recording scene acceptance reads only captured state, source identity and source duration. CaptureStore owns those facts; the five existing scene-evidence cases do not edit or interpret a recording revision. All fixtures, reopened stores and type annotations use it directly. No wrapper, new helper, policy branch, table or response change.

All test bodies and assertions are exact except store names/imports/type annotations. The wrong-source control fails when its actual acceptance equality is removed; exact restored production returns green. Full five-case file, core build/typecheck and tools pass. Runtime JS is exact except deletion of the obsolete empty library import. Mixed scene-processing/transcript tests still genuinely interpret revisions; they remain for a separate mapped port. Existing owner docs need no behavior-contract rewrite; root owns shared handoff/spec accounting.
