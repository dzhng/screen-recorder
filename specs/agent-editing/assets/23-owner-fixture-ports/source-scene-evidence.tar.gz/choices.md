# Decisions

Sound, high confidence: keep this pass to scene evidence storage and captured-source acceptance. A recorded source has one stored duration/identity, and the fixture needs those facts rather than a recording edit. The existing CaptureStore supplies them directly; source analysis still receives the same controlled samples and all assertions remain.

Sound, high confidence: use explicit type import, deleting only the old emitted empty library import. Retaining the old runtime dependency solely for byte-equality would defeat ownership removal; report this exact module difference and preserve all other emitted bytes.

Sound, high confidence: leave mixed SceneProcessing/transcript and JobQueue revision branches for mapped ports. Those tests genuinely edit and pin revisions; blindly replacing their store would silently remove meaningful contracts. This bounded pass does not claim those dependencies gone. No low-confidence architecture, cache, endpoint, limit or schema choice introduced.
