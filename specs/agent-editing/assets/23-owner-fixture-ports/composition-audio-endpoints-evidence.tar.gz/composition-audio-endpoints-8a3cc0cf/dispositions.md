# Current resampling endpoint controls

## Unique transfer and clock derivation

The original movie-render.test.mjs two-cuts endpoint test holds a useful independent control: excluded nearest-start and ceil-end native neighbors must not change PCM, while each admitted boundary impulse must survive. Current audio-mix cases already cover excluded-start, acquisition-gap and anchor-gap poison, but not both admitted endpoint controls together. This pass transfers only that unmatched boundary group to CompositionAudio.

The original third recording span is [2500000,5999983) microseconds. Its narration sourceOffsetUs is +125000, so the zero-origin physical source interval is exactly [2375000,5874983), duration3499983us. Its enclosing acquired run is [1800000,6000000) recording microseconds, so this selected span has no acquisition hole. At44100Hz, the raw start is104737.5 native frames: nearest ties-away admits104738. The end is259086.7503: ceil gives exclusive259087. Thus original excluded markers104737/259087 and included markers104738/259086 are preserved verbatim.

The old cumulative playback before this span is1558583us, rounded nearest to74812 output frames; its total5058566us rounds to242811, leaving167999 owed frames. The current capsule explicitly places the same unit-rate source interval at project[0,3499983)us. The current absolute floor clock also owes167999 frames. The test checks these exact native/output values through the current ExactTime owner and independently verifies each actual source has zero PTS, six seconds of44100Hz mono PCM and precisely the authored impulse frames.

The earlier proposed shorthand2375013..5875007 was corrected by reading the original recording span and offset BEFORE writing fixtures or running native code. No reference was recalibrated from output. The capsule does not reproduce the preceding two cuts, the unrelated system track, fixed-role half gain or automatic join ramps; none is secretly inserted into a current plan. Whole concatenation/clock and explicit-cut behavior retain their separate current owners. This narrow transfer does not itself authorize whole old movie/audio engine deletion.

## Actual numerical proof

Four six-second mono PCM sources contain zero, both excluded impulses, admitted first impulse, or admitted last impulse. Current CompositionAudio executes an explicit one-clip child-before-parent processing graph, no processors, zero asset origin and the exact selected context. Actual completed WAVEs, plans, receipts, independently decoded complete Float32 PCM, source markers/container clocks and measurements are retained before boundary assertions.

All outputs have exactly167999 frames of finite48000Hz stereo PCM. The outside PCM bytes equal the all-zero PCM bytes exactly. Each admitted impulse gives nonzero PCM independently. Recorded peaks are measurements, never acceptance thresholds; gates remain exact equality versus zero and strict nonzero survival.

Three precise native defects falsify the new oracle: increasing sourceStart by one removes the admitted-start marker; decreasing sourceEnd by one removes the admitted-end marker; increasing sourceEnd by one leaks the excluded-end marker. All three actual runs fail at the intended boundary assertion. Their exact production source overlays, distinct executables and complete outputs are retained. Restoring original production and rebuilding passes the small current CompositionAudio target's default runner, including its prior exact-time/basic stream/error/negative-zero checks. All four final PCM files equal initial unchanged-production green byte for byte.

Adding a second Swift source exposed the single-file @main/main.swift build heuristic. The test entry now explicitly awaits the same static main from main.swift; dispatch behavior stays the same. The initial compile failure is setup evidence, not a behavioral red. No product source changes remain.

## Reuse and limits

Current source extraction and mixed-codec cases already own AAC maximum AND RMS below1/32768, exact MP3/frozen-decoder arithmetic, channel/rate/format/tail/split and phase controls. The current8a matched AAC full/range bank retains its exact named inputs and zero-difference result; all32 current audio/media/manifest paths still match the referenced124-source8a bank. Historical AAC reproducibility failures are preserved and no general bitwise decoder claim is added.

The09c public/native FILE banks retain their source-pinned output/container/priming/rendition results. Independent source comparison finds29/31 old audio/media paths unchanged, with MediaProbe.swift and SampleTiming.swift changed. Therefore the whole current clock/probe stack is not claimed identical to that historical FILE run. Those codec results are reused only within their documented historical scope; this pass runs no AAC encoder or movie mux and supplies no new codec-wide verdict.

The current source-audio actual truncation/no-output/no-staging/source-immutability test already owns the old endpoint test's decoder-refusal adjunct; it is not duplicated or claimed rerun. Public descriptor transport, generic descriptor lifetimes, long audio and combined movie/RSS gates remain separate. No5m/30m fixture, old full body, native worker, model, capture, user library, primary index/spec or shared JavaScript build output was touched.
