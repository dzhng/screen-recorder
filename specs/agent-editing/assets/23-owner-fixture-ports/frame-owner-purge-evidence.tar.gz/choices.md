# Frame owner decisions

- Use the existing canonical projectServiceFixture and actual socket/cache/delivery owners, controlling only the native edge. The valid 1x1 PNG makes full byte/lifetime assertions meaningful; it supplies no decoder/color/quality evidence. High confidence.
- Keep source samples as containing-picture evidence. Retire old nearest kept-span/r0/automatic annotation policy instead of translating it into a project adapter. Existing explicit-project pin/head/regeneration and physical membership tests retain current contracts. High confidence.
- Keep native sparse/index recipes and valuable pixel/resolution/CLI/MCP/LRU/restart gates in current-source caller ports. Execution stays pending rather than replacing those floors with the controlled service test. Medium confidence until the actual native callers execute; generated fixture probe facts are deliberately supplied through AssetStore, as other existing authored fixtures do.
- Remove frame/materialization/recording-selector modules after the actual imports are only their own mapped tests; keep shared pointer/raster/time/source/project owners and separate obsolete media/audio/preview consumers. High confidence.
- Assert native-edge attempt multisets, not scheduling order. Public batch item/order and duplicate job/bytes remain exact; execution is concurrent. High confidence.

No new production mechanism/API/compatibility owner/cache/threshold. No user editorial decision. Corpus/media bytes and frozen workers untouched.
