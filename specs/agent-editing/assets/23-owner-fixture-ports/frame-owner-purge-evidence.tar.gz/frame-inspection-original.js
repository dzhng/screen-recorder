import { sceneSampleSourceTime } from "./source-scenes.js";
import { isDeepStrictEqual } from "node:util";
import { z } from "zod";
import { compiledFrameSchema, timeValueSchema, signedTimeValueSchema, add, subtract, toSignedTime, rational, round, compare, fromTime, fontReferenceSchema, processingTapSchema, } from "@screenrec/composition";
import { selectSource, sourceSelectionSchema } from "./source-selection.js";
import { compositionAsset } from "./assets.js";
import { CatalogError } from "./catalog.js";
import { submitCachedDerivative } from "./cached-derivative.js";
import { projectWindow, } from "./project-window.js";
const time = z.int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const selectedPicture = {
    clipId: z.string().min(1),
    assetId: z.string().min(1),
    streamId: z.string().min(1),
};
const pictureDeliverySchema = z.object({
    file: z.string(),
    mediaType: z.literal("image/png"),
    width: z.int().positive(),
    height: z.int().positive(),
    sourceWidth: z.int().positive(),
    sourceHeight: z.int().positive(),
    bytes: z
        .int()
        .positive()
        .max(32 * 1024 * 1024),
});
const textLayoutSchema = z
    .object({
    font: fontReferenceSchema,
    text: z.string().max(8192),
    visibleRange: z.tuple([time, time]),
    lines: z
        .array(z
        .object({
        range: z.tuple([time, time]),
        text: z.string().max(8192),
        origin: z.tuple([z.number().finite(), z.number().finite()]),
        width: z.number().finite().nonnegative(),
        fonts: z.array(z.string().min(1)).max(8192),
    })
        .strict())
        .max(8192),
})
    .strict();
const nativeProjectReceiptSchema = pictureDeliverySchema.extend({
    profile: z.literal("h264-rec709"),
    frame: compiledFrameSchema,
    decodedSamples: time,
    readerOpens: time,
    decodedImages: time,
    pictures: z.array(z.discriminatedUnion("kind", [
        z.discriminatedUnion("status", [
            z.strictObject({
                kind: z.literal("text"),
                clipId: z.string().min(1),
                status: z.literal("available"),
                layout: textLayoutSchema,
            }),
            z.strictObject({
                kind: z.literal("text"),
                clipId: z.string().min(1),
                status: z.literal("unavailable"),
                reason: z.string().min(1),
            }),
        ]),
        z
            .strictObject({
            kind: z.literal("image"),
            ...selectedPicture,
            status: z.enum(["available", "unavailable"]),
            reason: z.string().min(1).optional(),
        })
            .refine((value) => value.status === "available" ? value.reason === undefined : value.reason !== undefined),
        z.discriminatedUnion("status", [
            z.strictObject({
                kind: z.literal("video"),
                status: z.literal("unavailable"),
                ...selectedPicture,
                requestedSourceUs: timeValueSchema,
                reason: z.string().min(1),
            }),
            z.strictObject({
                kind: z.literal("video"),
                status: z.literal("available"),
                ...selectedPicture,
                requestedSourceUs: timeValueSchema,
                actualSourceUs: z.int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
                sample: z.object({
                    value: z.string().regex(/^-?\d+$/),
                    timescale: z.int().positive(),
                    originUs: signedTimeValueSchema,
                }),
            }),
        ]),
    ])),
});
const projectReceiptSchema = nativeProjectReceiptSchema.extend({
    frame: z.strictObject(compiledFrameSchema.shape).omit({ visual: true }),
});
export const projectPictureOptionsSchema = z.strictObject({
    maxLongEdge: z.int().min(1).max(8192),
    tap: processingTapSchema,
    implementationId: z.string().min(1),
});
const optionsSchema = z.strictObject({ atUs: time, ...projectPictureOptionsSchema.shape });
export const retainedProjectFrameSchema = projectReceiptSchema
    .extend({
    ...optionsSchema.shape,
    projectId: z.string().min(1),
    revisionId: z.string().min(1),
})
    .strict();
const sourceOptionsSchema = z.strictObject({
    selection: sourceSelectionSchema,
    atUs: time,
    maxLongEdge: z.int().min(1).max(8192),
    supportDigest: z.string().regex(/^[a-f0-9]{64}$/),
    implementationId: z.string().min(1),
});
const sourceReceiptSchema = pictureDeliverySchema.extend({
    decodedSamples: time,
    readerOpens: time,
    assetId: z.string().min(1),
    streamId: z.string().min(1),
    requestedSourceUs: time,
    actualSourceUs: z.int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
    sample: z.object({
        value: z
            .string()
            .max(21)
            .regex(/^-?\d+$/),
        timescale: z.int().positive(),
        endValue: z
            .string()
            .max(21)
            .regex(/^-?\d+$/),
        endTimescale: z.int().positive(),
        originUs: signedTimeValueSchema,
    }),
});
const sourceImageSelectionSchema = sourceSelectionSchema.omit({ acquisitionId: true });
const imageOptionsSchema = z.strictObject({
    kind: z.literal("image"),
    selection: sourceImageSelectionSchema,
    maxLongEdge: z.int().min(1).max(8192),
    implementationId: z.string().min(1),
});
const imageReceiptSchema = pictureDeliverySchema.extend({
    kind: z.literal("image"),
    ...sourceImageSelectionSchema.shape,
    orientation: z.int().min(1).max(8),
    hasAlpha: z.boolean(),
    decodedImages: z.literal(1),
    readerOpens: z.literal(1),
});
const imageInputSchema = sourceImageSelectionSchema
    .extend({
    maxLongEdge: imageOptionsSchema.shape.maxLongEdge.optional(),
})
    .strict();
/** Retained no-picture evidence keeps donor attempt identity without requiring a local execution. */
export const sourceFrameUnavailableSchema = sourceOptionsSchema
    .extend({
    jobId: z.uuid(),
    attemptId: z.uuid(),
    reason: z.string().max(4096).nullable(),
    observation: z.strictObject({
        requestedSourceUs: time,
        status: z.literal("unavailable"),
        reason: z.literal("empty_edit"),
    }),
})
    .refine((value) => value.observation.requestedSourceUs === value.atUs);
export function validateSourceFrameGeometry(value, source, maxLongEdge) {
    if (value.sourceWidth !== Math.round(source.width) ||
        value.sourceHeight !== Math.round(source.height) ||
        value.width > value.sourceWidth ||
        value.height > value.sourceHeight ||
        Math.max(value.width, value.height) > maxLongEdge)
        throw new CatalogError("INVALID_RESPONSE", "Source picture receipt changed its geometry");
}
export const retainedSourceFrameSchema = sourceReceiptSchema
    .extend({
    ...sourceSelectionSchema.shape,
    atUs: time,
    maxLongEdge: sourceOptionsSchema.shape.maxLongEdge,
    supportDigest: sourceOptionsSchema.shape.supportDigest,
    implementationId: z.string().min(1).max(256),
})
    .strict();
/** A demanded picture uses the movie's global schedule and shared derivative lifetime. */
export class MediaFrameInspection {
    owners;
    constructor(owners) {
        this.owners = owners;
        if (!owners.sourceRenderer.implementationId ||
            (owners.imageRenderer && !owners.imageRenderer.implementationId) ||
            (owners.project && !owners.project.renderer.implementationId))
            throw new Error("Picture renderer needs an implementation identity");
    }
    get project() {
        if (!this.owners.project)
            throw new CatalogError("UNSUPPORTED_JOB", "Project pictures are unavailable");
        return this.owners.project;
    }
    imagePlan(input) {
        // Input keys are checked separately so an image cannot acquire a timed selection by accident.
        const parsedInput = imageInputSchema.safeParse(input);
        if (!parsedInput.success)
            throw new CatalogError("INVALID_PARAMS", "Still images accept assetId, streamId and maxLongEdge only");
        const asset = this.owners.assets.get(input.assetId);
        const stream = compositionAsset(asset).streams.find((value) => value.id === input.streamId);
        if (!stream || stream.kind !== "image")
            throw new CatalogError("INVALID_PARAMS", "A timeless picture requires an image stream; video requires atUs");
        const renderer = this.owners.imageRenderer;
        if (!renderer)
            throw new CatalogError("UNSUPPORTED_JOB", "Still-image pictures are unavailable");
        const metadata = asset.streams.find((value) => value.id === stream.id);
        const options = imageOptionsSchema.parse({
            kind: "image",
            selection: { assetId: asset.id, streamId: stream.id },
            maxLongEdge: input.maxLongEdge ?? 1600,
            implementationId: renderer.implementationId,
        });
        return {
            options,
            metadata,
            stream,
            renderer,
            asset: { assetId: asset.id, streamId: stream.id, path: this.owners.assets.path(asset.id) },
        };
    }
    sourceDerivative(options) {
        const { assets, acquisitions, jobs, cache } = this.owners;
        return submitCachedDerivative(jobs, cache, {
            target: { kind: "asset", assetId: options.selection.assetId },
            artifact: "frame",
            input: JSON.stringify(options),
        }, "frame", {
            admitted: (job) => {
                const owner = { kind: "job", id: job.jobId };
                assets.retain(owner, [options.selection.assetId]);
                if ("acquisitionId" in options.selection && options.selection.acquisitionId)
                    acquisitions.retain(owner, [options.selection.acquisitionId]);
            },
        });
    }
    requestImage(input) {
        const { options } = this.imagePlan(input);
        const status = this.sourceDerivative(options);
        return {
            ...options.selection,
            kind: options.kind,
            maxLongEdge: options.maxLongEdge,
            implementationId: options.implementationId,
            state: status.state,
            reason: status.reason,
            retryable: status.retryable,
            jobId: status.jobId,
            published: status.published
                ? { generation: status.published.generation, frame: status.published.value }
                : null,
        };
    }
    sourcePlan(input) {
        const source = selectSource(this.owners.assets, this.owners.acquisitions, {
            assetId: input.assetId,
            streamId: input.streamId,
            ...(input.acquisitionId === undefined ? {} : { acquisitionId: input.acquisitionId }),
        });
        if (source.stream.kind !== "video")
            throw new CatalogError("UNSUPPORTED_MEDIA", "Source pictures require timed video");
        const parsed = sourceOptionsSchema.safeParse({
            selection: source.selection,
            atUs: input.atUs,
            maxLongEdge: input.maxLongEdge ?? 1600,
            supportDigest: source.supportDigest,
            implementationId: this.owners.sourceRenderer.implementationId,
        });
        if (!parsed.success || compare(fromTime(input.atUs), fromTime(source.durationUs)) >= 0)
            throw new CatalogError("INVALID_RANGE", "Picture time must lie within the source duration");
        const contains = (range) => compare(fromTime(range.startUs), fromTime(input.atUs)) <= 0 &&
            compare(fromTime(input.atUs), fromTime(range.endUs)) < 0;
        const available = source.track.available.filter(contains);
        const reason = !source.stream.available.some(contains)
            ? "physical_gap"
            : !available.length
                ? "acquisition_excluded"
                : null;
        const asset = {
            assetId: source.selection.assetId,
            streamId: source.selection.streamId,
            path: source.track.source,
            originUs: toSignedTime(subtract(fromTime(0), fromTime(source.track.sourceOffsetUs))),
        };
        return { source, options: parsed.data, asset, reason, available };
    }
    requestSource(input) {
        const { options, reason } = this.sourcePlan(input);
        const status = reason
            ? {
                state: "unavailable",
                reason,
                retryable: false,
                jobId: null,
                published: null,
            }
            : this.sourceDerivative(options);
        return {
            ...options.selection,
            atUs: options.atUs,
            maxLongEdge: options.maxLongEdge,
            supportDigest: options.supportDigest,
            implementationId: options.implementationId,
            state: status.state,
            reason: status.reason,
            retryable: status.retryable,
            jobId: status.jobId,
            published: status.published
                ? { generation: status.published.generation, frame: status.published.value }
                : null,
        };
    }
    /** Snapshots only a native no-picture observation; ordinary failures never become missing pixels. */
    sourceUnavailable(input) {
        const { options } = this.sourcePlan(input);
        const status = this.owners.jobs.status({
            target: { kind: "asset", assetId: options.selection.assetId },
            artifact: "frame",
            input: JSON.stringify(options),
        });
        const job = status.jobId ? this.owners.jobs.job(status.jobId) : null;
        if (!job ||
            job.state !== "unavailable" ||
            job.errorCode !== "UNAVAILABLE" ||
            job.errorDetails?.reason !== "empty_edit" ||
            job.errorDetails?.requestedSourceUs !== options.atUs)
            throw new CatalogError("NOT_READY", "No physical no-picture observation exists for this request");
        return {
            ...options,
            jobId: job.jobId,
            attemptId: job.attemptId,
            reason: job.reason,
            observation: { requestedSourceUs: options.atUs, status: "unavailable", reason: "empty_edit" },
        };
    }
    async publish(owner, signal, render) {
        signal.throwIfAborted();
        const output = this.owners.cache.reserve(owner);
        try {
            const value = await render(output.path);
            signal.throwIfAborted();
            if (value.file !== output.path)
                throw new CatalogError("INVALID_RESPONSE", "Picture receipt changed output path");
            const cached = await this.owners.cache.publish(output.id);
            signal.throwIfAborted();
            if (cached.bytes !== value.bytes)
                throw new CatalogError("INVALID_RESPONSE", "Published picture size differs from its receipt");
            return JSON.stringify({ ...value, cacheId: output.id });
        }
        catch (error) {
            this.owners.cache.remove(output.id);
            throw error;
        }
    }
    async executeImage({ job, signal }) {
        const parsed = imageOptionsSchema.safeParse(JSON.parse(job.input));
        if (job.target.kind !== "asset" ||
            job.artifact !== "frame" ||
            !parsed.success ||
            parsed.data.selection.assetId !== job.target.assetId)
            throw new CatalogError("UNSUPPORTED_JOB", "Picture job does not name a still image");
        const plan = this.imagePlan({ ...parsed.data.selection, maxLongEdge: parsed.data.maxLongEdge });
        if (plan.options.implementationId !== parsed.data.implementationId)
            throw new CatalogError("NOT_READY", "Pinned image renderer is unavailable", {}, true);
        return this.publish(job.target, signal, async (output) => {
            const receipt = imageReceiptSchema.safeParse(await plan.renderer.render({
                asset: plan.asset,
                output,
                maxLongEdge: plan.options.maxLongEdge,
            }, signal));
            if (!receipt.success)
                throw new CatalogError("INVALID_RESPONSE", "Malformed still-image receipt");
            const value = receipt.data;
            const scale = Math.min(1, plan.options.maxLongEdge / Math.max(plan.stream.width, plan.stream.height));
            if (value.assetId !== plan.asset.assetId ||
                value.streamId !== plan.asset.streamId ||
                value.sourceWidth !== plan.stream.width ||
                value.sourceHeight !== plan.stream.height ||
                value.width !== Math.max(1, Math.round(plan.stream.width * scale)) ||
                value.height !== Math.max(1, Math.round(plan.stream.height * scale)) ||
                value.orientation !== plan.metadata.orientation ||
                value.hasAlpha !== plan.metadata.hasAlpha)
                throw new CatalogError("INVALID_RESPONSE", "Still-image receipt changed its identity or dimensions");
            return {
                ...value,
                maxLongEdge: plan.options.maxLongEdge,
                implementationId: plan.options.implementationId,
            };
        });
    }
    async executeSource({ job, signal }) {
        const parsed = sourceOptionsSchema.safeParse(JSON.parse(job.input));
        if (job.target.kind !== "asset" ||
            job.artifact !== "frame" ||
            !parsed.success ||
            parsed.data.selection.assetId !== job.target.assetId)
            throw new CatalogError("UNSUPPORTED_JOB", "Picture job does not name a selected source");
        if (parsed.data.implementationId !== this.owners.sourceRenderer.implementationId)
            throw new CatalogError("NOT_READY", "Pinned picture renderer is unavailable", {}, true);
        const plan = this.sourcePlan({ ...parsed.data.selection, ...parsed.data });
        if (plan.options.supportDigest !== parsed.data.supportDigest)
            throw new CatalogError("ARTIFACT_CHANGED", "Selected source support changed");
        if (plan.reason)
            throw new CatalogError("UNAVAILABLE", plan.reason);
        return this.publish({ kind: "asset", assetId: job.target.assetId }, signal, async (output) => {
            const parsedReceipt = sourceReceiptSchema.safeParse(await this.owners.sourceRenderer
                .render({
                asset: plan.asset,
                // Native admission needs only the demanded interval; the job pins complete support.
                available: plan.available,
                atUs: plan.options.atUs,
                maxLongEdge: plan.options.maxLongEdge,
                output,
            }, signal)
                .catch((error) => {
                if (error instanceof CatalogError && error.code === "SOURCE_PICTURE_UNAVAILABLE")
                    throw new CatalogError("UNAVAILABLE", error.message, {
                        reason: "empty_edit",
                        requestedSourceUs: plan.options.atUs,
                    });
                throw error;
            }));
            if (!parsedReceipt.success)
                throw new CatalogError("INVALID_RESPONSE", "Malformed source picture receipt");
            const value = parsedReceipt.data, sample = value.sample;
            const start = BigInt(sample.value), end = BigInt(sample.endValue), scale = BigInt(sample.timescale), endScale = BigInt(sample.endTimescale);
            const at = add(fromTime(plan.options.atUs), fromTime(plan.asset.originUs));
            const metadata = this.owners.assets
                .get(plan.asset.assetId)
                .streams.find((stream) => stream.id === plan.asset.streamId);
            if (value.assetId !== plan.asset.assetId ||
                value.streamId !== plan.asset.streamId ||
                value.requestedSourceUs !== plan.options.atUs ||
                compare(fromTime(sample.originUs), fromTime(plan.asset.originUs)) !== 0 ||
                round(sceneSampleSourceTime(sample, sample.originUs)) !== value.actualSourceUs ||
                compare(rational(start * 1000000n, scale), at) > 0 ||
                compare(rational(end * 1000000n, endScale), at) <= 0)
                throw new CatalogError("INVALID_RESPONSE", "Source picture receipt changed its selection or physical clock");
            validateSourceFrameGeometry(value, {
                width: metadata.orientedWidth ?? metadata.width,
                height: metadata.orientedHeight ?? metadata.height,
            }, plan.options.maxLongEdge);
            return {
                ...value,
                ...plan.options.selection,
                atUs: plan.options.atUs,
                maxLongEdge: plan.options.maxLongEdge,
                supportDigest: plan.options.supportDigest,
                implementationId: plan.options.implementationId,
            };
        });
    }
    planProject(input) {
        const options = optionsSchema.safeParse({
            atUs: input.atUs,
            maxLongEdge: input.maxLongEdge ?? 1600,
            tap: input.tap ?? { target: { kind: "output" }, point: { kind: "processed" } },
            implementationId: this.project.renderer.implementationId,
        });
        if (!options.success || input.atUs === Number.MAX_SAFE_INTEGER)
            throw new CatalogError("INVALID_PARAMS", "Invalid demanded picture options");
        const plan = projectWindow(this.project.projects, this.owners.assets, {
            projectId: input.projectId,
            revisionId: input.revisionId,
            range: { startUs: input.atUs, endUs: input.atUs + 1 },
            tap: options.data.tap,
        }, this.project.renderer, "video");
        return { ...plan, options: options.data };
    }
    requestProject(input) {
        const { window, options, pointerSources } = this.planProject(input);
        const revisionId = window.manifest.revisionId;
        const status = submitCachedDerivative(this.owners.jobs, this.owners.cache, {
            target: { kind: "project", projectId: input.projectId, revisionId },
            artifact: "frame",
            input: JSON.stringify(options),
        }, "frame", { deferred: pointerSources.length > 0 });
        return {
            projectId: input.projectId,
            revisionId,
            ...options,
            state: status.state,
            reason: status.reason,
            retryable: status.retryable,
            jobId: status.jobId,
            published: status.published
                ? { generation: status.published.generation, frame: status.published.value }
                : null,
        };
    }
    request(input) {
        return "projectId" in input
            ? this.requestProject(input)
            : "atUs" in input
                ? this.requestSource(input)
                : this.requestImage(input);
    }
    retry(input) {
        const current = this.request(input);
        if ("projectId" in input && !current.published)
            for (const selection of this.planProject(input).pointerSources)
                this.project.renderer.pointers?.retry(selection);
        if (current.jobId)
            this.owners.jobs.retry(current.jobId);
        return this.request("projectId" in current
            ? { ...input, projectId: current.projectId, revisionId: current.revisionId }
            : input);
    }
    get projectSupport() {
        return this.project.renderer;
    }
    admit(job) {
        const options = optionsSchema.parse(JSON.parse(job.input));
        if (options.implementationId !== this.project.renderer.implementationId)
            throw new CatalogError("NOT_READY", "Pinned picture renderer is unavailable", { implementationId: options.implementationId }, true);
        if (job.target.kind !== "project" || job.artifact !== "frame")
            throw new CatalogError("UNSUPPORTED_JOB", "Picture admission requires a project job");
        const plan = this.planProject({
            projectId: job.target.projectId,
            revisionId: job.target.revisionId,
            ...options,
        });
        return this.project.renderer.pointers?.admit(plan.pointerSources) ?? { state: "ready" };
    }
    async execute(execution) {
        return execution.job.target.kind === "project"
            ? this.executeProject(execution)
            : JSON.parse(execution.job.input).kind === "image"
                ? this.executeImage(execution)
                : this.executeSource(execution);
    }
    async executeProject({ job, signal }) {
        const parsed = optionsSchema.safeParse(JSON.parse(job.input));
        if (job.target.kind !== "project" || job.artifact !== "frame" || !parsed.success)
            throw new CatalogError("UNSUPPORTED_JOB", "Picture job does not name a project frame");
        if (parsed.data.implementationId !== this.project.renderer.implementationId)
            throw new CatalogError("NOT_READY", "Pinned picture renderer is unavailable", {}, true);
        const plan = this.planProject({
            projectId: job.target.projectId,
            revisionId: job.target.revisionId,
            ...parsed.data,
        });
        const projectId = job.target.projectId;
        return this.publish({ kind: "project", projectId }, signal, async (output) => {
            const render = () => this.project.renderer.render({
                model: plan.model,
                window: plan.window,
                assets: plan.assets,
                fonts: plan.fonts,
                output,
                maxLongEdge: plan.options.maxLongEdge,
            }, signal);
            const receipt = this.project.renderer.pointers
                ? await this.project.renderer.pointers.withReady(plan.pointerSources, render)
                : await render();
            signal.throwIfAborted();
            const value = validateProjectFrameReceipt(receipt, plan, output, plan.options.maxLongEdge);
            return { ...value, ...plan.options, projectId, revisionId: plan.window.manifest.revisionId };
        });
    }
}
function inspectedFrame(frame, plan) {
    const { visual: _visual, ...evidence } = frame;
    return { ...evidence, visibleRange: plan.frameBoundary(frame.sampleAtUs).after.visibleRange };
}
/** Native instructions stay private, but must match before any public evidence is projected. */
export function validateProjectFrameReceipt(receipt, plan, output, maxLongEdge) {
    const parsed = nativeProjectReceiptSchema.safeParse(receipt);
    if (!parsed.success)
        throw new CatalogError("INVALID_RESPONSE", "Malformed picture receipt");
    checkPictureReceipt(parsed.data, plan.window.frames().next().value, plan, output, maxLongEdge);
    return { ...parsed.data, frame: inspectedFrame(parsed.data.frame, plan) };
}
/** Retained records contain the same public evidence; renderer-private instructions are never stored. */
export function validateRetainedProjectFrameReceipt(receipt, plan, output, maxLongEdge) {
    const parsed = projectReceiptSchema.safeParse(receipt);
    if (!parsed.success)
        throw new CatalogError("INVALID_RESPONSE", "Malformed picture receipt");
    checkPictureReceipt(parsed.data, inspectedFrame(plan.window.frames().next().value, plan), plan, output, maxLongEdge);
    return parsed.data;
}
function checkPictureReceipt(value, expected, plan, output, maxLongEdge) {
    const { pictures } = value;
    if (value.file !== output ||
        !isDeepStrictEqual(value.frame, expected) ||
        value.sourceWidth !== plan.window.manifest.canvas.width ||
        value.sourceHeight !== plan.window.manifest.canvas.height ||
        value.width > value.sourceWidth ||
        value.height > value.sourceHeight ||
        Math.max(value.width, value.height) > maxLongEdge ||
        pictures.length !== expected.layers.length ||
        pictures.some((picture, index) => {
            const layer = expected.layers[index];
            return (picture.clipId !== layer.clipId ||
                (picture.kind !== "text" &&
                    layer.kind !== "text" &&
                    (picture.assetId !== layer.assetId || picture.streamId !== layer.streamId)) ||
                (picture.kind === "text" &&
                    layer.kind === "text" &&
                    picture.status === "available" &&
                    (!isDeepStrictEqual(picture.layout.font, layer.text.font) ||
                        picture.layout.text !== layer.text.text ||
                        picture.layout.visibleRange[0] + picture.layout.visibleRange[1] >
                            layer.text.text.length ||
                        picture.layout.lines.some((line) => line.text !== layer.text.text.slice(line.range[0], line.range[0] + line.range[1]) ||
                            line.fonts.some((font) => font !== layer.text.font.postScriptName)))) ||
                picture.kind !== layer.kind ||
                (picture.kind === "video" &&
                    layer.kind === "video" &&
                    compare(fromTime(picture.requestedSourceUs), fromTime(layer.sourceUs)) !== 0) ||
                (layer.availability !== "available" &&
                    (picture.status !== "unavailable" || picture.reason !== layer.availability)) ||
                (layer.availability !== "available" && picture.status === "available"));
        }))
        throw new CatalogError("INVALID_RESPONSE", "Picture receipt differs from its pinned frame");
    if (pictures.some((picture) => picture.kind === "video" &&
        picture.status === "available" &&
        (round(sceneSampleSourceTime(picture.sample, picture.sample.originUs)) !==
            picture.actualSourceUs ||
            !isDeepStrictEqual(picture.sample.originUs, plan.assets.find((asset) => asset.assetId === picture.assetId && asset.streamId === picture.streamId)?.originUs))))
        throw new CatalogError("INVALID_RESPONSE", "Picture receipt changed its source clock");
}
