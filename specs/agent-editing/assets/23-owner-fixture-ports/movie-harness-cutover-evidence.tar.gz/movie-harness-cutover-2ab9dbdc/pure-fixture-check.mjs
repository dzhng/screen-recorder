import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createCompiler,validateComposition,resolveOutputSettings} from '/Users/david/.codex/worktrees/source-native-consumers/screen-recorder/packages/composition/dist/index.js';
const root='/Users/david/.codex/worktrees/source-native-consumers/screen-recorder';
const lifetime=await readFile(root+'/packages/test-harness/movie-lifetime.mjs','utf8');
const scale=await readFile(root+'/packages/test-harness/movie-scale.mjs','utf8');
const stream=(kind,endUs)=>({id:kind,kind,...(kind==='video'?{width:320,height:180}:{}),bounds:{startUs:0,endUs},available:[{startUs:0,endUs}]});
const output=[];
{
 const bindings=['video','audio'].map(kind=>({assetId:kind,streamId:kind,path:'/fixture/'+kind,originUs:0}));
 const assets=bindings.map(b=>({id:b.assetId,streams:[stream(b.assetId,60000000)]}));
 const fixture=new Function('assets','bindings',lifetime.slice(lifetime.indexOf('      const fixture ='),lifetime.indexOf('      const request = compile'))+'return fixture;')(assets,bindings);
 const compile=new Function('createCompiler','validateComposition','resolveOutputSettings',lifetime.slice(lifetime.indexOf('function compile('),lifetime.indexOf('async function command'))+'return compile;')(createCompiler,validateComposition,resolveOutputSettings);
 for (const endUs of [1000000,60000000]) {const request=compile(fixture,endUs,'/fixture/output.mp4'); assert.equal(request.window.manifest.sampleRange.end,endUs*48000/1e6);output.push({fixture:'lifetime',endUs,frames:[...request.window.frames()].length,audioClips:[...request.window.audio()].length});}
}
for (const seconds of [10,300]) {
 const bindings=['video','narration','system'].map(id=>({assetId:id,streamId:id==='video'?'video':'audio',path:'/fixture/'+id,originUs:0}));
 const assets=bindings.map(b=>({id:b.assetId,streams:[stream(b.streamId,300000000)]}));
 const spans=[{startUs:0,endUs:1728333},{startUs:2005000,endUs:seconds===10?10000000:153583337},...(seconds===300?[{startUs:154000000,endUs:300000000}]:[])];
 let durationUs=0;const placements=spans.map(s=>({startUs:durationUs,endUs:durationUs+=s.endUs-s.startUs}));
 const doc=new Function('bindings','spans','placements',scale.slice(scale.indexOf('  const document ='),scale.indexOf('  const model ='))+'return document;')(bindings,spans,placements);
 const window=createCompiler(validateComposition(doc,assets),'static-fixture-check').window({range:{startUs:0,endUs:durationUs},rendition:{sampleRate:48000,channels:2},tap:{target:{kind:'output'},point:{kind:'processed'}}});
 const audio=[...window.audio()];assert.equal(audio.length,spans.length*2);assert.equal(window.manifest.sampleRange.end,Math.floor(durationUs*48000/1e6));
 output.push({fixture:'scale',seconds,durationUs,frames:[...window.frames()].length,audioClips:audio.length,sampleRange:window.manifest.sampleRange});
}
console.log(JSON.stringify({scope:'Pure schema/compiler only, synthetic metadata; no native worker/media generation/encoding/decoding',fixtures:output},null,2));
