# Preserve contracts through owner removal

Removing an obsolete owner must preserve the guarantees it happened to exercise.
Current source/project owners carry those guarantees; an old wrapper stays only
while it has an identified consumer or unmatched contract. A wrapper calling
another wrapper is insufficient reason to retain either.

The [publication map](publication-contract-map.md) separates useful publication
and lifetime guarantees from retired recording-edit policies. Historical
[source/service](service-dependency-audit.json),
[native](native-consumer-audit.json), [matched native](native-guarantee-map.json)
and [caller](caller-cutover-audit.json) maps locate remaining dependencies. They
are source audits, not runtime results or deletion certificates.

## Evidence by contract

Each report identifies exact source operands, its adjacent evidence archive and
scope. Original failures remain distinct from repaired outcomes. Transcribed
observations are labelled separately from contemporaneous process journals;
controlled replies prove their contracts without becoming decode or quality proof.

| Contract | Canonical evidence |
| --- | --- |
| Archive admission, borrower drain and namespace ownership | [Registry](registry-verification.json), [package owner closure](package-owner-closure-verification.json) |
| Publication, acknowledgement loss and private retirement | [Publication](publication-verification.json), [lifetime](publication-lifetime-verification.json), [package publication](package-publication-verification.json), [abandonment](package-abandon-verification.json) |
| File containment, inherited writers and exact source authority | [Boundaries](package-boundaries-verification.json), [reader](project-archive-reader-verification.json), [extraction](project-archive-extraction-verification.json) |
| Pinned exports and retained portable generations | [Pinned retry](publication-pinned-verification.json), [generation retention](package-generations-verification.json) |
| Capture/source lifetime and recovery | [Capture lifetime](capture-lifetime-verification.json), [source facts](capture-source-verification.json), [deletion](captured-source-deletion-verification.json) |
| Public capture and default-service composition | [Capture service](capture-service-verification.json), [delivery/storage](capture-delivery-storage-verification.json), [project startup](project-startup-verification.json) |
| Shared source evidence, caches and jobs | [Cache](source-cache-verification.json), [scene facts](source-scene-verification.json), [evidence fixtures](source-evidence-fixtures-verification.json), [queue](source-project-jobs-verification.json) |
| Source normalization and common movie receipts | [Source export](source-export-verification.json), [movie validation](rendered-movie-verification.json) |
| Public project package ownership, media and discovery | [Package media](project-package-media-verification.json), [public detail](project-package-public-verification.json) |
| Canonical service framing, replay and source/job continuity | [Public service](public-service-contracts-verification.json) |
| Generic render cancellation, worker drain and consumption | [Render lifetime](generic-render-lifetime-verification.json) |
| Selected-source transcript processing and project projection | [Transcript owner removal](transcript-owner-purge-verification.json) |
| Source/project scene and index execution | [Producer removal](scene-index-owner-purge-verification.json), [index policy](index-policy-verification.json) |
| Retained PNG ownership, paging and managed portable adoption | [Generic index removal](generic-index-owner-purge-verification.json) |
| CLI/MCP media owner validation and complete selection delivery | [Batch delivery](batch-owner-contract-verification.json) |
| Current native frame/audio wire contracts and bounded grid | [Native source contracts](source-native-contracts-verification.json) |
| Owned imported media and cursor decode clock conversion | [Native consumers](source-native-consumers-verification.json) |
| Descriptor release and observed unfinished work on parent death | [Native lifetime](source-native-lifetime-verification.json) |
| Source-picture orientation, fidelity, byte bounds and aliases | [Raw pictures](source-native-pictures-verification.json) |
| Portable scene semantics, orphan carrier closure and source-cache scale caller | [Current owners](source-cache-carrier-closure-verification.json) |
| Delivered cursor/trail readability and crop sizing | [Compiled pictures](composition-pointer-readability-verification.json) |
| Caller-selected cuts, source/project clocks and adopted inspection | [Explicit caller](personal-release-caller-verification.json) |
| Independent source-frame failures, retry and delivery ownership | [Frame owner removal](frame-owner-purge-verification.json) |
| Recorded silence, missing samples and late stream consumer failure | [Native audio](source-native-audio-contracts-verification.json) |
| Resampling exclusion and admitted source endpoints | [Audio endpoints](composition-audio-endpoints-verification.json) |

[Capture/source caller ports](capture-source-caller-verification.json) and their
[review corrections](capture-source-caller-followup-verification.json) bind the remaining
source, capture, recovery and pointer callers to current acquisition/project owners.
Only their syntax and the unchanged pure presentation algorithms ran in that pass;
actual native scene, scale, trail, orphan-worker and retained paused-movie gates
remain execution obligations. Historical lab commands in the recording spec are
retained evidence, not runnable current entry points.

## Ownership and proof limits

Capture creates source facts; projects own edits. Deleting a capture does not
retire an independently managed asset or project. Adoption creates a fresh
recipient whose owned bytes survive donor removal. Source data mentioning a
recording is not thereby an edit interpreter; trace its actual consumers.

Portable resources keep the current authority and validation owner. Retaining an
unconsumed page format solely for a test would create another representation to
maintain. Generic index and scene resources use managed portable source
generations. Their semantic and continuity oracles run at the current staged
store; standalone scene/event page formats and their orphan adapter are removed.
Shared raster and pointer algorithms keep their existing owners.

Controlled metadata and fixed valid PNGs establish ownership, paging and refusal.
Actual worker checks establish only their named decoder, pixel or lifetime scope.
A test executable is distinct from the production worker; a default-entry bundle
is compilation proof, not app launch. Native source hashes bind use of a preserved
worker. Changed native code requires corresponding new execution evidence.

Abrupt worker death can leave private staging for its caller to remove. The
parent-lifetime contract promises no final publication or reply; it does not
promise Swift defer execution after a hard exit. Generic descriptor lifetime
remains live even where the retired PNG input/output handle pair has no caller.

The current compositor supplies actual delivery reduction and visible source
geometry to the existing cursor/trail sizing owner. Complete comparisons preserve
full-size and clean output; tight crop glyphs match the established reference but
remain difficult to recognize at 32 pixels. No new sizing recipe is introduced.

Recording frame/materialization/selectors are removed after their useful checks
move to current source/project owners. Service batches isolate bad admissions,
unreadable cached items and failed jobs without starving valid siblings. The
native sparse/index callers retain their actual pixel and cache gates, with
syntax scope until execution.

Focused native audio checks preserve physical occupancy, exact PCM and late
consumer failure. Composition resampling preserves admitted boundary impulses
while excluding adjacent samples. These checks use current test executables;
they do not establish whole-movie or production-worker acceptance.

Remaining obligations include orphan audio/preview/processing/span owners,
current-source scale execution, unmatched movie/lifetime contracts and the actual
schema purge. The explicit caller harness uses current operations through controlled
replies; installed and actual media execution remain open. Installed switching, continuous playback, physical capture
and speech/listening acceptance remain separate release gates. No source recording
or accepted audition is changed by these fixture ports.
