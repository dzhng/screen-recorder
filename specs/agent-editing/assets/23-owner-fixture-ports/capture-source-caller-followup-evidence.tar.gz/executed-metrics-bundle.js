// apps/macos/tests/index-scale-metrics.test.mjs
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { join as join6 } from "node:path";
import { test } from "node:test";

// apps/macos/tests/fixtures/index-scale-metrics.mjs
import { DatabaseSync } from "node:sqlite";
import { setTimeout as delay } from "node:timers/promises";
async function indexScaleMetrics(database, waitMs = 1000) {
  const deadline = performance.now() + waitMs;
  for (;; ) {
    let db;
    try {
      db = new DatabaseSync(database, { readOnly: true });
      return {
        ...db.prepare(`SELECT
          (SELECT COALESCE(SUM(bytes), 0) FROM derived_cache) AS cacheBytes,
          COUNT(*) AS retainedCandidates,
          COALESCE(SUM(bytes), 0) AS retainedPngBytes,
          MAX(json_extract(candidate, '$.requestedSourceUs')) AS throughSourceUs,
          COALESCE(SUM(length(candidate)+length(frame)), 0) AS retainedRowBytes
          FROM screenshot_index_entries`).get()
      };
    } catch (error) {
      if (error.errcode !== 5)
        throw error;
    } finally {
      db?.close();
    }
    if (performance.now() >= deadline)
      return null;
    await delay(Math.min(50, Math.max(0, deadline - performance.now())));
  }
}

// packages/core/src/catalog.ts
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
var catalogFormat = 22;

class CatalogError extends Error {
  code;
  details;
  retryable;
  constructor(code, message, details = {}, retryable = false) {
    super(message);
    this.code = code;
    this.details = details;
    this.retryable = retryable;
  }
}

class Catalog {
  catalog;
  constructor(path, busyTimeoutMs = 1000) {
    if (!Number.isSafeInteger(busyTimeoutMs) || busyTimeoutMs < 0 || busyTimeoutMs > 1e4)
      throw new RangeError("SQLite timeout must be 0–10000 milliseconds");
    this.catalog = new DatabaseSync2(path, { timeout: busyTimeoutMs });
    const { user_version: format } = this.catalog.prepare("PRAGMA user_version").get();
    if (format === 0 && !this.catalog.prepare("SELECT 1 FROM sqlite_master LIMIT 1").get())
      this.catalog.exec(`PRAGMA user_version=${catalogFormat}`);
    else if (format !== catalogFormat) {
      this.catalog.close();
      throw new CatalogError("UNSUPPORTED_CATALOG", "This catalog was written in another format; open a library created by this version.", { format, supportedFormat: catalogFormat });
    }
  }
  close() {
    if (this.catalog.isOpen)
      this.catalog.close();
  }
  transaction(run) {
    let began = false;
    try {
      this.catalog.exec("BEGIN IMMEDIATE");
      began = true;
      const result = run();
      this.catalog.exec("COMMIT");
      return result;
    } catch (error) {
      if (began)
        this.catalog.exec("ROLLBACK");
      if (error && typeof error === "object" && "errcode" in error && error.errcode === 5)
        throw new CatalogError("STORAGE_BUSY", "Catalog is locked; retry the request", {}, true);
      throw error;
    }
  }
}

// packages/core/src/cache.ts
import { setImmediate as setImmediate2 } from "node:timers/promises";
import { randomUUID } from "node:crypto";
import {
  closeSync as closeSync2,
  constants as constants2,
  fstatSync as fstatSync2,
  lstatSync,
  mkdirSync,
  openSync as openSync2,
  opendirSync,
  realpathSync,
  unlinkSync
} from "node:fs";
import { basename, dirname, join as join2 } from "node:path";

// packages/core/src/files.ts
import { createHash } from "node:crypto";
import { lstat, realpath, open } from "node:fs/promises";
import { isDeepStrictEqual } from "node:util";
import { readSync, closeSync, constants, fstatSync, openSync } from "node:fs";
import { join } from "node:path";
var O_NOFOLLOW_ANY = 536870912;
function fileIdentity(stat) {
  return {
    device: String(stat.dev),
    inode: String(stat.ino),
    modifiedNs: String(stat.mtimeNs),
    changedNs: String(stat.ctimeNs)
  };
}
function openedFile(fd, onClose = () => {}) {
  let closed = false;
  return {
    get fd() {
      if (closed)
        throw new CatalogError("CONTEXT_CLOSED", "File read has been closed");
      return fd;
    },
    close() {
      if (closed)
        return;
      closed = true;
      try {
        closeSync(fd);
      } finally {
        onClose();
      }
    }
  };
}
class IdentifiedFiles {
  root;
  maximumOpen;
  entries = new Map;
  leases = new Map;
  closed = false;
  accepting = true;
  constructor(root, entries, maximumOpen = 32) {
    this.root = root;
    this.maximumOpen = maximumOpen;
    if (process.platform !== "darwin")
      throw new CatalogError("UNSUPPORTED_PLATFORM", "Retained packages require macOS file admission");
    for (const entry of entries)
      this.add(entry);
  }
  add(entry) {
    if (this.closed)
      throw new CatalogError("CONTEXT_CLOSED", "Package is closed");
    if (!/^[A-Za-z0-9_./-]+$/.test(entry.path) || entry.path.split("/").some((part) => !part || part === "." || part === "..") || this.entries.has(entry.path))
      throw new CatalogError("INVALID_PACKAGE", "Invalid or repeated local file identity");
    this.entries.set(entry.path, entry);
  }
  stop() {
    this.accepting = false;
  }
  check() {
    if (!this.accepting || this.closed)
      throw new CatalogError("CONTEXT_CLOSED", "Package is closed");
  }
  path(file) {
    return join(this.root, file);
  }
  open(file, writable = false, onClose = () => {}) {
    this.check();
    const expected = this.entries.get(file);
    if (!expected)
      throw new CatalogError("NOT_FOUND", "File is not admitted to this package");
    if (this.leases.size >= this.maximumOpen)
      throw new CatalogError("LIMIT_EXCEEDED", "Package open-file limit exceeded", {}, true);
    const fd = openSync(this.path(file), (writable ? constants.O_RDWR : constants.O_RDONLY) | constants.O_NONBLOCK | O_NOFOLLOW_ANY);
    try {
      const stat = fstatSync(fd, { bigint: true }), actual = fileIdentity(stat);
      if (!stat.isFile() || stat.nlink !== 1n || stat.size !== BigInt(expected.bytes) || actual.device !== expected.identity.device || actual.inode !== expected.identity.inode || actual.modifiedNs !== expected.identity.modifiedNs || actual.changedNs !== expected.identity.changedNs)
        throw new CatalogError("INVALID_STORAGE", "Package member changed after extraction");
      const lease = openedFile(fd, () => {
        this.leases.delete(lease);
        onClose();
      });
      this.leases.set(lease, file);
      return lease;
    } catch (error) {
      closeSync(fd);
      throw error;
    }
  }
  refresh(file, lease) {
    const previous = this.entries.get(file), stat = fstatSync(lease.fd, { bigint: true });
    if (!previous || !stat.isFile() || stat.nlink !== 1n || String(stat.dev) !== previous.identity.device || String(stat.ino) !== previous.identity.inode || stat.size > BigInt(Number.MAX_SAFE_INTEGER))
      throw new CatalogError("INVALID_STORAGE", "Output identity changed while writing");
    const entry = { path: file, bytes: Number(stat.size), identity: fileIdentity(stat) };
    this.entries.set(file, entry);
    return entry;
  }
  forget(file) {
    if ([...this.leases.values()].includes(file))
      throw new CatalogError("PROCESSING_BUSY", "File still has active reads");
    this.entries.delete(file);
  }
  close() {
    if (this.closed)
      return;
    this.closed = true;
    this.stop();
    const failures = [];
    for (const lease of this.leases.keys()) {
      try {
        lease.close();
      } catch (error) {
        failures.push(error);
      }
    }
    if (failures.length)
      throw new AggregateError(failures, "Package file closure failed");
  }
}
function retainedFileRead(file, bytes) {
  let released = false;
  return {
    bytes,
    read(buffer, position) {
      if (released)
        throw new CatalogError("INVALID_EVIDENCE", "Retained file read has been released");
      if (!Number.isSafeInteger(position) || position < 0 || position > bytes)
        throw new CatalogError("INVALID_EVIDENCE", "Invalid retained file read position");
      return readSync(file.fd, buffer, 0, Math.min(buffer.length, bytes - position), position);
    },
    release() {
      if (!released) {
        released = true;
        file.close();
      }
    }
  };
}
async function hashFile(file, expectedBytes, signal) {
  const before = await file.stat({ bigint: true });
  if (!before.isFile() || before.size !== BigInt(expectedBytes))
    throw new CatalogError("INVALID_STORAGE", "Retained file size differs from its identity");
  const hash = createHash("sha256"), buffer = Buffer.alloc(65536);
  for (let position = 0;position < expectedBytes; ) {
    signal.throwIfAborted();
    const { bytesRead } = await file.read(buffer, 0, Math.min(buffer.length, expectedBytes - position), position);
    if (!bytesRead)
      throw new CatalogError("INVALID_STORAGE", "Retained file ended during hashing");
    hash.update(buffer.subarray(0, bytesRead));
    position += bytesRead;
  }
  if (!isDeepStrictEqual(fileIdentity(before), fileIdentity(await file.stat({ bigint: true }))))
    throw new CatalogError("SOURCE_CHANGED", "Retained file changed during hashing");
  signal.throwIfAborted();
  return { bytes: expectedBytes, sha256: hash.digest("hex") };
}
async function copyImportedFile(path, destination, signal, expected, maximumBytes = Number.MAX_SAFE_INTEGER) {
  signal.throwIfAborted();
  let input;
  try {
    input = await open(path, constants.O_RDONLY | constants.O_NONBLOCK);
  } catch (error) {
    throw new CatalogError(error.code === "ENOENT" ? "NOT_FOUND" : "INVALID_PATH", "Cannot open import source", { filesystemCode: error.code });
  }
  try {
    const before = await input.stat({ bigint: true });
    if (expected && (BigInt(expected.bytes) !== before.size || !isDeepStrictEqual(expected.identity, fileIdentity(before))))
      throw new CatalogError("SOURCE_CHANGED", "Import source no longer matches the frozen request; create a new import", {}, false);
    if (!before.isFile() || before.size > BigInt(maximumBytes))
      throw new CatalogError("UNSUPPORTED_MEDIA", "Import source must be a regular file of supported size");
    const output = await open(destination, "wx", 384);
    const hash = createHash("sha256");
    let bytes = 0;
    try {
      const buffer = Buffer.allocUnsafe(1024 * 1024);
      for (;; ) {
        signal.throwIfAborted();
        const read = await input.read(buffer, 0, buffer.length, null);
        if (!read.bytesRead)
          break;
        bytes += read.bytesRead;
        if (BigInt(bytes) > before.size)
          throw new CatalogError("SOURCE_CHANGED", "Import source grew during copying", {}, false);
        hash.update(buffer.subarray(0, read.bytesRead));
        let written = 0;
        while (written < read.bytesRead) {
          signal.throwIfAborted();
          const result = await output.write(buffer, written, read.bytesRead - written);
          if (!result.bytesWritten)
            throw new CatalogError("STORAGE_ERROR", "Import copy made no progress");
          written += result.bytesWritten;
        }
      }
      const after = await input.stat({ bigint: true });
      if (BigInt(bytes) !== before.size || after.size !== before.size || after.mtimeNs !== before.mtimeNs || after.ctimeNs !== before.ctimeNs)
        throw new CatalogError("SOURCE_CHANGED", "Import source changed during copying", {}, false);
      await output.chmod(256);
      await output.sync();
    } finally {
      await output.close();
    }
    const sha256 = hash.digest("hex");
    if (expected?.sha256 !== undefined && sha256 !== expected.sha256)
      throw new CatalogError("SOURCE_CHANGED", "Imported bytes differ from verified source identity");
    return { sha256, bytes };
  } finally {
    await input.close();
  }
}

// packages/core/src/jobs.ts
import { createHash as createHash2 } from "node:crypto";
import { z as z2 } from "zod";

// packages/core/src/references.ts
var resourceKinds = [
  "asset",
  "acquisition",
  "scene-generation",
  "transcript-generation",
  "prepared-audio",
  "index-generation"
];

class ResourceReferences {
  store;
  constructor(store) {
    this.store = store;
    store.catalog.exec(`
      CREATE TABLE IF NOT EXISTS resource_references (
        resourceKind TEXT NOT NULL, resourceId TEXT NOT NULL,
        ownerKind TEXT NOT NULL, ownerId TEXT NOT NULL,
        PRIMARY KEY(resourceKind,resourceId,ownerKind,ownerId)
      ) STRICT;
      CREATE INDEX IF NOT EXISTS resource_reference_owner
        ON resource_references(ownerKind,ownerId,resourceKind);
    `);
  }
  retain(kind, owner, ids) {
    const insert = this.store.catalog.prepare("INSERT OR IGNORE INTO resource_references VALUES(?,?,?,?)");
    for (const id of ids)
      insert.run(kind, id, owner.kind, owner.id);
  }
  release(kind, owner) {
    this.store.catalog.prepare("DELETE FROM resource_references WHERE resourceKind=? AND ownerKind=? AND ownerId=?").run(kind, owner.kind, owner.id);
  }
  releaseOwnerPage(owner) {
    return Number(this.store.catalog.prepare(`DELETE FROM resource_references WHERE rowid IN
      (SELECT rowid FROM resource_references WHERE ownerKind=? AND ownerId=? LIMIT 256)`).run(owner.kind, owner.id).changes);
  }
  dependencies(owner, limit = 25000) {
    const rows = this.store.catalog.prepare(`SELECT resourceKind AS kind,resourceId AS id FROM resource_references
       WHERE ownerKind=? AND ownerId=? ORDER BY resourceKind,resourceId LIMIT ?`).all(owner.kind, owner.id, limit + 1);
    if (rows.length > limit)
      throw new RangeError("Resource dependency inventory exceeds its limit");
    return rows;
  }
  has(kind, id) {
    return Boolean(this.store.catalog.prepare("SELECT 1 FROM resource_references WHERE resourceKind=? AND resourceId=? LIMIT 1").get(kind, id));
  }
  owners(kind, id) {
    return this.store.catalog.prepare(`SELECT ownerKind AS kind,ownerId AS id FROM resource_references
        WHERE resourceKind=? AND resourceId=? ORDER BY ownerKind,ownerId`).all(kind, id);
  }
}

// packages/core/src/jobs.ts
import { setImmediate } from "node:timers/promises";

// packages/core/src/capture-publication.ts
import { z } from "zod";
var identity = z.string().min(1).max(256);
var diagnostic = z.strictObject({
  code: z.string().min(1).max(128),
  message: z.string().max(4096)
});
var hash = z.string().regex(/^[a-f0-9]{64}$/);
var media = z.strictObject({
  bytes: z.string().max(19).refine((value) => /^(0|[1-9]\d*)$/.test(value) && Number.isSafeInteger(Number(value))),
  sha256: hash
});
var published = z.strictObject({
  kind: z.enum(["primary", "camera"]),
  sourceId: identity,
  sourceDurationUs: z.int().positive(),
  originHostUs: z.int().nonnegative(),
  binding: z.strictObject({ recordingId: identity, sourceId: identity, deviceId: identity }).optional(),
  diagnostic: diagnostic.optional(),
  journal: z.strictObject({
    file: z.enum(["source.journal.jsonl", "capture.journal.jsonl"]),
    bytes: z.int().positive().max(268435456),
    sha256: hash,
    lastSequence: z.int().positive(),
    layout: z.union([z.literal(1), z.literal(2)])
  }),
  members: z.strictObject({
    "video.mov": media,
    "narration.mov": media.optional(),
    "system.mov": media.optional(),
    "narration.publication.json": media.optional(),
    "system.publication.json": media.optional(),
    "camera.publication.json": media.optional(),
    "camera.mapping.jsonl": media.optional()
  })
});
var outcome = z.discriminatedUnion("state", [
  z.strictObject({ state: z.literal("published"), source: published }),
  z.strictObject({
    state: z.literal("pending"),
    error: diagnostic.extend({ retryable: z.boolean() })
  }),
  z.strictObject({ state: z.literal("unavailable"), error: diagnostic })
]);
var observation = z.strictObject({
  generation: identity,
  sourceId: identity,
  inputsClosed: z.boolean(),
  primary: outcome.nullable(),
  camera: outcome.nullable()
});

// packages/core/src/capture-store.ts
var nextStates = {
  preparing: ["recording", "finalizing", "interrupted", "canceled"],
  recording: ["recording", "paused", "finalizing", "interrupted", "canceled"],
  paused: ["paused", "recording", "finalizing", "interrupted", "canceled"],
  finalizing: ["finalizing", "complete", "interrupted", "canceled"],
  complete: ["complete"],
  interrupted: ["interrupted"],
  canceled: ["canceled"]
};
function isSettled(state) {
  return nextStates[state].every((next) => next === state);
}
var unsettledStates = Object.keys(nextStates).filter((state) => !isSettled(state));

// packages/core/src/jobs.ts
var laneLimits = { heavy: 1, frame: 2 };
var queuedLimit = 32;
var waitingLimit = 32;
var retainedPublicationSchema = z2.strictObject({
  generation: z2.int().positive().max(Number.MAX_SAFE_INTEGER),
  attemptId: z2.string().min(1).max(256),
  input: z2.string().max(65536)
});

class JobDependencyLost extends Error {
}
function contextValue({ queuedSequence: _sequence, ...job }) {
  return job;
}
var contextLimit = 4;
var contextJobLimit = 32;
var contextValueBytes = 64 * 1024;
var summaryColumns = "jobId,attemptId,targetKind,targetId,revisionId,artifact,lane,state,reason,retryable,generation,errorCode,errorDetails";
var jobColumns = `${summaryColumns},input`;
function inputDigest(input) {
  return createHash2("sha256").update(input).digest("hex");
}
function requireExactInput(actual, expected) {
  if (actual !== expected)
    throw new CatalogError("IDENTITY_COLLISION", "Different job inputs have the same digest");
}
function ownerIdentity(owner) {
  switch (owner.kind) {
    case "import":
      return [owner.kind, owner.importId];
    case "asset":
      return [owner.kind, owner.assetId];
    case "acquisition":
      return [owner.kind, owner.acquisitionId];
    case "project":
      return [owner.kind, owner.projectId];
    case "recording":
      return [owner.kind, owner.recordingId];
  }
}
function targetValues(target) {
  return [...ownerIdentity(target), "revisionId" in target ? target.revisionId ?? "" : ""];
}
function ownerFromIdentity(kind, id) {
  switch (kind) {
    case "import":
      return { kind, importId: id };
    case "asset":
      return { kind, assetId: id };
    case "acquisition":
      return { kind, acquisitionId: id };
    case "project":
      return { kind, projectId: id };
    case "recording":
      return { kind, recordingId: id };
  }
}
function targetFrom({ targetKind, targetId, revisionId }) {
  const owner = ownerFromIdentity(targetKind, targetId);
  if (owner.kind === "recording")
    return { ...owner, revisionId: revisionId === "" ? null : revisionId };
  return owner.kind === "project" ? { ...owner, revisionId } : owner;
}
function toArtifact({
  targetKind,
  targetId,
  revisionId,
  attemptId: _attemptId,
  ...row
}) {
  return { ...row, target: targetFrom({ targetKind, targetId, revisionId }) };
}
function toJob({ targetKind, targetId, revisionId, ...row }) {
  return {
    ...row,
    target: targetFrom({ targetKind, targetId, revisionId }),
    errorDetails: row.errorDetails === null ? null : JSON.parse(row.errorDetails),
    retryable: row.retryable === 1
  };
}
function sameOwner(first, second) {
  return first !== undefined && ownerIdentity(first).every((value, index) => value === ownerIdentity(second)[index]);
}
function failureDetails(details) {
  let entries = 0;
  let bytes = 0;
  const copy = (value, depth) => {
    if (++entries > 1024 || depth > 8)
      throw new Error("limit");
    if (typeof value === "string") {
      bytes += Buffer.byteLength(value);
      if (bytes > 16384)
        throw new Error("limit");
      return value;
    }
    if (value === null || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
      return value;
    if (!value || typeof value !== "object")
      throw new Error("unsupported");
    const array = Array.isArray(value);
    if (!array && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
      throw new Error("unsupported");
    const result = Object.create(null);
    for (const key in value) {
      if (!Object.hasOwn(value, key))
        continue;
      bytes += Buffer.byteLength(key);
      if (bytes > 16384)
        throw new Error("limit");
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor))
        throw new Error("accessor");
      result[key] = copy(descriptor.value, depth + 1);
    }
    return array ? Object.values(result) : result;
  };
  try {
    const result = copy(details, 0);
    if (Buffer.byteLength(JSON.stringify(result)) > 16384)
      throw new Error("limit");
    return result;
  } catch {
    return { truncated: true, reason: "Diagnostic details exceed limits or are not JSON data" };
  }
}
function failure(error) {
  return {
    state: error instanceof CatalogError && error.code === "UNAVAILABLE" ? "unavailable" : "failed",
    errorCode: error instanceof CatalogError ? error.code : "JOB_FAILED",
    errorDetails: error instanceof CatalogError ? failureDetails(error.details) : null,
    reason: (error instanceof Error ? error.message : String(error)).slice(0, 4096),
    retryable: !(error instanceof CatalogError) || error.retryable
  };
}

class JobQueue {
  store;
  references;
  targets;
  execute;
  newId;
  attempts = new Map;
  contexts = new WeakMap;
  activeContexts = new Set;
  sequence = 0;
  closed = false;
  executionStarted;
  admission;
  admitting = false;
  admissionScheduled = false;
  onCapacity;
  constructor(options) {
    this.store = options.store;
    this.executionStarted = !options.deferExecution;
    this.store.catalog.function("job_input_digest", { deterministic: true }, (input) => {
      if (typeof input !== "string")
        throw new TypeError("Job input must be text");
      return inputDigest(input);
    });
    this.references = new ResourceReferences(this.store);
    this.targets = options.targets;
    this.execute = options.execute;
    this.newId = options.providers.newId;
    this.onCapacity = options.onCapacity;
    this.store.catalog.exec(`
   CREATE TABLE IF NOT EXISTS jobs (
    jobId TEXT PRIMARY KEY,attemptId TEXT NOT NULL,targetKind TEXT NOT NULL,targetId TEXT NOT NULL,revisionId TEXT NOT NULL,
    artifact TEXT NOT NULL,lane TEXT NOT NULL,state TEXT NOT NULL,
    reason TEXT,errorCode TEXT,errorDetails TEXT,retryable INTEGER NOT NULL,generation INTEGER NOT NULL,queuedSequence INTEGER NOT NULL,
    deferred INTEGER NOT NULL DEFAULT 0 CHECK(deferred IN (0,1)),
    readmitted INTEGER NOT NULL DEFAULT 0 CHECK(readmitted IN (0,1)),
    inputSha256 TEXT NOT NULL,input TEXT NOT NULL
   ) STRICT;
   CREATE UNIQUE INDEX IF NOT EXISTS jobs_identity
    ON jobs(targetKind,targetId,revisionId,artifact,inputSha256);
   CREATE INDEX IF NOT EXISTS jobs_waiting ON jobs(queuedSequence) WHERE state='waiting';
   CREATE TABLE IF NOT EXISTS artifacts (
    targetKind TEXT NOT NULL,targetId TEXT NOT NULL,artifact TEXT NOT NULL,generation INTEGER NOT NULL,
    revisionId TEXT NOT NULL,attemptId TEXT NOT NULL,result TEXT NOT NULL,inputSha256 TEXT NOT NULL,input TEXT NOT NULL,
    PRIMARY KEY(targetKind,targetId,revisionId,artifact,inputSha256)
   ) STRICT;
   CREATE INDEX IF NOT EXISTS artifacts_attempt ON artifacts(targetKind,targetId,artifact,attemptId);
  `);
    this.store.catalog.prepare("UPDATE jobs SET state='failed',reason=?,errorCode='JOB_INTERRUPTED',errorDetails=NULL,retryable=1 WHERE state='running'").run("interrupted");
    this.sequence = Number(this.store.catalog.prepare("SELECT COALESCE(MAX(queuedSequence),0) AS sequence FROM jobs").get().sequence);
    this.runQueued();
  }
  start() {
    this.requireOpen();
    if (this.executionStarted)
      return;
    this.executionStarted = true;
    this.resumeAdmission();
    this.runQueued();
  }
  createContext(execute) {
    this.requireOpen();
    if (this.activeContexts.size >= contextLimit)
      throw new CatalogError("LIMIT_EXCEEDED", "Too many package contexts are open", {}, true);
    const context = Object.freeze({ contextId: this.newId() });
    const state = { id: context.contextId, execute, jobs: new Map, closed: false };
    this.contexts.set(context, state);
    this.activeContexts.add(state);
    return context;
  }
  context(context, allowClosed = false) {
    const state = this.contexts.get(context);
    if (!state || state.closed && !allowClosed)
      throw new CatalogError("CONTEXT_CLOSED", "Package context is not open in this queue");
    return state;
  }
  submitContext(context, request) {
    this.requireOpen();
    const state = this.context(context);
    if (!request.artifact || Buffer.byteLength(request.artifact) > 128 || Buffer.byteLength(request.input) > contextValueBytes)
      throw new CatalogError("LIMIT_EXCEEDED", "Package job identity is too large");
    const existing = [...state.jobs.values()].find((job2) => job2.artifact === request.artifact && job2.input === request.input);
    if (existing) {
      if (existing.lane !== request.lane)
        throw new CatalogError("INVALID_REQUEST", "An existing job cannot change execution lane");
      this.runQueued();
      return this.contextJob(context, existing.jobId);
    }
    if (state.jobs.size >= contextJobLimit)
      throw new CatalogError("LIMIT_EXCEEDED", "Package context job metadata limit exceeded");
    this.admit();
    const job = {
      jobId: this.newId(),
      attemptId: this.newId(),
      contextId: state.id,
      artifact: request.artifact,
      input: request.input,
      lane: request.lane,
      state: "queued",
      reason: null,
      errorCode: null,
      errorDetails: null,
      retryable: false,
      generation: 1,
      result: null,
      queuedSequence: ++this.sequence
    };
    state.jobs.set(job.jobId, job);
    this.runQueued();
    return this.contextJob(context, job.jobId);
  }
  contextJobs(context) {
    return {
      jobs: [...this.context(context).jobs.values()].map(contextValue),
      capacity: contextJobLimit,
      valueBytes: contextValueBytes
    };
  }
  contextJob(context, jobId) {
    const job = this.context(context).jobs.get(jobId);
    if (!job)
      throw new CatalogError("NOT_FOUND", "Package job does not exist", { jobId });
    return contextValue(job);
  }
  retryContext(context, jobId) {
    this.requireOpen();
    const state = this.context(context), current = this.contextJob(context, jobId);
    if (["queued", "running", "ready"].includes(current.state)) {
      this.runQueued();
      return this.contextJob(context, jobId);
    }
    if (!current.retryable)
      throw new CatalogError("UNAVAILABLE", "Package job cannot be retried");
    this.admit();
    state.jobs.set(jobId, {
      ...current,
      attemptId: this.newId(),
      generation: current.generation + 1,
      queuedSequence: ++this.sequence,
      state: "queued",
      reason: null,
      errorCode: null,
      errorDetails: null,
      retryable: false,
      result: null
    });
    this.runQueued();
    return this.contextJob(context, jobId);
  }
  cancelContextJob(context, jobId) {
    this.requireOpen();
    const state = this.context(context), job = this.contextJob(context, jobId);
    if (job.state === "queued" || job.state === "running") {
      Object.assign(state.jobs.get(jobId), {
        state: "canceled",
        reason: "canceled",
        errorCode: null,
        errorDetails: null,
        retryable: true
      });
      this.attempts.get(job.attemptId)?.controller.abort();
      this.capacityAvailable();
    }
    return this.contextJob(context, jobId);
  }
  forgetContextJob(context, jobId) {
    const state = this.context(context), job = this.contextJob(context, jobId);
    if (job.state === "queued" || job.state === "running" || [...this.attempts.values()].some((attempt) => attempt.jobId === jobId))
      throw new CatalogError("PROCESSING_BUSY", "Package job is still active", {}, true);
    state.jobs.delete(jobId);
  }
  closeContext(context) {
    const state = this.context(context, true);
    return state.closing ??= (async () => {
      state.closed = true;
      for (const job of state.jobs.values())
        if (job.state === "queued" || job.state === "running")
          Object.assign(job, {
            state: "canceled",
            reason: "context_closed",
            errorCode: null,
            errorDetails: null,
            retryable: false
          });
      const attempts = [...this.attempts.values()].filter((attempt) => attempt.context === state);
      for (const attempt of attempts)
        attempt.controller.abort();
      this.capacityAvailable();
      await Promise.all(attempts.map((attempt) => attempt.done));
      state.jobs.clear();
      delete state.execute;
      this.activeContexts.delete(state);
    })();
  }
  submit(request, admitted) {
    return this.submitJob(request, false, admitted);
  }
  submitDeferred(request, admitted) {
    return this.submitJob(request, true, admitted);
  }
  submitJob(input, deferred, admitted) {
    let created = false;
    const jobId = this.store.transaction(() => {
      this.requireOpen();
      const request = typeof input === "function" ? input() : input;
      const target = this.targets.pin(request.target);
      const existing = this.existing({ ...request, target });
      if (existing) {
        if (existing.lane !== request.lane)
          throw new CatalogError("INVALID_REQUEST", "An existing job cannot change execution lane");
        admitted?.(this.job(existing.jobId));
        return existing.jobId;
      }
      if (deferred)
        this.admitWaiting();
      else
        this.admit();
      created = true;
      const admittedId = this.newId();
      this.store.catalog.prepare(`INSERT INTO jobs(jobId,attemptId,targetKind,targetId,revisionId,artifact,lane,input,state,reason,retryable,generation,errorCode,errorDetails,queuedSequence,deferred,inputSha256)
           VALUES (?,?,?,?,?,?,?,?,?,NULL,0,?,NULL,NULL,?,?,?)`).run(admittedId, this.newId(), ...targetValues(target), request.artifact, request.lane, request.input, deferred ? "waiting" : "queued", this.nextGeneration({ target, artifact: request.artifact, input: request.input }), ++this.sequence, Number(deferred), inputDigest(request.input));
      admitted?.(this.job(admittedId));
      return admittedId;
    });
    if (created) {
      if (deferred && this.admitting)
        this.scheduleAdmission();
      else
        this.resumeAdmission();
    }
    this.runQueued();
    return this.job(jobId);
  }
  retry(jobId) {
    let changed = false;
    const retried = this.store.transaction(() => {
      this.requireOpen();
      const current = this.job(jobId);
      this.targets.pin(current.target);
      if (current.state === "waiting" || current.state === "queued" || current.state === "running" || current.state === "ready")
        return current.jobId;
      if (!current.retryable)
        throw new CatalogError("UNAVAILABLE", "This job cannot be retried", {
          state: current.state,
          reason: current.reason,
          errorCode: current.errorCode
        });
      this.requeue(current);
      changed = true;
      return jobId;
    });
    if (changed)
      this.resumeAdmission();
    this.runQueued();
    return this.job(retried);
  }
  regenerate(jobId, generation, admitted) {
    let changed = false;
    this.store.transaction(() => {
      this.requireOpen();
      const current = this.job(jobId);
      if (current.state !== "ready" || current.generation !== generation)
        return;
      this.targets.pin(current.target);
      this.requeue(current);
      admitted?.(this.job(jobId));
      this.store.catalog.prepare("DELETE FROM artifacts WHERE targetKind=? AND targetId=? AND revisionId=? AND artifact=? AND inputSha256=? AND input=? AND generation=?").run(...targetValues(current.target), current.artifact, inputDigest(current.input), current.input, generation);
      changed = true;
    });
    if (changed)
      this.resumeAdmission();
    this.runQueued();
    return this.job(jobId);
  }
  requeue(current, readmitted = false) {
    const { deferred } = this.store.catalog.prepare("SELECT deferred FROM jobs WHERE jobId=?").get(current.jobId);
    if (deferred)
      this.admitWaiting();
    else
      this.admit();
    this.store.catalog.prepare(`UPDATE jobs SET state=?,attemptId=?,reason=NULL,errorCode=NULL,errorDetails=NULL,retryable=0,generation=generation+1,
         queuedSequence=?,readmitted=? WHERE jobId=?`).run(deferred ? "waiting" : "queued", this.newId(), ++this.sequence, Number(readmitted), current.jobId);
    if (deferred && this.admitting)
      this.scheduleAdmission();
  }
  cancel(jobId) {
    this.requireOpen();
    const stopped = this.store.transaction(() => {
      const current = this.job(jobId);
      if (current.state !== "waiting" && current.state !== "queued" && current.state !== "running")
        return null;
      this.discard(jobId, "canceled");
      return current.attemptId;
    });
    if (stopped !== null) {
      this.attempts.get(stopped)?.controller.abort();
      this.capacityAvailable();
    }
    return this.job(jobId);
  }
  requireOpen() {
    if (this.closed)
      throw new CatalogError("SERVICE_STOPPED", "The job queue is closed", {}, true);
  }
  existing(identity2) {
    const row = this.store.catalog.prepare(`SELECT ${jobColumns} FROM jobs WHERE targetKind=? AND targetId=? AND revisionId=? AND artifact=? AND inputSha256=?`).get(...targetValues(identity2.target), identity2.artifact, inputDigest(identity2.input));
    if (row)
      requireExactInput(row.input, identity2.input);
    return row ? toJob(row) : null;
  }
  job(jobId) {
    const row = this.store.catalog.prepare(`SELECT ${jobColumns} FROM jobs WHERE jobId=?`).get(jobId);
    if (!row)
      throw new CatalogError("NOT_FOUND", "Job does not exist", { jobId });
    return toJob(row);
  }
  wasReadmitted(jobId) {
    this.job(jobId);
    return !!this.store.catalog.prepare("SELECT readmitted FROM jobs WHERE jobId=?").get(jobId).readmitted;
  }
  publication(identity2) {
    const row = this.store.catalog.prepare("SELECT targetKind,targetId,revisionId,artifact,generation,input,attemptId,result FROM artifacts WHERE targetKind=? AND targetId=? AND revisionId=? AND artifact=? AND inputSha256=?").get(...targetValues(identity2.target), identity2.artifact, inputDigest(identity2.input));
    if (row)
      requireExactInput(row.input, identity2.input);
    return row ?? null;
  }
  nextGeneration(identity2) {
    const generation = (this.publication(identity2)?.generation ?? 0) + 1;
    if (!Number.isSafeInteger(generation))
      throw new CatalogError("LIMIT_EXCEEDED", "Artifact generation limit exceeded");
    return generation;
  }
  inspect(jobId) {
    const row = this.store.catalog.prepare(`SELECT ${summaryColumns},inputSha256 FROM jobs WHERE jobId=?`).get(jobId);
    if (!row)
      throw new CatalogError("NOT_FOUND", "Job does not exist", { jobId });
    const { targetKind, targetId, revisionId, retryable, errorDetails, ...summary } = row;
    const target = targetFrom(row);
    const publication = this.targets.isAvailable(target) ? this.store.catalog.prepare("SELECT result FROM artifacts WHERE targetKind=? AND targetId=? AND revisionId=? AND artifact=? AND inputSha256=?").get(targetKind, targetId, revisionId, row.artifact, row.inputSha256) : undefined;
    return {
      ...summary,
      target,
      retryable: Boolean(retryable),
      errorDetails: errorDetails ? JSON.parse(errorDetails) : null,
      result: publication ? JSON.parse(publication.result) : null
    };
  }
  retainedArtifact(owner, artifact, attemptId) {
    const row = this.store.catalog.prepare("SELECT targetKind,targetId,revisionId,artifact,generation,input,result FROM artifacts WHERE targetKind=? AND targetId=? AND artifact=? AND attemptId=? LIMIT 1").get(...ownerIdentity(owner), artifact, attemptId);
    return row ? { ...toArtifact(row), attemptId } : null;
  }
  adoptArtifact(receipt) {
    this.requireOpen();
    this.targets.pin(receipt.target);
    const existing = this.publication(receipt);
    if (existing) {
      if (existing.generation !== receipt.generation || existing.attemptId !== receipt.attemptId || existing.result !== receipt.result)
        throw new CatalogError("INVALID_PACKAGE", "Retained publication conflicts with local artifact");
      return;
    }
    const local = this.existing(receipt);
    if (local) {
      if (["waiting", "queued", "running"].includes(local.state))
        throw new CatalogError("PROCESSING_BUSY", "Local work already owns this publication identity", {}, true);
      throw new CatalogError("INVALID_PACKAGE", "Local terminal work conflicts with retained publication identity");
    }
    if (!Number.isSafeInteger(receipt.generation) || receipt.generation < 1 || !receipt.attemptId)
      throw new CatalogError("INVALID_PACKAGE", "Invalid retained publication identity");
    this.store.catalog.prepare("INSERT INTO artifacts(targetKind,targetId,revisionId,artifact,generation,input,attemptId,result,inputSha256) VALUES(?,?,?,?,?,?,?,?,?)").run(...targetValues(receipt.target), receipt.artifact, receipt.generation, receipt.input, receipt.attemptId, receipt.result, inputDigest(receipt.input));
  }
  status(identity2) {
    const job = this.existing(identity2);
    const present = this.targets.isAvailable(identity2.target);
    const published2 = present ? this.publication(identity2) : null;
    return {
      state: !present || job?.state === "canceled" ? "not_requested" : !job ? published2 ? "ready" : "not_requested" : job.state === "waiting" ? "queued" : job.state === "running" ? "processing" : job.state,
      jobId: job?.jobId ?? null,
      reason: job?.reason ?? null,
      retryable: job?.retryable ?? false,
      published: published2 ? toArtifact(published2) : null
    };
  }
  schedule() {
    this.resumeAdmission();
    this.runQueued();
  }
  runQueued() {
    if (this.closed || !this.executionStarted || this.admitting)
      return;
    const capturing = this.targets.isCapturing();
    for (const lane of Object.keys(laneLimits)) {
      if (lane === "heavy" && capturing)
        continue;
      while (this.occupied(lane) < laneLimits[lane]) {
        const job = this.claim(lane);
        if (!job)
          break;
        if (job.context)
          this.runContext(job.context, job.job);
        else
          this.run(job.job);
      }
    }
  }
  async drainJob(jobId) {
    this.cancel(jobId);
    const active = [...this.attempts.values()].filter((attempt) => attempt.jobId === jobId);
    for (const attempt of active)
      attempt.controller.abort();
    await Promise.all(active.map((attempt) => attempt.done));
  }
  forgetJob(jobId) {
    this.store.transaction(() => {
      const job = this.job(jobId);
      if (["waiting", "queued", "running"].includes(job.state) || [...this.attempts.values()].some((attempt) => attempt.jobId === jobId))
        throw new CatalogError("PROCESSING_BUSY", "Job is still active", {}, true);
      this.store.catalog.prepare("DELETE FROM artifacts WHERE targetKind=? AND targetId=? AND revisionId=? AND artifact=? AND inputSha256=? AND input=?").run(...targetValues(job.target), job.artifact, inputDigest(job.input), job.input);
      for (const kind of ["job", "job-input"])
        while (this.references.releaseOwnerPage({ kind, id: jobId })) {}
      this.store.catalog.prepare("DELETE FROM jobs WHERE jobId=?").run(jobId);
    });
  }
  async drainOwner(owner) {
    if (!this.targets.isDeleting(owner))
      throw new CatalogError("INVALID_STATE", "Target deletion has not been requested");
    this.store.catalog.prepare(`UPDATE jobs SET state='canceled',reason=?,errorCode=NULL,errorDetails=NULL,retryable=0
      WHERE targetKind=? AND targetId=? AND state IN ('waiting','queued','running')`).run(`${owner.kind}_unavailable`, ...ownerIdentity(owner));
    const active = [...this.attempts.values()].filter((attempt) => sameOwner(attempt.target, owner));
    for (const attempt of active)
      attempt.controller.abort();
    this.capacityAvailable();
    await Promise.all(active.map((attempt) => attempt.done));
  }
  async forgetOwner(owner) {
    if (!this.targets.isDeleting(owner))
      throw new CatalogError("INVALID_STATE", "Target deletion has not been requested");
    if ([...this.attempts.values()].some((attempt) => sameOwner(attempt.target, owner)) || this.store.catalog.prepare("SELECT 1 FROM jobs WHERE targetKind=? AND targetId=? AND state IN ('waiting','queued','running') LIMIT 1").get(...ownerIdentity(owner)))
      throw new CatalogError("PROCESSING_BUSY", "Target jobs have not finished closing", {}, true);
    for (;; ) {
      const jobs = this.store.catalog.prepare("SELECT jobId FROM jobs WHERE targetKind=? AND targetId=? LIMIT 256").all(...ownerIdentity(owner));
      if (!jobs.length)
        break;
      for (const { jobId } of jobs) {
        for (const kind of ["job", "job-input"])
          while (this.references.releaseOwnerPage({ kind, id: jobId }))
            await setImmediate();
        this.store.catalog.prepare("DELETE FROM jobs WHERE jobId=?").run(jobId);
      }
      await setImmediate();
    }
    for (;; ) {
      const removed = this.store.catalog.prepare(`DELETE FROM artifacts WHERE rowid IN
        (SELECT rowid FROM artifacts WHERE targetKind=? AND targetId=? LIMIT 256)`).run(...ownerIdentity(owner));
      if (Number(removed.changes) === 0)
        break;
      await setImmediate();
    }
  }
  async idle() {
    while (this.attempts.size > 0 || this.admissionScheduled) {
      if (this.attempts.size > 0)
        await Promise.all([...this.attempts.values()].map((attempt) => attempt.done));
      else
        await setImmediate();
    }
  }
  async close() {
    this.closed = true;
    let interruption;
    try {
      this.store.transaction(() => {
        for (const attemptId of this.attempts.keys())
          this.store.catalog.prepare("UPDATE jobs SET state='failed',reason='interrupted',errorCode='JOB_INTERRUPTED',errorDetails=NULL,retryable=1 WHERE attemptId=? AND state='running'").run(attemptId);
      });
    } catch (error) {
      interruption = error;
    }
    const contexts = [...this.activeContexts];
    for (const state of contexts)
      state.closed = true;
    for (const attempt of this.attempts.values())
      attempt.controller.abort();
    await this.idle();
    for (const state of contexts) {
      state.jobs.clear();
      delete state.execute;
    }
    this.activeContexts.clear();
    if (interruption)
      throw interruption;
  }
  isAttemptActive(attemptId) {
    return this.attempts.has(attemptId);
  }
  isArtifactBusy(artifact) {
    return [...this.attempts.values()].some((attempt) => attempt.artifact === artifact) || Boolean(this.store.catalog.prepare("SELECT 1 FROM jobs WHERE artifact=? AND state IN ('queued','running') LIMIT 1").get(artifact));
  }
  retainInputs(jobId, kind, ids) {
    const job = this.job(jobId);
    if (!["waiting", "queued", "running"].includes(job.state) && !job.retryable)
      return;
    this.references.retain(kind, { kind: "job-input", id: jobId }, ids);
  }
  retainsInput(kind, id) {
    if (this.store.catalog.prepare(`SELECT 1 FROM resource_references AS ref
      JOIN jobs ON jobs.jobId=ref.ownerId
      WHERE ref.resourceKind=? AND ref.resourceId=? AND ref.ownerKind='job-input'
      AND (jobs.state IN ('waiting','queued','running') OR jobs.retryable=1) LIMIT 1`).get(kind, id))
      return true;
    for (const attempt of this.attempts.values())
      if (this.store.catalog.prepare(`SELECT 1 FROM resource_references
        WHERE resourceKind=? AND resourceId=? AND ownerKind='job-input' AND ownerId=?`).get(kind, id, attempt.jobId))
        return true;
    return false;
  }
  releaseFinishedInputs(jobId, completedAttempt) {
    if ([...this.attempts.entries()].some(([id, attempt]) => attempt.jobId === jobId && id !== completedAttempt))
      return;
    this.store.catalog.prepare(`DELETE FROM resource_references
      WHERE ownerKind='job-input' AND ownerId=? AND EXISTS
      (SELECT 1 FROM jobs WHERE jobId=? AND state NOT IN ('waiting','queued','running') AND retryable=0)`).run(jobId, jobId);
  }
  retainsAttempt(owner, artifact, attemptId) {
    return this.attempts.has(attemptId) || Boolean(this.store.catalog.prepare("SELECT 1 FROM artifacts WHERE targetKind=? AND targetId=? AND artifact=? AND attemptId=?").get(...ownerIdentity(owner), artifact, attemptId));
  }
  backfill(request, dependency) {
    if (this.isArtifactBusy(request.artifact))
      return;
    const pending = this.store.catalog.prepare(`SELECT recordingId FROM recordings
      WHERE state IN ('complete','interrupted') AND sourceDurationUs IS NOT NULL
      AND recordingId NOT IN (SELECT recordingId FROM recording_deletions)
      AND NOT EXISTS (SELECT 1 FROM jobs WHERE jobs.targetKind='recording' AND jobs.targetId=recordings.recordingId
        AND jobs.revisionId='r0' AND jobs.artifact=? AND jobs.inputSha256=? AND jobs.input=?)
      ${dependency ? `AND EXISTS (SELECT 1 FROM artifacts WHERE artifacts.targetKind='recording' AND artifacts.targetId=recordings.recordingId
        AND artifacts.revisionId='r0' AND artifacts.artifact=? AND artifacts.inputSha256=? AND artifacts.input=?)` : ""}
      ORDER BY creationSequence LIMIT 1`).get(request.artifact, inputDigest(request.input), request.input, ...dependency ? [dependency.artifact, inputDigest(dependency.input), dependency.input] : []);
    if (!pending)
      return;
    try {
      this.submit({
        ...request,
        target: { kind: "recording", recordingId: pending.recordingId, revisionId: "r0" }
      });
    } catch (error) {
      if (!(error instanceof CatalogError && error.code === "LIMIT_EXCEEDED"))
        throw error;
    }
  }
  occupied(lane) {
    let count = 0;
    for (const attempt of this.attempts.values())
      if (attempt.lane === lane)
        count += 1;
    return count;
  }
  startAdmission(admit) {
    this.requireOpen();
    if (this.admission)
      throw new CatalogError("INVALID_STATE", "Admission owner already installed");
    this.admission = admit;
    this.resumeAdmission();
  }
  scheduleAdmission() {
    if (this.admissionScheduled || this.closed)
      return;
    this.admissionScheduled = true;
    setImmediate().then(() => {
      this.admissionScheduled = false;
      this.resumeAdmission();
    });
  }
  resumeAdmission() {
    if (this.closed || !this.executionStarted || this.admitting || !this.admission)
      return;
    this.admitting = true;
    try {
      const rows = this.store.catalog.prepare(`SELECT ${jobColumns} FROM jobs WHERE state='waiting' ORDER BY queuedSequence LIMIT ?`).all(waitingLimit);
      for (const row of rows) {
        if (this.closed)
          break;
        if (this.job(row.jobId).state !== "waiting")
          continue;
        if (this.targets.isDeleting(targetFrom(row))) {
          this.store.transaction(() => this.discard(row.jobId, `${row.targetKind}_unavailable`));
          this.scheduleAdmission();
          continue;
        }
        try {
          const outcome2 = this.admission(toJob(row));
          if (this.job(row.jobId).state !== "waiting")
            continue;
          if (outcome2.state === "waiting") {
            this.store.catalog.prepare("UPDATE jobs SET reason=? WHERE jobId=?").run(outcome2.dependency, row.jobId);
          } else {
            this.admit();
            this.store.catalog.prepare("UPDATE jobs SET state='queued',reason=NULL,queuedSequence=? WHERE jobId=?").run(++this.sequence, row.jobId);
          }
        } catch (error) {
          if (error instanceof CatalogError && error.code === "LIMIT_EXCEEDED" && error.retryable)
            continue;
          if (this.job(row.jobId).state !== "waiting")
            continue;
          this.store.transaction(() => this.fail(row.jobId, error));
          this.scheduleAdmission();
        }
      }
    } finally {
      this.admitting = false;
    }
    this.runQueued();
  }
  admitWaiting() {
    const row = this.store.catalog.prepare("SELECT COUNT(*) AS count FROM jobs WHERE state='waiting'").get();
    if (row.count >= waitingLimit)
      throw new CatalogError("LIMIT_EXCEEDED", "Too much dependency work is already waiting", {}, true);
  }
  admit() {
    const { queued } = this.store.catalog.prepare("SELECT COUNT(*) AS queued FROM jobs WHERE state='queued'").get();
    const contextQueued = [...this.activeContexts].reduce((count, context) => count + [...context.jobs.values()].filter((job) => job.state === "queued").length, 0);
    if (queued + contextQueued >= queuedLimit)
      throw new CatalogError("LIMIT_EXCEEDED", "Too much work is already waiting; retry once the queue drains", { queued: queued + contextQueued }, true);
  }
  fail(jobId, error, completedAttempt) {
    const { state, reason, retryable, errorCode, errorDetails } = failure(error);
    this.store.catalog.prepare("UPDATE jobs SET state=?,reason=?,retryable=?,errorCode=?,errorDetails=? WHERE jobId=?").run(state, reason, Number(retryable), errorCode, errorDetails === null ? null : JSON.stringify(errorDetails), jobId);
    this.releaseFinishedInputs(jobId, completedAttempt);
  }
  discard(jobId, reason) {
    this.store.catalog.prepare("UPDATE jobs SET state='canceled',reason=?,errorCode=NULL,errorDetails=NULL,retryable=? WHERE jobId=?").run(reason, reason === "canceled" ? 1 : 0, jobId);
    this.releaseFinishedInputs(jobId);
  }
  claim(lane) {
    const claimed = this.store.transaction(() => {
      for (;; ) {
        const row = this.store.catalog.prepare(`SELECT ${jobColumns},queuedSequence FROM jobs
             WHERE lane=? AND state='queued' ORDER BY queuedSequence LIMIT 1`).get(lane);
        const eligible = [...this.activeContexts].filter((context) => !context.closed && ![...this.attempts.values()].some((attempt) => attempt.context === context)).flatMap((context) => [...context.jobs.values()].filter((job) => job.state === "queued" && job.lane === lane).map((job) => ({ context, job }))).sort((a, b) => a.job.queuedSequence - b.job.queuedSequence)[0];
        if (eligible && (!row || eligible.job.queuedSequence < row.queuedSequence)) {
          return {
            context: eligible.context,
            job: { ...contextValue(eligible.job), state: "running" }
          };
        }
        if (!row)
          return null;
        const { queuedSequence: _sequence, ...fields } = row;
        if (!this.targets.isAvailable(targetFrom(fields))) {
          this.discard(row.jobId, `${row.targetKind}_unavailable`);
          continue;
        }
        this.store.catalog.prepare("UPDATE jobs SET state='running' WHERE jobId=?").run(row.jobId);
        return { job: { ...toJob(fields), state: "running" } };
      }
    });
    if (claimed?.context)
      Object.assign(claimed.context.jobs.get(claimed.job.jobId), { state: "running" });
    return claimed;
  }
  run(job) {
    this.startAttempt(job, { target: job.target }, (signal) => this.execute({ job, signal }), (outcome2) => this.settle(job, outcome2));
  }
  runContext(context, job) {
    this.startAttempt(job, { context }, (signal) => context.execute({ job, signal }), (outcome2) => {
      const current = context.jobs.get(job.jobId);
      if (context.closed || !current || current.attemptId !== job.attemptId || current.state !== "running")
        return;
      if ("result" in outcome2 && Buffer.byteLength(outcome2.result) > contextValueBytes)
        outcome2 = {
          error: new CatalogError("LIMIT_EXCEEDED", "Package job result exceeds metadata limit")
        };
      if ("result" in outcome2)
        Object.assign(current, {
          state: "ready",
          reason: null,
          errorCode: null,
          errorDetails: null,
          result: outcome2.result
        });
      else
        Object.assign(current, failure(outcome2.error));
    });
  }
  startAttempt(job, owner, execute, settle) {
    const controller = new AbortController;
    let staged;
    const done = Promise.resolve().then(() => execute(controller.signal)).then((value) => {
      if (typeof value !== "string")
        staged = value;
      try {
        settle(typeof value === "string" ? { result: value } : value);
      } catch (error) {
        settle({ error });
      }
    }, (error) => settle({ error })).finally(async () => {
      try {
        await staged?.close();
      } finally {
        this.attempts.delete(job.attemptId);
        if ("target" in owner)
          this.store.transaction(() => this.releaseFinishedInputs(job.jobId));
      }
    });
    this.attempts.set(job.attemptId, {
      ...owner,
      jobId: job.jobId,
      lane: job.lane,
      artifact: job.artifact,
      controller,
      done
    });
    done.then(() => this.capacityAvailable(), () => this.capacityAvailable());
  }
  capacityAvailable() {
    if (this.admitting)
      this.scheduleAdmission();
    else
      this.resumeAdmission();
    this.runQueued();
    if (!this.closed)
      this.onCapacity?.();
  }
  settle(job, outcome2) {
    this.store.transaction(() => {
      const current = this.store.catalog.prepare(`SELECT ${jobColumns} FROM jobs WHERE jobId=?`).get(job.jobId);
      if (!current || current.attemptId !== job.attemptId || current.state !== "running")
        return;
      if (!this.targets.isAvailable(job.target)) {
        this.discard(job.jobId, `${job.target.kind}_unavailable`);
        return;
      }
      if ("error" in outcome2) {
        let error = outcome2.error;
        if (error instanceof JobDependencyLost) {
          const row = this.store.catalog.prepare("SELECT deferred,readmitted FROM jobs WHERE jobId=?").get(job.jobId);
          if (row.deferred && !row.readmitted) {
            try {
              this.requeue(toJob(current), true);
              return;
            } catch (admission) {
              error = admission;
            }
          }
        }
        this.fail(job.jobId, error, job.attemptId);
        return;
      }
      this.publication(job);
      outcome2.publish?.();
      this.store.catalog.prepare(`INSERT INTO artifacts(targetKind,targetId,revisionId,artifact,generation,input,attemptId,result,inputSha256)
           VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(targetKind,targetId,revisionId,artifact,inputSha256) DO UPDATE SET
           generation=excluded.generation,attemptId=excluded.attemptId,result=excluded.result`).run(...targetValues(job.target), job.artifact, job.generation, job.input, job.attemptId, outcome2.result, inputDigest(job.input));
      this.store.catalog.prepare("UPDATE jobs SET state='ready',reason=NULL,errorCode=NULL,errorDetails=NULL,retryable=0 WHERE jobId=?").run(job.jobId);
      this.releaseFinishedInputs(job.jobId, job.attemptId);
    });
  }
}

// packages/core/src/cache.ts
var filename = /^[0-9a-f-]{36}\.cache$/;
var missing = (error) => error.code === "ENOENT";

class DerivedCache {
  store;
  assertAvailable;
  budget;
  root;
  ready = false;
  publication = Promise.resolve();
  reconciling;
  held = new Map;
  directories = [];
  constructor(store, home, assertAvailable, budget = 4 * 1024 ** 3) {
    this.store = store;
    this.assertAvailable = assertAvailable;
    this.budget = budget;
    if (!Number.isSafeInteger(budget) || budget < 1)
      throw new RangeError("Invalid cache budget");
    const base = realpathSync(home);
    let path = base;
    for (const name of ["cache", "derived"]) {
      path = join2(path, name);
      try {
        mkdirSync(path);
      } catch (error) {
        if (error.code !== "EEXIST")
          throw error;
      }
      const stat = lstatSync(path, { bigint: true });
      if (!stat.isDirectory())
        throw new CatalogError("INVALID_CACHE", "Cache directory must not be a link");
      this.directories.push({ path, dev: stat.dev, ino: stat.ino });
    }
    this.root = path;
    store.catalog.exec(`CREATE TABLE IF NOT EXISTS derived_cache (
      id TEXT PRIMARY KEY, ownerKind TEXT NOT NULL, ownerId TEXT NOT NULL, bytes INTEGER, touched INTEGER NOT NULL, device INTEGER, inode INTEGER
    ); CREATE INDEX IF NOT EXISTS derived_cache_lru ON derived_cache(touched,id);
    CREATE INDEX IF NOT EXISTS derived_cache_owner ON derived_cache(ownerKind,ownerId,id);`);
  }
  checkCapacity(minimumBytes) {
    if (!Number.isSafeInteger(minimumBytes) || minimumBytes < 0)
      throw new RangeError("Invalid derivative size");
    if (minimumBytes > this.budget)
      throw new CatalogError("LIMIT_EXCEEDED", "Derivative exceeds cache budget");
  }
  get bytes() {
    return this.store.catalog.prepare("SELECT COALESCE(SUM(bytes),0) AS bytes FROM derived_cache").get().bytes;
  }
  checkRoot() {
    for (const directory of this.directories) {
      const stat = lstatSync(directory.path, { bigint: true });
      if (!stat.isDirectory() || stat.dev !== directory.dev || stat.ino !== directory.ino)
        throw new CatalogError("INVALID_CACHE", "Cache directory changed while in use");
    }
  }
  path(id) {
    if (!filename.test(`${id}.cache`))
      throw new CatalogError("INVALID_CACHE", "Invalid cache identity");
    return join2(this.root, `${id}.cache`);
  }
  *usageFiles(owner) {
    this.checkRoot();
    let after = "";
    for (;; ) {
      const rows = this.store.catalog.prepare("SELECT id FROM derived_cache WHERE ownerKind=? AND ownerId=? AND id>? ORDER BY id LIMIT 100").all(...ownerIdentity(owner), after);
      if (!rows.length)
        return;
      for (const row of rows) {
        this.checkRoot();
        yield this.path(row.id);
      }
      after = rows.at(-1).id;
    }
  }
  ownerForFile(path) {
    if (dirname(path) !== this.root || !filename.test(basename(path)))
      return null;
    this.checkRoot();
    const row = this.row(basename(path).slice(0, -".cache".length));
    return row ? ownerFromIdentity(row.ownerKind, row.ownerId) : null;
  }
  row(id) {
    return this.store.catalog.prepare("SELECT * FROM derived_cache WHERE id=?").get(id);
  }
  tick() {
    return this.store.catalog.prepare("SELECT COALESCE(MAX(touched),0)+1 AS value FROM derived_cache").get().value;
  }
  requireReady() {
    if (!this.ready)
      throw new CatalogError("NOT_READY", "Cache reconciliation is pending", {}, true);
  }
  reserve(owner) {
    this.requireReady();
    this.checkRoot();
    this.assertAvailable(owner);
    const id = randomUUID();
    this.store.catalog.prepare("INSERT INTO derived_cache(id,ownerKind,ownerId,touched) VALUES (?,?,?,?)").run(id, ...ownerIdentity(owner), this.tick());
    return { id, path: this.path(id) };
  }
  publish(id) {
    const result = this.publication.then(() => this.admit(id));
    this.publication = result.catch(() => {});
    return result;
  }
  async admit(id) {
    this.requireReady();
    this.checkRoot();
    const row = this.row(id);
    if (!row)
      throw new CatalogError("INVALID_CACHE", "No cache reservation exists");
    const path = this.path(id);
    let fd;
    try {
      this.assertAvailable(ownerFromIdentity(row.ownerKind, row.ownerId));
      if (row.bytes !== null)
        return { id, path, bytes: row.bytes };
      fd = openSync2(path, constants2.O_RDONLY | constants2.O_NOFOLLOW | constants2.O_NONBLOCK);
      const stat = fstatSync2(fd);
      if (!stat.isFile() || stat.nlink !== 1)
        throw new CatalogError("INVALID_CACHE", "Derivative must be an independent regular file");
      this.checkCapacity(stat.size);
      await this.makeRoom(stat.size);
      if (!this.row(id))
        throw new CatalogError("INVALID_CACHE", "Cache reservation was removed");
      this.assertAvailable(ownerFromIdentity(row.ownerKind, row.ownerId));
      this.store.catalog.prepare("UPDATE derived_cache SET bytes=?,device=?,inode=?,touched=? WHERE id=?").run(stat.size, stat.dev, stat.ino, this.tick(), id);
      return { id, path, bytes: stat.size };
    } catch (error) {
      this.removeFile(id);
      throw error;
    } finally {
      if (fd !== undefined)
        closeSync2(fd);
    }
  }
  acquire(id) {
    this.requireReady();
    return this.open(id, true)?.read ?? null;
  }
  async withDescriptor(id, consume) {
    this.requireReady();
    const opened = this.open(id, true);
    if (!opened)
      throw new CatalogError("ARTIFACT_EXPIRED", "Derivative is no longer available", {}, true);
    try {
      return await consume({ fd: opened.file.fd, bytes: opened.read.bytes });
    } finally {
      opened.read.release();
    }
  }
  open(id, touch) {
    this.checkRoot();
    const row = this.row(id);
    if (!row || row.bytes === null)
      return null;
    if (touch)
      this.assertAvailable(ownerFromIdentity(row.ownerKind, row.ownerId));
    let fd;
    try {
      fd = openSync2(this.path(id), constants2.O_RDONLY | constants2.O_NOFOLLOW | constants2.O_NONBLOCK);
    } catch (error) {
      if (missing(error) || error.code === "ELOOP") {
        this.removeFile(id);
        return null;
      }
      throw error;
    }
    const stat = fstatSync2(fd);
    if (!stat.isFile() || stat.nlink !== 1 || stat.size !== row.bytes || stat.dev !== row.device || stat.ino !== row.inode) {
      closeSync2(fd);
      this.removeFile(id);
      return null;
    }
    if (touch)
      this.store.catalog.prepare("UPDATE derived_cache SET touched=? WHERE id=?").run(this.tick(), id);
    this.held.set(id, (this.held.get(id) ?? 0) + 1);
    const file = openedFile(fd, () => {
      const count = this.held.get(id) - 1;
      if (count)
        this.held.set(id, count);
      else
        this.held.delete(id);
    });
    return { file, read: retainedFileRead(file, row.bytes) };
  }
  remove(id) {
    this.requireReady();
    this.removeFile(id);
  }
  purgeOwner(owner, removeFiles) {
    const result = this.publication.then(async () => {
      this.requireReady();
      for (;; ) {
        const rows = this.store.catalog.prepare("SELECT id FROM derived_cache WHERE ownerKind=? AND ownerId=? ORDER BY id LIMIT 64").all(...ownerIdentity(owner));
        if (!rows.length)
          return;
        this.checkRoot();
        for (const row of rows)
          if (this.held.has(row.id))
            throw new CatalogError("CACHE_BUSY", "Derivative is being read", {}, true);
        const root = this.directories.at(-1);
        await removeFiles({
          ids: rows.map((row) => row.id),
          root: { dev: root.dev.toString(), ino: root.ino.toString() }
        });
        this.store.transaction(() => {
          for (const row of rows)
            this.store.catalog.prepare("DELETE FROM derived_cache WHERE id=? AND ownerKind=? AND ownerId=?").run(row.id, ...ownerIdentity(owner));
        });
        await setImmediate2();
      }
    });
    this.publication = result.catch(() => {});
    return result;
  }
  removeFile(id) {
    this.checkRoot();
    if (this.held.has(id))
      throw new CatalogError("CACHE_BUSY", "Derivative is being read", {}, true);
    if (!this.row(id))
      return;
    try {
      unlinkSync(this.path(id));
    } catch (error) {
      if (!missing(error))
        throw error;
    }
    this.store.catalog.prepare("DELETE FROM derived_cache WHERE id=?").run(id);
  }
  async makeRoom(extra) {
    let touched = -1, id = "";
    let work = 0;
    let bytes = this.bytes;
    const cutoff = this.tick();
    while (bytes + extra > this.budget) {
      const row = this.store.catalog.prepare(`SELECT * FROM derived_cache WHERE bytes IS NOT NULL
        AND touched<? AND (touched>? OR (touched=? AND id>?)) ORDER BY touched,id LIMIT 1`).get(cutoff, touched, touched, id);
      if (!row)
        throw new CatalogError("CACHE_BUSY", "Cache budget is held by active readers", {}, true);
      touched = row.touched;
      id = row.id;
      if (!this.held.has(id)) {
        this.removeFile(id);
        bytes -= row.bytes;
      }
      if (++work % 64 === 0) {
        await setImmediate2();
        bytes = this.bytes;
      }
    }
  }
  reconcile(signal) {
    if (this.ready)
      return Promise.resolve();
    if (this.reconciling)
      return this.reconciling;
    this.reconciling = this.scan(signal).finally(() => {
      this.reconciling = undefined;
    });
    return this.reconciling;
  }
  async scan(signal) {
    let work = 0;
    const checkpoint = async () => {
      signal?.throwIfAborted();
      if (++work % 64 === 0)
        await setImmediate2(undefined, { signal });
    };
    let after = "";
    for (;; ) {
      await checkpoint();
      const row = this.store.catalog.prepare("SELECT * FROM derived_cache WHERE id>? ORDER BY id LIMIT 1").get(after);
      if (!row)
        break;
      after = row.id;
      if (row.bytes === null)
        this.removeFile(row.id);
      else
        this.open(row.id, false)?.read.release();
    }
    this.checkRoot();
    const directory = opendirSync(this.root);
    try {
      for (let entry = directory.readSync();entry; entry = directory.readSync()) {
        await checkpoint();
        this.checkRoot();
        if (filename.test(entry.name) && !this.row(entry.name.slice(0, -6)))
          unlinkSync(join2(this.root, entry.name));
      }
    } finally {
      directory.closeSync();
    }
    let bytes = this.bytes;
    while (bytes > this.budget) {
      await checkpoint();
      const row = this.store.catalog.prepare("SELECT * FROM derived_cache WHERE bytes IS NOT NULL ORDER BY touched,id LIMIT 1").get();
      this.removeFile(row.id);
      bytes -= row.bytes;
    }
    signal?.throwIfAborted();
    this.ready = true;
  }
}

// packages/core/src/retained-image.ts
import { constants as constants3, fstatSync as fstatSync3, openSync as openSync3, readSync as readSync2 } from "node:fs";
function invalid(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function openRetainedImage(input, frame, expected) {
  const file = typeof input === "string" ? openedFile(openSync3(input, constants3.O_RDONLY | constants3.O_NOFOLLOW | constants3.O_NONBLOCK)) : input;
  const fd = file.fd;
  try {
    const stat = fstatSync3(fd);
    if (!stat.isFile() || stat.nlink !== 1 || stat.size !== frame.bytes || stat.size < 33 || stat.size > 32 * 1024 * 1024 || frame.mediaType !== "image/png")
      invalid("Invalid retained PNG file or byte receipt");
    if (expected && (stat.dev !== expected.device || stat.ino !== expected.inode || stat.mtimeMs !== expected.modified))
      invalid("Retained image changed after admission");
    const header = Buffer.alloc(24);
    readSync2(fd, header, 0, 24, 0);
    if (!header.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) || header.toString("ascii", 12, 16) !== "IHDR" || header.readUInt32BE(16) !== frame.width || header.readUInt32BE(20) !== frame.height)
      invalid("Retained PNG does not match dimensions");
    return { file, stat };
  } catch (error) {
    file.close();
    throw error;
  }
}

// packages/core/src/screenshot-index-read.ts
var integer = (n) => Number.isSafeInteger(n) && n >= 0;
function limitValue(limit = 50) {
  if (!integer(limit) || limit < 1 || limit > 200)
    throw new CatalogError("INVALID_PARAMS", "Index page limit must be 1...200");
  return limit;
}
function invalid2(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}

class ScreenshotIndexReader {
  metadata(identity2) {
    return this.readMetadata(identity2);
  }
  readEntry(identity2, ordinal) {
    if (!integer(ordinal))
      throw new CatalogError("INVALID_PARAMS", "Index ordinal must be a nonnegative integer");
    const row = this.entryRows(identity2, { after: ordinal - 1, through: ordinal, limit: 1 })[0];
    if (!row)
      throw new CatalogError("NOT_FOUND", "Selected index frame does not exist");
    return row;
  }
  page({
    identity: identity2,
    afterOrdinal,
    limit
  }) {
    const metadata = this.readMetadata(identity2), take = limitValue(limit);
    if (afterOrdinal !== undefined)
      this.readEntry(identity2, afterOrdinal);
    const entries = this.entryRows(identity2, { after: afterOrdinal ?? -1, limit: take + 1 });
    const more = entries.length > take;
    if (more)
      entries.pop();
    return { metadata, entries, nextOrdinal: more ? entries.at(-1).candidate.ordinal : null };
  }
  coveragePage({
    identity: identity2,
    afterSequence,
    candidateOrdinal,
    limit
  }) {
    this.readMetadata(identity2);
    const take = limitValue(limit);
    if (candidateOrdinal !== undefined)
      this.readEntry(identity2, candidateOrdinal);
    if (afterSequence !== undefined) {
      if (!integer(afterSequence))
        invalid2("Invalid coverage continuation");
      const anchor = this.coverageRows(identity2, {
        after: afterSequence - 1,
        through: afterSequence,
        limit: 1
      })[0];
      if (!anchor || candidateOrdinal !== undefined && anchor.ordinal !== candidateOrdinal)
        invalid2("Coverage continuation is outside this query");
    }
    const coverage = this.coverageRows(identity2, {
      after: afterSequence ?? -1,
      ...candidateOrdinal === undefined ? {} : { ordinal: candidateOrdinal },
      limit: take + 1
    });
    const more = coverage.length > take;
    if (more)
      coverage.pop();
    return { coverage, nextSequence: more ? coverage.at(-1).sequence : null };
  }
}

// packages/core/src/screenshot-index.ts
import { createHash as createHash3 } from "node:crypto";
import { fstatSync as fstatSync4, lstatSync as lstatSync2, mkdirSync as mkdirSync2, realpathSync as realpathSync2, rmdirSync, unlinkSync as unlinkSync2 } from "node:fs";
import { join as join3, dirname as dirname2 } from "node:path";
import { open as open2 } from "node:fs/promises";
import { constants as constants4 } from "node:fs";
import { setImmediate as setImmediate3 } from "node:timers/promises";
import { isDeepStrictEqual as isDeepStrictEqual2 } from "node:util";
var selectionPolicy = Object.freeze({
  id: "sampled-evidence-selection-v2",
  coverageUs: 5000000,
  ordinarySpacingUs: 1e6,
  idleUs: 300000,
  continuousUs: 2000000,
  motionToleranceFraction: 0.001,
  burstDistanceFraction: 0.01,
  maximumPendingCandidates: 5000
});
function indexGenerationResource(owner, generation) {
  return JSON.stringify([...ownerIdentity(owner), generation]);
}
var where = "ownerKind=? AND ownerId=? AND generation=?";
var integer2 = (n) => Number.isSafeInteger(n) && n >= 0;
function invalid3(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function metadata(row) {
  return {
    ...JSON.parse(row.identity),
    durationUs: row.durationUs,
    candidateCount: row.candidateCount,
    coverageCount: row.coverageCount,
    bytes: row.bytes
  };
}
function encodeIndexRecord(value) {
  const text = JSON.stringify(value), observed = Buffer.byteLength(text), maximum = 262144;
  if (observed > maximum)
    throw new CatalogError("LIMIT_EXCEEDED", "Index row exceeds storage budget", {
      limitKind: "index-record-bytes",
      maximum,
      observed
    });
  return text;
}
function missing2(error) {
  return error.code === "ENOENT";
}

class ScreenshotIndexStore extends ScreenshotIndexReader {
  store;
  domain;
  home;
  device;
  references;
  async recoverPending(ownerKind, signal) {
    let cursor = 0;
    const failures = [];
    for (;; ) {
      signal.throwIfAborted();
      const rows = this.store.catalog.prepare("SELECT rowid AS cursor,identity FROM screenshot_index_generations WHERE ownerKind=? AND state!='complete' AND rowid>? ORDER BY rowid LIMIT 100").all(ownerKind, cursor);
      for (const row of rows) {
        signal.throwIfAborted();
        try {
          await this.remove(JSON.parse(row.identity));
        } catch (error) {
          if (!failures.length)
            failures.push(error);
        }
        cursor = row.cursor;
      }
      if (rows.length < 100)
        break;
      await setImmediate3();
    }
    if (failures.length)
      throw new AggregateError(failures, "Pending screenshot index recovery failed");
  }
  portableGenerations(owner, limit = 25000, revisionIds) {
    const rows = this.store.catalog.prepare("SELECT * FROM screenshot_index_generations WHERE ownerKind=? AND ownerId=? AND (? IS NULL OR json_extract(identity, '$.revisionId') IN (SELECT value FROM json_each(?))) ORDER BY generation LIMIT ?").all(...ownerIdentity(owner), revisionIds ? JSON.stringify(revisionIds) : null, revisionIds ? JSON.stringify(revisionIds) : null, limit + 1);
    if (rows.length > limit)
      throw new CatalogError("LIMIT_EXCEEDED", "Retained index inventory exceeds its limit");
    if (rows.some((row) => row.state !== "complete"))
      throw new CatalogError("PROCESSING_BUSY", "Screenshot index generation is incomplete", {}, true);
    return rows.map((row) => metadata(row));
  }
  portableImage(identity2, ordinal) {
    const row = this.row(identity2, "complete"), entry = this.entry(identity2, ordinal);
    const directory = this.checkedDirectory(identity2, row);
    const file = this.openImage(directory, row, entry).file;
    try {
      return {
        path: join3(directory, `${ordinal}.png`),
        bytes: entry.bytes,
        identity: fileIdentity(fstatSync4(file.fd, { bigint: true }))
      };
    } finally {
      file.close();
    }
  }
  constructor(store, home, domain) {
    super();
    this.store = store;
    this.domain = domain;
    this.references = new ResourceReferences(store);
    this.home = realpathSync2(home);
    this.device = lstatSync2(this.home).dev;
    store.catalog.exec(`CREATE TABLE IF NOT EXISTS screenshot_index_generations (
    ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,generation TEXT NOT NULL,identity TEXT NOT NULL,state TEXT NOT NULL,
    durationUs INTEGER NOT NULL,candidateCount INTEGER NOT NULL DEFAULT 0,coverageCount INTEGER NOT NULL DEFAULT 0,
    bytes INTEGER NOT NULL DEFAULT 0,throughUs INTEGER NOT NULL DEFAULT 0,device INTEGER,inode INTEGER,
    PRIMARY KEY(ownerKind,ownerId,generation)
  ) STRICT;
  CREATE TABLE IF NOT EXISTS screenshot_index_entries (
    ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,generation TEXT NOT NULL,ordinal INTEGER NOT NULL,candidate TEXT NOT NULL,frame TEXT NOT NULL,
    bytes INTEGER NOT NULL,device INTEGER NOT NULL,inode INTEGER NOT NULL,modified REAL NOT NULL,coverageCount INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(ownerKind,ownerId,generation,ordinal)
  ) STRICT;
  CREATE TABLE IF NOT EXISTS screenshot_index_coverage (
    ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,generation TEXT NOT NULL,sequence INTEGER NOT NULL,ordinal INTEGER,content TEXT NOT NULL,
    PRIMARY KEY(ownerKind,ownerId,generation,sequence)
  ) STRICT;
  CREATE INDEX IF NOT EXISTS screenshot_index_coverage_candidate ON screenshot_index_coverage(ownerKind,ownerId,generation,ordinal,sequence);`);
  }
  key(identity2) {
    return [...ownerIdentity(this.domain.owner(identity2)), identity2.generation];
  }
  row(identity2, state) {
    const row = this.store.catalog.prepare(`SELECT * FROM screenshot_index_generations WHERE ${where}`).get(...this.key(identity2));
    if (!row || !isDeepStrictEqual2(JSON.parse(row.identity), this.domain.pin(identity2)))
      invalid3("Index identity does not match retained generation");
    if (state && row.state !== state)
      invalid3(state === "complete" ? "Index generation is not complete" : "Index generation is not writable");
    return row;
  }
  directory(identity2, create = false, exclusive = false) {
    const owner = this.domain.owner(identity2), [kind, id] = ownerIdentity(owner);
    if (!/^[a-zA-Z0-9_-]+$/.test(id) || !identity2.generation)
      invalid3("Invalid index identity");
    const home = lstatSync2(this.home);
    if (!home.isDirectory() || home.dev !== this.device)
      invalid3("Retained index home changed");
    let path = this.home;
    const parts = [
      "evidence",
      "index",
      kind,
      id,
      createHash3("sha256").update(identity2.generation).digest("hex")
    ];
    for (const [partIndex, segment] of parts.entries()) {
      path = join3(path, segment);
      if (create) {
        try {
          mkdirSync2(path);
        } catch (error) {
          if (error.code !== "EEXIST" || exclusive && partIndex === parts.length - 1)
            throw error;
        }
      }
      const stat = lstatSync2(path);
      if (!stat.isDirectory())
        invalid3("Retained index directory must not be a link");
      if (stat.dev !== this.device)
        invalid3("Retained index must stay on the library filesystem");
    }
    return path;
  }
  checkedDirectory(identity2, row) {
    const path = this.directory(identity2);
    const stat = lstatSync2(path);
    if (stat.ino !== row.inode)
      invalid3("Retained index directory changed");
    return path;
  }
  openImage(directory, row, entry) {
    if (entry.device !== row.device)
      invalid3("Retained image belongs to another filesystem");
    return openRetainedImage(join3(directory, `${entry.ordinal}.png`), JSON.parse(entry.frame), {
      device: this.device,
      inode: entry.inode,
      modified: entry.modified
    });
  }
  async stagePortable(expected, records, signal, validation) {
    for (const count of [
      expected.durationUs,
      expected.candidateCount,
      expected.coverageCount,
      expected.bytes
    ])
      if (!integer2(count))
        throw new CatalogError("INVALID_PACKAGE", "Invalid retained index counts");
    if (expected.candidateCount > 25000 || expected.coverageCount > 25000)
      throw new CatalogError("LIMIT_EXCEEDED", "Retained index exceeds package row budget");
    const identity2 = this.domain.pin(expected), key = this.key(identity2);
    const prior = this.store.catalog.prepare(`SELECT * FROM screenshot_index_generations WHERE ${where}`).get(...key);
    if (prior && (prior.state !== "complete" || !isDeepStrictEqual2(metadata(prior), expected)))
      throw new CatalogError("INVALID_PACKAGE", "Retained index identity conflicts with local generation");
    let owned = false;
    const close = async () => {
      if (!owned)
        return;
      const row = this.store.catalog.prepare(`SELECT state FROM screenshot_index_generations WHERE ${where}`).get(...key);
      if (row?.state !== "complete")
        await this.remove(identity2);
    };
    try {
      if (!prior) {
        this.store.catalog.prepare("INSERT INTO screenshot_index_generations(ownerKind,ownerId,generation,identity,state,durationUs) VALUES(?,?,?,?,'staging',?)").run(...key, encodeIndexRecord(identity2), expected.durationUs);
        try {
          const path = this.directory(identity2, true, true), stat = lstatSync2(path);
          owned = true;
          this.store.catalog.prepare(`UPDATE screenshot_index_generations SET device=?,inode=? WHERE ${where}`).run(stat.dev, stat.ino, ...key);
        } catch (error) {
          if (!owned)
            this.store.catalog.prepare(`DELETE FROM screenshot_index_generations WHERE ${where}`).run(...key);
          throw error;
        }
      }
      let candidates = 0, coverageCount = 0, bytes = 0;
      for await (const record of records) {
        signal.throwIfAborted();
        const row = this.row(identity2, prior ? "complete" : "staging");
        if (record.kind === "entry") {
          if (coverageCount || record.candidate.ordinal !== candidates || candidates >= expected.candidateCount || record.frame.file !== `${candidates}.png` || !/^[a-f0-9]{64}$/.test(record.sha256))
            throw new CatalogError("INVALID_PACKAGE", "Retained index entry ordering or file identity is invalid");
          const path = join3(this.checkedDirectory(identity2, row), `${candidates}.png`), frame = { ...record.frame, file: path };
          if (prior) {
            const old = this.entry(identity2, candidates);
            if (!isDeepStrictEqual2(JSON.parse(old.candidate), record.candidate) || !isDeepStrictEqual2(JSON.parse(old.frame), frame))
              throw new CatalogError("INVALID_PACKAGE", "Retained index entry conflicts with local evidence");
            const file = await open2(path, constants4.O_RDONLY | constants4.O_NOFOLLOW);
            try {
              if ((await hashFile(file, frame.bytes, signal)).sha256 !== record.sha256)
                throw new CatalogError("INVALID_PACKAGE", "Retained index PNG conflicts with local bytes");
            } finally {
              await file.close();
            }
          } else {
            const copied = await copyImportedFile(record.source.path, path, signal, record.source, 32 * 1024 * 1024);
            if (copied.bytes !== frame.bytes || copied.sha256 !== record.sha256)
              throw new CatalogError("INVALID_PACKAGE", "Retained index PNG differs from inventory");
            const retained = openRetainedImage(path, frame), stat = retained.stat;
            retained.file.close();
            this.store.catalog.prepare("INSERT INTO screenshot_index_entries VALUES(?,?,?,?,?,?,?,?,?,?,0)").run(...key, candidates, encodeIndexRecord(record.candidate), encodeIndexRecord(frame), stat.size, stat.dev, stat.ino, stat.mtimeMs);
            this.store.catalog.prepare(`UPDATE screenshot_index_generations SET candidateCount=candidateCount+1,bytes=bytes+? WHERE ${where}`).run(stat.size, ...key);
          }
          candidates++;
          bytes += frame.bytes;
        } else {
          const coverage = record.coverage;
          if (candidates !== expected.candidateCount || coverageCount >= expected.coverageCount || coverage.ordinal !== null && (!integer2(coverage.ordinal) || coverage.ordinal >= candidates))
            throw new CatalogError("INVALID_PACKAGE", "Retained index coverage ordering is invalid");
          if (prior) {
            const old = this.store.catalog.prepare(`SELECT content FROM screenshot_index_coverage WHERE ${where} AND sequence=?`).get(...key, coverageCount);
            if (!old || !isDeepStrictEqual2(JSON.parse(old.content), coverage))
              throw new CatalogError("INVALID_PACKAGE", "Retained index coverage conflicts with local evidence");
          } else {
            this.store.catalog.prepare("INSERT INTO screenshot_index_coverage VALUES(?,?,?,?,?,?)").run(...key, coverageCount, coverage.ordinal, encodeIndexRecord(coverage));
            this.store.catalog.prepare(`UPDATE screenshot_index_generations SET coverageCount=coverageCount+1 WHERE ${where}`).run(...key);
            this.store.catalog.prepare(`UPDATE screenshot_index_entries SET coverageCount=coverageCount+1 WHERE ${where} AND ordinal=?`).run(...key, coverage.ordinal);
          }
          coverageCount++;
        }
        await setImmediate3();
      }
      if (candidates !== expected.candidateCount || coverageCount !== expected.coverageCount || bytes !== expected.bytes)
        throw new CatalogError("INVALID_PACKAGE", "Retained index inventory differs from metadata");
      if (!prior) {
        let directory = this.directory(identity2);
        for (;; ) {
          const handle = await open2(directory, constants4.O_RDONLY | constants4.O_NOFOLLOW);
          try {
            await handle.sync();
          } finally {
            await handle.close();
          }
          if (directory === this.home)
            break;
          directory = dirname2(directory);
        }
      }
      await this.validateRetained(identity2, validation, signal);
      return {
        metadata: expected,
        close,
        publish: () => {
          signal.throwIfAborted();
          this.row(identity2, prior ? "complete" : "staging");
          if (this.domain.begin(identity2, "retained") !== expected.durationUs)
            invalid3("Retained index owner changed before publication");
          if (!prior)
            this.store.catalog.prepare(`UPDATE screenshot_index_generations SET state='complete',throughUs=durationUs WHERE ${where}`).run(...key);
        }
      };
    } catch (error) {
      await close();
      throw error;
    }
  }
  async validateRetained(identity2, domain, signal) {
    const row = this.row(identity2), directory = this.checkedDirectory(identity2, row);
    if (domain.begin(identity2, "retained") !== row.durationUs)
      invalid3("Retained index duration differs from its owner");
    const retained = domain.retained?.(identity2, signal);
    try {
      let previous = null;
      for (let ordinal = 0;ordinal < row.candidateCount; ordinal++) {
        signal.throwIfAborted();
        const entry = this.entry(identity2, ordinal), candidate = JSON.parse(entry.candidate);
        domain.candidate(identity2, candidate, JSON.parse(entry.frame), join3(directory, `${ordinal}.png`), previous);
        domain.finishEntry?.(identity2, candidate, entry.coverageCount);
        this.openImage(directory, row, entry).file.close();
        previous = candidate;
        if (ordinal % 100 === 99)
          await setImmediate3(undefined, { signal });
      }
      let through = 0;
      for (let sequence = 0;sequence < row.coverageCount; sequence++) {
        signal.throwIfAborted();
        const stored = this.store.catalog.prepare(`SELECT content FROM screenshot_index_coverage WHERE ${where} AND sequence=?`).get(...this.key(identity2), sequence);
        if (!stored)
          invalid3("Retained index coverage is missing");
        const coverage = JSON.parse(stored.content), candidate = coverage.ordinal === null ? null : JSON.parse(this.entry(identity2, coverage.ordinal).candidate), extent = domain.coverage(identity2, candidate, coverage, "retained");
        if (!integer2(extent.startUs) || !integer2(extent.endUs) || extent.startUs !== through || extent.endUs <= through || extent.endUs > row.durationUs)
          invalid3("Retained index coverage must progress contiguously inside its span");
        await retained?.coverage(coverage.ordinal === null ? undefined : JSON.parse(this.entry(identity2, coverage.ordinal).frame), coverage);
        through = extent.endUs;
        if (sequence % 100 === 99)
          await setImmediate3(undefined, { signal });
      }
      if (through !== row.durationUs)
        invalid3("Retained index coverage is incomplete");
      domain.finish(identity2, row.candidateCount);
    } finally {
      await retained?.close();
    }
  }
  begin(identity2) {
    const encoded = encodeIndexRecord(this.domain.pin(identity2));
    const durationUs = this.domain.begin(identity2, "produced");
    this.store.catalog.prepare("INSERT INTO screenshot_index_generations(ownerKind,ownerId,generation,identity,state,durationUs) VALUES(?,?,?,?,'building',?)").run(...this.key(identity2), encoded, durationUs);
    const path = this.directory(identity2, true), stat = lstatSync2(path);
    this.store.catalog.prepare(`UPDATE screenshot_index_generations SET device=?,inode=? WHERE ${where}`).run(stat.dev, stat.ino, ...this.key(identity2));
  }
  outputPath(identity2, ordinal) {
    const row = this.row(identity2, "building");
    if (!integer2(ordinal) || ordinal !== row.candidateCount)
      invalid3("Candidate ordinal must be the next append");
    return join3(this.checkedDirectory(identity2, row), `${ordinal}.png`);
  }
  entry(identity2, ordinal) {
    if (!integer2(ordinal))
      invalid3("Invalid candidate ordinal");
    const entry = this.store.catalog.prepare(`SELECT * FROM screenshot_index_entries WHERE ${where} AND ordinal=?`).get(...this.key(identity2), ordinal);
    if (!entry)
      invalid3("Unknown selected image");
    return entry;
  }
  appendCandidate(identity2, candidate, frame) {
    const encodedCandidate = encodeIndexRecord(candidate), encodedFrame = encodeIndexRecord(frame);
    const path = this.outputPath(identity2, candidate.ordinal);
    const previous = candidate.ordinal ? JSON.parse(this.entry(identity2, candidate.ordinal - 1).candidate) : null;
    this.domain.candidate(identity2, candidate, frame, path, previous);
    const { file, stat } = openRetainedImage(path, frame);
    file.close();
    this.store.transaction(() => {
      const row = this.row(identity2, "building");
      if (row.candidateCount !== candidate.ordinal)
        invalid3("Candidate append moved");
      this.store.catalog.prepare("INSERT INTO screenshot_index_entries VALUES(?,?,?,?,?,?,?,?,?,?,0)").run(...this.key(identity2), candidate.ordinal, encodedCandidate, encodedFrame, stat.size, stat.dev, stat.ino, stat.mtimeMs);
      this.store.catalog.prepare(`UPDATE screenshot_index_generations SET candidateCount=candidateCount+1,bytes=bytes+? WHERE ${where}`).run(stat.size, ...this.key(identity2));
    });
  }
  appendCoverage(identity2, coverage) {
    this.store.transaction(() => {
      const row = this.row(identity2, "building");
      const candidate = coverage.ordinal === null ? null : JSON.parse(this.entry(identity2, coverage.ordinal).candidate);
      const extent = this.domain.coverage(identity2, candidate, coverage, "produced");
      if (!integer2(extent.startUs) || !integer2(extent.endUs) || extent.startUs !== row.throughUs || extent.endUs <= extent.startUs || extent.endUs > row.durationUs)
        invalid3("Index coverage must progress contiguously inside its retained span");
      const previous = this.store.catalog.prepare(`SELECT * FROM screenshot_index_coverage WHERE ${where} ORDER BY sequence DESC LIMIT 1`).get(...this.key(identity2));
      const before = previous ? JSON.parse(previous.content) : undefined;
      const merged = before ? this.domain.merge(before, coverage) : null;
      if (previous && merged) {
        this.store.catalog.prepare(`UPDATE screenshot_index_coverage SET content=? WHERE ${where} AND sequence=?`).run(encodeIndexRecord(merged), ...this.key(identity2), previous.sequence);
      } else {
        this.store.catalog.prepare("INSERT INTO screenshot_index_coverage VALUES(?,?,?,?,?,?)").run(...this.key(identity2), row.coverageCount, coverage.ordinal, encodeIndexRecord(coverage));
        this.store.catalog.prepare(`UPDATE screenshot_index_generations SET coverageCount=coverageCount+1 WHERE ${where}`).run(...this.key(identity2));
        this.store.catalog.prepare(`UPDATE screenshot_index_entries SET coverageCount=coverageCount+1 WHERE ${where} AND ordinal=?`).run(...this.key(identity2), coverage.ordinal);
      }
      this.store.catalog.prepare(`UPDATE screenshot_index_generations SET throughUs=? WHERE ${where}`).run(extent.endUs, ...this.key(identity2));
    });
  }
  async finish(identity2, signal) {
    const row = this.row(identity2, "building");
    if (row.throughUs !== row.durationUs)
      invalid3("Index coverage is incomplete");
    signal?.throwIfAborted();
    this.store.catalog.prepare(`UPDATE screenshot_index_generations SET state='finishing' WHERE ${where}`).run(...this.key(identity2));
    for (let ordinal = 0;ordinal < row.candidateCount; ordinal += 100) {
      signal?.throwIfAborted();
      this.row(identity2, "finishing");
      const directory = this.checkedDirectory(identity2, row);
      const entries = this.store.catalog.prepare(`SELECT * FROM screenshot_index_entries WHERE ${where} AND ordinal>=? ORDER BY ordinal LIMIT 100`).all(...this.key(identity2), ordinal);
      for (const entry of entries) {
        this.domain.finishEntry?.(identity2, JSON.parse(entry.candidate), entry.coverageCount);
        const file = this.openImage(directory, row, entry);
        file.file.close();
      }
      await setImmediate3();
    }
    signal?.throwIfAborted();
    this.row(identity2, "finishing");
    this.domain.finish(identity2, row.candidateCount);
    this.store.catalog.prepare(`UPDATE screenshot_index_generations SET state='complete' WHERE ${where}`).run(...this.key(identity2));
    return metadata(this.row(identity2, "complete"));
  }
  readMetadata(identity2) {
    if (this.domain.isDeleting(this.domain.owner(identity2)))
      throw new CatalogError("NOT_FOUND", "Screenshot index owner is being deleted");
    return metadata(this.row(identity2, "complete"));
  }
  entryRows(identity2, query) {
    this.readMetadata(identity2);
    const rows = this.store.catalog.prepare(`SELECT candidate,frame,coverageCount FROM screenshot_index_entries WHERE ${where} AND ordinal>? ${query.through === undefined ? "" : "AND ordinal<=?"} ORDER BY ordinal LIMIT ?`).all(...this.key(identity2), query.after, ...query.through === undefined ? [] : [query.through], query.limit);
    return rows.map(({ candidate, frame, coverageCount }) => ({
      candidate: JSON.parse(candidate),
      frame: JSON.parse(frame),
      coverageCount
    }));
  }
  coverageRows(identity2, query) {
    const rows = this.store.catalog.prepare(`SELECT sequence,content FROM screenshot_index_coverage WHERE ${where} AND sequence>? ${query.through === undefined ? "" : "AND sequence<=?"} ${query.ordinal === undefined ? "" : "AND ordinal=?"} ORDER BY sequence LIMIT ?`).all(...this.key(identity2), query.after, ...query.through === undefined ? [] : [query.through], ...query.ordinal === undefined ? [] : [query.ordinal], query.limit);
    return rows.map(({ sequence, content }) => ({ sequence, ...JSON.parse(content) }));
  }
  openRead(identity2, ordinal) {
    const row = this.row(identity2, "complete");
    this.readEntry(identity2, ordinal);
    const entry = this.entry(identity2, ordinal);
    const { file } = this.openImage(this.checkedDirectory(identity2, row), row, entry);
    return retainedFileRead(file, entry.bytes);
  }
  async remove(identity2) {
    if (!this.store.catalog.prepare(`SELECT 1 FROM screenshot_index_generations WHERE ${where}`).get(...this.key(identity2)))
      return;
    const row = this.row(identity2);
    this.store.catalog.prepare(`UPDATE screenshot_index_generations SET state='deleting' WHERE ${where}`).run(...this.key(identity2));
    let directory;
    try {
      if (row.device === null) {
        this.directory(identity2);
        throw new CatalogError("INVALID_STORAGE", "Unadmitted screenshot index directory requires inspection");
      }
      directory = this.checkedDirectory(identity2, row);
    } catch (error) {
      if (!missing2(error))
        throw error;
    }
    for (let ordinal = 0;ordinal <= row.candidateCount; ordinal++) {
      if (directory) {
        try {
          unlinkSync2(join3(directory, `${ordinal}.png`));
        } catch (error) {
          if (!missing2(error))
            throw error;
        }
      }
      if (ordinal % 100 === 99) {
        await setImmediate3();
        if (directory)
          this.checkedDirectory(identity2, row);
      }
    }
    for (const table of ["screenshot_index_entries", "screenshot_index_coverage"]) {
      while (true) {
        const result = this.store.catalog.prepare(`DELETE FROM ${table} WHERE rowid IN (SELECT rowid FROM ${table} WHERE ${where} LIMIT 100)`).run(...this.key(identity2));
        if (Number(result.changes) < 100)
          break;
        await setImmediate3();
      }
    }
    if (directory) {
      try {
        rmdirSync(directory);
      } catch (error) {
        if (!missing2(error))
          throw error;
      }
    }
    this.store.catalog.prepare(`DELETE FROM screenshot_index_generations WHERE ${where}`).run(...this.key(identity2));
  }
  async reclaim(owner, keep, signal) {
    let cursor = 0;
    let failureCount = 0;
    let firstFailure;
    while (true) {
      signal?.throwIfAborted();
      const rows = this.store.catalog.prepare("SELECT rowid AS cursor,identity FROM screenshot_index_generations WHERE ownerKind=? AND ownerId=? AND rowid>? ORDER BY rowid LIMIT 100").all(...ownerIdentity(owner), cursor);
      for (const row of rows) {
        signal?.throwIfAborted();
        const identity2 = JSON.parse(row.identity);
        try {
          if (!keep(identity2) && !this.references.has("index-generation", indexGenerationResource(owner, identity2.generation)))
            await this.remove(identity2);
        } catch (error) {
          failureCount++;
          firstFailure ??= error;
        }
        cursor = row.cursor;
      }
      if (rows.length < 100) {
        if (failureCount)
          throw new AggregateError([firstFailure], `${failureCount} retained index generations could not be reclaimed`);
        return;
      }
      await setImmediate3();
    }
  }
}

// packages/core/src/assets.ts
import {
  signedTimeValueSchema,
  timeValueSchema,
  fromTime,
  compare
} from "@screenrec/composition";

// packages/core/src/asset-origins.ts
import { z as z4 } from "zod";

// packages/core/src/voice-types.ts
import { z as z3 } from "zod";
var voiceGenerationSchema = z3.strictObject({
  temperature: z3.number().finite().nonnegative(),
  top_k: z3.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  top_p: z3.number().finite().min(0).max(1),
  repetition_penalty: z3.number().finite().positive(),
  max_tokens: z3.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  lang_code: z3.string().min(1),
  stream: z3.literal(false)
});
var voiceSeedSchema = z3.string().regex(/^(0|[1-9][0-9]{0,19})$/).pipe(z3.string().refine((value) => BigInt(value) <= 18446744073709551615n, "Seed exceeds the unsigned 64-bit range"));
var voiceFilterModesSchema = z3.strictObject({
  sampling: z3.enum(["greedy", "categorical"]),
  firstBookTopK: z3.enum(["bypassed", "disabled", "enabled"]),
  residualTopK: z3.enum(["bypassed", "disabled", "enabled"]),
  nucleus: z3.enum(["bypassed", "disabled", "enabled"])
});
var sha256 = z3.string().regex(/^[a-f0-9]{64}$/);
var positiveCount = z3.number().int().positive().max(Number.MAX_SAFE_INTEGER);
var voiceReceiptSchema = z3.strictObject({
  file: z3.string(),
  sha256,
  sampleRate: positiveCount,
  channels: positiveCount,
  frames: positiveCount,
  durationUs: positiveCount,
  referenceSha256: sha256,
  referenceFrames: positiveCount,
  runtimeRevision: z3.string(),
  modelRevision: z3.string(),
  profileId: z3.string(),
  profileSha256: sha256,
  tokenizerIdentity: z3.record(z3.string(), sha256),
  iclSourceSha256: sha256,
  generation: voiceGenerationSchema,
  effectiveGeneration: voiceGenerationSchema,
  filterModes: voiceFilterModesSchema,
  seed: voiceSeedSchema,
  prefill: z3.strictObject({
    referenceTextTokens: positiveCount,
    targetTextTokens: positiveCount,
    referenceTextTokenSha256: sha256,
    targetTextTokenSha256: sha256,
    referenceCodes: positiveCount,
    inputTokens: positiveCount
  }),
  stopReason: z3.literal("eos"),
  generatedTokens: positiveCount,
  text: z3.string(),
  referenceText: z3.string(),
  descriptorDigest: sha256,
  runtimeDigest: sha256,
  modelDigest: sha256
});
var resolvedVoiceSettingsSchema = z3.strictObject({
  profileId: z3.string(),
  seed: voiceSeedSchema,
  requested: voiceGenerationSchema,
  effective: voiceGenerationSchema,
  filterModes: voiceFilterModesSchema
});

// packages/core/src/asset-origins.ts
import { processingTapSchema, rangeSchema, selectionRangeSchema } from "@screenrec/composition";
var integer3 = z4.int().nonnegative().max(Number.MAX_SAFE_INTEGER);
var sampleRange = z4.strictObject({ start: integer3, end: integer3 });
var id = z4.string().min(1);
var audioRenditionSchema = z4.strictObject({
  sampleRate: z4.int().min(1).max(192000),
  channels: z4.union([z4.literal(1), z4.literal(2)])
});
var audioDimensionsSchema = audioRenditionSchema.extend({ frames: integer3.positive() });
var extractionOriginSchema = z4.strictObject({
  kind: z4.literal("extraction"),
  selection: z4.discriminatedUnion("kind", [
    z4.strictObject({
      kind: z4.literal("source"),
      assetId: id,
      streamId: id,
      acquisitionId: id.optional(),
      range: selectionRangeSchema,
      sampleRange,
      supportDigest: id,
      unavailable: z4.array(selectionRangeSchema)
    }),
    z4.strictObject({
      kind: z4.literal("project"),
      projectId: id,
      revisionId: id,
      range: rangeSchema,
      sampleRange,
      tap: processingTapSchema,
      processingSha256: z4.string().regex(/^[a-f0-9]{64}$/),
      unavailable: z4.array(z4.strictObject({ clipId: id, ranges: z4.array(sampleRange) }))
    })
  ]),
  selectionImplementationId: id,
  input: audioDimensionsSchema,
  output: audioDimensionsSchema,
  conversion: z4.strictObject({
    implementationId: id,
    channelPolicy: z4.enum(["preserve", "duplicate", "equal-weight-double-rounded-float32"]),
    contextPolicy: z4.enum(["complete-selected-pcm-zero-origin", "complete-source"])
  })
});
var generatedVoiceOriginSchema = z4.strictObject({
  kind: z4.literal("voice-generation"),
  requestSha256: z4.string().regex(/^[a-f0-9]{64}$/),
  modelId: id,
  reference: z4.strictObject({
    assetId: id,
    streamId: id,
    originSha256: z4.string().regex(/^[a-f0-9]{64}$/).nullable()
  }),
  receipt: voiceReceiptSchema.omit({ file: true })
});
var assetOriginSchema = z4.union([
  z4.strictObject({
    kind: z4.enum(["import", "capture", "generated"]),
    source: z4.string().optional()
  }),
  extractionOriginSchema,
  generatedVoiceOriginSchema
]);

// packages/core/src/assets.ts
import { isDeepStrictEqual as isDeepStrictEqual3 } from "node:util";
import { randomUUID as randomUUID2 } from "node:crypto";
import { constants as constants5 } from "node:fs";
import { mkdir, open as open3, link, unlink, opendir, rm, lstat as lstat2 } from "node:fs/promises";
import { extname, isAbsolute, join as join4 } from "node:path";
import { z as z5 } from "zod";
var integer4 = z5.number().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER);
var positive = integer4.positive();
var segment = z5.object({
  startUs: signedTimeValueSchema,
  endUs: signedTimeValueSchema,
  empty: z5.boolean(),
  mediaStartUs: signedTimeValueSchema.optional(),
  mediaDurationUs: timeValueSchema.optional()
});
var stream = z5.object({
  id: z5.string().min(1),
  kind: z5.enum(["image", "video", "audio", "unsupported"]),
  codec: z5.string(),
  decodable: z5.boolean(),
  startUs: timeValueSchema.optional(),
  endUs: timeValueSchema.optional(),
  segments: z5.array(segment).max(2 * 1e5 + 1).optional(),
  width: positive.optional(),
  height: positive.optional(),
  orientedWidth: z5.number().finite().positive().optional(),
  orientedHeight: z5.number().finite().positive().optional(),
  orientedPixelBounds: z5.object({
    x: z5.number().finite(),
    y: z5.number().finite(),
    width: z5.number().finite().positive(),
    height: z5.number().finite().positive()
  }).optional(),
  transform: z5.array(z5.number().finite()).length(6).optional(),
  orientation: integer4.min(1).max(8).optional(),
  hasAlpha: z5.boolean().optional(),
  sampleRate: z5.number().positive().finite().optional(),
  channels: positive.optional(),
  channelLayoutTag: integer4.nonnegative().optional(),
  colorPrimaries: z5.string().optional(),
  transferFunction: z5.string().optional(),
  ycbcrMatrix: z5.string().optional(),
  samples: z5.object({
    count: integer4.nonnegative(),
    firstPtsUs: integer4,
    lastPtsUs: integer4,
    minDurationUs: integer4.nonnegative(),
    maxDurationUs: integer4.nonnegative()
  }).optional()
});
var mediaProbeSchema = z5.object({
  originUs: signedTimeValueSchema,
  streams: z5.array(stream).max(256),
  fontFaces: z5.array(z5.object({
    postScriptName: z5.string().min(1),
    familyName: z5.string().min(1),
    styleName: z5.string().min(1).optional()
  }).strict()).min(1).max(256).optional()
}).refine(({ originUs, streams, fontFaces }) => fontFaces ? originUs === 0 && streams.length === 0 && new Set(fontFaces.map((face) => face.postScriptName)).size === fontFaces.length : streams.length > 0, "Expected playable streams or unambiguous, non-timed font faces").refine(({ streams }) => new Set(streams.map((stream2) => stream2.id)).size === streams.length, "Expected unique stream identities");
var portableAssetSchema = z5.strictObject({
  asset: mediaProbeSchema.safeExtend({
    id: z5.string().regex(/^[a-f0-9]{64}$/),
    bytes: integer4.nonnegative(),
    createdAt: z5.string().min(1),
    fileName: z5.string().regex(/^[a-f0-9]{64}(?:\.[a-z0-9]{1,12})?$/)
  }).strict(),
  origins: z5.array(assetOriginSchema).max(1000),
  dependencies: z5.array(z5.strictObject({ kind: z5.enum(resourceKinds), id: z5.string().min(1).max(2048) })).max(25000)
});
var absent = (error) => error.code === "ENOENT";

class AssetStore {
  store;
  libraryDirectory;
  directory;
  staging;
  dependencies;
  publications = new Map;
  constructor(store, libraryDirectory) {
    this.store = store;
    this.libraryDirectory = libraryDirectory;
    this.dependencies = new ResourceReferences(store);
    this.directory = join4(libraryDirectory, "assets");
    this.staging = join4(libraryDirectory, "staging", "assets");
    store.catalog.exec(`
      CREATE TABLE IF NOT EXISTS asset_imports (
        importId TEXT PRIMARY KEY, requestId TEXT UNIQUE NOT NULL, path TEXT NOT NULL, assetId TEXT, source TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS assets (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL,
        metadata TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS asset_segments (
        assetId TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
        streamId TEXT NOT NULL, ordinal INTEGER NOT NULL CHECK(ordinal>=0), value TEXT NOT NULL,
        PRIMARY KEY(assetId,streamId,ordinal)
      ) STRICT, WITHOUT ROWID;
      CREATE TABLE IF NOT EXISTS asset_origins (
        assetId TEXT NOT NULL, provenance TEXT NOT NULL, PRIMARY KEY(assetId,provenance)
      ) STRICT;
    `);
  }
  async recover() {
    for (const directory of [
      this.libraryDirectory,
      this.directory,
      join4(this.libraryDirectory, "staging"),
      this.staging
    ]) {
      await mkdir(directory, { recursive: true, mode: 448 });
      const stat = await lstat2(directory);
      if (!stat.isDirectory() || stat.uid !== process.getuid?.() || (stat.mode & 63) !== 0)
        throw new CatalogError("INVALID_PATH", "Managed asset directories must be private directories owned by this user");
    }
    for await (const file of await opendir(this.staging))
      await rm(join4(this.staging, file.name), { recursive: true, force: true });
    for await (const entry of await opendir(this.directory)) {
      const file = entry.name;
      const row = this.store.catalog.prepare("SELECT metadata FROM assets WHERE id=?").get(file.split(".")[0]);
      if (!row || JSON.parse(row.metadata).fileName !== file)
        await rm(join4(this.directory, file), { recursive: true, force: true });
    }
  }
  async prepareImport(requestId, path) {
    if (!requestId || !isAbsolute(path))
      throw new CatalogError("INVALID_PARAMS", "Import requires a request ID and absolute local path");
    const previous = this.importReplay(requestId, path);
    if (previous)
      return { requestId, path, source: previous.source };
    const file = await open3(path, constants5.O_RDONLY | constants5.O_NONBLOCK).catch((error) => {
      throw new CatalogError(absent(error) ? "NOT_FOUND" : "INVALID_PATH", "Cannot open import source");
    });
    let source;
    try {
      const stat = await file.stat({ bigint: true });
      if (!stat.isFile() || stat.size > BigInt(Number.MAX_SAFE_INTEGER))
        throw new CatalogError("UNSUPPORTED_MEDIA", "Import source must be a regular file of supported size");
      source = { path, bytes: Number(stat.size), identity: fileIdentity(stat) };
    } finally {
      await file.close();
    }
    return { requestId, path, source };
  }
  admitImport(prepared) {
    const { requestId, path, source } = prepared;
    const existing = this.importReplay(requestId, path);
    if (existing)
      return existing;
    const importId = randomUUID2();
    this.store.catalog.prepare("INSERT INTO asset_imports VALUES(?,?,?,NULL,?)").run(importId, requestId, path, JSON.stringify(source));
    return this.intent(importId);
  }
  importReplay(requestId, path) {
    const row = this.store.catalog.prepare("SELECT importId,path FROM asset_imports WHERE requestId=?").get(requestId);
    if (!row)
      return null;
    if (row.path !== path)
      throw new CatalogError("REQUEST_CONFLICT", "Import request ID already names another path");
    return this.intent(row.importId);
  }
  intent(importId) {
    const row = this.store.catalog.prepare("SELECT * FROM asset_imports WHERE importId=?").get(importId);
    if (!row)
      throw new CatalogError("NOT_FOUND", "Import intent does not exist", { importId });
    return {
      importId: row.importId,
      requestId: row.requestId,
      path: row.path,
      assetId: row.assetId,
      source: JSON.parse(row.source)
    };
  }
  async executeImport(importId, probe, signal, owner) {
    const intent = this.intent(importId);
    if (intent.assetId) {
      const asset = this.get(intent.assetId);
      if (owner)
        this.retain(owner, [asset.id]);
      return asset;
    }
    return this.import(intent.path, { kind: "import", source: intent.path }, probe, signal, (asset) => {
      this.store.catalog.prepare("UPDATE asset_imports SET assetId=? WHERE importId=?").run(asset.id, importId);
      if (owner)
        this.retain(owner, [asset.id]);
    }, intent.source);
  }
  has(id2) {
    return Boolean(this.store.catalog.prepare("SELECT 1 FROM assets WHERE id=?").get(id2));
  }
  header(id2) {
    const row = this.store.catalog.prepare("SELECT metadata FROM assets WHERE id=?").get(id2);
    if (!row)
      throw new CatalogError("NOT_FOUND", "Asset does not exist", { assetId: id2 });
    return JSON.parse(row.metadata);
  }
  get(id2) {
    const asset = this.header(id2);
    if (!asset.streams.some((stream2) => stream2.segments !== undefined))
      return asset;
    const rows = this.store.catalog.prepare("SELECT streamId,value FROM asset_segments WHERE assetId=? ORDER BY streamId,ordinal").all(id2);
    const segments = new Map;
    for (const row of rows) {
      const streamId = row.streamId;
      const values = segments.get(streamId) ?? [];
      values.push(row.value);
      segments.set(streamId, values);
    }
    for (const stream2 of asset.streams)
      if (stream2.segments !== undefined)
        stream2.segments = (segments.get(stream2.id) ?? []).map((value) => JSON.parse(value));
    return asset;
  }
  insert(asset) {
    const header = {
      ...asset,
      streams: asset.streams.map(({ segments, ...stream2 }) => ({
        ...stream2,
        ...segments === undefined ? {} : { segments: [] }
      }))
    };
    const inserted = this.store.catalog.prepare("INSERT OR IGNORE INTO assets(id,metadata) VALUES(?,?)").run(asset.id, JSON.stringify(header));
    if (!inserted.changes)
      return;
    const row = this.store.catalog.prepare("INSERT INTO asset_segments(assetId,streamId,ordinal,value) VALUES(?,?,?,?)");
    for (const stream2 of asset.streams)
      for (const [ordinal, segment2] of (stream2.segments ?? []).entries())
        row.run(asset.id, stream2.id, ordinal, JSON.stringify(segment2));
  }
  describe(id2) {
    const asset = this.header(id2);
    const count = this.store.catalog.prepare("SELECT coalesce(max(ordinal)+1,0) AS count FROM asset_segments WHERE assetId=? AND streamId=?");
    return {
      ...asset,
      streams: asset.streams.map(({ segments: _segments, ...stream2 }) => ({
        ...stream2,
        segmentCount: count.get(id2, stream2.id).count
      }))
    };
  }
  segments(id2, streamId, input = {}) {
    const limit = input.limit ?? 250, after = input.cursor?.afterOrdinal ?? -1;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000 || !Number.isSafeInteger(after) || after < -1 || input.cursor && (input.cursor.assetId !== id2 || input.cursor.streamId !== streamId))
      throw new CatalogError("INVALID_PARAMS", "Invalid asset segment cursor or page bounds");
    const asset = this.header(id2);
    if (!asset.streams.some((stream2) => stream2.id === streamId))
      throw new CatalogError("NOT_FOUND", "Stream does not exist", { assetId: id2, streamId });
    const count = this.store.catalog.prepare("SELECT coalesce(max(ordinal)+1,0) AS count FROM asset_segments WHERE assetId=? AND streamId=?").get(id2, streamId).count;
    if (after >= count)
      throw new CatalogError("INVALID_PARAMS", "Asset segment cursor exceeds the stream");
    const rows = this.store.catalog.prepare("SELECT ordinal,value FROM asset_segments WHERE assetId=? AND streamId=? AND ordinal>? ORDER BY ordinal LIMIT ?").all(id2, streamId, after, limit + 1);
    return {
      assetId: id2,
      streamId,
      segments: rows.slice(0, limit).map((row) => ({ ordinal: row.ordinal, ...JSON.parse(row.value) })),
      nextCursor: rows.length > limit ? { assetId: id2, streamId, afterOrdinal: rows[limit - 1].ordinal } : null
    };
  }
  path(id2) {
    return join4(this.directory, this.header(id2).fileName);
  }
  list(input = {}) {
    const limit = input.limit ?? 250, after = input.afterSequence ?? 0;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000 || !Number.isSafeInteger(after) || after < 0)
      throw new CatalogError("INVALID_PARAMS", "Invalid asset page bounds");
    const rows = this.store.catalog.prepare(`SELECT sequence,id,
        json_extract(metadata,'$.bytes') AS bytes,
        json_extract(metadata,'$.createdAt') AS createdAt,
        json_extract(metadata,'$.fileName') AS fileName,
        json_array_length(metadata,'$.streams') AS streamCount,
        coalesce(json_array_length(metadata,'$.fontFaces'),0) AS fontFaceCount,
        (SELECT json_group_array(kind) FROM (
          SELECT DISTINCT json_extract(value,'$.kind') AS kind
          FROM json_each(assets.metadata,'$.streams') ORDER BY kind
        )) AS mediaKinds
        FROM assets WHERE sequence>? ORDER BY sequence LIMIT ?`).all(after, limit + 1);
    return {
      assets: rows.slice(0, limit).map(({ sequence: _sequence, mediaKinds, ...row }) => ({
        ...row,
        mediaKinds: JSON.parse(mediaKinds)
      })),
      nextCursor: rows.length > limit ? { afterSequence: rows[limit - 1].sequence } : null
    };
  }
  origins(id2, input = {}) {
    this.header(id2);
    const limit = input.limit ?? 250;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000 || input.afterProvenance !== undefined && typeof input.afterProvenance !== "string")
      throw new CatalogError("INVALID_PARAMS", "Invalid provenance page bounds");
    const rows = this.store.catalog.prepare("SELECT provenance FROM asset_origins WHERE assetId=? AND provenance>? ORDER BY provenance LIMIT ?").all(id2, input.afterProvenance ?? "", limit + 1);
    return {
      origins: rows.slice(0, limit).map((row) => JSON.parse(row.provenance)),
      nextCursor: rows.length > limit ? { afterProvenance: rows[limit - 1].provenance } : null
    };
  }
  retain(owner, ids) {
    for (const id2 of ids)
      this.header(id2);
    this.dependencies.retain("asset", owner, ids);
  }
  release(owner) {
    this.dependencies.release("asset", owner);
  }
  references(id2) {
    this.header(id2);
    return this.dependencies.owners("asset", id2);
  }
  portable(id2) {
    const origins = this.origins(id2, { limit: 1000 });
    if (origins.nextCursor)
      throw new CatalogError("LIMIT_EXCEEDED", "Asset provenance exceeds package limit");
    const dependencies = this.dependencies.dependencies({ kind: "asset", id: id2 });
    return { asset: this.get(id2), origins: origins.origins, dependencies };
  }
  async stagePortable(value, path, signal, expected) {
    const parsed = portableAssetSchema.safeParse(value);
    if (!parsed.success)
      throw new CatalogError("INVALID_PACKAGE", "Invalid portable asset metadata");
    const { asset, origins, dependencies } = parsed.data;
    if (!asset.fileName.startsWith(asset.id))
      throw new CatalogError("INVALID_PACKAGE", "Asset member identity differs from its hash");
    return this.stageFile(path, extname(asset.fileName), signal, async (copied) => {
      if (copied.sha256 !== asset.id || copied.bytes !== asset.bytes)
        throw new CatalogError("INVALID_PACKAGE", "Asset byte hash or size does not match its identity");
      return { asset, origins, dependencies };
    }, expected);
  }
  async stageFile(path, suffix, signal, describe, expected) {
    const staging = join4(this.staging, randomUUID2() + suffix);
    let asset;
    let retainedName;
    const removeStaging = async () => {
      await unlink(staging).catch((error) => {
        if (!absent(error))
          throw error;
      });
    };
    const cleanup = async () => {
      await removeStaging();
      if (!asset || !retainedName)
        return;
      const id2 = asset.id, fileName = retainedName;
      const row = this.store.catalog.prepare("SELECT metadata FROM assets WHERE id=?").get(id2);
      if (row && JSON.parse(row.metadata).fileName !== fileName)
        await unlink(join4(this.directory, fileName)).catch((error) => {
          if (!absent(error))
            throw error;
        });
    };
    const close = () => asset ? this.publishFile(asset.id, cleanup) : cleanup();
    try {
      const copied = await copyImportedFile(path, staging, signal, expected);
      const described = await describe(copied, staging);
      asset = described.asset;
      const { origins, dependencies } = described;
      const candidate = asset;
      retainedName = asset.fileName;
      const stored = this.store.catalog.prepare("SELECT metadata FROM assets WHERE id=?").get(asset.id);
      if (stored)
        retainedName = JSON.parse(stored.metadata).fileName;
      const publishedName = retainedName;
      await this.publishFile(candidate.id, async () => {
        try {
          signal.throwIfAborted();
          await link(staging, join4(this.directory, publishedName)).catch(async (error) => {
            if (error.code !== "EEXIST")
              throw error;
            const existing = await open3(join4(this.directory, publishedName), constants5.O_RDONLY | constants5.O_NOFOLLOW | constants5.O_NONBLOCK);
            try {
              const checked = await hashFile(existing, candidate.bytes, signal);
              if (checked.sha256 !== candidate.id)
                throw new CatalogError("ASSET_CONFLICT", "Existing asset file hash conflicts with immutable identity");
            } finally {
              await existing.close();
            }
          });
          const directory = await open3(this.directory, constants5.O_RDONLY);
          try {
            await directory.sync();
          } finally {
            await directory.close();
          }
        } finally {
          await removeStaging();
        }
      });
      signal.throwIfAborted();
      return {
        asset: candidate,
        path: join4(this.directory, publishedName),
        close,
        publish: ({ pinnedFile = true } = {}) => {
          signal.throwIfAborted();
          const prior = this.store.catalog.prepare("SELECT metadata FROM assets WHERE id=?").get(candidate.id);
          if (prior) {
            const existing = this.get(candidate.id);
            if (pinnedFile && existing.fileName !== publishedName)
              throw new CatalogError("STORAGE_BUSY", "Asset publication changed during staging; retry publication", {}, true);
            if (existing.bytes !== candidate.bytes || !isDeepStrictEqual3(mediaProbeSchema.parse(existing), mediaProbeSchema.parse(candidate)))
              throw new CatalogError("ASSET_CONFLICT", "Existing asset metadata conflicts with immutable identity");
          } else
            this.insert({ ...candidate, fileName: publishedName });
          for (const origin of origins)
            this.store.catalog.prepare("INSERT OR IGNORE INTO asset_origins VALUES(?,?)").run(candidate.id, JSON.stringify(origin));
          for (const kind of resourceKinds)
            this.dependencies.retain(kind, { kind: "asset", id: candidate.id }, dependencies.filter((dependency) => dependency.kind === kind).map((dependency) => dependency.id));
          return this.get(candidate.id);
        }
      };
    } catch (error) {
      await close();
      throw error;
    }
  }
  async publishFile(id2, run) {
    const result = (this.publications.get(id2) ?? Promise.resolve()).then(run);
    const settled = result.then(() => {
      return;
    }, () => {
      return;
    });
    this.publications.set(id2, settled);
    try {
      return await result;
    } finally {
      if (this.publications.get(id2) === settled)
        this.publications.delete(id2);
    }
  }
  async stage(path, provenance, probe, signal = new AbortController().signal, expected) {
    if (!isAbsolute(path))
      throw new CatalogError("INVALID_PATH", "Asset import requires an absolute local path");
    signal.throwIfAborted();
    const extension = extname(path).toLowerCase();
    const suffix = /^\.[a-z0-9]{1,12}$/.test(extension) ? extension : "";
    return this.stageFile(path, suffix, signal, async ({ sha256: id2, bytes }, staging) => {
      if (this.has(id2))
        return { asset: this.get(id2), origins: [provenance], dependencies: [] };
      const parsed = mediaProbeSchema.safeParse(await probe(staging, signal));
      if (!parsed.success)
        throw new CatalogError("INVALID_NATIVE_RESPONSE", "Media probe returned invalid metadata");
      const metadata2 = parsed.data;
      if (!metadata2.fontFaces && !metadata2.streams.some((stream2) => stream2.kind !== "unsupported" && stream2.decodable))
        throw new CatalogError("UNSUPPORTED_MEDIA", `Media contains no decodable streams: ${metadata2.streams.map((stream2) => stream2.codec).join(", ")}`, {
          streams: metadata2.streams.map(({ id: id3, kind, codec, decodable }) => ({
            id: id3,
            kind,
            codec,
            decodable
          }))
        });
      for (const item of metadata2.streams) {
        if (item.kind === "audio" || item.kind === "video") {
          if (item.startUs === undefined || item.endUs === undefined || compare(fromTime(item.endUs), fromTime(item.startUs)) <= 0 || !item.segments?.length)
            throw new CatalogError("UNSUPPORTED_MEDIA", "Timed stream has no occupied presentation interval", { streamId: item.id });
        }
      }
      return {
        asset: {
          ...metadata2,
          id: id2,
          bytes,
          createdAt: new Date().toISOString(),
          fileName: id2 + suffix
        },
        origins: [provenance],
        dependencies: []
      };
    }, expected);
  }
  async import(path, provenance, probe, signal = new AbortController().signal, published2, expected) {
    const staged = await this.stage(path, provenance, probe, signal, expected);
    try {
      return this.store.transaction(() => {
        const asset = staged.publish({ pinnedFile: false });
        published2?.(asset);
        return asset;
      });
    } finally {
      await staged.close();
    }
  }
}
function compositionAsset(asset) {
  return {
    id: asset.id,
    ...asset.fontFaces ? { fontFaces: asset.fontFaces.map((face) => face.postScriptName) } : {},
    streams: asset.streams.flatMap((stream2) => {
      if (!stream2.decodable || stream2.kind === "unsupported")
        return [];
      if (stream2.kind === "image")
        return [
          {
            id: stream2.id,
            kind: "image",
            width: stream2.orientedWidth,
            height: stream2.orientedHeight
          }
        ];
      const available = [];
      for (const segment2 of [...stream2.segments].filter((s) => !s.empty).sort((a, b) => compare(fromTime(a.startUs), fromTime(b.startUs)))) {
        const startUs = compare(fromTime(stream2.startUs), fromTime(segment2.startUs)) > 0 ? stream2.startUs : segment2.startUs, endUs = compare(fromTime(stream2.endUs), fromTime(segment2.endUs)) < 0 ? stream2.endUs : segment2.endUs;
        if (compare(fromTime(startUs), fromTime(endUs)) >= 0)
          continue;
        const last = available.at(-1);
        if (last && compare(fromTime(startUs), fromTime(last.endUs)) <= 0) {
          if (compare(fromTime(endUs), fromTime(last.endUs)) > 0)
            last.endUs = endUs;
        } else
          available.push({ startUs, endUs });
      }
      return [
        {
          id: stream2.id,
          ...stream2.kind === "video" ? {
            kind: "video",
            width: stream2.orientedWidth,
            height: stream2.orientedHeight,
            ...stream2.orientedPixelBounds ? { pixelBounds: stream2.orientedPixelBounds } : {}
          } : {
            kind: "audio",
            ...stream2.channels !== undefined ? { channels: stream2.channels } : {},
            ...stream2.sampleRate !== undefined ? { sampleRate: stream2.sampleRate } : {}
          },
          bounds: { startUs: stream2.startUs, endUs: stream2.endUs },
          available
        }
      ];
    })
  };
}

// packages/core/src/acquisitions.ts
import {
  signedTimeValueSchema as signedTimeValueSchema2,
  fromTime as fromTime2,
  toTime,
  toSignedTime,
  subtract,
  compare as compare2
} from "@screenrec/composition";

// packages/core/src/evidence-read.ts
var max = Number.MAX_SAFE_INTEGER;

// packages/core/src/evidence.ts
import { selectionRangeSchema as selectionRangeSchema2 } from "@screenrec/composition";
var maxBytes = 268435456;
function invalid4(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function integer5(value) {
  return Number.isSafeInteger(value) && value >= 0;
}
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    invalid4("Expected evidence object");
  return value;
}
function validateSourceReceipt(value, sourceId) {
  const receipt = object(value);
  const header = object(receipt.header);
  if (header.sessionID !== sourceId)
    invalid4("Evidence identity does not match its recording");
  if (typeof receipt.file !== "string" || !receipt.file || receipt.journal !== "capture.journal.jsonl" || ![
    receipt.cursorSamples,
    receipt.geometryRecords,
    receipt.displaySpaces,
    receipt.pauseEvents,
    receipt.audioIntervals,
    receipt.lastSequence
  ].every(integer5) || !integer5(receipt.bytes) || receipt.normalizationVersion !== undefined && receipt.normalizationVersion !== 2 || receipt.bytes > maxBytes || typeof receipt.incompleteTail !== "boolean" || typeof receipt.finished !== "boolean" || [
    receipt.originHostUs,
    receipt.openPauseHostUs,
    receipt.firstCursorSourceUs,
    receipt.lastCursorSourceUs,
    receipt.invalidAtSequence
  ].some((v) => v != null && !integer5(v)) || Buffer.byteLength(JSON.stringify(receipt)) > 32768)
    invalid4("Invalid evidence receipt");
  if (receipt.lastLifecycle != null) {
    const lifecycle = object(receipt.lastLifecycle);
    if (typeof lifecycle.state !== "string" || lifecycle.reason != null && typeof lifecycle.reason !== "string")
      invalid4("Invalid capture lifecycle provenance");
  }
  if (receipt.completion != null) {
    const completion = object(receipt.completion);
    if (receipt.normalizationVersion === undefined && completion.failureMessage !== undefined || !receipt.finished || !integer5(completion.sequence) || completion.sequence < 1 || completion.sequence > receipt.lastSequence || !["complete", "interrupted"].includes(completion.state) || !integer5(completion.durationUs) || completion.failureCode != null && typeof completion.failureCode !== "string" || completion.failureMessage != null && (typeof completion.failureMessage !== "string" || completion.failureMessage.length > 4096 || completion.failureCode == null) || completion.state === "complete" && (completion.failureCode != null || completion.failureMessage != null))
      invalid4("Invalid capture completion provenance");
  }
  if (receipt.publications !== undefined) {
    for (const [role, proof] of Object.entries(object(receipt.publications))) {
      if (!["video", "narration", "system"].includes(role))
        invalid4("Invalid publication role");
      if (role !== "video" && header.schemaVersion !== 2)
        invalid4("Audio publication proof requires the packed journal layout");
      const identity2 = object(proof);
      for (const kind of role === "video" ? ["canonical", "receipt", "mapping"] : ["canonical", "receipt"]) {
        const file = object(identity2[kind]);
        if (typeof file.bytes !== "string" || !/^[1-9][0-9]*$/.test(file.bytes) || BigInt(file.bytes) > BigInt(kind === "receipt" ? 65536 : kind === "mapping" ? maxBytes : Number.MAX_SAFE_INTEGER) || typeof file.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(file.sha256))
          invalid4("Invalid verified publication identity");
      }
      if (role === "video" && (!integer5(identity2.representedFrames) || identity2.representedFrames === 0 || !selectionRangeSchema2.safeParse(identity2.support).success))
        invalid4("Invalid verified camera support");
    }
  } else if (header.schemaVersion === 2)
    invalid4("Packed evidence requires verified publications");
  const camera = header.source != null && object(header.source).kind === "camera";
  if (camera || header.cameraBinding !== undefined) {
    const binding = object(header.cameraBinding);
    if (!camera || binding.sourceId !== sourceId || ![binding.recordingId, binding.sourceId, binding.deviceId].every((id2) => typeof id2 === "string" && id2.length > 0 && id2.length <= 256))
      invalid4("Invalid supplied camera binding");
    if (!object(receipt.publications ?? {}).video)
      invalid4("Declared camera requires verified camera publication");
  }
  return receipt;
}

// packages/core/src/source-admission.ts
var publicationNames = {
  narration: "narration.publication.json",
  system: "system.publication.json",
  video: "camera.publication.json"
};
var sourcePublicationMembers = [
  ...Object.values(publicationNames),
  "camera.mapping.jsonl"
];

// packages/core/src/acquisitions.ts
import { createHash as createHash4, randomUUID as randomUUID3 } from "node:crypto";
import { z as z6 } from "zod";
import { isDeepStrictEqual as isDeepStrictEqual4 } from "node:util";
import { dirname as dirname3, isAbsolute as isAbsolute2, join as join5, relative, sep } from "node:path";
import { acquisitionContextSchema } from "@screenrec/composition";
var members = [
  "capture.journal.jsonl",
  "video.mov",
  "narration.mov",
  "system.mov",
  ...sourcePublicationMembers
];
var sourceAuthorityFile = "source.publication.json";
var captureMembers = [...members, sourceAuthorityFile];
var captureRequestPrefix = "capture:";
var memberBytes = z6.number().int().nonnegative().max(268435456);
var portableAcquisitionSchema = z6.strictObject({
  id: z6.uuid().refine((value) => value === value.toLowerCase(), "Acquisition ID must be canonical"),
  sourceId: z6.string().min(1).max(256),
  generation: z6.string().regex(/^[A-Za-z0-9_-]{1,128}$/),
  receipt: z6.record(z6.string(), z6.unknown()),
  journal: z6.strictObject({ bytes: memberBytes, sha256: z6.string().regex(/^[a-f0-9]{64}$/) }),
  bindings: z6.array(acquisitionContextSchema.shape.bindings.element.extend({
    sourceRoles: z6.array(z6.enum(["video", "narration", "system"])).min(1).max(3),
    sourceToAssetOffsetUs: signedTimeValueSchema2,
    supportBasis: z6.enum(["physical", "captured-audio"])
  }).strict()).min(1).max(256)
}).transform((value) => {
  if ("file" in value.receipt)
    throw new CatalogError("INVALID_PACKAGE", "Portable acquisition receipt must not contain a local path");
  const { file: _file, ...receipt } = validateSourceReceipt({ ...value.receipt, file: "source.jsonl" }, value.sourceId);
  return { ...value, receipt };
});
function donorRecordingId(recordings, path) {
  const [recordingId, member] = relative(recordings, path).split(sep);
  return recordingId && recordingId !== ".." && member ? recordingId : null;
}
function acquisitionContext(value) {
  return {
    id: value.id,
    bindings: value.bindings.map(({ assetId, streamId, available }) => ({
      assetId,
      streamId,
      available
    }))
  };
}

class AcquisitionStore {
  catalog;
  dependencies;
  constructor(catalog) {
    this.catalog = catalog;
    this.dependencies = new ResourceReferences(catalog);
    catalog.catalog.exec(`CREATE TABLE IF NOT EXISTS acquisitions (
      id TEXT PRIMARY KEY, requestId TEXT UNIQUE NOT NULL, admission TEXT NOT NULL, metadata TEXT
    ) STRICT`);
  }
  replay(requestId, path) {
    const row = this.catalog.catalog.prepare("SELECT id,admission FROM acquisitions WHERE requestId=?").get(requestId);
    if (!row)
      return null;
    const admission = JSON.parse(row.admission);
    if (admission.kind !== "import" || admission.path !== path)
      throw new CatalogError("REQUEST_CONFLICT", "Acquisition request ID already names another input");
    return { ...admission, requestId, acquisitionId: row.id };
  }
  admitImport(prepared) {
    const replay = this.replay(prepared.requestId, prepared.path);
    if (replay)
      return replay;
    const acquisitionId = randomUUID3();
    const admission = {
      kind: "import",
      path: prepared.path,
      files: prepared.files
    };
    this.catalog.catalog.prepare("INSERT INTO acquisitions VALUES(?,?,?,NULL)").run(acquisitionId, prepared.requestId, JSON.stringify(admission));
    return { ...prepared, kind: "import", acquisitionId };
  }
  admitCapture(captures, recordingId, path, sourceId = captures.get(recordingId).sourceId) {
    if (captures.catalog !== this.catalog.catalog)
      throw new CatalogError("INVALID_STATE", "Capture admission requires the shared catalog connection");
    if (!isAbsolute2(path))
      throw new CatalogError("INVALID_PARAMS", "Capture source requires an absolute directory");
    const source = captures.publishedSource(recordingId, sourceId);
    const requestId = `${captureRequestPrefix}${sourceId}`;
    const row = this.catalog.catalog.prepare("SELECT id FROM acquisitions WHERE requestId=?").get(requestId);
    if (row) {
      const intent = this.intent(row.id);
      if (intent.kind !== "capture" || intent.recordingId !== recordingId || intent.sourceId !== sourceId || !isDeepStrictEqual4(intent.source, source) || intent.path !== path)
        throw new CatalogError("REQUEST_CONFLICT", "Capture source already names another input");
      return intent;
    }
    const acquisitionId = randomUUID3();
    const admission = {
      kind: "capture",
      recordingId,
      sourceId,
      source,
      path,
      files: {}
    };
    this.catalog.catalog.prepare("INSERT INTO acquisitions VALUES(?,?,?,NULL)").run(acquisitionId, requestId, JSON.stringify(admission));
    return { ...admission, acquisitionId, requestId };
  }
  captureIntent(sourceId) {
    const row = this.catalog.catalog.prepare("SELECT id FROM acquisitions WHERE requestId=?").get(`${captureRequestPrefix}${sourceId}`);
    if (!row)
      return null;
    const intent = this.intent(row.id);
    if (intent.kind !== "capture" || intent.sourceId !== sourceId)
      throw new CatalogError("REQUEST_CONFLICT", "Capture source request names another input");
    return intent;
  }
  pendingCaptureSources(captures) {
    if (captures.catalog !== this.catalog.catalog)
      throw new CatalogError("INVALID_STATE", "Capture admission requires the shared catalog connection");
    return this.catalog.catalog.prepare(`WITH sources AS (
        SELECT recordingId,creationSequence,sourceId,'primary' kind FROM recordings
        WHERE state!='canceled' AND json_extract(publication,'$.observation.inputsClosed')=1
          AND json_extract(publication,'$.observation.primary.state')='published'
        UNION ALL
        SELECT recordingId,creationSequence,cameraSourceId sourceId,'camera' kind FROM recordings
        WHERE state!='canceled' AND json_extract(publication,'$.observation.inputsClosed')=1
          AND json_extract(publication,'$.observation.camera.state')='published'
      ) SELECT r.recordingId,r.sourceId,r.kind FROM sources r
      LEFT JOIN acquisitions a ON a.requestId=? || r.sourceId
      WHERE a.id IS NULL AND r.recordingId NOT IN (SELECT recordingId FROM recording_deletions)
      ORDER BY r.creationSequence,r.kind LIMIT 100`).all(captureRequestPrefix);
  }
  recordingDonors(acquisitionId, recordings) {
    const intent = this.intent(acquisitionId);
    if (this.ready(acquisitionId) || intent.kind === "package")
      return [];
    if (intent.kind === "capture")
      return [intent.recordingId];
    return [
      ...new Set(Object.values(intent.files).flatMap((file) => {
        const id2 = file && donorRecordingId(recordings, file.path);
        return id2 ? [id2] : [];
      }))
    ].sort();
  }
  unfinishedRecordingImports(recordingId, recordings, afterId = "") {
    const prefix = join5(recordings, recordingId) + sep;
    return this.catalog.catalog.prepare(`SELECT id,requestId,admission FROM acquisitions WHERE metadata IS NULL AND id>?
        AND ((json_extract(admission,'$.kind')='capture' AND json_extract(admission,'$.recordingId')=?)
          OR (json_extract(admission,'$.kind')='import' AND EXISTS (
            SELECT 1 FROM json_each(admission,'$.files') member
            WHERE substr(json_extract(member.value,'$.path'),1,length(?))=?)))
        ORDER BY id LIMIT 64`).all(afterId, recordingId, prefix, prefix).map((row) => ({
      ...JSON.parse(row.admission),
      acquisitionId: row.id,
      requestId: row.requestId
    }));
  }
  freezeCaptureMember(acquisitionId, member, file) {
    this.catalog.transaction(() => {
      const intent = this.intent(acquisitionId);
      if (intent.kind !== "capture")
        throw new CatalogError("INVALID_STATE", "Deferred observation requires a capture intent");
      if (Object.hasOwn(intent.files, member) && !isDeepStrictEqual4(intent.files[member], file))
        throw new CatalogError("SOURCE_CHANGED", "Capture member differs from its frozen identity");
      const admission = {
        kind: intent.kind,
        recordingId: intent.recordingId,
        sourceId: intent.sourceId,
        source: intent.source,
        path: intent.path,
        files: intent.files
      };
      admission.files[member] = file;
      this.catalog.catalog.prepare("UPDATE acquisitions SET admission=? WHERE id=?").run(JSON.stringify(admission), acquisitionId);
    });
  }
  intent(acquisitionId) {
    const row = this.catalog.catalog.prepare("SELECT requestId,admission FROM acquisitions WHERE id=?").get(acquisitionId);
    if (!row)
      throw new CatalogError("NOT_FOUND", "Acquisition does not exist", { acquisitionId });
    return {
      ...JSON.parse(row.admission),
      acquisitionId,
      requestId: row.requestId
    };
  }
  admitPortable(acquisitionId, packageIdentity) {
    const existing = this.catalog.catalog.prepare("SELECT metadata FROM acquisitions WHERE id=?").get(acquisitionId);
    if (existing) {
      if (existing.metadata === null)
        throw new CatalogError("PROCESSING_BUSY", "Acquisition is already being prepared", {}, true);
      return { existing: JSON.parse(existing.metadata), requestId: null };
    }
    const requestId = randomUUID3();
    this.catalog.catalog.prepare("INSERT INTO acquisitions VALUES(?,?,?,NULL)").run(acquisitionId, requestId, JSON.stringify({ kind: "package", packageIdentity }));
    return { existing: null, requestId };
  }
  publish(value) {
    this.intent(value.id);
    this.catalog.catalog.prepare("UPDATE acquisitions SET metadata=? WHERE id=?").run(JSON.stringify(value), value.id);
  }
  ready(acquisitionId) {
    return Boolean(this.catalog.catalog.prepare("SELECT 1 FROM acquisitions WHERE id=? AND metadata IS NOT NULL").get(acquisitionId));
  }
  discardPortable(acquisitionId, requestId) {
    this.catalog.catalog.prepare("DELETE FROM acquisitions WHERE id=? AND requestId=? AND metadata IS NULL AND json_extract(admission,'$.kind')='package'").run(acquisitionId, requestId);
  }
  decode(acquisitionId, metadata2) {
    if (metadata2 === undefined)
      throw new CatalogError("NOT_FOUND", "Acquisition does not exist", { acquisitionId });
    if (metadata2 === null)
      throw new CatalogError("NOT_READY", "Acquisition import has not completed", {
        acquisitionId
      });
    return JSON.parse(metadata2);
  }
  get(acquisitionId) {
    const row = this.catalog.catalog.prepare("SELECT metadata FROM acquisitions WHERE id=?").get(acquisitionId);
    return this.decode(acquisitionId, row?.metadata);
  }
  read(ids) {
    const rows = this.catalog.catalog.prepare("SELECT id,metadata FROM acquisitions WHERE id IN (SELECT value FROM json_each(?))").all(JSON.stringify([...new Set(ids)]));
    const metadata2 = new Map(rows.map((row) => [row.id, row.metadata]));
    return (id2) => this.decode(id2, metadata2.get(id2));
  }
  context(acquisitionId) {
    return acquisitionContext(this.get(acquisitionId));
  }
  retain(owner, ids) {
    for (const id2 of ids)
      this.get(id2);
    this.dependencies.retain("acquisition", owner, ids);
  }
  release(owner) {
    this.dependencies.release("acquisition", owner);
  }
  references(id2) {
    this.get(id2);
    return this.dependencies.owners("acquisition", id2);
  }
}

// packages/core/src/scene-evidence.ts
import {
  signedTimeValueSchema as signedTimeValueSchema4,
  timeValueSchema as timeValueSchema3,
  toSignedTime as toSignedTime3,
  subtract as subtract4,
  ceil as ceil2
} from "@screenrec/composition";
import { z as z8 } from "zod";
import { isDeepStrictEqual as isDeepStrictEqual6 } from "node:util";

// packages/core/src/source-selection.ts
import { createHash as createHash5 } from "node:crypto";
import {
  mediaClipSchema,
  sourceAvailability,
  toSignedTime as toSignedTime2,
  subtract as subtract2,
  fromTime as fromTime3
} from "@screenrec/composition";
var sourceSelectionSchema = mediaClipSchema.pick({
  assetId: true,
  streamId: true,
  acquisitionId: true
});
function selectSource(assets, acquisitions, input) {
  const selection = sourceSelectionSchema.parse(input);
  const asset = assets.get(selection.assetId);
  const acquisition = selection.acquisitionId === undefined ? undefined : acquisitions.get(selection.acquisitionId);
  return selectSourceMetadata(asset, assets.path(asset.id), acquisition, selection);
}

class SourceSelectionRead {
  assetStore;
  assets = new Map;
  acquisitions = new Map;
  acquisition;
  constructor(assetStore, acquisitionStore, selections) {
    this.assetStore = assetStore;
    const ids = selections?.map((value) => value?.acquisitionId).filter((id2) => typeof id2 === "string");
    this.acquisition = ids?.length ? acquisitionStore.read(ids) : (id2) => acquisitionStore.get(id2);
  }
  get(input) {
    const selection = sourceSelectionSchema.parse(input);
    let metadata2 = this.assets.get(selection.assetId);
    if (!metadata2) {
      const asset = this.assetStore.get(selection.assetId);
      metadata2 = { asset: compositionAsset(asset), originUs: asset.originUs };
      this.assets.set(selection.assetId, metadata2);
    }
    let acquisition = selection.acquisitionId === undefined ? undefined : this.acquisitions.get(selection.acquisitionId);
    if (!acquisition && selection.acquisitionId !== undefined) {
      acquisition = this.acquisition(selection.acquisitionId);
      this.acquisitions.set(selection.acquisitionId, acquisition);
    }
    const selected = selectSourceSupport(metadata2.asset, acquisition, selection);
    return {
      ...selected,
      acquisition,
      track: sourceTrackSupport(metadata2.originUs, selected.available)
    };
  }
}
function selectSourceMetadata(asset, path, acquisition, input) {
  const selected = selectSourceSupport(compositionAsset(asset), acquisition, input);
  return {
    selection: selected.selection,
    stream: selected.stream,
    durationUs: selected.durationUs,
    supportDigest: selected.supportDigest,
    track: {
      source: path,
      streamId: selected.stream.id,
      ...sourceTrackSupport(asset.originUs, selected.available)
    }
  };
}
function sourceTrackSupport(originUs, available) {
  return { sourceOffsetUs: toSignedTime2(subtract2(fromTime3(0), fromTime3(originUs))), available };
}
function selectSourceSupport(asset, acquisition, input) {
  const selection = sourceSelectionSchema.parse(input);
  if (asset.id !== selection.assetId || acquisition?.id !== selection.acquisitionId)
    throw new CatalogError("INVALID_PARAMS", "Source metadata differs from selection");
  const stream2 = asset.streams.find((value) => value.id === selection.streamId);
  if (!stream2 || stream2.kind === "image")
    throw new CatalogError("UNSUPPORTED_MEDIA", "Source inspection requires a decodable timed stream", selection);
  const binding = acquisition?.bindings.find((value) => value.assetId === asset.id && value.streamId === stream2.id);
  if (acquisition && !binding)
    throw new CatalogError("INVALID_PARAMS", "Acquisition does not bind the selected asset and stream", selection);
  const available = sourceAvailability(stream2.available, binding?.available);
  const supportDigest = createHash5("sha256").update(JSON.stringify(available)).digest("hex");
  return {
    selection,
    stream: stream2,
    durationUs: stream2.bounds.endUs,
    supportDigest,
    binding,
    available
  };
}

// packages/core/src/scene-evidence.ts
import { setImmediate as setImmediate4 } from "node:timers/promises";

// packages/core/src/scenes.ts
var scenePolicy = Object.freeze({
  id: "rgb-spatial-change-v3",
  stepUs: 200000,
  maximumRangeUs: 1e7,
  changedChannelDelta: 24,
  stillnessChannelRange: 2,
  gridColumns: 8,
  gridRows: 8,
  activeCellFraction: 0.05,
  broadPixelFraction: 0.3,
  spatialPixelFraction: 0.04,
  broadCellFraction: 0.5
});
var sceneSampleLimits = Object.freeze({
  count: scenePolicy.maximumRangeUs / scenePolicy.stepUs + 2,
  spanUs: scenePolicy.maximumRangeUs + scenePolicy.stepUs
});
var integer6 = (n) => Number.isSafeInteger(n) && n >= 0;
function interval(range) {
  if (!integer6(range.startUs) || !integer6(range.endUs) || range.endUs <= range.startUs)
    throw new CatalogError("INVALID_RANGE", "Scene analysis requires a nonempty source interval");
}
function sceneSampleTimes(range, kept) {
  interval(range);
  interval(kept);
  if (range.startUs < kept.startUs || range.endUs > kept.endUs || range.endUs - range.startUs > scenePolicy.maximumRangeUs)
    throw new CatalogError("INVALID_RANGE", "Scene interval must fit the kept span and ten-second limit");
  const step = scenePolicy.stepUs;
  const first = Math.max(kept.startUs, Math.ceil(range.startUs / step) * step - step);
  const endpoint = Math.min(range.endUs, kept.endUs - 1);
  const times = [first];
  for (let at = (Math.floor(first / step) + 1) * step;at <= endpoint; at += step)
    times.push(at);
  if (times.at(-1) < endpoint)
    times.push(endpoint);
  return times;
}

// packages/core/src/source-scene-chunks.ts
import { signedTimeValueSchema as signedTimeValueSchema3, timeValueSchema as timeValueSchema2, fromTime as fromTime5, compare as compare4 } from "@screenrec/composition";
import { z as z7 } from "zod";
import { isDeepStrictEqual as isDeepStrictEqual5 } from "node:util";

// packages/core/src/source-scenes.ts
import {
  rational,
  subtract as subtract3,
  fromTime as fromTime4,
  add,
  compare as compare3,
  round,
  ceil
} from "@screenrec/composition";
var sourceScenePolicy = `${scenePolicy.id}-presentation-v1`;
function invalid5(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function stamp(clock) {
  if (!/^-?\d+$/.test(clock.value) || !/^-?\d+$/.test(clock.endValue) || !Number.isInteger(clock.timescale) || clock.timescale <= 0 || clock.timescale > 2147483647 || !Number.isInteger(clock.endTimescale) || clock.endTimescale <= 0 || clock.endTimescale > 2147483647)
    invalid5("Invalid presentation clock");
  return {
    start: BigInt(clock.value),
    scale: BigInt(clock.timescale),
    end: BigInt(clock.endValue),
    endScale: BigInt(clock.endTimescale)
  };
}
function compareSceneSampleClocks(a, b) {
  const left = BigInt(a.value) * BigInt(b.timescale), right = BigInt(b.value) * BigInt(a.timescale);
  return left < right ? -1 : left > right ? 1 : 0;
}
function sceneSampleSourceTime(sample, originUs) {
  return subtract3(rational(BigInt(sample.value) * 1000000n, BigInt(sample.timescale)), fromTime4(originUs));
}
function validateSceneSampleClock(sample, requestedSourceUs, actualSourceUs, originUs) {
  const { start, scale, end, endScale } = stamp(sample);
  const at = add(fromTime4(requestedSourceUs), fromTime4(originUs));
  if (compare3(rational(start * 1000000n, scale), at) > 0 || compare3(rational(end * 1000000n, endScale), at) <= 0 || round(sceneSampleSourceTime(sample, originUs)) !== actualSourceUs)
    invalid5("Visual sample does not contain its request");
}
function sourceSceneSampleTimes(range, durationUs) {
  const grid = sceneSampleTimes(range, { startUs: 0, endUs: ceil(fromTime4(durationUs)) });
  return [range.startUs, ...grid.filter((at) => at > range.startUs)];
}

// packages/core/src/source-scene-chunks.ts
var integer7 = z7.int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER);
var time = integer7.nonnegative();
var sourceSceneClockSchema = z7.strictObject({
  value: z7.string().regex(/^-?\d+$/).max(20),
  timescale: z7.int().positive().max(2147483647),
  endValue: z7.string().regex(/^-?\d+$/).max(20),
  endTimescale: z7.int().positive().max(2147483647)
});
var coverage = z7.discriminatedUnion("status", [
  z7.strictObject({
    requestedSourceUs: time,
    status: z7.literal("unavailable"),
    reason: z7.enum(["outside_support", "empty_edit"]),
    continuousFromPrevious: z7.literal(false)
  }),
  z7.strictObject({
    requestedSourceUs: time,
    status: z7.literal("available"),
    actualSourceUs: integer7,
    sample: sourceSceneClockSchema,
    width: time.positive().max(64),
    height: time.positive().max(64),
    continuousFromPrevious: z7.boolean(),
    stillnessRunStartUs: time
  })
]);
var comparison = z7.strictObject({
  previous: sourceSceneClockSchema,
  current: sourceSceneClockSchema,
  actualSourceUs: integer7,
  changedPixelFraction: z7.number().min(0).max(1),
  changedCellFraction: z7.number().min(0).max(1),
  meanAbsoluteChannelDifference: z7.number().min(0).max(1),
  boundary: z7.boolean()
});
var schema = z7.strictObject({
  policy: z7.literal(sourceScenePolicy),
  assetId: z7.string().min(1),
  streamId: z7.string().min(1),
  range: z7.strictObject({ startUs: time, endUs: time }),
  durationUs: timeValueSchema2,
  originUs: signedTimeValueSchema3,
  sourceWidth: time.positive().max(8192),
  sourceHeight: time.positive().max(8192),
  coverage: z7.array(coverage).max(52),
  comparisons: z7.array(comparison).max(51)
});
function invalid6(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function normalizeSourceSceneChunk(report, assetId, source, previous) {
  const parsed = schema.safeParse(report);
  if (!parsed.success)
    invalid6("Malformed source scene chunk");
  const chunk = parsed.data;
  if (chunk.assetId !== assetId || chunk.streamId !== source.streamId || compare4(fromTime5(chunk.originUs), fromTime5(source.originUs)) !== 0 || compare4(fromTime5(chunk.durationUs), fromTime5(source.durationUs)) !== 0)
    invalid6("Scene chunk changed its selected source");
  const times = sourceSceneSampleTimes(chunk.range, chunk.durationUs);
  if (times.length !== chunk.coverage.length)
    invalid6("Incomplete source scene coverage");
  if (previous && !isDeepStrictEqual5(previous.coverage, chunk.coverage[0]))
    invalid6("Overlapping scene coverage changed");
  let prior;
  let lastAvailable = previous?.lastAvailable;
  let last = previous?.comparison;
  let pairIndex = 0;
  for (const [index, point] of chunk.coverage.entries()) {
    if (point.requestedSourceUs !== times[index])
      invalid6("Source scene coverage changed its grid");
    if (point.status === "unavailable") {
      prior = undefined;
      continue;
    }
    validateSceneSampleClock(point.sample, point.requestedSourceUs, point.actualSourceUs, source.originUs);
    if (lastAvailable && compareSceneSampleClocks(lastAvailable.sample, point.sample) > 0)
      invalid6("Source scene samples moved backwards");
    if (index === 0 && !previous && point.continuousFromPrevious)
      invalid6("First scene observation has no predecessor");
    if (index > 0 && !prior && point.continuousFromPrevious)
      invalid6("Scene continuity follows an unavailable observation");
    if (index > 0 || !previous) {
      if (!prior || !point.continuousFromPrevious) {
        if (point.stillnessRunStartUs !== point.requestedSourceUs)
          invalid6("Scene stillness crosses a gap");
      } else if (point.stillnessRunStartUs !== prior.stillnessRunStartUs && point.stillnessRunStartUs !== point.requestedSourceUs)
        invalid6("Scene stillness changed its observed start");
    }
    if (prior && point.continuousFromPrevious && compareSceneSampleClocks(prior.sample, point.sample) < 0) {
      const pair = chunk.comparisons[pairIndex++];
      if (!pair || !isDeepStrictEqual5(pair.previous, prior.sample) || !isDeepStrictEqual5(pair.current, point.sample) || pair.actualSourceUs !== point.actualSourceUs)
        invalid6("Scene comparison does not join retained observations");
      if (last && compareSceneSampleClocks(last.current, pair.current) >= 0)
        invalid6("Scene comparisons moved backwards");
      last = pair;
    }
    prior = point;
    lastAvailable = point;
  }
  if (pairIndex !== chunk.comparisons.length)
    invalid6("Source scene comparisons cross gaps or repeat observations");
  if (Buffer.byteLength(JSON.stringify(chunk)) > 65536)
    invalid6("Scene chunk exceeds bounded storage");
  return {
    chunk,
    last,
    sourceState: { coverage: chunk.coverage.at(-1), ...lastAvailable ? { lastAvailable } : {} }
  };
}

// packages/core/src/scene-evidence.ts
import { compare as compare5, fromTime as fromTime6 } from "@screenrec/composition";
function sceneGenerationResource(identity2) {
  return JSON.stringify([...ownerIdentity(identity2.owner), identity2.generation]);
}
var portableCount = z8.int().nonnegative().max(Number.MAX_SAFE_INTEGER);
var portableSceneMetadataSchema = z8.strictObject({
  owner: z8.strictObject({
    kind: z8.literal("asset"),
    assetId: z8.string().regex(/^[a-f0-9]{64}$/)
  }),
  sourceId: z8.string().regex(/^[a-f0-9]{64}$/),
  generation: z8.string().min(1).max(256),
  policy: z8.literal(sourceScenePolicy),
  source: z8.strictObject({
    kind: z8.literal("asset"),
    streamId: z8.string().min(1).max(256),
    acquisitionId: z8.uuid().optional(),
    supportDigest: z8.string().min(1).max(256),
    originUs: signedTimeValueSchema4,
    durationUs: timeValueSchema3
  }).transform(({ acquisitionId, ...source }) => ({
    ...source,
    ...acquisitionId === undefined ? {} : { acquisitionId }
  })),
  sourceWidth: portableCount.positive(),
  sourceHeight: portableCount.positive(),
  chunkCount: portableCount.positive(),
  comparisonCount: portableCount,
  boundaryCount: portableCount
}).refine((value) => value.sourceId === value.owner.assetId, "Scene source identity differs from its owner");
function sourceSceneDescriptor(selected) {
  return {
    kind: "asset",
    streamId: selected.selection.streamId,
    ...selected.selection.acquisitionId === undefined ? {} : { acquisitionId: selected.selection.acquisitionId },
    originUs: toSignedTime3(subtract4(fromTime6(0), fromTime6(selected.track.sourceOffsetUs))),
    supportDigest: selected.supportDigest,
    durationUs: selected.durationUs
  };
}
function assetSceneOwner(assets, acquisitions) {
  return (identity2, source) => {
    if (identity2.owner.kind !== "asset" || source.kind !== "asset" || identity2.sourceId !== identity2.owner.assetId)
      invalid7("Scene identity requires an asset source");
    const selected = selectSource(assets, acquisitions, {
      assetId: identity2.owner.assetId,
      streamId: source.streamId,
      ...source.acquisitionId === undefined ? {} : { acquisitionId: source.acquisitionId }
    });
    if (selected.stream.kind !== "video")
      invalid7("Scene evidence requires a video stream");
    if (!isDeepStrictEqual6(source, sourceSceneDescriptor(selected)))
      throw new CatalogError("ARTIFACT_CHANGED", "Scene source support changed");
  };
}
var where2 = "ownerKind=? AND ownerId=? AND sourceId=? AND generation=? AND policy=?";
var key = (identity2) => [
  ...ownerIdentity(identity2.owner),
  identity2.sourceId,
  identity2.generation,
  identity2.policy
];
var integer8 = (value) => Number.isSafeInteger(value) && value >= 0;
function invalid7(message) {
  throw new CatalogError("INVALID_EVIDENCE", message);
}
function metadata2(row) {
  const {
    ownerKind,
    ownerId,
    source,
    durationUs: _durationUs,
    throughUs: _throughUs,
    complete: _complete,
    lastComparison: _lastComparison,
    sourceState: _sourceState,
    ...details
  } = row;
  const owner = ownerKind === "recording" ? { kind: "recording", recordingId: ownerId } : { kind: "asset", assetId: ownerId };
  return { ...details, owner, source: JSON.parse(source) };
}
function normalizeSceneChunk(report, durationUs, previous) {
  if (report.kept.startUs !== 0 || report.kept.endUs !== durationUs || !integer8(report.sourceWidth) || report.sourceWidth < 1 || !integer8(report.sourceHeight) || report.sourceHeight < 1)
    invalid7("Scene evidence requires canonical source bounds and dimensions");
  const times = sceneSampleTimes(report.range, report.kept);
  if (report.coverage.length !== times.length || report.comparisons.length > 51)
    invalid7("Incomplete scene coverage");
  for (const [i, point] of report.coverage.entries()) {
    if (point.requestedSourceUs !== times[i] || !integer8(point.actualSourceUs) || point.actualSourceUs >= durationUs || !integer8(point.stillnessRunStartUs) || point.stillnessRunStartUs > point.actualSourceUs || point.distanceUs !== Math.abs(point.requestedSourceUs - point.actualSourceUs) || !integer8(point.width) || point.width < 1 || point.width > 64 || !integer8(point.height) || point.height < 1 || point.height > 64 || i > 0 && point.actualSourceUs < report.coverage[i - 1].actualSourceUs)
      invalid7("Invalid scene coverage");
  }
  let last = previous;
  const comparisons = [];
  for (const pair of report.comparisons) {
    if (!integer8(pair.previousActualSourceUs) || !integer8(pair.actualSourceUs) || pair.previousActualSourceUs >= pair.actualSourceUs || pair.actualSourceUs >= durationUs || typeof pair.boundary !== "boolean" || ![
      pair.changedPixelFraction,
      pair.changedCellFraction,
      pair.meanAbsoluteChannelDifference
    ].every((v) => Number.isFinite(v) && v >= 0 && v <= 1))
      invalid7("Invalid scene comparison");
    if (last && pair.actualSourceUs <= last.actualSourceUs) {
      if (JSON.stringify(pair) !== JSON.stringify(last))
        invalid7("Scene comparison moved backwards or changed");
      continue;
    }
    comparisons.push(pair);
    last = pair;
  }
  const chunk = {
    policy: report.policy,
    range: report.range,
    kept: report.kept,
    sourceWidth: report.sourceWidth,
    sourceHeight: report.sourceHeight,
    coverage: report.coverage,
    comparisons
  };
  if (Buffer.byteLength(JSON.stringify(chunk)) > 65536)
    invalid7("Scene chunk exceeds bounded storage");
  return { chunk, last };
}

class SceneEvidenceReader {
  page(request) {
    return this.chunkPage(request, "recording");
  }
  sourcePage(request) {
    return this.chunkPage(request, "asset");
  }
  chunkPage({ identity: identity2, afterStartUs, limit = 100 }, kind, stagedMetadata) {
    if (!integer8(limit) || limit < 1 || limit > 100 || afterStartUs !== undefined && !integer8(afterStartUs))
      throw new CatalogError("INVALID_PARAMS", "Invalid scene page limit or cursor");
    const metadata3 = stagedMetadata ?? this.readMetadata(identity2);
    if (metadata3.source.kind !== kind)
      invalid7(`Scene page requires a ${kind === "recording" ? "recording" : "asset"} source`);
    const rows = this.readChunks(identity2, afterStartUs ?? -1, limit + 1);
    const more = rows.length > limit;
    if (more)
      rows.pop();
    return {
      metadata: metadata3,
      chunks: rows,
      nextStartUs: more ? rows.at(-1).range.startUs : null
    };
  }
}

class SceneEvidenceStore extends SceneEvidenceReader {
  store;
  validateOwner;
  references;
  constructor(store, validateOwner) {
    super();
    this.store = store;
    this.validateOwner = validateOwner;
    this.references = new ResourceReferences(store);
    store.catalog.exec(`CREATE TABLE IF NOT EXISTS scene_evidence_generations (
   ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,sourceId TEXT NOT NULL,generation TEXT NOT NULL,policy TEXT NOT NULL,
   source TEXT NOT NULL,durationUs INTEGER NOT NULL,sourceWidth INTEGER NOT NULL,sourceHeight INTEGER NOT NULL,
   throughUs INTEGER NOT NULL,chunkCount INTEGER NOT NULL,comparisonCount INTEGER NOT NULL,
   boundaryCount INTEGER NOT NULL,lastComparison TEXT,sourceState TEXT,complete INTEGER NOT NULL,
   PRIMARY KEY(ownerKind,ownerId,sourceId,generation,policy)
  ) STRICT;
  CREATE TABLE IF NOT EXISTS scene_evidence_chunks (
   ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,sourceId TEXT NOT NULL,generation TEXT NOT NULL,policy TEXT NOT NULL,
   startUs INTEGER NOT NULL,content TEXT NOT NULL,
   PRIMARY KEY(ownerKind,ownerId,sourceId,generation,policy,startUs)
  ) STRICT;
  CREATE TABLE IF NOT EXISTS scene_evidence_boundaries (
   ownerKind TEXT NOT NULL,ownerId TEXT NOT NULL,sourceId TEXT NOT NULL,generation TEXT NOT NULL,policy TEXT NOT NULL,
   actualSourceUs INTEGER NOT NULL,ordinal INTEGER NOT NULL,content TEXT NOT NULL,
   PRIMARY KEY(ownerKind,ownerId,sourceId,generation,policy,actualSourceUs,ordinal)
  ) STRICT;`);
  }
  async recoverPending(ownerKind, signal) {
    let cursor = 0;
    for (;; ) {
      signal.throwIfAborted();
      const rows = this.store.catalog.prepare("SELECT rowid AS cursor,ownerKind,ownerId,sourceId,generation,policy,complete FROM scene_evidence_generations WHERE ownerKind=? AND rowid>? ORDER BY rowid LIMIT 100").all(ownerKind, cursor);
      for (const row of rows) {
        signal.throwIfAborted();
        if (row.complete !== 1) {
          const owner = row.ownerKind === "asset" ? { kind: "asset", assetId: row.ownerId } : { kind: "recording", recordingId: row.ownerId };
          await this.remove({
            owner,
            sourceId: row.sourceId,
            generation: row.generation,
            policy: row.policy
          });
        }
        cursor = row.cursor;
      }
      if (rows.length < 100)
        return;
      await setImmediate4(undefined, { signal });
    }
  }
  portableGenerations(assetId, limit = 25000) {
    const rows = this.store.catalog.prepare("SELECT * FROM scene_evidence_generations WHERE ownerKind='asset' AND ownerId=? ORDER BY generation,sourceId,policy LIMIT ?").all(assetId, limit + 1);
    if (rows.length > limit)
      throw new CatalogError("LIMIT_EXCEEDED", "Scene dependency inventory exceeds its limit");
    return rows.map((row) => {
      if (row.complete !== 1)
        throw new CatalogError("PROCESSING_BUSY", "Scene generation is incomplete", {}, true);
      return portableSceneMetadataSchema.parse(metadata2(row));
    });
  }
  async stagePortable(value, chunks, signal) {
    const expected = portableSceneMetadataSchema.parse(value), existing = this.get(expected);
    if (existing && existing.complete !== 1)
      throw new CatalogError("PROCESSING_BUSY", "Scene generation is already being prepared", {}, true);
    if (existing && !isDeepStrictEqual6(metadata2(existing), expected))
      invalid7("Retained scene metadata conflicts with package");
    let owned = false, count = 0, throughUs = 0;
    const close = async () => {
      if (owned && this.get(expected)?.complete !== 1)
        await this.remove(expected);
    };
    try {
      for await (const value2 of chunks) {
        signal.throwIfAborted();
        if (!value2 || typeof value2 !== "object")
          invalid7("Invalid portable scene chunk");
        const chunk = value2;
        if (chunk.range?.startUs !== throughUs || !integer8(chunk.range?.endUs) || chunk.range.endUs <= throughUs)
          invalid7("Portable scene chunks require contiguous coverage");
        throughUs = chunk.range.endUs;
        if (++count > expected.chunkCount)
          invalid7("Scene chunk inventory exceeds metadata");
        if (existing) {
          const row = this.store.catalog.prepare(`SELECT content FROM scene_evidence_chunks WHERE ${where2} AND startUs=?`).get(...key(expected), chunk?.range?.startUs);
          if (!row || !isDeepStrictEqual6(JSON.parse(row.content), chunk))
            invalid7("Retained scene content conflicts with package");
        } else {
          this.store.transaction(() => this.appendChunk(expected, expected.source, chunk));
          owned = true;
        }
        await setImmediate4(undefined, { signal });
      }
      signal.throwIfAborted();
      const ready = this.get(expected);
      if (!ready || ready.throughUs !== ceil2(fromTime6(expected.source.durationUs)) || count !== expected.chunkCount || !isDeepStrictEqual6(metadata2(ready), expected))
        invalid7("Scene inventory is incomplete or differs from metadata");
      const stagedMetadata = (identity2) => {
        if (!isDeepStrictEqual6(key(identity2), key(expected)))
          invalid7("Staged scene read names another generation");
        const row = this.get(expected);
        if (!row || row.complete === -1 || !isDeepStrictEqual6(metadata2(row), expected))
          invalid7("Staged scene evidence is no longer retained");
        return expected;
      };
      return {
        close,
        read: {
          metadata: stagedMetadata,
          sourcePage: (request) => this.chunkPage(request, "asset", stagedMetadata(request.identity)),
          sourceWindowPage: (request) => this.sourceWindow(request, stagedMetadata(request.identity))
        },
        publish: () => {
          signal.throwIfAborted();
          this.validateOwner(expected, expected.source);
          this.store.catalog.prepare(`UPDATE scene_evidence_generations SET complete=1 WHERE ${where2}`).run(...key(expected));
        }
      };
    } catch (error) {
      await close();
      throw error;
    }
  }
  get(identity2) {
    return this.store.catalog.prepare(`SELECT * FROM scene_evidence_generations WHERE ${where2}`).get(...key(identity2));
  }
  append(identity2, source, report) {
    this.store.transaction(() => {
      this.validateOwner(identity2, source);
      this.appendChunk(identity2, source, report);
    });
  }
  appendChunk(identity2, source, report) {
    const durationUs = ceil2(fromTime6(source.durationUs));
    if (!integer8(durationUs) || durationUs < 1 || !identity2.generation || !identity2.policy || report.policy !== identity2.policy)
      invalid7("Scene evidence identity does not match its source");
    const row = this.get(identity2);
    if (row?.complete || report.range.startUs !== (row?.throughUs ?? 0))
      invalid7("Scene chunks require contiguous unpublished coverage");
    if (row && (row.sourceWidth !== report.sourceWidth || row.sourceHeight !== report.sourceHeight || !isDeepStrictEqual6(metadata2(row).source, source)))
      invalid7("Scene source context or dimensions changed");
    if (identity2.policy !== (source.kind === "asset" ? sourceScenePolicy : scenePolicy.id))
      invalid7("Unsupported scene policy for source owner");
    const normalized = source.kind === "asset" ? normalizeSourceSceneChunk(report, identity2.sourceId, source, row?.sourceState ? {
      ...JSON.parse(row.sourceState),
      ...row.lastComparison ? { comparison: JSON.parse(row.lastComparison) } : {}
    } : undefined) : normalizeSceneChunk(report, durationUs, row?.lastComparison ? JSON.parse(row.lastComparison) : undefined);
    const { chunk, last } = normalized;
    const content = JSON.stringify(chunk);
    if (!row)
      this.store.catalog.prepare(`INSERT INTO scene_evidence_generations VALUES (?,?,?,?,?,?,?,?,?,0,0,0,0,NULL,NULL,0)`).run(...key(identity2), JSON.stringify(source), durationUs, report.sourceWidth, report.sourceHeight);
    this.store.catalog.prepare("INSERT INTO scene_evidence_chunks VALUES (?,?,?,?,?,?,?)").run(...key(identity2), report.range.startUs, content);
    for (const [index, pair] of chunk.comparisons.entries()) {
      if (!pair.boundary)
        continue;
      const boundary = {
        ordinal: (row?.comparisonCount ?? 0) + index,
        actualSourceUs: pair.actualSourceUs,
        sample: "current" in pair && source.kind === "asset" ? { ...pair.current, originUs: source.originUs } : null
      };
      this.store.catalog.prepare("INSERT INTO scene_evidence_boundaries VALUES (?,?,?,?,?,?,?,?)").run(...key(identity2), boundary.actualSourceUs, boundary.ordinal, JSON.stringify(boundary));
    }
    this.store.catalog.prepare(`UPDATE scene_evidence_generations SET throughUs=?,chunkCount=chunkCount+1,comparisonCount=comparisonCount+?,boundaryCount=boundaryCount+?,lastComparison=?,sourceState=? WHERE ${where2}`).run(report.range.endUs, chunk.comparisons.length, chunk.comparisons.filter((pair) => pair.boundary).length, last ? JSON.stringify(last) : null, "sourceState" in normalized ? JSON.stringify(normalized.sourceState) : null, ...key(identity2));
  }
  finish(identity2) {
    return this.store.transaction(() => {
      const row = this.get(identity2);
      if (!row || row.complete === -1 || row.throughUs !== row.durationUs)
        invalid7("Scene coverage is incomplete");
      this.validateOwner(identity2, metadata2(row).source);
      this.store.catalog.prepare(`UPDATE scene_evidence_generations SET complete=1 WHERE ${where2}`).run(...key(identity2));
      return metadata2(row);
    });
  }
  metadata(identity2) {
    return this.readMetadata(identity2);
  }
  readMetadata(identity2) {
    const row = this.get(identity2);
    if (row?.complete !== 1)
      invalid7("Scene evidence is not complete");
    return metadata2(row);
  }
  readChunks(identity2, afterStartUs, limit) {
    const rows = this.store.catalog.prepare(`SELECT content FROM scene_evidence_chunks WHERE ${where2} AND startUs>? ORDER BY startUs LIMIT ?`).all(...key(identity2), afterStartUs, limit);
    return rows.map((row) => JSON.parse(row.content));
  }
  sourceWindowPage(request) {
    return this.sourceWindow(request, this.readMetadata(request.identity));
  }
  sourceWindow({
    identity: identity2,
    range,
    afterStartUs,
    limit = 1
  }, metadata3) {
    if (metadata3.source.kind !== "asset")
      invalid7("Scene coverage requires an asset source");
    if (!integer8(range.startUs) || !integer8(range.endUs) || range.startUs >= range.endUs || range.endUs > ceil2(fromTime6(metadata3.source.durationUs)) || !integer8(limit) || limit < 1 || limit > 100 || afterStartUs !== undefined && (!integer8(afterStartUs) || afterStartUs >= range.endUs))
      throw new CatalogError("INVALID_PARAMS", "Invalid scene coverage window");
    const first = this.store.catalog.prepare(`SELECT startUs FROM scene_evidence_chunks WHERE ${where2} AND startUs<=? ORDER BY startUs DESC LIMIT 1`).get(...key(identity2), range.startUs);
    const lower = Math.max(first.startUs, afterStartUs === undefined ? 0 : afterStartUs + 1);
    const rows = this.store.catalog.prepare(`SELECT content FROM scene_evidence_chunks WHERE ${where2} AND startUs>=? AND startUs<? ORDER BY startUs LIMIT ?`).all(...key(identity2), lower, range.endUs, limit + 1);
    const more = rows.length > limit;
    if (more)
      rows.pop();
    const chunks = rows.map((row) => JSON.parse(row.content));
    return { metadata: metadata3, chunks, nextStartUs: more ? chunks.at(-1).range.startUs : null };
  }
  boundaryPage({
    identity: identity2,
    range,
    after,
    limit = 100
  }) {
    const metadata3 = this.readMetadata(identity2);
    const window = range ?? { startUs: 0, endUs: ceil2(fromTime6(metadata3.source.durationUs)) };
    if (!integer8(limit) || limit < 1 || limit > 100 || !integer8(window.startUs) || !integer8(window.endUs) || window.startUs >= window.endUs || window.endUs > ceil2(fromTime6(metadata3.source.durationUs)) || after && (!integer8(after.ordinal) || !Number.isSafeInteger(after.actualSourceUs)))
      throw new CatalogError("INVALID_PARAMS", "Invalid scene boundary page");
    const lower = after && after.actualSourceUs >= window.startUs ? after : { actualSourceUs: window.startUs, ordinal: -1 };
    const rows = this.store.catalog.prepare(`SELECT content FROM scene_evidence_boundaries WHERE ${where2}
      AND (actualSourceUs,ordinal)>(?,?) AND actualSourceUs<=?
      ORDER BY actualSourceUs,ordinal LIMIT ?`).all(...key(identity2), lower.actualSourceUs, lower.ordinal, window.endUs, limit + 1);
    const more = rows.length > limit;
    if (more)
      rows.pop();
    const scanned = rows.map((row) => JSON.parse(row.content));
    const boundaries = scanned.filter((row) => {
      const at = row.sample ? sceneSampleSourceTime(row.sample, row.sample.originUs) : fromTime6(row.actualSourceUs);
      return compare5(at, fromTime6(window.startUs)) >= 0 && compare5(at, fromTime6(window.endUs)) < 0;
    });
    const last = scanned.at(-1);
    return {
      metadata: metadata3,
      boundaries,
      scanned: scanned.length,
      next: more && last ? { actualSourceUs: last.actualSourceUs, ordinal: last.ordinal } : null
    };
  }
  async remove(identity2) {
    this.store.transaction(() => {
      this.store.catalog.prepare(`UPDATE scene_evidence_generations SET complete=-1 WHERE ${where2}`).run(...key(identity2));
    });
    for (const table of ["scene_evidence_chunks", "scene_evidence_boundaries"])
      while (true) {
        const removed = this.store.transaction(() => this.store.catalog.prepare(`DELETE FROM ${table} WHERE rowid IN (SELECT rowid FROM ${table} WHERE ${where2} LIMIT 100)`).run(...key(identity2)).changes);
        if (Number(removed) < 100)
          break;
        await setImmediate4();
      }
    this.store.transaction(() => {
      this.store.catalog.prepare(`DELETE FROM scene_evidence_generations WHERE ${where2}`).run(...key(identity2));
    });
  }
  async reclaim(owner, keep, signal) {
    let cursor = 0;
    while (true) {
      signal?.throwIfAborted();
      const rows = this.store.catalog.prepare("SELECT rowid AS cursor,sourceId,generation,policy FROM scene_evidence_generations WHERE ownerKind=? AND ownerId=? AND rowid>? ORDER BY rowid LIMIT 100").all(...ownerIdentity(owner), cursor);
      for (const row of rows) {
        signal?.throwIfAborted();
        if (!keep(row.generation) && !this.references.has("scene-generation", sceneGenerationResource({ owner, generation: row.generation })))
          await this.remove({ ...row, owner });
        cursor = row.cursor;
      }
      if (rows.length < 100)
        return;
      await setImmediate4();
    }
  }
}

// packages/core/src/source-index-selection.ts
import { fromTime as fromTime7, ceil as ceil3 } from "@screenrec/composition";
import { setImmediate as setImmediate5 } from "node:timers/promises";
var sourceIndexPolicy = {
  id: "source-presentation-selection-v2",
  coverageUs: selectionPolicy.coverageUs
};
async function* sourceIndexChunks(records, identity2, signal) {
  let afterStartUs;
  for (;; ) {
    signal.throwIfAborted();
    const page = records.sourcePage({
      identity: identity2,
      limit: 1,
      ...afterStartUs === undefined ? {} : { afterStartUs }
    });
    yield* page.chunks;
    if (page.nextStartUs === null)
      return;
    afterStartUs = page.nextStartUs;
    await setImmediate5();
  }
}
function sourceIndexQueryRanges(support) {
  return support.map((range) => ({
    startUs: ceil3(fromTime7(range.startUs)),
    endUs: ceil3(fromTime7(range.endUs))
  })).filter((range) => range.startUs < range.endUs);
}

// packages/core/src/source-index.ts
import {
  signedTimeValueSchema as signedTimeValueSchema6,
  fromTime as fromTime11,
  compare as compare8,
  toSignedTime as toSignedTime5,
  subtract as subtract7,
  ceil as ceil4
} from "@screenrec/composition";

// packages/core/src/source-index-equality.ts
class SourceIndexStillness {
  points;
  before;
  next;
  constructor(points) {
    this.points = points;
  }
  async equality(frame, range) {
    this.next ??= await this.points.next();
    while (!this.next.done && this.next.value.requestedSourceUs <= range.startUs) {
      this.before = this.next.value;
      this.next = await this.points.next();
    }
    let unchanged = !!frame && this.before?.status === "available" && compareSceneSampleClocks(frame.sample, this.before.sample) === 0 && range.startUs - this.before.requestedSourceUs <= scenePolicy.stepUs;
    const run = this.before?.status === "available" ? this.before.stillnessRunStartUs : undefined;
    while (!this.next.done && this.next.value.requestedSourceUs <= range.endUs) {
      const point = this.next.value;
      unchanged &&= point.status === "available" && point.continuousFromPrevious && point.stillnessRunStartUs === run;
      this.before = point;
      this.next = await this.points.next();
    }
    return unchanged && this.before && range.endUs - this.before.requestedSourceUs <= scenePolicy.stepUs ? "sampled" : "unproven";
  }
  close() {
    return this.points.return(undefined);
  }
}
async function* sourceIndexPoints(records, identity2, signal) {
  let through = -1;
  for await (const chunk of sourceIndexChunks(records, identity2.scenes, signal))
    for (const point of chunk.coverage) {
      if (point.requestedSourceUs <= through)
        continue;
      signal.throwIfAborted();
      through = point.requestedSourceUs;
      yield point;
    }
}

// packages/core/src/source-index.ts
import { z as z11 } from "zod";
import { isDeepStrictEqual as isDeepStrictEqual7 } from "node:util";

// packages/core/src/frame-inspection.ts
import { z as z10 } from "zod";
import {
  compiledFrameSchema,
  timeValueSchema as timeValueSchema5,
  signedTimeValueSchema as signedTimeValueSchema5,
  add as add2,
  subtract as subtract6,
  toSignedTime as toSignedTime4,
  rational as rational2,
  round as round2,
  compare as compare7,
  fromTime as fromTime10,
  fontReferenceSchema,
  processingTapSchema as processingTapSchema2
} from "@screenrec/composition";

// packages/core/src/project-window.ts
import {
  createCompiler,
  documentAssetIds,
  isMediaClip as isMediaClip2,
  processingCapabilities,
  rangeSchema as rangeSchema2,
  requireWindowReady,
  validateComposition
} from "@screenrec/composition";

// packages/core/src/composition-pointer.ts
import {
  isMediaClip,
  compare as compare6,
  fromTime as fromTime9,
  toTime as toTime2,
  floor,
  subtract as subtract5
} from "@screenrec/composition";

// packages/core/src/presentation-pointer-history.ts
import { fromTime as fromTime8, timeValueSchema as timeValueSchema4 } from "@screenrec/composition";

// packages/core/src/trails.ts
import { maximumPointerTrailUs } from "@screenrec/composition";

// packages/core/src/presentation-time.ts
import { z as z9 } from "zod";
var integer9 = z9.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
var presentationTimeSchema = z9.strictObject({
  value: z9.string().regex(/^(0|[1-9]\d{0,18})$/).refine((v) => BigInt(v) <= 9223372036854775807n),
  timescale: integer9.min(1).max(2147483647)
});

// packages/core/src/trails.ts
var trailPolicy = Object.freeze({
  id: "requested-time-trail-v1",
  defaultUs: 2000000,
  maximumUs: maximumPointerTrailUs,
  maximumPoints: 1200,
  maximumObservations: 5000
});

// packages/core/src/composition-pointer.ts
var pointerPreparationLimits = Object.freeze({
  maxBytes: 128 * 1024 ** 2,
  maxRows: 1e6,
  maxEvents: 1e6,
  maxSources: 256,
  maxHistoryBytes: 1024 ** 3,
  maxFrames: 1e6,
  maxOperations: 1e7,
  maxAdmissionWork: 1e5,
  rowBytes: 256 * 1024
});

// packages/core/src/frame-inspection.ts
var time2 = z10.int().nonnegative().max(Number.MAX_SAFE_INTEGER);
var selectedPicture = {
  clipId: z10.string().min(1),
  assetId: z10.string().min(1),
  streamId: z10.string().min(1)
};
var pictureDeliverySchema = z10.object({
  file: z10.string(),
  mediaType: z10.literal("image/png"),
  width: z10.int().positive(),
  height: z10.int().positive(),
  sourceWidth: z10.int().positive(),
  sourceHeight: z10.int().positive(),
  bytes: z10.int().positive().max(32 * 1024 * 1024)
});
var textLayoutSchema = z10.object({
  font: fontReferenceSchema,
  text: z10.string().max(8192),
  visibleRange: z10.tuple([time2, time2]),
  lines: z10.array(z10.object({
    range: z10.tuple([time2, time2]),
    text: z10.string().max(8192),
    origin: z10.tuple([z10.number().finite(), z10.number().finite()]),
    width: z10.number().finite().nonnegative(),
    fonts: z10.array(z10.string().min(1)).max(8192)
  }).strict()).max(8192)
}).strict();
var nativeProjectReceiptSchema = pictureDeliverySchema.extend({
  profile: z10.literal("h264-rec709"),
  frame: compiledFrameSchema,
  decodedSamples: time2,
  readerOpens: time2,
  decodedImages: time2,
  pictures: z10.array(z10.discriminatedUnion("kind", [
    z10.discriminatedUnion("status", [
      z10.strictObject({
        kind: z10.literal("text"),
        clipId: z10.string().min(1),
        status: z10.literal("available"),
        layout: textLayoutSchema
      }),
      z10.strictObject({
        kind: z10.literal("text"),
        clipId: z10.string().min(1),
        status: z10.literal("unavailable"),
        reason: z10.string().min(1)
      })
    ]),
    z10.strictObject({
      kind: z10.literal("image"),
      ...selectedPicture,
      status: z10.enum(["available", "unavailable"]),
      reason: z10.string().min(1).optional()
    }).refine((value) => value.status === "available" ? value.reason === undefined : value.reason !== undefined),
    z10.discriminatedUnion("status", [
      z10.strictObject({
        kind: z10.literal("video"),
        status: z10.literal("unavailable"),
        ...selectedPicture,
        requestedSourceUs: timeValueSchema5,
        reason: z10.string().min(1)
      }),
      z10.strictObject({
        kind: z10.literal("video"),
        status: z10.literal("available"),
        ...selectedPicture,
        requestedSourceUs: timeValueSchema5,
        actualSourceUs: z10.int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
        sample: z10.object({
          value: z10.string().regex(/^-?\d+$/),
          timescale: z10.int().positive(),
          originUs: signedTimeValueSchema5
        })
      })
    ])
  ]))
});
var projectReceiptSchema = nativeProjectReceiptSchema.extend({
  frame: z10.strictObject(compiledFrameSchema.shape).omit({ visual: true })
});
var projectPictureOptionsSchema = z10.strictObject({
  maxLongEdge: z10.int().min(1).max(8192),
  tap: processingTapSchema2,
  implementationId: z10.string().min(1)
});
var optionsSchema = z10.strictObject({ atUs: time2, ...projectPictureOptionsSchema.shape });
var retainedProjectFrameSchema = projectReceiptSchema.extend({
  ...optionsSchema.shape,
  projectId: z10.string().min(1),
  revisionId: z10.string().min(1)
}).strict();
var sourceOptionsSchema = z10.strictObject({
  selection: sourceSelectionSchema,
  atUs: time2,
  maxLongEdge: z10.int().min(1).max(8192),
  supportDigest: z10.string().regex(/^[a-f0-9]{64}$/),
  implementationId: z10.string().min(1)
});
var sourceReceiptSchema = pictureDeliverySchema.extend({
  decodedSamples: time2,
  readerOpens: time2,
  assetId: z10.string().min(1),
  streamId: z10.string().min(1),
  requestedSourceUs: time2,
  actualSourceUs: z10.int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
  sample: z10.object({
    value: z10.string().max(21).regex(/^-?\d+$/),
    timescale: z10.int().positive(),
    endValue: z10.string().max(21).regex(/^-?\d+$/),
    endTimescale: z10.int().positive(),
    originUs: signedTimeValueSchema5
  })
});
var sourceImageSelectionSchema = sourceSelectionSchema.omit({ acquisitionId: true });
var imageOptionsSchema = z10.strictObject({
  kind: z10.literal("image"),
  selection: sourceImageSelectionSchema,
  maxLongEdge: z10.int().min(1).max(8192),
  implementationId: z10.string().min(1)
});
var imageReceiptSchema = pictureDeliverySchema.extend({
  kind: z10.literal("image"),
  ...sourceImageSelectionSchema.shape,
  orientation: z10.int().min(1).max(8),
  hasAlpha: z10.boolean(),
  decodedImages: z10.literal(1),
  readerOpens: z10.literal(1)
});
var imageInputSchema = sourceImageSelectionSchema.extend({
  maxLongEdge: imageOptionsSchema.shape.maxLongEdge.optional()
}).strict();
var sourceFrameUnavailableSchema = sourceOptionsSchema.extend({
  jobId: z10.uuid(),
  attemptId: z10.uuid(),
  reason: z10.string().max(4096).nullable(),
  observation: z10.strictObject({
    requestedSourceUs: time2,
    status: z10.literal("unavailable"),
    reason: z10.literal("empty_edit")
  })
}).refine((value) => value.observation.requestedSourceUs === value.atUs);
function validateSourceFrameGeometry(value, source, maxLongEdge) {
  if (value.sourceWidth !== Math.round(source.width) || value.sourceHeight !== Math.round(source.height) || value.width > value.sourceWidth || value.height > value.sourceHeight || Math.max(value.width, value.height) > maxLongEdge)
    throw new CatalogError("INVALID_RESPONSE", "Source picture receipt changed its geometry");
}
var retainedSourceFrameSchema = sourceReceiptSchema.extend({
  ...sourceSelectionSchema.shape,
  atUs: time2,
  maxLongEdge: sourceOptionsSchema.shape.maxLongEdge,
  supportDigest: sourceOptionsSchema.shape.supportDigest,
  implementationId: z10.string().min(1).max(256)
}).strict();

// packages/core/src/source-index.ts
var portableTime = z11.int().nonnegative().max(Number.MAX_SAFE_INTEGER);
var portableRange = z11.strictObject({ startUs: portableTime, endUs: portableTime }).refine((r) => r.endUs > r.startUs);
var portableSourceIndexMetadataSchema = sourceSelectionSchema.extend({
  generation: z11.string().min(1).max(256),
  scenes: portableSceneMetadataSchema,
  selectionPolicy: z11.literal(sourceIndexPolicy.id),
  implementationId: z11.string().min(1).max(256),
  maxLongEdge: z11.int().min(1).max(8192),
  durationUs: portableTime,
  candidateCount: portableTime.max(25000),
  coverageCount: portableTime.max(25000),
  bytes: portableTime
}).strict();
var portableSourceIndexRecordSchema = z11.discriminatedUnion("kind", [
  z11.strictObject({
    kind: z11.literal("entry"),
    candidate: z11.strictObject({
      ordinal: portableTime,
      requestedSourceUs: portableTime,
      support: portableRange,
      reasons: z11.array(z11.union([
        z11.strictObject({
          kind: z11.enum(["first", "last", "availability", "coverage"]),
          eventSourceUs: portableTime
        }),
        z11.strictObject({
          kind: z11.literal("scene"),
          side: z11.enum(["before", "after"]),
          observedSourceUs: portableTime,
          sample: sourceSceneClockSchema,
          originUs: signedTimeValueSchema6
        })
      ])).max(1e4)
    }),
    frame: retainedSourceFrameSchema
  }),
  z11.strictObject({
    kind: z11.literal("coverage"),
    coverage: z11.union([
      z11.strictObject({
        source: portableRange,
        ordinal: portableTime,
        state: z11.literal("available"),
        equality: z11.enum(["sampled", "unproven"])
      }),
      z11.strictObject({
        source: portableRange,
        ordinal: z11.null(),
        state: z11.literal("unavailable"),
        basis: z11.literal("support")
      }),
      z11.strictObject({
        source: portableRange,
        ordinal: z11.null(),
        state: z11.literal("unavailable"),
        basis: z11.literal("observation"),
        equality: z11.literal("unproven"),
        observation: z11.discriminatedUnion("kind", [
          z11.strictObject({ kind: z11.literal("frame"), frame: sourceFrameUnavailableSchema }),
          z11.strictObject({
            kind: z11.literal("scene"),
            point: z11.strictObject({
              requestedSourceUs: portableTime,
              status: z11.literal("unavailable"),
              reason: z11.enum(["outside_support", "empty_edit"]),
              continuousFromPrevious: z11.literal(false)
            })
          })
        ])
      })
    ])
  })
]);
var invalid8 = (message) => {
  throw new CatalogError("INVALID_EVIDENCE", message);
};
function sourceIndexDomain(source, scenes, frames) {
  function selected(identity2) {
    return source({
      assetId: identity2.assetId,
      streamId: identity2.streamId,
      ...identity2.acquisitionId === undefined ? {} : { acquisitionId: identity2.acquisitionId }
    });
  }
  return {
    owner: (i) => ({ kind: "asset", assetId: i.assetId }),
    pin: (i) => ({
      assetId: i.assetId,
      streamId: i.streamId,
      ...i.acquisitionId === undefined ? {} : { acquisitionId: i.acquisitionId },
      generation: i.generation,
      scenes: i.scenes,
      selectionPolicy: i.selectionPolicy,
      implementationId: i.implementationId,
      maxLongEdge: i.maxLongEdge
    }),
    begin(identity2) {
      const source2 = selected(identity2);
      const metadata3 = scenes.metadata(identity2.scenes);
      if (source2.stream.kind !== "video" || metadata3.owner.kind !== "asset" || metadata3.owner.assetId !== identity2.assetId || !isDeepStrictEqual7(metadata3, identity2.scenes) || !isDeepStrictEqual7(metadata3.source, sourceSceneDescriptor(source2)) || !identity2.generation || !identity2.selectionPolicy || !identity2.implementationId || !Number.isInteger(identity2.maxLongEdge) || identity2.maxLongEdge < 1 || identity2.maxLongEdge > 8192)
        invalid8("Source index identity does not match published scenes");
      return ceil4(fromTime11(source2.durationUs));
    },
    candidate(identity2, candidate, frame, path) {
      const source2 = selected(identity2);
      if (source2.stream.kind !== "video")
        throw new CatalogError("INVALID_EVIDENCE", "Source index requires video geometry");
      validateSourceFrameGeometry(frame, source2.stream, identity2.maxLongEdge);
      if (!Number.isSafeInteger(candidate.requestedSourceUs) || !sourceIndexQueryRanges(source2.track.available).some((r) => r.startUs === candidate.support.startUs && r.endUs === candidate.support.endUs) || candidate.requestedSourceUs < candidate.support.startUs || candidate.requestedSourceUs >= candidate.support.endUs || frame.file !== path || frame.assetId !== identity2.assetId || frame.streamId !== identity2.streamId || frame.acquisitionId !== identity2.acquisitionId || frame.supportDigest !== source2.supportDigest || frame.implementationId !== identity2.implementationId || compare8(fromTime11(frame.sample.originUs), subtract7(fromTime11(0), fromTime11(source2.track.sourceOffsetUs))) !== 0 || frame.maxLongEdge !== identity2.maxLongEdge || frame.atUs !== candidate.requestedSourceUs || frame.requestedSourceUs !== candidate.requestedSourceUs)
        invalid8("Selected source image receipt does not match its candidate");
      validateSceneSampleClock(frame.sample, candidate.requestedSourceUs, frame.actualSourceUs, toSignedTime5(subtract7(fromTime11(0), fromTime11(source2.track.sourceOffsetUs))));
    },
    coverage(identity2, candidate, coverage2, admission) {
      if (coverage2.state === "available") {
        if (!candidate || coverage2.source.startUs < candidate.support.startUs || coverage2.source.endUs > candidate.support.endUs)
          invalid8("Available source coverage requires its supported candidate");
      } else {
        if (candidate)
          invalid8("Unavailable index coverage cannot name an image");
        if (coverage2.basis === "support") {
          if (sourceIndexQueryRanges(selected(identity2).track.available).some((r) => r.startUs < coverage2.source.endUs && r.endUs > coverage2.source.startUs))
            invalid8("Support exclusion overlaps available footage");
        } else {
          const observation2 = coverage2.observation;
          const at = observation2.kind === "scene" ? observation2.point.requestedSourceUs : observation2.frame.atUs;
          if (!Number.isSafeInteger(at) || at < coverage2.source.startUs || at >= coverage2.source.endUs)
            invalid8("Unavailable observation lies outside its index coverage");
          if (observation2.kind === "scene") {
            const page = scenes.sourceWindowPage({
              identity: identity2.scenes,
              range: { startUs: at, endUs: at + 1 },
              limit: 1
            });
            if (!page.chunks[0].coverage.some((point) => isDeepStrictEqual7(point, observation2.point)))
              invalid8("Unavailable observation is not in the pinned scene evidence");
          } else {
            const frame = observation2.frame;
            const source2 = selected(identity2);
            if (!sourceFrameUnavailableSchema.safeParse(frame).success || !isDeepStrictEqual7(frame.selection, source2.selection) || frame.supportDigest !== source2.supportDigest || frame.implementationId !== identity2.implementationId || frame.maxLongEdge !== identity2.maxLongEdge || admission === "produced" && (!frames || !isDeepStrictEqual7(frame, frames.sourceUnavailable({
              ...frame.selection,
              atUs: frame.atUs,
              maxLongEdge: frame.maxLongEdge
            }))))
              invalid8("Unavailable picture observation does not match the selected source request");
          }
        }
      }
      return coverage2.source;
    },
    merge(a, b) {
      if (a.ordinal !== b.ordinal || a.state !== b.state || a.source.endUs !== b.source.startUs || a.state === "available" && b.state === "available" && a.equality !== b.equality || a.state === "unavailable" && b.state === "unavailable" && (a.basis !== b.basis || a.basis === "observation" && b.basis === "observation" && !isDeepStrictEqual7(a.observation, b.observation)))
        return null;
      return { ...a, source: { startUs: a.source.startUs, endUs: b.source.endUs } };
    },
    finish(identity2) {
      selected(identity2);
    },
    retained(identity2, signal) {
      const proof = new SourceIndexStillness(sourceIndexPoints(scenes, identity2, signal));
      return {
        async coverage(frame, coverage2) {
          const equality = await proof.equality(frame, coverage2.source);
          if (coverage2.state === "available" && coverage2.equality === "sampled" && equality !== "sampled")
            invalid8("Sampled source coverage lacks retained stillness evidence");
        },
        close: () => proof.close()
      };
    },
    isDeleting: () => false
  };
}

// apps/macos/tests/index-scale-metrics.test.mjs
function fixture(t) {
  const home = mkdtempSync("/tmp/screenrec-scale-metrics-lock-");
  const database = join6(home, "catalog.sqlite");
  const catalog = new Catalog(database);
  new DerivedCache(catalog, home, () => {});
  const assets = new AssetStore(catalog, home), acquisitions = new AcquisitionStore(catalog);
  const scenes = new SceneEvidenceStore(catalog, assetSceneOwner(assets, acquisitions));
  new ScreenshotIndexStore(catalog, home, sourceIndexDomain((selection) => selectSource(assets, acquisitions, selection), scenes, null));
  const writer = catalog.catalog;
  writer.exec(`INSERT INTO derived_cache(id,ownerKind,ownerId,bytes,touched) VALUES('cache','asset','asset',37,0);
    INSERT INTO screenshot_index_entries(ownerKind,ownerId,generation,ordinal,bytes,candidate,frame,device,inode,modified)
    VALUES('asset','asset','generation',0,81,'{"requestedSourceUs":100}','{}',0,0,0);`);
  t.after(() => {
    catalog.close();
    rmSync(home, { recursive: true });
  });
  return { database, writer };
}
test("scale metrics retry a real competing writer and read its committed snapshot", async (t) => {
  const { database, writer } = fixture(t);
  writer.exec("BEGIN EXCLUSIVE; UPDATE derived_cache SET bytes=52; UPDATE screenshot_index_entries SET bytes=99");
  const release = setTimeout(() => writer.exec("COMMIT"), 125);
  t.after(() => clearTimeout(release));
  assert.deepEqual(await indexScaleMetrics(database), {
    cacheBytes: 52,
    retainedCandidates: 1,
    retainedPngBytes: 99,
    throughSourceUs: 100,
    retainedRowBytes: 27
  });
});
test("bounded lock contention is missing evidence, then the next measurement recovers", async (t) => {
  const { database, writer } = fixture(t);
  writer.exec("BEGIN EXCLUSIVE");
  assert.equal(await indexScaleMetrics(database, 60), null);
  writer.exec("ROLLBACK");
  assert.equal((await indexScaleMetrics(database)).cacheBytes, 37);
});
test("permanent catalog errors are never treated as transient contention", async (t) => {
  const { database, writer } = fixture(t);
  writer.exec("DROP TABLE screenshot_index_entries");
  await assert.rejects(indexScaleMetrics(database), /no such table/);
});
