# Decisions

## Keep the generic recording index domain until its lifetime fixtures are ported
When removing the obsolete recording producer, the generic retained index still has old directory/FD/reclaim/portable tests and an old macOS deletion consumer. Deleting those at the same time would lose contracts or force a large parallel fixture rewrite. This pass explicitly retains that domain and gives its old page consumer an explicit RecordingIndexRecords type. The current source/project processors no longer depend on the recording producer. Sound; high confidence. This is a staged deletion boundary, not compatibility behavior offered by the canonical service.

## Put the shared image receipt in retained-image
An index consumes a PNG file and its byte length/type/dimensions, independent of the recording edit renderer. The existing contained-image validator is the natural owner of these five fields. NativeFrame and IndexRecords now use that direct type; no wrapper/module/format change. Sound; high confidence. The string mediaType stays exactly as before so the existing runtime PNG refusal remains authoritative.

## Require the actual selected-source scene authority
Canonical service and all current producer fixtures configure an asset domain. SceneProcessing now stores that same object directly and no longer exposes a recording option or unsupported optional getter. Its dynamic implementation identity property and selected-source execution remain unchanged. Sound; high confidence.

## Reconcile stale metadata instrumentation to the already-selected batching owner
The original observer matches an obsolete per-stream SQL query, and reportszero reads despite complete output. Current AssetStore performs one all-stream segment query per asset/phase; we observe3 ready phases or1 execute phase rather than6 or2 stream calls. No freshness phase, fact, failure order or bound is removed. Both stale instrumentation reds are retained. Sound; high confidence; this is an observer contract repair, not a performance threshold change.

## Reuse matched current source/project proof for retired old producer rows
The new public source tests transfer missing partial/abandoned/private-generation/long-range oracles. Existing current source/project suites already exercise queue child lifetime, exact coverage/bytes, old project revisions and portable adoption. The recording nearest-future sampling rule and old singleton frame-slot admission are explicitly retired rather than called equivalent to physical source support. Sound; medium confidence at the historical-correspondence boundary; all old declaration dispositions are named and generic raster/pointer evidence remains untouched.
