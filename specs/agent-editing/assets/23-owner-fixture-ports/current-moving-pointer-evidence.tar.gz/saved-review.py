from pathlib import Path
import json,hashlib,collections
b=Path(__file__).parent;root=Path('/Users/david/dev/screen-recorder'); wt=Path('/Users/david/.codex/worktrees/continuous-preview/screen-recorder');case=b/'final';out=case/'output'
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
# Independent fixed saved-data checks; no additional media execution.
records=[json.loads(l)for l in (case/'processes/processes.jsonl').read_text().splitlines()]
spawns=[r for r in records if r['event']=='spawn'];closes=[r for r in records if r['event']=='close'];assert len(spawns)==len(closes)==41
assert {r['pid']for r in spawns}=={r['pid']for r in closes};assert all(r['code']==0 and r['signal']is None for r in closes)
movie=[]
for p in (case/'processes').glob('*native-*.json'):
 r=json.loads(p.read_text());q=r['request'];assert r['response']['ok']
 if q['operation']=='media.renderCompositionMovie':movie.append((p,r))
assert len(movie)==2
prepared=[]
for p,r in movie:
 if r['request']['params'].get('pointers'):
  pp=p.with_name(p.stem+'-pointers.jsonl');rows=[json.loads(l)for l in pp.read_text().splitlines()];prepared=rows
  for i,row in enumerate(rows):
   assert row['sampleAtUs']==1000000+i*100000 and row['requestedSourceUs']==row['sampleAtUs'] and row['captureUs']==row['sampleAtUs']
   assert row['assetId']=='c21c9bc0a04591563532d310d366d8a245a77e1386859f7422f80778b23265e0'
   assert row['sampleTime']=={'value':'16384','timescale':16384} and row['start']==row['sampleTime']
   assert row['end']=={'value':'32768','timescale':16384} and row['clockOffsetUs']==row['sourceToAssetOffsetUs']==0
   assert row['overlay']=={'trail':[],'trailUs':0,'pointer':{'atSourceUs':1000000 if i==0 else 1100000,'x':64 if i==0 else 84,'y':40 if i==0 else 44}}
assert len(prepared)==3
original=json.loads((root/'specs/agent-editing/assets/15-pointer-execution/report.json').read_text())
original_rows=[json.loads(l)for l in (root/'specs/agent-editing/assets/06-pointer-writer/input/full.pointers.jsonl').read_text().splitlines()]
point=original_rows[10]['overlay']['pointer'];white=original['movies'][0]['samples'][0]['whiteCore'];offset=[white['bounds'][i]-point['x' if i%2==0 else 'y']for i in range(4)];assert offset==[1,3,5,12]
summary=json.loads((out/'pointer-operands.json').read_text())
for i,row in enumerate(summary['samples']):
 x,y=(64,40)if i==0 else(84,44);expected=[x+1,y+3,x+5,y+12];assert row['pngCore']['bounds']==row['movieCore']['bounds']==expected
assert (out/'pointer-frame-1.png.rgba').read_bytes()==(out/'pointer-frame-2.png.rgba').read_bytes()
r=json.loads((out/'report.json').read_text());assert r['passed']and r['serviceClosed']and r['control']['rejected']
assert r['admittedSourceSHA']==r['finalAdmittedSourceSHA']==r['sourceSHA']
result={'passed':True,'sourcePins':[pin(wt/'packages/test-harness/editing/moving-pointer-movie.mjs'),pin(root/'apps/macos/tests/fixtures/public-service.mjs'),pin(root/'packages/test-harness/editing/FrameImagePixels.swift')], 'referenceAuthority':{'whiteCriterion':pin(root/'packages/test-harness/editing/pointer-native.mjs'),'unitScaleGeometryReport':pin(root/'specs/agent-editing/assets/15-pointer-execution/report.json'),'originalHotspot':pin(root/'specs/agent-editing/assets/06-pointer-writer/input/full.pointers.jsonl'),'hotspot':point,'whiteBounds':white['bounds'],'offsets':offset},'moviePreparedRows':prepared,'spawnCount':len(spawns),'zeroCloseCount':len(closes),'nativeCount':sum(x['args'][0].endswith('screenrec-native')for x in spawns),'fullPointers':pin(next(p for p,_ in movie if p.with_name(p.stem+'-pointers.jsonl').exists()).with_name(next(p for p,_ in movie if p.with_name(p.stem+'-pointers.jsonl').exists()).stem+'-pointers.jsonl'))}
(b/'saved-review.json').write_text(json.dumps(result,indent=2))
# Current runtime/source bindings are post-run observations, not invented pre-run pins.
production=[]
for d in ['apps/service/dist','apps/cli/dist','packages/core/dist','packages/protocol/dist','packages/client/dist','packages/composition/dist']:
 production.extend(pin(p)for p in sorted((root/d).rglob('*.js')))
for name in ['node','ffmpeg','ffprobe']:
 import shutil
 production.append(pin(Path(shutil.which(name)).resolve()))
production.append(pin(b/'screenrec-native'))
(b/'runtime-postrun-pins.json').write_text(json.dumps(production,indent=2))
print(json.dumps({'passed':True,'spawn':len(spawns),'close':len(closes),'native':result['nativeCount'],'runtimePins':len(production)}))
