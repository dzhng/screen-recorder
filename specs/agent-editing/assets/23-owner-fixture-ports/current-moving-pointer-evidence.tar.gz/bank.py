from pathlib import Path
import tarfile,hashlib,json
b=Path(__file__).parent
items=[];excluded=[]
for p in sorted(b.rglob('*')):
 if 'packaging-initial' in p.parts or not p.is_file() or p.name in ['evidence.tar.gz','archive-manifest.json','archive-pin.json']:continue
 if p.name in ['screenrec-native','frame-pixels']:
  excluded.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 items.append(p)
manifest=[{'member':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in items]
with tarfile.open(b/'evidence.tar.gz','w:gz',dereference=True)as t:
 for p in items:t.add(p,arcname=str(p.relative_to(b)),recursive=False)
(b/'archive-manifest.json').write_text(json.dumps({'members':manifest,'excludedRetainedBinaries':excluded},indent=2))
p=b/'evidence.tar.gz';(b/'archive-pin.json').write_text(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'memberCount':len(items)},indent=2))
print((b/'archive-pin.json').read_text())
