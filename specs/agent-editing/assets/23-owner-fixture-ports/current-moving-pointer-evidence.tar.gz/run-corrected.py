import pathlib,subprocess,os,time,json,hashlib,signal
base=pathlib.Path(__file__).parent;wt=pathlib.Path('/Users/david/.codex/worktrees/continuous-preview/screen-recorder');case=base/'owner-corrected';case.mkdir();out=case/'output'
source=wt/'packages/test-harness/editing/moving-pointer-movie.mjs';(case/'executed-producer.mjs').write_bytes(source.read_bytes())
env=os.environ.copy();env.update(SCREENREC_NATIVE=str(base/'screenrec-native'),SCREENREC_POINTER_MOVIE_EVIDENCE=str(out),POINTER_PROCESS_EVIDENCE=str(case/'processes'),NODE_OPTIONS='--require='+str(base/'observe.cjs'))
argv=['/Users/david/.nvm/versions/node/v24.14.0/bin/node','--test',str(source)]
start=time.time();record={'argv':argv,'cwd':str(wt),'sourceSHA':hashlib.sha256(source.read_bytes()).hexdigest(),'start':start,'boundSeconds':120}
with (case/'stdout').open('wb')as stdout,(case/'stderr').open('wb')as stderr:
 p=subprocess.Popen(argv,cwd=wt,env=env,stdout=stdout,stderr=stderr,start_new_session=True);record['pid']=p.pid;(case/'process.json').write_text(json.dumps(record,indent=2));print(json.dumps({'pid':p.pid,'case':str(case)}),flush=True)
 try:record['exit']=p.wait(timeout=120)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);record['exit']=p.wait();record['deadline']=True
record['end']=time.time();record['elapsed']=record['end']-start;(case/'process.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
