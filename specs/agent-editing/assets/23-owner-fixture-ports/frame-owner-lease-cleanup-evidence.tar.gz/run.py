from pathlib import Path
import subprocess,time,json,sys,os,signal
b=Path(__file__).parent;out=b/sys.argv[1];out.mkdir();argv=sys.argv[2:];start=time.time()
with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:
 p=subprocess.Popen(argv,cwd='/Users/david/dev/screen-recorder',stdout=so,stderr=se,start_new_session=True)
 (out/'process.json').write_text(json.dumps({'argv':argv,'pid':p.pid,'start':start,'boundSeconds':30,'terminationGraceSeconds':2},indent=2))
 expired=False
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 (out/'terminal.json').write_text(json.dumps({'pid':p.pid,'end':time.time(),'exit':code,'waited':True,'deadlineExpired':expired},indent=2))
print(json.dumps({'phase':out.name,'pid':p.pid,'exit':code,'deadlineExpired':expired}));sys.exit(code)
