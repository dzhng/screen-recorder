# Evidence manifest

Repository worktree used for implementation: `/Users/david/.codex/worktrees/personal-release-cutover/screen-recorder` (archived after commit; this path is historical, not the current checkout).
Worktree starting commit for this isolated task: `cadb2e3096bf77526601413f5a19c0d49ec66952`.
Initial implementation commit: `d2e3fc16caff9b7309cf0b2b74a8ad31b4e8fdc1` (`Migrate personal release caller to source and project contracts`).
Follow-up commit: `5c9517bd772855902dfaf1bbf9b3646519f5e612` (`Harden caller journey readiness and support evidence`).
The isolated checkout was archived after the follow-up commit; both commits remain available by hash.

SHA-256 pins (committed files):

- `packages/test-harness/package.json`: `144153666cb679374b41594f1fed91c48331580b4f396a9e72516219d5520c79`
- `packages/test-harness/personal-release.mjs`: `ebb5450c8c776eec8b97166f03d7f1c5b5e5ec84188b25168542e0215379a213`
- `packages/test-harness/personal-release.test.mjs`: `b7dbfff0a52cf3c0a2bb812f3f416b66af73ec706032a8dc7311ab63bb9f1036`
- `packages/test-harness/personal-release-cli-fixture.mjs`: `f25ac3a7029e1862c71b824e3fb724aae0641e519ed8dc2dbe179dbbb3a86016`

Logs and qualification are in `final-test.log`, `build.log`, `red-green.md`, and `followup-red-green.md` beside this file. The latest targeted test and dependency-aware build logs are `followup-test.log` and `followup-build.log`.
