# Personal-release caller-cutover test record

Worktree: `/Users/david/.codex/worktrees/personal-release-cutover/screen-recorder`
Baseline: `cadb2e3096bf77526601413f5a19c0d49ec66952`

The fake CLI validates each input against the current `operationSchema` and records each request.
It does not contact an installed service or the user's library and returns controlled fixture data.

## Red/green records

- Before the edit-plan gate, `node --test packages/test-harness/personal-release.test.mjs` failed the new missing-intent case: the script called `recording.latest` and received `FIXTURE_SENTINEL` instead of rejecting before CLI use. After the gate, the case passed and the call trace did not exist.
- Before the source/project migration, the controlled positive journey reached `processing.status`, which the current `operationSchema` rejected as `INVALID_REQUEST`. After migration to `job.get`, source-owned transcript/index/media selectors, explicit project authoring, and project-owned selectors, the journey passed.
- Before moving plan preflight, `node --test --test-name-pattern='asset-clock cuts outside' packages/test-harness/personal-release.test.mjs` failed the no-expensive-work assertion: transcript/index/frame/audio operations had already run. After moving support and timeline validation to immediately after acquisition/asset metadata, the assertion passed and no transcript/index/frame/audio operation was recorded.
- Before moving plan preflight, `node --test --test-name-pattern='overlapping caller cuts' packages/test-harness/personal-release.test.mjs` failed the same no-expensive-work assertion. After the move, overlapping mapped ranges are rejected before transcript/index/frame/audio work.
- The out-of-support fixture uses the acquisition owner's normalized asset-clock binding: video available `[0, 8,000,000)`, narration available `[0, 7,900,000)`, with narration `sourceToAssetOffsetUs = -100,000`. A plan over asset `[7,900,000, 8,000,000)` is rejected before project creation. A valid boundary plan over asset `[7,800,000, 7,900,000)` is accepted and maps to project `[7,900,000, 8,000,000)`. An intentionally wrong offset-adjusted availability comparison made this valid positive case fail; restoring direct asset-clock comparison made it pass. An earlier exploratory red run used narration availability `[0,8,000,000)` and therefore encoded the wrong premise; it is not evidence of a product defect.
- Before the preview fix, the controlled journey recorded two `preview.get` calls, one without `--output`. The new assertion failed `2 !== 1`; the media call now waits and drains the preview in one request.

## Final verification

`node --test packages/test-harness/personal-release.test.mjs`: 5 passed, 0 failed.

`bunx turbo build --filter='@screenrec/test-harness...'`: 5 dependency/package build tasks passed.

Also passed: Node syntax checks for the script and fake CLI; `oxlint` on the three touched JavaScript files; `oxfmt --check` on those files and `package.json`; and `git diff --check`.

The standalone `bun run --cwd packages/test-harness build` was initially tried before building workspace dependencies and failed to resolve `@screenrec/core/timeline` and `@screenrec/core/presentation-time`. The dependency-aware Turbo build above passed, including the test-harness build, and is the valid build evidence.

No installed-service, personal-library, capture, model, actual rendering, or human listening acceptance was run.
