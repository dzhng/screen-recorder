# Caller hardening follow-up

This follow-up is layered on implementation commit `d2e3fc16caff9b7309cf0b2b74a8ad31b4e8fdc1` and committed as `5c9517bd772855902dfaf1bbf9b3646519f5e612`.

## Owner contracts consulted

- `packages/core/src/jobs.ts` defines the job terminal state `canceled`. `apps/service/src/package-registry.ts` defines package admission states including `cleanup_failed` and `closed`. Readiness now fails immediately for those real states; the unsupported `cancelled` spelling was removed.
- `apps/service/src/project-service.ts` returns per-item `ok:false,error` for failed `frame.batch` items. The CLI drains batch deliveries and preserves those item errors, so `media()` now rejects them on the first response instead of polling without progress.
- `packages/core/src/frame-inspection.ts` resolves source frames through selected-source support. The fixture uses disjoint video support `[0,2s)` and `[6,8s)`. The caller samples the midpoint of its first admitted support interval at 1s; the fake CLI validates the input schema and returns an item failure for unsupported samples.
- `packages/core/src/audio-inspection.ts` permits an `audio.get` range through the selected stream duration and returns exact `published.audio.unavailable` ranges computed from selected-source support. It does not require the whole requested range to be supported. The caller retains its requested ±1.5s audition context and records the owner-provided unavailable ranges without interpreting gaps as silence or editing them.

## Red/green records

- Per-frame item failure: before the fix, the harness retried after `{ok:false,error:{code:"FRAME_ITEM_ERROR"}}` and only stopped on the fake's second-poll guard. The regression asserted the error code and one request; it passed after immediate item-error refusal.
- Canceled source job: before the fix, `job.get` was called twice (the second controlled response was a failure guard). It now refuses `canceled` after one request.
- Failed package cleanup: before the fix, `package.status` was called twice and the journey reported the guard's generic failure. It now refuses `cleanup_failed` on the first response. `closed` is also a package-registry terminal state.
- Disjoint video support: the old whole-stream midpoint request was 4s even though 4s was unsupported. The new assertion observed actual `[4,000,000]` versus expected `[1,000,000]`; the source-support midpoint now passes.
- Audio audition context: an intermediate clamp proposal produced `[5,000,000,6,900,000)` and failed the new expectation of `[3,800,000,6,900,000)` plus unavailable `[4,000,000,5,000,000)`. Review of the audio owner showed that preserving the wider range and reporting its unavailable interval is the contract. This red result rejects the proposed clamp policy; it is not evidence of a product defect.
- Console copy: the new result assertion failed on the prior “keep or undo the edits” instruction. Completion output now points to `journey.json` without making an editorial assignment.

## Final checks

- `node --test packages/test-harness/personal-release.test.mjs`: 8 passed, 0 failed.
- `bunx turbo build --filter='@screenrec/test-harness...'`: five package/dependency build tasks passed.
- Passed Node syntax checks, `oxlint`, `oxfmt --check`, and `git diff --check`.
- All behavior tests used the schema-validating fake CLI. No service, library, installed release, capture, model, renderer, or real media was invoked.
