# Fixture correction choices

All choices are sound; none requires a user decision. The work changes no production behavior.

## Native cancellation proves release before replacement — high confidence

When cancel arrives while the first finalizing report is held, publication has not begun. Native remembers cancellation, closes input, and releases its take. The native reply is the finalizing lifecycle event; the real service separately authors canceled state and removes the donor directory. This test uses a fake service, so it must not expect that service-owned deletion. The correction keeps the closed journal and proves its bytes cannot change after the next take begins. Added idle/null-owner checks and the replacement source identity make release and noninterference explicit. The alternative of merely accepting either complete or finalizing would hide a wrong race outcome. The task prescribed this branch; the particular public-state checks were local discretion. Future tests must distinguish device release from durable service cancellation.

## Seed private ownership at creation — high confidence

The restart test creates a target recording directory, marks its catalog row for deletion, then starts the real service. Native removal refuses directories that are not private (0700). All directories newly created by this fixture's existing file helper now use 0700, including intermediate recording parents. It does not chmod pre-existing paths or weaken native refusal. The task prescribed private directories; using the one existing helper avoids a second directory owner. Unrelated sentinels keep their byte-preservation checks.

## Reuse exact retained reds and avoid new live capture — high confidence

The full default gate already demonstrated all three original failures. Those complete logs are copied into this bank before edits. Only the generated deletion/restart fixture was rerun, against the hashed app/service/worker candidate; it needs no device acquisition. The two live-capture fixtures remain explicitly unrun. Existing real-controller injected-input cancellation checks passed in that same default gate and support the branch interpretation, but are not labeled fresh proof of the edited app fixture. The task explicitly required this boundary. No thresholds, deadlines, skips, or production hooks changed.
