@preconcurrency import AVFoundation
import CryptoKit
import Foundation
import ObjectiveC
import Synchronization
@testable import ScreenRecorderWire

private final class Pumps {
    struct Event: Codable {
        let phase: String
        let role: String
        let writerStatus: Int
        let accepted: Bool?
        let audioAppends: Int
        let videoAppends: Int
        let audioFinished: Bool
        let videoFinished: Bool
        let error: String?
    }
    struct State: @unchecked Sendable {
        var writer: AVAssetWriter?
        var task: Task<Data, Never>?
        var roles: [ObjectIdentifier: String] = [:]
        var audio = 0, video = 0
        var audioFinished = false, videoFinished = false
        var active = 0, fault: ContinuousClock.Instant?
        var callerCanceledAtFault: Bool?
        var faultReturned: Bool?
        var logError: String?
        var events: [Event] = []
    }
    final class Counter: Sendable {
        let state = Mutex(State())
        let log: FileHandle
        init(_ log: FileHandle) { self.log = log }
        func record(_ phase: String, _ role: String, _ writer: AVAssetWriter, _ accepted: Bool? = nil) {
            state.withLock { value in
                let event = Event(phase: phase, role: role, writerStatus: writer.status.rawValue,
                    accepted: accepted, audioAppends: value.audio, videoAppends: value.video,
                    audioFinished: value.audioFinished, videoFinished: value.videoFinished,
                    error: writer.error?.localizedDescription)
                value.events.append(event)
                do { try log.write(contentsOf: JSONEncoder().encode(event) + Data([10])) }
                catch { value.logError = String(describing: error) }
            }
        }
    }
    private let counter: Counter
    private var methods: [(Method, IMP, IMP)] = []
    init(directory: URL) throws {
        let file = directory.appendingPathComponent("sdk-prefix.jsonl")
        precondition(FileManager.default.createFile(atPath: file.path, contents: nil))
        counter = Counter(try FileHandle(forWritingTo: file))
        let c = counter
        let startSelector = #selector(AVAssetWriter.startWriting)
        let appendSelector = #selector(AVAssetWriterInput.append(_:))
        let finishSelector = #selector(AVAssetWriterInput.markAsFinished)
        func method(_ type: AnyClass, _ selector: Selector, _ expected: String) throws -> Method {
            guard let m = class_getInstanceMethod(type, selector), let e = method_getTypeEncoding(m) else {
                throw NSError(domain: "Missing SDK observation method", code: 1)
            }
            let encoding = String(cString: e)
            print(NSStringFromSelector(selector), encoding)
            guard encoding == expected else { throw NSError(domain: "Unexpected ABI: \(encoding)", code: 2) }
            return m
        }
        let start = try method(AVAssetWriter.self, startSelector, "B16@0:8")
        let append = try method(AVAssetWriterInput.self, appendSelector, "B24@0:8^{opaqueCMSampleBuffer=}16")
        let finish = try method(AVAssetWriterInput.self, finishSelector, "v16@0:8")
        typealias Start = @convention(c) (AnyObject, Selector) -> Bool
        typealias Append = @convention(c) (AnyObject, Selector, CMSampleBuffer) -> Bool
        typealias Finish = @convention(c) (AnyObject, Selector) -> Void
        let originalStart = method_getImplementation(start), originalAppend = method_getImplementation(append), originalFinish = method_getImplementation(finish)
        let forwardStart = unsafeBitCast(originalStart, to: Start.self)
        let forwardAppend = unsafeBitCast(originalAppend, to: Append.self)
        let forwardFinish = unsafeBitCast(originalFinish, to: Finish.self)
        let startBlock: @convention(block) (AVAssetWriter) -> Bool = { writer in
            c.state.withLock { $0.active += 1 }; defer { c.state.withLock { $0.active -= 1 } }
            let accepted = forwardStart(writer, startSelector)
            let url = writer.outputURL
            if accepted, url.lastPathComponent == "movie.mp4",
                url.deletingLastPathComponent().lastPathComponent.hasPrefix(".screenrec-output-"),
                url.deletingLastPathComponent().deletingLastPathComponent() == directory {
                c.state.withLock { value in
                    value.writer = writer
                    value.roles = Dictionary(uniqueKeysWithValues: writer.inputs.map { input in
                        (ObjectIdentifier(input), input.mediaType == .video ? "video" : input.mediaType == .audio ? "audio" : "other")
                    })
                }
                c.record("started", "outer", writer, accepted)
            }
            return accepted
        }
        let appendBlock: @convention(block) (AVAssetWriterInput, CMSampleBuffer) -> Bool = { input, sample in
            c.state.withLock { $0.active += 1 }; defer { c.state.withLock { $0.active -= 1 } }
            let selected = c.state.withLock { value -> (AVAssetWriter, String)? in
                guard let writer = value.writer, let role = value.roles[ObjectIdentifier(input)] else { return nil }
                return (writer, role)
            }
            guard let (writer, role) = selected else { return forwardAppend(input, appendSelector, sample) }
            c.record("append-enter", role, writer)
            let fault = c.state.withLock { value in
                guard role == "video", value.audio > 0, !value.audioFinished, !value.videoFinished,
                    writer.status == .writing, value.fault == nil, value.task != nil else { return false }
                value.fault = .now
                value.callerCanceledAtFault = value.task?.isCancelled
                return true
            }
            if fault { c.record("fault-before-cancelWriting", role, writer); writer.cancelWriting(); c.record("fault-after-cancelWriting", role, writer) }
            let accepted = forwardAppend(input, appendSelector, sample)
            c.state.withLock { value in
                if accepted { if role == "audio" { value.audio += 1 }; if role == "video" { value.video += 1 } }
                if fault { value.faultReturned = accepted }
            }
            c.record("append-return", role, writer, accepted)
            return accepted
        }
        let finishBlock: @convention(block) (AVAssetWriterInput) -> Void = { input in
            c.state.withLock { $0.active += 1 }; defer { c.state.withLock { $0.active -= 1 } }
            forwardFinish(input, finishSelector)
            let selected = c.state.withLock { value -> (AVAssetWriter, String)? in
                guard let writer = value.writer, let role = value.roles[ObjectIdentifier(input)] else { return nil }
                if role == "audio" { value.audioFinished = true }; if role == "video" { value.videoFinished = true }
                return (writer, role)
            }
            if let (writer, role) = selected { c.record("finished", role, writer) }
        }
        let blocks = [(start, originalStart, imp_implementationWithBlock(startBlock)),
            (append, originalAppend, imp_implementationWithBlock(appendBlock)),
            (finish, originalFinish, imp_implementationWithBlock(finishBlock))]
        for (m, _, replacement) in blocks { method_setImplementation(m, replacement) }
        methods = blocks
    }
    func attach(_ task: Task<Data, Never>) { counter.state.withLock { $0.task = task } }
    var state: State { counter.state.withLock { $0 } }
    func restore() {
        precondition(state.active == 0)
        for (m, original, replacement) in methods.reversed() {
            precondition(method_getImplementation(m) == replacement)
            method_setImplementation(m, original)
            precondition(method_getImplementation(m) == original)
            imp_removeBlock(replacement)
        }
        try? counter.log.close()
    }
}

@main struct Main {
    static func main() async throws {
        let data = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
        let params = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let output = URL(fileURLWithPath: params["output"] as! String), directory = output.deletingLastPathComponent()
        let assets = params["assets"] as! [[String: Any]]
        let paths = Set(assets.map { $0["path"] as! String } + [params["frames"] as! String]).sorted()
        func hashes() throws -> [String: String] {
            try Dictionary(uniqueKeysWithValues: paths.map { ($0, SHA256.hash(data: try Data(contentsOf: URL(fileURLWithPath: $0))).map { String(format: "%02x", $0) }.joined()) })
        }
        let before = try hashes()
        let line = String(data: try JSONSerialization.data(withJSONObject: ["id":"pump-fault", "operation":"media.renderCompositionMovie", "params":params]),encoding:.utf8)!
        let observer = try Pumps(directory: directory)
        let work = Task { await NativeWire.respond(to: line) }; observer.attach(work)
        let reply = await work.value
        let returned = ContinuousClock.now, state = observer.state
        observer.restore()
        let after = try hashes()
        let elapsed = state.fault.map { $0.duration(to: returned).components }
        let seconds = elapsed.map { Double($0.seconds) + Double($0.attoseconds) / 1e18 }
        let record: [String: Any] = ["faultTriggered":state.fault != nil, "faultToReplySeconds":seconds as Any? ?? NSNull(),
            "faultSDKReturned":state.faultReturned as Any? ?? NSNull(), "callerCanceledAtFault":state.callerCanceledAtFault as Any? ?? NSNull(),
            "callerCanceledAtReply":work.isCancelled, "sdkCallsActiveAtReply":state.active,
            "sourceBefore":before,"sourceAfter":after,"outputExists":FileManager.default.fileExists(atPath:output.path),
            "remaining":try FileManager.default.contentsOfDirectory(atPath:directory.path), "methodRestored":true,
            "logError":state.logError as Any? ?? NSNull()]
        try reply.write(to: directory.appendingPathComponent("response.json"))
        try JSONSerialization.data(withJSONObject:record,options:[.prettyPrinted,.sortedKeys]).write(to:directory.appendingPathComponent("observation.json"))
        print("PROBE", String(data:reply,encoding:.utf8)!, record)
    }
}
