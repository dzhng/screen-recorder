# Capture lifetime fixture decisions

**Sound, high confidence — observe a turn while recovery is held.** Removing the real shutdown await initially escaped the inherited microtask assertion because close had not yet resumed. An event-loop turn gives a prematurely returning close the chance to settle while the controlled recovery worker remains held. This is an ordering check, with no sleep or timing threshold. The same missing-await fault now fails; original source restores green. The test releases the worker in finally before draining the service, including on failure.

**Sound, medium confidence — local source-only JobTargets policy.** The single queue case needs a settled capture source, not an editing revision. Its inline fixture domain policy validates actual CaptureStore availability/deletion/capturing and returns revisionId:null. No generic production helper or compatibility adapter was added for one fixture. This deliberately excludes the obsolete recording-edit branch; project jobs and editing behavior remain in their own owners.

**Sound, high confidence — null editing identity.** Both complete and interrupted source-finalization races retain all old state/duration/sentinel assertions. They now explicitly expect currentRevisionId:null, because actual CaptureStore makes no project/revision. The field itself is not hidden or removed; source/schema purge remains a separate pass.

No new production architecture, bound, recipe, retry, data format or user-only choice was introduced. Existing test declaration/parameter rows all remain.
