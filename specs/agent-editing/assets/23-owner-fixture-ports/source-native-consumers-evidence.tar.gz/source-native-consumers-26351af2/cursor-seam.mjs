import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {selectSourceMetadata} from '/Users/david/.codex/worktrees/source-native-consumers/screen-recorder/packages/core/dist/source-selection.js';
import {fromTime,rational,round,subtract} from '/Users/david/.codex/worktrees/source-native-consumers/screen-recorder/packages/composition/dist/index.js';
const wt='/Users/david/.codex/worktrees/source-native-consumers/screen-recorder';
const bank='/Users/david/.cache/screen-recorder/verification/source-native-consumers-26351af2';
const folder=path.join(bank,'cursor-seam');fs.mkdirSync(folder,{recursive:true});
const pins=JSON.parse(fs.readFileSync(path.join(bank,'native-source-pins.json')));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const row of pins.files)assert.equal(sha(fs.readFileSync(path.join(wt,row.path))),row.sha256);
assert.equal(sha(fs.readFileSync(pins.binary)),pins.binarySHA256);
const sourceFile=path.join(wt,'scripts/cursor-geometry-lab.mjs');
const source=fs.readFileSync(sourceFile,'utf8');
const seam=source.slice(source.indexOf('function native(operation, params) {'),source.indexOf('/** Sorted the same way'));
assert.ok(seam.includes('media.sourceFrame')&&!seam.includes('--probe'));
const make=new Function('spawnSync','worker','evidence','output','join','selectSourceMetadata','fromTime','rational','round','subtract',seam+'\nreturn {decodeFrame,metadata,track};');
const corpus=path.join(wt,'specs/agent-editing/assets/00-corpus/a.mov');
const before=sha(fs.readFileSync(corpus));let ordinal=0;
function run(command,args,options={}){
 const key=String(ordinal++).padStart(3,'0');
 const result=spawnSync(command,args,options);
 fs.writeFileSync(path.join(folder,key+'.command.json'),JSON.stringify({command,args,input:options.input,status:result.status,signal:result.signal,error:String(result.error??'')},null,2));
 if(result.stdout?.length)fs.writeFileSync(path.join(folder,key+'.stdout'),result.stdout);
 if(result.stderr?.length)fs.writeFileSync(path.join(folder,key+'.stderr'),result.stderr);
 return result;
}
const results=[];
for(const offset of [0,1250000]){
 const output=path.join(folder,'offset-'+offset);fs.mkdirSync(path.join(output,'source'),{recursive:true});
 const movie=path.join(output,'source/video.mov');
 if(offset===0)fs.copyFileSync(corpus,movie);
 else {
  const encoded=run('ffmpeg',['-v','error','-nostdin','-i',corpus,'-map','0:v:0','-c','copy','-output_ts_offset',String(offset/1000000),movie],{timeout:30000});
  assert.equal(encoded.status,0,String(encoded.stderr));
 }
 const caller=make(run,pins.binary,{capture:{durationUs:2000000+offset}},output,path.join,selectSourceMetadata,fromTime,rational,round,subtract);
 const frame=caller.decodeFrame(500000+offset,path.join(output,'frame.png'));
 fs.writeFileSync(path.join(output,'operands.json'),JSON.stringify({metadata:caller.metadata,track:caller.track,frame},null,2));
 assert.equal(caller.metadata.originUs,offset);
 assert.equal(frame.requestedSourceUs,500000+offset);
 assert.equal(frame.actualSourceUs,500000+offset);
 assert.equal(frame.width,160);assert.equal(frame.height,96);
 results.push({offset,frame,pngSHA256:sha(fs.readFileSync(frame.file))});
}
assert.deepEqual(fs.readFileSync(results[0].frame.file),fs.readFileSync(results[1].frame.file));
assert.equal(sha(fs.readFileSync(corpus)),before);
fs.writeFileSync(path.join(folder,'result.json'),JSON.stringify({source:sourceFile,sourceSHA256:sha(source),seamSHA256:sha(seam),corpusSHA256:before,results,scope:'Exact current helper extracted without executing capture/build/top-level lab; real frozen native probe/sourceFrame; offset remux copies encoded video'},null,2));
console.log('PASS exact cursor helper preserves 160x96 PNG pixels and capture-clock labels at origins 0 and 1250000; no capture or lab launch');
