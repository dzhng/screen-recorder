const fs = require('node:fs');
const fsp = require('node:fs/promises');
const cp = require('node:child_process');
const path = require('node:path');
const crypto = require('node:crypto');
const { syncBuiltinESMExports } = require('node:module');
const folder = path.join(process.env.PROOF_BANK, process.env.PROOF_PHASE);
fs.mkdirSync(folder, { recursive: true });
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const log = event => fs.appendFileSync(path.join(folder, `events-${process.pid}.jsonl`), JSON.stringify(event) + '\n');
let sequence = 0;
function retain(file, name) {
  try {
    const data = fs.readFileSync(file);
    const row = { file, bytes: data.length, sha256: sha(data) };
    if (data.length <= 2 * 1024 * 1024) {
      row.saved = name;
      fs.writeFileSync(path.join(folder, name), data);
    }
    return row;
  } catch (error) { return { file, error: String(error) }; }
}
const originalSpawn = cp.spawn;
cp.spawn = function(command, args, options) {
  const child = originalSpawn.apply(this, arguments);
  if (command !== process.env.SCREENREC_NATIVE) return child;
  const key = `${process.pid}-${sequence++}`;
  let input = '', stdout = '', stderr = '';
  const end = child.stdin.end;
  child.stdin.end = function(chunk) {
    if (typeof chunk === 'string' || Buffer.isBuffer(chunk)) input += chunk.toString();
    return end.apply(this, arguments);
  };
  child.stdout.on('data', chunk => { stdout += chunk.toString(); });
  child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
  child.on('close', (code, signal) => {
    fs.writeFileSync(path.join(folder, key + '.request.jsonl'), input);
    fs.writeFileSync(path.join(folder, key + '.stdout'), stdout);
    fs.writeFileSync(path.join(folder, key + '.stderr'), stderr);
    let request;
    try { request = JSON.parse(input); } catch {}
    const params = request?.params;
    const files = [...new Set([params?.path, params?.asset?.path, params?.source?.source, params?.source, params?.output].filter(x => typeof x === 'string'))].map((file,i) => retain(file, `${key}.file-${i}`));
    let fault = null;
    if (process.env.PROOF_FAULT === 'owned-video-corrupt' && params?.output?.endsWith('/a.mov.png')) {
      const bytes = fs.readFileSync(params.output); bytes[bytes.length - 1] ^= 1; fs.writeFileSync(params.output, bytes); fault = retain(params.output, key + '.fault-output');
    }
    if (process.env.PROOF_FAULT === 'audio-truncate' && request?.operation === 'media.sourceAudio' && params?.output?.endsWith('/wav.wav')) {
      fs.truncateSync(params.output, 44); fault = retain(params.output, key + '.fault-output');
    }
    log({ key, command, args, pid: child.pid, code, signal, request, files, fault });
  });
  return child;
};
const originalSpawnSync = cp.spawnSync;
cp.spawnSync = function(command, args, options) {
  const result = originalSpawnSync.apply(this, arguments);
  const key = `${process.pid}-${sequence++}`;
  if (result.stdout?.length) fs.writeFileSync(path.join(folder, key + '.stdout'), result.stdout);
  if (result.stderr?.length) fs.writeFileSync(path.join(folder, key + '.stderr'), result.stderr);
  log({ key, command, args, status: result.status, signal: result.signal, error: String(result.error ?? '') });
  return result;
};
const originalRm = fsp.rm;
fsp.rm = async function(target, options) {
  if (typeof target === 'string' && path.basename(target).startsWith('screenrec-asset-native-')) {
    const key = `${process.pid}-${sequence++}`;
    const files = [];
    function walk(dir) {
      for (const item of fs.readdirSync(dir, {withFileTypes:true})) {
        const file = path.join(dir,item.name);
        if (item.isDirectory()) walk(file);
        else if (item.isFile()) files.push(retain(file, `${key}.retained-${files.length}`));
      }
    }
    walk(target); log({ key, cleanup:target, files });
  }
  return originalRm.apply(this, arguments);
};
syncBuiltinESMExports();
