from pathlib import Path
import sys,subprocess,os,json,time,hashlib
bank=Path(__file__).parent;wt=Path('/Users/david/.codex/worktrees/source-native-consumers/screen-recorder')
phase=sys.argv[1];pattern=sys.argv[2];fault=sys.argv[3] if len(sys.argv)>3 else ''
folder=bank/phase;folder.mkdir(exist_ok=False)
pins=json.loads((bank/'native-source-pins.json').read_text())
for row in pins['files']:assert hashlib.sha256((wt/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert hashlib.sha256(Path(pins['binary']).read_bytes()).hexdigest()==pins['binarySHA256']
args=['node','--require',str(bank/'observe.cjs'),'--test','--test-concurrency=1','--test-name-pattern='+pattern,'packages/test-harness/editing/assets-native.test.mjs']
env={**os.environ,'SCREENREC_NATIVE':pins['binary'],'PROOF_BANK':str(bank),'PROOF_PHASE':phase,'PROOF_FAULT':fault}
start=time.time();p=subprocess.Popen(args,cwd=wt,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(folder/'process.json').write_text(json.dumps({'argv':args,'pid':p.pid,'start':start,'fault':fault,'sourceSHA256':hashlib.sha256((wt/'packages/test-harness/editing/assets-native.test.mjs').read_bytes()).hexdigest()},indent=2)+'\n')
try:output,_=p.communicate(timeout=90)
except subprocess.TimeoutExpired:p.kill();output,_=p.communicate();raise
finally:
 if p.returncode is not None:(folder/'terminal.json').write_text(json.dumps({'exit':p.returncode,'end':time.time(),'seconds':time.time()-start,'waited':True},indent=2)+'\n')
(folder/'terminal.log').write_bytes(output);print(output.decode(),end='');sys.exit(p.returncode)
