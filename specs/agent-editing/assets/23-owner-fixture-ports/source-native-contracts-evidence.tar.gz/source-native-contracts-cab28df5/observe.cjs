const fs = require('node:fs');
const cp = require('node:child_process');
const path = require('node:path');
const crypto = require('node:crypto');
const { syncBuiltinESMExports } = require('node:module');
const bank = process.env.PROOF_BANK, phase = process.env.PROOF_PHASE;
if (bank && phase) {
  const folder = path.join(bank, phase);
  fs.mkdirSync(folder, { recursive: true });
  const sha = data => crypto.createHash('sha256').update(data).digest('hex');
  const log = value => fs.appendFileSync(path.join(folder, `events-${process.pid}.jsonl`), JSON.stringify(value) + '\n');
  const originalSpawn = cp.spawnSync, originalRemove = fs.rmSync;
  let sequence = 0;
  cp.spawnSync = function(command, args, options = {}) {
    const index = `${process.pid}-${sequence++}`;
    const input = options.input;
    const forwarded = { ...options };
    if (process.env.PROOF_FAULT === 'ignore-nested-field' && typeof input === 'string' && input.includes('media.sourceFrame')) {
      forwarded.input = input.trim().split('\n').map(line => {
        const request = JSON.parse(line);
        if (request.params?.asset?.extra) delete request.params.asset.extra;
        return JSON.stringify(request);
      }).join('\n') + '\n';
    }
    const target = command === 'ffmpeg' && args.includes('lavfi') ? args.at(-1) : null;
    const fixtureKey = target && sha(JSON.stringify([command, args.slice(0,-1), options.input ?? null]));
    const cached = fixtureKey && path.join(bank, 'fixtures', fixtureKey);
    let result, reused = false;
    if (cached && fs.existsSync(cached)) {
      fs.copyFileSync(cached, target); reused = true;
      result = { status: 0, signal: null, error: undefined, stdout: options.encoding ? '' : Buffer.alloc(0), stderr: options.encoding ? '' : Buffer.alloc(0) };
    } else {
      result = originalSpawn(command, args, forwarded);
      if (cached && result.status === 0) {
        fs.mkdirSync(path.dirname(cached), { recursive: true }); fs.copyFileSync(target, cached);
      }
    }
    const nativeCall = (command.endsWith('screenrec-native') || args.some(x => typeof x === 'string' && x.endsWith('screenrec-native')));
    if (nativeCall && result.stdout != null) fs.writeFileSync(path.join(folder,`${index}.native.stdout`),result.stdout);
    if (nativeCall && typeof result.stdout === 'string' && process.env.PROOF_FAULT === 'grid-color') {
      try {
        const reply = JSON.parse(result.stdout);
        if (reply.data?.samples?.length === 52) {
          const sample = reply.data.samples[25]; const bytes = Buffer.from(sample.rgbBase64,'base64');
          bytes[0] = 0; sample.rgbBase64 = bytes.toString('base64');
          result.stdout = JSON.stringify(reply) + '\n';
        }
      } catch {}
    }
    if (nativeCall && typeof result.stdout === 'string' && process.env.PROOF_FAULT === 'budget-error') {
      try { const reply=JSON.parse(result.stdout); if(reply.error?.code==='LIMIT_EXCEEDED') { reply.error.code='NATIVE_DECODE_FAILED';result.stdout=JSON.stringify(reply)+'\n';} } catch {}
    }
    if (nativeCall && typeof result.stdout === 'string' && process.env.PROOF_FAULT === 'descriptor-bytes') {
      try {const request=JSON.parse(forwarded.input); const reply=JSON.parse(result.stdout);
        const source=request.params.asset?.path??request.params.source?.source;
        if(reply.ok && source==='/dev/fd/3') {
          const output=request.params.output;
          if(output.startsWith('/dev/fd/')) { const fd=options.stdio[Number(output.slice(8))];fs.writeSync(fd,Buffer.from([0]),0,1,0); }
          else {const fd=fs.openSync(output,'r+');try{fs.writeSync(fd,Buffer.from([0]),0,1,0);}finally{fs.closeSync(fd);}}
        }
      } catch(e) {log({controlError:String(e)});throw e;}
    }
    for(const kind of ['stdout','stderr']) if(result[kind] != null) fs.writeFileSync(path.join(folder,`${index}.${kind}`),result[kind]);
    if(input!=null)fs.writeFileSync(path.join(folder,`${index}.input`),input);
    if(forwarded.input!==input)fs.writeFileSync(path.join(folder,`${index}.forwarded-input`),forwarded.input);
    const fds=(options.stdio??[]).map((fd,i)=> {if(typeof fd!=='number')return null;try {const s=fs.fstatSync(fd,{bigint:true});return {childFd:i,dev:String(s.dev),ino:String(s.ino),bytes:String(s.size)};}catch{return null;}}).filter(Boolean);
    log({index,command,args,status:result.status,signal:result.signal,error:result.error?.message,reusedFixture:reused,fixtureKey,fixtureSHA256:cached&&fs.existsSync(cached)?sha(fs.readFileSync(cached)):null,descriptors:fds});
    return result;
  };
  fs.rmSync = function(target, options) {
    if(typeof target==='string' && target.includes('source-') || typeof target==='string' && target.includes('descriptor-')) {
      try {
        const save=(file)=>{const stat=fs.lstatSync(file);if(stat.isDirectory()){for(const leaf of fs.readdirSync(file))save(path.join(file,leaf));return;}if(!stat.isFile())return;
          const data=fs.readFileSync(file), digest=sha(data);log({artifact:file,bytes:data.length,sha256:digest});
          if(data.length<=2*1024*1024){const out=path.join(folder,'artifacts',digest);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,data);}
        }; if(fs.existsSync(target))save(target);
      }catch(e){log({captureError:String(e),target});}
    }
    return originalRemove(target,options);
  };
  syncBuiltinESMExports();
}
