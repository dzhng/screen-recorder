from pathlib import Path
import subprocess,os,sys,time,json,hashlib
bank=Path(__file__).parent;w=Path('/Users/david/.codex/worktrees/source-native-contracts/screen-recorder');label,file,pattern,*fault=sys.argv[1:];folder=bank/label;folder.mkdir(exist_ok=True)
worker='/Users/david/.codex/artifacts/screen-recorder/frozen-native-workers/8a0c7732f3c1f99e074048f2ac3b8b29beb613462fb5ce769a134b1cbfdea186/screenrec-native'
files=['helpers/mac/Tests/source-frame.test.mjs','helpers/mac/Tests/source-visual-samples.test.mjs','helpers/mac/Tests/descriptor-media.test.mjs'];pins=[]
for f in files:
 data=(w/f).read_bytes();out=folder/'sources'/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);pins.append({'path':f,'sha256':hashlib.sha256(data).hexdigest()})
env={**os.environ,'SCREENREC_NATIVE':worker,'PROOF_BANK':str(bank),'PROOF_PHASE':label,'NODE_OPTIONS':'--require='+str(bank/'observe.cjs')}
if fault:env['PROOF_FAULT']=fault[0]
argv=['node','--test','--test-concurrency=1','--test-name-pattern='+pattern,*file.split(',')]
with (folder/'stdout').open('w') as out,(folder/'stderr').open('w') as err:
 start=time.time();child=subprocess.Popen(argv,cwd=w,env=env,stdout=out,stderr=err);(folder/'process.json').write_text(json.dumps({'argv':argv,'pid':child.pid,'start':start,'pins':pins,'binary':worker,'control':fault,'observer':'../observe.cjs'},indent=2)+'\n')
 try:code=child.wait(timeout=90)
 except subprocess.TimeoutExpired:child.terminate();code=child.wait(timeout=5)
 (folder/'terminal.json').write_text(json.dumps({'exit':code,'end':time.time(),'seconds':time.time()-start,'waited':True})+'\n')
print(json.dumps({'phase':label,'exit':code,'seconds':time.time()-start}))
