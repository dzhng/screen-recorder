# Actual project package boundary ports

- V3162: actual current package input directory is substituted just before native archive.write, after input files are copied. Held descriptors stay owned but external publication refuses a changed locator. Recovery refuses the foreign substitute without deleting its sentinel; restoring original identity permits cleanup.
- V3219: actual current copyImportedFile reads selected asset bytes through FileHandle, then the external filesystem observer mutates that inode before copying completes. Changed source is refused, no ZIP is published, private cleanup remains possible and the intentional source mutation remains observable.
- V3063: actual archive writer survives real owner SIGKILL while retaining private payload/reservation. Actual ProjectDeletion is retryably fenced until native child dies. Final project deletion does not delete independent source asset bytes (current ownership contract).
- No obsolete recording donor, source-generation methods, or native archive.copy semantics are recreated.
