import assert from "node:assert/strict";
import { test } from "node:test";
import { fork, spawnSync } from "node:child_process";
import { once } from "node:events";
import { readFile, readdir, stat } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { fixture, until, nativeBinary } from "/Users/david/.codex/worktrees/service-composition/screen-recorder/apps/service/tests/fixtures/project-export.mjs";

if (process.argv[2] === "child") {
  process.on("message", () => {});
  const existing = JSON.parse(process.argv[3]);
  const f = await fixture({ after() {} }, { existing, wrap: (run) => async (operation, ...args) => {
    if (operation !== "archive.write") return run(operation, ...args);
    const environment = { DYLD_INSERT_LIBRARIES: existing.library, SCREENREC_TEST_COPY_BARRIER: existing.marker, SCREENREC_TEST_COPY_PARTIAL: "0", SCREENREC_TEST_COPY_MIN_FD: "6" };
    Object.assign(process.env, environment);
    try { return run(operation, ...args); }
    finally { for (const key of Object.keys(environment)) delete process.env[key]; }
  } });
  await f.jobs.idle();
} else test("surviving native project package writer fences project deletion after owner SIGKILL", { timeout: 20000 }, async (t) => {
  const original = await fixture(t, { admission: false });
  const request = { ...original.request(), kind: "processed-package", leaf: "uncommitted.zip" };
  await original.exports.create(request);
  await original.close();
  const library = join(original.home, "copy-barrier.dylib"), marker = join(original.home, "copy-stopped");
  const compiled = spawnSync("/usr/bin/clang", ["-dynamiclib", "-o", library, "/Users/david/.codex/worktrees/service-composition/screen-recorder/apps/macos/tests/fixtures/archive-copy-barrier.c"], { encoding: "utf8" });
  assert.equal(compiled.status, 0, compiled.stderr);
  const existing = { home: original.home, output: original.output, projectId: original.projectId, asset: { id: original.asset.id }, placed: { revision: { id: original.placed.revision.id } }, library, marker };
  const child = fork(fileURLToPath(import.meta.url), ["child", JSON.stringify(existing)], { stdio: ["ignore", "ignore", "inherit", "ipc"], env: { ...process.env, SCREENREC_NATIVE: nativeBinary } });
  const closed = once(child, "close");
  t.after(async () => { child.kill("SIGKILL"); await closed; });
  const pid = await until(async () => Number(await readFile(marker, "utf8").catch((error) => { if (error.code !== "ENOENT") throw error; return ""; })));
  t.after(() => { try { process.kill(pid, "SIGKILL"); } catch (error) { if (error.code !== "ESRCH") throw error; } });
  assert.equal(Number(spawnSync("/bin/ps", ["-p", String(pid), "-o", "ppid="], { encoding: "utf8" }).stdout.trim()), child.pid);
  assert.equal(child.kill("SIGKILL"), true);
  assert.deepEqual(await closed, [null, "SIGKILL"]);
  const f = await fixture(t, { existing: original });
  const assembly = () => f.catalog.catalog.prepare("SELECT assembly FROM export_intents WHERE exportId=?").get(request.exportId).assembly;
  const before = assembly(), reservation = JSON.parse(before);
  assert.ok(reservation.input.identity && reservation.zip.identity);
  await assert.rejects(f.deletion.delete(f.projectId), (error) => error.retryable === true);
  assert.equal(await readFile(f.assets.path(f.asset.id), "utf8"), "source identity");
  assert.ok((await stat(join(f.home, "package-exports", reservation.zip.name, "payload.zip"))).size > 0);
  assert.equal(assembly(), before);
  process.kill(pid, "SIGKILL");
  await until(async () => { try { await f.deletion.delete(f.projectId); return true; } catch (error) { if (!error.retryable) throw error; return false; } });
  assert.equal(f.catalog.catalog.prepare("SELECT COUNT(*) AS n FROM export_intents").get().n, 0);
  assert.throws(() => f.projects.get(f.projectId), { code: "NOT_FOUND" });
  assert.deepEqual(await readdir(join(f.home, "package-exports")), []);
  assert.deepEqual(await readdir(f.output), []);
  assert.equal(await readFile(f.assets.path(f.asset.id), "utf8"), "source identity");
});
