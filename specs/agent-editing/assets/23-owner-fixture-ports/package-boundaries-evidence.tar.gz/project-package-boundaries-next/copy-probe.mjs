import assert from "node:assert/strict";
import { test } from "node:test";
import { chmod, open, readFile, readdir, stat } from "node:fs/promises";
import { join } from "node:path";
import { fixture } from "/Users/david/.codex/worktrees/service-composition/screen-recorder/apps/service/tests/fixtures/project-export.mjs";

test("project package refuses source mutation after an actual descriptor read during copying", async (t) => {
  const f = await fixture(t);
  const path = f.assets.path(f.asset.id);
  await chmod(path, 0o600);
  const writer = await open(path, "r+");
  await chmod(path, 0o400);
  const identity = await writer.stat({ bigint: true });
  const prototype = Object.getPrototypeOf(writer), read = prototype.read;
  let changed = false;
  prototype.read = async function (...args) {
    const result = await read.apply(this, args);
    if (!changed && result.bytesRead > 0) {
      const info = await this.stat({ bigint: true });
      if (info.dev === identity.dev && info.ino === identity.ino) {
        changed = true;
        await writer.write(Buffer.from([99]), 0, 1, 0);
      }
    }
    return result;
  };
  const request = { ...f.request(), kind: "processed-package", leaf: "changed.zip" };
  try {
    await f.exports.create(request);
    await f.jobs.idle();
  } finally {
    prototype.read = read;
    await writer.close();
  }
  assert.equal(changed, true, "A real read of the selected source preceded its mutation");
  const failed = f.exports.status(request.exportId);
  assert.equal(failed.state, "failed");
  assert.match(failed.reason, /source changed during copying/i);
  await assert.rejects(stat(join(f.output, "changed.zip")), { code: "ENOENT" });
  await f.exports.abandon(request.exportId);
  assert.deepEqual(await readdir(f.output), []);
  assert.equal((await readFile(path))[0], 99);
});
