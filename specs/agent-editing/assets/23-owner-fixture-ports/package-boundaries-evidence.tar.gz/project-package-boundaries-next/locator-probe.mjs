import assert from "node:assert/strict";
import { test } from "node:test";
import { mkdir, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { fixture } from "/Users/david/.codex/worktrees/service-composition/screen-recorder/apps/service/tests/fixtures/project-export.mjs";

test("substituted project package input blocks publication and cleanup until owned identity returns", async (t) => {
  let f, moved, original, replace = true;
  f = await fixture(t, { wrap: (run) => async (operation, ...args) => {
    if (operation === "archive.write" && replace) {
      replace = false;
      const reservation = JSON.parse(f.catalog.catalog.prepare("SELECT assembly FROM export_intents WHERE kind='processed-package'").get().assembly);
      original = join(f.home, "package-exports", reservation.input.name);
      moved = original + "-owned";
      await rename(original, moved);
      await mkdir(original, { mode: 0o700 });
      await writeFile(join(original, "foreign"), "preserve replacement");
    }
    return run(operation, ...args);
  } });
  const request = { ...f.request(), kind: "processed-package", leaf: "substituted.zip" };
  await f.exports.create(request);
  await f.jobs.idle();
  assert.equal(f.exports.status(request.exportId).state, "failed");
  await assert.rejects(stat(join(f.output, "substituted.zip")), { code: "ENOENT" });
  f.exports.resumeRecovery();
  await f.jobs.idle();
  const recovery = f.exports.status(request.exportId).recovery;
  assert.equal(recovery.state, "failed");
  assert.equal(recovery.retryable, true);
  assert.equal(await readFile(join(original, "foreign"), "utf8"), "preserve replacement");
  await rm(original, { recursive: true });
  await rename(moved, original);
  f.exports.recover(request.exportId);
  await f.jobs.idle();
  assert.equal(f.exports.status(request.exportId).recovery.state, "ready");
  assert.equal(f.catalog.catalog.prepare("SELECT assembly FROM export_intents WHERE exportId=?").get(request.exportId).assembly, null);
  await f.exports.abandon(request.exportId);
  assert.deepEqual(await readdir(f.output), []);
  assert.equal(await readFile(f.assets.path(f.asset.id), "utf8"), "source identity");
});
