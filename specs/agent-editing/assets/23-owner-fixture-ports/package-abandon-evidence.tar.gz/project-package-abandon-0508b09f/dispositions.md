# Exact publication resource and receipt contracts

- V1005 transferred with real package asset reference: actual late publication commit releases resource pins, while failed native retirement keeps abandonment admission until confirmed cleanup. Assembly absence distinguishes this allowance from retained package workspace capacity.
- V1061 transferred with actual substituted private staging: ref/fence/capacity remain; output and destination stay truthful; retry is fenced; foreign sentinel/collision/source bytes survive identity-safe retry.
- V1212 transferred through twice-abandon, missing old job/publication/intent/ref, same-ID new job reuse and second abandonment after successful external publication.
- V3266 transferred to actual acquisition normalized member rather than obsolete recording source receipt. Pin records byte receipt, then external append makes physical bytes receipt+1; SOURCE_CHANGED refusal, no external file, cleanup and unmodified raw journal/source assets are asserted. No inference or new recording.
