from pathlib import Path
import json,hashlib,re
b=Path(__file__).parent
names=['transcript.test.ts','transcript-pages.test.ts','transcript-ownership.test.ts','capture-interruption.test.ts']
inputs=[]
for name in names:
 path='packages/core/src/'+name;data=(b/'before'/path).read_bytes()
 titles=re.findall(r'(?m)^test(?:\.each\([^\n]*\))?\(\s*"([^\"]+)"',data.decode())
 inputs.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'declarationTitles':titles})
processing=[
('233','port','selected decoded segments: exact seven words/gaps/kinds/null confidence/instant and raw receipt; actual selected source clock/native request in asset/public tests; old r0/fragments retired'),
('339','reuse/retire','current project-evidence/cutover-words occurrence removal/partial/fragments/phrase proof; old recording cuts/span/r0 retired'),
('399','reuse/retire','current source window/cursor/partial and project transcript range query; old recording playback projection retired'),
('466','port','selected raw occupied segments inside broad support derive exact five gaps'),
('490','port','new source 3000-word exact pages/ordinals/gap/phrases across record batches'),
('554','reuse','source identities/generation/query/window cursor refusal'),
('587','reuse/retire','asset empty acquisition/no_audio; fixed narration-role requirement retired'),
('609','reuse','asset readiness/failure and canonical public unavailable/null-job/no native work'),
('634','retire','automatic narration backfill; current explicit request admission/context retention remains'),
('655','reuse','asset/public ready/running retry no duplicate requests'),
('680','reuse','actual source-evidence interrupted source retry/reopen and generic JobQueue restart proof; old recording edit resume retired'),
('707','port','nine actual asset native refusal rows; zero rows/files, receipt/hash failure retained'),
('806','reuse','asset cleanup plus unchanged source TranscriptStore namespace/reclaim/purge cases'),
('847','reuse','asset historical decoder/model work separate new identities while earlier words remain')]
page=[
('positive partial projection/reopen','reuse/retire','current asset portable raw/metadata adoption with recipient model absent + project partial-word proof; old recording source/edited-page format retired'),
('word bounds/segment/order/overlap','port','current nine native raw refusal controls; current ingest assigns contiguous canonical word IDs across complete raw stream'),
('changed/renumbered word ID','retire','current portable raw format has no caller-supplied indexed word ID; IDs derive from indexed ordinal'),
('gap overlap','reuse/retire','current ingest derives gaps from decoded/acquired support, exact positive rows; mutable gap page representation retired'),
('page descriptor/hash','reuse/retire','shared OrderedPageReader remains used by current scene/index file owners; old transcript JSON page carrier retired'),
('raw hash','port','Raw transcript does not match its receipt matrix row'),
('edited row not projection','reuse/retire','project transcript/evidence owner computes current occurrence rows; old separately published edited JSON rows retired'),
('within/across-page overlap [false,true]','port/retire','current raw nonoverlap admission retained; transcript paged representation retired')]
r={'baseline':'cab28df5','originalInputs':inputs,'processingDeclarations':14,'pagedDeclarations':3,'pagedExpandedCases':4,'genericOwnershipExpandedCasesRetainedUnchanged':7,'captureInterruptionCasesRetained':8,'processingDispositions':[dict(oldLocator=l,decision=d,survivor=s) for l,d,s in processing],'pageFormatDispositions':[dict(claim=c,decision=d,survivor=s) for c,d,s in page],'keptSourceOwners':['SourceTranscriptRead/Traversal/search/work bounds','asset/project transcript/portable/adopt/cleanup and selected source execution','TranscriptStore unchanged generic source/schema; seven CaptureStore namespace/cancel/reclaim/native306-word cases','all eight capture-interruption current source/project rows'],'scopeLimits':['no blanket removal of recording source identity or frozen raw r0 provenance','no schema/format bump or migration','no native/model/inference/capture/full suite work'],'mappingTiming':'Original inputs retained before edits. Initial mapping writer hit str.decode authoring error; final mapping authored from frozen originals after production removal, using the prior read-only audit and approved dispositions, not claiming an earlier file was written.'}
(b/'coverage.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'inputTitles':[len(v['declarationTitles']) for v in inputs]}))
