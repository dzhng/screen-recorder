import { z } from "zod";
import { type FileAccess } from "./files.js";
import type { TimelineRevision } from "./timeline.js";
import type { TimeRange } from "./presentation-time.js";
import { type RecordingTranscriptIdentity, type TranscriptGapRecord, type TranscriptIdentity, type RecordingTranscriptMetadata, type TranscriptRecordQuery, type TranscriptRecords, type TranscriptSegmentRecord, type TranscriptStore, type TranscriptWordRecord } from "./transcript.js";
import { TranscriptRead, type TranscriptRow } from "./transcript-read.js";
/** The narration member relative to the package root, which portable metadata names instead of a library path. */
export declare const portableNarration = "source/narration.mov";
/** The retained engine output beside the source-transcript pages. */
export declare const portableRawTranscript = "raw.jsonl";
type SourceTranscriptRecords = Pick<TranscriptStore, "wordRecords" | "gapRecords" | "segmentRecords">;
/** Writes one published generation in source time; the raw engine output is copied beside it. */
export declare function writeTranscriptPages(records: SourceTranscriptRecords, metadata: RecordingTranscriptMetadata, directory: string, signal?: AbortSignal): Promise<void>;
/** One portable generation as the ordered records `TranscriptRead` consumes. */
export declare class FileTranscript implements TranscriptRecords {
    private readonly pages;
    readonly root: FileAccess;
    constructor(root: string | FileAccess);
    get metadata(): RecordingTranscriptMetadata;
    private rows;
    wordRecords(identity: TranscriptIdentity, query: TranscriptRecordQuery): TranscriptWordRecord[];
    gapRecords(identity: TranscriptIdentity, query: TranscriptRecordQuery): TranscriptGapRecord[];
    segmentRecords(identity: TranscriptIdentity, query: TranscriptRecordQuery): TranscriptSegmentRecord[];
}
declare const editedMetadataSchema: z.ZodObject<{
    recordingId: z.ZodString;
    sourceId: z.ZodString;
    revisionId: z.ZodString;
    generation: z.ZodString;
    policy: z.ZodLiteral<"transcript-v1">;
}, z.core.$strict>;
/** A projected row of the pinned revision, numbered in reading order. */
export type EditedTranscriptRow = TranscriptRow & {
    position: number;
};
/** The pinned revision's projection, so the package carries the edited transcript in playback time. */
export declare function writeEditedTranscriptPages(read: TranscriptRead, metadata: z.infer<typeof editedMetadataSchema>, directory: string, signal?: AbortSignal): Promise<void>;
/**
 * Full admission of portable transcript payloads: canonical source rows that agree with the
 * package's own narration acquisition, the hashed raw engine output, and an edited transcript that
 * is exactly the pinned revision's projection of those rows.
 */
export declare function validateTranscriptPages(input: {
    source: string | FileAccess;
    edited: string | FileAccess;
    identity: RecordingTranscriptIdentity;
    revision: TimelineRevision;
    /** Acquired narration intervals from the same package's source evidence. */
    narration: readonly TimeRange[];
}, signal?: AbortSignal): Promise<FileTranscript>;
export {};
