const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { syncBuiltinESMExports } = require('node:module');
const bank = process.env.SCREENREC_INDEX_OBSERVER;
const remove = fs.rmSync;
const observed = new Set();
fs.rmSync = function (target, ...args) {
  const selected = String(target);
  if (bank && /^\/tmp\/scr-index-scale-[^/]+$/.test(selected) && !observed.has(selected)) {
    observed.add(selected);
    const out = path.join(bank, `cleanup-${process.pid}`);
    fs.mkdirSync(out, {recursive:true});
    let db;
    try {
      const { DatabaseSync } = require('node:sqlite');
      const catalog = path.join(selected, 'library/catalog.sqlite');
      if (fs.existsSync(catalog)) {
        db = new DatabaseSync(catalog, {readOnly:true});
        const tables = ['jobs','scene_evidence_generations','screenshot_index_generations','screenshot_index_entries','screenshot_index_coverage'];
        const counts = {};
        const pngs = [];
        for (const table of tables) {
          const output = fs.openSync(path.join(out, table+'.jsonl'),'wx');
          let count=0;
          try {
            const order = table==='screenshot_index_entries'?' ORDER BY ownerKind,ownerId,generation,ordinal':table==='screenshot_index_coverage'?' ORDER BY ownerKind,ownerId,generation,sequence':'';
            for(const row of db.prepare('SELECT * FROM '+table+order).iterate()) {
              fs.writeSync(output,JSON.stringify(row)+'\n');count++;
              if(table==='screenshot_index_entries') {
                const frame=JSON.parse(row.frame),bytes=fs.readFileSync(frame.file);
                pngs.push({ownerKind:row.ownerKind,ownerId:row.ownerId,generation:row.generation,ordinal:row.ordinal,file:frame.file,bytes:bytes.length,declaredBytes:row.bytes,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});
              }
            }
          } finally {fs.closeSync(output);}
          counts[table]=count;
        }
        fs.writeFileSync(path.join(out,'retained-pngs.json'),JSON.stringify(pngs,null,2)+'\n');
        fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify({home:selected,counts,retainedPngCount:pngs.length,retainedPngBytes:pngs.reduce((n,p)=>n+p.bytes,0),allDeclaredPngSizesMatch:pngs.every(p=>p.bytes===p.declaredBytes),scope:'Read-only durable table and retained PNG hash snapshot immediately before unchanged fixture scratch cleanup; no requests replayed.'},null,2)+'\n');
      }
    } catch(error) {
      fs.writeFileSync(path.join(out,'error.txt'),String(error.stack||error));process.exitCode=1;
    } finally {db?.close();}
  }
  return Reflect.apply(remove,this,[target,...args]);
};
syncBuiltinESMExports();
