from pathlib import Path
import subprocess,os,time,json,signal,sqlite3
b=Path(__file__).parent;r=Path('/Users/david/dev/screen-recorder');c=b/'capsule'
output=b/'output';output.mkdir(exist_ok=False)
input=Path('/Users/david/.cache/screen-recorder/verification/frame-cache-long-6eb419eb/video.mov')
env=dict(os.environ,SCREENREC_INDEX_SCALE_VIDEO=str(input),SCREENREC_INDEX_SCALE_EVIDENCE=str(output),SCREENREC_INDEX_OBSERVER=str(b))
cmd=['node','--require',str(b/'observe-cleanup.cjs'),'--test','--test-concurrency=1',str(c/'apps/macos/tests/index-scale.mjs')]
start=time.time();baseline=set(Path('/tmp').glob('scr-index-scale-*'));log=(b/'gate.log').open('w');p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(b/'process.json').write_text(json.dumps({'argv':cmd,'cwd':str(r),'pid':p.pid,'start':start,'budgetSeconds':2865,'measurementSafetySeconds':2700,'testSeconds':2850,'source':str(input)},indent=2)+'\n')
seen={};last=None;progressAt=start;nextSaved=0;stopping=None;stopAt=None
while p.poll() is None:
 now=time.time();rows=[]
 for line in subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,command='],text=True).splitlines():
  v=line.strip().split(None,3)
  if len(v)==4:rows.append((int(v[0]),int(v[1]),int(v[2]),v[3]))
 owned={p.pid};again=True
 while again:
  again=False
  for pid,ppid,pgid,command in rows:
   if ppid in owned and pid not in owned:owned.add(pid);again=True
 for row in rows:
  if row[0] in owned:seen[row[0]]=row
 snapshot={'elapsedSeconds':now-start,'ownedPids':sorted(owned),'logBytes':(b/'gate.log').stat().st_size}
 homes=[home for home in Path('/tmp').glob('scr-index-scale-*') if home not in baseline]
 for home in homes:
  dbpath=home/'library/catalog.sqlite'
  if not dbpath.exists():continue
  db=None
  try:
   db=sqlite3.connect('file:'+str(dbpath)+'?mode=ro',uri=True,timeout=.1);db.row_factory=sqlite3.Row
   tables={row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
   state={'home':str(home)}
   if 'jobs' in tables:state['jobs']=[dict(row) for row in db.execute('SELECT artifact,state,COUNT(*) AS count FROM jobs GROUP BY artifact,state ORDER BY artifact,state')]
   if 'scene_evidence_generations' in tables:state['scenes']=[dict(row) for row in db.execute('SELECT ownerKind,ownerId,generation,throughUs,chunkCount,comparisonCount,boundaryCount,complete FROM scene_evidence_generations')]
   if 'screenshot_index_generations' in tables:state['indexes']=[dict(row) for row in db.execute('SELECT ownerKind,ownerId,generation,state,candidateCount,coverageCount,throughUs,bytes FROM screenshot_index_generations')]
   snapshot['durable']=state
  except sqlite3.OperationalError as error:snapshot['statusReadMissing']=str(error)
  finally:
   if db:db.close()
 token=json.dumps(snapshot.get('durable'),sort_keys=True)
 if token!=last:last=token;progressAt=now
 snapshot['secondsSinceDurableProgress']=now-progressAt
 (b/'progress.json').write_text(json.dumps(snapshot,indent=2)+'\n')
 if now>=nextSaved:
  with (b/'progress.jsonl').open('a') as f:f.write(json.dumps(snapshot)+'\n')
  print(json.dumps(snapshot),flush=True);nextSaved=now+30
 if not stopping and (now-start>2865 or (snapshot.get('durable') and now-progressAt>120)):
  stopping='Outer bounded stop' if now-start>2865 else 'No durable job/scene/index progress for120seconds; diagnostic stop, not acceptance failure budget or retry'
  (b/'stop-diagnosis.json').write_text(json.dumps({'reason':stopping,'snapshot':snapshot,'processes':rows},indent=2)+'\n');stopAt=now;p.send_signal(signal.SIGTERM)
 if stopping and now-stopAt>15:
  for pid,ppid,pgid,command in rows:
   if pid in seen and seen[pid][3]==command:
    try:os.kill(pid,signal.SIGKILL)
    except ProcessLookupError:pass
 time.sleep(5)
code=p.wait();log.close();terminal={'exitCode':code,'seconds':time.time()-start,'controlledStop':stopping,'observedProcesses':list(seen.values())};(b/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps({k:v for k,v in terminal.items() if k!='observedProcesses'}),flush=True);print((b/'gate.log').read_text()[-5000:],flush=True)
raise SystemExit(code)
