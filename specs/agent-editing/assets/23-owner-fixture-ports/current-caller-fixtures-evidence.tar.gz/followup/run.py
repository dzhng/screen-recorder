import os,sys,json,time,subprocess
from pathlib import Path
out=Path(__file__).parent
name=sys.argv[1];args=sys.argv[2:];start=time.time()
env=dict(os.environ,SCREENREC_NATIVE="/Users/david/.codex/artifacts/screen-recorder/current-native-workers/479676ca8fde43b0ae44bc308a4e71fd84f3e6a80c3e51f317253ebb5a3cdd8d/screenrec-native")
with (out/(name+".stdout")).open("w") as stdout,(out/(name+".stderr")).open("w") as stderr:
 process=subprocess.Popen(args,stdout=stdout,stderr=stderr,env=env,start_new_session=True)
 (out/(name+"-process.json")).write_text(json.dumps({"argv":args,"pid":process.pid,"start":start,"budgetSeconds":90}))
 try: code=process.wait(timeout=90)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,9);code=process.wait()
 (out/(name+"-terminal.json")).write_text(json.dumps({"pid":process.pid,"exit":code,"waited":True,"end":time.time()}))
print(code,(out/(name+".stdout")).read_text(),(out/(name+".stderr")).read_text())
sys.exit(code)
