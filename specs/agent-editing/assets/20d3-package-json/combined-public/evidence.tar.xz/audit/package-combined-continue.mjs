import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {execFile} from "node:child_process";
import {promisify} from "node:util";
import {readFile,writeFile,mkdir,rm,realpath} from "node:fs/promises";
import {join} from "node:path";
import {JourneyService,poll} from "/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs";
const run=promisify(execFile),hash=b=>createHash("sha256").update(b).digest("hex");
const out=await realpath("/tmp/package-combined-catalog16-run"),donorReal=join(out,"donor"),values={acquisition:"f87d6d01-04f8-498f-b53a-ec44e265a847"},assetId="e83523233b5b60dbfc70334f80a4dec3f38aab52ea8451afbdb459123c06ca04";
const report=JSON.parse(await readFile(join(out,"report.json"))),manifest=JSON.parse(await readFile(join(out,"inspected/manifest.json"))),exported=JSON.parse(await readFile(join(out,"export-status-terminal.json"))),acquisition=JSON.parse(await readFile(join(out,"donor-acquisition.json")));
report.continuation="Resumes already-adopted receiver after correcting only expected normalized receipt.file locator relocation; no setup or native readiness/adoption repeated.";
const ref=manifest.resources.find(r=>r.identity.kind==="asset"&&r.identity.id===assetId),portable=JSON.parse(await readFile(join(out,"inspected",ref.metadata.path))),header={...portable.asset,streams:portable.asset.streams.map(({segments,...stream})=>({...stream,segmentCount:segments?.length??0}))},stream=header.streams.find(r=>r.kind==="audio");
let service=new JourneyService(join(out,"receiver"),report);await service.start();const call=(...args)=>service.call(...args);
async function settled(operation,params,desired){const result=await poll(()=>call(operation,params,{transport:"mcp"}),v=>[desired,"failed","canceled","unavailable"].includes(v.state),operation);await writeFile(join(out,operation.replaceAll(".","-")+"-terminal.json"),JSON.stringify(result,null,2));assert.equal(result.state,desired,JSON.stringify(result));return result;}
try {
  assert.deepEqual(await call("asset.get", { assetId }), header);
  if (acquisition) {
    const relocated = await call(
      "acquisition.get",
      { acquisitionId: values.acquisition },
      { transport: "mcp" },
    );
    assert.ok(acquisition.evidence.receipt.file.startsWith(donorReal + "/"));
    const expected = structuredClone(acquisition);
    expected.evidence.receipt.file = join(
      await realpath(join(out, "receiver")),
      acquisition.evidence.receipt.file.slice(donorReal.length + 1),
    );
    assert.deepEqual(relocated, expected);
    await writeFile(join(out, "receiver-acquisition.json"), JSON.stringify(relocated));
    report.checks.push("complete acquisition metadata and exact support retained");
  }
  let cursor,
    count = 0;
  do {
    const page = await call(
      "asset.segments",
      { assetId, streamId: stream.id, limit: 1000, ...(cursor ? { cursor } : {}) },
      { transport: "mcp" },
    );
    await writeFile(join(out, `segments-${count}.json`), JSON.stringify(page));
    assert.deepEqual(
      page.segments,
      portable.asset.streams
        .find((item) => item.id === stream.id)
        .segments.slice(count, count + 1000)
        .map((row, i) => ({ ordinal: count + i, ...row })),
    );
    count += page.segments.length;
    cursor = page.nextCursor;
  } while (cursor);
  assert.equal(count, stream.segmentCount);
  report.physicalRows = count;
  report.checks.push("receiver adoption and exact complete physical rows");
  // The prior service stop already closed this transient package owner.
  for (const mode of ["missing", "corrupt", "duplicate-stream", "version1"]) {
    const directory = join(out, mode);
    await mkdir(directory);
    await run("unzip", ["-q", exported.output, "-d", directory]);
    const editedManifest = structuredClone(manifest);
    const ref = editedManifest.resources.find(
      (item) => item.identity.kind === "asset" && item.identity.id === assetId,
    );
    if (mode === "missing") await rm(join(directory, ref.metadata.path));
    if (mode === "corrupt") await writeFile(join(directory, ref.metadata.path), "{}");
    if (mode === "version1") editedManifest.version = 1;
    if (mode === "duplicate-stream") {
      const changed = structuredClone(portable);
      changed.asset.streams.push({ ...changed.asset.streams[0], segments: [] });
      const body = JSON.stringify(changed);
      await writeFile(join(directory, ref.metadata.path), body);
      ref.metadata.bytes = Buffer.byteLength(body);
      ref.metadata.sha256 = hash(body);
      Object.assign(
        editedManifest.inventory.find((item) => item.path === ref.metadata.path),
        ref.metadata,
      );
    }
    await writeFile(join(directory, "manifest.json"), JSON.stringify(editedManifest));
    const path = join(out, `${mode}.zip`);
    await run("zip", ["-qr", path, "."], { cwd: directory });
    const pending = await call("package.open", { path });
    const failure = await settled("package.status", { admissionId: pending.id }, "failed");
    assert.equal(failure.packageHandle, null);
    await writeFile(join(out, `${mode}.json`), JSON.stringify(failure, null, 2));
    report.checks.push(`${mode} never ready`);
  }
  report.passed = true;
} finally {
  await service?.stop();
  await writeFile(join(out, "report.json"), JSON.stringify(report, null, 2));
}
