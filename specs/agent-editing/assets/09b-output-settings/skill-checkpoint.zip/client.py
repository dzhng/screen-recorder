import json,subprocess,pathlib,time,uuid
out=pathlib.Path('/tmp/screenrec-output-skill')
cli='/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/apps/cli/dist/main.js'
socket=json.load(open('/tmp/output-skill-service.json'))['socketPath']
def call(name,operation,params,output=None):
 p=out/(name+'.request.json');p.write_text(json.dumps(params,indent=2))
 args=['node',cli,operation,'--socket',socket,'--params','-']
 if output:args+=['--output',str(output)]
 (out/(name+'.command.json')).write_text(json.dumps(args))
 r=subprocess.run(args,input=p.read_bytes(),capture_output=True)
 (out/(name+'.receipt.json')).write_bytes(r.stdout);(out/(name+'.stderr.txt')).write_bytes(r.stderr)
 parsed=json.loads(r.stdout)
 print(name,r.returncode,parsed.get('data',{}).get('state',parsed.get('error',{})))
 return parsed
