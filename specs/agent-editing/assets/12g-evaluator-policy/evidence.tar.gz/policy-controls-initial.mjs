import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
const directory = ".build/12g/controls";
mkdirSync(directory, { recursive: true });
const source = readFileSync("packages/test-harness/speech/evaluate.test.mjs", "utf8");
// Reuse authored test inputs verbatim; this scratch probe adds no scorer or model path.
const factory = source.slice(source.indexOf("function completeEvidence()"), source.indexOf("async function cliEvaluate"));
const misses = source.slice(source.indexOf("function optionalFillerMisses("), source.indexOf('\ntest("CLI accepts'));
const fixtures = new Function(factory + misses + "return {completeEvidence, optionalFillerMisses};")();
const cases = [
  ["optional", () => {}, 0, null],
  ["perfect", (value) => { value.runs = value.originalRuns; }, 0, null],
  ["required-filler", ({ clips }) => { clips[0].words[0] = { ...clips[0].words[0], required: true }; }, 1, "Canonical omissions: canonical"],
  ["required-word", (value) => { value.runs[0].words = value.runs[0].words.slice(1); }, 1, "Canonical omissions: canonical"],
  ["fewer-labels", ({ clips }) => { clips[1].words = clips[1].words.slice(0, 19); }, 2, "At least 40 labeled fillers across held-out human clips required"],
  ["one-held-clip", (value) => { value.clips = value.clips.filter((clip) => clip.id !== "held-b"); value.runs = value.runs.filter((run) => run.clipId !== "held-b"); }, 2, "At least 40 labeled fillers across held-out human clips required"],
  ["missing-coverage", ({ clips }) => { for (const clip of clips) clip.covers = clip.covers.filter((kind) => kind !== "false-start"); }, 2, "Human coverage pending: false-start"],
  ["missing-provenance", ({ runs }) => { delete runs[0].runtimeRevision; }, 2, "Inference provenance pending: canonical"],
  ["audition-missing", ({ runs }) => { delete runs[0].audition; }, 2, "Audition pending: canonical"],
  ["audition-clipped", ({ runs }) => { runs[0].audition.neighboringSpeechIntact = false; }, 1, "Audition clipped speech: canonical"],
  ["cold-resources", ({ runs }) => { runs[3].warm = false; }, 2, "Warm resource measurement pending: walk"],
  ["too-slow", ({ runs }) => { runs[3].elapsedSeconds = 301; }, 1, "Slower than realtime: walk"],
  ["excess-rss", ({ runs }) => { runs[3].peakRssBytes = 4 * 1024 ** 3 + 1; }, 1, "RSS exceeds 4 GiB: walk"],
  ["timing", ({ runs }) => { for (const run of runs) run.words = run.words.map((word) => ({ ...word, start: word.start + 0.3, end: word.end + 0.3 })); }, 1, "P95 boundary error exceeds 250 ms"],
];
const outcomes = [];
for (const [name, change, expectedExit, reason] of cases) {
  const seed = fixtures.completeEvidence();
  const value = { clips: structuredClone(seed.clips), originalRuns: structuredClone(seed.runs), runs: fixtures.optionalFillerMisses(structuredClone(seed.runs)) };
  change(value);
  const dataset = { clips: value.clips, fillerTerms: ["um", "uh"] };
  const datasetPath = join(directory, name + "-dataset.json"), runsPath = join(directory, name + "-runs.json");
  writeFileSync(datasetPath, JSON.stringify(dataset, null, 2) + "\n");
  writeFileSync(runsPath, JSON.stringify(value.runs, null, 2) + "\n");
  const args = ["scripts/speech-eval.mjs", "evaluate", datasetPath, runsPath];
  const result = spawnSync(process.execPath, args, { encoding: "utf8" });
  writeFileSync(join(directory, name + "-stdout.json"), result.stdout);
  writeFileSync(join(directory, name + "-stderr.txt"), result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(result.status, expectedExit, name + result.stderr);
  if (reason) assert.ok([...report.failures, ...report.pending].includes(reason), name);
  if (name !== "perfect" && name !== "fewer-labels") {
    assert.equal(report.heldOut.precision, 0.75, name);
    assert.equal(report.heldOut.recall, 0.75, name);
  }
  outcomes.push({ name, command: [process.execPath, ...args], exitCode: result.status, status: report.status, failures: report.failures, pending: report.pending, heldOut: report.heldOut, boundaries: report.boundaries });
}
writeFileSync(join(directory, "outcomes.json"), JSON.stringify({ scope: "Synthetic evaluator contract controls, not human speech quality or inference", outcomes }, null, 2) + "\n");
console.log(JSON.stringify({ cases: outcomes.length, passed: outcomes.length, noRunOrPrepare: true }));
