# Scoped local review

Shape: the existing evaluator remains the sole matching/measurement/status owner.
Production changes are +5/-3 lines: require the explicit true flag, retain separate
filler omission indices, and delete the two retired 95% failures. No policy flag,
wrapper, alternate matching owner or dependency is added. Tests reuse the existing
complete cohort fixture and one actual CLI helper; the duplicate direct complete-
cohort timing check is replaced by the CLI timing control. The sparse original
fixture still owns low-metric/incomplete behavior. Separate required/filler roles
remain visible at the same per-clip output seam.

Diff: all alignment, boundary, percentile/Wilson, denominator, human coverage,
40-label/two-held-clip, provenance, audition, warm-resource and canonical-only hard
omission code outside the exact correction is unchanged. Explicitly required
fillers appear in both omission arrays and fail canonical preservation. Other
required words still fail. Held-out/walkthrough required misses remain diagnostics.
The actual evaluate CLI owns exit 0/1/2 and prints the complete report. Tests and
14 additional synthetic control cases preserve those outputs without inference.

Docs: protocol describes labels and zero-based reference indices. The selected
engine acceptance prose now follows the existing user policy, while historical
failed trials/reports are unchanged. The new leaf and packet are linked from the
owning model-selection slice. Root hubs/parent12/global choices and AGENTS are
untouched. All local changed-document links resolve.

Choices: the synthetic fixture/provenance distinction and numerical oracle are
explicitly recorded. No human quality, baseline improvement, model selection or
full12 completion follows. No unsound/user-only decision remains.
