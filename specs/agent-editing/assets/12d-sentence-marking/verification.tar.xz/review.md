# Sentence marking page review

Scope: local evaluation tool only; no capture, model, installed app, frozen worker or production API changes.

Root shape review: existing WAV parser is reused, one shared clock/export owner feeds browser and server, no duplicated audio decoder or persisted product state. Fixed packet and four targets are intentional; this is not a general transcript editor. Request byte budget and loopback binding keep the local save surface bounded. Server does not overwrite exports.

Root diff review caught missing byte ranges: native browser seekable range was [0,0], and waveform click returned currentTime 0. After exact byte-range delivery, seekable [0,7.14], currentTime 3.57, paused true. Range regression mutation (delivery disabled) fails 200 vs 206; restored code passes. Clock mutation (origin added twice) fails 50567350 vs 50518675; restored code passes. Unknown request fields initially failed expected-refusal test; strict request field parsing earns green. All four timing/export tests and the range test pass in the default harness command, alongside its eight existing speech-evaluation tests and native bootstrap.

Browser flow: all eight initial fields blank, confirmation unchecked, audio metadata duration 7.14, paused true and autoplay false. Synthetic partial draft save persists exact source timestamp 51518675 with null end and no independent annotations. Editing after confirmation clears it. Reversed uh range is rejected without save. Clear removes row error. Seeking and 16x zoom never play audio. Actual playhead button stores displayed clip position and matching source clock. No browser playback performed.

Independent code review: clean; five focused tests and real HTTP draft/null/source-binding rejection pass. Confirmed synthetic filler marks remain local with complete:false. Test subprocesses exit and scratch state is removed. Browser playback/decoding, seek completion, layout and save failure recovery not exercised by that reviewer; root tested seeking/metadata/layout/save separately, never audio playback.

Fresh visual critique inspected every original full capture and three enlarged crops. It identified distant reversed-range error and tiny narrow waveform ticks. Final candidate adds row-local message/red end border and enlarges tick text. Follow-up inspected three final full captures and five enlarged crops: no clipping, overlap, ambiguous start/end labels or new layout defects. Minor compact phone-scale tick spacing and vertical distance from playback to later rows remain acknowledged; desktop ticks and numbered scan order are readable. The desktop Mac is the intended listening context; unknown fields stay explicit rather than collapsing their readouts.

Numeric metrics describe an intentionally sparse white form, not acceptance: blank desktop edgeDensity .15812, no transparency; bright background trips low entropy/dominant-color suspicion. Root inspected the form itself; no content is missing. All full images, crops and raw metrics retained.

Codex CLI second review remains unavailable: earlier current-session configured model was rejected before review (HTTP400), no model/config override or retry. No passing CLI review is claimed. Collaboration review and root review cover this pass.

All HTTP/UI exported positions in the verification evidence are SYNTHETIC TEST ONLY, never human ground truth. Disposable saved test files and the test server/tab were removed. Separate user server/page has fresh blank inputs and separate output directory. It stays running intentionally for the requested human task.
