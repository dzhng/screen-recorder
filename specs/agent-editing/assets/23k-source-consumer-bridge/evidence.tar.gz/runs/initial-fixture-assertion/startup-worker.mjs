#!/Users/david/.nvm/versions/node/v24.14.0/bin/node
import {spawn} from 'node:child_process';import {appendFileSync,fstatSync,statSync} from 'node:fs';import {join} from 'node:path';
const log=x=>appendFileSync(process.env.SCREENREC_23K_NATIVE_LOG,JSON.stringify(x)+'\n');let bytes='';
process.stdin.setEncoding('utf8').on('data',x=>bytes+=x);process.stdin.on('end',()=>{
const request=JSON.parse(bytes);log({event:'request',request});const operation=request.operation;
if(!['media.audioCapabilities','packageWorkspace.recover'].includes(operation)){log({event:'refused',operation});process.stdout.write(JSON.stringify({id:request.id,ok:false,error:{code:'FIXTURE_UNEXPECTED_NATIVE',message:operation,retryable:false,details:{}}})+'\n');return;}
const stdio=['pipe','pipe','pipe'];if(operation==='packageWorkspace.recover'){
const fd=fstatSync(3,{bigint:true}),owned=statSync(join(process.env.SCREENREC_HOME,'library/packages'),{bigint:true});
if(fd.dev!==owned.dev||fd.ino!==owned.ino||request.params.parent.dev!==String(fd.dev)||request.params.parent.ino!==String(fd.ino))throw Error('Workspace descriptor escaped owned home');stdio.push(3);}
const child=spawn(process.env.SCREENREC_23K_NATIVE,[],{stdio});log({event:'forwarded',operation,pid:child.pid});
let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
child.on('close',(code,signal)=>{log({event:'close',operation,pid:child.pid,code,signal,stdout,stderr});process.stdout.write(stdout);process.stderr.write(stderr);process.exitCode=code??1});child.stdin.end(bytes);
});
