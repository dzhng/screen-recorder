import hashlib, json, pathlib, subprocess, tarfile, io
root=pathlib.Path.cwd(); scratch=pathlib.Path(__file__).parent
owner=root/'specs/agent-editing/assets/24z13-cli-delivery-selection'
payloads={}
def add(name,data):
    assert name not in payloads
    payloads[name]=data
phases=[]
for directory in sorted(scratch.iterdir()):
    if directory.is_dir() and (directory/'command.json').exists():
        command=(directory/'command.json').read_bytes(); record=json.loads(command)
        add('runs/'+directory.name+'/command.json',command)
        add('runs/'+directory.name+'/output.log',(directory/'output.log').read_bytes())
        sources={}
        for file,sha in record['sourcePins'].items():
            data=(directory/file).read_bytes(); assert hashlib.sha256(data).hexdigest()==sha
            member='sources/'+sha+pathlib.Path(file).suffix
            if member not in payloads: add(member,data)
            sources[file]=member
        phases.append({'phase':directory.name,'exitCode':record['exitCode'],'sourceMembers':sources})
for name in ['run-check.py','pin-runtime.py','pin-runtime-initial.py','runtime-authority.json','build-commands.json','bank-packet.py']:
    add('authority/'+name,(scratch/name).read_bytes())
for log in sorted(scratch.glob('*-emit.log')):add('build/'+log.name,log.read_bytes())
for file in ['apps/cli/src/main.ts','apps/cli/src/main.test.ts','apps/cli/dist/main.js']:
    add('final/'+file,(root/file).read_bytes())
add('authority/diff.patch',subprocess.check_output(['git','diff','--','apps/cli/src/main.ts','apps/cli/src/main.test.ts']))
add('authority/phases.json',(json.dumps(phases,indent=2)+'\n').encode())
archive=owner/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,data in sorted(payloads.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
manifest=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(payloads.items())]
verify={'scope':'Synthetic owned socket + actual CLI child delivery-selection correction; no media/native/model/timing execution','base':'2591aa28c99c2cea064e0d312742020343f63169','affectedSuite':{'phase':'affected-suite','files':7,'testsPassed':84,'exitCode':0,'durationSeconds':11.73},'regressions':{'single':'initial health once and exact file/metadata','batch':'initial health once, duplicate bytes, middle error preserved, later duplicate delivered','disappearance':'first truncated frame preserved; later selected-socket connection failure; no bootstrap/replay'},'retainedFailures':{'single-red':'extra health probe','batch-red':'extra health probe per ready item','disappearance-red':'initial guessed close-event oracle plus later app-discovery failure','disappearance-green':'fixed arm still failed initial guessed first-error oracle','disappearance-corrected-red':'only later APP_NOT_FOUND differs from selected connection error','types-final':'fixture circular inference; corrected with independent producer return type'},'successfulChecks':['disappearance-corrected-green','focused-final','types-corrected','affected-suite','lint-closeout','format-closeout'],'runtimeAuthority':'authority/runtime-authority.json','phaseAuthority':'authority/phases.json','childLifetime':'New tests await actual CLI child close via existing runCli, assert exit0 and empty stderr; no separate same-PID event inventory claim','scopeLimits':['Path retention does not pin service instance','Existing CLI has no new cancellation interface; carried signals and MCP cancellation behavior preserved','Batch overall success/exit0 with per-item failures preserved','No installed/default launch proof or performance claim','No accepted preparation or historical media cohort repeated'],'archive':{'path':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest)},'members':manifest}
(owner/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
with tarfile.open(archive) as tar:
    for member in manifest:
        data=tar.extractfile(member['path']).read();assert len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256']
print(json.dumps(verify['archive'],indent=2))
