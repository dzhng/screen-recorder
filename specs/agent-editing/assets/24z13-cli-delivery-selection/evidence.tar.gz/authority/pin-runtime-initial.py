import hashlib, json, pathlib, subprocess, datetime
root=pathlib.Path.cwd(); out=pathlib.Path(__file__).parent
previous=pathlib.Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2/runtime-authority.json')
def pin(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''): h.update(part)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
a=json.loads(previous.read_text()); changed=[]
for old in a['sourceAndEmittedFiles']:
    current=pin(root/old['path'])
    if current['sha256']!=old['sha256'] or current['bytes']!=old['bytes']:
        changed.append({'path':old['path'],'current':current,'previous':old})
for old in a['sdk']['esmFiles']:
    current=pin(pathlib.Path(old['path']))
    assert current['sha256']==old['sha256'] and current['bytes']==old['bytes'],old['path']
resolution = subprocess.run(['node','--input-type=module','-e', "const names=['@screenrec/protocol','@screenrec/client','@screenrec/service','@screenrec/core/library','@screenrec/composition','@modelcontextprotocol/sdk/client/index.js','@modelcontextprotocol/sdk/server/index.js','zod']; console.log(JSON.stringify(Object.fromEntries(names.map(name=>[name,import.meta.resolve(name)]))))"],capture_output=True,check=True,text=True)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'2591aa28c99c2cea064e0d312742020343f63169','worktree':str(root),'reference':pin(previous),'referenceArchive':pin(root/'specs/agent-editing/assets/24z-current-preparation/evidence.tar.gz'),'referenceAuthorityMember':'authority/runtime-authority.json','ownedCompared':len(a['sourceAndEmittedFiles']),'differences':changed,'sdkCompared':len(a['sdk']['esmFiles']),'sdkAllEqual':True,'resolvedModules':json.loads(resolution.stdout),'entry':pin(root/'apps/cli/dist/main.js'),'node':pin(pathlib.Path(subprocess.check_output(['which','node'],text=True).strip())),'nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'tests':[pin(root/path) for path in ['apps/cli/src/main.test.ts','apps/cli/src/mcp-media.test.ts','apps/cli/src/result-delivery.test.ts','packages/client/src/transport.test.ts','packages/client/src/discovery.test.ts','apps/service/src/result-delivery.test.ts','apps/service/src/delivery.test.ts']]}
(out/'runtime-authority.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'ownedCompared':record['ownedCompared'],'changedPaths':[x['path'] for x in changed],'sdkCompared':record['sdkCompared'],'resolvedModules':record['resolvedModules']},indent=2))
