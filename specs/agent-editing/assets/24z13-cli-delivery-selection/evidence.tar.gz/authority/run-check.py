import datetime, hashlib, json, pathlib, shutil, subprocess, sys
out=pathlib.Path(__file__).parent
name=sys.argv[1]; args=sys.argv[2:]
root=pathlib.Path.cwd()
snapshot=out/name; snapshot.mkdir()
for file in ['apps/cli/src/main.ts','apps/cli/src/main.test.ts','apps/cli/dist/main.js']:
    target=snapshot/file; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(root/file,target)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(snapshot/'output.log').write_bytes(p.stdout)
record={'args':args,'cwd':str(root),'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'sourcePins':{file:hashlib.sha256((snapshot/file).read_bytes()).hexdigest() for file in ['apps/cli/src/main.ts','apps/cli/src/main.test.ts','apps/cli/dist/main.js']}}
(snapshot/'command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2)); print(p.stdout.decode(errors='replace')[-7000:]); raise SystemExit(p.returncode)
