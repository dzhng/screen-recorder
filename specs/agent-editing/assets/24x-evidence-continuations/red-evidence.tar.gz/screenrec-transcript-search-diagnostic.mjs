import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, realpath } from 'node:fs/promises';
import { join } from 'node:path';
import { loadavg } from 'node:os';
import { JourneyService, poll, hash, root } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
import { writeSourceWave } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/audio-project-fixture.mjs';
import { transcriptDurationFixture } from '/Users/david/dev/screen-recorder/packages/test-harness/editing/transcript-duration-fixture.mjs';

const out = '/tmp/screenrec-transcript-search-diagnostic';
await mkdir(out, { recursive: true });
const source = join(out, 'source.wav');
await writeSourceWave(source, { source: 0, seconds: 6 });
const fixture = await transcriptDurationFixture(out, source);
const home = await realpath(await mkdtemp('/tmp/sr-search-throughput-'));
const report = {
  passed: false, trace: [], home,
  scope: 'One two-hour/10000-occurrence public search throughput diagnostic; unchanged frozen first-segment words over synthetic admitted PCM; declared model readiness and inference',
  sourceSha256: hash(await readFile(source)), fixture: fixture.evidence,
  nativeSha256: hash(await readFile(process.env.SCREENREC_NATIVE)),
  nodeVersion: process.version, loadAtStart: loadavg(),
  controls: { seconds: 7200, occurrences: 10000, clipUs: 320000, matches: 250, text: 'so', warmTrials: 20, cachedP95BudgetMs: 250 },
  queries: [],
};
const config = await fixture.configure(report, 1);
const service = new JourneyService(home, report, config,
  new URL('file://' + join(root, 'packages/test-harness/editing/transcript-duration-service.mjs')));
const call = (operation, params, transport = 'mcp') => service.call(operation, params, { transport });
const save = () => writeFile(join(out, 'report.json'), JSON.stringify(report, null, 2));
try {
  await service.start();
  const imported = await call('asset.import', { path: source, requestId: 'source' });
  const admitted = await poll(() => call('job.get', { jobId: imported.jobId }), value => value.state === 'ready', 'import');
  const asset = await call('asset.get', { assetId: admitted.result.assetId });
  report.asset = asset;
  const selection = { assetId: asset.id, streamId: asset.streams[0].id };
  const sourceTranscript = await poll(() => call('transcript.get', { ...selection, limit: 1000 }), value => value.state === 'ready', 'ingestion');
  report.sourceTranscript = sourceTranscript;
  const generation = sourceTranscript.generation;
  assert.deepEqual(sourceTranscript.page.rows.filter(row => row.type === 'word').slice(0, 5)
    .map(row => ({ text: row.text, source: row.sourceRange })),
    fixture.words.map(word => ({ text: word.text, source: word.source })));
  const created = await call('project.create', { requestId: 'project', canvas: { width: 16, height: 16, fps: { numerator: 30, denominator: 1 }, background: '#000000ff' } });
  const projectId = created.project.projectId;
  let revisionId = created.revision.id;
  const apply = async (operations, requestId) => {
    const result = await call('edit.apply', { projectId, expectedRevisionId: revisionId, requestId, operations });
    revisionId = result.revision.id;
    return result;
  };
  const trackId = (await apply([{ operation: 'track.add', label: 'track', track: { kind: 'audio', order: 0 } }], 'track')).edit.labels.track;
  const durationUs = 7200e6, clipUs = 320000;
  const starts = Array.from({ length: 10000 }, (_, index) => Math.floor(index * (durationUs - clipUs) / 9999));
  const clipIds = [];
  let last;
  for (let first = 0; first < 10000; first += 500) {
    last = await apply(starts.slice(first, first + 500).map((startUs, offset) => ({
      operation: 'place', label: `word-${first + offset}`,
      clip: { trackId, ...selection, source: { kind: 'range', range: fixture.words[(first + offset) % 5].source },
        placement: { kind: 'project', range: { startUs, endUs: startUs + clipUs } } },
    })), `place-${first}`);
    for (let offset = 0; offset < 500; offset++) clipIds.push(last.edit.labels[`word-${first + offset}`]);
  }
  assert.equal(last.revision.ordinal, 21);
  assert.equal(last.revision.document.clips.length, 10000);
  assert.equal(last.revision.document.tracks.length, 1);
  assert.equal(last.revision.document.groups.length, 0);
  Object.assign(report, { projectId, revisionId, revisionOrdinal: last.revision.ordinal });
  await writeFile(join(out, 'authored-revision.json'), JSON.stringify(last.revision));
  const word = fixture.words[1];
  assert.equal(word.text, 'so');
  const expected = Array.from({ length: 250 }, (_, index) => {
    const occurrence = 1 + index * 5;
    const projectRange = { startUs: starts[occurrence], endUs: starts[occurrence] + clipUs };
    return { trackId, trackRank: 0, words: [{ type: 'word', id: 'w1', ordinal: 1, text: word.text,
      kind: 'speech', confidence: word.confidence, segment: 0, sourceRange: word.source, partial: false,
      clipId: clipIds[occurrence], ...selection, trackId, trackRank: 0, generation,
      fragments: [{ source: word.source, project: projectRange }] }], projectRange };
  });
  await writeFile(join(out, 'expected-matches.json'), JSON.stringify(expected, null, 2));
  await service.stop();
  await service.start();
  report.queryPid = service.child.pid;
  const read = async (label, transport = 'mcp') => {
    const entries = [], pages = [];
    let cursor;
    const at = performance.now();
    do {
      const params = { projectId, revisionId, text: 'so', limit: 250 - entries.length, ...(cursor ? { cursor } : {}) };
      const response = await poll(() => call('transcript.search', params, transport), value => value.state === 'ready', 'search');
      assert.equal(response.projectId, projectId);
      assert.equal(response.revisionId, revisionId);
      assert.equal(response.dependencies.length, 1);
      assert.equal(response.dependencies[0].transcript.generation, generation);
      assert.deepEqual(response.dependencies[0].transcript.engine, fixture.engine);
      assert.notDeepEqual(response.page.nextCursor, cursor, 'Continuation must progress');
      pages.push({ request: { operation: 'transcript.search', params, transport }, response });
      entries.push(...response.page.entries);
      cursor = response.page.nextCursor;
      assert.ok(pages.length <= 100, 'A fixed 250-match workload must terminate within bounded continuations');
    } while (entries.length < 250 && cursor);
    assert.deepEqual(entries, expected, 'Every exact so occurrence, identity and clock must agree');
    assert.ok(cursor, 'Remaining source occurrences must retain a continuation');
    const rowsSha256 = hash(Buffer.from(JSON.stringify(entries)));
    const elapsedMs = performance.now() - at;
    const file = `${label}-pages.json`;
    await writeFile(join(out, file), JSON.stringify(pages));
    const measurement = { label, transport, elapsedMs, pages: pages.length, entriesPerPage: pages.map(page => page.response.page.entries.length), matches: entries.length, rowsSha256, file };
    report.queries.push(measurement);
    await save();
    return measurement;
  };
  report.cold = await read('cold');
  for (let trial = 0; trial < 20; trial++) {
    const measured = await read(`warm-${trial + 1}`);
    assert.equal(measured.rowsSha256, report.cold.rowsSha256);
  }
  report.cli = await read('cli', 'cli');
  assert.equal(report.cli.rowsSha256, report.cold.rowsSha256);
  const warm = report.queries.filter(query => query.label.startsWith('warm-')).map(query => query.elapsedMs).sort((a, b) => a - b);
  report.cachedP95Ms = warm[Math.ceil(warm.length * 0.95) - 1];
  report.passed = report.cachedP95Ms <= 250;
  const operations = (await readFile(report.nativeOperationsFile, 'utf8')).trim().split('\n').map(JSON.parse);
  assert.deepEqual(operations.filter(({ operation }) => operation !== 'storage.clearRenderWorkspace'), [{ operation: 'media.probe' }, { operation: 'speech.transcribe' }]);
  report.noQueryNativeWork = true;
  report.loadAtEnd = loadavg();
  await save();
  assert.ok(report.passed, 'Cached complete 250-match search exceeded unchanged 250ms p95 budget');
} catch (error) {
  report.error = { message: error.message, stack: error.stack };
  throw error;
} finally {
  await service.stop();
  await save();
}
