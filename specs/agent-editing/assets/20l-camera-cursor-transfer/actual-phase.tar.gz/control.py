"""Frozen supervisor for the reviewed fixed experiment; no product executor."""
import pathlib,json,subprocess,selectors,signal,os,time,datetime,hashlib,sys,ctypes
libproc=ctypes.CDLL('/usr/lib/libproc.dylib')
libproc.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int];libproc.proc_pidinfo.restype=ctypes.c_int
root=pathlib.Path(__file__).parent;plan=json.loads((root/'plan.json').read_text());records=[];phase=time.monotonic()
def save():
    (root/'processes.json').write_text(json.dumps({'phaseBoundSeconds':180,'elapsedSeconds':time.monotonic()-phase,'processes':records},indent=2)+'\n')
def receipts(case):
    out=[]
    if case:
        for path in case.rglob('*.process.json'):
            try:out.append({'path':str(path),'receipt':json.loads(path.read_text())})
            except (OSError,json.JSONDecodeError):pass # Atomic writer receipt may not have appeared yet.
    return out
def run(label,argv,bound,case=None,ownership=False):
    bound=min(bound,180-(time.monotonic()-phase));assert bound>0
    with (root/(label+'.stdout')).open('wb') as stdout,(root/(label+'.stderr')).open('wb') as stderr:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        start=time.monotonic();waited=False;r={'label':label,'argv':argv,'pid':p.pid,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundSeconds':bound,'terminal':False};records.append(r);save()
        streams=selectors.DefaultSelector();streams.register(p.stdout,selectors.EVENT_READ,('stdout',stdout));streams.register(p.stderr,selectors.EVENT_READ,('stderr',stderr));sizes={'stdout':0,'stderr':0}
        def drain(wait):
            for key,_ in streams.select(wait):
                data=os.read(key.fileobj.fileno(),65536);name,destination=key.data
                if not data:streams.unregister(key.fileobj);key.fileobj.close();continue
                remaining=1048576-sizes[name];destination.write(data[:remaining]);destination.flush();sizes[name]+=min(len(data),remaining)
                if len(data)>remaining:raise RuntimeError('1 MiB '+name+' cap')
        try:
            while streams.get_map() or p.poll() is None:
                if time.monotonic()-start>bound:raise TimeoutError(label+' work deadline')
                drain(.02)
            p.wait();waited=True;expected=0
            assert p.returncode==expected,(label,p.returncode,expected)
        except BaseException as error:
            r['controllerFailure']=repr(error)
            # Terminate the actual owned query child first; native waitUntilExit reaps it.
            cleanup=[];grace=time.monotonic()+1
            for entry in receipts(case):
                q=entry['receipt']
                if q.get('terminal') or q.get('parentPID')!=p.pid:continue
                try:
                    # SDK proc_bsdinfo begins with five uint32 fields; actual PPID is at byte16.
                    info=ctypes.create_string_buffer(4096);size=libproc.proc_pidinfo(q['pid'],3,0,info,len(info))
                    actual_parent=int.from_bytes(info.raw[16:20],sys.byteorder) if size>=20 else None
                    if p.poll() is None and actual_parent==p.pid and os.getpgid(q['pid'])==q['groupID']:
                        os.kill(q['pid'],signal.SIGKILL);cleanup.append({'pid':q['pid'],'signal':'SIGKILL','actualPPID':p.pid,'actualPGID':q['groupID'],'receipt':entry['path']})
                    else:cleanup.append({'pid':q['pid'],'notInLiveOwnedGroup':True,'receipt':entry['path']})
                except ProcessLookupError:cleanup.append({'pid':q['pid'],'alreadyAbsent':True,'receipt':entry['path']})
                except (OSError,KeyError,TypeError,ValueError) as guardError:cleanup.append({'pid':q.get('pid'),'identityUnknown':repr(guardError),'receipt':entry['path']})
            r['queryCleanup']=cleanup;r['cleanupGraceSeconds']=1
            while p.poll() is None and time.monotonic()<grace:
                try:drain(.02)
                except RuntimeError:break
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGKILL);r['writerCleanupSignal']='SIGKILL after query-first grace'
                except ProcessLookupError:r['parentAlreadyAbsentBeforeKill']=True
            p.wait(timeout=5);waited=True
            if ownership and isinstance(error,TimeoutError) and p.returncode==0 and len(cleanup)==1 and cleanup[0].get('signal')=='SIGKILL' and 'writerCleanupSignal' not in r:
                r['expectedOwnershipDeadline']=True
                while streams.get_map() and time.monotonic()<grace:drain(.01)
                final=receipts(case);assert len(final)==1 and final[0]['receipt']['terminal'] and final[0]['receipt']['waited'] and final[0]['receipt']['exitCode']==9
                verdict=json.loads((case/'verdict.json').read_text());assert verdict['status']=='pass'
            else:raise
        finally:
            fullyDrained=not bool(streams.get_map());streams.close()
            for stream in [p.stdout,p.stderr]:
                if not stream.closed:stream.close()
            absence=[]
            for entry in receipts(case):
                q=entry['receipt'];fact={'pid':q.get('pid'),'receipt':entry['path'],'terminalReceipt':q.get('terminal'),'waitedReceipt':q.get('waited')}
                try:os.kill(q['pid'],0);fact['absent']=False
                except ProcessLookupError:fact['absent']=True
                except (OSError,KeyError,TypeError,ValueError) as observationError:fact['absent']=None;fact['observationError']=repr(observationError)
                absence.append(fact)
            try:os.kill(p.pid,0);parentAbsent=False
            except ProcessLookupError:parentAbsent=True
            except OSError:parentAbsent=None
            r.update(streamsFullyDrained=fullyDrained,terminal=p.returncode is not None,waited=waited,parentAbsent=parentAbsent,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,stdioBytes=sizes,stdioCapBytes=1048576,byteQueries=receipts(case),queryAbsence=absence);save()
def cache():
    folder=pathlib.Path(plan['moduleCache']);return [{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'mtimeNs':p.stat().st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(folder.rglob('*')) if p.is_file()]
try:
    authority=json.loads((root/'authority.json').read_text())
    for pin in authority['pins']:
        p=pathlib.Path(pin['path']);d=p.read_bytes();assert len(d)==pin['bytes'] and hashlib.sha256(d).hexdigest()==pin['sha256'],str(p)
    (root/'cache-before.json').write_text(json.dumps(cache(),indent=2)+'\n')
    run('compile',plan['compile'],150)
    binary=pathlib.Path(plan['native'][0]);(root/'binary.json').write_text(json.dumps({'path':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
    run('transfer',plan['native'],15,root/'case')
    assert json.loads((root/'case/verdict.json').read_text())['status']=='pass'
    assert records[-1]['terminal'] and records[-1]['waited'] and records[-1]['parentAbsent'] is True
    (root/'controller-verdict.json').write_text(json.dumps({'status':'pass','scope':'197 unchanged cursor buffers: candidate own active prefix and closed pixels/support/full-reader facts; no live/adoption'},indent=2)+'\n')
except BaseException as error:
    (root/'controller-verdict.json').write_text(json.dumps({'status':'fail','error':repr(error),'noRetry':True},indent=2)+'\n');print('FAIL',error);sys.exit(1)
finally:
    (root/'cache-after.json').write_text(json.dumps(cache(),indent=2)+'\n');save()
