@preconcurrency import AVFoundation
import Foundation
import CoreMedia
import Darwin
import ScreenRecorderMedia

struct FrozenPictures:Decodable {let pictures:[Picture];let nativeScale:Int32;let duration:Tick;let readerStatus:Int}
struct SavedCursorRow:Decodable {let ordinal:Int;let cursor:CursorFact}
struct SavedNativeInventory:Decodable {let rows:[SavedCursorRow];let nativeDuration:Tick;let nativeScale:Int32;let segmentBounds:[SegmentBounds]}
struct Packet:Codable,Equatable {
    let decodePosition:Int;let presentationOrdinal:Int;let pts:Tick;let dts:Tick;let duration:Tick
    let payload:Data;let attachmentsJSON:Data?;let formatEqualToSource:Bool
}
func nativeTime(_ t:Tick)->CMTime {CMTime(value:t.value,timescale:t.scale,flags:CMTimeFlags(rawValue:t.flags),epoch:t.epoch)}
func packet(_ sample:CMSampleBuffer,position:Int,presentation:Int,description:CMFormatDescription) throws -> Packet {
    guard let block=sample.dataBuffer,let format=sample.formatDescription,sample.numSamples==1 else {throw ProbeFailure(message:"Compressed sample lacks one complete block/format")}
    let length=CMBlockBufferGetDataLength(block);guard length>0 && length<=65_536 else {throw ProbeFailure(message:"Compressed packet length outside fixed bound")}
    var data=Data(count:length)
    let status=data.withUnsafeMutableBytes {bytes in CMBlockBufferCopyDataBytes(block,atOffset:0,dataLength:length,destination:bytes.baseAddress!)}
    guard status==noErr else {throw ProbeFailure(message:"Compressed bytes unavailable: \(status)")}
    var attachments:Data?
    if let array=CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false) {
        let encoder=JSONEncoder();encoder.outputFormatting=[.sortedKeys];attachments=try encoder.encode(FormatValue(array as NSArray))
    }
    return Packet(decodePosition:position,presentationOrdinal:presentation,pts:Tick(sample.presentationTimeStamp),dts:Tick(sample.decodeTimeStamp),duration:Tick(sample.duration),payload:data,attachmentsJSON:attachments,formatEqualToSource:CMFormatDescriptionEqual(format,otherFormatDescription:description))
}
func mediaFactOperand(_ facts:[BufferFact]) throws -> Data {
    let bytes=try JSONEncoder().encode(facts.filter{$0.numSamples>0})
    guard var rows=try JSONSerialization.jsonObject(with:bytes) as? [[String:Any]] else {throw ProbeFailure(message:"Media fact encoding is not an object array")}
    for i in rows.indices {rows[i].removeValue(forKey:"bufferOrdinal")}
    return try JSONSerialization.data(withJSONObject:rows,options:[.prettyPrinted,.sortedKeys])
}
@main struct CursorTransferExperiment {
    @MainActor static func main() async {
        var ownership:OwnedEvidenceDestination?
        do {
            let args=CommandLine.arguments,mode=args[1],root=URL(fileURLWithPath:args[2])
            let owner=try OwnedEvidenceDestination(root:root);ownership=owner
            let evidence=try ObserverEvidence(root:root.appendingPathComponent("evidence"))
            guard mode=="canonical" else {throw ProbeFailure(message:"Unknown fixed case")}
            let sourceURL=URL(fileURLWithPath:args[3]),savedURL=URL(fileURLWithPath:args[4]),metadataURL=URL(fileURLWithPath:args[5]),script=args[6]
            let saved=try JSONDecoder().decode(FrozenPictures.self,from:Data(contentsOf:savedURL))
            let metadata=try JSONDecoder().decode(SavedNativeInventory.self,from:Data(contentsOf:metadataURL))
            try require(saved.pictures.count==197 && metadata.rows.count==197 && metadata.nativeScale==1_000_000,"frozen source inventory",["pictures":String(saved.pictures.count),"metadata":String(metadata.rows.count),"scale":String(metadata.nativeScale)],evidence:evidence)
            let source=AVURLAsset(url:sourceURL,options:[AVURLAssetPreferPreciseDurationAndTimingKey:true]);let tracks=try await source.loadTracks(withMediaType:.video)
            let audio=try await source.loadTracks(withMediaType:.audio)
            try require(tracks.count==1 && audio.isEmpty,"source one video/no audio",["videos":String(tracks.count)],evidence:evidence)
            let track=tracks[0],descriptions=try await track.load(.formatDescriptions),scale=try await track.load(.naturalTimeScale),transform=try await track.load(.preferredTransform)
            try require(descriptions.count==1 && scale==1_000_000,"source description/scale",["descriptions":String(descriptions.count),"scale":String(scale)],evidence:evidence)
            let description=descriptions[0]
            let sourceCodecURL=URL(fileURLWithPath:args[7]),qualifiedBufferRoot=URL(fileURLWithPath:args[8])
            let sourceFile=try FileHandle(forReadingFrom:sourceURL);defer{try? sourceFile.close()};let sourceBytes=try sourceFile.read(upToCount:2_097_153) ?? Data()
            try require(sourceBytes.count<=2_097_152,"source byte cap",["bytes":String(sourceBytes.count)],evidence:evidence)
            let ordered=metadata.rows.sorted {CMTimeCompare(nativeTime($0.cursor.clocks["mediaDTS"]!),nativeTime($1.cursor.clocks["mediaDTS"]!))<0}
            let generator=AVSampleBufferGenerator(asset:source,timebase:nil)
            var samples=[CMSampleBuffer](),packets=[Packet](),sourceCounts=[Int](),sourceFacts=[BufferFact](),sourcePayload=0
            for (position,row) in ordered.enumerated() {
                let pts=row.cursor.clocks["mediaPTS"]!,dts=row.cursor.clocks["mediaDTS"]!
                guard let cursor=track.makeSampleCursor(presentationTimeStamp:nativeTime(pts)) else {throw ProbeFailure(message:"No source cursor at decode position \(position)")}
                let request=AVSampleBufferRequest(start:cursor);request.direction = .none;request.mode = .immediate
                try save(["position":String(position),"expectedPTS":String(describing:pts),"expectedDTS":String(describing:dts),"actualPTS":String(describing:Tick(cursor.presentationTimeStamp)),"actualDTS":String(describing:Tick(cursor.decodeTimeStamp)),"overrideTime":String(describing:Tick(request.overrideTime))],root.appendingPathComponent("request-\(position).json"))
                try require(Tick(cursor.presentationTimeStamp)==pts && Tick(cursor.decodeTimeStamp)==dts,"source cursor identity",["position":String(position)],evidence:evidence)
                let sample:CMSampleBuffer
                do {sample=try generator.makeSampleBuffer(for:request)}catch {let e=error as NSError;try save(["domain":TypedFact(e.domain),"code":TypedFact(e.code),"description":TypedFact(e.localizedDescription),"userInfo":TypedFact(e.userInfo)],root.appendingPathComponent("creation-error-\(position).json"));throw error}
                let fact=observe(sample,ordinal:position,remainingPayload:2_097_152-sourcePayload,source:description)
                let actualURL=root.appendingPathComponent("source-buffer-\(position).json"),expectedURL=qualifiedBufferRoot.appendingPathComponent("buffer-\(position).json")
                try save(fact,actualURL);sourceFacts.append(fact);sourcePayload+=fact.copiedBytes;samples.append(sample);sourceCounts.append(fact.numSamples)
                try require(try Data(contentsOf:actualURL)==Data(contentsOf:expectedURL),"generated buffer differs from qualified20k",["position":String(position)],evidence:evidence)
                let record=try packet(sample,position:position,presentation:row.ordinal,description:description)
                packets.append(record);try save(packets,root.appendingPathComponent("source-packets.json"))
                let extent=row.cursor.extents["sample"]!,offset=Int(extent.offset),length=Int(extent.length)
                try require(offset>=0 && length>0 && offset+length<=sourceBytes.count,"source packet extent",["position":String(position),"offset":String(offset),"length":String(length)],evidence:evidence)
                try require(record.payload==sourceBytes.subdata(in:offset..<offset+length) && record.pts==pts && record.dts==dts && record.duration==row.cursor.clocks["decodeDuration"]! && record.formatEqualToSource,"generated packet/native correspondence",["position":String(position)],evidence:evidence)
            }
            try require(samples.count==197 && packets.count==197,"complete generated inventory",["samples":String(samples.count),"packets":String(packets.count)],evidence:evidence)
            var cumulative=0,boundaries=[Int:Int]()
            for (i,n) in sourceCounts.enumerated() {cumulative+=n;if n>0 && [59,175,197].contains(cumulative){boundaries[cumulative]=i+1}}
            try save(boundaries.map{["media":$0.key,"bufferEndExclusive":$0.value]}.sorted{$0["media"]!<$1["media"]!},root.appendingPathComponent("whole-buffer-boundaries.json"))
            try require(boundaries.count==3 && cumulative==197,"fixed media boundaries do not coincide with whole buffers",["media":String(cumulative)],evidence:evidence)
            let movie=root.appendingPathComponent("candidate.mov"),writer=try AVAssetWriter(outputURL:movie,fileType:.mov)
            var appended=[Packet](),appendedBuffers=0,forwardReceipts=[[String:String]]()
            defer {
                try? save(appended,root.appendingPathComponent("appended-packets.json"));try? save(forwardReceipts,root.appendingPathComponent("forwarded-buffers.json"))
                evidence.preserve(mappings:[],observations:Data(),receipts:[],raw:movie)
                if writer.status == .writing{writer.cancelWriting()}
            }
            writer.movieTimeScale=scale;writer.initialMovieFragmentInterval=CMTime(value:1,timescale:4);writer.movieFragmentInterval=CMTime(value:1,timescale:1)
            let input=AVAssetWriterInput(mediaType:.video,outputSettings:nil,sourceFormatHint:description);input.mediaTimeScale=scale;input.transform=transform
            try require(writer.canAdd(input),"candidate rejects passthrough input",[:],evidence:evidence);writer.add(input)
            let writing=writer.startWriting();try require(writing,"candidate writer start",["status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence);writer.startSession(atSourceTime:.zero)
            let started=ContinuousClock.now
            func appendBuffers(to end:Int) async throws {
                for i in appendedBuffers..<end {
                    while !input.isReadyForMoreMediaData {
                        try require(writer.status == .writing && started.duration(to:.now) < .seconds(15),"passthrough admission deadline",["buffer":String(i),"status":String(writer.status.rawValue)],evidence:evidence)
                        try await Task.sleep(for:.milliseconds(1))
                    }
                    let accepted=input.append(samples[i]) // Exact generated object; no reconstruction, markers or attachment change.
                    forwardReceipts.append(["bufferOrdinal":String(i),"numSamples":String(sourceCounts[i]),"accepted":String(accepted),"status":String(writer.status.rawValue),"error":String(describing:writer.error)])
                    try save(forwardReceipts,root.appendingPathComponent("forwarded-buffers.json"))
                    try require(accepted,"intact passthrough buffer append failed",["buffer":String(i),"numSamples":String(sourceCounts[i]),"status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence)
                    if sourceCounts[i]>0 {appended.append(packets[appended.count]);try save(appended,root.appendingPathComponent("appended-packets.json"))}
                    appendedBuffers+=1
                }
            }
            func append(to media:Int) async throws {try await appendBuffers(to:boundaries[media]!);try require(appended.count==media,"whole-buffer media admission",["media":String(appended.count),"buffers":String(appendedBuffers)],evidence:evidence)}
            var last=0,candidate:Snapshot?,candidateCodec:URL?,fence:Int?,selectedCount:Int?,activePassed=false
            func observeCandidate() async throws {
                guard let (copy,n)=try frozenExtension(movie,root,last,evidence:evidence) else{return}
                let snap=try await read(copy,phase:"canonical-active-\(n)",fragments:n,evidence:evidence)
                let snapshotURL=root.appendingPathComponent("active-\(n).json"),fmtURL=root.appendingPathComponent("active-\(n)-formats.json"),codecURL=root.appendingPathComponent("active-\(n)-codec.json")
                try save(snap,snapshotURL);try save(try await formatFacts(copy,snap,evidence:evidence),fmtURL)
                let result=try inspectBytes(copy,snapshotURL,fmtURL,codecURL,script,evidence:evidence)
                try require(snap.canContainFragments==true && (n==1 || snap.containsFragments==true),"native candidate fragment qualification",["count":String(n)],evidence:evidence)
                if candidate==nil,let selected=result.completeIDRFenceOrdinals.min() {
                    try require(snap.pictures.count>selected,"candidate closing IDR was not decoded",["fence":String(selected),"pictures":String(snap.pictures.count)],evidence:evidence)
                    candidate=snap;candidateCodec=codecURL;fence=selected;selectedCount=appended.count
                    try save(snap,root.appendingPathComponent("candidate-prefix.json"));try save(["fenceOrdinal":selected,"appendedAtSelection":appended.count,"fragment":n],root.appendingPathComponent("selection.json"))
                } else if let candidate,let fence,let expected=candidateCodec,let count=selectedCount {
                    try save(["candidateAppended":count,"laterAppended":appended.count,"candidateFragment":candidate.completedFragments,"laterFragment":n,"closeCalled":0],root.appendingPathComponent("active-\(n)-comparison-receipt.json"))
                    try require(appended.count>count && n>candidate.completedFragments,"further active successful append absent",["selected":String(count),"later":String(appended.count)],evidence:evidence)
                    try compare(Array(candidate.pictures.prefix(fence)),snap,evidence:evidence);try compareLogical(expected,codecURL,fence,script,root.appendingPathComponent("active-\(n)-logical-comparison.json"),evidence:evidence);activePassed=true
                }
                last=n
            }
            try await append(to:59)
            while candidate==nil && started.duration(to:.now) < .seconds(7){try await observeCandidate();if candidate==nil{try await Task.sleep(for:.milliseconds(20))}}
            try require(candidate != nil && selectedCount==59,"first fixed batch lacks a complete candidate IDR fence",["appended":String(appended.count)],evidence:evidence)
            try await append(to:175)
            while !activePassed && started.duration(to:.now) < .seconds(14){try await observeCandidate();if !activePassed{try await Task.sleep(for:.milliseconds(20))}}
            try require(activePassed,"second fixed batch lacks further active candidate extension",["appended":String(appended.count),"fragments":String(last)],evidence:evidence)
            try await append(to:197)
            try await appendBuffers(to:samples.count)
            try require(appendedBuffers==197 && appended.count==197,"complete generated forwarding before close",["buffers":String(appendedBuffers),"media":String(appended.count)],evidence:evidence)
            let end=saved.pictures.last!.end!;writer.endSession(atSourceTime:nativeTime(end));input.markAsFinished();await writer.finishWriting()
            try require(writer.status == .completed,"candidate closure failed",["status":String(writer.status.rawValue),"error":String(describing:writer.error)],evidence:evidence)
            let final=try await read(movie,phase:"canonical-closed",fragments:try fragments(movie,evidence:evidence),evidence:evidence)
            let finalURL=root.appendingPathComponent("closed.json"),fmtURL=root.appendingPathComponent("closed-formats.json"),codecURL=root.appendingPathComponent("closed-codec.json")
            try save(final,finalURL);try save(try await formatFacts(movie,final,evidence:evidence),fmtURL);_ = try inspectBytes(movie,finalURL,fmtURL,codecURL,script,evidence:evidence)
            try compareLogical(sourceCodecURL,codecURL,197,script,root.appendingPathComponent("all197-source-logical-comparison.json"),evidence:evidence)
            let reopened=AVURLAsset(url:movie),reopenedTracks=try await reopened.loadTracks(withMediaType:.video)
            try require(reopenedTracks.count==1,"closed compressed track count",["count":String(reopenedTracks.count)],evidence:evidence)
            let compressedReader=try AVAssetReader(asset:reopened);defer{compressedReader.cancelReading()}
            let compressedOutput=AVAssetReaderTrackOutput(track:reopenedTracks[0],outputSettings:nil);compressedOutput.alwaysCopiesSampleData=false;compressedReader.add(compressedOutput)
            let compressedStarted=compressedReader.startReading();try require(compressedStarted,"closed compressed reader start",["status":String(compressedReader.status.rawValue)],evidence:evidence)
            var closedPackets=[Packet](),closedSamples=[CMSampleBuffer](),closedFacts=[BufferFact](),closedBufferOrdinal=0,closedPayload=0
            while let sample=compressedOutput.copyNextSampleBuffer() {
                let fact=observe(sample,ordinal:closedBufferOrdinal,remainingPayload:2_097_152-closedPayload,source:description)
                try save(fact,root.appendingPathComponent("closed-buffer-\(closedBufferOrdinal).json"));closedSamples.append(sample);closedFacts.append(fact);closedBufferOrdinal+=1;closedPayload+=fact.copiedBytes
                try require(closedBufferOrdinal<=512 && fact.blockCopyComplete != false,"closed buffer observation bound",["buffers":String(closedBufferOrdinal)],evidence:evidence)
            }
            try save(["buffers":String(closedBufferOrdinal),"media":String(closedFacts.reduce(0){$0+$1.numSamples}),"status":String(compressedReader.status.rawValue),"error":String(describing:compressedReader.error)],root.appendingPathComponent("closed-buffer-eof.json"))
            try save(sourceFacts,root.appendingPathComponent("source-full-buffer-facts.json"));try save(closedFacts,root.appendingPathComponent("closed-full-buffer-facts.json"))
            let fullReaderRoot=URL(fileURLWithPath:args[9])
            let fullReaderRows=try (1...197).map {i -> [String:Any] in
                guard var row=try JSONSerialization.jsonObject(with:Data(contentsOf:fullReaderRoot.appendingPathComponent("buffer-\(i).json"))) as? [String:Any] else {throw ProbeFailure(message:"Saved full-reader buffer is not an object")}
                row.removeValue(forKey:"bufferOrdinal");return row
            }
            let expectedFacts=try JSONSerialization.data(withJSONObject:fullReaderRows,options:[.prettyPrinted,.sortedKeys]),actualFacts=try mediaFactOperand(closedFacts)
            let expectedFactsURL=root.appendingPathComponent("source-media-facts-without-ordinal.json"),actualFactsURL=root.appendingPathComponent("closed-media-facts-without-ordinal.json")
            try expectedFacts.write(to:expectedFactsURL);try actualFacts.write(to:actualFactsURL)
            try require(expectedFacts==actualFacts,"complete media BufferFact mismatch; only bufferOrdinal excluded",["expected":expectedFactsURL.path,"actual":actualFactsURL.path],evidence:evidence)
            for sample in closedSamples where CMSampleBufferGetNumSamples(sample)>0 {
                let i=closedPackets.count;try require(i<197,"extra closed media",["position":String(i)],evidence:evidence)
                closedPackets.append(try packet(sample,position:i,presentation:ordered[i].ordinal,description:description))
            }
            try save(closedPackets,root.appendingPathComponent("closed-packets.json"))
            try require(compressedReader.status == .completed && closedPackets==packets,"all compressed payload/attachment/timing/format receipts differ",["status":String(compressedReader.status.rawValue),"expectedCount":String(packets.count),"actualCount":String(closedPackets.count),"expectedOperand":"source-packets.json","actualOperand":"closed-packets.json"],evidence:evidence)
            try compare(saved.pictures,final,evidence:evidence);try require(final.pictures.count==197 && (final.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}) == (metadata.segmentBounds.map{[$0.mediaStart,$0.mediaDuration,$0.assetStart,$0.assetDuration]}),"complete candidate support/inventory correspondence",["count":String(final.pictures.count)],evidence:evidence)
            try compare(Array(candidate!.pictures.prefix(fence!)),final,evidence:evidence);try compareLogical(candidateCodec!,codecURL,fence!,script,root.appendingPathComponent("closed-prefix-logical-comparison.json"),evidence:evidence)
            try save(["status":"pass","scope":"Cursor-generated unchanged197 buffer transfer: own active prefix/full pixels/support and original full-reader facts; no live/adoption","committedPictures":String(fence!),"appendedMedia":"197","forwardedBuffers":String(appendedBuffers)],root.appendingPathComponent("verdict.json"))
        }catch{if let owner=ownership{try? save(["status":"fail","error":String(describing:error)],owner.failure)};print("FAIL \(error)");Darwin.exit(1)}
    }
}
