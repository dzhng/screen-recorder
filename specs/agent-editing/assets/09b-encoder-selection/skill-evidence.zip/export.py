from client import *
import uuid,hashlib
d=json.loads((B/'preview-deliver.stdout.json').read_text())['data']
(B/'exports').mkdir(exist_ok=True)
p={'projectId':d['projectId'],'revisionId':d['revisionId'],'exportId':str(uuid.uuid4()),'directory':str(B/'exports'),'leaf':'software-durable.mp4','kind':'video','settings':d['settings']}
x=call('export-create','export.create',p);print(json.dumps(x),flush=True)
for i in range(90):
 x=call('export-status-%02d'%i,'export.status',{'exportId':p['exportId']})
 print(json.dumps(x),flush=True)
 if not x['ok'] or x['data'].get('state') in ['committed','failed']: break
 time.sleep(1)
print('REPLAY',json.dumps(call('export-replay','export.create',p)),flush=True)
