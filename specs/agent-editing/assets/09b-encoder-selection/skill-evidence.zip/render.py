from client import *
def data(n): return json.loads((B/(n+'.stdout.json')).read_text())['data']
c=data('create');ops=[]
for n,kind in [('video','video'),('narration','audio')]:
 a=data('asset-'+n);s=next(s for s in a['streams'] if s['kind']==kind)
 assert s['startUs']<=1000000 and s['endUs']>=4000000
 ops += [{'operation':'track.add','track':{'kind':kind,'order':0},'label':n},{'operation':'place','clip':{'trackId':{'label':n},'assetId':a['id'],'streamId':s['id'],'source':{'kind':'range','range':{'startUs':1000000,'endUs':4000000}},'placement':{'kind':'project','range':{'startUs':0,'endUs':3000000}}}}]
r=call('edit','edit.apply',{'projectId':c['project']['projectId'],'expectedRevisionId':c['revision']['id'],'requestId':'fresh-place','operations':ops})
print(json.dumps(r))
