import json,subprocess,pathlib,time
B=pathlib.Path('/tmp/screenrec-output-fresh-skill')
def call(name,op,p,output=None):
 (B/(name+'.request.json')).write_text(json.dumps(p,indent=2))
 cmd=['node','/Users/david/dev/screen-recorder/apps/cli/dist/main.js',op,'--socket',json.loads((B/'service.json').read_text())['socketPath'],'--params','-']
 if output: cmd+=['--output',str(B/output)]
 (B/(name+'.command.json')).write_text(json.dumps(cmd))
 r=subprocess.run(cmd,input=json.dumps(p),text=True,capture_output=True)
 (B/(name+'.stdout.json')).write_text(r.stdout);(B/(name+'.stderr.txt')).write_text(r.stderr);(B/(name+'.exit.txt')).write_text(str(r.returncode))
 return json.loads(r.stdout)
if __name__=='__main__':
 print(json.dumps(call('capabilities','output.capabilities',{}),indent=2))
 for n in ['video','narration']:
  print(n,call('import-'+n,'asset.import',{'requestId':'fresh-'+n,'path':'/Users/david/dev/screen-recorder/fixtures/narrated-workbench/'+n+'.mov'}))
 print(call('create','project.create',{'requestId':'fresh-project','title':'Fresh output workflow','canvas':{'width':640,'height':360,'fps':{'numerator':24,'denominator':1},'background':'#000000ff'}}))
