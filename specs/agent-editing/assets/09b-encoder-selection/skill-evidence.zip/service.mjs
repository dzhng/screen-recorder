import {JourneyService} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
import {mkdtempSync,writeFileSync,existsSync} from 'node:fs';
const base='/tmp/screenrec-output-fresh-skill';
const home=mkdtempSync('/tmp/srof-'); const report={trace:[]};
const s=new JourneyService(home,report);
try {await s.start();writeFileSync(base+'/service.json',JSON.stringify({home,socketPath:s.socketPath}));while(!existsSync(base+'/STOP')) await new Promise(r=>setTimeout(r,300));}
finally {await s.stop();writeFileSync(base+'/stopped.json',JSON.stringify({stopped:true,report}));}
