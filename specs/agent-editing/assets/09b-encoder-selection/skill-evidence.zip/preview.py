from client import *
r=json.loads((B/'edit.stdout.json').read_text())['data']['revision']
caps=json.loads((B/'capabilities.stdout.json').read_text())['data']
sw=next(e for e in caps['encoderSelection']['encoders'] if e['name']=='Apple H.264 (SW)')
settings={'video':{'encoder':{'hardware':'disabled','id':sw['id'],'gpu':None},'rateControl':{'mode':'average','bitrate':1750000},'profile':'main','level':'3.1','keyframeInterval':37,'keyframeIntervalSeconds':1.5,'openGop':None,'prioritizeSpeed':None,'spatialAdaptiveQuantization':None},'audio':{'sampleRate':44100,'layout':'mono','rateControl':{'mode':'constant','bitrate':80000},'quality':'medium'}}
assert any(f['sampleRate']==44100 and f['layout']=='mono' and f['strategy']=='constant' and 80000 in f['bitrates'] for f in caps['encodedAudio']['formats'])
p={'projectId':r['projectId'],'revisionId':r['id'],'settings':settings}
for i in range(90):
 x=call('preview-%02d'%i,'preview.get',p)
 print(i,json.dumps(x),flush=True)
 if not x['ok'] or x['data'].get('state') in ['ready','failed']: break
 time.sleep(1)
if x['ok'] and x['data'].get('state')=='ready': print(call('preview-deliver','preview.get',p,'software-preview.mp4'))
