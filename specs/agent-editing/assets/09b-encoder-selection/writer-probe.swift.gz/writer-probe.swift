import AVFoundation
import VideoToolbox
import Foundation
Task {
 var results:[[String:Any]]=[]
 let cases:[(String,[String:Any])] = [
  ("required-hardware",[kVTVideoEncoderSpecification_RequireHardwareAcceleratedVideoEncoder as String:true]),
  ("disabled-hardware",[kVTVideoEncoderSpecification_EnableHardwareAcceleratedVideoEncoder as String:false]),
  ("impossible-required-gpu",[kVTVideoEncoderSpecification_RequiredEncoderGPURegistryID as String:NSNumber(value:UInt64.max)]),
  ("impossible-preferred-gpu",[kVTVideoEncoderSpecification_PreferredEncoderGPURegistryID as String:NSNumber(value:UInt64.max)])]
 for (name,specification) in cases {
  let path="/tmp/selection-writer-\(name).mp4";try? FileManager.default.removeItem(atPath:path)
  let writer=try AVAssetWriter(outputURL:URL(fileURLWithPath:path),fileType:.mp4)
  let input=AVAssetWriterInput(mediaType:.video,outputSettings:[AVVideoCodecKey:AVVideoCodecType.h264,AVVideoWidthKey:128,AVVideoHeightKey:128,AVVideoEncoderSpecificationKey:specification])
  let adaptor=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,kCVPixelBufferWidthKey as String:128,kCVPixelBufferHeightKey as String:128])
  writer.add(input);writer.startWriting();writer.startSession(atSourceTime:.zero)
  var pixel:CVPixelBuffer?;CVPixelBufferCreate(nil,128,128,kCVPixelFormatType_32BGRA,[kCVPixelBufferIOSurfacePropertiesKey:[:]] as CFDictionary,&pixel)
  CVPixelBufferLockBaseAddress(pixel!,[]);memset(CVPixelBufferGetBaseAddress(pixel!),0,CVPixelBufferGetDataSize(pixel!));CVPixelBufferUnlockBaseAddress(pixel!,[])
  for index in 0..<30 {
   let deadline=Date().addingTimeInterval(5)
   while !input.isReadyForMoreMediaData && writer.status == .writing && Date()<deadline { try await Task.sleep(for:.milliseconds(1)) }
   guard input.isReadyForMoreMediaData,adaptor.append(pixel!,withPresentationTime:CMTime(value:Int64(index),timescale:30)) else {break}
  }
  if writer.status == .writing {input.markAsFinished();await writer.finishWriting()}
  results.append(["policy":name,"status":writer.status.rawValue,"error":writer.error?.localizedDescription ?? "none"])
 }
 let data=try JSONSerialization.data(withJSONObject:results,options:[.prettyPrinted,.sortedKeys]);try data.write(to:URL(fileURLWithPath:"/tmp/screenrec-selection-writer.json"));print(String(decoding:data,as:UTF8.self));exit(0)
}
dispatchMain()
