import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='/tmp/screenrec-audio-rates-controlled', out='/tmp/screenrec-aac-repeat-fixed'; mkdirSync(out);
const prior=JSON.parse(readFileSync(root+'/report.json')).cases[0];
function samples(file){const b=readFileSync(file);for(let p=12;p<b.length;){let n=b.readUInt32LE(p+4);if(b.toString('ascii',p,p+4)==='data')return Array.from({length:n/4},(_,i)=>b.readFloatLE(p+8+i*4));p+=8+n+(n%2)}throw Error('No PCM')}
function diff(a,b){assert.equal(a.length,b.length);let max=0,sum=0,count=0;for(let i=0;i<a.length;i++){let d=Math.abs(a[i]-b[i]);max=Math.max(max,d);sum+=d*d;if(d)count++}return{maximum:max,rms:Math.sqrt(sum/a.length),changedSamples:count}}
const report={scope:'Repeated fresh native invocations with one frozen AAC input; no listening',cases:[]};
for(const kind of ['source','resampled']){
 const results=[];
 for(let i=0;i<8;i++){
  const params=structuredClone(kind==='source'?prior.windows[0].nativeRequest:prior.windows[0].componentRequest);
  params.output=`${out}/${kind}-${i}.wav`;
  if(kind==='source')params.source.source=root+'/m4a-encoded.m4a';
  else params.assets=params.assets.filter(v=>v.assetId==='rate-m4a').map(v=>({...v,path:root+'/m4a-encoded.m4a'}));
  const request={id:`${kind}-${i}`,operation:kind==='source'?'media.sourceAudio':'media.mixCompositionAudio',params};
  const r=spawnSync('/tmp/screenrec-caption-output-combined-native',[],{input:JSON.stringify(request)+'\n',encoding:'utf8',timeout:30000,maxBuffer:2e6});
  assert.equal(r.status,0,r.stderr);const receipt=JSON.parse(r.stdout);assert(receipt.ok,JSON.stringify(receipt));
  const pcm=samples(params.output);results.push(pcm);report.cases.push({kind,index:i,request,receipt,differenceFromFirst:diff(pcm,results[0])});
 }
}
writeFileSync(out+'/report.json',JSON.stringify(report,null,2)+'\n'); console.log(JSON.stringify(report.cases.map(({kind,index,differenceFromFirst})=>({kind,index,...differenceFromFirst})),null,2));
