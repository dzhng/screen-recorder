# Job inspection work audit

Current scope: real public catalog15 matched one-clip/10,000-clip prepared-audio jobs, both canceled before the measurement. Fresh large project setup took 2.368s. No full DSP rerun; original scale homes untouched. Their catalog14 refusal is retained separately rather than migrated or bypassed.

## Measured red

| Recipe characters | MCP median ms (10) | CLI median ms (3) | Decoded public response bytes |
| --- | --- | --- | --- |
| 3,736 | 0.804 | 88.999 | 476 |
| 15,944,124 | 29.964 | 122.214 | 476 |

These recipes contain ASCII, so character counts equal UTF-8 byte lengths here. CLI includes process startup; MCP uses one live connection. Alternating matched cases share a service; these are observations, not a newly selected performance threshold.

Separate instrumented large get has five SQL reads: job by ID returns15,944,124 recipe characters; existing job by raw identity returns the same recipe again; project existence; project revision returns4,095,341 content characters; artifact by raw identity. The two identity queries each bind15,944,124 recipe characters plus93 fixed identity characters. After SQL, service hashes the recipe again. A canceled job has no result; ready-result size remains a distinct bound.

Service RSS started104,415,232B and reached271,548,416B after mixed uninstrumented polls; process peak RSS was351,072KiB. This is process residency/peak across the series, not per-call allocation or a leak proof. Instrumented timings are retained separately and not used as the baseline medians.

Priority: bounded-query requirement is unmet for a recurring public poll; work grows with serialized execution input/project size while returning fixed-size status. There is no timeout failure in this measurement. Current framing/digest response fix bounds delivery, not query work. Original whole-recipe indexes/storage growth are related but not made harmless by a compact response.

## Proposed owner repair (pending design response)

Use existing JobQueue for compact inspection. Persist inputSha256 once at admission/publication/adoption and index compact identity; retain exact raw recipes for execution/provenance. Hash-index candidates must be compared with exact raw identity during mutation/admission, with explicit collision refusal rather than silently merging distinct recipes. Inspection reads bounded summary/result columns without input, rehashing or recipe-size binds. No cache, queue, public schema or global transport-limit addition.

ProjectStore should answer exact revision availability by indexed existence with the same project deletion semantics, rather than parse document content. The existing service target adapter uses that query. Retry execution may still read its necessary full recipe; recurring get must not.

Catalog17 reserved after capture16, subject to root coordination. Package lane needs no format bump. Do not modify retained catalog14 homes.

Acceptance: original identity/retry/generation/retained adoption/publication/deletion semantics, public get/retry/cancel response equality, restart digest integrity, actual small/10k public profile, and SQL evidence of no recipe/document loads or recipe-length binds on get. No constant whole-service memory claim; result/error payloads and general startup/recovery storage remain separate contracts.

Evidence: `/tmp/screenrec-job-inspection-setup.{json,log}`, `/tmp/screenrec-job-inspection-profile.{json,log}`, `/tmp/screenrec-job-inspection-{setup,profile,service}.mjs`. SQL instrumentation observes StatementSync.get only, read-only, without dumping raw parameters/results. The baseline disables query capture. Fresh home `/tmp/screenrec-job-inspection-current` preserves both actual jobs and recipes.
