import {DatabaseSync} from 'node:sqlite';
import {writeFileSync} from 'node:fs';
const statements=new WeakMap(),records=new Map(),prepare=DatabaseSync.prototype.prepare;
DatabaseSync.prototype.prepare=function(sql){const s=prepare.call(this,sql);statements.set(s,{db:this,sql});return s;};
const db=new DatabaseSync(':memory:'),p=Object.getPrototypeOf(db.prepare('SELECT 1')),all=p.all,get=p.get;db.close();
for(const [name,original] of [['get',get],['all',all]])p[name]=function(...args){const source=statements.get(this);if(source && /^\s*SELECT/i.test(source.sql) && /\bjobs\b/.test(source.sql) && !records.has(source.sql)){const plan=all.apply(prepare.call(source.db,'EXPLAIN QUERY PLAN '+source.sql),args);records.set(source.sql,{sql:source.sql,plan});}return original.apply(this,args);};
process.on('exit',()=>writeFileSync('/tmp/screenrec-job-query-plans-'+process.pid+'.json',JSON.stringify([...records.values()],null,2)));
