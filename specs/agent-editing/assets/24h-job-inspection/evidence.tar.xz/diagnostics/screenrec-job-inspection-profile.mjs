import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { JourneyService,poll } from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const home='/tmp/screenrec-job-inspection-current';const db=new DatabaseSync(home+'/library/catalog.sqlite',{readOnly:true});
const cases=db.prepare("SELECT jobId,artifact,state,length(input) inputCharacters FROM jobs WHERE artifact='prepared-audio' ORDER BY length(input)").all();db.close();
assert.equal(cases.length,2);assert(cases.every(j=>['ready','canceled'].includes(j.state)));
const report={passed:false,trace:[],cases,unprofiled:[],profiled:[],scope:'Fresh matched public jobs admitted and canceled before this measurement; no inference/retry during inspection. SQL instrumentation separately labeled.'};
const service=new JourneyService(home,report,undefined,new URL('file:///tmp/screenrec-job-inspection-service.mjs'));
async function snapshot(enable=false){const id=randomUUID();service.child.send({id,type:'profile.snapshot',enable});return poll(()=>service.barriers.get(id+'/profile.snapshot')??{},v=>!!v.memory,'profile snapshot');}
try{
await service.start();report.start=await snapshot();
for(let i=0;i<10;i++)for(const job of cases){const at=performance.now();const value=await service.call('job.get',{jobId:job.jobId},{transport:'mcp'});assert.equal(value.state,job.state);report.unprofiled.push({case:job.inputCharacters,transport:'mcp',ms:performance.now()-at,responseBytes:Buffer.byteLength(JSON.stringify(value))});}
for(let i=0;i<3;i++)for(const job of cases){const at=performance.now();const value=await service.call('job.get',{jobId:job.jobId});assert.equal(value.state,job.state);report.unprofiled.push({case:job.inputCharacters,transport:'cli',ms:performance.now()-at,responseBytes:Buffer.byteLength(JSON.stringify(value))});}
report.afterUnprofiled=await snapshot();
for(const job of cases){await snapshot(true);const at=performance.now();const value=await service.call('job.get',{jobId:job.jobId},{transport:'mcp'});const ms=performance.now()-at;const data=await snapshot(false);report.profiled.push({case:job.inputCharacters,ms,responseBytes:Buffer.byteLength(JSON.stringify(value)),...data});}
report.passed=true;
}finally{await service.stop();await writeFile('/tmp/screenrec-job-inspection-profile.json',JSON.stringify(report,null,2));}
console.log(JSON.stringify({cases,observations:report.unprofiled,sql:report.profiled},null,2));
