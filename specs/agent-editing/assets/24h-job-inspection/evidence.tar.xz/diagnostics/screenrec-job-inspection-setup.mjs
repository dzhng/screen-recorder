import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {JourneyService,poll} from '/Users/david/.codex/worktrees/noise-prepared-output/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const home='/tmp/screenrec-job-inspection-current', report={passed:false,home,trace:[],jobs:[]};
const service=new JourneyService(home,report);
try{
await service.start();
const admitted=await service.call('asset.import',{requestId:'source',path:'/tmp/screenrec-active-mixer-five-minute-final/source.wav'});
const imported=await poll(()=>service.call('job.get',{jobId:admitted.jobId}),v=>v.state==='ready','import');const asset=await service.call('asset.get',{assetId:imported.result.assetId});
for(const count of [1,10000]){
 const started=performance.now();const made=await service.call('project.create',{requestId:'project-'+count,canvas:{width:16,height:16,fps:{numerator:30,denominator:1},background:'#000000ff'}});let revision=made.revision;
 for(let start=0;start<count;start+=500){const operations=[];if(start===0)operations.push({operation:'track.add',label:'audio',track:{kind:'audio',order:0}});for(let i=start;i<Math.min(start+500,count);i++)operations.push({operation:'place',clip:{trackId:start===0?{label:'audio'}:revision.document.tracks[0].id,assetId:asset.id,streamId:asset.streams[0].id,source:{kind:'range',range:{startUs:0,endUs:720000}},placement:{kind:'project',range:{startUs:i*720000,endUs:(i+1)*720000}}}});if(start+500>=count)operations.push({operation:'processing.set',target:{kind:'output'},steps:[{processor:{type:'rnnoise'}}]});revision=(await service.call('edit.apply',{projectId:made.project.projectId,expectedRevisionId:revision.id,requestId:'place-'+start,operations},{transport:'mcp'})).revision;}
 const setupMs=performance.now()-started;
 const barrier=count===1?await service.arm('media.mixCompositionAudio'):null;
 const requested=await service.call('audio.prepare',{projectId:made.project.projectId,revisionId:revision.id});if(barrier)await barrier();
 const canceled=await service.call('job.cancel',{jobId:requested.jobId},{transport:'mcp'});assert.equal(canceled.state,'canceled');assert.equal(canceled.result,null);
 report.jobs.push({count,setupMs,projectId:made.project.projectId,revisionId:revision.id,jobId:requested.jobId,canceled});
}
report.passed=true;
}finally{await service.stop();await writeFile('/tmp/screenrec-job-inspection-setup.json',JSON.stringify(report,null,2));}
console.log(report.jobs.map(({count,setupMs,jobId})=>({count,setupMs,jobId})));
