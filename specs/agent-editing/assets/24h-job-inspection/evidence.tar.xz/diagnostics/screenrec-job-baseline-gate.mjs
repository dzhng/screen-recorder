import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const baseline=JSON.parse(readFileSync('/tmp/screenrec-job-inspection-profile.json'));
assert(baseline.profiled.every(p=>p.queries.every(q=>q.returnedInputCharacters===0 && q.returnedContentCharacters===0)), 'public job inspection must not hydrate recipe or revision document');
