import {DatabaseSync} from 'node:sqlite';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const reports=[];
for(const version of ['current','format17']){
 const source=new DatabaseSync('/tmp/screenrec-job-inspection-'+version+'/library/catalog.sqlite',{readOnly:true});
 const destination=new DatabaseSync(':memory:');
 for(const name of ['jobs','artifacts']){destination.exec(source.prepare('SELECT sql FROM sqlite_master WHERE name=?').get(name).sql);for(const row of source.prepare('SELECT sql FROM sqlite_master WHERE tbl_name=? AND type=\'index\' AND sql IS NOT NULL').all(name))destination.exec(row.sql);}
 const jobs=source.prepare('SELECT * FROM jobs').all();
 for(const row of jobs){const keys=Object.keys(row);destination.prepare(`INSERT INTO jobs(${keys.join(',')}) VALUES(${keys.map(()=>'?').join(',')})`).run(...keys.map(k=>row[k]));}
 for(const job of jobs.filter(j=>j.artifact==='prepared-audio')){const row={targetKind:job.targetKind,targetId:job.targetId,revisionId:job.revisionId,artifact:job.artifact,generation:1,attemptId:job.attemptId,result:'{"storageFixture":true}',input:job.input,...(version==='format17'?{inputSha256:createHash('sha256').update(job.input).digest('hex')}:{})};const keys=Object.keys(row);destination.prepare(`INSERT INTO artifacts(${keys.join(',')}) VALUES(${keys.map(()=>'?').join(',')})`).run(...keys.map(k=>row[k]));}
 reports.push({version,scope:'Same admitted recipes plus explicitly synthetic publication rows; storage experiment only, not native completion',tables:destination.prepare('SELECT name,sum(pgsize) bytes FROM dbstat GROUP BY name').all(),sourceTables:source.prepare("SELECT name,sum(pgsize) bytes FROM dbstat WHERE name LIKE '%jobs%' OR name LIKE '%artifacts%' GROUP BY name").all()});destination.close();source.close();
}
writeFileSync('/tmp/screenrec-job-storage.json',JSON.stringify(reports,null,2));
