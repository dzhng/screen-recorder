# Pointer demo delivery report

Both requested movie exports are committed in `deliveries/`:

- `pointer-demo-v1.mp4` — revision `65f64bb5-2468-4c82-9136-7e3396df188c`, 2,000,000 µs.
- `pointer-demo-v2-dimmed-split.mp4` — revision `fc3247a3-9ba3-413c-9930-d54cf24da869`, 2,000,000 µs.

The managed project uses a 256×160 canvas at 10 fps with opaque black background. It imports the supplied captured-source directory and explicitly binds the video clip to its acquisition. The source stream is 256×160 with 20 frames over 2 seconds. Both versions place the full-size footage in a 256×160 destination rectangle at (32, 16), leaving the remainder outside the canvas, and apply a 600,000 µs pointer trail.

Revision 1 is the first export. Revision 2 adds clip opacity 0.2 before the pointer processor, so the footage dims while the pointer/trail remain bright. Revision 3 splits that version at exactly 950,001 µs. The resulting clips cover [0, 950001) and [950001, 2000000), retain the same asset/acquisition binding and have copied processing settings; total duration remains 2 seconds.

I verified the split by requesting processed project frames at 1,000,000 and 1,100,000 µs from both pre-split revision 2 and post-split revision 3. The pointer and trail appear visually continuous and the paired pictures match by inspection. The project event read for 900,000–1,100,000 µs completed with ready coverage across both clip occurrences and no cut rows. The v2 frame at 900,000 µs also shows the 20% footage and bright pointer trail. V1 processed frames are included at 800,000 and 1,600,000 µs.

Inspection pictures are in `deliveries/inspection/`. Raw CLI receipts and requests remain in this scratch directory, including the export receipts, edit receipts, frame receipts, and `split-events.receipt.json`. Both movies are H.264 exports; their committed export receipts report 4,045 bytes and 4,039 bytes respectively.

Limitations: this was verified with selected rendered stills and the project event result, not by playing through the whole movie. I did not listen to audio; this source contains no audio intervals. A still cannot establish every in-between frame, though the project duration, clip coverage, and frame samples support continuity at and just after the split.
