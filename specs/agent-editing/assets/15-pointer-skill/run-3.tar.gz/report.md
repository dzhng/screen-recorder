# Pointer demo delivery

## Delivered

- Version 1: `exports/pointer-demo-v1.mp4` — committed export `4ae40fca-c5db-4be0-8fd9-b9e8ce51b87f`, pinned to project revision `81342a68-e948-43db-bf0e-9e68979d9ba8` (revision 1). The export receipt reports 4,045 bytes and SHA-256 `3244f53cee513d6bdd5c9158e46dc82e910bb119f93748d4dc15ea24fa220109`.
- Version 2: `exports/pointer-demo-v2.mp4` — committed export `9e410683-2ffd-415e-9193-fb0bdb25999b`, pinned to revision `14414536-5f19-42b0-a3ad-2c3272121988` (revision 2).
- Inspection pictures: `pictures/v1-500k.png`, `pictures/v1-1500k.png`, `pictures/v2-900k.png`, `pictures/v2-1000k.png`, and `pictures/v2-1500k.png`.

## Edit and evidence

The project canvas is 256×160 at 10 fps over opaque black, with a 2,000,000 µs clip. Both versions retain the captured 256×160 footage at its original dimensions and place it at x=32, y=16. The capture import completed successfully and its cursor evidence covers the full two seconds.

Version 1 uses a 600,000 µs pointer trail and preserves the first edit revision. Version 2 adds 0.2 opacity before the pointer processor, so the footage is dimmed while the subsequently composited pointer and trail stay bright. The processing capability receipt reports execution support for opacity, pointer, and geometry on clips. The processed pictures show darkened footage with the brighter cursor and trail.

Version 2 splits the clip at exactly 950,001 µs. The returned revision keeps continuous source ranges [0, 950001) and [950001, 2000000), with no removed footage. I inspected processed output frames at 900,000 and 1,000,000 µs. Their receipts report the expected first and second clip IDs respectively, source samples at those exact times, and full 256×160 frames. The visible trail carries across the boundary in the rendered pictures; it does not appear to restart.

## Recovery and limits

This task resumed after an interruption. The earlier version-1 export had already committed, and the existing public receipts showed the source import ready and revision 1 in place. An earlier edit attempt was rejected because its processing step IDs did not belong to the clip; that rejected receipt was retained. The corrected request succeeded and its revision was preserved as version 1.

A project `timeline.events` read for the whole track returned `not_ready` because source event evidence was not ready. Therefore, the no-restart check is based on the processed pictures and their clip/source provenance, not on a ready cut-event report. The pictures sample the 10 fps frames at 900 ms and 1,000 ms, so they establish rendered continuity across adjacent sampled frames rather than every instant around the exact split. I did not listen to audio; the imported capture evidence reports no audio intervals.

All requests and raw CLI receipts are retained in `requests/` and `receipts/`. The managed project was left in place.
