from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile,datetime,re,ast
root=Path('/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder');out=root/'specs/agent-editing/assets/23f-capture-source-lifetime';packet=Path('/tmp/screenrec-23f-evidence');packet.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,name=None):
 p=Path(p);q=packet/(name or p.name);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for p in Path('/tmp').glob('screenrec-23f-*.log'): copy(p,'logs/'+p.name)
for p in Path('/tmp').glob('screenrec-23f-*.patch'): copy(p,'controls/'+p.name)
for name in ['descriptor-control.mjs','descriptor-control.json','descriptor-current.mjs','descriptor-current.json','files-build-pins.json','mutations.json','mutations.py','native-cleanup-old-harness.mjs']:
 copy('/tmp/screenrec-23f-'+name,('controls/' if 'descriptor' in name or 'mutation' in name else 'runtime/')+name)
for folder in ['native-cleanup','native-cleanup-current','native-final']:
 for p in Path('/tmp/screenrec-23f-'+folder).glob('*.json'): copy(p,'receipts/'+folder+'/'+p.name)
reproducer=Path('/tmp/screenrec-23f-mutations.py').read_text().replace('report=json.loads(Path("/tmp/screenrec-23f-mutations.json").read_text())["controls"]','report=[]').replace('in controls[2:]:','in controls:')
(packet/'controls/mutations-reproduce.py').write_text(reproducer)
changed=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACM'],cwd=root,text=True).splitlines()
code=[p for p in changed if p.endswith(('.ts','.mjs','.swift'))]
extra=['packages/core/src/capture-store.ts','packages/core/src/jobs.ts','packages/core/src/files.ts','packages/core/src/assets.ts','packages/core/src/evidence.ts','packages/core/src/references.ts','packages/core/src/storage.ts','packages/core/src/library.ts','apps/service/src/managed-files.ts','apps/service/src/source-export.ts','apps/service/src/worker.ts','packages/protocol/src/operations.ts']
sources={}
for name in sorted(set(code+extra)):
 copy(root/name,'sources/'+name);sources[name]={'bytes':(root/name).stat().st_size,'sha256':sha(root/name)}
compiled={}
for name in sorted(set(code+extra)):
 if not name.endswith('.ts') or name.endswith(('.test.ts','.fixture.ts')):continue
 target=name.replace('/src/','/dist/').removesuffix('.ts')+'.js'
 if (root/target).exists(): compiled[target]={'sha256':sha(root/target),'bytes':(root/target).stat().st_size}
copy(root/'specs/agent-editing/slices/23f-capture-source-lifetime.md','scope.md')
(packet/'review.json').write_text(json.dumps({'shape':'One existing admission/lifetime owner; concrete installed artifact retirement; mutually exclusive ownership branches; no new persisted field, queue, periodic loop or asset GC.','diff':'Author review clean. Independent root source review reported clean with an ownership-shape consideration resolved by the mutually exclusive type.','docs':'Child contract names the actual native failure and authorized narrow build; source/readme pointers updated.','choices':'Queue cancellation preserves explicit retry if native completion wins; existing native removal requires the supplied directory descriptor.','cliReview':'Known unavailable configured CLI review was not repeated; root performed independent source review.'},indent=2)+'\n')
commands={'base':'d679bd33','worktree':str(root),'focused':'node node_modules/vitest/vitest.mjs run apps/service/src/capture-source-lifetime.test.ts apps/service/src/project-capture.test.ts apps/service/src/deletion.test.ts apps/service/src/capture-lifetime.test.ts packages/core/src/capture-acquisition.test.ts packages/core/src/acquisitions.test.ts packages/core/src/recording-deletion.test.ts packages/core/src/storage.test.ts --maxWorkers=1','builds':['node node_modules/typescript/bin/tsc -p packages/core/tsconfig.json','node node_modules/typescript/bin/tsc -p apps/service/tsconfig.json'],'types':['node node_modules/typescript/bin/tsc -p packages/core/tsconfig.check.json','node node_modules/typescript/bin/tsc -p apps/service/tsconfig.check.json'],'installed':'node node_modules/vitest/vitest.mjs run apps/service/src/capture.test.ts --maxWorkers=1','nativeBuild':'swift build --package-path helpers/mac --scratch-path /tmp/screenrec-23f-files-build --disable-automatic-resolution --skip-update --product screenrec-native -j 2','nativeFiles':'SCREENREC_NATIVE=/tmp/screenrec-23f-files-build/arm64-apple-macosx/debug/screenrec-native node --test helpers/mac/Tests/managed-files.test.mjs','nativeCleanup':'SCREENREC_NATIVE_PINS=/tmp/screenrec-23f-files-build-pins.json SCREENREC_LIFETIME_OUTPUT=<owned scratch output> node --test apps/service/tests/capture-source-lifetime.mjs','controls':'controls/mutations-reproduce.py restores exact source bytes in finally; core mutations rebuild and restore compiled output.'}
(packet/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(packet/'final-code.diff').write_bytes(subprocess.check_output(['git','diff','--cached','--',*code,'apps/service/src/capture-admission.ts'],cwd=root))
copy('/tmp/screenrec-23f-package-evidence.py','package-evidence.py')
old=Path('/tmp/screenrec-21d-native-build/arm64-apple-macosx/debug/screenrec-native');new=Path('/tmp/screenrec-23f-files-build/arm64-apple-macosx/debug/screenrec-native')
assert sha(old)=='8f2d759e6f3e9abefea9496f7c2eae9299726abd50f3acb4edb993be150b3094'
assert sha(new)=='bb8980df1913dc25bb3fefb4938445c140a614c24a51c0041f84c5fdf1bab92c'
refs={p:{'sha256':sha(root/p),'bytes':(root/p).stat().st_size} for p in ['specs/agent-editing/assets/20d6-settled-cleanup/prerecorded-source.tar.xz','specs/agent-editing/assets/21d-captured-source-adoption/manifest.json']}
verification={'status':'verified scoped source-lifetime checkpoint','base':'d679bd33','observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gates':{'focused':{'files':8,'tests':85,'exitCode':0},'installedCapture':{'tests':24,'exitCode':0,'finalCompiledCleanupCase':1},'nativeFiles':{'tests':9,'exitCode':0},'freshPublicNativeCleanup':{'tests':2,'exitCode':0},'scopedOmissionControls':{'expectedRed':4,'restored':True},'coreServiceBuildsTypes':'passed','formatLint':'passed'},'native':{'new':{'path':str(new),'sha256':sha(new)},'historicalUnchanged':{'path':str(old),'sha256':sha(old)},'productionSourceManifest':'runtime/files-build-pins.json','productionSourceEntries':120},'retainedFailures':['public operations unavailable before port','donor removed before acquisition/import closure','missing shared donor lease','completion kept source admission fenced','busy lease misclassified as changed source','old native descriptor ignored and replacement removed','initial installed test attempt used stale compiled service; rebuilt current TypeScript and all24 passed'],'limits':['Scripted acquisition media responses isolate coordination; no new native media-admission claim.','Actual native calls limited to scratch file/cleanup operations.','Offline native build reused existing code dependencies; historical runtimes unchanged.','No capture, playback, model work, installed switch, old-library mutation, asset GC or performance acceptance.']}
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
members={str(p.relative_to(packet)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(packet.rglob('*')) if p.is_file()}
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in members:tar.add(packet/name,arcname=name,recursive=False)
manifest={'scope':'Actual source-lifetime, native file-descriptor and verified cleanup evidence','archive':{'bytes':archive.stat().st_size,'sha256':sha(archive)},'members':members,'sources':sources,'compiled':compiled,'references':refs}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(members) and set(m.name for m in entries)==set(members)
 for m in entries:assert m.isfile() and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
print(json.dumps({'archive':manifest['archive'],'members':len(members),'sourcePins':len(sources),'compiledPins':len(compiled),'references':len(refs)}))
