from pathlib import Path
import subprocess,hashlib,json,difflib
root=Path('/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder')
node=['node','node_modules/vitest/vitest.mjs','run','apps/service/src/capture-source-lifetime.test.ts','--maxWorkers=1','-t']
controls=[
 ('omit-drain','apps/service/src/capture-sources.ts','this.jobs.drainJob(jobId)','Promise.resolve()', 'joins an acquisition', False, 'deletion-settled-before-borrower'),
 ('omit-donor-lease','packages/core/src/acquisitions.ts','for (const recordingId of this.store.recordingDonors(acquisitionId, this.recordings)) {','for (const recordingId of [] as string[]) {','inherit the shared',True,'expected undefined'),
 ('omit-ready-exception','packages/core/src/acquisitions.ts','if (this.ready(acquisitionId) || intent.kind === "package") return [];','if (intent.kind === "package") return [];','authored project history',True,'to match object { ok: true, data: { state: \'ready\' } }'),
 ('omit-discard-scope','apps/service/src/capture.ts','return await this.sourceLifetime.discard(recordingId, this.lifetime.signal, discard);','return await discard();','public discard fences',False,'"queued"'),
]
report=json.loads(Path("/tmp/screenrec-23f-mutations.json").read_text())["controls"]
for name,path,old,new,test,compile,reason in controls[2:]:
 p=root/path; original=p.read_bytes();source=original.decode(); assert source.count(old)==1,(name,'mutation must be exact')
 changed=source.replace(old,new,1)
 Path('/tmp/screenrec-23f-'+name+'.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile=path,tofile=path)))
 try:
  p.write_text(changed)
  if compile:
   build=subprocess.run(['node','node_modules/typescript/bin/tsc','-p','packages/core/tsconfig.json'],cwd=root,capture_output=True,text=True,timeout=90)
   assert build.returncode==0,build.stdout+build.stderr
  run=subprocess.run(node+[test],cwd=root,capture_output=True,text=True,timeout=30)
  output=run.stdout+run.stderr;Path('/tmp/screenrec-23f-'+name+'-red.log').write_text(output)
  result={'name':name,'path':path,'test':test,'exitCode':run.returncode,'expectedFailure':reason,'expectedFailureObserved':reason in output}
  assert run.returncode!=0 and reason in output,(result,output)
  report.append(result)
 finally:
  p.write_bytes(original)
  assert p.read_bytes()==original
  if compile:
   restored=subprocess.run(['node','node_modules/typescript/bin/tsc','-p','packages/core/tsconfig.json'],cwd=root,capture_output=True,text=True,timeout=90)
   assert restored.returncode==0,restored.stdout+restored.stderr
  Path('/tmp/screenrec-23f-mutations.json').write_text(json.dumps({'controls':report,'restored':path,'sha256':hashlib.sha256(original).hexdigest()},indent=2)+'\n')
 print(json.dumps(result),flush=True)
