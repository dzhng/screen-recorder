import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {mkdtemp,mkdir,readFile,writeFile,rename,rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {ManagedFiles} from '/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder/apps/service/dist/managed-files.js';
import {mediaWorker} from '/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder/apps/service/dist/worker.js';
const repository='/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder';
const binary='/tmp/screenrec-23f-files-build/arm64-apple-macosx/debug/screenrec-native';
const sha=createHash('sha256').update(await readFile(binary)).digest('hex');
assert.equal(sha,'bb8980df1913dc25bb3fefb4938445c140a614c24a51c0041f84c5fdf1bab92c');
const pins=JSON.parse(await readFile('/tmp/screenrec-23f-files-build-pins.json','utf8'));
for(const [path,expected] of Object.entries(pins.sources)) assert.equal(createHash('sha256').update(await readFile(join(repository,path))).digest('hex'),expected);
const root=await mkdtemp('/tmp/screenrec-23f-descriptor-');
const id=randomUUID(),selected=join(root,'recordings',id),moved=join(root,'moved');
let lease;const result={root,binary,sha,sourceMatches:'/tmp/screenrec-23f-files-build-pins.json',operations:[]};
try{
 await mkdir(selected,{recursive:true,mode:0o700});await writeFile(join(selected,'original'),'original donor');
 const native=mediaWorker({SCREENREC_NATIVE:binary});
 const files=new ManagedFiles(root,async(op,params,opts)=>{assert(['storage.recordingDirectory','storage.removeRecordingDirectory'].includes(op));result.operations.push(op);return native(op,params,opts);});
 lease=await files.recordingDirectory(id,new AbortController().signal);
 await rename(selected,moved);await mkdir(selected,{mode:0o700});await writeFile(join(selected,'replacement'),'replacement must survive stale descriptor');
 try{await files.removeRecordingDirectory(id,new AbortController().signal,lease.handle);result.removal='accepted';}
 catch(error){result.removal={code:error.code,message:error.message};}
 result.original=await readFile(join(moved,'original'),'utf8');
 result.replacement=await readFile(join(selected,'replacement'),'utf8').catch(error=>({error:error.code}));
 await writeFile('/tmp/screenrec-23f-descriptor-current.json',JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
 assert.equal(result.removal.code,'INVALID_STORAGE');
 assert.equal(result.original,'original donor');
 assert.equal(result.replacement,'replacement must survive stale descriptor');
}finally{await lease?.handle.close();await rm(root,{recursive:true,force:true});}
