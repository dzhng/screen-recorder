import { readFile, writeFile } from 'node:fs/promises';
const directory=process.argv[2];
const report=JSON.parse(await readFile(directory+'/report.json'));
const result=[];
for(const [at,screen,camera] of report.checks.exactBaseline.landmarks){
 const frame=await readFile(`${directory}/baseline-${at}.rgba`);
 for(const [side,role,source] of [[0,'screen',screen],[1,'camera',camera]]){
  if(source===null)continue;
  const ref=await readFile(`${directory}/source-${role}-${source}.rgba`);
  const channels=[0,0,0,0], signs={negative:0,positive:0},grid=Array.from({length:4},()=>[0,0,0,0]); let max=0, alpha=0;
  for(let y=0;y<120;y++)for(let x=0;x<160;x++)for(let c=0;c<4;c++){
   const difference=frame[(y*320+x+side*160)*4+c]-ref[(y*160+x)*4+c];
   max=Math.max(max,Math.abs(difference));
   if(difference){channels[c]++; signs[difference<0?'negative':'positive']++;grid[Math.floor(y/30)][Math.floor(x/40)]++;if(c===3)alpha++;}
  }
  result.push({at,role,source,maximumAbsoluteChannelError:max,changedChannels:channels,signs,changedChannelsBy4x4Grid:grid,alphaChanges:alpha});
 }
}
const output={scope:'Offline per-channel spatial inspection of retained source/composition rasters, no new rendering',profiles:[...new Set(report.pictures.map(p=>p.profile.sourceProfileSHA256))],allOpaque:report.pictures.every(p=>p.profile.opaque),comparisons:result};
await writeFile(directory+'/raster-diagnostic.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
