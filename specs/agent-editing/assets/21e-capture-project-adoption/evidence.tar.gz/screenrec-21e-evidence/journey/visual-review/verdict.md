# Visual inspection

The target is the caller's two adjacent 160×120 planes, with screen, camera and
microphone placed on their preserved common clock. Named source pictures must
remain visible only inside the authored support. This is a numeric fixture,
not a presenter layout or physical synchronization judgment.

All 28 public PNGs appear in the full sheet; the crop sheet preserves their order
and enlarges the central stripe/plane boundary four times. The unprimed reviewer
received only those images, their paths and neutral defect categories.

The reviewer identified black right halves before camera onset and completely
black late video frames; the retained landmark oracle confirms these are the
requested unsupported intervals while microphone audio continues. The central
stripe phase changes during simultaneous video are the two different source
pictures required by their common-clock offsets, with no gap or overlap.

The replacement halves look enlarged and blurry, with cyan/purple edge fringes.
The replacement source is the preserved 32×16 camera fixture; caller-authored
stretch fills 160×120. This proves replacement identity, placement, isolation and
undo, not quality under enlargement. The unchanged half and full audio remain
byte exact. Relocated replacements equal the original replacement rasters.

The reviewer also identified stair-stepping and faint colored fringes in the
source shots themselves, visible in the crops. Direct inspection agrees: the
numeric H.264 fixture contains these features before composition. No new clipping,
overlap or missing imagery was found outside the deliberate support gaps.

Source-versus-composition contexts differ by at most one 8-bit RGB code on this
fixture. Every PNG has the same embedded sRGB profile and opaque alpha. Spatial
inspection shows 745–817 changed RGB channel values per 76,800-byte plane, spread
through all grid cells, with both positive and negative differences and zero
alpha differences. This supports the bounded fixture rounding allowance; it is
not a general codec or color-conversion tolerance. Wrong-source-picture and
premature-camera-onset controls fail through that same comparator. Same-path
replacement/undo/relocation raster equality and all PCM checks remain exact.

Verdict: accept the isolated fixture's support, timing and independent-edit
behavior. Physical synchronization, audible quality, representative capture
quality and arbitrary source/color handling remain unverified.
