import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile,statfs} from 'node:fs/promises';
import {join} from 'node:path';
import {JourneyService,poll} from '/Users/david/dev/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/Users/david/.cache/screen-recorder/verification/voice-runtime-3f20d26c';
await mkdir(out,{recursive:true,mode:0o700});
const home=join(out,'home');
process.env.SCREENREC_NATIVE='/Users/david/dev/screen-recorder/helpers/mac/.build/debug/screenrec-native';
const report={passed:false,home,trace:[],attempts:[],scope:'Recovery readiness only; no editorial synthesis or repeated voice acceptance'};
const service=new JourneyService(home,report);
const call=async(operation,params,options={})=>{const result=await service.call(operation,params,options);report.attempts.push({operation,params,options,result});return result;};
try{
 report.capacityBefore=await statfs(out);
 await service.start();
 const modelId='qwen3-tts-icl-v1';
 const listed=await call('model.list',{});assert.deepEqual(await call('model.list',{}, {transport:'mcp'}),listed);
 const item=listed.find(x=>x.modelId===modelId);assert(item);report.identity=item;
 assert.equal(item.runtimeDigest,'3f20d26c32dfdc7d83f13e4e68cf3dab38ca5e6231f6bf9c2c20584b75805001');
 assert.equal(item.modelDigest,'552386a41acdd3e29266a9a6fac90b4a26021c1d2888cdaa5cf16e796024c1b9');
 assert.equal(item.descriptorDigest,'a5795fea222f39b7a8f69185868e9a2af52e40ce0998066614042d1702681377');
 assert.deepEqual(await call('model.status',{modelId}),{state:'absent'});
 const params={modelId,runtimeSource:'/Users/david/.cache/screen-recorder/prepared-sources/voice-runtime-3f20d26c32dfdc7d83f13e4e68cf3dab38ca5e6231f6bf9c2c20584b75805001',modelSource:'/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519'};
 const start=performance.now();
 assert.equal((await call('model.prepare',params)).state,'preparing');
 assert.equal((await call('model.prepare',params,{transport:'mcp'})).state,'preparing');
 await poll(()=>call('model.status',{modelId},{transport:'mcp'}),v=>v.state==='ready','recovered public preparation');
 report.preparationMs=performance.now()-start;
 assert.deepEqual(await call('model.prepare',{modelId}),{state:'ready'});
 await service.stop();await service.start();
 assert.deepEqual(await call('model.status',{modelId}),{state:'ready'});
 assert.deepEqual(await call('model.list',{}),listed);
 report.preparedReceipt=JSON.parse(await readFile(join(home,'library/models',modelId,'1eccf1cb2519b5a4e8a95b5f0544f3303568164f/receipt.json'),'utf8'));
 report.passed=true;
}catch(error){report.error={message:error.message,stack:error.stack};throw error;}
finally{await service.stop();report.capacityAfter=await statfs(out);await writeFile(join(out,'report.json'),JSON.stringify(report,null,2));await writeFile(join(out,'service.log'),service.logs.join(''));}
console.log(JSON.stringify({passed:report.passed,home,preparationMs:report.preparationMs}));
