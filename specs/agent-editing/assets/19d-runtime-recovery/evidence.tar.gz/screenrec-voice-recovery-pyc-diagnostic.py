import json,pathlib,hashlib,importlib._bootstrap_external as be
p=json.load(open('/tmp/screenrec-voice-recovery-plan.json'));path='python/lib/python3.12/site-packages/scipy/signal/__pycache__/_short_time_fft.cpython-312.pyc';r=p['recipes'][path];e=next(x for x in p['entries'] if x['path']==path);data=pathlib.Path(r['source']).read_bytes()
for i in range(5):
 filename=('/'+r['filename'].lstrip('/'))
 code=compile(data,filename,'exec',dont_inherit=True,optimize=0)
 pyc=be._code_to_timestamp_pyc(code,r['mtime'],len(data));print(i,len(pyc),hashlib.sha256(pyc).hexdigest(),e['sha256'])
