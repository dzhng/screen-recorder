"""Read-only proof of every registered runtime byte; no imports from the recovered runtime."""
import sys,json,pathlib,hashlib,base64,importlib._bootstrap_external as be,collections
plan=json.loads(pathlib.Path(sys.argv[1]).read_text());counts=collections.Counter();total=0
assert hashlib.sha256(pathlib.Path(plan['interpreter']).read_bytes()).hexdigest()==plan['interpreterSha256']
for entry in plan['entries']:
 if entry['kind']!='file':continue
 r=plan['recipes'][entry['path']];counts[r['kind']]+=1
 if r['kind']=='literal':data=base64.b64decode(r['base64'])
 else:
  data=pathlib.Path(r['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==r['sourceSha256'],r['source']
  if r['kind']=='pyc':data=bytes(be._code_to_timestamp_pyc(compile(data,r['filename'],'exec',dont_inherit=True,optimize=0),r['mtime'],len(data)))
  elif r['kind']=='replace':
   text=data.decode();assert text.count(r['old'])==1;data=text.replace(r['old'],r['new']).encode()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
 total+=len(data)
print(json.dumps({'passed':True,'runtimeDigest':plan['runtimeDigest'],'regularFiles':sum(counts.values()),'bytes':total,'recipes':dict(counts),'runtimeWritten':False,'inference':False}))
