import pathlib,json,hashlib,stat,collections
root=pathlib.Path('/Users/david/dev/screen-recorder'); model=pathlib.Path('/Users/david/.cache/screen-recorder/prepared-sources/qwen3-tts-1eccf1cb2519'); base=pathlib.Path('/Users/david/.local/share/uv/python/cpython-3.12.14-macos-aarch64-none'); cache=pathlib.Path('/Users/david/.cache/uv/archive-v0'); spec=json.load(open('/tmp/screenrec-voice-recovery-registry.json'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def match(p,e):
 try:return p.is_file() and p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
 except OSError:return False
models=[dict(path=e['path'],bytes=e['bytes'],expected=e['sha256'],actual=sha(model/e['path'])) for e in spec['files']]
# Index cache package roots without searching unrelated home contents.
roots=collections.defaultdict(list)
for d in cache.iterdir():
 if d.is_dir():
  for p in d.iterdir():roots[p.name].append(d)
found=[];missing=[]
for e in spec['runtimeArtifact']['entries']:
 if e['kind']!='file':continue
 p=e['path']; candidates=[]
 if p.startswith('python/lib/python3.12/site-packages/'):
  rel=p[len('python/lib/python3.12/site-packages/'):]
  candidates=[d/rel for d in roots[rel.split('/')[0]]]
 elif p.startswith('python/'):candidates=[base/p[len('python/'):]]
 elif p=='voice/profile.json':candidates=[root/'packages/core/src/model-data/voice-profile-v1.json']
 elif p.startswith('voice/'):candidates=[root/'helpers'/p]
 hit=next((q for q in candidates if match(q,e)),None)
 if hit:found.append({'path':p,'source':str(hit),'bytes':e['bytes'],'sha256':e['sha256'],'modeMatches':stat.S_IMODE(hit.stat().st_mode)==e['mode']})
 else:missing.append(e)
report={'modelSource':str(model),'modelFiles':models,'modelExact':all(m['actual']==m['expected'] for m in models),'modelBytes':sum(e['bytes'] for e in spec['files']),'runtimeDigest':spec['runtimeArtifact']['digest'],'runtimeEntries':len(spec['runtimeArtifact']['entries']),'runtimeBytes':sum(e.get('bytes',0) for e in spec['runtimeArtifact']['entries']),'exactFiles':found,'missingFiles':missing,'missingBytes':sum(e['bytes'] for e in missing)}
pathlib.Path('/tmp/screenrec-voice-recovery-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['modelFiles','exactFiles','missingFiles']}));print('exact',len(found),'missing',len(missing));print('\n'.join(e['path'] for e in missing)[:10000])
