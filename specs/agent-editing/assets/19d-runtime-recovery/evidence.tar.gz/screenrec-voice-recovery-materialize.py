"""Materialize only registered bytes from the banked exact recovery recipe."""
import sys,json,pathlib,hashlib,base64,importlib._bootstrap_external as be,collections
import os,stat,ctypes,shutil
output=pathlib.Path(sys.argv[2]);assert not output.exists();partial=output.with_name(output.name+'.partial');assert not partial.exists();partial.mkdir(mode=0o700)
assert shutil.disk_usage(partial).free>4*1024**3
clone=ctypes.CDLL(None,use_errno=True).clonefile;clone.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];clone.restype=ctypes.c_int
plan=json.loads(pathlib.Path(sys.argv[1]).read_text());counts=collections.Counter();total=0
assert hashlib.sha256(pathlib.Path(plan['interpreter']).read_bytes()).hexdigest()==plan['interpreterSha256']
for entry in plan['entries']:
 path=partial/entry['path']
 if entry['kind']=='directory':path.mkdir(mode=entry['mode'],parents=True,exist_ok=True);continue
 if entry['kind']=='symlink':path.symlink_to(entry['target']);continue
 r=plan['recipes'][entry['path']];counts[r['kind']]+=1
 if r['kind']=='literal':data=base64.b64decode(r['base64'])
 else:
  data=pathlib.Path(r['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==r['sourceSha256'],r['source']
  if r['kind']=='pyc':
   sourceData=data;filename=r['filename']
   for attempt in range(2):
    code=compile(sourceData,filename,'exec',dont_inherit=True,optimize=0)
    data=bytes(be._code_to_timestamp_pyc(code,r['mtime'],len(sourceData)))
    if hashlib.sha256(data).hexdigest()==entry['sha256']:break
  elif r['kind']=='replace':
   text=data.decode();assert text.count(r['old'])==1;data=text.replace(r['old'],r['new']).encode()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
 path.parent.mkdir(parents=True,exist_ok=True)
 if r['kind']=='existing':
  if clone(os.fsencode(r['source']),os.fsencode(path),0):raise OSError(ctypes.get_errno(),'clone failed; no full-copy fallback')
  assert path.stat().st_ino!=pathlib.Path(r['source']).stat().st_ino
 else:
  with path.open('xb') as f:f.write(data)
 path.chmod(entry['mode']);total+=len(data)
for entry in plan['entries']:
 path=partial/entry['path'];assert stat.S_IMODE(path.lstat().st_mode)==entry['mode'],entry['path']
 if entry['kind']=='file':assert path.stat().st_size==entry['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
 elif entry['kind']=='symlink':assert os.readlink(path)==entry['target'] and path.resolve().is_relative_to(partial) and path.resolve().exists()
assert len(list(partial.rglob('*')))==len(plan['entries'])
partial.rename(output)
print(json.dumps({'passed':True,'runtimeDigest':plan['runtimeDigest'],'regularFiles':sum(counts.values()),'bytes':total,'recipes':dict(counts),'runtimeWritten':True,'path':str(output),'modesAndLinksVerified':True,'inference':False}))
