import pathlib,json,hashlib,importlib._bootstrap_external as be,collections,stat
r=json.load(open('/tmp/screenrec-voice-recovery-audit.json')); cache=pathlib.Path('/Users/david/.cache/uv/archive-v0'); prefix='python/lib/python3.12/site-packages/'; roots=[p for p in cache.iterdir() if p.is_dir()];roots += [p/'lib/python3.12/site-packages' for p in roots if (p/'lib/python3.12/site-packages').is_dir()];known={e['path']:e for e in r['exactFiles']};out=[];remaining=[]
for e in r['missingFiles']:
 rel=e['path'].removeprefix(prefix);found=None
 for root in roots:
  p=root/rel
  if p.is_file() and p.stat().st_size==e['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']:found={'path':e['path'],'source':str(p),'method':'existing-bytes'};break
 if found:out.append(found);continue
 if not rel.endswith('.pyc'):remaining.append(e);continue
 sourceRel=str(pathlib.Path(rel).parent.parent/(pathlib.Path(rel).name.split('.cpython-')[0]+'.py'))
 source=known.get(prefix+sourceRel)
 if not source:remaining.append(e);continue
 p=pathlib.Path(source['source']);data=p.read_bytes()
 for base in ['/private/tmp/screenrec-voice-venv','/tmp/screenrec-voice-venv']:
  filename=base+'/lib/python3.12/site-packages/'+sourceRel
  code=compile(data,filename,'exec',dont_inherit=True,optimize=0)
  pyc=be._code_to_timestamp_pyc(code,int(p.stat().st_mtime),len(data))
  if hashlib.sha256(pyc).hexdigest()==e['sha256']:
   found={'path':e['path'],'source':str(p),'method':'compile-in-memory','filename':filename,'mtime':int(p.stat().st_mtime)};break
 if found:out.append(found)
 else:remaining.append(e)
print('additional exact',len(out),'remaining',len(remaining),collections.Counter('pyc' if e['path'].endswith('.pyc') else 'metadata' if '.dist-info/' in e['path'] else 'other' for e in remaining));print(out[:8]);pathlib.Path('/tmp/screenrec-voice-recovery-pyc.json').write_text(json.dumps({'recovered':out,'remaining':remaining},indent=2))
