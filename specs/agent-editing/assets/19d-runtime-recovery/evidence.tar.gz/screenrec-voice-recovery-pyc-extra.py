exec(open('/tmp/screenrec-voice-recovery-pyc.py').read().split('found=[]')[0]) if False else None
import pathlib,json,hashlib,importlib._bootstrap_external as be,collections
r=json.load(open('/tmp/screenrec-voice-recovery-pyc.json')); initial=json.load(open('/tmp/screenrec-voice-recovery-audit.json')); prefix='python/lib/python3.12/site-packages/'; cache=pathlib.Path('/Users/david/.cache/uv/archive-v0'); roots=[p for p in cache.iterdir() if p.is_dir()];roots += [p/'lib/python3.12/site-packages' for p in roots if (p/'lib/python3.12/site-packages').is_dir()];known={e['path']:e for e in initial['exactFiles']};found=[];miss=[]
for e in r['remaining']:
 if not e['path'].endswith('.pyc'):continue
 rel=e['path'].removeprefix(prefix);src=str(pathlib.Path(rel).parent.parent/(pathlib.Path(rel).name.split('.cpython-')[0]+'.py')); options=[p/src for p in roots if (p/src).is_file()]
 hit=None
 for p in options:
  data=p.read_bytes()
  for base in ['/tmp/screenrec-voice-venv','/private/tmp/screenrec-voice-venv','/tmp/screenrec-19d-repaired-bundle/python','/private/tmp/screenrec-19d-repaired-bundle/python']:
   fn=base+'/lib/python3.12/site-packages/'+src
   try:code=compile(data,fn,'exec',dont_inherit=True,optimize=0)
   except (SyntaxError,ValueError):continue
   pyc=be._code_to_timestamp_pyc(code,int(p.stat().st_mtime),len(data))
   if hashlib.sha256(pyc).hexdigest()==e['sha256']:hit={'path':e['path'],'source':str(p),'filename':fn,'mtime':int(p.stat().st_mtime)};break
  if hit:break
 if hit:found.append(hit)
 else:miss.append(e)
print('additional',len(found),'unresolvedpyc',len(miss));print(collections.Counter(x['path'].split('site-packages/')[1].split('/')[0] for x in miss));pathlib.Path('/tmp/screenrec-voice-recovery-pyc-extra.json').write_text(json.dumps({'recovered':found,'remaining':miss},indent=2))
