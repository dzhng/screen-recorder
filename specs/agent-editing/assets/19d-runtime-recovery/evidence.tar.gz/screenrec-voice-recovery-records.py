import pathlib,json,csv,io,base64,hashlib,configparser
r=json.load(open('/tmp/screenrec-voice-recovery-metadata.json'));cache=pathlib.Path('/Users/david/.cache/uv/archive-v0');out=[];miss=[]
def row(path,data):return [path,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('='),str(len(data))]
for e in r['remaining']:
 if not e['path'].endswith('/RECORD'):continue
 rel=e['path'].split('site-packages/')[1];dn=rel.split('/')[0];hit=None
 for p in cache.glob('*/'+rel):
  config=configparser.ConfigParser();config.read(p.parent/'entry_points.txt');points=dict(config['console_scripts']) if 'console_scripts' in config else {}
  for interpreter in ['python','python3','python3.12']:
   for base in ['/tmp/screenrec-voice-venv','/private/tmp/screenrec-voice-venv']:
    rows=list(csv.reader(io.StringIO(p.read_text())))+[row(dn+'/INSTALLER',b'uv'),row(dn+'/REQUESTED',b'')]
    if dn=='mlx_audio-0.5.6.dist-info':
     rows += [row(x['path'].split('site-packages/')[1], x['text'].encode()) for x in json.load(open('/tmp/screenrec-voice-recovery-local-metadata.json'))]
     rows.append(row(dn+'/uv_build.json',b'{}'))
    for name,target in points.items():
     mod,fn=target.split(':');fn=fn.split('[')[0].strip();script=f'''#!{base}/bin/{interpreter}
# -*- coding: utf-8 -*-
import sys
from {mod} import {fn.split('.')[0]}
if __name__ == "__main__":
    if sys.argv[0].endswith("-script.pyw"):
        sys.argv[0] = sys.argv[0][:-11]
    elif sys.argv[0].endswith(".exe"):
        sys.argv[0] = sys.argv[0][:-4]
    sys.exit({fn}())
'''.encode();rows.append(row('../../../bin/'+name,script))
    rows.sort(key=lambda a:a[0]);b=io.StringIO(newline='');csv.writer(b,lineterminator='\n').writerows(rows);data=b.getvalue().encode()
    if hashlib.sha256(data).hexdigest()==e['sha256']:hit={'path':e['path'],'source':str(p),'interpreter':base+'/bin/'+interpreter,'base64':base64.b64encode(data).decode()};break
   if hit:break
  if hit:break
 if hit:out.append(hit)
 else:miss.append(e)
print('exact record',len(out),'remaining',len(miss));print('\n'.join(e['path'] for e in miss));pathlib.Path('/tmp/screenrec-voice-recovery-records.json').write_text(json.dumps({'recovered':out,'remaining':miss},indent=2))
