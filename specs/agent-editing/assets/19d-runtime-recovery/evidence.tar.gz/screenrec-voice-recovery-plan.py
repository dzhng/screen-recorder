import pathlib,json,hashlib,base64
root=pathlib.Path('/Users/david/dev/screen-recorder'); prefix='python/lib/python3.12/site-packages/'; initial=json.load(open('/tmp/screenrec-voice-recovery-audit.json')); registry=json.load(open('/tmp/screenrec-voice-recovery-registry.json')); recipe={}
def source(path):return {'source':path,'sourceSha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()}
for e in initial['exactFiles']:recipe[e['path']]={'kind':'existing',**source(e['source'])}
for label in ['pyc','pyc-extra']:
 for e in json.load(open('/tmp/screenrec-voice-recovery-'+label+'.json'))['recovered']:
  recipe[e['path']]={'kind':'pyc' if 'filename' in e else 'existing',**source(e['source']),**{k:e[k] for k in ['filename','mtime'] if k in e}}
e=json.load(open('/tmp/screenrec-voice-recovery-header.json'));recipe[e['path']]={'kind':'pyc',**source(e['source']),'filename':e['filename'],'mtime':e['mtime']}
for label in ['metadata','records']:
 for e in json.load(open('/tmp/screenrec-voice-recovery-'+label+'.json'))['recovered']:recipe[e['path']]={'kind':'literal','base64':e['base64']}
for e in json.load(open('/tmp/screenrec-voice-recovery-local-metadata.json')):recipe[e['path']]={'kind':'literal','base64':base64.b64encode(e['text'].encode()).decode()}
p=pathlib.Path('/Users/david/.cache/uv/archive-v0/ouRiShQt6WMqt5-R/mlx_audio/tts/models/qwen3_tts/qwen3_tts.py');lines=(root/'helpers/voice/probability-filter.patch').read_text().splitlines();old='\n'.join(x[1:] for x in lines if x.startswith('-') and not x.startswith('---'))+'\n';new='\n'.join(x[1:] for x in lines if x.startswith('+') and not x.startswith('+++'))+'\n';recipe[prefix+'mlx_audio/tts/models/qwen3_tts/qwen3_tts.py']={'kind':'replace',**source(str(p)),'old':old,'new':new,'patchSha256':hashlib.sha256((root/'helpers/voice/probability-filter.patch').read_bytes()).hexdigest()}
expected={e['path']:e for e in registry['runtimeArtifact']['entries'] if e['kind']=='file'};assert set(recipe)==set(expected),(len(recipe),len(expected));plan={'runtimeDigest':registry['runtimeArtifact']['digest'],'interpreter':'/Users/david/.local/share/uv/python/cpython-3.12.14-macos-aarch64-none/bin/python3.12','interpreterSha256':next(e['sha256'] for e in registry['runtimeArtifact']['entries'] if e['path']=='python/bin/python3.12'),'entries':registry['runtimeArtifact']['entries'],'recipes':recipe};pathlib.Path('/tmp/screenrec-voice-recovery-plan.json').write_text(json.dumps(plan,separators=(',',':'))+'\n');print('recipes',len(recipe))
