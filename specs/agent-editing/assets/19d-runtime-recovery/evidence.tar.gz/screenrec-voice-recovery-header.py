import pathlib,json,hashlib,importlib._bootstrap_external as be,struct,datetime,time
r=json.load(open('/tmp/screenrec-voice-recovery-pyc-extra.json'));e=r['remaining'][0]; source=pathlib.Path('/Users/david/.cache/uv/archive-v0/_QejW7JNv_etm3Xk/lib/python3.12/site-packages/_virtualenv.py');data=source.read_bytes();start=int(datetime.datetime(2026,9,27,tzinfo=datetime.timezone.utc).timestamp());end=start+86400*3
for base in ['/tmp/screenrec-voice-venv','/private/tmp/screenrec-voice-venv']:
 fn=base+'/lib/python3.12/site-packages/_virtualenv.py';code=compile(data,fn,'exec',dont_inherit=True,optimize=0);pyc=bytes(be._code_to_timestamp_pyc(code,0,len(data)));print('candidate length',len(pyc),'expected',e['bytes'],flush=True)
 if len(pyc)!=e['bytes']:continue
 h=hashlib.sha256(pyc[:8]);tail=pyc[12:]
 for stamp in range(start,end):
  trial=h.copy();trial.update(struct.pack('<I',stamp));trial.update(tail)
  if trial.hexdigest()==e['sha256']:
   result={'path':e['path'],'source':str(source),'filename':fn,'mtime':stamp,'timestampSearchUTC':['2026-09-27','2026-09-30'],'sha256':e['sha256']};pathlib.Path('/tmp/screenrec-voice-recovery-header.json').write_text(json.dumps(result,indent=2));print(result);raise SystemExit
print('No exact header found')
