import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';
import assert from 'node:assert/strict';
const out='/tmp/screenrec-23i-boot/public-final';
const env={...process.env,SCREENREC_HOME:out+'/home',SCREENREC_NATIVE:out+'/startup-worker.mjs',SCREENREC_BOOT_WORKER_LOG:'/tmp/screenrec-23i-boot/discovery-red-requests.jsonl',SCREENREC_APP:'/tmp/screenrec-23i-boot/never-launch.app'};
const child=spawn(process.execPath,[out+'/service.mjs'],{env,stdio:['pipe','pipe','pipe']});
const exited=once(child,'close');
try { await once(child.stdout,'data'); const run=(()=>{try{return execFileSync(process.execPath,[out+'/cli.mjs','service.health'],{env,encoding:'utf8'});}catch(e){return e.stdout;}})();console.log(run);assert.equal(JSON.parse(run).ok,true,'Shared client discovery must reach the fresh service without a socket override');}
finally{child.stdin.end();await exited;}
