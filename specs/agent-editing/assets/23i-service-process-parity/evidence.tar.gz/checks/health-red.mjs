import { startProjectService } from '/Users/david/.codex/worktrees/release-consumer-parity/screen-recorder/apps/service/dist/project-service.js';
import { callLocal } from '/Users/david/.codex/worktrees/release-consumer-parity/screen-recorder/packages/client/dist/index.js';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
const home=await mkdtemp(join(tmpdir(),'sr-23i-red-'));
const service=await startProjectService({home,worker:async(operation)=>({ok:true,data:operation==='media.audioCapabilities'?{}:{removed:true}})});
try {const reply=await callLocal(service.socketPath,{id:'health',operation:'service.health',params:{}});console.log(JSON.stringify(reply));assert.equal(reply.ok,true,'A service discoverable by ordinary clients answers service.health');}
finally {await service.close();await rm(home,{recursive:true,force:true});}
