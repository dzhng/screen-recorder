from pathlib import Path
import json,hashlib,tarfile,sqlite3,urllib.parse,datetime
root=Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder');base=Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2');packet=root/'specs/agent-editing/assets/24z-current-preparation'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
fixture=json.loads((base/'current/fixture.json').read_text());verified=json.loads((base/'current/verify-report.json').read_text());prepared=json.loads((base/'current/prepare-report.json').read_text());assert verified['passed']and prepared['passed'];assert not(base/'current/measure-report.json').exists();assert all('totalMs'not in c and all('latencyMs'not in page for page in c['pages'])for c in verified['collections'])
runtime=json.loads((base/'runtime-authority.json').read_text());modules=json.loads((base/'executed-module-authority.json').read_text());current=root/'packages/test-harness/editing/source-cardinality.mjs';(base/'maintained-harness.mjs').write_bytes(current.read_bytes());currentAuthority=next(r for r in runtime['scenarioConsumers']if r['path']=='packages/test-harness/editing/source-cardinality.mjs');assert pin(current)['sha256']==currentAuthority['sha256']
files={}
def add(name,path):
 assert name not in files;files[name]=path
for name in ['original-harness.mjs','original-fixture.mjs','preparation-producer.mjs','correctness-producer.mjs','maintained-harness.mjs','prepare-runtime.py','pin-runtime.py','run-phase.py','observed-run-phase.py','check-observer.py','check-preservation.py','bank-packet.py','initial-setup-command.json','initial-static-resource-check.py','initial-static-resource-check.json','build-commands.json','runtime-authority.json','executed-module-authority.json','preservation-before.json','preservation-after.json','prepare-command.json','verify-command.json','wrong-clock-command.json','final-checks.json','observer-control-commands.json']:
 add('authority/'+name,base/name)
for folder in ['initial-setup','current','observer-control']:
 for p in sorted((base/folder).rglob('*')):
  if p.is_file():add(str(p.relative_to(base)),p)
for r in runtime['sourceAndEmittedFiles']:
 p=root/r['path']
 if '/dist/'in r['path']and p.suffix in ['.js','.json']:add('runtime/owned/'+r['path'],p)
for r in runtime['scenarioConsumers']:
 p=root/r['path'];add('runtime/consumers/'+p.name,p)
for r in runtime['sdk']['esmFiles']:
 p=Path(r['path']);relative=str(p.relative_to(Path(runtime['sdk']['package'])/'dist/esm'));add('runtime/sdk-esm/'+relative,p)
external={}
for phase in modules:
 for r in phase['modules']:
  p=Path(r['path']);assert '/Users/david/dev/screen-recorder/apps/'not in str(p)and'/Users/david/dev/screen-recorder/packages/'not in str(p)
  if '/node_modules/'in str(p)and str(p)not in {x['path']for x in runtime['sdk']['esmFiles']}:
   external[str(p)]=r
for pth,r in sorted(external.items()):
 p=Path(pth);name=pth.split('/node_modules/.bun/',1)[-1]if'/node_modules/.bun/'in pth else pth.split('/node_modules/',1)[-1];add('runtime/external/'+name,p)
add('input/authored-source.mov',root/'specs/agent-editing/assets/10d-public-scenes/authored-source.mov')
with tarfile.open(packet/'evidence.tar.gz','w:gz')as tar:
 for name,path in files.items():tar.add(path,arcname=name,recursive=False)
producers={phase:{'file':name,**pin(base/name)}for phase,name in [('prepare','preparation-producer.mjs'),('correctness','correctness-producer.mjs'),('prospectiveMeasure','maintained-harness.mjs')]}
parents=['24z-source-cardinality','24z-owner-profile','24z11-operation-result-delivery','24z12-mcp-media-admission','23n-parakeet-model-readiness'];refs=[]
for name in parents:
 directory=root/'specs/agent-editing/assets'/name
 archive=directory/('changed-closure.tar.gz'if name=='24z11-operation-result-delivery'else'evidence.tar.gz');refs.append({'path':str(archive.relative_to(root)),**pin(archive)})
metadata={'scope':'Current-production24z preparation and untimed correctness only; measure authorization/p95 remain open','sourceBase':'edc309d2','prepared':True,'correctness':True,'timingCollections':0,'hostPreflightAttempts':0,'namespace':fixture['home'],'catalogFormat':22,'controls':verified['controls'],'acquisitions':len(fixture['acquisitions']),'deduplicatedAssets':1,'arms':[{'cardinality':a['cardinality'],'projectId':a['projectId'],'revisionId':a['revisionId'],'clips':len(a['clipIds']),'ordinal':a['revision']['ordinal']}for a in fixture['arms']],'collections':[{'cardinality':c['cardinality'],'transport':c['transport'],'pageCount':c['pageCount'],'pageRows':[p['rows']for p in c['pages']],'rowsSha256':c['rowsSha256'],'nativeCallBoundary':c['nativeCallBoundary']}for c in verified['collections']],'defaultClient':verified['defaultClient'],'pinnedQueryRefusal':verified['pinnedRefusal'],'journalSha256':fixture['journalSha256'],'normalizedSha256':fixture['normalizedSha256'],'worker':prepared['runtime']['nativeSha256'],'producerIdentities':producers,'terminalCommands':{phase:{'pid':json.loads((base/(phase+'-command.json')).read_text())['pid'],'exit':json.loads((base/(phase+'-command.json')).read_text())['exit']}for phase in ['prepare','wrong-clock','verify']},'lifecycleLimit':'Accepted producer exits recorded; JourneyService source zero-exit assertion passed. No independent same-PID MCP Node/OS events persisted in these accepted phases. V8 emitted-module inventories identify VM/process modules, not OS exit codes. Prospective measure-only observer has a separate synthetic Node/default-SDK proof and must establish actual measurement finality.','instrumentation':'V8 coverage in untimed phases only. No SQL/profiler instrumentation or model preparation/inference. Future timing must omit NODE_V8_COVERAGE and use its own actual maintained producer authority.','runtimeAuthority':'authority/runtime-authority.json','executedModuleAuthority':'authority/executed-module-authority.json','preservation':'authority/preservation-after.json','originalReferences':refs,'archive':pin(packet/'evidence.tar.gz'),'members':[{'path':name,**pin(path)}for name,path in files.items()]}
(packet/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(packet/'evidence.tar.gz')as tar:
 assert len(tar.getmembers())==len(files)
 for r in metadata['members']:
  b=tar.extractfile(r['path']).read();assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
print(json.dumps({'members':len(files),'archive':metadata['archive'],'producers':producers,'namespace':fixture['home']}))
