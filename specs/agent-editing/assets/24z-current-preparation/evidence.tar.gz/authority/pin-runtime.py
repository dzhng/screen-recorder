import pathlib,json,hashlib,os,subprocess
root=pathlib.Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder');base=pathlib.Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
scopes=['packages/composition','packages/protocol','packages/core','packages/client','apps/service','apps/cli'];files=[]
for scope in scopes:
 for folder in ['src','dist']:
  for p in sorted((root/scope/folder).rglob('*')):
   if not p.is_file()or p.suffix not in ['.ts','.js','.json']:continue
   record={'path':str(p.relative_to(root)),**pin(p)}
   if folder=='src':
    committed=subprocess.check_output(['git','show','edc309d2:'+record['path']],cwd=root);assert hashlib.sha256(committed).hexdigest()==record['sha256'];record['equalsSourceBase']=True
   files.append(record)
resources=[]
for p in sorted((root/'packages/core/src/model-data').glob('*.json')):
 q=root/'packages/core/dist/model-data'/p.name;assert json.loads(p.read_text())==json.loads(q.read_text());resources.append({'source':{'path':str(p.relative_to(root)),**pin(p)},'emitted':{'path':str(q.relative_to(root)),**pin(q)},'parsedValuesEqual':True})
consumers=[]
for n in ['source-cardinality.mjs','source-cardinality-fixture.mjs','source-evidence-fixture.mjs','evidence-service.mjs','first-preview-transport.mjs','service-cpu-profile.mjs']:
 p=root/'packages/test-harness/editing'/n;consumers.append({'path':str(p.relative_to(root)),**pin(p)})
deps=[]
sdk=(root/'packages/test-harness/node_modules/@modelcontextprotocol/sdk').resolve();sdkmeta=json.loads((sdk/'package.json').read_text());assert sdkmeta['version']=='1.30.0'
for p in sorted((sdk/'dist/esm').rglob('*.js')):deps.append({'path':str(p),**pin(p)})
node=pathlib.Path(subprocess.check_output(['which','node'],text=True).strip()).resolve()
record={'base':'edc309d2','node':{'path':str(node),'version':subprocess.check_output([str(node),'--version'],text=True).strip(),**pin(node)},'sixScopes':scopes,'sourceAndEmittedFiles':files,'resources':resources,'scenarioConsumers':consumers,'sdk':{'package':str(sdk),'version':sdkmeta['version'],'esmFiles':deps},'scope':'Current isolated emitted inputs and all installed SDK ESM bytes. Actual executed Node URLs are recorded separately from V8 coverage; production source bytes equal committed base. No timing authority inherited.'}
(base/'runtime-authority.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'files':len(files),'resources':len(resources),'sdkEsmFiles':len(deps),'consumers':len(consumers)}))
