import pathlib,os,json,hashlib,subprocess,datetime,sqlite3
root=pathlib.Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder');base=pathlib.Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}
protected=[]
for p in [pathlib.Path('/private/tmp/sr-source-cardinality-uywBEr/library/catalog.sqlite'),pathlib.Path('/private/tmp/screenrec-09c-native-presented-worker'),*[root/'specs/agent-editing/assets'/n/'evidence.tar.gz' for n in ['24z-source-cardinality','24z-owner-profile','23n-parakeet-model-readiness']]]:protected.append({'path':str(p),**digest(p)})
modelbase=pathlib.Path('/Users/david/.cache/screen-recorder/verification/parakeet-23n-db6b985b');identities=[]
for folder in ['source','home','runtime']:
 for p in sorted((modelbase/folder).rglob('*')):
  st=p.lstat();identities.append({'path':str(p),'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'bytes':st.st_size,'modifiedNs':st.st_mtime_ns,'changedNs':st.st_ctime_ns})
(base/'preservation-before.json').write_text(json.dumps({'protected':protected,'23nIdentities':identities},indent=2)+'\n')
records=[]
for scope in ['packages/composition','packages/protocol','packages/core','packages/client','apps/service','apps/cli']:
 args=['node',str(root/'node_modules/typescript/bin/tsc'),'-p',scope+'/tsconfig.json','--pretty','false'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();child=subprocess.Popen(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();r={'scope':scope,'argv':args,'pid':child.pid,'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code':child.returncode,'stdout':out.decode(),'stderr':err.decode()};records.append(r);(base/'build-commands.json').write_text(json.dumps(records,indent=2)+'\n');assert child.returncode==0,r
print('Six local package emissions passed; protected state captured')
