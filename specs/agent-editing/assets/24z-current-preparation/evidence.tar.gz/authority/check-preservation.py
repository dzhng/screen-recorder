from pathlib import Path
import json,hashlib,os,subprocess,datetime
root=Path('/Users/david/.codex/worktrees/parakeet-model-readiness/screen-recorder');base=Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2');before=json.loads((base/'preservation-before.json').read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  while b:=f.read(1048576):h.update(b)
 return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}
protected=[{'path':r['path'],**digest(Path(r['path']))}for r in before['protected']];identities=[];modelbase=Path('/Users/david/.cache/screen-recorder/verification/parakeet-23n-db6b985b')
for folder in ['source','home','runtime']:
 for p in sorted((modelbase/folder).rglob('*')):
  st=p.lstat();identities.append({'path':str(p),'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'bytes':st.st_size,'modifiedNs':st.st_mtime_ns,'changedNs':st.st_ctime_ns})
assert before['protected']==protected;assert before['23nIdentities']==identities
(base/'preservation-after.json').write_text(json.dumps({'allProtectedBytesEqual':True,'all23nIdentitiesEqual':True,'protected':protected,'identityCount':len(identities)},indent=2)+'\n')
checks=[]
for label,args in [('syntax',['node','--check','packages/test-harness/editing/source-cardinality.mjs']),('lint',[str(root/'node_modules/.bin/oxlint'),'packages/test-harness/editing/source-cardinality.mjs']),('format',[str(root/'node_modules/.bin/oxfmt'),'--check','packages/test-harness/editing/source-cardinality.mjs']),('diff',['git','diff','--check'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();child=subprocess.Popen(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();r={'label':label,'argv':args,'pid':child.pid,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':child.returncode,'stdout':out.decode(),'stderr':err.decode()};checks.append(r);assert child.returncode==0,r
(base/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'protectedFiles':len(protected),'23nIdentities':len(identities),'checksPassed':len(checks)}))
