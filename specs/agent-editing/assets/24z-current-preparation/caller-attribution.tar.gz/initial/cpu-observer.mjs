import assert from 'node:assert/strict';
import { Session } from 'node:inspector/promises';
import net from 'node:net';
import { writeFile } from 'node:fs/promises';
import { unlinkSync } from 'node:fs';
import { join } from 'node:path';
let active;
const completed = new Set();
export async function startLocal(kind, arm, directory) {
  assert(!active && !completed.has(arm));
  const session = new Session(); session.connect();
  try {
    await session.post('Profiler.enable');
    await session.post('Profiler.setSamplingInterval', {interval:1000});
    await session.post('Profiler.start');
  } catch(error) {session.disconnect();throw error;}
  active={kind,arm,directory,session,at:performance.now(),cpu:process.cpuUsage()};
  active.timer=setTimeout(()=>void stopLocal('arm_deadline').catch(e=>console.error(e)),60000);
  return {pid:process.pid,kind,arm};
}
export async function stopLocal(reason='complete') {
  if(!active)return null;
  const current=active;if(current.stopping)return current.stopping;clearTimeout(current.timer);
  current.stopping=(async()=>{try {
    const {profile}=await current.session.post('Profiler.stop');
    const result={pid:process.pid,kind:current.kind,arm:current.arm,reason,
      elapsedMs:performance.now()-current.at,cpu:process.cpuUsage(current.cpu),
      file:join(current.directory,`${current.kind}-${current.arm}.cpuprofile`),
      attribution:'Inspector observation only; start/stop controls are outside collection stopwatch, sampling and GC overhead remain.'};
    await writeFile(result.file,JSON.stringify(profile),{flag:'wx'});
    await writeFile(join(current.directory,`${current.kind}-${current.arm}-profile.json`),JSON.stringify(result,null,2),{flag:'wx'});
    completed.add(current.arm); return result;
  } finally {current.session.disconnect();active=undefined;}})();
  return current.stopping;
}
process.on('exit',()=>{if(active){clearTimeout(active.timer);active.session.disconnect();}});
if (process.argv.includes('mcp')) {
  const directory=process.env.SCREENREC_ATTRIBUTION_OUT;
  assert(directory);
  const server=net.createServer(socket=>{
    socket.unref(); let pending='',commands=Promise.resolve();
    socket.on('error',()=>{});
    socket.on('data',bytes=>{
      pending+=bytes.toString('utf8');
      if(Buffer.byteLength(pending)>65536){socket.destroy(new Error('Profile control frame limit'));return;}
      for(let newline;(newline=pending.indexOf('\n'))>=0;){
        const line=pending.slice(0,newline);pending=pending.slice(newline+1);
        commands=commands.then(async()=>{
          const message=JSON.parse(line);
          try {
            const result=message.action==='start' ? await startLocal('mcp',message.arm,directory) : await stopLocal(message.reason);
            socket.write(JSON.stringify({id:message.id,result})+'\n');
          }catch(error){socket.write(JSON.stringify({id:message.id,error:error.message})+'\n');}
        }).catch(error=>console.error(error));
      }
    });
  });
  const socketPath=join(directory,`mcp-${process.pid}.sock`);
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socketPath,resolve);});
  server.unref();
  process.on('exit',()=>{server.close();try{unlinkSync(socketPath);}catch(error){if(error.code!=='ENOENT')console.error(error);}});
}
export async function connectControl(pid,directory) {
  const socket=net.createConnection(join(directory,`mcp-${pid}.sock`));
  await new Promise((resolve,reject)=>{socket.once('connect',resolve);socket.once('error',reject);});
  const waiting=new Map();let pending='';let next=0;
  const fail=error=>{for(const request of waiting.values()){clearTimeout(request.timer);request.reject(error);}waiting.clear();};
  socket.on('error',fail);socket.on('close',()=>fail(new Error('MCP profile control closed')));
  socket.on('data',bytes=>{
    pending+=bytes.toString('utf8');
    for(let newline;(newline=pending.indexOf('\n'))>=0;){
      const message=JSON.parse(pending.slice(0,newline));pending=pending.slice(newline+1);
      const request=waiting.get(message.id);if(!request)continue;
      waiting.delete(message.id);clearTimeout(request.timer);
      if(message.error)request.reject(new Error(message.error));else request.resolve(message.result);
    }
  });
  return {request(action,arm,reason){return new Promise((resolve,reject)=>{
    const id=++next;const timer=setTimeout(()=>{waiting.delete(id);reject(new Error('MCP CPU control deadline'));},5000);
    waiting.set(id,{resolve,reject,timer});socket.write(JSON.stringify({id,action,arm,reason})+'\n');
  });},close(){socket.destroy();}};
}
