import os,json,time,hashlib,subprocess,datetime
from pathlib import Path
root=Path('/tmp/screenrec-24z-caller-mcp-profile/successor')
record={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outerBoundSeconds':180,'terminal':False,'waited':False}
def save(): (root/'process.json').write_text(json.dumps(record,indent=2))
save()
try:
    preparation=json.loads((root/'preparation.json').read_text())
    authority=json.loads(Path('/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2/metadata-batch-55738523/profile/reference.json').read_text())
    checked=[]
    for entry in preparation['pins']+authority['runtime']+[authority['fixture'],authority['measure']]:
        data=Path(entry['path']).read_bytes()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
        checked.append(entry)
    (root/'immediate-pins.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':checked},indent=2))
    argv=['/Users/david/.nvm/versions/node/v24.14.0/bin/node',str(root/'producer.mjs'),'--out',str(root/'case'),'--phase','profile','--prepared','/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2/metadata-batch-55738523/measure']
    env=os.environ.copy();env.pop('NODE_OPTIONS',None);env.pop('NODE_V8_COVERAGE',None)
    env['SCREENREC_NATIVE']='/private/tmp/screenrec-09c-native-presented-worker'
    record['argv']=argv;record['environmentOverrides']={'SCREENREC_NATIVE':env['SCREENREC_NATIVE'],'NODE_OPTIONS':None,'NODE_V8_COVERAGE':None}
    with (root/'stdout.log').open('wb') as out,(root/'stderr.log').open('wb') as err:
        child=subprocess.Popen(argv,cwd='/Users/david/dev/screen-recorder',env=env,stdout=out,stderr=err,start_new_session=True)
        record['pid']=child.pid;record['dispatchedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
        print(json.dumps({'pid':child.pid,'status':'live','processRecord':str(root/'process.json')}),flush=True)
        at=time.monotonic()
        try: code=child.wait(timeout=180);record['timedOut']=False
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(child.pid,signal.SIGKILL);code=child.wait();record['timedOut']=True
        record.update(exitCode=code,terminal=True,waited=True,elapsedSeconds=time.monotonic()-at,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
        print(json.dumps(record),flush=True)
except BaseException as error:
    record['supervisorFailure']=repr(error);save();raise
