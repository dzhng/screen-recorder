import json,pathlib,hashlib,tarfile,datetime
r=pathlib.Path(__file__).parent;root=pathlib.Path('/Users/david/dev/screen-recorder');dest=root/'specs/agent-editing/assets/24z-current-preparation'
def read(p):return json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
a=read(r/'runtime-authority.json')
for v in a['pins']:assert pin(pathlib.Path(v['path']))==v,v['path']
g=read(r/'green/verify-report.json');m=read(r/'measure/measure-report.json');assert g['passed'] and m['passed'];assert len(g['collections'])==4 and len(m['collections'])==42
for report in [g,m]:
 assert not report['shutdownErrors'];assert report['defaultClient']['configured']==False and report['defaultClient']['maxBufferBytes']==10485760
 for c in report['collections']:
  assert c['pageCount']==7 and sum(p['rows'] for p in c['pages'])==250 and c['pages'][0]['rows']==0 and c['nextCursor'];assert c['nativeCallBoundary']['before']==c['nativeCallBoundary']['after']
assert all(v['p95Ms']<250 for v in m['arms'])
for phase,report in [('green',g),('measure',m)]:
 for p in (r/phase).glob('*operands.json'):
  o=read(p);assert len(o['actual'])==7
  for i,page in enumerate(o['actual']):assert page['response']['dependencies']==(o['expected']['dependencies'] if i==0 else {'manifestId':page['params']['cursor']['manifestId']})
for pid in {e['pid'] for e in m['processEvents'] if e['event']=='spawn'}:
 assert any(e['event']=='node-exit' and e['pid']==pid and e['code']==0 for e in m['processEvents'])
 assert any(e['event']=='close' and e['pid']==pid and e['code']==0 and e['signal']==None for e in m['processEvents'])
files={}
def add(p,n):assert p.is_file();files[n]=p
for f in r.iterdir():
 if f.is_file() and f.name!='whole-host-preflight.txt':add(f,f.name)
for phase,report in [('green',g),('measure',m),('red',read(r/'red/verify-report.json'))]:
 for f in (r/phase).iterdir():
  if f.is_file() and not f.name.endswith('processes.txt'):add(f,phase+'/'+f.name)
 for c in report['collections']:
  for v in c.get('cacheFiles',[]):
   p=r/phase/(v['id']+'.cache.json');assert pin(p)['sha256']==v['sha256'];add(p,phase+'/'+p.name)
for relative in ['packages/core/src/project-evidence.ts','packages/core/src/project-evidence.test.ts','packages/core/dist/project-evidence.js','packages/core/dist/project-evidence.d.ts','packages/test-harness/editing/source-cardinality.mjs','packages/test-harness/editing/source-metadata.mjs','packages/test-harness/editing/duration-memory.mjs','packages/test-harness/editing/cutover.mjs']:
 add(root/relative,'executed/'+relative)
child=pathlib.Path('/tmp/screenrec-project-evidence-reference')
for f in child.rglob('*'):
 if f.is_file():add(f,'child/'+str(f.relative_to(child)))
archive=dest/'manifest-reference.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name,recursive=False)
members=[{'member':n,**pin(f)} for n,f in sorted(files.items())]
with tarfile.open(archive) as t:
 for v in members:
  b=t.extractfile(v['member']).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
result={'scope':'Current public source-cardinality query proof only; final scale, installed adoption, physical synchronization and speech acceptance remain separate.','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'sourceCommit':'0d413958','formatDecision':'Named correction: full first-page dependencies; same immutable manifest reference on continuations including terminal. All source validation still occurs before reading and after checkpoint publication. Historical full-every-page outputs are not claimed byte-identical.','productionSize':{'added':3,'deleted':2,'net':1,'newTablesEndpointsDependenciesFlagsCaches':0},'focusedChecks':{'mergedTests':49,'files':2,'exitCode':0,'log':pin(r/'merged-tests.log'),'lint':'four changed harnesses pass','format':'changed harnesses pass after formatting one expression','independentCliReview':'Unavailable: configured model unsupported in earlier unchanged attempt; root source review and blind external-caller skill check used, not a CLI review pass.'},'runtimeAfter':{'authority':pin(r/'runtime-authority.json'),'count':774,'intendedChanges':5,'differences':[]},'preflight':read(r/'preflight.json'),'correctness':{'process':read(r/'green-process.json'),'report':pin(r/'green/verify-report.json'),'collections':4,'cliMcpParity':True,'changedQueryRefusal':g['pinnedRefusal'],'completeComparisonOperandsRetained':True,'queryNativeCalls':0,'latencyMeaning':'untimed'},'measurement':{'process':read(r/'measure-process.json'),'report':pin(r/'measure/measure-report.json'),'collections':42,'warmCollectionsPerArm':20,'budgetMs':250,'arms':m['arms'],'completeOutputChecks':True,'completeColdComparisonOperandsRetained':True,'queryNativeCalls':0,'allChildrenNodeExitAndOsClose':True,'shutdownErrors':[]},'redPreservation':'Original public harness format failure retained; full failing operands were not saved by that executed producer. No false latency claim for that correctness run.','next':'Reuse this scoped pass; prepare updated staged candidate and remaining consumer/installed acceptance. Do not repeat this cohort without a change invalidating it.','archive':pin(archive),'members':members}
(dest/'manifest-reference.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'pinsVerified':774,'membersVerified':len(members),'archiveBytes':archive.stat().st_size,'p95':[v['p95Ms'] for v in m['arms']]}))
