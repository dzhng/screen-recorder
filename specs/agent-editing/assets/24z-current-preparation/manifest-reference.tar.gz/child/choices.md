The response format is the root-authorized contract decision: the first ready page carries complete source metadata, while each continuation names that same immutable manifest. Pending first-request replies remain complete arrays. No source fact is removed from the manifest, and both fresh validations remain in place.

Sound implementation choice (high confidence): one local dependency value feeds the existing size check and actual return. For a continuation with many sources, the byte guard therefore measures the reference the caller really receives; it does not charge for metadata absent from that reply. There is no second format owner or new public helper.

Sound type choice (high confidence): infer the existing method's array-or-reference union from that same return owner. First-page tests narrow the array through a small test-local accessor before inspecting source fields; pagination tests validate reference IDs, including terminal continuation pages. No cast, type suppression or duplicate response schema was added.

No unresolved implementation choice. Whether callers prefer repeated full metadata is the explicitly named root-owned, reversible product choice, not a hidden performance requirement relaxation.
