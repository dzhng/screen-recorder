Shape/code/docs review clean. Three production additions/two removals select dependencies once and use the result for bounding and publication; persisted manifests, query policies, source selection, digest, cursor budgets, both validation phases, publication rollback and restart consumers are unchanged. No new API/cache/epoch/schema/dependency/configuration.

49 affected existing tests pass, including source changes during checkpoint publication, next-request freshness, earlier failure ordering, recovery, exact clocks/rows and empty continuations. First-page dependency equality is checked against the complete persisted immutable manifest. Get/search/events collectors check continuation references, including terminal pages. Core type check, focused lint/format and diff check pass.

Direct live harness assumptions needing root-owned updates: source-cardinality.mjs, source-metadata.mjs, cutover.mjs completeTranscript, duration-memory.mjs. First-only array consumers in capture-evidence.mjs, generation-evidence.mjs, cutover-words.mjs, speech-parity.mjs and transcript-duration-fixture.mjs remain valid. Service handlers pass through the shared owner; no renderer/frontend array consumer found. Historical immutable reports remain historical.

The prior local Codex review failed before review with unsupported configured default model; root explicitly prohibited unchanged retry/model override. This pass used own review and root independent integration review, not a new claimed Codex review. Prior authority: /tmp/screenrec-source-metadata-batch/codex-process.json and codex.stderr.

No measurement/native/service/media/model/build/full-suite run; no p95 claim. Original red, fixture authoring errors and deleted-semantics test failures remain separate.
