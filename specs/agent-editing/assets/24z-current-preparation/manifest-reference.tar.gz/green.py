import datetime,json,os,pathlib,signal,subprocess,time
r=pathlib.Path(__file__).parent
cmd=['/Users/david/.nvm/versions/node/v24.14.0/bin/node','packages/test-harness/editing/source-cardinality.mjs','--out','/Users/david/.cache/screen-recorder/verification/source-cardinality-current-edc309d2/manifest-reference-68ebf797/green','--phase','verify']
env=dict(os.environ,SCREENREC_NATIVE='/private/tmp/screenrec-09c-native-presented-worker');env.pop('NODE_V8_COVERAGE',None);env.pop('NODE_OPTIONS',None)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();at=time.monotonic()
with (r/'green.stdout').open('wb') as out,(r/'green.stderr').open('wb') as err:
 child=subprocess.Popen(cmd,cwd='/Users/david/dev/screen-recorder',env=env,stdout=out,stderr=err,start_new_session=True)
 record={'argv':cmd,'pid':child.pid,'startedAt':start,'outerBoundSeconds':180,'environmentOverrides':{'SCREENREC_NATIVE':env['SCREENREC_NATIVE'],'NODE_V8_COVERAGE':None,'NODE_OPTIONS':None}}
 (r/'green-process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
 expired=False
 try:code=child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 record.update(exitCode=code,terminal=True,waited=True,timedOut=expired,elapsedSeconds=time.monotonic()-at,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (r/'green-process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(code if not expired else 124)
