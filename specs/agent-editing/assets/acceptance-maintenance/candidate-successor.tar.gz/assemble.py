import pathlib,json,subprocess,hashlib
root=pathlib.Path('/Users/david/dev/screen-recorder');r=pathlib.Path(__file__).parent;b=r.parent;source=b/'ScreenRecorder.app';target=r/'ScreenRecorder.app';assert not target.exists()
def pin(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
relative=['Contents/MacOS/ScreenRecorder','Contents/MacOS/screenrec-native','Contents/Resources/service/main.mjs','Contents/Resources/service/runtime.json','Contents/Resources/cli/main.mjs'];before=[pin(source/f) for f in relative];steps=[]
for argv in [['/bin/cp','-cR',str(source),str(target)],['bun','build','apps/service/dist/project-main.js','--target=node','--outfile',str(target/'Contents/Resources/service/main.mjs')],['codesign','--force','--sign','Screen Recorder Local',str(target)],['codesign','--verify','--strict',str(target)]]:
 p=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=30);steps.append({'argv':argv,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(r/'assembly.json').write_text(json.dumps({'sourceCommit':'0d413958','scope':'Separate staged project-service successor; original staged app and installed app unchanged','steps':steps},indent=2)+'\n');assert p.returncode==0,p.stderr
assert before==[pin(source/f) for f in relative]
record=json.loads((r/'assembly.json').read_text());record.update(originalCandidateUnchanged=before,candidatePins=[pin(target/f) for f in relative],sourceInputs=[pin(root/f) for f in ['apps/service/dist/project-main.js','packages/core/dist/project-evidence.js']]);(r/'assembly.json').write_text(json.dumps(record,indent=2)+'\n')
script=(b/'smoke-qualified/smoke.py').read_text().replace("app=p.parent/'ScreenRecorder.app'","app=p/'ScreenRecorder.app'");(r/'smoke.py').write_text(script);print('Separate candidate assembled and signed; original candidate pins unchanged')
