import Foundation
import AVFoundation

@main struct PlaybackCheck {
    static func main() async {
        let path = CommandLine.arguments[1]
        let asset = AVURLAsset(url: URL(fileURLWithPath: path), options: [AVURLAssetOverrideMIMETypeKey: "video/mp4"])
        do {
            let playable = try await asset.load(.isPlayable)
            let duration = try await asset.load(.duration)
            let item = AVPlayerItem(asset: asset)
            let player = AVPlayer(playerItem: item)
            player.play()
            let ends = Date().addingTimeInterval(5)
            var observations: [[String: Any]] = []
            while Date() < ends {
                try await Task.sleep(for: .milliseconds(100))
                observations.append(["status": item.status.rawValue, "rate": player.rate,
                    "seconds": CMTimeGetSeconds(player.currentTime()), "timeControlStatus": player.timeControlStatus.rawValue])
                if item.status == .failed || CMTimeGetSeconds(player.currentTime()) > 0.5 { break }
            }
            player.pause()
            let passed = playable && item.status == .readyToPlay && CMTimeGetSeconds(player.currentTime()) > 0.5
            let report: [String: Any] = ["passed": passed, "scope": "Headless AVFoundation item/playback readiness using the actual preview cache path and identical MIME override; no AVPlayerView/window/pixels proof", "playable": playable,
                "durationSeconds": CMTimeGetSeconds(duration), "observations": observations,
                "error": item.error?.localizedDescription ?? NSNull()]
            let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
            print(String(data: data, encoding: .utf8)!)
            exit(passed ? 0 : 1)
        } catch { print(error); exit(1) }
    }
}
