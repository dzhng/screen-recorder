import pathlib,json,hashlib
base=pathlib.Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002')
inputs={'capture':base/'public-capture/report.json','facts':base/'public-capture/publication-facts.json','recovery':base/'public-capture-recovery/report.json'}
loaded={k:json.loads(p.read_text()) for k,p in inputs.items()}
c,f,r=(loaded[k] for k in ['capture','facts','recovery'])
finished={role:next(x['data'] for x in f[path] if x['event']=='finished') for role,path in [('primary','source/capture.journal.jsonl'),('camera','camera/capture.journal.jsonl')]}
assert c['terminal']['state']=='complete' and c['terminal']['publication']==r['finalRecording']['publication']
assert finished['primary']['hostOriginUs']==finished['camera']['hostOriginUs']
assert finished['primary']['pauses']==finished['camera']['pauses'] and len(finished['primary']['pauses'])==1
checks=[]
for kind,role in [('primary','video'),('primary','narration'),('camera','video')]:
 a=r['acquisitions'][kind];binding=next(b for b in a['bindings'] if role in b['sourceRoles']);track=next(t for t in finished[kind]['tracks'] if t['role']==role)
 offset=binding['sourceToAssetOffsetUs'];mapped=[{'startUs':v['startUs']-offset,'endUs':v['endUs']-offset} for v in binding['available']]
 expectedEnd=min(track['lastSampleEndUs'],finished[kind]['durationUs'])
 assert mapped[0]['startUs']==track['firstSampleUs']
 assert mapped[-1]['endUs']==expectedEnd
 assert track['droppedSamples']==0
 # Source duration clips a submitted sample that extends past physical terminal support.
 checks.append({'sourceKind':kind,'sourceId':a['sourceId'],'role':role,'assetId':binding['assetId'],'streamId':binding['streamId'],'formula':'sourceUs = assetUs - sourceToAssetOffsetUs','sourceToAssetOffsetUs':offset,'assetAvailable':binding['available'],'mappedSourceAvailable':mapped,'journalFirstSampleUs':track['firstSampleUs'],'journalLastSampleEndUs':track['lastSampleEndUs'],'journalDurationUs':finished[kind]['durationUs'],'expectedEndFormula':'min(journalLastSampleEndUs, journalDurationUs)','expectedEndUs':expectedEnd,'matches':True})
mic=next(x for x in checks if x['role']=='narration');ranges=mic['mappedSourceAvailable'];assert len(ranges)==2
pause=finished['primary']['pauses'][0];gap={'startUs':ranges[0]['endUs'],'endUs':ranges[1]['startUs']};assert gap['startUs']<=pause['atSourceUs']<gap['endUs']
assert c['terminal']['publication']['primary']['source']['originHostUs']==finished['primary']['hostOriginUs']==c['terminal']['publication']['camera']['source']['originHostUs']
report={'passed':True,'scope':'Saved JSON reconciliation of one actual built-in public capture and its recovered source admission; no media decoding, model, capture or product process executed.','inputs':{k:{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in inputs.items()},'recordingId':c['terminal']['recordingId'],'publicationUnchangedAcrossRecovery':True,'sharedOriginHostUs':finished['primary']['hostOriginUs'],'sourceSupport':checks,'pause':{'screenAndCameraJournalEqual':True,**pause,'microphoneGap':gap,'gapDurationUs':gap['endUs']-gap['startUs'],'boundaryInsideGap':True,'boundaryPredicate':'gap.startUs <= atSourceUs < gap.endUs','gapStartRelativeToPauseUs':gap['startUs']-pause['atSourceUs'],'gapEndRelativeToPauseUs':gap['endUs']-pause['atSourceUs'],'interpretation':'Omitted microphone buffer support brackets the shared pause splice; this is not a measurement of audible splice quality.'},'limitations':['Checks saved authoritative JSON and prior hashed publication facts; does not independently decode or rehash media.','Clock/support consistency does not establish physical audiovisual synchronization or a33ms drift bound.','Does not establish sustained physical stop performance, missing/disconnected-device behavior, installed or full-release acceptance.','The journals describe capture-authoritative facts, not an independent physical event oracle.']}
out=pathlib.Path(__file__).parent;(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'checks':len(checks),'gap':gap,'pauseUs':pause['atSourceUs'],'output':str(out/'report.json')}))
