"""Frozen complete saved-case checker; no compiler/native/media invocation."""
import json,pathlib,base64,hashlib,copy
from fractions import Fraction
root=pathlib.Path(__file__).parent
j=lambda name:json.loads((root/name).read_text())
def rat(t):return Fraction(t['value'],t['scale'])
def pictures(snapshot):
    assert snapshot['readerStatus']==2 and snapshot['nativeScale']==1000000
    for i,p in enumerate(snapshot['pictures']):
        assert p['ordinal']==i and (p['width'],p['height'])==(32,16)
        assert p['end'] is not None and len(base64.b64decode(p['bgra'],validate=True))==2048
    return snapshot['pictures']
def validate():
    plan=j('plan.json');proc=j('processes.json')['processes'];assert [x['label'] for x in proc]==['compile','ordinary','interrupt','fresh-raw-reader']
    assert all(x['terminal'] for x in proc) and [x['exitCode'] for x in proc]==[0,0,-9,0]
    assert all(x['elapsedSeconds']<b for x,b in zip(proc,[150,20,20,15]))
    assert proc[0]['argv']==plan['compile']
    for x,key in zip(proc[1:],['ordinary','interrupt','recover']):assert x['argv']==plan[key]
    assert j('controller-verdict.json')['status']=='pass'
    pin=j('binary.json');binary=root/'fence-probe';assert binary.stat().st_size==pin['bytes'] and hashlib.sha256(binary.read_bytes()).hexdigest()==pin['sha256']
    assert proc[2]['intentionalSignal'].startswith('SIGKILL')
    allqueries=[]
    for x in proc:
        assert x['streamsFullyDrained'] and max(x['stdioBytes'].values())<=1048576
        allqueries.extend(x['byteQueries'])
    for q in allqueries:
        receipt=q['receipt'];assert receipt['terminal'] and receipt['waited'] and receipt['exitCode']==0
    assert len(allqueries)==14
    assert all(q['receipt']['groupID']==q['receipt']['pid'] for q in allqueries) # Observed distinct group, not a general ownership claim.
    for case in ['ordinary','interrupted']:
        selected=j(case+'/candidate-fence.json');assert selected=={'fenceOrdinal':29,'fragment':1,'admittedAtSelection':37,'offeredAtSelection':37}
        candidate=j(case+'/candidate.json');prefix=pictures(candidate)[:29]
        assert len(candidate['pictures'])==30
        first=j(case+'/active-1-codec.json');assert first['rows'][29]['idr']['noOutputOfPriorPics']==0
        assert first['completeIDRFenceOrdinals']==[29]
        assert candidate['pictures'][29]['pts']==candidate['cursorFacts'][29]['requestedAssetPTS']
        for n in [1,2,3]:
            copy=j(case+f'/fragment-{n}-copy.json');movie=root/case/f'fragment-{n}.mov'
            assert movie.stat().st_size==copy['completeBytes']<=copy['sourceBytes']<=2097152
            assert not copy['atomRewriting'] and not copy['offsetsNormalized'] and copy['copiedFromOffset']==0
            snap=j(case+f'/active-{n}.json');codec=j(case+f'/active-{n}-codec.json')
            assert hashlib.sha256(movie.read_bytes()).hexdigest()==codec['sourceSHA256']
            assert pictures(snap)[:29]==prefix
            assert len(codec['rows'])==len(snap['pictures']) and [r['logical'] for r in codec['rows'][:29]]==[r['logical'] for r in first['rows'][:29]]
            fmt=j(case+f'/active-{n}-formats.json');assert fmt['authority']=='native-cursors' and fmt['allCursorFormatsEqual']
            assert 'preferredTransform' in fmt['formatIdentity']
            for row in codec['rows'][:29]:
                assert row['logical']['format']==fmt['formatIdentity'] and row['logical']['parameterSets']==fmt['parameterSets']
            if n>1:
                receipt=j(case+f'/active-{n}-comparison-receipt.json')
                assert receipt['laterFragment']>receipt['candidateFragment']==1 and receipt['laterAdmitted']>receipt['candidateAdmitted']==37 and receipt['writerCloseCalled']==0
                logical=j(case+f'/active-{n}-logical-comparison.json');assert logical['differences']==[] and logical['expected']==logical['actual']==[r['logical'] for r in first['rows'][:29]] and not logical['physicalOffsetsCompared']
                for name in ['expected','actual','differences']:
                    operand=j(case+f'/evidence/comparison-active-{n}-{n}-'+name+'.json')
                    if name=='expected':assert operand==prefix
                    elif name=='actual':assert operand==snap
                    else:assert operand==[]
        mappings=j(case+'/accepted-mappings.json');receipts=j(case+'/evidence/offered-receipts.json');assert len(receipts)==390
        assert [r['offeredOrdinal'] for r in receipts]==list(range(390))
        admitted=[r['cameraFrame'] for r in receipts if r.get('cameraFrame') is not None];assert admitted==mappings
    closed=j('ordinary/closed.json');assert pictures(closed)[:29]==pictures(j('ordinary/candidate.json'))[:29]
    mappings=j('ordinary/accepted-mappings.json');assert len(mappings)==len(closed['pictures'])==384
    for i,(m,p) in enumerate(zip(mappings,closed['pictures'])):
        assert m['ordinal']==p['ordinal']==i
        t=m['start'];grid=(2*t['value']*1000000+t['timescale'])//(2*t['timescale'])
        assert p['digestPTS']['value']==grid and p['digestPTS']['scale']==1000000 and p['digestPTS']['epoch']==t['epoch']
    logical=j('ordinary/closed-logical-comparison.json');assert logical['expected']==logical['actual'] and logical['differences']==[]
    reopened=j('interrupted/recovery/recovered.json');assert len(pictures(reopened))==276 and pictures(reopened)[:29]==pictures(j('interrupted/candidate.json'))[:29]
    logical=j('interrupted/recovery/logical-comparison.json');assert logical['expected']==logical['actual'] and logical['differences']==[]
    assert j('interrupted/recovery/verdict.json')['status']=='pass' and 'no canonical' in j('interrupted/recovery/verdict.json')['scope']
    assert j('ordinary/verdict.json')['status']=='pass' and len(j('interrupted/accepted-mappings.json'))==334
    assert j('cache-before.json')==j('cache-after.json')
    assert j('termination.json')['targetedOwnedPIDAbsence']['stdout']==''
    for pin in j('authority.json')['pins']:
        p=pathlib.Path(pin['path']);data=p.read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],pin['path']
    return {'status':'pass','ordinaryCommitted':29,'ordinaryClosedAccepted':384,'interruptCommitted':29,'interruptAccepted':334,'reopenedCompletePictures':276,'decodedClosingIDR':True,'actualLaterAdmissions':True,'completeLogicalAndTupleIdentity':True,'byteQueryReceiptsAllTerminalWaited':14,'protectedPins':129,'cacheFilesUnchanged':len(j('cache-before.json')),'timeoutCleanupQualified':False,'scope':'Full saved-case values only; no native replay'}
if __name__=='__main__':print(json.dumps(validate(),indent=2))
