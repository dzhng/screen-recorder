import{appendFileSync}from'node:fs';
import{PreparedAudioStore}from'/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/prepared-audio.js';
for(const method of ['request','resolve','open']){const original=PreparedAudioStore.prototype[method];PreparedAudioStore.prototype[method]=function(...args){try{return original.apply(this,args);}catch(error){appendFileSync('/tmp/screenrec-24v-owner-errors.jsonl',JSON.stringify({method,name:error.name,message:error.message,stack:error.stack})+'\n');throw error;}}}
