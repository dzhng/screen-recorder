import assert from 'node:assert/strict';import{readFile,writeFile,mkdir,realpath,readdir}from'node:fs/promises';import{join}from'node:path';
import{JourneyService,poll,hash}from'/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
import{waveHeader}from'/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/audio-project-fixture.mjs';
import{createDenoiseReference}from'/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/denoise-reference.mjs';
const prior='/tmp/screenrec-24v-learned-topology-bounded',out='/tmp/screenrec-24v-learned-topology-continuation';await mkdir(out);
const previous=JSON.parse(await readFile(prior+'/report.json','utf8'));
const report={passed:false,trace:[],checks:{},selection:previous.selection,home:await realpath(previous.home),priorReportSha256:hash(await readFile(prior+'/report.json')),scope:'Continue existing ready prepared publication through canonical home; all learned operations unavailable; no preparation rerun'};
const reference=createDenoiseReference('/Users/david/.cache/screen-recorder/test-prerequisites/rnnoise-api-697657e249b1',out),s=new JourneyService(report.home,report);
const pcm=b=>{const h=waveHeader(b,b.length);return b.subarray(h.offset,h.offset+h.frames*8);};
function exact(a,b,label){assert(a.equals(b),JSON.stringify({label,a:hash(a),b:hash(b),actualBytes:a.length,expectedBytes:b.length}));}
try{await s.start();const call=(o,p,extra={})=>s.call(o,p,{transport:'mcp',...extra});
const at=performance.now();report.prepared=await call('audio.prepare',report.selection);report.retainedLookupMs=performance.now()-at;assert.equal(report.prepared.state,'ready');assert.deepEqual(await call('audio.prepare',report.selection),report.prepared);
const asset=await call('asset.get',{assetId:report.prepared.published.audio.assetId});const full=await readFile(join(report.home,'library/assets',asset.id+'.wav'));await writeFile(out+'/prepared.wav',full);
const dry=await readFile(prior+'/independent-dry.f32');const start=performance.now(),wet=reference('combined',dry,2);report.referenceMs=performance.now()-start;exact(pcm(full),wet,'full reference');report.checks.full={frames:wet.length/8,sha256:hash(wet),exact:true};
await s.stop();await s.start();const late={assetId:asset.id,streamId:asset.streams[0].id,range:{startUs:7750000,endUs:8000000}};
const started=performance.now();report.late=await poll(()=>call('audio.get',late),v=>v.state==='ready','retained late');await call('audio.get',late,{transport:'cli',output:out+'/retained-late.wav'});report.lateMs=performance.now()-started;const bytes=await readFile(out+'/retained-late.wav');exact(pcm(bytes),wet.subarray(372000*8),'late reference');report.checks.late={frames:12000,sha256:hash(pcm(bytes)),exact:true};
assert.deepEqual(await readdir(join(report.home,'library/render'),{recursive:true}),[]);report.passed=true;
}catch(e){report.failure={message:e.message,stack:e.stack};throw e;}finally{try{await s.stop();}catch(e){report.passed=false;report.shutdownFailure=e.message;throw e;}finally{report.serviceLogs=s.logs;report.controllerPeakRSS=process.resourceUsage().maxRSS*1024;await writeFile(out+'/report.json',JSON.stringify(report,null,2));}}
