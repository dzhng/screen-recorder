import datetime,json,os,pathlib,signal,subprocess,time
p=pathlib.Path(__file__).parent; app=p.parent/'ScreenRecorder.app/Contents/MacOS/ScreenRecorder'
request={'cameraID':'6C707041-05AC-0011-0009-000000000001','framesPerSecond':30,'source':{'kind':'display','displayID':1},'cameraDelaySeconds':2,'microphone':{'deviceID':'BuiltInMicrophoneDevice','enabled':True},'outputDirectory':str(p/'builtin-live'),'durationSeconds':30,'pause':{'atSeconds':8,'durationSeconds':2}}
(p/'builtin-request.json').write_text(json.dumps(request)); env={**os.environ,'SCREENREC_HOME':str(p/'home'),'SCREENREC_DEFAULTS':str(p/'defaults'),'SCREENREC_SERVICE_LAUNCH':'1'}
argv=[str(app),'--probe','selected-devices','capture',str(p/'builtin-request.json')]
start=time.monotonic();stdout=(p/'capture.stdout').open('w');stderr=(p/'capture.stderr').open('w');proc=subprocess.Popen(argv,cwd='/',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
r={'argv':argv,'pid':proc.pid,'scope':'One built-in selected-device live shutdown fixture; not retained iPhone or synchronization acceptance','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':request,'terminal':False};(p/'capture-process.json').write_text(json.dumps(r,indent=2))
while proc.poll() is None and time.monotonic()-start<18:time.sleep(.1)
if proc.poll() is None:
 stop=time.monotonic();r['signalAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();proc.send_signal(signal.SIGTERM)
 try:proc.wait(timeout=12)
 except subprocess.TimeoutExpired: r['timedOut']=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 r['signalToExitSeconds']=time.monotonic()-stop
else:r['earlyExit']=True
r.update(exitCode=proc.returncode,terminal=True,waited=True,elapsedSeconds=time.monotonic()-start,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()); stdout.close();stderr.close()
result=p/'builtin-live/screen-result.json';r['durableResultExists']=result.is_file()
if result.is_file():r['result']=json.loads(result.read_text())
(p/'capture-process.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k not in ['result','request','argv']}));raise SystemExit(proc.returncode or 0)
