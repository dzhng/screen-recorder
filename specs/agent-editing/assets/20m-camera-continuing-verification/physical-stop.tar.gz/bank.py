import json,pathlib,hashlib,tarfile
b=pathlib.Path('/Users/david/.cache/screen-recorder/verification/project-candidate-20261002');p=b/'physical';d=json.loads((p/'capture-process.json').read_text());r=d['result'];o=p/'builtin-live'
assert d['exitCode']==0 and d['waited'] and d['terminal'] and not d.get('earlyExit') and not d.get('timedOut') and d['signalToExitSeconds']<10
assert r['state']==r['camera']['state']=='complete' and r['hostOriginUs']==r['camera']['hostOriginUs'] and r['pauses']==r['camera']['pauses'] and len(r['pauses'])==1
assert all(v['droppedSamples']==0 for v in r['tracks']+r['camera']['tracks'])
cr=json.loads((o/'camera/capture-result.json').read_text());returned=r['camera'];assert pathlib.Path(returned['directory'])==o/'camera'
assert all(cr[k]==v for k,v in returned.items() if k!='directory')
def pin(p):
 data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
files=[p/v for v in ['bank.py','capture.py','builtin-request.json','capture-process.json','capture.stdout','capture.stderr','status-process.json','sources-process.json']]+[v for v in o.rglob('*') if v.is_file() and v.suffix in ['.json','.jsonl']]
a=pathlib.Path('/Users/david/dev/screen-recorder/specs/agent-editing/assets/20m-camera-continuing-verification/physical-stop.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for v in files:t.add(v,arcname=str(v.relative_to(p)),recursive=False)
media=[pin(v) for v in o.rglob('*.mov')]
result={'scope':'One brief built-in selected-device graceful shutdown, not iPhone synchronization, sustained-stop or general performance','rootHead':'e96cddac','process':d,'actualApp':pin(b/'ScreenRecorder.app/Contents/MacOS/ScreenRecorder'),'actualWorker':pin(b/'ScreenRecorder.app/Contents/MacOS/screenrec-native'),'inputs':json.loads((p/'sources-process.json').read_text()),'originalIphoneAttempt':'Not dispatched: selected original camera absent. Built-in capture is a separately authored fixture, not a fallback or substitution.','checks':{'signalToDurableResultAndExitUnder10s':True,'screenAndCameraComplete':True,'sharedOriginAndPause':True,'zeroDroppedSamples':True,'cameraDurableFieldsMatchReturnedCamera':True},'media':media,'archive':pin(a),'members':[pin(v) for v in files],'limits':['No physical flash/beep uncertainty bound or drift measurement','No 250-second sustained physical-input stop claim','No candidate service or installed-app acceptance','App-owned probe output; source CLI/MCP live capture remains separate']}
a.with_name('physical-stop.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'actualStopSeconds':d['signalToExitSeconds'],'mediaFiles':len(media),'retainedBytes':sum(v['bytes'] for v in media),'archiveBytes':a.stat().st_size}))
