from pathlib import Path
import json,hashlib,subprocess,time,datetime,os
from fractions import Fraction
out=Path('/tmp/screenrec-two-camera-correspondence')
plan=json.loads((out/'plan.json').read_text())
report={'scope':plan['scope'],'passed':False,'producerPid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processes':[],'cases':[],'beforePins':plan['currentPins'],'historicalWorkerSha256':plan['historicalWorkerSha256'],'candidateWorkerSourceCommit':plan['candidateWorkerSourceCommit'],'encodedSampleProbe':plan['encodedSampleProbe']}
started=time.monotonic()
def save(): (out/'report.json').write_text(json.dumps(report,indent=2))
def pin(path):
 p=Path(path);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def run(argv,label,bound,input=None):
 remaining=plan['outerBoundSeconds']-(time.monotonic()-started)
 assert remaining>0,'Outer diagnostic deadline'
 process={'argv':argv,'boundSeconds':min(bound,remaining),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False}
 report['processes'].append(process);save()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  child=subprocess.Popen(argv,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=stdout,stderr=stderr)
  process['pid']=child.pid;save();print(json.dumps({'pid':child.pid,'label':label,'status':'live'}),flush=True)
  at=time.monotonic()
  try:
   child.communicate(input=input,timeout=process['boundSeconds']);process['timedOut']=False
  except subprocess.TimeoutExpired:
   child.kill();child.communicate();process['timedOut']=True
  process.update(exitCode=child.returncode,terminal=True,waited=True,elapsedSeconds=time.monotonic()-at,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
  assert not process['timedOut'] and child.returncode==0,f'{label} actual terminal {child.returncode}'
 return (out/(label+'.stdout')).read_bytes()
try:
 for p in plan['currentPins']:assert pin(p['path'])==p,p['path']
 report['producer']=pin(out/'run.py');save()
 for case in plan['cases']:
  n=case['ordinal'];row={'ordinal':n,'request':case['request'],'reference':pin(out/case['reference'])};report['cases'].append(row);save()
  stdout=run([plan['currentPins'][0]['path']],f'native-{n}',plan['nativeBoundSeconds'],(json.dumps(case['request'])+'\n').encode())
  lines=stdout.decode().splitlines();assert len(lines)==1,'Exactly one native reply required'
  reply=json.loads(lines[0]);row['reply']=reply;save()
  assert reply['id']==case['request']['id'] and reply['ok'] is True,reply
  data=reply['data'];row['nativePNG']=pin(data['file']);save()
  assert data['actualSourceUs']==case['sourceUs'], 'Selected source picture changed'
  assert (data['width'],data['height'])==(1920,1080), 'Full source geometry changed'
  sample=data['sample'];row['sample']=sample;save()
  first=Fraction(int(sample['value']),sample['timescale'])*1000000
  end=Fraction(int(sample['endValue']),sample['endTimescale'])*1000000
  assert first<=case['containerUs']<end,'Requested container time is outside selected physical support'
  for prefix,image in [('reference',out/case['reference']),('native',Path(data['file']))]:
   target=out/f'{prefix}-{n}.rgba'
   run([plan['currentPins'][1]['path'],str(image),str(target)],f'{prefix}-pixels-{n}',plan['pixelCommandBoundSeconds'])
   row[prefix+'RGBA']=pin(target);save()
  a=(out/f'reference-{n}.rgba').read_bytes();b=(out/f'native-{n}.rgba').read_bytes()
  row['comparison']={'bytesExpected':8294400,'referenceBytes':len(a),'nativeBytes':len(b),'equal':a==b}
  if a!=b and len(a)==len(b):
   row['comparison']['differentSamples']=sum(x!=y for x,y in zip(a,b))
   row['comparison']['differentPixels']=sum(a[i:i+4]!=b[i:i+4] for i in range(0,len(a),4))
   row['comparison']['firstDifferentByte']=next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y)
  save()
  assert len(a)==len(b)==8294400 and a==b,'Complete pixel comparison differs; stop without tolerance/second request'
 report['passed']=True
except BaseException as error:
 report['error']={'type':type(error).__name__,'message':str(error)}
finally:
 report['afterPins']=[pin(p['path']) for p in plan['currentPins']]
 report['inputsUnchanged']=report['afterPins']==report['beforePins']
 report['elapsedSeconds']=time.monotonic()-started;report['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps({'passed':report['passed'],'caseCount':len(report['cases']),'report':str(out/'report.json')}),flush=True)
raise SystemExit(0 if report['passed'] and report['inputsUnchanged'] else 1)
