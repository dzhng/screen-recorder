from pathlib import Path
import json,subprocess,os,time,datetime,hashlib,selectors,re,signal
from fractions import Fraction
r=Path(__file__).parent;base=r.parent
plan=json.loads((base/'current-binding-preparation/plan.json').read_text());source=Path(plan['target']['input']);ffprobe=plan['toolPaths']['ffprobe'];ffmpeg=plan['toolPaths']['ffmpeg'];deadline=None
old=base/'current-binding-execution'
fixed=json.loads((r/'plan.json').read_text())
previous=base/'current-binding-ffclock-successor'
report={'scope':'FINITE64packetview; exactlogicalmetadata beforeonePNG; originaltwofailures/nativeRGBredunchanged' ,'passed':False,'producerPID':os.getpid(),'processes':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bounds':plan['boundedPhases'],'sharedDataDeadlineSeconds':30}
def save(): (r/'report.json').write_text(json.dumps(report,indent=2))
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def run(argv,label,onLine=None):
 remaining=deadline-time.monotonic();assert remaining>0,'Shared data deadline expired before '+label
 row={'label':label,'argv':argv,'boundSeconds':remaining,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False};report['processes'].append(row);save();start=time.monotonic()
 buffers={};counts={};failure=None
 with (r/(label+'.stdout')).open('wb') as o,(r/(label+'.stderr')).open('wb') as e:
  child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);row['pid']=child.pid;row['processGroupID']=os.getpgid(child.pid);save();print(json.dumps({'label':label,'pid':child.pid,'status':'live'}),flush=True)
  selector=selectors.DefaultSelector()
  for key,stream,dst in [('stdout',child.stdout,o),('stderr',child.stderr,e)]:
   os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,(key,dst));buffers[key]=b'';counts[key]=0
  try:
   while selector.get_map():
    assert time.monotonic()<deadline,'Shared data deadline expired during '+label
    if (r/'view.mov').exists():assert (r/'view.mov').stat().st_size<=16_777_216,'PrivateMOV16MiBbound'
    for event,_ in selector.select(timeout=min(.1,max(0,deadline-time.monotonic()))):
     key,dst=event.data;chunk=os.read(event.fileobj.fileno(),65536)
     if not chunk:selector.unregister(event.fileobj);continue
     dst.write(chunk);dst.flush();counts[key]+=len(chunk);assert counts[key]<=2_097_152,label+' stdio cap exceeded'
     buffers[key]+=chunk
     while b'\n' in buffers[key]:
      line,buffers[key]=buffers[key].split(b'\n',1)
      if onLine:onLine(key,line.decode('utf8',errors='strict'))
   for key,data in buffers.items():
    if data and onLine:onLine(key,data.decode('utf8',errors='strict'))
   child.wait(timeout=max(.001,deadline-time.monotonic()))
  except BaseException as error:
   failure=error
   if child.poll() is None:os.killpg(child.pid,signal.SIGKILL)
   child.wait()
  finally:
   selector.close();child.stdout.close();child.stderr.close();row.update(exitCode=child.returncode,terminal=True,waited=True,elapsedSeconds=time.monotonic()-start,stdioBytes=counts,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),supervisorFailure=None if failure is None else str(failure));save()
  if failure:raise failure
  assert child.returncode==0,label+' actual terminal '+str(child.returncode)
 return (r/(label+'.stdout')).read_text()
try:
 before=json.loads((r/'before-pins.json').read_text());report['beforePins']=[pin(p['path']) for p in before];assert report['beforePins']==before,'Protected authority changed'
 tools=json.loads((r/'tool-authority.json').read_text());toolPins=[t['executable'] for t in tools.values()]+[p for t in tools.values() for p in t['libraries']];assert all(pin(p['path'])==p for p in toolPins),'Currenttools/librarieschanged';report['toolPins']=toolPins;report['producer']=pin(__file__);report['fixedPlan']=fixed
 saved=json.loads((previous/'packets.json').read_text());expected=saved['packets'];frames=saved['frames'];assert len(expected)==len(frames)==64
 for packet in expected:assert len([f for f in frames if f.get('pts')==packet['pts'] and f.get('pkt_pos')==packet['pos'] and f.get('pkt_size')==packet['size']])==1,'Savedfixedpicturebudgetauthority'
 assert sum(int(p['size']) for p in expected)==6_335_748<16_777_216
 assert expected[0]['pts']=='83652853' and expected[0]['flags']=='K__';report['fixedPacketFrameBudgetAuthority']=pin(previous/'packets.json');save();dataStart=time.monotonic();deadline=dataStart+30
 view=r/'view.mov'
 # n8.1.2 copy path: no outputss gives zero outputts_offset; defaultcopy_prior_start=-1 retains seekkey; explicitno clockshifting.
 run([ffmpeg,'-hide_banner','-nostdin','-copyts','-seek_timestamp','1','-ss','83.652853','-i',str(source),'-map','0:v:0','-an','-c:v','copy','-copytb','1','-frames:v','64','-avoid_negative_ts','disabled','-f','mov',str(view)],'streamcopy')
 report['view']=pin(view);save();assert view.stat().st_size<=16_777_216,'Closedprivateview16MiBbound'
 metadata=run([ffprobe,'-v','error','-show_packets','-show_streams','-show_format','-show_data_hash','sha256','-of','json',str(view)],'view-metadata')
 actual=json.loads(metadata);(r/'view-metadata.json').write_text(json.dumps(actual,indent=2));packets=actual['packets'];streams=actual['streams'];differences=[];fields=['pts','dts','duration','size','flags','data_hash']
 assert len(packets)==64 and len(streams)==1,'Exactly64packets/onevideostreamrequired'
 for i,(a,b) in enumerate(zip(expected,packets)):
  changed=[k for k in fields if str(a[k]).lower()!=str(b.get(k)).lower()]
  if changed:differences.append({'index':i,'fields':changed,'expected':a,'actual':b})
 report['packetDifferences']=differences;report['viewPacketCount']=len(packets);report['viewPacketPayloadBytes']=sum(int(p['size']) for p in packets);save()
 assert not differences,'Finiteview changedorderedpayload/PTS/DTS/duration/flags; stopbeforedecode'
 st=streams[0];oldStream=saved['stream'];streamKeys=['codec_name','width','height','color_space','color_transfer','color_primaries','time_base'];streamDifferences=[k for k in streamKeys if str(st.get(k))!=oldStream[k]]
 report['viewStream']=st;report['streamDifferences']=streamDifferences;save();assert not streamDifferences,'Finiteview codec/color/dimensions/clock changed'
 assert st['codec_type']=='video' and st['codec_tag_string']=='avc1' and st['profile']=='High' and st['level']==40,'NativeAVCcodecshape'
 assert st['extradata_size']==fixed['expectedAVCC']['bytes'] and st['extradata_hash'].lower()=='sha256:'+fixed['expectedAVCC']['sha256'],'NativeavcCcompletebyteidentity'
 assert st['pix_fmt']=='yuv420p' and st['color_range']=='tv' and st.get('field_order')=='progressive','Nativecolor/fieldshape'
 # MOV n8.1.2 mov_read_tkhd5255 emits DisplayMatrix iff composedmatrix!=identity; codedside_data exported10315.
 assert not any(d.get('side_data_type')=='Display Matrix' for d in st.get('side_data_list',[])),'Finiteview nativeidentitytransformchanged'
 report['metadataGate']='PASS:exact64orderedlogicalpackets+avcC+codec/color/dimensions/nativeidentitytransform';save()
 received=[];filtered=[];targetPTS=83_986_213;selected=[];showTB=[]
 def frameLine(key,line):
  if key!='stderr':return
  m=re.search(r'decoder -> pts:(-?\d+) pts_time:([^ ]+) pkt_dts:([^ ]+).*time_base:(\d+/\d+)',line)
  if m:received.append({'ptsAfterBestEffort':int(m[1]),'pts_time':m[2],'pkt_dts':m[3],'time_base':m[4],'line':line})
  m=re.search(r'\[Parsed_showinfo_0[^]]*\].*n:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:',line)
  if m:filtered.append({'n':int(m[1]),'pts':int(m[2]),'line':line})
  m=re.search(r'\[Parsed_showinfo_0[^]]*\].*config in time_base:\s*([0-9]+/[0-9]+)',line)
  if m:showTB.append(m[1])
  m=re.search(r'\[Parsed_showinfo_3[^]]*\].*n:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:',line)
  if m:selected.append({'n':int(m[1]),'pts':int(m[2]),'line':line})
 png=r/'current-ffmpeg.png'
 try:
  run([ffmpeg,'-hide_banner','-nostdin','-debug_ts','-copyts','-i',str(view),'-an','-vf',"showinfo,select='eq(pts,83986213)',format=rgb24,showinfo",'-fps_mode','passthrough','-frames:v','1','-update','1','-c:v','png','-pix_fmt','rgb24',str(png)],'decode',frameLine)
 finally:
  report['decoderReceivedFrames']=received;report['decoderReceivedCount']=len(received);report['filterFrames']=filtered;report['selectedFrames']=selected;report['showinfoTimeBases']=showTB;report['combinedFixedLogicalPictureWorkCount']=64+len(received);save()
 assert received and len(received)<=64 and all(f['time_base']=='1/1000000' for f in received),'Completereceiveauditempty/overshoot/clockfailure'
 assert showTB and all(t=='1/1000000' for t in showTB) and len(selected)==1 and selected[0]['pts']==targetPTS,'UniquePNGselectoroutputclock'
 assert png.is_file(),'ExactlyonePNGrequired';report['currentPNG']=pin(png);save()
 for label,image in [('reference',base/'confirm-01.png'),('current',png)]:
  raw=r/(label+'.rgba');run([plan['boundedPhases']['pixelCompare']['reader'],str(image),str(raw)],label+'-pixels');report[label+'RGBA']=pin(raw);save()
 a=(r/'reference.rgba').read_bytes();b=(r/'current.rgba').read_bytes();assert len(a)==len(b)==8_294_400,'CompleteRGBAgeometry'
 comparison={'bytes':len(a),'equal':a==b,'differentSamples':sum(x!=y for x,y in zip(a,b)),'differentPixels':sum(a[i:i+4]!=b[i:i+4] for i in range(0,len(a),4))};report['comparison']=comparison;save();assert a==b,'CompletecurrentFFmpegRGBA vs savedconfirm01 differs; stopRED'
 assert time.monotonic()<=deadline,'Shared30sdata deadline';report['passed']=True
except BaseException as error:
 report['error']={'type':type(error).__name__,'message':str(error)}
finally:
 report['dataElapsedSeconds']=None if deadline is None else time.monotonic()-(deadline-30)
 before=json.loads((r/'before-pins.json').read_text());report['afterPins']=[pin(p['path']) for p in before];report['inputsUnchanged']=report['afterPins']==before
 report['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({'passed':report['passed'],'error':report.get('error'),'report':str(r/'report.json'),'dataElapsedSeconds':report['dataElapsedSeconds']}),flush=True)
raise SystemExit(0 if report['passed'] and report['inputsUnchanged'] else 1)
