import pathlib,json,subprocess,hashlib
out=pathlib.Path('/tmp/screenrec-09c-public-complete');p=json.load(open(out/'report.json'));checks=[]
for v in p['checks']['aac']:
 r=v['settings']['audio']['sampleRate'];layout=v['settings']['audio']['layout'];channels=v['stream']['channels'];leaf=f'{r}-{layout}'
 decoded=subprocess.check_output(['ffmpeg','-v','error','-i',v['receipt']['output'],'-f','f32le','-'])
 ref=(out/f'reference-{layout}.f32').read_bytes()
 if r!=48000:ref=subprocess.check_output(['ffmpeg','-v','error','-f','f32le','-ar','48000','-ac',str(channels),'-i',str(out/f'reference-{layout}.f32'),'-ar',str(r),'-f','f32le','-'])
 assert hashlib.sha256(decoded).hexdigest()==v['decodedSha256']
 assert hashlib.sha256(ref).hexdigest()==v['referenceSha256']
 (out/f'decoded-{leaf}.f32').write_bytes(decoded);(out/f'oracle-{leaf}.f32').write_bytes(ref)
 checks.append({'rendition':leaf,'decodedMatchesOriginalReport':True,'referenceMatchesOriginalReport':True})
(out/'decoder-retention.json').write_text(json.dumps({'passed':True,'offlineRetentionOnly':True,'checks':checks},indent=2)+'\n')
print('4/4 original decoded and reference hashes reproduced')
