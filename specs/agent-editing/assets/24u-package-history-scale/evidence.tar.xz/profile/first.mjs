import {writeFile,realpath} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {callLocal} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/client/dist/index.js';
import {JourneyService,poll} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const home='/tmp/screenrec-24u-adoption-profile/fresh-receiver';const report={trace:[],scope:'First adoption of retained full package into separate receiver; original request/deadline unchanged',observations:[]};const service=new JourneyService(home,report);
try{await service.start();const call=(op,params)=>service.call(op,params,{transport:'mcp'});report.before=await call('project.list',{});const opened=await call('package.open',{path:await realpath('/tmp/screenrec-24u-package-history/pinned-after.zip')});const ready=await poll(()=>call('package.status',{admissionId:opened.id}),x=>x.state==='ready','open original package');
const deadline=performance.now()+180000;for(;;){if(performance.now()>deadline)throw new Error("Unchanged180s observation horizon reached");const at=performance.now();const result=await callLocal(home+'/library/run/service.sock',{id:randomUUID(),operation:'package.adopt',params:{packageHandle:ready.packageHandle,requestId:'adopt'}});report.observations.push({elapsedMs:performance.now()-at,result});if(!result.ok)break;if(result.data.state==='ready')break;await delay(100);}
report.after=await call('project.list',{});await call('package.close',{admissionId:opened.id});
}catch(error){report.error={message:error.message,stack:error.stack};throw error;}finally{await service.stop();await writeFile('/tmp/screenrec-24u-adoption-profile/first-report.json',JSON.stringify(report,null,2)+'\n');}
