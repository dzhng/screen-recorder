import {appendFileSync} from 'node:fs';
import {ProjectStore} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/projects.js';
import {ProjectPackages} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/project-packages.js';
import {PackageRegistry} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/package-registry.js';
import {DatabaseSync} from 'node:sqlite';
const path=`/tmp/screenrec-24u-adoption-profile/${process.pid}.jsonl`;
const stringify=JSON.stringify;const emit=row=>appendFileSync(path,stringify({pid:process.pid,atMs:performance.now(),...row})+'\n');
let active=false;const totals={};
for(const name of ['insertRevision','pushUndo']){const original=ProjectStore.prototype[name];ProjectStore.prototype[name]=function(...args){const at=performance.now();try{return original.apply(this,args);}finally{if(active){const v=totals[name]??={count:0,ms:0,maxMs:0};const ms=performance.now()-at;v.count++;v.ms+=ms;v.maxMs=Math.max(v.maxMs,ms);}}};}
const originalPrepare=ProjectStore.prototype.prepareAdoption;
ProjectStore.prototype.prepareAdoption=function(...args){const at=performance.now();emit({phase:'prepare-start',requestId:args[0].requestId,revisions:args[0].snapshot.revisions.length});let result;try{result=originalPrepare.apply(this,args);return result;}finally{emit({phase:'prepare-end',elapsedMs:performance.now()-at});if(result){const original=result.publish;result.publish=(...values)=>{const at=performance.now();active=true;emit({phase:'publish-start'});try{return original(...values);}finally{active=false;emit({phase:'publish-end',elapsedMs:performance.now()-at,totals});}};}}};
for(const [prototype,name] of [[ProjectPackages.prototype,'adopt'],[PackageRegistry.prototype,'submit']]){const original=prototype[name];prototype[name]=function(...args){const at=performance.now();emit({phase:name+'-start'});try{return original.apply(this,args);}finally{emit({phase:name+'-returned',elapsedMs:performance.now()-at});}};}
JSON.stringify=function(...args){const value=args[0];if(!value?.snapshot?.revisions)return stringify.apply(JSON,args);const at=performance.now();try{return stringify.apply(JSON,args);}finally{emit({phase:'snapshot-stringify',revisions:value.snapshot.revisions.length,elapsedMs:performance.now()-at});}};
const clone=globalThis.structuredClone;globalThis.structuredClone=function(...args){const value=args[0];if(!Array.isArray(value)||!value[0]?.document)return clone.apply(globalThis,args);const at=performance.now();try{return clone.apply(globalThis,args);}finally{emit({phase:'revisions-clone',count:value.length,elapsedMs:performance.now()-at});}};

const prepare = DatabaseSync.prototype.prepare;
DatabaseSync.prototype.prepare = function(sql, ...args) {
  const statement = prepare.call(this, sql, ...args);
  const kind = sql.startsWith('UPDATE projects SET currentRevisionId=') ? 'headUpdate' : sql.startsWith('INSERT INTO project_revisions') ? 'revisionInsert' : sql.startsWith('INSERT INTO projects') ? 'projectInsert' : null;
  if (kind) { const run = statement.run; statement.run = function(...values) { const at = performance.now(); try { return run.apply(this, values); } finally { if(active) { const v=totals[kind]??={count:0,ms:0,maxMs:0};const ms=performance.now()-at;v.count++;v.ms+=ms;v.maxMs=Math.max(v.maxMs,ms); if(kind==='headUpdate' && v.count%100===0) emit({phase:'sql-checkpoint',totals}); } } }; }
  return statement;
};
