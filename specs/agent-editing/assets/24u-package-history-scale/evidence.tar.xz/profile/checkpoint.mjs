import {writeFile,realpath,readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {callLocal} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/client/dist/index.js';
import {JourneyService,poll} from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/source-evidence-fixture.mjs';
const out='/tmp/screenrec-24u-adoption-profile',home=out+'/fresh-receiver';
const report={trace:[],observations:[],scope:'Same request after confirmed transaction rollback; retained full package; unchanged public15s deadline; separate bounded publication observation',peakRSS:0};
const service=new JourneyService(home,report);
try {
 await service.start(); const call=(op,params)=>service.call(op,params,{transport:'mcp'});
 report.before=await call('project.list',{});
 const opened=await call('package.open',{path:await realpath('/tmp/screenrec-24u-package-history/pinned-after.zip')});
 const ready=await poll(()=>call('package.status',{admissionId:opened.id}),x=>x.state==='ready','open');
 const at=performance.now();
 let settled=false;
 const request=callLocal(home+'/library/run/service.sock',{id:randomUUID(),operation:'package.adopt',params:{packageHandle:ready.packageHandle,requestId:'adopt'}}).then(result=>{report.observations.push({elapsedMs:performance.now()-at,result});},error=>{report.observations.push({elapsedMs:performance.now()-at,error:{message:error.message,code:error.code}});}).finally(()=>{settled=true;});
 for(;;) {
  const rss=Number(execFileSync('ps',['-o','rss=','-p',String(service.child.pid)],{encoding:'utf8'}).trim())*1024;report.peakRSS=Math.max(report.peakRSS,rss);
  if(rss>4*1024**3) {report.operationalStop='4GiB service RSS';service.child.kill('SIGKILL');break;}
  const trace=await readFile(out+'/'+service.child.pid+'.jsonl','utf8').catch(()=>'');
  if(trace.includes('"phase":"publish-end"')) {report.publicationObservedMs=performance.now()-at;break;}
  if(performance.now()-at>180000) {report.observationError='180s observation horizon; request deadline unchanged';break;}
  await delay(100);
 }
 await request;
 report.after=await call('project.list',{});
 report.sameIdentity=await call('package.adopt',{packageHandle:ready.packageHandle,requestId:'adopt'});
 await call('package.close',{admissionId:opened.id});
} catch(error) {report.error={message:error.message,stack:error.stack};}
finally {try{await service.stop();}catch(error){report.shutdownError=error.message;}await writeFile(out+'/checkpoint-report.json',JSON.stringify(report,null,2)+'\n');}
if(report.error||report.shutdownError||report.operationalStop)process.exitCode=1;
