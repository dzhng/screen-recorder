import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {spawn,execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
const source=await readFile('/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/test-harness/editing/package-history-scale.mjs','utf8');
const body=source.slice(source.indexOf('async function ownedProcesses'),source.indexOf('async function close'));
const run=promisify(execFile);
const {ownedProcesses,stopOwnedProcesses}=new Function('run',body+'\nreturn {ownedProcesses,stopOwnedProcesses};')(run);
const other=spawn(process.execPath,['-e','setInterval(()=>{},1000)']);
const parent=spawn(process.execPath,['-e',`const {spawn}=require('node:child_process');const c=spawn(process.execPath,['-e','setInterval(()=>{},1000)']);console.log(c.pid);setInterval(()=>{},1000);`],{stdio:['ignore','pipe','ignore']});
const parentExit=once(parent,'exit'),otherExit=once(other,'exit');let childPid;
try {
 childPid=Number((await once(parent.stdout,'data'))[0].toString().trim());
 const owned=await ownedProcesses(parent.pid);assert(owned.has(parent.pid));assert(owned.has(childPid));assert(!owned.has(other.pid));
 await stopOwnedProcesses(new Map([[other.pid,'different process start identity']]));process.kill(other.pid,0);
 await stopOwnedProcesses(owned);await parentExit;
 const until=Date.now()+2000;while((await ownedProcesses(childPid)).has(childPid)&&Date.now()<until)await delay(20);
 assert(!(await ownedProcesses(childPid)).has(childPid));process.kill(other.pid,0);
 const finish=source.slice(source.lastIndexOf('  try {\n    await close();')).trim().slice(0,-1);
 const finishRun=new (Object.getPrototypeOf(async function(){}).constructor)('close','report','writeFile','join','out',finish);
 let saved;const result={passed:true};await assert.rejects(finishRun(async()=>{throw new Error('shutdown control');},result,async(_p,text)=>{saved=JSON.parse(text);},(a,b)=>a+'/'+b,'unused'),/shutdown control/);
 assert.equal(saved.passed,false);assert.equal(saved.shutdownError,'shutdown control');
 await writeFile('/tmp/screenrec-24u-cleanup-control.json',JSON.stringify({passed:true,ownedParentAndChildTerminated:true,unrelatedProcessSurvived:true,startIdentityMismatchSurvived:true,shutdownFailurePersistedAsFailed:true,sourceSha256:(await import('node:crypto')).createHash('sha256').update(source).digest('hex')},null,2)+'\n');
}finally {for(const p of [parent,other])if(p.exitCode===null&&p.signalCode===null)p.kill('SIGKILL');await Promise.allSettled([parentExit,otherExit]);}
