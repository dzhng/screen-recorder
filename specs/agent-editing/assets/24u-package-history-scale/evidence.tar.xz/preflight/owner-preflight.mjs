import assert from 'node:assert/strict';
import { mkdir,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Catalog } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/catalog.js';
import { AssetStore } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/assets.js';
import { AcquisitionStore } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/acquisitions.js';
import { ProjectStore } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/projects.js';
import { TranscriptStore } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/transcript.js';
import { assetTranscriptOwner } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/transcript-processing.js';
import { projectPackageManifest,resourceMetadataMember,resourceMembers } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/project-package.js';
import { archiveLimits,projectJsonBytes } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/packages/core/dist/package-archive.js';
import { mediaWorker } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/worker.js';
import { readMediaProbe } from '/Users/david/.codex/worktrees/capture-pause-recovery/screen-recorder/apps/service/dist/media-probe.js';
const out='/tmp/screenrec-history-preflight';await mkdir(out,{mode:0o700});const library=out+'/library';await mkdir(library,{mode:0o700});const catalog=new Catalog(':memory:');const start=process.memoryUsage();const report={scope:'Five actual owner revisions;1000-history byte-count projection only. No projected document/history is persisted or adopted.',start,limits:{...archiveLimits,projectJsonBytes}};
const bytes=x=>Buffer.byteLength(JSON.stringify(x));const hash=x=>createHash('sha256').update(x).digest('hex');
try{
 const assets=new AssetStore(catalog,library);await assets.recover();const acquisitions=new AcquisitionStore(catalog);const projects=new ProjectStore(catalog,assets,new TranscriptStore(catalog,library,assetTranscriptOwner(assets,acquisitions)),acquisitions);
 const worker=mediaWorker({SCREENREC_NATIVE:'/Users/david/dev/screen-recorder/helpers/mac/.build/debug/screenrec-native'});
 const asset=await assets.import('/Users/david/dev/screen-recorder/specs/agent-editing/assets/18-voice/reference.wav',{kind:'import'},(path,signal)=>readMediaProbe(worker,out,path,signal,[]));
 const made=projects.create({requestId:'create',canvas:{width:320,height:240,fps:{numerator:30,denominator:1},background:'#000000ff'}});const pid=made.project.projectId;
 const operations=[{operation:'track.add',label:'audio',track:{kind:'audio',order:0}}];for(let i=0;i<250;i++)operations.push({operation:'place',clip:{trackId:{label:'audio'},assetId:asset.id,streamId:asset.streams[0].id,source:{kind:'range',range:{startUs:0,endUs:100000}},placement:{kind:'project',range:{startUs:i*100000,endUs:(i+1)*100000}}}});
 let revision=projects.apply(pid,{requestId:'place',expectedRevisionId:made.revision.id,operations}).revision;
 for(let i=2;i<5;i++)revision=projects.apply(pid,{requestId:`edit-${i}`,expectedRevisionId:revision.id,operations:[{operation:'canvas.set',canvas:{background:i%2?'#010203ff':'#030201ff'}}]}).revision;
 const snapshot=projects.snapshot(pid);const resource={kind:'asset',...assets.portable(asset.id)};const metadata=resourceMetadataMember(resource);const rows=snapshot.revisions.map(r=>({ordinal:r.ordinal,clips:r.document.clips.length,bytes:bytes(r),documentBytes:bytes(r.document),sha256:hash(JSON.stringify(r))}));
 let projectedRevisionBytes=bytes(made.revision),maximumRevisionBytes=0;for(let ordinal=1;ordinal<1000;ordinal++){const n=bytes({...revision,ordinal});projectedRevisionBytes+=n;maximumRevisionBytes=Math.max(maximumRevisionBytes,n);}
 const projected={...snapshot,revisions:Array.from({length:1000},(_,ordinal)=>({ordinal})),undo:Array(999).fill(revision.id),references:[snapshot.references[0],...Array(999).fill(snapshot.references[1])]};
 const inventory=[...Array.from({length:1000},(_,ordinal)=>({path:`revisions/${ordinal}.json`,bytes:ordinal?bytes({...revision,ordinal}):bytes(made.revision),sha256:'0'.repeat(64)})),...resourceMembers(resource),metadata.reference.metadata];
 const manifest=projectPackageManifest(projected,[resource],inventory);
 Object.assign(report,{actual:rows,assetId:asset.id,sourceBytes:asset.bytes,actualMetadataBytes:metadata.reference.metadata.bytes,projected:{revisionCount:1000,full250ClipDocuments:999,emptyCreationDocuments:1,revisionJsonBytes:projectedRevisionBytes,aggregateJsonBytes:projectedRevisionBytes+metadata.reference.metadata.bytes,maximumRevisionBytes,manifestBytes:bytes(manifest),dependencyEdges:projected.references.reduce((n,r)=>n+r.resources.length,0),archiveMembers:inventory.length+1,expandedMemberBytes:inventory.reduce((n,r)=>n+r.bytes,0)+bytes(manifest)},end:process.memoryUsage(),peakRSSBytes:process.resourceUsage().maxRSS*1024});
 assert(report.projected.aggregateJsonBytes<=projectJsonBytes);assert(maximumRevisionBytes<=archiveLimits.revisionBytes);assert(bytes(manifest)<=archiveLimits.manifestBytes);assert(report.projected.dependencyEdges<=25000);report.passed=true;
}finally{catalog.close();await writeFile(out+'/report.json',JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify(report.projected));
