# Review

Shape: one canonical process entry, no aliases/feature flags or extra engine. Existing project composition reused verbatim apart from removing its now-false isolated-development comment. Legacy mixed domain modules remain for the next preservation-guided removal pass; they are not a retained production entry.

Diff: native status edge supplies exact scripted idle facts over the actual app control pipe; startup and public socket/project behavior are real. The single new test retains complete first-failure operands before assertion and independently records successful process/socket teardown. Shared lifetime cases retain catalog-contention and real native workspace-lock refusal. Existing process harness retains pipe/socket/CLI/MCP, single owner, EOF/signal/crash/reopen and privacy refusal contracts.

Docs: README points to canonical main and distinguishes built source composition from installed adoption. Root README→apps/service/README.md links resolve. Root owns spec/handoff updates.

Independent root review fixed a stale project-service comment and consolidated the test operand writer. Codex CLI is not retried: the configured-model400 failure is already banked by root.

Qualification: red was before production change. Its test variant lacked only final teardown-record writing and later formatting/record-writer consolidation; the first startup assertion and fixture contract are unchanged. Original red and initial lifetime file failures are retained. Whole lifetime file17 passes; later single-test-only record-writer change passes independently, with final build/typecheck. No full suite or installed/media-quality verdict.
