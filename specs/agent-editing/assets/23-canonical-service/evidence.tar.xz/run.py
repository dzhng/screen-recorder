import subprocess,time,json,os,pathlib,sys
root='/Users/david/.codex/worktrees/service-composition/screen-recorder'
out=pathlib.Path(__file__).parent
label=sys.argv[1];argv=sys.argv[2:]
env=dict(os.environ)
env['SCREENREC_NATIVE']='/private/tmp/screenrec-09c-native-presented-worker'
if label.startswith(('red','green')):env['SCREENREC_SERVICE_ENTRY_OUTPUT']=str(out/(label+'-operands'))
began=time.monotonic();p=subprocess.Popen(argv,cwd=root,env=env,stdout=(out/(label+'.stdout')).open('w'),stderr=(out/(label+'.stderr')).open('w'))
try:p.wait(timeout=60)
except subprocess.TimeoutExpired:p.kill();p.wait()
report={'argv':argv,'pid':p.pid,'exitCode':p.returncode,'reaped':True,'elapsedSeconds':time.monotonic()-began,'cwd':root,'native':env['SCREENREC_NATIVE']}
(out/(label+'.process.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));sys.exit(p.returncode)
