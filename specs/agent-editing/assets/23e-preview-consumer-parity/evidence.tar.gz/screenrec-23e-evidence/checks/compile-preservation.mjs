import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { compileControlsCheck } from "/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder/apps/macos/tests/fixtures/swift-controls.mjs";
const root = "/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder";
for (const [name, marker, sources] of [
  ["preview-player.test.mjs", "writeFileSync(\n        source,", ["PreviewController", "PreviewWindow"]],
  ["preview-service.test.mjs", "await writeFile(\n        swift,", ["PreviewController", "PreviewWindow", "ServiceHost", "ServiceBundle", "NodeRuntime"]],
]) {
  const text = readFileSync(join(root, "apps/macos/tests", name), "utf8");
  const markerAt = text.indexOf(marker);
  assert.ok(markerAt >= 0);
  const start = text.indexOf("`", markerAt), end = text.indexOf("\n`,", start) + 2;
  assert.ok(start >= 0 && end > start);
  const literal = text.slice(start, end);
  assert.ok(!literal.includes("${"), "Compile only a literal Swift fixture, without evaluating JavaScript substitutions");
  const swift = Function('"use strict"; return ' + literal)();
  const scratch = mkdtempSync(join(tmpdir(), "screenrec-23e-preserved-"));
  try {
    compileControlsCheck(scratch, sources, swift);
    console.log(`PASS compile-only ${name}; executable deliberately not launched`);
  } finally { rmSync(scratch, { recursive: true, force: true }); }
}
