from pathlib import Path
import subprocess,tempfile,shutil
root=Path('/Users/david/.codex/worktrees/camera-project-adoption/screen-recorder')
scratch=Path(tempfile.mkdtemp(prefix='screenrec-23e-controls-'))
try:
 controls=sorted((root/'apps/macos/Sources/ScreenRecorderControls').glob('*.swift'))
 tests=sorted((root/'apps/macos/tests/ScreenRecorderControlsTests').glob('*.swift'))
 subprocess.run(['swiftc','-emit-library','-emit-module','-module-name','ScreenRecorderControls','-emit-module-path',str(scratch/'ScreenRecorderControls.swiftmodule'),'-o',str(scratch/'libScreenRecorderControls.dylib'),*map(str,controls)],check=True,timeout=60)
 subprocess.run(['swiftc','-swift-version','6','-I',str(scratch),'-L',str(scratch),'-lScreenRecorderControls','-Xlinker','-rpath','-Xlinker',str(scratch),*map(str,tests),'-o',str(scratch/'controls-check')],check=True,timeout=60)
 subprocess.run([str(scratch/'controls-check')],check=True,timeout=30)
finally:shutil.rmtree(scratch)
