# Review

Shape: PreviewController remains the only request/receipt/lease/generation owner.
PreviewWindow owns actual AppKit/AV construction and presentation callbacks only.
MediaTarget replaces the export-only enum/decoder, with direct consumers and no
compatibility aliases. The existing test compiler has one shared owner rather
than separate export/preview copies. No service, native worker or persisted
lifecycle changes were made.

Diff: independent root review against02619714 is clean, including the restored
post-renewal fence, platform presentation properties and unchanged assertions in
the original player/service fixtures. Source inspection confirms recording menu
entry and deletion now pass explicit recording targets; there is no project
chooser or automatic project. Default real-time clock behavior, MIME override,
ordinary playback, pause/remove cleanup and unshared window properties remain.

Checks: the first headless tracer ran after extracting the platform boundary and
before target porting. Preserved recording-only request logic failed the project
namespace assertion. A later targeted mutation removed only the post-renewal
generation guard; the check failed because stale renewal overwrote the new
session's lease. The production source was restored and all final affected checks
passed: three headless controller cases, sixteen pure-controls groups and both
original player/service Swift fixtures compiled without execution.

Docs/choices: the child and parent23 pointer keep isolated protocol behavior
separate from actual media, visual, listening and installed acceptance. The app
README describes the lifetime/presentation boundary. Root README/pickup remains
with the orchestrator. Choices document real presentation separation, one target
decoder and the explicit historical clock boundary.

No screenshot aesthetic or actual AV playback judgment was made. The configured
unavailable CLI reviewer was not retried. All owned processes exited and unique
scratch build directories were removed.
