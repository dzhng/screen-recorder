import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { ReadBuffer, serializeMessage, STDIO_DEFAULT_MAX_BUFFER_SIZE } from '/Users/david/dev/screen-recorder/apps/cli/node_modules/@modelcontextprotocol/sdk/dist/esm/shared/stdio.js';
const out = '/tmp/screenrec-mcp-receipt-size';
const bytes = value => Buffer.byteLength(JSON.stringify(value));
const report = { sdkMaximum: STDIO_DEFAULT_MAX_BUFFER_SIZE, serviceMaximum: 8*1024*1024, envelopeIdentity: 'Representative36-character operationUUID and2-digit MCPrequestid; only opaqueidentityvalues substituted, actual retained public receipt unchanged', cases: [] };
for (const requestId of ['place-9000','place-9500']) {
 const raw = await readFile(`${out}/${requestId}.json`);
 const data = JSON.parse(raw);
 for (const scope of requestId === 'place-9500' ? ['edit.apply','revision.get'] : ['edit.apply']) {
  const payload = scope === 'edit.apply' ? data : { revision: data.revision };
  const result = { id: '00000000-0000-0000-0000-000000000000', ok:true, data:payload };
  const response = { jsonrpc:'2.0', id:29, result:{ content:[{type:'text',text:JSON.stringify(result)}],structuredContent:result,isError:false } };
  const message = Buffer.from(serializeMessage(response));
  const buffer = new ReadBuffer();
  let outcome, chunkIndex=0;
  try {
   for (let start=0;start<message.length;start+=65536) {
    chunkIndex++; buffer.append(message.subarray(start,start+65536));
    const parsed = buffer.readMessage();
    if(parsed) outcome={accepted:true,id:parsed.id};
   }
  } catch(error) {outcome={accepted:false,message:error.message,chunkIndex};}
  report.cases.push({requestId,scope,ordinal:data.revision.ordinal,clips:data.revision.document.clips.length,
   storedReceiptBytes:raw.length,storedReceiptSha256:createHash('sha256').update(raw).digest('hex'),
   publicPayloadBytes:bytes(payload),serviceLineBytes:bytes(result)+1,
   mcpLineBytes:message.length,overSdkLimit:message.length-STDIO_DEFAULT_MAX_BUFFER_SIZE,outcome,
   components:{revision:bytes(data.revision),document:bytes(data.revision.document),edit:bytes(data.edit),...Object.fromEntries(Object.entries(data.edit).map(([key,value])=>['edit.'+key,bytes(value)]))}});
 }
}
await writeFile(`${out}/report.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
