import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { ReadBuffer, serializeMessage, STDIO_DEFAULT_MAX_BUFFER_SIZE } from '/Users/david/dev/screen-recorder/apps/cli/node_modules/@modelcontextprotocol/sdk/dist/esm/shared/stdio.js';
import { RESPONSE_FRAME_BYTES } from '/Users/david/dev/screen-recorder/packages/protocol/dist/framing.js';
const maxBufferSize = 3 * RESPONSE_FRAME_BYTES + 64 * 1024;
const raw = await readFile('/tmp/screenrec-mcp-receipt-size/place-9500.json');
const receipt = JSON.parse(raw);
const result = {id:'00000000-0000-0000-0000-000000000000',ok:true,data:receipt};
const response = {jsonrpc:'2.0',id:29,result:{content:[{type:'text',text:JSON.stringify(result)}],structuredContent:result,isError:false}};
const message = Buffer.from(serializeMessage(response));
const cases=[];
for(const limit of [STDIO_DEFAULT_MAX_BUFFER_SIZE,maxBufferSize]) {
 const buffer=new ReadBuffer({maxBufferSize:limit});
 let parsed, error;
 try {
  for(let offset=0;offset<message.length;offset+=65536) {
   buffer.append(message.subarray(offset,offset+65536));
   parsed=buffer.readMessage()??parsed;
  }
 }catch(caught){error=caught.message;}
 if(limit===maxBufferSize){assert.deepEqual(parsed,response);assert.deepEqual(JSON.parse(parsed.result.content[0].text).data,receipt);assert.deepEqual(parsed.result.structuredContent.data,receipt);}
 else assert.match(error,/ReadBuffer exceeded maximum size/);
 cases.push({maxBufferSize:limit,accepted:!!parsed,error:error??null,completeTextAndStructuredReceiptEqual:!!parsed});
}
const report={protocolResponseFrameBytes:RESPONSE_FRAME_BYTES,derivedMaximum:maxBufferSize,formula:'3 * RESPONSE_FRAME_BYTES + 64 * 1024',storedReceiptSha256:createHash('sha256').update(raw).digest('hex'),mcpLineBytes:message.length,ordinal:receipt.revision.ordinal,clips:receipt.revision.document.clips.length,cases,scope:'Retained exact full edit.apply receipt; representative fixed-width operation UUID and numeric MCP ID; SDK ReadBuffer reconstruction, not live wire replay. Bound excludes inline artifact payloads and concurrent buffered responses.'};
await writeFile('/tmp/screenrec-mcp-receipt-size/derived-bound-report.json',JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
