#!/Users/david/.nvm/versions/node/v24.14.0/bin/node
process.argv[2]='--native-proxy'; await import("/Users/david/.codex/worktrees/cutover-state-preservation/screen-recorder/packages/test-harness/editing/cutover-state.mjs");
