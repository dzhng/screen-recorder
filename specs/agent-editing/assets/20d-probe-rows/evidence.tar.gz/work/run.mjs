import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {Catalog} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/core/dist/catalog.js';
import {AssetStore,mediaProbeSchema,compositionAsset} from '/Users/david/.codex/worktrees/acquisition-picture-journey/screen-recorder/packages/core/dist/assets.js';
const phases=[];const mark=(name,start)=>phases.push({name,seconds:(performance.now()-start)/1000,rss:process.memoryUsage().rss,maxRSS:process.resourceUsage().maxRSS});
let t=performance.now();const bytes=gunzipSync(await readFile('/tmp/probe-file-parity/bulk-metadata.json.gz'));const raw=JSON.parse(bytes);mark('read+JSON parse',t);
t=performance.now();const decoded=mediaProbeSchema.parse(raw);mark('strict schema',t);assert.deepEqual(decoded,raw);
const directory=await mkdtemp('/tmp/probe-row-work-');const catalog=new Catalog(directory+'/catalog.sqlite');
try{const store=new AssetStore(catalog,directory);await store.recover();t=performance.now();const asset=await store.import('/tmp/source-admission-scale/source/narration.mov',{kind:'import'},async()=>raw);mark('owned copy + strict admission + SQLite publication',t);
t=performance.now();const retained=store.get(asset.id);assert.deepEqual(retained.streams,raw.streams);mark('stored metadata read + exact comparison',t);
t=performance.now();const resolved=compositionAsset(retained);mark('composition resolver',t);const expected=raw.streams[0].segments.filter(s=>!s.empty).map(({startUs,endUs})=>({startUs,endUs}));assert.deepEqual(resolved.streams[0].available,expected);
await writeFile('/tmp/probe-row-work.json',JSON.stringify({passed:true,metadataBytes:bytes.length,physicalRows:raw.streams[0].segments.length,occupiedRows:expected.length,phases,maxRSSUnit:'KiB (Node process.resourceUsage)',limits:'One process, framework/native worker excluded; no universal RSS bound inferred.'},null,2));
}finally{catalog.close();await rm(directory,{recursive:true,force:true});}
