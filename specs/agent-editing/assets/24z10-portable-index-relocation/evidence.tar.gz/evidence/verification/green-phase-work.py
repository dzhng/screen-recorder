from pathlib import Path
import subprocess
root=Path('/Users/david/.codex/worktrees/portable-index-relocation-work/screen-recorder')
p=root/'packages/core/src/portable-index.test.ts';original=p.read_text()
s=original.replace('import { mkdtempSync', 'import { cpSync, mkdtempSync',1)
s=s.replace('import { recordingSceneOwner','import { performance } from "node:perf_hooks";\nimport { recordingSceneOwner',1)
s=s.replace('async function fixture(count = 260) {','''const phaseRows: unknown[] = [];
const work: Record<string, {calls: number; elapsedMs: number}> = {};
const origin = performance.now();
let candidates = 0, coverages = 0, scenesWritten = 0;
const record = (phase: string) => {
  phaseRows.push({phase, elapsedMs: performance.now()-origin, candidates, coverages, scenesWritten, work: structuredClone(work)});
  writeFileSync("/tmp/24z10-profile/green-phase-work.json",JSON.stringify(phaseRows,null,2));
};
function observe<T>(key: string, run: () => T): T {
  const start=performance.now();
  try {return run();} finally {
    const row=work[key] ??= {calls:0,elapsedMs:0};row.calls++;row.elapsedMs+=performance.now()-start;
  }
}
async function fixture(count = 260) {''',1)
s=s.replace('  stores.add(store);','''  stores.add(store);
  record("store-created");
  const db=store.catalog, exec=db.exec.bind(db), prepare=db.prepare.bind(db);
  db.exec=(sql) => observe(sql.trim().split(/\\s+/).slice(0,2).join(" "),()=>exec(sql));
  db.prepare=(sql) => {
    const statement=observe("prepare",()=>prepare(sql));
    return new Proxy(statement,{get(target,key){const value=Reflect.get(target,key,target);return typeof value === "function" ? (...args: unknown[]) => observe(String(key)+":"+sql.trim().split(/\\s+/).slice(0,2).join(" "),()=>value.apply(target,args)) : value;}});
  };''',1)
s=s.replace('  scenes.finish(recordingSceneIdentity(sceneIdentity));','  scenesWritten=duration/10_000_000;\n  record("scene-appends-complete");\n  scenes.finish(recordingSceneIdentity(sceneIdentity));\n  record("scene-finish-complete");',1)
s=s.replace('    for (let part = 0;', '    candidates++;\n    for (let part = 0;',1)
s=s.replace('      });\n    }\n  }\n  await index.finish(identity);','      });\n      coverages++;\n    }\n    if (ordinal % 26 === 25) record("image-and-coverage-appends");\n  }\n  record("appends-complete");\n  await index.finish(identity);\n  record("fixture-complete");',1)
s=s.replace('  await writeSceneEvidencePages(', '  record("baseline-reads-complete");\n  await writeSceneEvidencePages(',1)
s=s.replace('  await writeScreenshotIndexPages(', '  record("scene-export-complete");\n  await writeScreenshotIndexPages(',1)
s=s.replace('    f.store.close();','''    record("index-export-complete");
    mkdirSync("/tmp/24z10-profile/green-values", { recursive: true });
    cpSync(join(f.root, "index"), "/tmp/24z10-profile/green-values/index", {recursive:true});
    cpSync(join(f.root, "scenes"), "/tmp/24z10-profile/green-values/scenes", {recursive:true});
    writeFileSync("/tmp/24z10-profile/green-values/catalog.sqlite",readFileSync(join(f.original,"catalog.sqlite")));
    writeFileSync("/tmp/24z10-profile/green-values/context.json",JSON.stringify({identity:f.identity,sceneIdentity:f.sceneIdentity,revision:f.revision},null,2));
    f.store.close();''',1)
start=s.index('test("scene chunks, retained images');end=s.index('\n  });',start)
s=s[:end]+'\n  record("full-oracles-complete");'+s[end:]
Path('/tmp/24z10-profile/green-phase-work-instrumented.ts').write_text(s)
p.write_text(s)
try:
 with open('/tmp/24z10-profile/green-phase-work-test.txt','w') as log:
  result=subprocess.run(['node','node_modules/vitest/vitest.mjs','run','packages/core/src/portable-index.test.ts','-t','scene chunks, retained images and coverage remain readable'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('Vitest exit:',result.returncode)
finally:p.write_text(original)
