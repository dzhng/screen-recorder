from pathlib import Path
import subprocess
root=Path('/Users/david/.codex/worktrees/portable-index-relocation-work/screen-recorder');p=root/'packages/core/src/portable-index.test.ts';original=p.read_text()
s=original.replace('    for (let ordinal = 0; ordinal < 260; ordinal++)','    writeFileSync(join(f.root, "moved-index", "images", "0.png"), Buffer.from("changed"));\n    for (let ordinal = 0; ordinal < 260; ordinal++)',1)
Path('/tmp/24z10-profile/image-control-instrumented.ts').write_text(s);p.write_text(s)
try:
 with open('/tmp/24z10-profile/image-control-red.txt','w') as log:
  r=subprocess.run(['node','node_modules/vitest/vitest.mjs','run','packages/core/src/portable-index.test.ts','-t','scene chunks, retained images and coverage remain readable'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('Vitest exit:',r.returncode)
finally:p.write_text(original)
