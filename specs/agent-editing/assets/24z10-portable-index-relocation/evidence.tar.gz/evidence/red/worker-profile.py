from pathlib import Path
import subprocess
root=Path('/Users/david/.codex/worktrees/portable-index-relocation-work/screen-recorder')
p=root/'packages/core/src/portable-index.test.ts'
original=p.read_text()
modified=original.replace('import { recordingSceneOwner', 'import { Session } from "node:inspector";\nimport { performance } from "node:perf_hooks";\nimport { recordingSceneOwner',1)
start=modified.index('test("scene chunks, retained images')
end=modified.index('\n});',start)
body=modified[start:end]
body=body.replace('  const f = await fixture();', '''  const session = new Session();
  session.connect();
  const post = (method: string) => new Promise<any>((resolve, reject) => session.post(method, (error, result) => error ? reject(error) : resolve(result)));
  const phases: {phase: string; elapsedMs: number}[] = [];
  const started = performance.now();
  const mark = (phase: string) => {
    phases.push({phase, elapsedMs: performance.now() - started});
    writeFileSync("/tmp/24z10-profile/worker-phases.json", JSON.stringify(phases, null, 2));
  };
  await post("Profiler.enable");
  await post("Profiler.start");
  try {
  const f = await fixture();
  mark("fixture-complete");''',1)
body=body.replace('  await writeSceneEvidencePages(', '  mark("baseline-reads-complete");\n  await writeSceneEvidencePages(',1)
body=body.replace('  await writeScreenshotIndexPages(', '  mark("scene-export-complete");\n  await writeScreenshotIndexPages(',1)
body=body.replace('  f.store.close();','  mark("index-export-complete");\n  f.store.close();',1)
body=body.replace('  const scenes = new FileSceneEvidence(', '  mark("relocation-complete");\n  const scenes = new FileSceneEvidence(',1)
body += '''
  mark("full-oracles-complete");
  } finally {
    mark("body-finally");
    const { profile } = await post("Profiler.stop");
    writeFileSync("/tmp/24z10-profile/worker.cpuprofile", JSON.stringify(profile));
    session.disconnect();
  }'''
modified=modified[:start]+body+modified[end:]
p.write_text(modified)
try:
  with open('/tmp/24z10-profile/worker-test.txt','w') as log:
    result=subprocess.run(['node','node_modules/vitest/vitest.mjs','run','packages/core/src/portable-index.test.ts','-t','scene chunks, retained images and coverage remain readable'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  print('Vitest exit:', result.returncode)
finally:
  p.write_text(original)
