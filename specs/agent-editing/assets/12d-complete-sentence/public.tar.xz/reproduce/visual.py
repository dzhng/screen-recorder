import subprocess,json,pathlib,hashlib
from PIL import Image
import numpy as np
root=pathlib.Path('/Users/david/.codex/worktrees/prepared-package-transfer/screen-recorder')
out=pathlib.Path('/private/tmp/screenrec-12d-public-pcm/visual');out.mkdir(exist_ok=True)
source=root/'fixtures/narrated-workbench/video.mov'
movie=out.parent/'candidate.mp4'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='ade26eacf8dce118e4fe16dcf261e7d3445d115e2b92721f0a01b8a4511de17a'
packets=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_packets','-show_entries','packet=pts','-of','json',str(source)]))['packets']
pts=sorted(p['pts'] for p in packets)
report={'intent':'Preserve the selected recording picture in a640x404 sentence edit, with one420ms time cut shared with audio. Source references show the containing physical source sample for each export clock. No continuous-playback or pixel/color identity claim.','pairs':[],'images':[]}
for index,frame in enumerate([0,108,109,201]):
    at=frame*1000000//30
    mapped=50518675+at+(420000 if at>=3610000 else 0)
    actual=max(p for p in pts if p<=mapped)
    paths=[]
    for kind,path,filt in [('source',source,f'select=eq(pts\\,{actual})'),('export',movie,f'select=eq(n\\,{frame})')]:
        target=out/f'{index+1}-{kind}.png'
        subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(path),'-vf',filt,'-frames:v','1','-update','1','-y',str(target)],check=True)
        paths.append(target)
        image=Image.open(target).convert('RGB'); w,h=image.size
        crops=[]
        for label,box in [('chrome',(0.03,0.01,0.97,0.17)),('body',(0.12,0.25,0.88,0.82))]:
            rect=tuple(round(v*(w if i%2==0 else h)) for i,v in enumerate(box))
            assert 0<=rect[0]<rect[2]<=w and 0<=rect[1]<rect[3]<=h
            crop=image.crop(rect)
            assert np.std(np.array(crop))>0
            # Preserve actual resolution; use2x for640px views,1x for3120px reference crops.
            scale=2 if w<1000 else 1
            crop=crop.resize((crop.width*scale,crop.height*scale),Image.Resampling.NEAREST)
            file=out/f'{index+1}-{kind}-{label}.png';crop.save(file)
            crops.append({'path':str(file),'box':rect,'scale':scale})
        arr=np.array(image).astype(float)
        report['images'].append({'path':str(target),'dimensions':[w,h],'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'luminance':float(arr.mean()),'std':float(arr.std()),'crops':crops})
    source_scaled=np.array(Image.open(paths[0]).convert('RGB').resize((640,404),Image.Resampling.LANCZOS)).astype(float)
    rendered=np.array(Image.open(paths[1]).convert('RGB')).astype(float)
    report['pairs'].append({'exportFrame':frame,'projectUs':at,'mappedSourceUs':mapped,'containingSourcePTS':actual,'source':str(paths[0]),'export':str(paths[1]),'scaledReferenceMAE':float(np.abs(source_scaled-rendered).mean()),'purpose':'Difference locator only; different resize and encoded color paths, no numeric acceptance threshold.'})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['pairs'],indent=2))
